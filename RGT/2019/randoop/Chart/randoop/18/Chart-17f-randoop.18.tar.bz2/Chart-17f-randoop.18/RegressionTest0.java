import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 1, (int) (short) 10, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths((int) (short) 100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (byte) 100, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) 13);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(1, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test014");
//        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
//        org.junit.Assert.assertNull(classLoader0);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) -1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test017");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = null;
//        try {
//            timeSeries4.add(timeSeriesDataItem8, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) -1, (int) (short) 10, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = null;
        try {
            timeSeries4.add(timeSeriesDataItem7, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) -1, 7, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(7, 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test028");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        try {
//            timeSeries4.setMaximumItemAge((long) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, 10, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("13-June-2019", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        timeSeries4.setRangeDescription("hi!");
        try {
            java.lang.Number number8 = timeSeries4.getValue((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = null;
        java.lang.Number number6 = null;
        try {
            timeSeries4.update(regularTimePeriod5, number6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) 100, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener8);
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) propertyChangeListener8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, class1);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeries2.getTimePeriod(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test043");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        long long5 = timeSeries4.getMaximumItemAge();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.lang.String str7 = day6.toString();
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day6, (double) 0, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener8);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries4.getTimePeriod(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        try {
            java.lang.Number number8 = timeSeries4.getValue(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        timeSeries4.setRangeDescription("hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = null;
        try {
            timeSeries4.update(regularTimePeriod7, (java.lang.Number) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("13-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test053");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries4.addChangeListener(seriesChangeListener18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = null;
//        try {
//            timeSeries4.add(timeSeriesDataItem20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(0, (int) '4', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths(100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        try {
            timeSeries4.update(6, (java.lang.Number) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2019, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-1), year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.lang.Class class0 = null;
        try {
            java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(2958465, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("org.jfree.data.time.TimePeriodFormatException: ", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.data.time.TimePeriodFormatException: ", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test081");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day13.equals(obj18);
//        java.util.Date date20 = day13.getStart();
//        java.util.TimeZone timeZone21 = null;
//        try {
//            org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20, timeZone21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date20);
//    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test082");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timeSeries4.removePropertyChangeListener(propertyChangeListener8);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        java.lang.Number number17 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) day15);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) 10.0f);
//        java.lang.Object obj28 = null;
//        boolean boolean29 = day23.equals(obj28);
//        java.util.Date date30 = day23.getStart();
//        java.lang.Class<?> wildcardClass31 = day23.getClass();
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day23, (java.lang.Number) 1900);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "13-June-2019" + "'", str16.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test083");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries16 = timeSeries13.createCopy((int) 'a', 6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
        try {
            org.jfree.data.time.SerialDate serialDate5 = serialDate3.getPreviousDayOfWeek(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(5, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "May" + "'", str2.equals("May"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test090");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class17);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries4.addAndOrUpdate(timeSeries18);
//        timeSeries18.setRangeDescription("May");
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(timeSeries19);
//    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test091");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getYear();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getMiddleMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test095");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day13.equals(obj18);
//        java.util.Calendar calendar20 = null;
//        try {
//            day13.peg(calendar20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("13-June-2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test098");
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.lang.String str7 = day6.toString();
//        java.lang.Number number8 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) day6);
//        boolean boolean9 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) 1, (java.lang.Object) number8);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test099");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = serialDate3.getEndOfCurrentMonth(serialDate7);
//        java.lang.String str9 = serialDate3.toString();
//        try {
//            org.jfree.data.time.SerialDate serialDate11 = serialDate3.getNearestDayOfWeek(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(7, (int) 'a', 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        timeSeries4.setRangeDescription("hi!");
        timeSeries4.setRangeDescription("");
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries4.getDataItem(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "" + "'", str0.equals(""));
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test104");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.clear();
//        int int9 = timeSeries4.getMaximumItemCount();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries4.getDataItem(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
//    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test105");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.clear();
//        try {
//            timeSeries4.removeAgedItems(0L, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = serialDate3.getEndOfCurrentMonth(serialDate7);
//        java.lang.String str9 = serialDate3.toString();
//        try {
//            org.jfree.data.time.SerialDate serialDate11 = serialDate3.getFollowingDayOfWeek((int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        boolean boolean6 = day4.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = serialDate3.getEndOfCurrentMonth(serialDate7);
        try {
            org.jfree.data.time.SerialDate serialDate10 = serialDate7.getPreviousDayOfWeek((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        timeSeries4.setRangeDescription("hi!");
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        try {
            org.jfree.data.time.TimeSeries timeSeries10 = timeSeries4.createCopy((int) 'a', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(class7);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test111");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        boolean boolean3 = day1.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate4 = day1.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate4);
//        java.lang.String str6 = serialDate4.toString();
//        java.lang.String str7 = serialDate4.toString();
//        try {
//            org.jfree.data.time.SerialDate serialDate9 = serialDate4.getPreviousDayOfWeek(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        int int8 = timeSeries4.getItemCount();
//        timeSeries4.setMaximumItemAge((long) (short) 0);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sunday" + "'", str1.equals("Sunday"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        boolean boolean6 = day4.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = serialDate3.getEndOfCurrentMonth(serialDate7);
        java.lang.String str9 = serialDate8.toString();
        try {
            org.jfree.data.time.SerialDate serialDate11 = serialDate8.getNearestDayOfWeek((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "30-June-2019" + "'", str9.equals("30-June-2019"));
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day13.equals(obj18);
//        java.util.Date date20 = day13.getStart();
//        java.util.TimeZone timeZone21 = null;
//        try {
//            org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20, timeZone21);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date20);
//    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test119");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        timeSeries4.setRangeDescription("hi!");
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        java.util.Collection collection8 = timeSeries4.getTimePeriods();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertNotNull(collection8);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(2958465);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 716968 + "'", int1 == 716968);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Sunday");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        boolean boolean5 = day3.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(13, serialDate6);
        java.lang.String str9 = serialDate8.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(10, serialDate8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test129");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.clear();
//        int int9 = timeSeries4.getMaximumItemCount();
//        try {
//            timeSeries4.removeAgedItems((long) 2, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        boolean boolean5 = day3.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(13, serialDate6);
        java.lang.String str9 = serialDate8.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(2147483647, serialDate8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(13);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(6, (int) (byte) 0, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, class1);
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        java.lang.Number number10 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        java.lang.Number number18 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) day16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (double) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) day16);
//        java.util.Calendar calendar22 = null;
//        try {
//            long long23 = day16.getLastMillisecond(calendar22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number10);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number18);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day13.equals(obj18);
//        java.util.Date date20 = day13.getStart();
//        java.lang.Class<?> wildcardClass21 = day13.getClass();
//        org.jfree.data.time.SerialDate serialDate22 = day13.getSerialDate();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(serialDate22);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries4.addChangeListener(seriesChangeListener18);
//        timeSeries4.setMaximumItemAge((long) (short) 10);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        java.lang.Number number29 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) day27);
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.lang.String str36 = day35.toString();
//        java.lang.Number number37 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) 10.0f);
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class43);
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timeSeries44.addPropertyChangeListener(propertyChangeListener45);
//        java.lang.String str47 = timeSeries44.getRangeDescription();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        boolean boolean52 = day50.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) day48, (org.jfree.data.time.RegularTimePeriod) day50);
//        int int54 = day35.compareTo((java.lang.Object) day50);
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day50);
//        java.util.Calendar calendar56 = null;
//        try {
//            long long57 = day50.getMiddleMillisecond(calendar56);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number29);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number37);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-June-2019" + "'", str49.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 1, 7, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(6);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June" + "'", str1.equals("June"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        java.lang.Class<?> wildcardClass6 = timeSeries4.getClass();
        java.lang.ClassLoader classLoader7 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass6);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(classLoader7);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test147");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        boolean boolean4 = year0.equals((java.lang.Object) day2);
//        java.util.Calendar calendar5 = null;
//        try {
//            year0.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day5.getMiddleMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        boolean boolean3 = day1.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate4 = day1.getSerialDate();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        boolean boolean7 = day5.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate9 = serialDate4.getEndOfCurrentMonth(serialDate8);
//        java.lang.String str10 = serialDate4.toString();
//        try {
//            org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, serialDate4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        java.lang.String str6 = timeSeries4.getRangeDescription();
        timeSeries4.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean4 = day2.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate5);
//        java.lang.String str7 = serialDate5.toString();
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths(0, serialDate5);
//        java.lang.String str9 = serialDate8.toString();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            year0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        try {
            java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) regularTimePeriod2);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        try {
            timeSeries4.delete((int) '#', 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.lang.String str7 = day6.toString();
//        java.lang.Number number8 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) day6);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day14, (double) 10.0f);
//        java.lang.Object obj19 = null;
//        boolean boolean20 = day14.equals(obj19);
//        java.util.Date date21 = day14.getStart();
//        java.lang.Class<?> wildcardClass22 = day14.getClass();
//        java.net.URL uRL23 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", (java.lang.Class) wildcardClass22);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(uRL23);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean4 = day2.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate5);
//        java.lang.String str7 = serialDate5.toString();
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths(0, serialDate5);
//        try {
//            org.jfree.data.time.SerialDate serialDate10 = serialDate5.getNearestDayOfWeek((int) 'a');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate8);
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timeSeries22.addPropertyChangeListener(propertyChangeListener23);
//        java.lang.String str25 = timeSeries22.getRangeDescription();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.lang.String str27 = day26.toString();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        boolean boolean30 = day28.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) day28);
//        int int32 = day13.compareTo((java.lang.Object) day28);
//        java.util.Calendar calendar33 = null;
//        try {
//            long long34 = day28.getLastMillisecond(calendar33);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timeSeries22.addPropertyChangeListener(propertyChangeListener23);
//        java.lang.String str25 = timeSeries22.getRangeDescription();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.lang.String str27 = day26.toString();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        boolean boolean30 = day28.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) day28);
//        int int32 = day13.compareTo((java.lang.Object) day28);
//        java.util.Calendar calendar33 = null;
//        try {
//            long long34 = day13.getFirstMillisecond(calendar33);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean9 = day7.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate10 = day7.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate11 = serialDate6.getEndOfCurrentMonth(serialDate10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        boolean boolean15 = day13.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate16);
//        java.lang.String str18 = serialDate16.toString();
//        org.jfree.data.time.SerialDate serialDate19 = serialDate11.getEndOfCurrentMonth(serialDate16);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        boolean boolean22 = day20.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate23 = day20.getSerialDate();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        boolean boolean26 = day24.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate27 = day24.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate28 = serialDate23.getEndOfCurrentMonth(serialDate27);
//        boolean boolean30 = spreadsheetDate2.isInRange(serialDate16, serialDate28, 2019);
//        try {
//            org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(716968, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        boolean boolean6 = day4.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate7);
        boolean boolean9 = spreadsheetDate2.isOnOrAfter(serialDate8);
        java.lang.String str10 = spreadsheetDate2.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.lang.Number number2 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeriesDataItem3.getPeriod();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        java.lang.Throwable[] throwableArray6 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '4', (int) '#', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        boolean boolean5 = day3.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
        boolean boolean8 = spreadsheetDate1.isOnOrAfter(serialDate7);
        int int9 = spreadsheetDate1.getMonth();
        org.jfree.data.time.SerialDate serialDate10 = null;
        try {
            org.jfree.data.time.SerialDate serialDate11 = spreadsheetDate1.getEndOfCurrentMonth(serialDate10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 1);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        java.lang.Number number12 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.String str19 = day18.toString();
//        java.lang.Number number20 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) day18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day18, (double) 10.0f);
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day18.equals(obj23);
//        java.util.Date date25 = day18.getStart();
//        java.lang.Class<?> wildcardClass26 = day18.getClass();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1, "30-June-2019", "30-June-2019", (java.lang.Class) wildcardClass26);
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class31);
//        java.beans.PropertyChangeListener propertyChangeListener33 = null;
//        timeSeries32.addPropertyChangeListener(propertyChangeListener33);
//        java.lang.String str35 = timeSeries32.getRangeDescription();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        java.lang.String str37 = day36.toString();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        boolean boolean40 = day38.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) day36, (org.jfree.data.time.RegularTimePeriod) day38);
//        java.lang.Class class45 = null;
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class45);
//        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries32.addAndOrUpdate(timeSeries46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        java.lang.Object obj50 = null;
//        boolean boolean51 = day48.equals(obj50);
//        java.lang.Number number52 = timeSeries47.getValue((org.jfree.data.time.RegularTimePeriod) day48);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries27.addAndOrUpdate(timeSeries47);
//        java.lang.Class class57 = null;
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class57);
//        java.beans.PropertyChangeListener propertyChangeListener59 = null;
//        timeSeries58.addPropertyChangeListener(propertyChangeListener59);
//        java.lang.String str61 = timeSeries58.getRangeDescription();
//        timeSeries58.setNotify(true);
//        java.util.List list64 = timeSeries58.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries58.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond66);
//        java.lang.Class class71 = null;
//        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class71);
//        java.beans.PropertyChangeListener propertyChangeListener73 = null;
//        timeSeries72.addPropertyChangeListener(propertyChangeListener73);
//        java.lang.String str75 = timeSeries72.getRangeDescription();
//        timeSeries72.setNotify(true);
//        java.util.List list78 = timeSeries72.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond80 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem81 = timeSeries72.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond80);
//        long long82 = fixedMillisecond80.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = fixedMillisecond80.previous();
//        timeSeries58.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond80);
//        try {
//            timeSeries53.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond80, (java.lang.Number) (-1.0f));
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "13-June-2019" + "'", str19.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number20);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "13-June-2019" + "'", str37.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertNotNull(timeSeries47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-June-2019" + "'", str49.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNull(number52);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "" + "'", str61.equals(""));
//        org.junit.Assert.assertNotNull(list64);
//        org.junit.Assert.assertNull(timeSeriesDataItem67);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "" + "'", str75.equals(""));
//        org.junit.Assert.assertNotNull(list78);
//        org.junit.Assert.assertNull(timeSeriesDataItem81);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 5L + "'", long82 == 5L);
//        org.junit.Assert.assertNotNull(regularTimePeriod83);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-459));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, class1);
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        java.lang.Number number10 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        java.lang.Number number18 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) day16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (double) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) day16);
//        try {
//            timeSeries2.removeAgedItems((long) 13, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number10);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number18);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        java.lang.Number number11 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) day9);
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.String str18 = day17.toString();
//        java.lang.Number number19 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) day17);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day17, (double) 10.0f);
//        java.lang.Object obj22 = null;
//        boolean boolean23 = day17.equals(obj22);
//        java.util.Date date24 = day17.getStart();
//        java.lang.Class<?> wildcardClass25 = day17.getClass();
//        java.io.InputStream inputStream26 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass25);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, "org.jfree.data.time.TimePeriodFormatException: ", "hi!", (java.lang.Class) wildcardClass25);
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.String str34 = day33.toString();
//        java.lang.Number number35 = timeSeries32.getValue((org.jfree.data.time.RegularTimePeriod) day33);
//        java.lang.Class class39 = null;
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class39);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        java.lang.String str42 = day41.toString();
//        java.lang.Number number43 = timeSeries40.getValue((org.jfree.data.time.RegularTimePeriod) day41);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day41, (double) 10.0f);
//        java.lang.Object obj46 = null;
//        boolean boolean47 = day41.equals(obj46);
//        java.util.Date date48 = day41.getStart();
//        java.util.TimeZone timeZone49 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date48, timeZone49);
//        java.util.TimeZone timeZone51 = null;
//        try {
//            org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date48, timeZone51);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number11);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number19);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(inputStream26);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "13-June-2019" + "'", str34.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number35);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "13-June-2019" + "'", str42.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number43);
//        org.junit.Assert.assertNull(timeSeriesDataItem45);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNull(regularTimePeriod50);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) -1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test175");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class17);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries4.addAndOrUpdate(timeSeries18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.lang.String str21 = day20.toString();
//        java.lang.Object obj22 = null;
//        boolean boolean23 = day20.equals(obj22);
//        java.lang.Number number24 = timeSeries19.getValue((org.jfree.data.time.RegularTimePeriod) day20);
//        timeSeries19.setNotify(true);
//        timeSeries19.clear();
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "13-June-2019" + "'", str21.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNull(number24);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection6 = timeSeries4.getTimePeriods();
        java.lang.Object obj7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) collection6);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(4, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Apr" + "'", str2.equals("Apr"));
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        java.lang.Class class0 = null;
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.lang.String str7 = day6.toString();
//        java.lang.Number number8 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) day6);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day14, (double) 10.0f);
//        java.lang.Object obj19 = null;
//        boolean boolean20 = day14.equals(obj19);
//        java.util.Date date21 = day14.getStart();
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date21, timeZone22);
//        java.util.TimeZone timeZone24 = null;
//        try {
//            org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date21, timeZone24);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.lang.Object obj0 = null;
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'object' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2019, 0, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        boolean boolean5 = day3.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
        boolean boolean8 = spreadsheetDate1.isOnOrAfter(serialDate7);
        try {
            int int10 = spreadsheetDate1.compareTo((java.lang.Object) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Byte cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(716968);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 716968");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test183");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 1);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        java.lang.Number number12 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.String str19 = day18.toString();
//        java.lang.Number number20 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) day18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day18, (double) 10.0f);
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day18.equals(obj23);
//        java.util.Date date25 = day18.getStart();
//        java.lang.Class<?> wildcardClass26 = day18.getClass();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1, "30-June-2019", "30-June-2019", (java.lang.Class) wildcardClass26);
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class31);
//        java.beans.PropertyChangeListener propertyChangeListener33 = null;
//        timeSeries32.addPropertyChangeListener(propertyChangeListener33);
//        java.lang.String str35 = timeSeries32.getRangeDescription();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        java.lang.String str37 = day36.toString();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        boolean boolean40 = day38.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) day36, (org.jfree.data.time.RegularTimePeriod) day38);
//        java.lang.Class class45 = null;
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class45);
//        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries32.addAndOrUpdate(timeSeries46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        java.lang.Object obj50 = null;
//        boolean boolean51 = day48.equals(obj50);
//        java.lang.Number number52 = timeSeries47.getValue((org.jfree.data.time.RegularTimePeriod) day48);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries27.addAndOrUpdate(timeSeries47);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = timeSeries53.getTimePeriod(13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "13-June-2019" + "'", str19.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number20);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "13-June-2019" + "'", str37.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertNotNull(timeSeries47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-June-2019" + "'", str49.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNull(number52);
//        org.junit.Assert.assertNotNull(timeSeries53);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class17);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries4.addAndOrUpdate(timeSeries18);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries22 = timeSeries4.createCopy(9, (-1));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(timeSeries19);
//    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test186");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        boolean boolean4 = year0.equals((java.lang.Object) day2);
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = year0.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries4.addChangeListener(seriesChangeListener18);
//        timeSeries4.setMaximumItemAge((long) (short) 10);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries4.getDataItem(7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance(12);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(100, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 1);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        java.lang.Number number12 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.String str19 = day18.toString();
//        java.lang.Number number20 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) day18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day18, (double) 10.0f);
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day18.equals(obj23);
//        java.util.Date date25 = day18.getStart();
//        java.lang.Class<?> wildcardClass26 = day18.getClass();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1, "30-June-2019", "30-June-2019", (java.lang.Class) wildcardClass26);
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class31);
//        java.beans.PropertyChangeListener propertyChangeListener33 = null;
//        timeSeries32.addPropertyChangeListener(propertyChangeListener33);
//        java.lang.String str35 = timeSeries32.getRangeDescription();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        java.lang.String str37 = day36.toString();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        boolean boolean40 = day38.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) day36, (org.jfree.data.time.RegularTimePeriod) day38);
//        java.lang.Class class45 = null;
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class45);
//        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries32.addAndOrUpdate(timeSeries46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        java.lang.Object obj50 = null;
//        boolean boolean51 = day48.equals(obj50);
//        java.lang.Number number52 = timeSeries47.getValue((org.jfree.data.time.RegularTimePeriod) day48);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries27.addAndOrUpdate(timeSeries47);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = null;
//        try {
//            timeSeries47.add(regularTimePeriod54, (double) '4', true);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "13-June-2019" + "'", str19.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number20);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "13-June-2019" + "'", str37.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertNotNull(timeSeries47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-June-2019" + "'", str49.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNull(number52);
//        org.junit.Assert.assertNotNull(timeSeries53);
//    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        int int14 = timeSeries4.getItemCount();
//        java.lang.Class class15 = timeSeries4.getTimePeriodClass();
//        timeSeries4.setKey((java.lang.Comparable) 0L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNull(class15);
//    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 1);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        java.lang.Number number12 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.String str19 = day18.toString();
//        java.lang.Number number20 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) day18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day18, (double) 10.0f);
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day18.equals(obj23);
//        java.util.Date date25 = day18.getStart();
//        java.lang.Class<?> wildcardClass26 = day18.getClass();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1, "30-June-2019", "30-June-2019", (java.lang.Class) wildcardClass26);
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class31);
//        java.beans.PropertyChangeListener propertyChangeListener33 = null;
//        timeSeries32.addPropertyChangeListener(propertyChangeListener33);
//        java.lang.String str35 = timeSeries32.getRangeDescription();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        java.lang.String str37 = day36.toString();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        boolean boolean40 = day38.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) day36, (org.jfree.data.time.RegularTimePeriod) day38);
//        java.lang.Class class45 = null;
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class45);
//        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries32.addAndOrUpdate(timeSeries46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        java.lang.Object obj50 = null;
//        boolean boolean51 = day48.equals(obj50);
//        java.lang.Number number52 = timeSeries47.getValue((org.jfree.data.time.RegularTimePeriod) day48);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries27.addAndOrUpdate(timeSeries47);
//        java.lang.Class class57 = null;
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class57);
//        java.beans.PropertyChangeListener propertyChangeListener59 = null;
//        timeSeries58.addPropertyChangeListener(propertyChangeListener59);
//        java.lang.String str61 = timeSeries58.getRangeDescription();
//        timeSeries58.setNotify(true);
//        java.util.List list64 = timeSeries58.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond66 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries58.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond66);
//        long long68 = fixedMillisecond66.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = fixedMillisecond66.previous();
//        java.lang.Class class73 = null;
//        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class73);
//        int int75 = fixedMillisecond66.compareTo((java.lang.Object) 10.0d);
//        java.util.Calendar calendar76 = null;
//        fixedMillisecond66.peg(calendar76);
//        int int79 = fixedMillisecond66.compareTo((java.lang.Object) 100L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = null;
//        try {
//            org.jfree.data.time.TimeSeries timeSeries81 = timeSeries27.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond66, regularTimePeriod80);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "13-June-2019" + "'", str19.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number20);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "13-June-2019" + "'", str37.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertNotNull(timeSeries47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-June-2019" + "'", str49.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNull(number52);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "" + "'", str61.equals(""));
//        org.junit.Assert.assertNotNull(list64);
//        org.junit.Assert.assertNull(timeSeriesDataItem67);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 5L + "'", long68 == 5L);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
//    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test194");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries4.addChangeListener(seriesChangeListener18);
//        timeSeries4.setMaximumItemAge((long) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond23.previous();
//        try {
//            timeSeries4.add(regularTimePeriod24, (java.lang.Number) 12, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test195");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 1);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        java.lang.Number number12 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.String str19 = day18.toString();
//        java.lang.Number number20 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) day18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day18, (double) 10.0f);
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day18.equals(obj23);
//        java.util.Date date25 = day18.getStart();
//        java.lang.Class<?> wildcardClass26 = day18.getClass();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1, "30-June-2019", "30-June-2019", (java.lang.Class) wildcardClass26);
//        timeSeries27.setKey((java.lang.Comparable) 100.0d);
//        java.lang.Number number31 = null;
//        try {
//            timeSeries27.update(5, number31);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "13-June-2019" + "'", str19.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number20);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 1);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        java.lang.Number number12 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.String str19 = day18.toString();
//        java.lang.Number number20 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) day18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day18, (double) 10.0f);
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day18.equals(obj23);
//        java.util.Date date25 = day18.getStart();
//        java.lang.Class<?> wildcardClass26 = day18.getClass();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1, "30-June-2019", "30-June-2019", (java.lang.Class) wildcardClass26);
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class31);
//        java.beans.PropertyChangeListener propertyChangeListener33 = null;
//        timeSeries32.addPropertyChangeListener(propertyChangeListener33);
//        java.lang.String str35 = timeSeries32.getRangeDescription();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        java.lang.String str37 = day36.toString();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        boolean boolean40 = day38.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) day36, (org.jfree.data.time.RegularTimePeriod) day38);
//        java.lang.Class class45 = null;
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class45);
//        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries32.addAndOrUpdate(timeSeries46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        java.lang.Object obj50 = null;
//        boolean boolean51 = day48.equals(obj50);
//        java.lang.Number number52 = timeSeries47.getValue((org.jfree.data.time.RegularTimePeriod) day48);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries27.addAndOrUpdate(timeSeries47);
//        java.lang.Class class55 = null;
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, class55);
//        java.lang.Class class60 = null;
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class60);
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        java.lang.String str63 = day62.toString();
//        java.lang.Number number64 = timeSeries61.getValue((org.jfree.data.time.RegularTimePeriod) day62);
//        java.lang.Class class68 = null;
//        org.jfree.data.time.TimeSeries timeSeries69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class68);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day();
//        java.lang.String str71 = day70.toString();
//        java.lang.Number number72 = timeSeries69.getValue((org.jfree.data.time.RegularTimePeriod) day70);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries61.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day70, (double) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem75 = timeSeries56.getDataItem((org.jfree.data.time.RegularTimePeriod) day70);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries47.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day70, (java.lang.Number) (byte) 10);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "13-June-2019" + "'", str19.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number20);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "13-June-2019" + "'", str37.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertNotNull(timeSeries47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-June-2019" + "'", str49.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNull(number52);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "13-June-2019" + "'", str63.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number64);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "13-June-2019" + "'", str71.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number72);
//        org.junit.Assert.assertNull(timeSeriesDataItem74);
//        org.junit.Assert.assertNull(timeSeriesDataItem75);
//        org.junit.Assert.assertNull(timeSeriesDataItem77);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection6 = timeSeries4.getTimePeriods();
        java.util.Collection collection7 = timeSeries4.getTimePeriods();
        try {
            java.lang.Number number9 = timeSeries4.getValue(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNotNull(collection7);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean4 = day2.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate5);
//        java.lang.String str7 = serialDate5.toString();
//        java.lang.String str8 = serialDate5.toString();
//        boolean boolean10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) serialDate5, (java.lang.Object) 0L);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears(12, serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(serialDate11);
//    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test200");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        try {
//            java.lang.Number number15 = timeSeries13.getValue((-460));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        try {
            org.jfree.data.time.TimeSeries timeSeries12 = timeSeries4.createCopy((int) '4', (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test203");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
//        boolean boolean8 = spreadsheetDate1.isOnOrAfter(serialDate7);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        java.lang.Number number24 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) 10.0f);
//        java.lang.Object obj27 = null;
//        boolean boolean28 = day22.equals(obj27);
//        java.util.Date date29 = day22.getStart();
//        java.lang.Class<?> wildcardClass30 = day22.getClass();
//        java.lang.ClassLoader classLoader31 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass30);
//        boolean boolean32 = spreadsheetDate1.equals((java.lang.Object) classLoader31);
//        java.util.Date date33 = spreadsheetDate1.toDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date33);
//        java.util.TimeZone timeZone35 = null;
//        try {
//            org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date33, timeZone35);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(classLoader31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(date33);
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test205");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.clear();
//        int int9 = timeSeries4.getMaximumItemCount();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        java.lang.Number number17 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) day15);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) 10.0f);
//        java.lang.Object obj28 = null;
//        boolean boolean29 = day23.equals(obj28);
//        java.util.Date date30 = day23.getStart();
//        java.lang.Number number31 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        try {
//            timeSeries4.delete((int) ' ', 9999);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "13-June-2019" + "'", str16.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNull(number31);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 8);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate7);
//        boolean boolean9 = spreadsheetDate2.isOnOrAfter(serialDate8);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        java.lang.Number number17 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) day15);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) 10.0f);
//        java.lang.Object obj28 = null;
//        boolean boolean29 = day23.equals(obj28);
//        java.util.Date date30 = day23.getStart();
//        java.lang.Class<?> wildcardClass31 = day23.getClass();
//        java.lang.ClassLoader classLoader32 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass31);
//        boolean boolean33 = spreadsheetDate2.equals((java.lang.Object) classLoader32);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        int int35 = spreadsheetDate2.getDayOfWeek();
//        int int36 = spreadsheetDate2.toSerial();
//        org.jfree.data.time.SerialDate serialDate37 = null;
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        boolean boolean42 = day40.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate43 = day40.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate43);
//        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addYears(13, serialDate43);
//        try {
//            boolean boolean46 = spreadsheetDate2.isInRange(serialDate37, serialDate45);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "13-June-2019" + "'", str16.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(classLoader32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 3 + "'", int35 == 3);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate45);
//    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.clear();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        java.lang.Number number24 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) 10.0f);
//        java.lang.Number number27 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        timeSeries4.setDescription("ERROR : Relative To String");
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = timeSeries4.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNull(number27);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.lang.Number number2 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 5L + "'", long5 == 5L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(13, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean4 = day2.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        boolean boolean8 = day6.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate5.getEndOfCurrentMonth(serialDate9);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        boolean boolean14 = day12.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate15);
//        java.lang.String str17 = serialDate15.toString();
//        org.jfree.data.time.SerialDate serialDate18 = serialDate10.getEndOfCurrentMonth(serialDate15);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        boolean boolean21 = day19.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        boolean boolean25 = day23.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate26 = day23.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate27 = serialDate22.getEndOfCurrentMonth(serialDate26);
//        boolean boolean29 = spreadsheetDate1.isInRange(serialDate15, serialDate27, 2019);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate33 = day30.getSerialDate();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        boolean boolean36 = day34.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate37 = day34.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate38 = serialDate33.getEndOfCurrentMonth(serialDate37);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        boolean boolean42 = day40.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate43 = day40.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate43);
//        java.lang.String str45 = serialDate43.toString();
//        org.jfree.data.time.SerialDate serialDate46 = serialDate38.getEndOfCurrentMonth(serialDate43);
//        boolean boolean47 = spreadsheetDate1.isOn(serialDate46);
//        try {
//            org.jfree.data.time.SerialDate serialDate49 = spreadsheetDate1.getFollowingDayOfWeek(8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "13-June-2019" + "'", str45.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.String str8 = day5.toString();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate7);
//        boolean boolean9 = spreadsheetDate2.isOnOrAfter(serialDate8);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        java.lang.Number number17 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) day15);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) 10.0f);
//        java.lang.Object obj28 = null;
//        boolean boolean29 = day23.equals(obj28);
//        java.util.Date date30 = day23.getStart();
//        java.lang.Class<?> wildcardClass31 = day23.getClass();
//        java.lang.ClassLoader classLoader32 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass31);
//        boolean boolean33 = spreadsheetDate2.equals((java.lang.Object) classLoader32);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(serialDate34);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "13-June-2019" + "'", str16.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(classLoader32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(serialDate34);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 11, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test217");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        boolean boolean4 = year0.equals((java.lang.Object) day2);
//        java.util.Calendar calendar5 = null;
//        try {
//            day2.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("May");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.lang.Object obj5 = timeSeries4.clone();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) 5);
        java.lang.Number number8 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, number8);
        timeSeriesDataItem9.setValue((java.lang.Number) (byte) 10);
        try {
            timeSeries4.add(timeSeriesDataItem9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(4);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class6);
        long long8 = timeSeries7.getMaximumItemAge();
        java.lang.Class<?> wildcardClass9 = timeSeries7.getClass();
        java.net.URL uRL10 = org.jfree.chart.util.ObjectUtilities.getResource("13-June-2019", (java.lang.Class) wildcardClass9);
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("30-June-2019", (java.lang.Class) wildcardClass9);
        java.lang.Object obj12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Sunday", (java.lang.Class) wildcardClass9);
        java.lang.ClassLoader classLoader13 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass9);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(uRL10);
        org.junit.Assert.assertNull(uRL11);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNotNull(classLoader13);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(100, (int) (byte) -1, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 3);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        try {
            org.jfree.data.time.Year year5 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (3) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "December 3" + "'", str3.equals("December 3"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day13.equals(obj18);
//        java.util.Date date20 = day13.getStart();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
//        java.util.Calendar calendar22 = null;
//        try {
//            long long23 = year21.getLastMillisecond(calendar22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date20);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) 1, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        long long5 = timeSeries4.getMaximumItemAge();
//        java.util.Collection collection6 = timeSeries4.getTimePeriods();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        java.lang.Number number14 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) day12);
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.lang.String str21 = day20.toString();
//        java.lang.Number number22 = timeSeries19.getValue((org.jfree.data.time.RegularTimePeriod) day20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day20, (double) 10.0f);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class28);
//        java.beans.PropertyChangeListener propertyChangeListener30 = null;
//        timeSeries29.addPropertyChangeListener(propertyChangeListener30);
//        java.lang.String str32 = timeSeries29.getRangeDescription();
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.String str34 = day33.toString();
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        boolean boolean37 = day35.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) day33, (org.jfree.data.time.RegularTimePeriod) day35);
//        int int39 = day20.compareTo((java.lang.Object) day35);
//        try {
//            timeSeries4.update((org.jfree.data.time.RegularTimePeriod) day20, (java.lang.Number) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(collection6);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "13-June-2019" + "'", str21.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number22);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "13-June-2019" + "'", str34.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class5);
        long long7 = timeSeries6.getMaximumItemAge();
        java.lang.Class<?> wildcardClass8 = timeSeries6.getClass();
        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResource("13-June-2019", (java.lang.Class) wildcardClass8);
        java.io.InputStream inputStream10 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Sunday", (java.lang.Class) wildcardClass8);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(uRL9);
        org.junit.Assert.assertNull(inputStream10);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test230");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        timeSeries4.setNotify(true);
//        timeSeries4.setMaximumItemCount(3);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        java.lang.Number number14 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = null;
//        try {
//            timeSeries4.add(regularTimePeriod15, 100.0d, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number14);
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        timeSeries4.setRangeDescription("hi!");
        timeSeries4.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond10.previous();
        java.lang.Number number12 = timeSeries4.getValue(regularTimePeriod11);
        java.lang.Object obj13 = timeSeries4.clone();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener14);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNotNull(obj13);
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = day0.equals(obj2);
//        java.util.Date date4 = day0.getEnd();
//        int int5 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean4 = day2.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        boolean boolean8 = day6.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate5.getEndOfCurrentMonth(serialDate9);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        boolean boolean14 = day12.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate15);
//        java.lang.String str17 = serialDate15.toString();
//        org.jfree.data.time.SerialDate serialDate18 = serialDate10.getEndOfCurrentMonth(serialDate15);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        boolean boolean21 = day19.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        boolean boolean25 = day23.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate26 = day23.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate27 = serialDate22.getEndOfCurrentMonth(serialDate26);
//        boolean boolean29 = spreadsheetDate1.isInRange(serialDate15, serialDate27, 2019);
//        org.jfree.data.time.SerialDate serialDate30 = null;
//        try {
//            boolean boolean31 = spreadsheetDate1.isOnOrBefore(serialDate30);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(9999);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        boolean boolean4 = day2.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        boolean boolean8 = day6.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.SerialDate serialDate10 = serialDate5.getEndOfCurrentMonth(serialDate9);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addDays((int) (short) 100, serialDate10);
        try {
            org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(2019, serialDate11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        java.lang.Number number2 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number2);
//        timeSeriesDataItem3.setValue((java.lang.Number) (byte) 10);
//        java.lang.Class class9 = null;
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.lang.String str12 = day11.toString();
//        java.lang.Number number13 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) day11);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.lang.String str20 = day19.toString();
//        java.lang.Number number21 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) day19);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries10.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day19, (double) 10.0f);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        java.lang.Number number31 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) day29);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries10.addAndOrUpdate(timeSeries28);
//        java.lang.Class class34 = null;
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), class34);
//        java.util.Collection collection36 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries35);
//        timeSeries35.fireSeriesChanged();
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
//        long long39 = year38.getSerialIndex();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        java.lang.String str41 = day40.toString();
//        boolean boolean42 = year38.equals((java.lang.Object) day40);
//        int int43 = timeSeries35.getIndex((org.jfree.data.time.RegularTimePeriod) day40);
//        java.lang.Class class47 = null;
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class47);
//        timeSeries48.setRangeDescription("hi!");
//        java.lang.Class class51 = timeSeries48.getTimePeriodClass();
//        java.util.Collection collection52 = timeSeries35.getTimePeriodsUniqueToOtherSeries(timeSeries48);
//        timeSeries48.removeAgedItems(true);
//        boolean boolean55 = timeSeriesDataItem3.equals((java.lang.Object) true);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = timeSeriesDataItem3.getPeriod();
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number13);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number21);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "13-June-2019" + "'", str30.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number31);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNotNull(collection36);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 2019L + "'", long39 == 2019L);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "13-June-2019" + "'", str41.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
//        org.junit.Assert.assertNull(class51);
//        org.junit.Assert.assertNotNull(collection52);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        boolean boolean5 = day3.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(13, serialDate6);
        java.lang.Object obj9 = null;
        boolean boolean10 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) serialDate6, obj9);
        try {
            org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 0, serialDate6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(8);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean4 = day2.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate5);
//        java.lang.String str7 = serialDate5.toString();
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths(0, serialDate5);
//        try {
//            org.jfree.data.time.SerialDate serialDate10 = serialDate5.getNearestDayOfWeek((int) ' ');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate8);
//    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        long long14 = timeSeries4.getMaximumItemAge();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener15);
//        java.lang.Comparable comparable17 = timeSeries4.getKey();
//        java.lang.Comparable comparable18 = null;
//        try {
//            timeSeries4.setKey(comparable18);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + 10.0d + "'", comparable17.equals(10.0d));
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener8);
        try {
            timeSeries4.delete((int) (byte) 10, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries4.addChangeListener(seriesChangeListener18);
//        timeSeries4.setMaximumItemAge((long) (short) 10);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        java.lang.Number number29 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) day27);
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.lang.String str36 = day35.toString();
//        java.lang.Number number37 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) 10.0f);
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class43);
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timeSeries44.addPropertyChangeListener(propertyChangeListener45);
//        java.lang.String str47 = timeSeries44.getRangeDescription();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        boolean boolean52 = day50.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) day48, (org.jfree.data.time.RegularTimePeriod) day50);
//        int int54 = day35.compareTo((java.lang.Object) day50);
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day50);
//        java.lang.Class class59 = null;
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class59);
//        java.beans.PropertyChangeListener propertyChangeListener61 = null;
//        timeSeries60.addPropertyChangeListener(propertyChangeListener61);
//        java.lang.String str63 = timeSeries60.getRangeDescription();
//        timeSeries60.setNotify(true);
//        java.util.List list66 = timeSeries60.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = timeSeries60.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68);
//        long long70 = fixedMillisecond68.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = fixedMillisecond68.previous();
//        java.lang.Class class75 = null;
//        org.jfree.data.time.TimeSeries timeSeries76 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class75);
//        int int77 = fixedMillisecond68.compareTo((java.lang.Object) 10.0d);
//        java.util.Calendar calendar78 = null;
//        fixedMillisecond68.peg(calendar78);
//        long long80 = fixedMillisecond68.getFirstMillisecond();
//        java.lang.Number number81 = null;
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68, number81, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number29);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number37);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-June-2019" + "'", str49.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "" + "'", str63.equals(""));
//        org.junit.Assert.assertNotNull(list66);
//        org.junit.Assert.assertNull(timeSeriesDataItem69);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 5L + "'", long70 == 5L);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 5L + "'", long80 == 5L);
//    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day13.equals(obj18);
//        java.util.Date date20 = day13.getStart();
//        java.lang.Class<?> wildcardClass21 = day13.getClass();
//        java.lang.ClassLoader classLoader22 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass21);
//        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(classLoader22);
//        org.junit.Assert.assertNotNull(class23);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timeSeries22.addPropertyChangeListener(propertyChangeListener23);
//        java.lang.String str25 = timeSeries22.getRangeDescription();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.lang.String str27 = day26.toString();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        boolean boolean30 = day28.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) day28);
//        int int32 = day13.compareTo((java.lang.Object) day28);
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class36);
//        java.beans.PropertyChangeListener propertyChangeListener38 = null;
//        timeSeries37.addPropertyChangeListener(propertyChangeListener38);
//        java.lang.String str40 = timeSeries37.getRangeDescription();
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        java.lang.String str42 = day41.toString();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        boolean boolean45 = day43.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries37.createCopy((org.jfree.data.time.RegularTimePeriod) day41, (org.jfree.data.time.RegularTimePeriod) day43);
//        int int47 = timeSeries37.getItemCount();
//        java.lang.Class class48 = timeSeries37.getTimePeriodClass();
//        boolean boolean49 = day13.equals((java.lang.Object) class48);
//        java.util.Calendar calendar50 = null;
//        try {
//            long long51 = day13.getFirstMillisecond(calendar50);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "13-June-2019" + "'", str42.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertNull(class48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("December 3");
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test254");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        java.lang.Number number14 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) day12);
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.lang.String str21 = day20.toString();
//        java.lang.Number number22 = timeSeries19.getValue((org.jfree.data.time.RegularTimePeriod) day20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day20, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
//        timeSeries11.addChangeListener(seriesChangeListener25);
//        timeSeries11.setMaximumItemAge((long) (short) 10);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
//        long long30 = year29.getSerialIndex();
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        java.lang.String str32 = day31.toString();
//        boolean boolean33 = year29.equals((java.lang.Object) day31);
//        java.lang.Number number34 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) day31);
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day31, (java.lang.Number) 9223372036854775807L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "13-June-2019" + "'", str21.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number22);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2019L + "'", long30 == 2019L);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "13-June-2019" + "'", str32.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 10.0d + "'", number34.equals(10.0d));
//    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
//        boolean boolean8 = spreadsheetDate1.isOnOrAfter(serialDate7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean11 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        boolean boolean14 = day12.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        boolean boolean18 = day16.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate19 = day16.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = serialDate15.getEndOfCurrentMonth(serialDate19);
//        java.lang.String str21 = serialDate20.toString();
//        java.lang.String str22 = serialDate20.toString();
//        java.lang.String str23 = serialDate20.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        boolean boolean29 = day27.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate30 = day27.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate30);
//        boolean boolean32 = spreadsheetDate25.isOnOrAfter(serialDate31);
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        java.lang.String str39 = day38.toString();
//        java.lang.Number number40 = timeSeries37.getValue((org.jfree.data.time.RegularTimePeriod) day38);
//        java.lang.Class class44 = null;
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        java.lang.String str47 = day46.toString();
//        java.lang.Number number48 = timeSeries45.getValue((org.jfree.data.time.RegularTimePeriod) day46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day46, (double) 10.0f);
//        java.lang.Object obj51 = null;
//        boolean boolean52 = day46.equals(obj51);
//        java.util.Date date53 = day46.getStart();
//        java.lang.Class<?> wildcardClass54 = day46.getClass();
//        java.lang.ClassLoader classLoader55 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass54);
//        boolean boolean56 = spreadsheetDate25.equals((java.lang.Object) classLoader55);
//        boolean boolean58 = spreadsheetDate1.isInRange(serialDate20, (org.jfree.data.time.SerialDate) spreadsheetDate25, (int) (short) -1);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        boolean boolean64 = day62.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate65 = day62.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate65);
//        boolean boolean67 = spreadsheetDate60.isOnOrAfter(serialDate66);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate69 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean70 = spreadsheetDate60.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate69);
//        org.jfree.data.time.SerialDate serialDate71 = null;
//        try {
//            boolean boolean72 = spreadsheetDate25.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate60, serialDate71);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "30-June-2019" + "'", str21.equals("30-June-2019"));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "30-June-2019" + "'", str22.equals("30-June-2019"));
//        org.junit.Assert.assertNull(str23);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "13-June-2019" + "'", str39.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number40);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "13-June-2019" + "'", str47.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number48);
//        org.junit.Assert.assertNull(timeSeriesDataItem50);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertNotNull(classLoader55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        int int8 = timeSeries4.getItemCount();
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        long long4 = month2.getSerialIndex();
        try {
            org.jfree.data.time.Year year5 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (3) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 48L + "'", long4 == 48L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-458) + "'", int1 == (-458));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        int int14 = timeSeries4.getItemCount();
//        java.lang.Class class15 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNull(class15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate7);
//        boolean boolean9 = spreadsheetDate2.isOnOrAfter(serialDate8);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        java.lang.Number number17 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) day15);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) 10.0f);
//        java.lang.Object obj28 = null;
//        boolean boolean29 = day23.equals(obj28);
//        java.util.Date date30 = day23.getStart();
//        java.lang.Class<?> wildcardClass31 = day23.getClass();
//        java.lang.ClassLoader classLoader32 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass31);
//        boolean boolean33 = spreadsheetDate2.equals((java.lang.Object) classLoader32);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        try {
//            org.jfree.data.time.SerialDate serialDate36 = serialDate34.getNearestDayOfWeek(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "13-June-2019" + "'", str16.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(classLoader32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(serialDate34);
//    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test262");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getYear();
//        java.lang.String str3 = day0.toString();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1.0d);
        java.lang.String str2 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1.0]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=1.0]"));
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries4.addAndOrUpdate(timeSeries22);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), class28);
//        java.util.Collection collection30 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries29);
//        timeSeries29.fireSeriesChanged();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        long long33 = year32.getSerialIndex();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.lang.String str35 = day34.toString();
//        boolean boolean36 = year32.equals((java.lang.Object) day34);
//        int int37 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) day34);
//        java.lang.Class class41 = null;
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class41);
//        java.beans.PropertyChangeListener propertyChangeListener43 = null;
//        timeSeries42.addPropertyChangeListener(propertyChangeListener43);
//        java.lang.String str45 = timeSeries42.getRangeDescription();
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        java.lang.String str47 = day46.toString();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        boolean boolean50 = day48.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries42.createCopy((org.jfree.data.time.RegularTimePeriod) day46, (org.jfree.data.time.RegularTimePeriod) day48);
//        java.lang.Class class55 = null;
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class55);
//        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries42.addAndOrUpdate(timeSeries56);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
//        long long59 = year58.getSerialIndex();
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        java.lang.String str61 = day60.toString();
//        boolean boolean62 = year58.equals((java.lang.Object) day60);
//        timeSeries56.delete((org.jfree.data.time.RegularTimePeriod) day60);
//        java.util.Collection collection64 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries56);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNotNull(collection30);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "13-June-2019" + "'", str35.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "13-June-2019" + "'", str47.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(timeSeries51);
//        org.junit.Assert.assertNotNull(timeSeries57);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 2019L + "'", long59 == 2019L);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "13-June-2019" + "'", str61.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(collection64);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Apr", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class8);
        long long10 = timeSeries9.getMaximumItemAge();
        java.lang.Class<?> wildcardClass11 = timeSeries9.getClass();
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResource("13-June-2019", (java.lang.Class) wildcardClass11);
        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("30-June-2019", (java.lang.Class) wildcardClass11);
        java.lang.Object obj14 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Sunday", (java.lang.Class) wildcardClass11);
        java.net.URL uRL15 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesException: ", (java.lang.Class) wildcardClass11);
        java.net.URL uRL16 = org.jfree.chart.util.ObjectUtilities.getResource("ClassContext", (java.lang.Class) wildcardClass11);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNull(uRL12);
        org.junit.Assert.assertNull(uRL13);
        org.junit.Assert.assertNull(obj14);
        org.junit.Assert.assertNull(uRL15);
        org.junit.Assert.assertNull(uRL16);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(2019);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries4.addChangeListener(seriesChangeListener18);
//        timeSeries4.setMaximumItemAge((long) (short) 10);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        java.lang.Number number29 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) day27);
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.lang.String str36 = day35.toString();
//        java.lang.Number number37 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) 10.0f);
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class43);
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timeSeries44.addPropertyChangeListener(propertyChangeListener45);
//        java.lang.String str47 = timeSeries44.getRangeDescription();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        boolean boolean52 = day50.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) day48, (org.jfree.data.time.RegularTimePeriod) day50);
//        int int54 = day35.compareTo((java.lang.Object) day50);
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day50);
//        java.lang.String str56 = day50.toString();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number29);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number37);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-June-2019" + "'", str49.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "13-June-2019" + "'", str56.equals("13-June-2019"));
//    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class17);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries4.addAndOrUpdate(timeSeries18);
//        java.lang.Class class23 = null;
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class23);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        java.lang.String str26 = day25.toString();
//        java.lang.Number number27 = timeSeries24.getValue((org.jfree.data.time.RegularTimePeriod) day25);
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.String str34 = day33.toString();
//        java.lang.Number number35 = timeSeries32.getValue((org.jfree.data.time.RegularTimePeriod) day33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day33, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener38 = null;
//        timeSeries24.addChangeListener(seriesChangeListener38);
//        timeSeries24.setMaximumItemAge((long) (short) 10);
//        java.lang.Class class45 = null;
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class45);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        java.lang.Number number49 = timeSeries46.getValue((org.jfree.data.time.RegularTimePeriod) day47);
//        java.lang.Class class53 = null;
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class53);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        java.lang.String str56 = day55.toString();
//        java.lang.Number number57 = timeSeries54.getValue((org.jfree.data.time.RegularTimePeriod) day55);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day55, (double) 10.0f);
//        java.lang.Class class63 = null;
//        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class63);
//        java.beans.PropertyChangeListener propertyChangeListener65 = null;
//        timeSeries64.addPropertyChangeListener(propertyChangeListener65);
//        java.lang.String str67 = timeSeries64.getRangeDescription();
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
//        java.lang.String str69 = day68.toString();
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day();
//        boolean boolean72 = day70.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries64.createCopy((org.jfree.data.time.RegularTimePeriod) day68, (org.jfree.data.time.RegularTimePeriod) day70);
//        int int74 = day55.compareTo((java.lang.Object) day70);
//        timeSeries24.delete((org.jfree.data.time.RegularTimePeriod) day70);
//        java.util.Date date76 = day70.getEnd();
//        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date76);
//        boolean boolean78 = timeSeries18.equals((java.lang.Object) year77);
//        timeSeries18.setMaximumItemCount((int) (byte) 0);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "13-June-2019" + "'", str26.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number27);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "13-June-2019" + "'", str34.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number35);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "13-June-2019" + "'", str48.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number49);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "13-June-2019" + "'", str56.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number57);
//        org.junit.Assert.assertNull(timeSeriesDataItem59);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "" + "'", str67.equals(""));
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "13-June-2019" + "'", str69.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNotNull(timeSeries73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class17);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries4.addAndOrUpdate(timeSeries18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.lang.String str21 = day20.toString();
//        java.lang.Object obj22 = null;
//        boolean boolean23 = day20.equals(obj22);
//        java.lang.Number number24 = timeSeries19.getValue((org.jfree.data.time.RegularTimePeriod) day20);
//        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(12, 3);
//        java.lang.String str28 = month27.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month27.next();
//        int int30 = month27.getYearValue();
//        java.lang.Number number31 = null;
//        try {
//            timeSeries19.add((org.jfree.data.time.RegularTimePeriod) month27, number31);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "13-June-2019" + "'", str21.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "December 3" + "'", str28.equals("December 3"));
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
//        boolean boolean8 = spreadsheetDate1.isOnOrAfter(serialDate7);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        java.lang.Number number24 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) 10.0f);
//        java.lang.Object obj27 = null;
//        boolean boolean28 = day22.equals(obj27);
//        java.util.Date date29 = day22.getStart();
//        java.lang.Class<?> wildcardClass30 = day22.getClass();
//        java.lang.ClassLoader classLoader31 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass30);
//        boolean boolean32 = spreadsheetDate1.equals((java.lang.Object) classLoader31);
//        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader31);
//        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader31);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(classLoader31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        java.util.List list10 = timeSeries4.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond12.getMiddleMillisecond(calendar15);
        long long17 = fixedMillisecond12.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5L + "'", long14 == 5L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 5L + "'", long16 == 5L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 5L + "'", long17 == 5L);
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test274");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries4.addAndOrUpdate(timeSeries22);
//        int int27 = timeSeries4.getItemCount();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        boolean boolean30 = day28.equals((java.lang.Object) 1);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        boolean boolean35 = day33.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate36 = day33.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate36);
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addYears(13, serialDate36);
//        int int39 = day28.compareTo((java.lang.Object) serialDate36);
//        java.lang.Number number40 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (java.lang.Number) 9999, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 10.0d + "'", number40.equals(10.0d));
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("May");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries4.addChangeListener(seriesChangeListener18);
//        timeSeries4.setMaximumItemAge((long) (short) 10);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        java.lang.Number number29 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) day27);
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.lang.String str36 = day35.toString();
//        java.lang.Number number37 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) 10.0f);
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class43);
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timeSeries44.addPropertyChangeListener(propertyChangeListener45);
//        java.lang.String str47 = timeSeries44.getRangeDescription();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        boolean boolean52 = day50.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) day48, (org.jfree.data.time.RegularTimePeriod) day50);
//        int int54 = day35.compareTo((java.lang.Object) day50);
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day50);
//        java.util.Date date56 = day50.getEnd();
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
//        java.util.TimeZone timeZone58 = null;
//        try {
//            org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date56, timeZone58);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number29);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number37);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-June-2019" + "'", str49.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertNotNull(date56);
//    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test278");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries4.addAndOrUpdate(timeSeries22);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), class28);
//        java.util.Collection collection30 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries29);
//        timeSeries29.fireSeriesChanged();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        long long33 = year32.getSerialIndex();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.lang.String str35 = day34.toString();
//        boolean boolean36 = year32.equals((java.lang.Object) day34);
//        int int37 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) day34);
//        java.lang.String str38 = timeSeries29.getDomainDescription();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNotNull(collection30);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "13-June-2019" + "'", str35.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Time" + "'", str38.equals("Time"));
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) 1);
        java.util.Date date3 = day0.getEnd();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        int int4 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.previous();
//        long long6 = regularTimePeriod5.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560365999999L + "'", long6 == 1560365999999L);
//    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test281");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries4.addChangeListener(seriesChangeListener18);
//        timeSeries4.setMaximumItemAge((long) (short) 10);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        java.lang.Number number29 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) day27);
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.lang.String str36 = day35.toString();
//        java.lang.Number number37 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) 10.0f);
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class43);
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timeSeries44.addPropertyChangeListener(propertyChangeListener45);
//        java.lang.String str47 = timeSeries44.getRangeDescription();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        boolean boolean52 = day50.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) day48, (org.jfree.data.time.RegularTimePeriod) day50);
//        int int54 = day35.compareTo((java.lang.Object) day50);
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day50);
//        java.util.Date date56 = day50.getEnd();
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date56);
//        java.util.Calendar calendar58 = null;
//        try {
//            long long59 = year57.getLastMillisecond(calendar58);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number29);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number37);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-June-2019" + "'", str49.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertNotNull(date56);
//    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.clear();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        java.lang.Number number24 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) 10.0f);
//        java.lang.Number number27 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.String str34 = day33.toString();
//        java.lang.Number number35 = timeSeries32.getValue((org.jfree.data.time.RegularTimePeriod) day33);
//        timeSeries32.clear();
//        int int37 = timeSeries32.getMaximumItemCount();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries4.addAndOrUpdate(timeSeries32);
//        java.lang.Class class42 = null;
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        java.lang.String str45 = day44.toString();
//        java.lang.Number number46 = timeSeries43.getValue((org.jfree.data.time.RegularTimePeriod) day44);
//        java.lang.Class class50 = null;
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class50);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        java.lang.String str53 = day52.toString();
//        java.lang.Number number54 = timeSeries51.getValue((org.jfree.data.time.RegularTimePeriod) day52);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries43.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day52, (double) 10.0f);
//        java.lang.Object obj57 = null;
//        boolean boolean58 = day52.equals(obj57);
//        long long59 = day52.getSerialIndex();
//        long long60 = day52.getFirstMillisecond();
//        int int61 = day52.getDayOfMonth();
//        try {
//            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day52, (double) 43629L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNull(number27);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "13-June-2019" + "'", str34.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2147483647 + "'", int37 == 2147483647);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "13-June-2019" + "'", str45.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number46);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "13-June-2019" + "'", str53.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number54);
//        org.junit.Assert.assertNull(timeSeriesDataItem56);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 43629L + "'", long59 == 43629L);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560409200000L + "'", long60 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 13 + "'", int61 == 13);
//    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class14 = timeSeries13.getTimePeriodClass();
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries13.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNull(class14);
//    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day13.equals(obj18);
//        long long20 = day13.getSerialIndex();
//        long long21 = day13.getFirstMillisecond();
//        int int22 = day13.getDayOfMonth();
//        java.util.Calendar calendar23 = null;
//        try {
//            day13.peg(calendar23);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 43629L + "'", long20 == 43629L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560409200000L + "'", long21 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 13 + "'", int22 == 13);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(31, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class17);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries4.addAndOrUpdate(timeSeries18);
//        timeSeries19.setDomainDescription("13-June-2019");
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(timeSeries19);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.clear();
//        int int9 = timeSeries4.getMaximumItemCount();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        java.lang.Number number17 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) day15);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) 10.0f);
//        java.lang.Object obj28 = null;
//        boolean boolean29 = day23.equals(obj28);
//        java.util.Date date30 = day23.getStart();
//        java.lang.Number number31 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        java.util.Calendar calendar32 = null;
//        try {
//            day23.peg(calendar32);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "13-June-2019" + "'", str16.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNull(number31);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = day0.equals(obj2);
//        java.util.Date date4 = day0.getEnd();
//        java.lang.String str5 = day0.toString();
//        java.util.Calendar calendar6 = null;
//        try {
//            day0.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = day8.getFirstMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day13.equals(obj18);
//        long long20 = day13.getSerialIndex();
//        long long21 = day13.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day13.previous();
//        java.util.Calendar calendar23 = null;
//        try {
//            long long24 = day13.getLastMillisecond(calendar23);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 43629L + "'", long20 == 43629L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560409200000L + "'", long21 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.lang.String str7 = day6.toString();
//        java.lang.Number number8 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) day6);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day14, (double) 10.0f);
//        java.lang.Object obj19 = null;
//        boolean boolean20 = day14.equals(obj19);
//        java.util.Date date21 = day14.getStart();
//        java.lang.Class<?> wildcardClass22 = day14.getClass();
//        java.net.URL uRL23 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.data.time.TimePeriodFormatException: ", (java.lang.Class) wildcardClass22);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNull(uRL23);
//    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getMonth();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries4.addChangeListener(seriesChangeListener18);
//        timeSeries4.setMaximumItemAge((long) (short) 10);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        java.lang.Number number29 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) day27);
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.lang.String str36 = day35.toString();
//        java.lang.Number number37 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) 10.0f);
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class43);
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timeSeries44.addPropertyChangeListener(propertyChangeListener45);
//        java.lang.String str47 = timeSeries44.getRangeDescription();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        boolean boolean52 = day50.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) day48, (org.jfree.data.time.RegularTimePeriod) day50);
//        int int54 = day35.compareTo((java.lang.Object) day50);
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day50);
//        int int56 = day50.getYear();
//        java.util.Calendar calendar57 = null;
//        try {
//            long long58 = day50.getLastMillisecond(calendar57);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number29);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number37);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-June-2019" + "'", str49.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2019 + "'", int56 == 2019);
//    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
//        boolean boolean8 = spreadsheetDate1.isOnOrAfter(serialDate7);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        java.lang.Number number24 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) 10.0f);
//        java.lang.Object obj27 = null;
//        boolean boolean28 = day22.equals(obj27);
//        java.util.Date date29 = day22.getStart();
//        java.lang.Class<?> wildcardClass30 = day22.getClass();
//        java.lang.ClassLoader classLoader31 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass30);
//        boolean boolean32 = spreadsheetDate1.equals((java.lang.Object) classLoader31);
//        java.util.Date date33 = spreadsheetDate1.toDate();
//        int int34 = spreadsheetDate1.getMonth();
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(classLoader31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate7);
//        boolean boolean9 = spreadsheetDate2.isOnOrAfter(serialDate8);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        java.lang.Number number17 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) day15);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) 10.0f);
//        java.lang.Object obj28 = null;
//        boolean boolean29 = day23.equals(obj28);
//        java.util.Date date30 = day23.getStart();
//        java.lang.Class<?> wildcardClass31 = day23.getClass();
//        java.lang.ClassLoader classLoader32 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass31);
//        boolean boolean33 = spreadsheetDate2.equals((java.lang.Object) classLoader32);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        int int35 = spreadsheetDate2.getDayOfWeek();
//        spreadsheetDate2.setDescription("Sunday");
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "13-June-2019" + "'", str16.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(classLoader32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 3 + "'", int35 == 3);
//    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.clear();
//        int int9 = timeSeries4.getMaximumItemCount();
//        java.lang.Comparable comparable10 = timeSeries4.getKey();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
//        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 10.0d + "'", comparable10.equals(10.0d));
//    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test299");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        boolean boolean22 = day20.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate23 = day20.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate23);
//        java.lang.String str25 = serialDate23.toString();
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addMonths(0, serialDate23);
//        boolean boolean27 = day13.equals((java.lang.Object) serialDate23);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "13-June-2019" + "'", str25.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test301");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        timeSeries4.setNotify(true);
//        java.util.List list10 = timeSeries4.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        long long14 = fixedMillisecond12.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.previous();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class19);
//        int int21 = fixedMillisecond12.compareTo((java.lang.Object) 10.0d);
//        java.util.Calendar calendar22 = null;
//        fixedMillisecond12.peg(calendar22);
//        long long24 = fixedMillisecond12.getFirstMillisecond();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        boolean boolean30 = day28.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate31 = day28.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate31);
//        boolean boolean33 = spreadsheetDate26.isOnOrAfter(serialDate32);
//        java.lang.Class class37 = null;
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        java.lang.String str40 = day39.toString();
//        java.lang.Number number41 = timeSeries38.getValue((org.jfree.data.time.RegularTimePeriod) day39);
//        java.lang.Class class45 = null;
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class45);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        java.lang.Number number49 = timeSeries46.getValue((org.jfree.data.time.RegularTimePeriod) day47);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day47, (double) 10.0f);
//        java.lang.Object obj52 = null;
//        boolean boolean53 = day47.equals(obj52);
//        java.util.Date date54 = day47.getStart();
//        java.lang.Class<?> wildcardClass55 = day47.getClass();
//        java.lang.ClassLoader classLoader56 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass55);
//        boolean boolean57 = spreadsheetDate26.equals((java.lang.Object) classLoader56);
//        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader56);
//        int int59 = fixedMillisecond12.compareTo((java.lang.Object) classLoader56);
//        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader56);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertNotNull(list10);
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5L + "'", long14 == 5L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 5L + "'", long24 == 5L);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "13-June-2019" + "'", str40.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number41);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "13-June-2019" + "'", str48.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number49);
//        org.junit.Assert.assertNull(timeSeriesDataItem51);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertNotNull(classLoader56);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class17);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries4.addAndOrUpdate(timeSeries18);
//        java.lang.Class class23 = null;
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class23);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        java.lang.String str26 = day25.toString();
//        java.lang.Number number27 = timeSeries24.getValue((org.jfree.data.time.RegularTimePeriod) day25);
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.String str34 = day33.toString();
//        java.lang.Number number35 = timeSeries32.getValue((org.jfree.data.time.RegularTimePeriod) day33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day33, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener38 = null;
//        timeSeries24.addChangeListener(seriesChangeListener38);
//        timeSeries24.setMaximumItemAge((long) (short) 10);
//        java.lang.Class class45 = null;
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class45);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        java.lang.Number number49 = timeSeries46.getValue((org.jfree.data.time.RegularTimePeriod) day47);
//        java.lang.Class class53 = null;
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class53);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        java.lang.String str56 = day55.toString();
//        java.lang.Number number57 = timeSeries54.getValue((org.jfree.data.time.RegularTimePeriod) day55);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day55, (double) 10.0f);
//        java.lang.Class class63 = null;
//        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class63);
//        java.beans.PropertyChangeListener propertyChangeListener65 = null;
//        timeSeries64.addPropertyChangeListener(propertyChangeListener65);
//        java.lang.String str67 = timeSeries64.getRangeDescription();
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
//        java.lang.String str69 = day68.toString();
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day();
//        boolean boolean72 = day70.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries64.createCopy((org.jfree.data.time.RegularTimePeriod) day68, (org.jfree.data.time.RegularTimePeriod) day70);
//        int int74 = day55.compareTo((java.lang.Object) day70);
//        timeSeries24.delete((org.jfree.data.time.RegularTimePeriod) day70);
//        java.util.Date date76 = day70.getEnd();
//        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date76);
//        boolean boolean78 = timeSeries18.equals((java.lang.Object) year77);
//        int int79 = timeSeries18.getMaximumItemCount();
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "13-June-2019" + "'", str26.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number27);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "13-June-2019" + "'", str34.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number35);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "13-June-2019" + "'", str48.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number49);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "13-June-2019" + "'", str56.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number57);
//        org.junit.Assert.assertNull(timeSeriesDataItem59);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "" + "'", str67.equals(""));
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "13-June-2019" + "'", str69.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNotNull(timeSeries73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 2147483647 + "'", int79 == 2147483647);
//    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries4.addAndOrUpdate(timeSeries22);
//        int int27 = timeSeries26.getMaximumItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (java.lang.Number) (-1.0f));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2147483647 + "'", int27 == 2147483647);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesException: ", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("org.jfree.data.general.SeriesException: ");
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getYear();
//        java.lang.String str3 = day0.toString();
//        java.util.Date date4 = day0.getStart();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date4);
//    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
//        boolean boolean8 = spreadsheetDate1.isOnOrAfter(serialDate7);
//        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate1.getNearestDayOfWeek(6);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        java.lang.Number number18 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) day16);
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.lang.String str25 = day24.toString();
//        java.lang.Number number26 = timeSeries23.getValue((org.jfree.data.time.RegularTimePeriod) day24);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day24, (double) 10.0f);
//        java.lang.Class class32 = null;
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class32);
//        java.beans.PropertyChangeListener propertyChangeListener34 = null;
//        timeSeries33.addPropertyChangeListener(propertyChangeListener34);
//        java.lang.String str36 = timeSeries33.getRangeDescription();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        java.lang.String str38 = day37.toString();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        boolean boolean41 = day39.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) day37, (org.jfree.data.time.RegularTimePeriod) day39);
//        int int43 = day24.compareTo((java.lang.Object) day39);
//        long long44 = day24.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day24.next();
//        try {
//            int int46 = spreadsheetDate1.compareTo((java.lang.Object) day24);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.Day cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number18);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "13-June-2019" + "'", str25.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number26);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "13-June-2019" + "'", str38.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(timeSeries42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560409200000L + "'", long44 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.String str18 = day13.toString();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test311");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        timeSeries4.setMaximumItemAge((long) 2019);
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        java.lang.Number number14 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) day12);
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.lang.String str21 = day20.toString();
//        java.lang.Number number22 = timeSeries19.getValue((org.jfree.data.time.RegularTimePeriod) day20);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day20, (double) 10.0f);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.lang.String str31 = day30.toString();
//        java.lang.Number number32 = timeSeries29.getValue((org.jfree.data.time.RegularTimePeriod) day30);
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries11.addAndOrUpdate(timeSeries29);
//        boolean boolean34 = timeSeries4.equals((java.lang.Object) timeSeries29);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = timeSeries29.getTimePeriod(0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "13-June-2019" + "'", str21.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number22);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "13-June-2019" + "'", str31.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number32);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        java.util.List list10 = timeSeries4.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond12.getLastMillisecond(calendar15);
        long long17 = fixedMillisecond12.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5L + "'", long14 == 5L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 5L + "'", long16 == 5L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 5L + "'", long17 == 5L);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 1);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        java.lang.Number number12 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.String str19 = day18.toString();
//        java.lang.Number number20 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) day18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day18, (double) 10.0f);
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day18.equals(obj23);
//        java.util.Date date25 = day18.getStart();
//        java.lang.Class<?> wildcardClass26 = day18.getClass();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1, "30-June-2019", "30-June-2019", (java.lang.Class) wildcardClass26);
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class31);
//        java.beans.PropertyChangeListener propertyChangeListener33 = null;
//        timeSeries32.addPropertyChangeListener(propertyChangeListener33);
//        java.lang.String str35 = timeSeries32.getRangeDescription();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        java.lang.String str37 = day36.toString();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        boolean boolean40 = day38.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) day36, (org.jfree.data.time.RegularTimePeriod) day38);
//        java.lang.Class class45 = null;
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class45);
//        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries32.addAndOrUpdate(timeSeries46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        java.lang.Object obj50 = null;
//        boolean boolean51 = day48.equals(obj50);
//        java.lang.Number number52 = timeSeries47.getValue((org.jfree.data.time.RegularTimePeriod) day48);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries27.addAndOrUpdate(timeSeries47);
//        java.lang.Class class57 = null;
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class57);
//        timeSeries58.setRangeDescription("hi!");
//        java.lang.Class class61 = timeSeries58.getTimePeriodClass();
//        java.util.Collection collection62 = timeSeries47.getTimePeriodsUniqueToOtherSeries(timeSeries58);
//        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(12, 3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = month65.previous();
//        try {
//            timeSeries47.update(regularTimePeriod66, (java.lang.Number) 9223372036854775807L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "13-June-2019" + "'", str19.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number20);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "13-June-2019" + "'", str37.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertNotNull(timeSeries47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-June-2019" + "'", str49.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNull(number52);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertNull(class61);
//        org.junit.Assert.assertNotNull(collection62);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(10, 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        boolean boolean6 = day4.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate7);
        boolean boolean9 = spreadsheetDate2.isOnOrAfter(serialDate8);
        java.lang.String str10 = spreadsheetDate2.getDescription();
        try {
            org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(100, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test317");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        long long14 = timeSeries4.getMaximumItemAge();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        boolean boolean17 = day15.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate18 = day15.getSerialDate();
//        int int19 = day15.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day15.previous();
//        int int21 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day15);
//        try {
//            timeSeries4.removeAgedItems(0L, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries4.addChangeListener(seriesChangeListener18);
//        timeSeries4.setMaximumItemAge((long) (short) 10);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        java.lang.Number number29 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) day27);
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.lang.String str36 = day35.toString();
//        java.lang.Number number37 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) 10.0f);
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class43);
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timeSeries44.addPropertyChangeListener(propertyChangeListener45);
//        java.lang.String str47 = timeSeries44.getRangeDescription();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        boolean boolean52 = day50.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) day48, (org.jfree.data.time.RegularTimePeriod) day50);
//        int int54 = day35.compareTo((java.lang.Object) day50);
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day50);
//        java.util.Date date56 = day50.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = day50.next();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number29);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number37);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-June-2019" + "'", str49.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 10, 8, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.clear();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        java.lang.Number number24 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) 10.0f);
//        java.lang.Number number27 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.String str34 = day33.toString();
//        java.lang.Number number35 = timeSeries32.getValue((org.jfree.data.time.RegularTimePeriod) day33);
//        timeSeries32.clear();
//        int int37 = timeSeries32.getMaximumItemCount();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries4.addAndOrUpdate(timeSeries32);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = timeSeries32.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNull(number27);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "13-June-2019" + "'", str34.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number35);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2147483647 + "'", int37 == 2147483647);
//        org.junit.Assert.assertNotNull(timeSeries38);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        java.util.List list10 = timeSeries4.getItems();
        try {
            timeSeries4.removeAgedItems((long) (short) 100, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(list10);
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class17);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries4.addAndOrUpdate(timeSeries18);
//        java.lang.Class class23 = null;
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class23);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        java.lang.String str26 = day25.toString();
//        java.lang.Number number27 = timeSeries24.getValue((org.jfree.data.time.RegularTimePeriod) day25);
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.String str34 = day33.toString();
//        java.lang.Number number35 = timeSeries32.getValue((org.jfree.data.time.RegularTimePeriod) day33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day33, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener38 = null;
//        timeSeries24.addChangeListener(seriesChangeListener38);
//        timeSeries24.setMaximumItemAge((long) (short) 10);
//        java.lang.Class class45 = null;
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class45);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        java.lang.Number number49 = timeSeries46.getValue((org.jfree.data.time.RegularTimePeriod) day47);
//        java.lang.Class class53 = null;
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class53);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        java.lang.String str56 = day55.toString();
//        java.lang.Number number57 = timeSeries54.getValue((org.jfree.data.time.RegularTimePeriod) day55);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries46.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day55, (double) 10.0f);
//        java.lang.Class class63 = null;
//        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class63);
//        java.beans.PropertyChangeListener propertyChangeListener65 = null;
//        timeSeries64.addPropertyChangeListener(propertyChangeListener65);
//        java.lang.String str67 = timeSeries64.getRangeDescription();
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day();
//        java.lang.String str69 = day68.toString();
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day();
//        boolean boolean72 = day70.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries64.createCopy((org.jfree.data.time.RegularTimePeriod) day68, (org.jfree.data.time.RegularTimePeriod) day70);
//        int int74 = day55.compareTo((java.lang.Object) day70);
//        timeSeries24.delete((org.jfree.data.time.RegularTimePeriod) day70);
//        java.util.Date date76 = day70.getEnd();
//        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date76);
//        boolean boolean78 = timeSeries18.equals((java.lang.Object) year77);
//        java.util.Calendar calendar79 = null;
//        try {
//            year77.peg(calendar79);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "13-June-2019" + "'", str26.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number27);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "13-June-2019" + "'", str34.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number35);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "13-June-2019" + "'", str48.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number49);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "13-June-2019" + "'", str56.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number57);
//        org.junit.Assert.assertNull(timeSeriesDataItem59);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "" + "'", str67.equals(""));
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "13-June-2019" + "'", str69.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNotNull(timeSeries73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener7);
        timeSeries4.setRangeDescription("13-June-2019");
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, class1);
        timeSeries2.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries2.addPropertyChangeListener(propertyChangeListener5);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 3);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        boolean boolean7 = day5.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        boolean boolean11 = day9.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate12 = day9.getSerialDate();
        org.jfree.data.time.SerialDate serialDate13 = serialDate8.getEndOfCurrentMonth(serialDate12);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addDays((int) (short) 100, serialDate13);
        boolean boolean15 = month2.equals((java.lang.Object) (short) 100);
        long long16 = month2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "December 3" + "'", str3.equals("December 3"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 48L + "'", long16 == 48L);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) 1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        int int4 = day2.getYear();
//        java.lang.String str5 = day2.toString();
//        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) str5);
//        long long7 = fixedMillisecond1.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 5L + "'", long7 == 5L);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(5);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Thursday" + "'", str1.equals("Thursday"));
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        java.lang.Number number11 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) day9);
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.String str18 = day17.toString();
//        java.lang.Number number19 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) day17);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day17, (double) 10.0f);
//        java.lang.Object obj22 = null;
//        boolean boolean23 = day17.equals(obj22);
//        java.util.Date date24 = day17.getStart();
//        java.lang.Class<?> wildcardClass25 = day17.getClass();
//        java.io.InputStream inputStream26 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass25);
//        java.net.URL uRL27 = org.jfree.chart.util.ObjectUtilities.getResource("30-June-2019", (java.lang.Class) wildcardClass25);
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        java.lang.String str39 = day38.toString();
//        java.lang.Number number40 = timeSeries37.getValue((org.jfree.data.time.RegularTimePeriod) day38);
//        java.lang.Class class44 = null;
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        java.lang.String str47 = day46.toString();
//        java.lang.Number number48 = timeSeries45.getValue((org.jfree.data.time.RegularTimePeriod) day46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day46, (double) 10.0f);
//        java.lang.Object obj51 = null;
//        boolean boolean52 = day46.equals(obj51);
//        java.util.Date date53 = day46.getStart();
//        java.lang.Class<?> wildcardClass54 = day46.getClass();
//        java.io.InputStream inputStream55 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass54);
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, "org.jfree.data.time.TimePeriodFormatException: ", "hi!", (java.lang.Class) wildcardClass54);
//        java.lang.Class class60 = null;
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class60);
//        long long62 = timeSeries61.getMaximumItemAge();
//        java.lang.Class<?> wildcardClass63 = timeSeries61.getClass();
//        java.lang.Object obj64 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass54, (java.lang.Class) wildcardClass63);
//        java.lang.Object obj65 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass25, (java.lang.Class) wildcardClass63);
//        java.lang.Object obj66 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("SerialDate.weekInMonthToString(): invalid code.", (java.lang.Class) wildcardClass63);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number11);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number19);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(inputStream26);
//        org.junit.Assert.assertNull(uRL27);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "13-June-2019" + "'", str39.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number40);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "13-June-2019" + "'", str47.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number48);
//        org.junit.Assert.assertNull(timeSeriesDataItem50);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertNotNull(inputStream55);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 9223372036854775807L + "'", long62 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(wildcardClass63);
//        org.junit.Assert.assertNull(obj64);
//        org.junit.Assert.assertNull(obj65);
//        org.junit.Assert.assertNull(obj66);
//    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate7);
//        boolean boolean9 = spreadsheetDate2.isOnOrAfter(serialDate8);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        java.lang.Number number17 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) day15);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) 10.0f);
//        java.lang.Object obj28 = null;
//        boolean boolean29 = day23.equals(obj28);
//        java.util.Date date30 = day23.getStart();
//        java.lang.Class<?> wildcardClass31 = day23.getClass();
//        java.lang.ClassLoader classLoader32 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass31);
//        boolean boolean33 = spreadsheetDate2.equals((java.lang.Object) classLoader32);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        int int35 = spreadsheetDate2.getDayOfWeek();
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class43);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        java.lang.String str46 = day45.toString();
//        java.lang.Number number47 = timeSeries44.getValue((org.jfree.data.time.RegularTimePeriod) day45);
//        java.lang.Class class51 = null;
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class51);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        java.lang.String str54 = day53.toString();
//        java.lang.Number number55 = timeSeries52.getValue((org.jfree.data.time.RegularTimePeriod) day53);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries44.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day53, (double) 10.0f);
//        java.lang.Object obj58 = null;
//        boolean boolean59 = day53.equals(obj58);
//        java.util.Date date60 = day53.getStart();
//        java.lang.Class<?> wildcardClass61 = day53.getClass();
//        java.io.InputStream inputStream62 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass61);
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, "org.jfree.data.time.TimePeriodFormatException: ", "hi!", (java.lang.Class) wildcardClass61);
//        java.lang.Class class67 = null;
//        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class67);
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
//        java.lang.String str70 = day69.toString();
//        java.lang.Number number71 = timeSeries68.getValue((org.jfree.data.time.RegularTimePeriod) day69);
//        java.lang.Class class75 = null;
//        org.jfree.data.time.TimeSeries timeSeries76 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class75);
//        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day();
//        java.lang.String str78 = day77.toString();
//        java.lang.Number number79 = timeSeries76.getValue((org.jfree.data.time.RegularTimePeriod) day77);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem81 = timeSeries68.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day77, (double) 10.0f);
//        java.lang.Object obj82 = null;
//        boolean boolean83 = day77.equals(obj82);
//        java.util.Date date84 = day77.getStart();
//        java.util.TimeZone timeZone85 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date84, timeZone85);
//        boolean boolean87 = spreadsheetDate2.equals((java.lang.Object) timeZone85);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "13-June-2019" + "'", str16.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(classLoader32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 3 + "'", int35 == 3);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "13-June-2019" + "'", str46.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number47);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "13-June-2019" + "'", str54.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number55);
//        org.junit.Assert.assertNull(timeSeriesDataItem57);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertNotNull(inputStream62);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "13-June-2019" + "'", str70.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number71);
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "13-June-2019" + "'", str78.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number79);
//        org.junit.Assert.assertNull(timeSeriesDataItem81);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertNotNull(date84);
//        org.junit.Assert.assertNull(regularTimePeriod86);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
        int int4 = day0.getYear();
        java.util.Calendar calendar5 = null;
        try {
            day0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) year8);
        java.lang.Object obj11 = null;
        boolean boolean12 = year8.equals(obj11);
        try {
            org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(1900, year8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        int int14 = day8.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day8.previous();
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.lang.String str7 = day6.toString();
//        java.lang.Number number8 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) day6);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day14, (double) 10.0f);
//        java.lang.Object obj19 = null;
//        boolean boolean20 = day14.equals(obj19);
//        java.util.Date date21 = day14.getStart();
//        java.lang.Class<?> wildcardClass22 = day14.getClass();
//        java.io.InputStream inputStream23 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass22);
//        java.lang.ClassLoader classLoader24 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass22);
//        java.lang.ClassLoader classLoader25 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass22);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(inputStream23);
//        org.junit.Assert.assertNotNull(classLoader24);
//        org.junit.Assert.assertNotNull(classLoader25);
//    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries4.addChangeListener(seriesChangeListener18);
//        timeSeries4.setMaximumItemAge((long) (short) 10);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        java.lang.Number number29 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) day27);
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.lang.String str36 = day35.toString();
//        java.lang.Number number37 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) 10.0f);
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class43);
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timeSeries44.addPropertyChangeListener(propertyChangeListener45);
//        java.lang.String str47 = timeSeries44.getRangeDescription();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        boolean boolean52 = day50.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) day48, (org.jfree.data.time.RegularTimePeriod) day50);
//        int int54 = day35.compareTo((java.lang.Object) day50);
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day50);
//        java.util.Date date56 = day50.getEnd();
//        int int57 = day50.getYear();
//        java.lang.String str58 = day50.toString();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number29);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number37);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-June-2019" + "'", str49.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "13-June-2019" + "'", str58.equals("13-June-2019"));
//    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getMiddleMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2147483647);
        timeSeries1.setKey((java.lang.Comparable) 1.0f);
        java.util.List list4 = timeSeries1.getItems();
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1L));
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        boolean boolean3 = day1.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate4 = day1.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate4);
//        java.lang.String str6 = serialDate4.toString();
//        java.lang.String str7 = serialDate4.toString();
//        boolean boolean9 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) serialDate4, (java.lang.Object) 0L);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        java.lang.Number number24 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.lang.String str31 = day30.toString();
//        java.lang.Number number32 = timeSeries29.getValue((org.jfree.data.time.RegularTimePeriod) day30);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day30, (double) 10.0f);
//        java.lang.Object obj35 = null;
//        boolean boolean36 = day30.equals(obj35);
//        java.util.Date date37 = day30.getStart();
//        java.lang.Class<?> wildcardClass38 = day30.getClass();
//        java.io.InputStream inputStream39 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass38);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, "org.jfree.data.time.TimePeriodFormatException: ", "hi!", (java.lang.Class) wildcardClass38);
//        java.lang.Class class44 = null;
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class44);
//        long long46 = timeSeries45.getMaximumItemAge();
//        java.lang.Class<?> wildcardClass47 = timeSeries45.getClass();
//        java.lang.Object obj48 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass38, (java.lang.Class) wildcardClass47);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean9, "13-June-2019", "30-June-2019", (java.lang.Class) wildcardClass38);
//        java.lang.Class class50 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass38);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "13-June-2019" + "'", str31.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number32);
//        org.junit.Assert.assertNull(timeSeriesDataItem34);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNotNull(inputStream39);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 9223372036854775807L + "'", long46 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertNull(obj48);
//        org.junit.Assert.assertNotNull(class50);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        timeSeries4.setRangeDescription("hi!");
        timeSeries4.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
        timeSeries4.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries4.removeChangeListener(seriesChangeListener11);
        try {
            java.lang.Number number14 = timeSeries4.getValue(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(5, (-1), 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries4.addAndOrUpdate(timeSeries22);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), class28);
//        java.util.Collection collection30 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries29);
//        timeSeries29.fireSeriesChanged();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        long long33 = year32.getSerialIndex();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.lang.String str35 = day34.toString();
//        boolean boolean36 = year32.equals((java.lang.Object) day34);
//        int int37 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) day34);
//        java.lang.Class class41 = null;
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class41);
//        timeSeries42.setRangeDescription("hi!");
//        java.lang.Class class45 = timeSeries42.getTimePeriodClass();
//        java.util.Collection collection46 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries42);
//        timeSeries42.removeAgedItems(true);
//        java.util.Collection collection49 = timeSeries42.getTimePeriods();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNotNull(collection30);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "13-June-2019" + "'", str35.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertNull(class45);
//        org.junit.Assert.assertNotNull(collection46);
//        org.junit.Assert.assertNotNull(collection49);
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        java.util.List list10 = timeSeries4.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.previous();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class19);
        int int21 = fixedMillisecond12.compareTo((java.lang.Object) 10.0d);
        java.util.Calendar calendar22 = null;
        fixedMillisecond12.peg(calendar22);
        java.util.Calendar calendar24 = null;
        fixedMillisecond12.peg(calendar24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond12.next();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5L + "'", long14 == 5L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries4.addAndOrUpdate(timeSeries22);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), class28);
//        java.util.Collection collection30 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries29);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month31.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month31.next();
//        java.lang.Class class37 = null;
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class37);
//        java.beans.PropertyChangeListener propertyChangeListener39 = null;
//        timeSeries38.addPropertyChangeListener(propertyChangeListener39);
//        java.lang.String str41 = timeSeries38.getRangeDescription();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        java.lang.String str43 = day42.toString();
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        boolean boolean46 = day44.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries38.createCopy((org.jfree.data.time.RegularTimePeriod) day42, (org.jfree.data.time.RegularTimePeriod) day44);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries48 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) month31, (org.jfree.data.time.RegularTimePeriod) day42);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNotNull(collection30);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "13-June-2019" + "'", str43.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(timeSeries47);
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 3);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        int int5 = month2.getYearValue();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "December 3" + "'", str3.equals("December 3"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(1900);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
//        java.lang.String str8 = serialDate6.toString();
//        java.lang.String str9 = serialDate6.getDescription();
//        boolean boolean10 = spreadsheetDate1.isOn(serialDate6);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(9999, (int) (byte) -1, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        timeSeries4.setRangeDescription("hi!");
        timeSeries4.setRangeDescription("");
        boolean boolean9 = timeSeries4.isEmpty();
        java.lang.Comparable comparable10 = timeSeries4.getKey();
        java.lang.Number number12 = null;
        try {
            timeSeries4.update((int) (byte) 100, number12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 10.0d + "'", comparable10.equals(10.0d));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            day0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate7);
//        boolean boolean9 = spreadsheetDate2.isOnOrAfter(serialDate8);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        java.lang.Number number17 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) day15);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) 10.0f);
//        java.lang.Object obj28 = null;
//        boolean boolean29 = day23.equals(obj28);
//        java.util.Date date30 = day23.getStart();
//        java.lang.Class<?> wildcardClass31 = day23.getClass();
//        java.lang.ClassLoader classLoader32 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass31);
//        boolean boolean33 = spreadsheetDate2.equals((java.lang.Object) classLoader32);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        int int35 = spreadsheetDate2.getDayOfWeek();
//        java.lang.String str36 = spreadsheetDate2.getDescription();
//        try {
//            org.jfree.data.time.SerialDate serialDate38 = spreadsheetDate2.getPreviousDayOfWeek(1900);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "13-June-2019" + "'", str16.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(classLoader32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 3 + "'", int35 == 3);
//        org.junit.Assert.assertNull(str36);
//    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener8);
        try {
            timeSeries4.removeAgedItems((long) 5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Time");
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year7);
        java.lang.Object obj10 = null;
        boolean boolean11 = year7.equals(obj10);
        long long12 = year7.getLastMillisecond();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = year7.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(4, (-1), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries4.addAndOrUpdate(timeSeries22);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), class28);
//        java.util.Collection collection30 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries29);
//        timeSeries29.fireSeriesChanged();
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
//        long long33 = year32.getSerialIndex();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.lang.String str35 = day34.toString();
//        boolean boolean36 = year32.equals((java.lang.Object) day34);
//        int int37 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) day34);
//        int int38 = day34.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNotNull(collection30);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "13-June-2019" + "'", str35.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 13 + "'", int38 == 13);
//    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        int int18 = timeSeries4.getItemCount();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), class1);
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        java.lang.Number number10 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        java.lang.Number number18 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) day16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries7.addChangeListener(seriesChangeListener21);
//        java.lang.Class class26 = null;
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.lang.String str29 = day28.toString();
//        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) day28);
//        java.lang.Class class34 = null;
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        java.lang.String str37 = day36.toString();
//        java.lang.Number number38 = timeSeries35.getValue((org.jfree.data.time.RegularTimePeriod) day36);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day36, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
//        timeSeries27.addChangeListener(seriesChangeListener41);
//        timeSeries27.setMaximumItemAge((long) (short) 10);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
//        long long46 = year45.getSerialIndex();
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        boolean boolean49 = year45.equals((java.lang.Object) day47);
//        java.lang.Number number50 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) day47);
//        java.util.Collection collection51 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries27);
//        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries2.addAndOrUpdate(timeSeries27);
//        java.lang.Class class56 = null;
//        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class56);
//        java.beans.PropertyChangeListener propertyChangeListener58 = null;
//        timeSeries57.addPropertyChangeListener(propertyChangeListener58);
//        java.lang.String str60 = timeSeries57.getRangeDescription();
//        timeSeries57.setNotify(true);
//        java.util.List list63 = timeSeries57.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem66 = timeSeries57.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65);
//        long long67 = fixedMillisecond65.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = fixedMillisecond65.previous();
//        java.lang.Class class72 = null;
//        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class72);
//        int int74 = fixedMillisecond65.compareTo((java.lang.Object) 10.0d);
//        java.util.Calendar calendar75 = null;
//        fixedMillisecond65.peg(calendar75);
//        int int78 = fixedMillisecond65.compareTo((java.lang.Object) 100L);
//        java.lang.Number number79 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem80 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65, number79);
//        try {
//            timeSeries2.add(timeSeriesDataItem80);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number10);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number18);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "13-June-2019" + "'", str29.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number30);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "13-June-2019" + "'", str37.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number38);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 2019L + "'", long46 == 2019L);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "13-June-2019" + "'", str48.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + number50 + "' != '" + 10.0d + "'", number50.equals(10.0d));
//        org.junit.Assert.assertNotNull(collection51);
//        org.junit.Assert.assertNotNull(timeSeries52);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "" + "'", str60.equals(""));
//        org.junit.Assert.assertNotNull(list63);
//        org.junit.Assert.assertNull(timeSeriesDataItem66);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 5L + "'", long67 == 5L);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(7, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 1);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        java.lang.Number number12 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.String str19 = day18.toString();
//        java.lang.Number number20 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) day18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day18, (double) 10.0f);
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day18.equals(obj23);
//        java.util.Date date25 = day18.getStart();
//        java.lang.Class<?> wildcardClass26 = day18.getClass();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1, "30-June-2019", "30-June-2019", (java.lang.Class) wildcardClass26);
//        java.lang.ClassLoader classLoader28 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass26);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "13-June-2019" + "'", str19.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number20);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(classLoader28);
//    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = day0.equals(obj2);
//        java.util.Date date4 = day0.getEnd();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        java.lang.Number number24 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) 10.0f);
//        java.lang.Object obj27 = null;
//        boolean boolean28 = day22.equals(obj27);
//        java.util.Date date29 = day22.getStart();
//        java.lang.Class<?> wildcardClass30 = day22.getClass();
//        java.io.InputStream inputStream31 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass30);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, "org.jfree.data.time.TimePeriodFormatException: ", "hi!", (java.lang.Class) wildcardClass30);
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        java.lang.String str39 = day38.toString();
//        java.lang.Number number40 = timeSeries37.getValue((org.jfree.data.time.RegularTimePeriod) day38);
//        java.lang.Class class44 = null;
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        java.lang.String str47 = day46.toString();
//        java.lang.Number number48 = timeSeries45.getValue((org.jfree.data.time.RegularTimePeriod) day46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day46, (double) 10.0f);
//        java.lang.Object obj51 = null;
//        boolean boolean52 = day46.equals(obj51);
//        java.util.Date date53 = day46.getStart();
//        java.util.TimeZone timeZone54 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date53, timeZone54);
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month(date53, timeZone56);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date4, timeZone56);
//        java.lang.String str59 = year58.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(inputStream31);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "13-June-2019" + "'", str39.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number40);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "13-June-2019" + "'", str47.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number48);
//        org.junit.Assert.assertNull(timeSeriesDataItem50);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "2019" + "'", str59.equals("2019"));
//    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 1);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        java.lang.Number number12 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.String str19 = day18.toString();
//        java.lang.Number number20 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) day18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day18, (double) 10.0f);
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day18.equals(obj23);
//        java.util.Date date25 = day18.getStart();
//        java.lang.Class<?> wildcardClass26 = day18.getClass();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1, "30-June-2019", "30-June-2019", (java.lang.Class) wildcardClass26);
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class31);
//        java.beans.PropertyChangeListener propertyChangeListener33 = null;
//        timeSeries32.addPropertyChangeListener(propertyChangeListener33);
//        java.lang.String str35 = timeSeries32.getRangeDescription();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        java.lang.String str37 = day36.toString();
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        boolean boolean40 = day38.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) day36, (org.jfree.data.time.RegularTimePeriod) day38);
//        java.lang.Class class45 = null;
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class45);
//        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries32.addAndOrUpdate(timeSeries46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        java.lang.Object obj50 = null;
//        boolean boolean51 = day48.equals(obj50);
//        java.lang.Number number52 = timeSeries47.getValue((org.jfree.data.time.RegularTimePeriod) day48);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries27.addAndOrUpdate(timeSeries47);
//        java.lang.Class class57 = null;
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class57);
//        timeSeries58.setRangeDescription("hi!");
//        java.lang.Class class61 = timeSeries58.getTimePeriodClass();
//        java.util.Collection collection62 = timeSeries47.getTimePeriodsUniqueToOtherSeries(timeSeries58);
//        java.util.Collection collection63 = org.jfree.chart.util.ObjectUtilities.deepClone(collection62);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "13-June-2019" + "'", str19.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number20);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "13-June-2019" + "'", str37.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertNotNull(timeSeries47);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-June-2019" + "'", str49.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNull(number52);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertNull(class61);
//        org.junit.Assert.assertNotNull(collection62);
//        org.junit.Assert.assertNotNull(collection63);
//    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        long long9 = day5.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43629L + "'", long9 == 43629L);
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection6 = timeSeries4.getTimePeriods();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        try {
            timeSeries4.update((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) 1.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        timeSeries4.setNotify(true);
//        timeSeries4.setMaximumItemCount(3);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.lang.String str13 = day12.toString();
//        java.lang.Number number14 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day12);
//        int int15 = timeSeries4.getMaximumItemCount();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.lang.String str22 = day21.toString();
//        java.lang.Number number23 = timeSeries20.getValue((org.jfree.data.time.RegularTimePeriod) day21);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        java.lang.Number number31 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) day29);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day29, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener34 = null;
//        timeSeries20.addChangeListener(seriesChangeListener34);
//        timeSeries20.setMaximumItemAge((long) (short) 10);
//        java.lang.Class class41 = null;
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class41);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        java.lang.String str44 = day43.toString();
//        java.lang.Number number45 = timeSeries42.getValue((org.jfree.data.time.RegularTimePeriod) day43);
//        java.lang.Class class49 = null;
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class49);
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
//        java.lang.String str52 = day51.toString();
//        java.lang.Number number53 = timeSeries50.getValue((org.jfree.data.time.RegularTimePeriod) day51);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries42.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day51, (double) 10.0f);
//        java.lang.Class class59 = null;
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class59);
//        java.beans.PropertyChangeListener propertyChangeListener61 = null;
//        timeSeries60.addPropertyChangeListener(propertyChangeListener61);
//        java.lang.String str63 = timeSeries60.getRangeDescription();
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
//        java.lang.String str65 = day64.toString();
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        boolean boolean68 = day66.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries69 = timeSeries60.createCopy((org.jfree.data.time.RegularTimePeriod) day64, (org.jfree.data.time.RegularTimePeriod) day66);
//        int int70 = day51.compareTo((java.lang.Object) day66);
//        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) day66);
//        java.util.Date date72 = day66.getEnd();
//        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date72);
//        try {
//            timeSeries4.update((org.jfree.data.time.RegularTimePeriod) year73, (java.lang.Number) (-1));
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "13-June-2019" + "'", str22.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number23);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "13-June-2019" + "'", str30.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number31);
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "13-June-2019" + "'", str44.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number45);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "13-June-2019" + "'", str52.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number53);
//        org.junit.Assert.assertNull(timeSeriesDataItem55);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "" + "'", str63.equals(""));
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "13-June-2019" + "'", str65.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertNotNull(timeSeries69);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertNotNull(date72);
//    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate7);
//        boolean boolean9 = spreadsheetDate2.isOnOrAfter(serialDate8);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        java.lang.String str16 = day15.toString();
//        java.lang.Number number17 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) day15);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (double) 10.0f);
//        java.lang.Object obj28 = null;
//        boolean boolean29 = day23.equals(obj28);
//        java.util.Date date30 = day23.getStart();
//        java.lang.Class<?> wildcardClass31 = day23.getClass();
//        java.lang.ClassLoader classLoader32 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass31);
//        boolean boolean33 = spreadsheetDate2.equals((java.lang.Object) classLoader32);
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//        int int35 = spreadsheetDate2.getDayOfWeek();
//        int int36 = spreadsheetDate2.toSerial();
//        java.lang.Class class41 = null;
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class41);
//        long long43 = timeSeries42.getMaximumItemAge();
//        java.lang.Class<?> wildcardClass44 = timeSeries42.getClass();
//        java.net.URL uRL45 = org.jfree.chart.util.ObjectUtilities.getResource("13-June-2019", (java.lang.Class) wildcardClass44);
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int36, (java.lang.Class) wildcardClass44);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "13-June-2019" + "'", str16.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertNotNull(classLoader32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 3 + "'", int35 == 3);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 9223372036854775807L + "'", long43 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(wildcardClass44);
//        org.junit.Assert.assertNull(uRL45);
//    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        java.util.List list10 = timeSeries4.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.previous();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class19);
        int int21 = fixedMillisecond12.compareTo((java.lang.Object) 10.0d);
        java.util.Calendar calendar22 = null;
        fixedMillisecond12.peg(calendar22);
        int int25 = fixedMillisecond12.compareTo((java.lang.Object) 100L);
        java.lang.Number number26 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, number26);
        timeSeriesDataItem27.setValue((java.lang.Number) (byte) 1);
        timeSeriesDataItem27.setValue((java.lang.Number) 4);
        int int33 = timeSeriesDataItem27.compareTo((java.lang.Object) (byte) 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5L + "'", long14 == 5L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate7);
//        boolean boolean9 = spreadsheetDate2.isOnOrAfter(serialDate8);
//        int int10 = spreadsheetDate2.getMonth();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        boolean boolean13 = day11.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate14 = day11.getSerialDate();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        boolean boolean17 = day15.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate18 = day15.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate19 = serialDate14.getEndOfCurrentMonth(serialDate18);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        boolean boolean23 = day21.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate24 = day21.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate24);
//        java.lang.String str26 = serialDate24.toString();
//        org.jfree.data.time.SerialDate serialDate27 = serialDate19.getEndOfCurrentMonth(serialDate24);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        boolean boolean33 = day31.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate34 = day31.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate34);
//        boolean boolean36 = spreadsheetDate29.isOnOrAfter(serialDate35);
//        org.jfree.data.time.SerialDate serialDate38 = spreadsheetDate29.getNearestDayOfWeek(6);
//        boolean boolean40 = spreadsheetDate2.isInRange(serialDate24, serialDate38, (int) 'a');
//        try {
//            org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, serialDate24);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "13-June-2019" + "'", str26.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 3);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        java.lang.String str5 = month2.toString();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "December 3" + "'", str3.equals("December 3"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "December 3" + "'", str5.equals("December 3"));
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test377");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class17);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries4.addAndOrUpdate(timeSeries18);
//        java.lang.String str20 = timeSeries4.getDomainDescription();
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
//    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test378");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, class1);
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        java.lang.Number number10 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        java.lang.Number number18 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) day16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (double) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) day16);
//        java.util.Date date22 = day16.getStart();
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number10);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number18);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(date22);
//    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, 4);
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries4.addAndOrUpdate(timeSeries22);
//        int int27 = timeSeries26.getMaximumItemCount();
//        java.beans.PropertyChangeListener propertyChangeListener28 = null;
//        timeSeries26.addPropertyChangeListener(propertyChangeListener28);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2147483647 + "'", int27 == 2147483647);
//    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test381");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        long long5 = timeSeries4.getMaximumItemAge();
//        timeSeries4.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        timeSeries4.setMaximumItemCount(0);
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class13);
//        timeSeries14.setRangeDescription("hi!");
//        timeSeries14.setRangeDescription("");
//        boolean boolean19 = timeSeries14.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries4.addAndOrUpdate(timeSeries14);
//        java.lang.Class class24 = null;
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.lang.String str27 = day26.toString();
//        java.lang.Number number28 = timeSeries25.getValue((org.jfree.data.time.RegularTimePeriod) day26);
//        java.lang.Class class32 = null;
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class32);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.lang.String str35 = day34.toString();
//        java.lang.Number number36 = timeSeries33.getValue((org.jfree.data.time.RegularTimePeriod) day34);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day34, (double) 10.0f);
//        java.lang.Object obj39 = null;
//        boolean boolean40 = day34.equals(obj39);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day34, (double) (-460));
//        try {
//            timeSeries4.add(timeSeriesDataItem42, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number28);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "13-June-2019" + "'", str35.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number36);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        boolean boolean2 = day0.equals((java.lang.Object) 1);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        boolean boolean7 = day5.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate8);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears(13, serialDate8);
        int int11 = day0.compareTo((java.lang.Object) serialDate8);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day0.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("December 3");
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class4);
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries5.addPropertyChangeListener(propertyChangeListener6);
//        java.lang.String str8 = timeSeries5.getRangeDescription();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        boolean boolean13 = day11.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) day9, (org.jfree.data.time.RegularTimePeriod) day11);
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class18);
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries5.addAndOrUpdate(timeSeries19);
//        timeSeries19.setDescription("30-June-2019");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        boolean boolean27 = day25.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        boolean boolean31 = day29.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate32 = day29.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate33 = serialDate28.getEndOfCurrentMonth(serialDate32);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        boolean boolean37 = day35.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate38 = day35.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate38);
//        java.lang.String str40 = serialDate38.toString();
//        org.jfree.data.time.SerialDate serialDate41 = serialDate33.getEndOfCurrentMonth(serialDate38);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        boolean boolean44 = day42.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate45 = day42.getSerialDate();
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        boolean boolean48 = day46.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate49 = day46.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate50 = serialDate45.getEndOfCurrentMonth(serialDate49);
//        boolean boolean52 = spreadsheetDate24.isInRange(serialDate38, serialDate50, 2019);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        boolean boolean55 = day53.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate56 = day53.getSerialDate();
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
//        boolean boolean59 = day57.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate60 = day57.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate61 = serialDate56.getEndOfCurrentMonth(serialDate60);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
//        boolean boolean65 = day63.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate66 = day63.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate66);
//        java.lang.String str68 = serialDate66.toString();
//        org.jfree.data.time.SerialDate serialDate69 = serialDate61.getEndOfCurrentMonth(serialDate66);
//        boolean boolean70 = spreadsheetDate24.isOn(serialDate69);
//        timeSeries19.setKey((java.lang.Comparable) serialDate69);
//        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.addMonths(0, serialDate69);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "13-June-2019" + "'", str40.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "13-June-2019" + "'", str68.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate69);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertNotNull(serialDate72);
//    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        int int18 = day13.getYear();
//        org.jfree.data.time.SerialDate serialDate19 = day13.getSerialDate();
//        long long20 = day13.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560452399999L + "'", long20 == 1560452399999L);
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 11);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day13.equals(obj18);
//        java.util.Date date20 = day13.getStart();
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance(date20);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(serialDate21);
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(7, 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        java.util.List list10 = timeSeries4.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class17);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
        java.lang.String str21 = timeSeries18.getRangeDescription();
        timeSeries18.setNotify(true);
        java.util.List list24 = timeSeries18.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        long long28 = fixedMillisecond26.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond26.previous();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond26.next();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 5L + "'", long28 == 5L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        int int8 = timeSeries4.getItemCount();
//        java.lang.String str9 = timeSeries4.getDomainDescription();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
//    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate7);
//        boolean boolean9 = spreadsheetDate2.isOnOrAfter(serialDate8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean12 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        boolean boolean15 = day13.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        boolean boolean19 = day17.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate20 = day17.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate21 = serialDate16.getEndOfCurrentMonth(serialDate20);
//        java.lang.String str22 = serialDate21.toString();
//        java.lang.String str23 = serialDate21.toString();
//        java.lang.String str24 = serialDate21.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        boolean boolean30 = day28.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate31 = day28.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate31);
//        boolean boolean33 = spreadsheetDate26.isOnOrAfter(serialDate32);
//        java.lang.Class class37 = null;
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        java.lang.String str40 = day39.toString();
//        java.lang.Number number41 = timeSeries38.getValue((org.jfree.data.time.RegularTimePeriod) day39);
//        java.lang.Class class45 = null;
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class45);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        java.lang.Number number49 = timeSeries46.getValue((org.jfree.data.time.RegularTimePeriod) day47);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day47, (double) 10.0f);
//        java.lang.Object obj52 = null;
//        boolean boolean53 = day47.equals(obj52);
//        java.util.Date date54 = day47.getStart();
//        java.lang.Class<?> wildcardClass55 = day47.getClass();
//        java.lang.ClassLoader classLoader56 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass55);
//        boolean boolean57 = spreadsheetDate26.equals((java.lang.Object) classLoader56);
//        boolean boolean59 = spreadsheetDate2.isInRange(serialDate21, (org.jfree.data.time.SerialDate) spreadsheetDate26, (int) (short) -1);
//        try {
//            org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 10, serialDate21);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "30-June-2019" + "'", str22.equals("30-June-2019"));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "30-June-2019" + "'", str23.equals("30-June-2019"));
//        org.junit.Assert.assertNull(str24);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "13-June-2019" + "'", str40.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number41);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "13-June-2019" + "'", str48.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number49);
//        org.junit.Assert.assertNull(timeSeriesDataItem51);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(wildcardClass55);
//        org.junit.Assert.assertNotNull(classLoader56);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
//        boolean boolean8 = spreadsheetDate1.isOnOrAfter(serialDate7);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean11 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        boolean boolean14 = day12.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        boolean boolean18 = day16.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate19 = day16.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate20 = serialDate15.getEndOfCurrentMonth(serialDate19);
//        java.lang.String str21 = serialDate20.toString();
//        java.lang.String str22 = serialDate20.toString();
//        java.lang.String str23 = serialDate20.getDescription();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        boolean boolean29 = day27.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate30 = day27.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate30);
//        boolean boolean32 = spreadsheetDate25.isOnOrAfter(serialDate31);
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        java.lang.String str39 = day38.toString();
//        java.lang.Number number40 = timeSeries37.getValue((org.jfree.data.time.RegularTimePeriod) day38);
//        java.lang.Class class44 = null;
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        java.lang.String str47 = day46.toString();
//        java.lang.Number number48 = timeSeries45.getValue((org.jfree.data.time.RegularTimePeriod) day46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day46, (double) 10.0f);
//        java.lang.Object obj51 = null;
//        boolean boolean52 = day46.equals(obj51);
//        java.util.Date date53 = day46.getStart();
//        java.lang.Class<?> wildcardClass54 = day46.getClass();
//        java.lang.ClassLoader classLoader55 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass54);
//        boolean boolean56 = spreadsheetDate25.equals((java.lang.Object) classLoader55);
//        boolean boolean58 = spreadsheetDate1.isInRange(serialDate20, (org.jfree.data.time.SerialDate) spreadsheetDate25, (int) (short) -1);
//        int int59 = spreadsheetDate25.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate62 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
//        boolean boolean66 = day64.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate67 = day64.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate67);
//        boolean boolean69 = spreadsheetDate62.isOnOrAfter(serialDate68);
//        int int70 = spreadsheetDate62.getMonth();
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day();
//        boolean boolean74 = day72.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate75 = day72.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate76 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate75);
//        java.lang.String str77 = serialDate75.toString();
//        java.lang.String str78 = serialDate75.toString();
//        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day();
//        boolean boolean81 = day79.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate82 = day79.getSerialDate();
//        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day();
//        boolean boolean85 = day83.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate86 = day83.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate87 = serialDate82.getEndOfCurrentMonth(serialDate86);
//        java.lang.String str88 = serialDate82.toString();
//        boolean boolean90 = spreadsheetDate62.isInRange(serialDate75, serialDate82, (int) (byte) 10);
//        org.jfree.data.time.SerialDate serialDate91 = org.jfree.data.time.SerialDate.addDays((int) (short) 1, serialDate82);
//        int int92 = spreadsheetDate25.compare(serialDate91);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "30-June-2019" + "'", str21.equals("30-June-2019"));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "30-June-2019" + "'", str22.equals("30-June-2019"));
//        org.junit.Assert.assertNull(str23);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "13-June-2019" + "'", str39.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number40);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "13-June-2019" + "'", str47.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number48);
//        org.junit.Assert.assertNull(timeSeriesDataItem50);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(wildcardClass54);
//        org.junit.Assert.assertNotNull(classLoader55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 9 + "'", int59 == 9);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertNotNull(serialDate75);
//        org.junit.Assert.assertNotNull(serialDate76);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "13-June-2019" + "'", str77.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "13-June-2019" + "'", str78.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertNotNull(serialDate82);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//        org.junit.Assert.assertNotNull(serialDate86);
//        org.junit.Assert.assertNotNull(serialDate87);
//        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "13-June-2019" + "'", str88.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
//        org.junit.Assert.assertNotNull(serialDate91);
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + (-43620) + "'", int92 == (-43620));
//    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        long long2 = month1.getMiddleMillisecond();
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class8);
//        long long10 = timeSeries9.getMaximumItemAge();
//        java.lang.Class<?> wildcardClass11 = timeSeries9.getClass();
//        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResource("13-June-2019", (java.lang.Class) wildcardClass11);
//        java.net.URL uRL13 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("30-June-2019", (java.lang.Class) wildcardClass11);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.lang.String str20 = day19.toString();
//        java.lang.Number number21 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) day19);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        java.lang.Number number29 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day27, (double) 10.0f);
//        java.lang.Object obj32 = null;
//        boolean boolean33 = day27.equals(obj32);
//        java.util.Date date34 = day27.getStart();
//        java.util.TimeZone timeZone35 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date34, timeZone35);
//        boolean boolean37 = month1.equals((java.lang.Object) date34);
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date34);
//        java.lang.Class class46 = null;
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class46);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        java.lang.Number number50 = timeSeries47.getValue((org.jfree.data.time.RegularTimePeriod) day48);
//        java.lang.Class class54 = null;
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class54);
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
//        java.lang.String str57 = day56.toString();
//        java.lang.Number number58 = timeSeries55.getValue((org.jfree.data.time.RegularTimePeriod) day56);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries47.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day56, (double) 10.0f);
//        java.lang.Object obj61 = null;
//        boolean boolean62 = day56.equals(obj61);
//        java.util.Date date63 = day56.getStart();
//        java.lang.Class<?> wildcardClass64 = day56.getClass();
//        java.io.InputStream inputStream65 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass64);
//        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, "org.jfree.data.time.TimePeriodFormatException: ", "hi!", (java.lang.Class) wildcardClass64);
//        java.lang.Class class70 = null;
//        org.jfree.data.time.TimeSeries timeSeries71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class70);
//        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day();
//        java.lang.String str73 = day72.toString();
//        java.lang.Number number74 = timeSeries71.getValue((org.jfree.data.time.RegularTimePeriod) day72);
//        java.lang.Class class78 = null;
//        org.jfree.data.time.TimeSeries timeSeries79 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class78);
//        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day();
//        java.lang.String str81 = day80.toString();
//        java.lang.Number number82 = timeSeries79.getValue((org.jfree.data.time.RegularTimePeriod) day80);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem84 = timeSeries71.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day80, (double) 10.0f);
//        java.lang.Object obj85 = null;
//        boolean boolean86 = day80.equals(obj85);
//        java.util.Date date87 = day80.getStart();
//        java.util.TimeZone timeZone88 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass64, date87, timeZone88);
//        java.util.TimeZone timeZone90 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month91 = new org.jfree.data.time.Month(date87, timeZone90);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod92 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date34, timeZone90);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560668399999L + "'", long2 == 1560668399999L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNull(uRL12);
//        org.junit.Assert.assertNull(uRL13);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number21);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number29);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-June-2019" + "'", str49.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number50);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "13-June-2019" + "'", str57.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number58);
//        org.junit.Assert.assertNull(timeSeriesDataItem60);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(wildcardClass64);
//        org.junit.Assert.assertNotNull(inputStream65);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "13-June-2019" + "'", str73.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number74);
//        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "13-June-2019" + "'", str81.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number82);
//        org.junit.Assert.assertNull(timeSeriesDataItem84);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//        org.junit.Assert.assertNotNull(date87);
//        org.junit.Assert.assertNull(regularTimePeriod89);
//        org.junit.Assert.assertNotNull(timeZone90);
//        org.junit.Assert.assertNull(regularTimePeriod92);
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        java.util.List list10 = timeSeries4.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.previous();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class19);
        int int21 = fixedMillisecond12.compareTo((java.lang.Object) 10.0d);
        java.util.Calendar calendar22 = null;
        fixedMillisecond12.peg(calendar22);
        int int25 = fixedMillisecond12.compareTo((java.lang.Object) 100L);
        java.lang.Number number26 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, number26);
        java.lang.Number number28 = timeSeriesDataItem27.getValue();
        java.lang.Object obj29 = timeSeriesDataItem27.clone();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5L + "'", long14 == 5L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertNotNull(obj29);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.lang.String str7 = day6.toString();
//        java.lang.Number number8 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) day6);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day14, (double) 10.0f);
//        java.lang.Object obj19 = null;
//        boolean boolean20 = day14.equals(obj19);
//        java.util.Date date21 = day14.getStart();
//        java.lang.Class<?> wildcardClass22 = day14.getClass();
//        java.io.InputStream inputStream23 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass22);
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number8);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(inputStream23);
//        org.junit.Assert.assertNotNull(class24);
//    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test397");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day13.equals(obj18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) (-460));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem21.getPeriod();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 1);
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        java.lang.Number number12 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.String str19 = day18.toString();
//        java.lang.Number number20 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) day18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day18, (double) 10.0f);
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day18.equals(obj23);
//        java.util.Date date25 = day18.getStart();
//        java.lang.Class<?> wildcardClass26 = day18.getClass();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1, "30-June-2019", "30-June-2019", (java.lang.Class) wildcardClass26);
//        try {
//            timeSeries27.setMaximumItemAge((long) (-460));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "13-June-2019" + "'", str19.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number20);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
//        java.lang.Class<?> wildcardClass8 = serialDate6.getClass();
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        java.lang.Number number18 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) day16);
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.lang.String str25 = day24.toString();
//        java.lang.Number number26 = timeSeries23.getValue((org.jfree.data.time.RegularTimePeriod) day24);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day24, (double) 10.0f);
//        java.lang.Object obj29 = null;
//        boolean boolean30 = day24.equals(obj29);
//        java.util.Date date31 = day24.getStart();
//        java.lang.Class<?> wildcardClass32 = day24.getClass();
//        java.io.InputStream inputStream33 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass32);
//        java.net.URL uRL34 = org.jfree.chart.util.ObjectUtilities.getResource("30-June-2019", (java.lang.Class) wildcardClass32);
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass8, (java.lang.Class) wildcardClass32);
//        java.net.URL uRL36 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("30-June-2019", (java.lang.Class) wildcardClass8);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number18);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "13-June-2019" + "'", str25.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number26);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(inputStream33);
//        org.junit.Assert.assertNull(uRL34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertNull(uRL36);
//    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str4 = timePeriodFormatException3.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str11 = timePeriodFormatException10.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException10.addSuppressed((java.lang.Throwable) timePeriodFormatException13);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries4.addAndOrUpdate(timeSeries22);
//        int int27 = timeSeries4.getItemCount();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        boolean boolean30 = day28.equals((java.lang.Object) 1);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        boolean boolean35 = day33.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate36 = day33.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate36);
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addYears(13, serialDate36);
//        int int39 = day28.compareTo((java.lang.Object) serialDate36);
//        java.lang.Number number40 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day28);
//        long long41 = day28.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 10.0d + "'", number40.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 43629L + "'", long41 == 43629L);
//    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test405");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day13.equals(obj18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) (-460));
//        int int22 = day13.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 13 + "'", int22 == 13);
//    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.general.SeriesChangeEvent[source=1.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        java.util.List list10 = timeSeries4.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond12.getMiddleMillisecond(calendar15);
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond12.getFirstMillisecond(calendar17);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5L + "'", long14 == 5L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 5L + "'", long16 == 5L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 5L + "'", long18 == 5L);
    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        long long5 = timeSeries4.getMaximumItemAge();
//        java.lang.Class<?> wildcardClass6 = timeSeries4.getClass();
//        timeSeries4.setMaximumItemCount((int) (short) 0);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        org.jfree.data.time.SerialDate serialDate17 = day14.getSerialDate();
//        int int18 = day14.getMonth();
//        java.lang.Number number19 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        long long20 = day14.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertNull(number19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560452399999L + "'", long20 == 1560452399999L);
//    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test409");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day13.equals(obj18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 10L);
//        timeSeriesDataItem21.setValue((java.lang.Number) 2147483647);
//        java.lang.Number number24 = timeSeriesDataItem21.getValue();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 2147483647 + "'", number24.equals(2147483647));
//    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), class1);
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        java.lang.Number number10 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        java.lang.Number number18 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) day16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries7.addChangeListener(seriesChangeListener21);
//        java.lang.Class class26 = null;
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.lang.String str29 = day28.toString();
//        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) day28);
//        java.lang.Class class34 = null;
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        java.lang.String str37 = day36.toString();
//        java.lang.Number number38 = timeSeries35.getValue((org.jfree.data.time.RegularTimePeriod) day36);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day36, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
//        timeSeries27.addChangeListener(seriesChangeListener41);
//        timeSeries27.setMaximumItemAge((long) (short) 10);
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
//        long long46 = year45.getSerialIndex();
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        boolean boolean49 = year45.equals((java.lang.Object) day47);
//        java.lang.Number number50 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) day47);
//        java.util.Collection collection51 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries27);
//        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries2.addAndOrUpdate(timeSeries27);
//        boolean boolean53 = timeSeries2.isEmpty();
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number10);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number18);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "13-June-2019" + "'", str29.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number30);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "13-June-2019" + "'", str37.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number38);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 2019L + "'", long46 == 2019L);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "13-June-2019" + "'", str48.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertTrue("'" + number50 + "' != '" + 10.0d + "'", number50.equals(10.0d));
//        org.junit.Assert.assertNotNull(collection51);
//        org.junit.Assert.assertNotNull(timeSeries52);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(2958465);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = day0.equals(obj2);
//        java.util.Date date4 = day0.getEnd();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        java.lang.Number number24 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) 10.0f);
//        java.lang.Object obj27 = null;
//        boolean boolean28 = day22.equals(obj27);
//        java.util.Date date29 = day22.getStart();
//        java.lang.Class<?> wildcardClass30 = day22.getClass();
//        java.io.InputStream inputStream31 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass30);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, "org.jfree.data.time.TimePeriodFormatException: ", "hi!", (java.lang.Class) wildcardClass30);
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        java.lang.String str39 = day38.toString();
//        java.lang.Number number40 = timeSeries37.getValue((org.jfree.data.time.RegularTimePeriod) day38);
//        java.lang.Class class44 = null;
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        java.lang.String str47 = day46.toString();
//        java.lang.Number number48 = timeSeries45.getValue((org.jfree.data.time.RegularTimePeriod) day46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day46, (double) 10.0f);
//        java.lang.Object obj51 = null;
//        boolean boolean52 = day46.equals(obj51);
//        java.util.Date date53 = day46.getStart();
//        java.util.TimeZone timeZone54 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date53, timeZone54);
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month(date53, timeZone56);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date4, timeZone56);
//        int int59 = year58.getYear();
//        java.lang.String str60 = year58.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(inputStream31);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "13-June-2019" + "'", str39.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number40);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "13-June-2019" + "'", str47.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number48);
//        org.junit.Assert.assertNull(timeSeriesDataItem50);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(timeZone56);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "2019" + "'", str60.equals("2019"));
//    }

//    @Test
//    public void test413() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test413");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = serialDate3.getEndOfCurrentMonth(serialDate7);
//        java.lang.String str9 = serialDate3.toString();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str9);
//        java.lang.String str11 = timeSeries10.getDomainDescription();
//        timeSeries10.clear();
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
//    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        java.util.List list10 = timeSeries4.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class17);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries18.addPropertyChangeListener(propertyChangeListener19);
        java.lang.String str21 = timeSeries18.getRangeDescription();
        timeSeries18.setNotify(true);
        java.util.List list24 = timeSeries18.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries18.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        long long28 = fixedMillisecond26.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond26.previous();
        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        long long31 = fixedMillisecond26.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 5L + "'", long28 == 5L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 5L + "'", long31 == 5L);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-43620));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class5);
        long long7 = timeSeries6.getMaximumItemAge();
        java.lang.Class<?> wildcardClass8 = timeSeries6.getClass();
        java.net.URL uRL9 = org.jfree.chart.util.ObjectUtilities.getResource("13-June-2019", (java.lang.Class) wildcardClass8);
        java.net.URL uRL10 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("30-June-2019", (java.lang.Class) wildcardClass8);
        java.lang.ClassLoader classLoader11 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass8);
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader11);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(uRL9);
        org.junit.Assert.assertNull(uRL10);
        org.junit.Assert.assertNotNull(classLoader11);
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = day0.equals(obj2);
//        java.util.Date date4 = day0.getEnd();
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        java.lang.Number number24 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) 10.0f);
//        java.lang.Object obj27 = null;
//        boolean boolean28 = day22.equals(obj27);
//        java.util.Date date29 = day22.getStart();
//        java.lang.Class<?> wildcardClass30 = day22.getClass();
//        java.io.InputStream inputStream31 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass30);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, "org.jfree.data.time.TimePeriodFormatException: ", "hi!", (java.lang.Class) wildcardClass30);
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class36);
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
//        java.lang.String str39 = day38.toString();
//        java.lang.Number number40 = timeSeries37.getValue((org.jfree.data.time.RegularTimePeriod) day38);
//        java.lang.Class class44 = null;
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        java.lang.String str47 = day46.toString();
//        java.lang.Number number48 = timeSeries45.getValue((org.jfree.data.time.RegularTimePeriod) day46);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries37.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day46, (double) 10.0f);
//        java.lang.Object obj51 = null;
//        boolean boolean52 = day46.equals(obj51);
//        java.util.Date date53 = day46.getStart();
//        java.util.TimeZone timeZone54 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date53, timeZone54);
//        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Month month57 = new org.jfree.data.time.Month(date53, timeZone56);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date4, timeZone56);
//        java.util.Calendar calendar59 = null;
//        try {
//            long long60 = year58.getLastMillisecond(calendar59);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "13-June-2019" + "'", str1.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(inputStream31);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "13-June-2019" + "'", str39.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number40);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "13-June-2019" + "'", str47.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number48);
//        org.junit.Assert.assertNull(timeSeriesDataItem50);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNull(regularTimePeriod55);
//        org.junit.Assert.assertNotNull(timeZone56);
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year7);
        java.lang.Object obj10 = null;
        boolean boolean11 = year7.equals(obj10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) 2019L);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year7.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test419");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        int int4 = day2.getYear();
//        java.lang.String str5 = day2.toString();
//        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) str5);
//        long long7 = fixedMillisecond1.getMiddleMillisecond();
//        long long8 = fixedMillisecond1.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 5L + "'", long7 == 5L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 5L + "'", long8 == 5L);
//    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test420");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
//        boolean boolean8 = spreadsheetDate1.isOnOrAfter(serialDate7);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        java.lang.Number number24 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) 10.0f);
//        java.lang.Object obj27 = null;
//        boolean boolean28 = day22.equals(obj27);
//        java.util.Date date29 = day22.getStart();
//        java.lang.Class<?> wildcardClass30 = day22.getClass();
//        java.lang.ClassLoader classLoader31 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass30);
//        boolean boolean32 = spreadsheetDate1.equals((java.lang.Object) classLoader31);
//        java.util.Date date33 = spreadsheetDate1.toDate();
//        org.jfree.data.time.SerialDate serialDate34 = null;
//        try {
//            boolean boolean35 = spreadsheetDate1.isBefore(serialDate34);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(classLoader31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(date33);
//    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 100, (-458), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        java.util.List list10 = timeSeries4.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.previous();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class19);
        int int21 = fixedMillisecond12.compareTo((java.lang.Object) 10.0d);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond12.getFirstMillisecond(calendar22);
        long long24 = fixedMillisecond12.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5L + "'", long14 == 5L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 5L + "'", long23 == 5L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 5L + "'", long24 == 5L);
    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test423");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        boolean boolean3 = day1.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate4 = day1.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate4);
//        java.lang.String str6 = serialDate4.toString();
//        java.lang.String str7 = serialDate4.toString();
//        boolean boolean9 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) serialDate4, (java.lang.Object) 0L);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        java.lang.Number number24 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.lang.String str31 = day30.toString();
//        java.lang.Number number32 = timeSeries29.getValue((org.jfree.data.time.RegularTimePeriod) day30);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day30, (double) 10.0f);
//        java.lang.Object obj35 = null;
//        boolean boolean36 = day30.equals(obj35);
//        java.util.Date date37 = day30.getStart();
//        java.lang.Class<?> wildcardClass38 = day30.getClass();
//        java.io.InputStream inputStream39 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass38);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, "org.jfree.data.time.TimePeriodFormatException: ", "hi!", (java.lang.Class) wildcardClass38);
//        java.lang.Class class44 = null;
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class44);
//        long long46 = timeSeries45.getMaximumItemAge();
//        java.lang.Class<?> wildcardClass47 = timeSeries45.getClass();
//        java.lang.Object obj48 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass38, (java.lang.Class) wildcardClass47);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean9, "13-June-2019", "30-June-2019", (java.lang.Class) wildcardClass38);
//        java.lang.Object obj50 = timeSeries49.clone();
//        java.lang.Class class54 = null;
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class54);
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
//        java.lang.String str57 = day56.toString();
//        java.lang.Number number58 = timeSeries55.getValue((org.jfree.data.time.RegularTimePeriod) day56);
//        java.lang.Class class62 = null;
//        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class62);
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
//        java.lang.String str65 = day64.toString();
//        java.lang.Number number66 = timeSeries63.getValue((org.jfree.data.time.RegularTimePeriod) day64);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries55.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day64, (double) 10.0f);
//        java.lang.Class class72 = null;
//        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class72);
//        java.beans.PropertyChangeListener propertyChangeListener74 = null;
//        timeSeries73.addPropertyChangeListener(propertyChangeListener74);
//        java.lang.String str76 = timeSeries73.getRangeDescription();
//        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day();
//        java.lang.String str78 = day77.toString();
//        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day();
//        boolean boolean81 = day79.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries82 = timeSeries73.createCopy((org.jfree.data.time.RegularTimePeriod) day77, (org.jfree.data.time.RegularTimePeriod) day79);
//        int int83 = day64.compareTo((java.lang.Object) day79);
//        long long84 = day64.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = day64.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = day64.previous();
//        java.util.Date date87 = day64.getStart();
//        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) day64, (java.lang.Number) (short) 10);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "13-June-2019" + "'", str7.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "13-June-2019" + "'", str31.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number32);
//        org.junit.Assert.assertNull(timeSeriesDataItem34);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNotNull(inputStream39);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 9223372036854775807L + "'", long46 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(wildcardClass47);
//        org.junit.Assert.assertNull(obj48);
//        org.junit.Assert.assertNotNull(obj50);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "13-June-2019" + "'", str57.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number58);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "13-June-2019" + "'", str65.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number66);
//        org.junit.Assert.assertNull(timeSeriesDataItem68);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "" + "'", str76.equals(""));
//        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "13-June-2019" + "'", str78.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertNotNull(timeSeries82);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1560409200000L + "'", long84 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod85);
//        org.junit.Assert.assertNotNull(regularTimePeriod86);
//        org.junit.Assert.assertNotNull(date87);
//    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        long long14 = timeSeries4.getMaximumItemAge();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener15);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
//        timeSeries4.addChangeListener(seriesChangeListener17);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
//    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        java.util.List list10 = timeSeries4.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.previous();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class19);
        int int21 = fixedMillisecond12.compareTo((java.lang.Object) 10.0d);
        java.util.Calendar calendar22 = null;
        fixedMillisecond12.peg(calendar22);
        int int25 = fixedMillisecond12.compareTo((java.lang.Object) 100L);
        java.lang.Number number26 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, number26);
        java.lang.Number number28 = timeSeriesDataItem27.getValue();
        java.lang.Number number29 = timeSeriesDataItem27.getValue();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5L + "'", long14 == 5L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertNull(number29);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        java.util.List list10 = timeSeries4.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.previous();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class19);
        int int21 = fixedMillisecond12.compareTo((java.lang.Object) 10.0d);
        java.util.Calendar calendar22 = null;
        fixedMillisecond12.peg(calendar22);
        int int25 = fixedMillisecond12.compareTo((java.lang.Object) 100L);
        java.lang.Number number26 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, number26);
        java.lang.Number number28 = timeSeriesDataItem27.getValue();
        timeSeriesDataItem27.setValue((java.lang.Number) 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5L + "'", long14 == 5L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNull(number28);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("ERROR : Relative To String");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getSerialIndex();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        boolean boolean4 = year0.equals((java.lang.Object) day2);
//        long long5 = year0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("ThreadContext");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener8);
        java.lang.String str10 = timeSeries4.getDescription();
        timeSeries4.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: ");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener13);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNull(str10);
    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        java.lang.Class class1 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, class1);
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        java.lang.Number number10 = timeSeries7.getValue((org.jfree.data.time.RegularTimePeriod) day8);
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        java.lang.Number number18 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) day16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (double) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries2.getDataItem((org.jfree.data.time.RegularTimePeriod) day16);
//        timeSeries2.setDomainDescription("13-June-2019");
//        java.lang.String str24 = timeSeries2.getDomainDescription();
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number10);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number18);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        boolean boolean6 = day4.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate7);
        boolean boolean9 = spreadsheetDate2.isOnOrAfter(serialDate8);
        java.lang.String str10 = spreadsheetDate2.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate(10);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        boolean boolean16 = day14.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate17 = day14.getSerialDate();
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate17);
        boolean boolean19 = spreadsheetDate12.isOnOrAfter(serialDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate(10);
        boolean boolean22 = spreadsheetDate12.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
        java.util.Date date23 = spreadsheetDate21.toDate();
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(date23);
        boolean boolean25 = spreadsheetDate2.isOn(serialDate24);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(serialDate26);
    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        java.lang.Number number11 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) day9);
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.String str18 = day17.toString();
//        java.lang.Number number19 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) day17);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day17, (double) 10.0f);
//        java.lang.Object obj22 = null;
//        boolean boolean23 = day17.equals(obj22);
//        java.util.Date date24 = day17.getStart();
//        java.lang.Class<?> wildcardClass25 = day17.getClass();
//        java.io.InputStream inputStream26 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass25);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, "org.jfree.data.time.TimePeriodFormatException: ", "hi!", (java.lang.Class) wildcardClass25);
//        timeSeries27.fireSeriesChanged();
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number11);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number19);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(inputStream26);
//    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("June");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        java.util.List list10 = timeSeries4.getItems();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        boolean boolean15 = day13.equals((java.lang.Object) 1);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        boolean boolean20 = day18.equals((java.lang.Object) 1);
        org.jfree.data.time.SerialDate serialDate21 = day18.getSerialDate();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears(13, serialDate21);
        int int24 = day13.compareTo((java.lang.Object) serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, serialDate21);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addMonths((int) '#', serialDate21);
        boolean boolean27 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) list10, (java.lang.Object) '#');
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        boolean boolean3 = day1.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate4 = day1.getSerialDate();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        boolean boolean7 = day5.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate8 = day5.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate9 = serialDate4.getEndOfCurrentMonth(serialDate8);
//        java.lang.String str10 = serialDate9.toString();
//        java.lang.Class<?> wildcardClass11 = serialDate9.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        int int16 = day14.getYear();
//        java.lang.String str17 = day14.toString();
//        boolean boolean18 = fixedMillisecond13.equals((java.lang.Object) str17);
//        java.util.Date date19 = fixedMillisecond13.getTime();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        boolean boolean26 = day24.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate27 = day24.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate27);
//        java.lang.Class<?> wildcardClass29 = serialDate27.getClass();
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        java.lang.String str38 = day37.toString();
//        java.lang.Number number39 = timeSeries36.getValue((org.jfree.data.time.RegularTimePeriod) day37);
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class43);
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        java.lang.String str46 = day45.toString();
//        java.lang.Number number47 = timeSeries44.getValue((org.jfree.data.time.RegularTimePeriod) day45);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day45, (double) 10.0f);
//        java.lang.Object obj50 = null;
//        boolean boolean51 = day45.equals(obj50);
//        java.util.Date date52 = day45.getStart();
//        java.lang.Class<?> wildcardClass53 = day45.getClass();
//        java.io.InputStream inputStream54 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass53);
//        java.net.URL uRL55 = org.jfree.chart.util.ObjectUtilities.getResource("30-June-2019", (java.lang.Class) wildcardClass53);
//        java.lang.Object obj56 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass29, (java.lang.Class) wildcardClass53);
//        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date19, "ERROR : Relative To String", "December 3", (java.lang.Class) wildcardClass53);
//        java.lang.Object obj58 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("June", (java.lang.Class) wildcardClass11, (java.lang.Class) wildcardClass53);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "30-June-2019" + "'", str10.equals("30-June-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "13-June-2019" + "'", str38.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number39);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "13-June-2019" + "'", str46.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number47);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(wildcardClass53);
//        org.junit.Assert.assertNotNull(inputStream54);
//        org.junit.Assert.assertNull(uRL55);
//        org.junit.Assert.assertNull(obj56);
//        org.junit.Assert.assertNull(obj58);
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) ' ');
        org.junit.Assert.assertNotNull(serialDate1);
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        boolean boolean4 = day2.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        boolean boolean8 = day6.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate10 = serialDate5.getEndOfCurrentMonth(serialDate9);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        boolean boolean14 = day12.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate15);
//        java.lang.String str17 = serialDate15.toString();
//        org.jfree.data.time.SerialDate serialDate18 = serialDate10.getEndOfCurrentMonth(serialDate15);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        boolean boolean21 = day19.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        boolean boolean25 = day23.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate26 = day23.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate27 = serialDate22.getEndOfCurrentMonth(serialDate26);
//        boolean boolean29 = spreadsheetDate1.isInRange(serialDate15, serialDate27, 2019);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        boolean boolean34 = day32.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate35 = day32.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate35);
//        java.lang.String str37 = serialDate35.toString();
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addMonths(0, serialDate35);
//        boolean boolean39 = spreadsheetDate1.isOnOrBefore(serialDate38);
//        spreadsheetDate1.setDescription("May");
//        org.jfree.data.time.SerialDate serialDate42 = null;
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        boolean boolean48 = day46.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate49 = day46.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate49);
//        boolean boolean51 = spreadsheetDate44.isOnOrAfter(serialDate50);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate(10);
//        boolean boolean54 = spreadsheetDate44.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate53);
//        int int55 = spreadsheetDate53.toSerial();
//        int int56 = spreadsheetDate53.toSerial();
//        try {
//            boolean boolean58 = spreadsheetDate1.isInRange(serialDate42, (org.jfree.data.time.SerialDate) spreadsheetDate53, 5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "13-June-2019" + "'", str37.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 10 + "'", int55 == 10);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 10 + "'", int56 == 10);
//    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: "));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        java.util.List list10 = timeSeries4.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.previous();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class19);
        int int21 = fixedMillisecond12.compareTo((java.lang.Object) 10.0d);
        java.util.Calendar calendar22 = null;
        fixedMillisecond12.peg(calendar22);
        int int25 = fixedMillisecond12.compareTo((java.lang.Object) 100L);
        java.lang.Number number26 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, number26);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5L + "'", long14 == 5L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        int int4 = day2.getYear();
//        java.lang.String str5 = day2.toString();
//        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) str5);
//        java.util.Date date7 = fixedMillisecond1.getTime();
//        boolean boolean9 = fixedMillisecond1.equals((java.lang.Object) 10.0d);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond1.getFirstMillisecond(calendar10);
//        long long12 = fixedMillisecond1.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 5L + "'", long11 == 5L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 5L + "'", long12 == 5L);
//    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test444");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries4.addChangeListener(seriesChangeListener18);
//        timeSeries4.setMaximumItemAge((long) (short) 10);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.lang.String str28 = day27.toString();
//        java.lang.Number number29 = timeSeries26.getValue((org.jfree.data.time.RegularTimePeriod) day27);
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.lang.String str36 = day35.toString();
//        java.lang.Number number37 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) day35);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day35, (double) 10.0f);
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class43);
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timeSeries44.addPropertyChangeListener(propertyChangeListener45);
//        java.lang.String str47 = timeSeries44.getRangeDescription();
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.lang.String str49 = day48.toString();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        boolean boolean52 = day50.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) day48, (org.jfree.data.time.RegularTimePeriod) day50);
//        int int54 = day35.compareTo((java.lang.Object) day50);
//        timeSeries4.delete((org.jfree.data.time.RegularTimePeriod) day50);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond((long) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond57, (java.lang.Number) 1.0f);
//        int int60 = timeSeries4.getMaximumItemCount();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number29);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number37);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "13-June-2019" + "'", str49.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(timeSeries53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertNull(timeSeriesDataItem59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2147483647 + "'", int60 == 2147483647);
//    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        int int4 = day2.getYear();
//        java.lang.String str5 = day2.toString();
//        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) str5);
//        java.util.Date date7 = fixedMillisecond1.getTime();
//        boolean boolean9 = fixedMillisecond1.equals((java.lang.Object) 10.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond1.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond1.previous();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test446");
//        java.lang.Class class8 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        java.lang.Number number12 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class16 = null;
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.lang.String str19 = day18.toString();
//        java.lang.Number number20 = timeSeries17.getValue((org.jfree.data.time.RegularTimePeriod) day18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day18, (double) 10.0f);
//        java.lang.Object obj23 = null;
//        boolean boolean24 = day18.equals(obj23);
//        java.util.Date date25 = day18.getStart();
//        java.lang.Class<?> wildcardClass26 = day18.getClass();
//        java.io.InputStream inputStream27 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass26);
//        java.net.URL uRL28 = org.jfree.chart.util.ObjectUtilities.getResource("30-June-2019", (java.lang.Class) wildcardClass26);
//        java.lang.Object obj29 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", (java.lang.Class) wildcardClass26);
//        java.io.InputStream inputStream30 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("30-June-2019", (java.lang.Class) wildcardClass26);
//        java.io.InputStream inputStream31 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass26);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "13-June-2019" + "'", str19.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number20);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertNotNull(inputStream27);
//        org.junit.Assert.assertNull(uRL28);
//        org.junit.Assert.assertNull(obj29);
//        org.junit.Assert.assertNull(inputStream30);
//        org.junit.Assert.assertNotNull(inputStream31);
//    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        timeSeries4.setNotify(true);
//        java.util.List list10 = timeSeries4.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        long long14 = fixedMillisecond12.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.previous();
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class19);
//        int int21 = fixedMillisecond12.compareTo((java.lang.Object) 10.0d);
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond12.getMiddleMillisecond(calendar22);
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.lang.String str30 = day29.toString();
//        java.lang.Number number31 = timeSeries28.getValue((org.jfree.data.time.RegularTimePeriod) day29);
//        java.lang.Class class35 = null;
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class35);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        java.lang.String str38 = day37.toString();
//        java.lang.Number number39 = timeSeries36.getValue((org.jfree.data.time.RegularTimePeriod) day37);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day37, (double) 10.0f);
//        java.lang.Class class45 = null;
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class45);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.lang.String str48 = day47.toString();
//        java.lang.Number number49 = timeSeries46.getValue((org.jfree.data.time.RegularTimePeriod) day47);
//        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries28.addAndOrUpdate(timeSeries46);
//        boolean boolean51 = fixedMillisecond12.equals((java.lang.Object) timeSeries28);
//        java.util.Date date52 = fixedMillisecond12.getTime();
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertNotNull(list10);
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5L + "'", long14 == 5L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 5L + "'", long23 == 5L);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "13-June-2019" + "'", str30.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number31);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "13-June-2019" + "'", str38.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number39);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "13-June-2019" + "'", str48.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number49);
//        org.junit.Assert.assertNotNull(timeSeries50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(date52);
//    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        timeSeries4.setMaximumItemAge((long) 2019);
        long long7 = timeSeries4.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        timeSeries4.setMaximumItemAge((long) 2019);
//        java.lang.String str7 = timeSeries4.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        int int12 = day10.getYear();
//        java.lang.String str13 = day10.toString();
//        boolean boolean14 = fixedMillisecond9.equals((java.lang.Object) str13);
//        long long15 = fixedMillisecond9.getMiddleMillisecond();
//        timeSeries4.setKey((java.lang.Comparable) long15);
//        org.junit.Assert.assertNull(str7);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "13-June-2019" + "'", str13.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 5L + "'", long15 == 5L);
//    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries4.addAndOrUpdate(timeSeries22);
//        java.lang.Class class28 = null;
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), class28);
//        java.util.Collection collection30 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries29);
//        java.lang.Class class31 = timeSeries29.getTimePeriodClass();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertNotNull(collection30);
//        org.junit.Assert.assertNull(class31);
//    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        java.lang.String str3 = seriesException1.toString();
        java.lang.Throwable[] throwableArray4 = seriesException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str3.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 3);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        java.lang.String str5 = month2.toString();
        long long6 = month2.getLastMillisecond();
        java.lang.String str7 = month2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "December 3" + "'", str3.equals("December 3"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "December 3" + "'", str5.equals("December 3"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62041132800001L) + "'", long6 == (-62041132800001L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "December 3" + "'", str7.equals("December 3"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.util.Collection collection5 = timeSeries4.getTimePeriods();
        org.junit.Assert.assertNotNull(collection5);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Apr");
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(1900);
        java.lang.String str2 = spreadsheetDate1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "14-March-1905" + "'", str2.equals("14-March-1905"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        java.util.Calendar calendar3 = null;
        try {
            month0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560668399999L + "'", long1 == 1560668399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test458");
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
//        java.lang.Class<?> wildcardClass8 = serialDate6.getClass();
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.lang.String str17 = day16.toString();
//        java.lang.Number number18 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) day16);
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.lang.String str25 = day24.toString();
//        java.lang.Number number26 = timeSeries23.getValue((org.jfree.data.time.RegularTimePeriod) day24);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries15.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day24, (double) 10.0f);
//        java.lang.Object obj29 = null;
//        boolean boolean30 = day24.equals(obj29);
//        java.util.Date date31 = day24.getStart();
//        java.lang.Class<?> wildcardClass32 = day24.getClass();
//        java.io.InputStream inputStream33 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass32);
//        java.net.URL uRL34 = org.jfree.chart.util.ObjectUtilities.getResource("30-June-2019", (java.lang.Class) wildcardClass32);
//        java.lang.Object obj35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass8, (java.lang.Class) wildcardClass32);
//        java.net.URL uRL36 = org.jfree.chart.util.ObjectUtilities.getResource("ThreadContext", (java.lang.Class) wildcardClass8);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number18);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "13-June-2019" + "'", str25.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number26);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(inputStream33);
//        org.junit.Assert.assertNull(uRL34);
//        org.junit.Assert.assertNull(obj35);
//        org.junit.Assert.assertNull(uRL36);
//    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        boolean boolean2 = day0.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate8 = serialDate3.getEndOfCurrentMonth(serialDate7);
//        java.lang.String str9 = serialDate3.toString();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) str9);
//        java.lang.String str11 = timeSeries10.getDomainDescription();
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries10.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
//    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        int int4 = day2.getYear();
//        java.lang.String str5 = day2.toString();
//        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) str5);
//        java.util.Date date7 = fixedMillisecond1.getTime();
//        long long8 = fixedMillisecond1.getFirstMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond1.getMiddleMillisecond(calendar9);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 5L + "'", long8 == 5L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 5L + "'", long10 == 5L);
//    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timeSeries22.addPropertyChangeListener(propertyChangeListener23);
//        java.lang.String str25 = timeSeries22.getRangeDescription();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.lang.String str27 = day26.toString();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        boolean boolean30 = day28.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) day26, (org.jfree.data.time.RegularTimePeriod) day28);
//        int int32 = day13.compareTo((java.lang.Object) day28);
//        long long33 = day13.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day13.next();
//        java.lang.String str35 = day13.toString();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560409200000L + "'", long33 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "13-June-2019" + "'", str35.equals("13-June-2019"));
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class6);
        long long8 = timeSeries7.getMaximumItemAge();
        java.lang.Class<?> wildcardClass9 = timeSeries7.getClass();
        java.net.URL uRL10 = org.jfree.chart.util.ObjectUtilities.getResource("13-June-2019", (java.lang.Class) wildcardClass9);
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("30-June-2019", (java.lang.Class) wildcardClass9);
        java.net.URL uRL12 = org.jfree.chart.util.ObjectUtilities.getResource("ThreadContext", (java.lang.Class) wildcardClass9);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(uRL10);
        org.junit.Assert.assertNull(uRL11);
        org.junit.Assert.assertNull(uRL12);
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day13.equals(obj18);
//        java.util.Date date20 = day13.getStart();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.previous();
//        java.lang.Class class26 = null;
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class26);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.lang.String str29 = day28.toString();
//        java.lang.Number number30 = timeSeries27.getValue((org.jfree.data.time.RegularTimePeriod) day28);
//        java.lang.Class class34 = null;
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        java.lang.String str37 = day36.toString();
//        java.lang.Number number38 = timeSeries35.getValue((org.jfree.data.time.RegularTimePeriod) day36);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day36, (double) 10.0f);
//        java.lang.Class class44 = null;
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        java.lang.String str47 = day46.toString();
//        java.lang.Number number48 = timeSeries45.getValue((org.jfree.data.time.RegularTimePeriod) day46);
//        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries27.addAndOrUpdate(timeSeries45);
//        boolean boolean50 = year21.equals((java.lang.Object) timeSeries49);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "13-June-2019" + "'", str29.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number30);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "13-June-2019" + "'", str37.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number38);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "13-June-2019" + "'", str47.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number48);
//        org.junit.Assert.assertNotNull(timeSeries49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        long long5 = timeSeries4.getMaximumItemAge();
        java.util.Collection collection6 = timeSeries4.getTimePeriods();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class10);
        long long12 = timeSeries11.getMaximumItemAge();
        java.lang.String str13 = timeSeries11.getRangeDescription();
        java.util.Collection collection14 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries11);
        timeSeries4.removeAgedItems(false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(collection14);
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day13.equals(obj18);
//        java.util.Date date20 = day13.getStart();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.previous();
//        try {
//            java.lang.Object obj23 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) regularTimePeriod22);
//            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
//        } catch (java.lang.CloneNotSupportedException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, class1);
        java.lang.Object obj3 = timeSeries2.clone();
        java.lang.String str4 = timeSeries2.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener5);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        java.lang.String str7 = timeSeries4.getRangeDescription();
        timeSeries4.setNotify(true);
        java.util.List list10 = timeSeries4.getItems();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond((long) 5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        long long14 = fixedMillisecond12.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond12.previous();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class19);
        int int21 = fixedMillisecond12.compareTo((java.lang.Object) 10.0d);
        java.util.Calendar calendar22 = null;
        fixedMillisecond12.peg(calendar22);
        int int25 = fixedMillisecond12.compareTo((java.lang.Object) 100L);
        long long26 = fixedMillisecond12.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5L + "'", long14 == 5L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 5L + "'", long26 == 5L);
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        timeSeries13.setDescription("May");
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        java.lang.Number number11 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) day9);
//        java.lang.Class class15 = null;
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.String str18 = day17.toString();
//        java.lang.Number number19 = timeSeries16.getValue((org.jfree.data.time.RegularTimePeriod) day17);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day17, (double) 10.0f);
//        java.lang.Object obj22 = null;
//        boolean boolean23 = day17.equals(obj22);
//        java.util.Date date24 = day17.getStart();
//        java.lang.Class<?> wildcardClass25 = day17.getClass();
//        java.io.InputStream inputStream26 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass25);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10, "org.jfree.data.time.TimePeriodFormatException: ", "hi!", (java.lang.Class) wildcardClass25);
//        timeSeries27.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: ");
//        timeSeries27.setDomainDescription("org.jfree.data.general.SeriesException: ");
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number11);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number19);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(inputStream26);
//    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        timeSeries4.clear();
//        int int9 = timeSeries4.getMaximumItemCount();
//        java.lang.String str10 = timeSeries4.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
//    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries4.addAndOrUpdate(timeSeries22);
//        int int27 = timeSeries26.getMaximumItemCount();
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = timeSeries26.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2147483647 + "'", int27 == 2147483647);
//    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean9 = day7.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate10 = day7.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate11 = serialDate6.getEndOfCurrentMonth(serialDate10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        boolean boolean15 = day13.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate16);
//        java.lang.String str18 = serialDate16.toString();
//        org.jfree.data.time.SerialDate serialDate19 = serialDate11.getEndOfCurrentMonth(serialDate16);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        boolean boolean22 = day20.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate23 = day20.getSerialDate();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        boolean boolean26 = day24.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate27 = day24.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate28 = serialDate23.getEndOfCurrentMonth(serialDate27);
//        boolean boolean30 = spreadsheetDate2.isInRange(serialDate16, serialDate28, 2019);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        boolean boolean35 = day33.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate36 = day33.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate36);
//        java.lang.String str38 = serialDate36.toString();
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addMonths(0, serialDate36);
//        boolean boolean40 = spreadsheetDate2.isOnOrBefore(serialDate39);
//        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addMonths(0, serialDate39);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "13-June-2019" + "'", str38.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
//        org.junit.Assert.assertNotNull(serialDate41);
//    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.lang.String str24 = day23.toString();
//        java.lang.Number number25 = timeSeries22.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries4.addAndOrUpdate(timeSeries22);
//        boolean boolean27 = timeSeries4.getNotify();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13-June-2019" + "'", str24.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number25);
//        org.junit.Assert.assertNotNull(timeSeries26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 3);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate6);
//        boolean boolean8 = spreadsheetDate1.isOnOrAfter(serialDate7);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class12);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.lang.String str15 = day14.toString();
//        java.lang.Number number16 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) day14);
//        java.lang.Class class20 = null;
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.lang.String str23 = day22.toString();
//        java.lang.Number number24 = timeSeries21.getValue((org.jfree.data.time.RegularTimePeriod) day22);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day22, (double) 10.0f);
//        java.lang.Object obj27 = null;
//        boolean boolean28 = day22.equals(obj27);
//        java.util.Date date29 = day22.getStart();
//        java.lang.Class<?> wildcardClass30 = day22.getClass();
//        java.lang.ClassLoader classLoader31 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass30);
//        boolean boolean32 = spreadsheetDate1.equals((java.lang.Object) classLoader31);
//        java.util.Date date33 = spreadsheetDate1.toDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date33);
//        java.lang.Class class38 = null;
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class38);
//        java.beans.PropertyChangeListener propertyChangeListener40 = null;
//        timeSeries39.addPropertyChangeListener(propertyChangeListener40);
//        java.lang.String str42 = timeSeries39.getRangeDescription();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        java.lang.String str44 = day43.toString();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
//        boolean boolean47 = day45.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries39.createCopy((org.jfree.data.time.RegularTimePeriod) day43, (org.jfree.data.time.RegularTimePeriod) day45);
//        java.lang.Class class52 = null;
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class52);
//        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries39.addAndOrUpdate(timeSeries53);
//        int int55 = fixedMillisecond34.compareTo((java.lang.Object) timeSeries39);
//        java.util.Collection collection56 = timeSeries39.getTimePeriods();
//        java.util.List list57 = timeSeries39.getItems();
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number16);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "13-June-2019" + "'", str23.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number24);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(classLoader31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "13-June-2019" + "'", str44.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(timeSeries48);
//        org.junit.Assert.assertNotNull(timeSeries54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
//        org.junit.Assert.assertNotNull(collection56);
//        org.junit.Assert.assertNotNull(list57);
//    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        java.lang.Object obj18 = null;
//        boolean boolean19 = day13.equals(obj18);
//        long long20 = day13.getSerialIndex();
//        long long21 = day13.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day13.previous();
//        int int23 = day13.getMonth();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 43629L + "'", long20 == 43629L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560409200000L + "'", long21 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        boolean boolean6 = day4.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate7 = day4.getSerialDate();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        boolean boolean10 = day8.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate11 = day8.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate12 = serialDate7.getEndOfCurrentMonth(serialDate11);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        boolean boolean16 = day14.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate17 = day14.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate17);
//        java.lang.String str19 = serialDate17.toString();
//        org.jfree.data.time.SerialDate serialDate20 = serialDate12.getEndOfCurrentMonth(serialDate17);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        boolean boolean23 = day21.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate24 = day21.getSerialDate();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        boolean boolean27 = day25.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate29 = serialDate24.getEndOfCurrentMonth(serialDate28);
//        boolean boolean31 = spreadsheetDate3.isInRange(serialDate17, serialDate29, 2019);
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addDays((-460), serialDate29);
//        try {
//            org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(2958465, serialDate32);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "13-June-2019" + "'", str19.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(serialDate32);
//    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test478");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.lang.String str6 = day5.toString();
//        java.lang.Number number7 = timeSeries4.getValue((org.jfree.data.time.RegularTimePeriod) day5);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.lang.String str14 = day13.toString();
//        java.lang.Number number15 = timeSeries12.getValue((org.jfree.data.time.RegularTimePeriod) day13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day13, (double) 10.0f);
//        int int18 = day13.getYear();
//        org.jfree.data.time.SerialDate serialDate19 = day13.getSerialDate();
//        java.lang.String str20 = day13.toString();
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number7);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13-June-2019" + "'", str20.equals("13-June-2019"));
//    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 3);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        int int5 = month2.getYearValue();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "December 3" + "'", str3.equals("December 3"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(12, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "December" + "'", str2.equals("December"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.lang.Class class1 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0d, class1);
        java.lang.Object obj3 = timeSeries2.clone();
        java.lang.String str4 = timeSeries2.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries2.removePropertyChangeListener(propertyChangeListener5);
        timeSeries2.setDomainDescription("");
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Value" + "'", str4.equals("Value"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Sunday");
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("ThreadContext");
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
//        java.lang.String str7 = timeSeries4.getRangeDescription();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        boolean boolean12 = day10.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) day8, (org.jfree.data.time.RegularTimePeriod) day10);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class17);
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries4.addAndOrUpdate(timeSeries18);
//        timeSeries19.setDomainDescription("");
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertNotNull(timeSeries19);
//    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(12, 3);
        java.lang.String str3 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        int int5 = month2.getYearValue();
        long long6 = month2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "December 3" + "'", str3.equals("December 3"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62041132800001L) + "'", long6 == (-62041132800001L));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100, 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test487() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test487");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        boolean boolean5 = day3.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        boolean boolean9 = day7.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate10 = day7.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate11 = serialDate6.getEndOfCurrentMonth(serialDate10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        boolean boolean15 = day13.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate16);
//        java.lang.String str18 = serialDate16.toString();
//        org.jfree.data.time.SerialDate serialDate19 = serialDate11.getEndOfCurrentMonth(serialDate16);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        boolean boolean22 = day20.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate23 = day20.getSerialDate();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        boolean boolean26 = day24.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate27 = day24.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate28 = serialDate23.getEndOfCurrentMonth(serialDate27);
//        boolean boolean30 = spreadsheetDate2.isInRange(serialDate16, serialDate28, 2019);
//        try {
//            org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addMonths((-460), (org.jfree.data.time.SerialDate) spreadsheetDate2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "13-June-2019" + "'", str18.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class4);
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timeSeries5.addPropertyChangeListener(propertyChangeListener6);
//        java.lang.String str8 = timeSeries5.getRangeDescription();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        boolean boolean13 = day11.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) day9, (org.jfree.data.time.RegularTimePeriod) day11);
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class18);
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries5.addAndOrUpdate(timeSeries19);
//        timeSeries19.setDescription("30-June-2019");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        boolean boolean27 = day25.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate28 = day25.getSerialDate();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        boolean boolean31 = day29.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate32 = day29.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate33 = serialDate28.getEndOfCurrentMonth(serialDate32);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        boolean boolean37 = day35.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate38 = day35.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate38);
//        java.lang.String str40 = serialDate38.toString();
//        org.jfree.data.time.SerialDate serialDate41 = serialDate33.getEndOfCurrentMonth(serialDate38);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        boolean boolean44 = day42.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate45 = day42.getSerialDate();
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        boolean boolean48 = day46.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate49 = day46.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate50 = serialDate45.getEndOfCurrentMonth(serialDate49);
//        boolean boolean52 = spreadsheetDate24.isInRange(serialDate38, serialDate50, 2019);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        boolean boolean55 = day53.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate56 = day53.getSerialDate();
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
//        boolean boolean59 = day57.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate60 = day57.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate61 = serialDate56.getEndOfCurrentMonth(serialDate60);
//        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
//        boolean boolean65 = day63.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate66 = day63.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate66);
//        java.lang.String str68 = serialDate66.toString();
//        org.jfree.data.time.SerialDate serialDate69 = serialDate61.getEndOfCurrentMonth(serialDate66);
//        boolean boolean70 = spreadsheetDate24.isOn(serialDate69);
//        timeSeries19.setKey((java.lang.Comparable) serialDate69);
//        java.lang.String str72 = serialDate69.getDescription();
//        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.addDays(6, serialDate69);
//        try {
//            org.jfree.data.time.SerialDate serialDate75 = serialDate69.getNearestDayOfWeek(11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "13-June-2019" + "'", str10.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "13-June-2019" + "'", str40.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "13-June-2019" + "'", str68.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate69);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertNull(str72);
//        org.junit.Assert.assertNotNull(serialDate73);
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        timeSeries4.setRangeDescription("hi!");
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries4.removeChangeListener(seriesChangeListener8);
        int int10 = timeSeries4.getMaximumItemCount();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        try {
            timeSeries4.update((org.jfree.data.time.RegularTimePeriod) year11, (java.lang.Number) 1577865599999L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.lang.String str8 = day7.toString();
//        java.lang.Number number9 = timeSeries6.getValue((org.jfree.data.time.RegularTimePeriod) day7);
//        org.jfree.data.time.SerialDate serialDate10 = day7.getSerialDate();
//        int int11 = spreadsheetDate1.compare(serialDate10);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-41610) + "'", int11 == (-41610));
//    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year7);
        java.lang.Object obj10 = null;
        boolean boolean11 = year7.equals(obj10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) 2019L);
        java.util.Calendar calendar14 = null;
        try {
            year7.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test492");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        int int4 = day2.getYear();
//        java.lang.String str5 = day2.toString();
//        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) str5);
//        long long7 = fixedMillisecond1.getMiddleMillisecond();
//        long long8 = fixedMillisecond1.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 5L + "'", long7 == 5L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 5L + "'", long8 == 5L);
//    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, (-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) year7);
        java.lang.Object obj10 = null;
        boolean boolean11 = year7.equals(obj10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (double) 2019L);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month14.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month14.next();
        boolean boolean17 = timeSeriesDataItem13.equals((java.lang.Object) regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 5);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.String str3 = day2.toString();
//        int int4 = day2.getYear();
//        java.lang.String str5 = day2.toString();
//        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) str5);
//        java.util.Date date7 = fixedMillisecond1.getTime();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        boolean boolean14 = day12.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate15);
//        java.lang.Class<?> wildcardClass17 = serialDate15.getClass();
//        java.lang.Class class23 = null;
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class23);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        java.lang.String str26 = day25.toString();
//        java.lang.Number number27 = timeSeries24.getValue((org.jfree.data.time.RegularTimePeriod) day25);
//        java.lang.Class class31 = null;
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
//        java.lang.String str34 = day33.toString();
//        java.lang.Number number35 = timeSeries32.getValue((org.jfree.data.time.RegularTimePeriod) day33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries24.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day33, (double) 10.0f);
//        java.lang.Object obj38 = null;
//        boolean boolean39 = day33.equals(obj38);
//        java.util.Date date40 = day33.getStart();
//        java.lang.Class<?> wildcardClass41 = day33.getClass();
//        java.io.InputStream inputStream42 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", (java.lang.Class) wildcardClass41);
//        java.net.URL uRL43 = org.jfree.chart.util.ObjectUtilities.getResource("30-June-2019", (java.lang.Class) wildcardClass41);
//        java.lang.Object obj44 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", (java.lang.Class) wildcardClass17, (java.lang.Class) wildcardClass41);
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date7, "ERROR : Relative To String", "December 3", (java.lang.Class) wildcardClass41);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        java.lang.String str47 = day46.toString();
//        java.lang.Object obj48 = null;
//        boolean boolean49 = day46.equals(obj48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = null;
//        try {
//            org.jfree.data.time.TimeSeries timeSeries51 = timeSeries45.createCopy((org.jfree.data.time.RegularTimePeriod) day46, regularTimePeriod50);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "13-June-2019" + "'", str26.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number27);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "13-June-2019" + "'", str34.equals("13-June-2019"));
//        org.junit.Assert.assertNull(number35);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(inputStream42);
//        org.junit.Assert.assertNull(uRL43);
//        org.junit.Assert.assertNull(obj44);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "13-June-2019" + "'", str47.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        timeSeries4.setRangeDescription("hi!");
        timeSeries4.setRangeDescription("");
        boolean boolean9 = timeSeries4.isEmpty();
        java.lang.Comparable comparable10 = timeSeries4.getKey();
        long long11 = timeSeries4.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 10.0d + "'", comparable10.equals(10.0d));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Thursday");
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class3);
        timeSeries4.setRangeDescription("hi!");
        java.lang.Class class7 = timeSeries4.getTimePeriodClass();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries4.removeChangeListener(seriesChangeListener8);
        int int10 = timeSeries4.getMaximumItemCount();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries4.getTimePeriod(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2958465, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test499");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(1900);
//        java.lang.Class class5 = null;
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries6.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.String str9 = timeSeries6.getRangeDescription();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.lang.String str11 = day10.toString();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        boolean boolean14 = day12.equals((java.lang.Object) 1);
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) day10, (org.jfree.data.time.RegularTimePeriod) day12);
//        java.lang.Class class19 = null;
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "", class19);
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries6.addAndOrUpdate(timeSeries20);
//        timeSeries20.setDescription("30-June-2019");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate(10);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        boolean boolean28 = day26.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate29 = day26.getSerialDate();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        boolean boolean32 = day30.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate33 = day30.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate34 = serialDate29.getEndOfCurrentMonth(serialDate33);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        boolean boolean38 = day36.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate39 = day36.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate39);
//        java.lang.String str41 = serialDate39.toString();
//        org.jfree.data.time.SerialDate serialDate42 = serialDate34.getEndOfCurrentMonth(serialDate39);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        boolean boolean45 = day43.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate46 = day43.getSerialDate();
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        boolean boolean49 = day47.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate50 = day47.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate51 = serialDate46.getEndOfCurrentMonth(serialDate50);
//        boolean boolean53 = spreadsheetDate25.isInRange(serialDate39, serialDate51, 2019);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
//        boolean boolean56 = day54.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate57 = day54.getSerialDate();
//        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day();
//        boolean boolean60 = day58.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate61 = day58.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate62 = serialDate57.getEndOfCurrentMonth(serialDate61);
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
//        boolean boolean66 = day64.equals((java.lang.Object) 1);
//        org.jfree.data.time.SerialDate serialDate67 = day64.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.addYears((int) (short) 100, serialDate67);
//        java.lang.String str69 = serialDate67.toString();
//        org.jfree.data.time.SerialDate serialDate70 = serialDate62.getEndOfCurrentMonth(serialDate67);
//        boolean boolean71 = spreadsheetDate25.isOn(serialDate70);
//        timeSeries20.setKey((java.lang.Comparable) serialDate70);
//        try {
//            int int73 = spreadsheetDate1.compareTo((java.lang.Object) timeSeries20);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeries cannot be cast to org.jfree.data.time.SerialDate");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13-June-2019" + "'", str11.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "13-June-2019" + "'", str41.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(serialDate50);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "13-June-2019" + "'", str69.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate70);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(2019);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }
}

