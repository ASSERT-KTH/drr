import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot0.getDomainAxisEdge((int) (byte) 0);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        java.awt.Color color30 = java.awt.Color.PINK;
        java.awt.Color color31 = color30.brighter();
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color31);
        java.lang.String str33 = categoryPlot0.getNoDataMessage();
        float float34 = categoryPlot0.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNull(str33);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 1.0f + "'", float34 == 1.0f);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        xYPlot0.clearDomainAxes();
        boolean boolean13 = xYPlot0.isOutlineVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot0.getRangeAxisEdge(12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart24 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType25 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color23, jFreeChart24, chartChangeEventType25);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color23, stroke27);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart31 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType32 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color30, jFreeChart31, chartChangeEventType32);
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color30, stroke34);
        valueMarker28.setOutlineStroke(stroke34);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace38 = color37.getColorSpace();
        valueMarker28.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.text.TextAnchor textAnchor40 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker28.setLabelTextAnchor(textAnchor40);
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str43 = layer42.toString();
        boolean boolean45 = categoryPlot20.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker28, layer42, true);
        org.jfree.chart.util.Layer layer46 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean48 = xYPlot18.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker28, layer46, true);
        xYPlot18.setRangeGridlinesVisible(false);
        xYPlot18.setForegroundAlpha(0.0f);
        java.awt.geom.Point2D point2D53 = xYPlot18.getQuadrantOrigin();
        xYPlot0.zoomRangeAxes((double) '#', plotRenderingInfo17, point2D53, true);
        org.jfree.chart.plot.Plot plot56 = xYPlot0.getParent();
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D58 = null;
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        java.util.List list60 = null;
        xYPlot57.drawDomainTickBands(graphics2D58, rectangle2D59, list60);
        java.awt.Color color62 = java.awt.Color.yellow;
        xYPlot57.setRangeCrosshairPaint((java.awt.Paint) color62);
        java.awt.Color color64 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int65 = color64.getTransparency();
        xYPlot57.setDomainZeroBaselinePaint((java.awt.Paint) color64);
        org.jfree.chart.util.Layer layer68 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection69 = xYPlot57.getRangeMarkers((int) ' ', layer68);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder70 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        xYPlot57.setSeriesRenderingOrder(seriesRenderingOrder70);
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder70);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(colorSpace38);
        org.junit.Assert.assertNotNull(textAnchor40);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Layer.FOREGROUND" + "'", str43.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(layer46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(point2D53);
        org.junit.Assert.assertNull(plot56);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(layer68);
        org.junit.Assert.assertNull(collection69);
        org.junit.Assert.assertNotNull(seriesRenderingOrder70);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.awt.Color color1 = java.awt.Color.getColor("SeriesRenderingOrder.REVERSE");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.util.List list16 = null;
        xYPlot13.drawDomainTickBands(graphics2D14, rectangle2D15, list16);
        java.awt.Color color18 = java.awt.Color.yellow;
        xYPlot13.setRangeCrosshairPaint((java.awt.Paint) color18);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color18);
        double double21 = xYPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace22 = xYPlot0.getFixedDomainAxisSpace();
        java.awt.Paint paint24 = null;
        xYPlot0.setQuadrantPaint((int) (short) 1, paint24);
        xYPlot0.setRangeCrosshairValue(0.2d, false);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNull(axisSpace22);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.configure();
        boolean boolean3 = dateAxis1.isAutoRange();
        java.awt.Shape shape4 = dateAxis1.getLeftArrow();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = dateAxis1.java2DToValue((double) 0.0f, rectangle2D6, rectangleEdge7);
        dateAxis1.setRangeWithMargins((double) 2.0f, (double) 12);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart22 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color21, jFreeChart22, chartChangeEventType23);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color21, stroke25);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart29 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType30 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color28, jFreeChart29, chartChangeEventType30);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color28, stroke32);
        valueMarker26.setOutlineStroke(stroke32);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace36 = color35.getColorSpace();
        valueMarker26.setLabelPaint((java.awt.Paint) color35);
        org.jfree.chart.text.TextAnchor textAnchor38 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker26.setLabelTextAnchor(textAnchor38);
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str41 = layer40.toString();
        boolean boolean43 = categoryPlot18.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker26, layer40, true);
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean46 = xYPlot16.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker26, layer44, true);
        java.awt.Font font47 = xYPlot16.getNoDataMessageFont();
        xYPlot16.setDomainCrosshairValue(1.0d);
        java.awt.Color color50 = org.jfree.chart.ChartColor.DARK_YELLOW;
        xYPlot16.setNoDataMessagePaint((java.awt.Paint) color50);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = xYPlot16.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        try {
            org.jfree.chart.axis.AxisState axisState54 = dateAxis1.draw(graphics2D12, (double) 192, rectangle2D14, rectangle2D15, rectangleEdge52, plotRenderingInfo53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(colorSpace36);
        org.junit.Assert.assertNotNull(textAnchor38);
        org.junit.Assert.assertNotNull(layer40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Layer.FOREGROUND" + "'", str41.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(rectangleEdge52);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        int int3 = categoryPlot0.getRangeAxisCount();
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.util.List list11 = null;
        xYPlot8.drawDomainTickBands(graphics2D9, rectangle2D10, list11);
        boolean boolean13 = xYPlot8.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.IntervalMarker intervalMarker16 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke17 = intervalMarker16.getOutlineStroke();
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.util.List list21 = null;
        xYPlot18.drawDomainTickBands(graphics2D19, rectangle2D20, list21);
        org.jfree.chart.plot.IntervalMarker intervalMarker26 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer27 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot18.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker26, layer27, true);
        boolean boolean30 = xYPlot8.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker16, layer27);
        try {
            categoryPlot0.addDomainMarker((int) (byte) 10, categoryMarker7, layer27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(layer27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color2, color3, color4, color5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color7, color8, color9, color10 };
        java.awt.Paint[] paintArray12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke stroke15 = null;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        java.awt.Shape shape17 = null;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray14, strokeArray16, shapeArray18);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        org.jfree.data.general.DatasetGroup datasetGroup21 = categoryPlot0.getDatasetGroup();
        int int22 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.clearRangeMarkers((int) (short) 10);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        try {
            categoryPlot0.drawBackground(graphics2D25, rectangle2D26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNull(datasetGroup21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 15 + "'", int22 == 15);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        java.lang.Object obj4 = categoryPlot0.clone();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(obj4);
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        long long2 = day0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE", timeZone1);
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = dateAxis2.getStandardTickUnits();
        dateAxis2.setVisible(false);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.util.List list9 = null;
        xYPlot6.drawDomainTickBands(graphics2D7, rectangle2D8, list9);
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer15 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot6.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker14, layer15, true);
        java.util.List list18 = xYPlot6.getAnnotations();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart23 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType24 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color22, jFreeChart23, chartChangeEventType24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color22, stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart30 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType31 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent32 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color29, jFreeChart30, chartChangeEventType31);
        java.awt.Stroke stroke33 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color29, stroke33);
        valueMarker27.setOutlineStroke(stroke33);
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace37 = color36.getColorSpace();
        valueMarker27.setLabelPaint((java.awt.Paint) color36);
        org.jfree.chart.text.TextAnchor textAnchor39 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker27.setLabelTextAnchor(textAnchor39);
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str42 = layer41.toString();
        boolean boolean44 = categoryPlot19.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker27, layer41, true);
        org.jfree.chart.axis.AxisLocation axisLocation45 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot19.setRangeAxisLocation(axisLocation45);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = categoryPlot19.getDomainAxisForDataset(0);
        org.jfree.chart.axis.AxisLocation axisLocation49 = categoryPlot19.getRangeAxisLocation();
        xYPlot6.setRangeAxisLocation(axisLocation49);
        dateAxis2.addChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(tickUnitSource3);
        org.junit.Assert.assertNotNull(layer15);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(colorSpace37);
        org.junit.Assert.assertNotNull(textAnchor39);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Layer.FOREGROUND" + "'", str42.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNull(categoryAxis48);
        org.junit.Assert.assertNotNull(axisLocation49);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection27 = categoryPlot0.getRangeMarkers(layer26);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent28);
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        categoryPlot0.drawBackgroundImage(graphics2D30, rectangle2D31);
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace33, false);
        categoryPlot0.configureDomainAxes();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNotNull(collection27);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
//        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        org.jfree.chart.JFreeChart jFreeChart6 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
//        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
//        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        org.jfree.chart.JFreeChart jFreeChart13 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
//        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
//        valueMarker10.setOutlineStroke(stroke16);
//        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
//        valueMarker10.setLabelPaint((java.awt.Paint) color19);
//        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
//        valueMarker10.setLabelTextAnchor(textAnchor22);
//        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
//        java.lang.String str25 = layer24.toString();
//        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
//        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
//        java.util.Collection collection29 = categoryPlot2.getRangeMarkers(layer28);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
//        categoryPlot2.rendererChanged(rendererChangeEvent30);
//        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
//        categoryPlot2.setRangeAxisLocation(axisLocation32);
//        org.jfree.chart.axis.AxisLocation axisLocation34 = axisLocation32.getOpposite();
//        int int35 = day0.compareTo((java.lang.Object) axisLocation34);
//        java.lang.String str36 = day0.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day0.next();
//        java.util.Date date38 = day0.getEnd();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertNotNull(color5);
//        org.junit.Assert.assertNotNull(stroke9);
//        org.junit.Assert.assertNotNull(color12);
//        org.junit.Assert.assertNotNull(stroke16);
//        org.junit.Assert.assertNotNull(color19);
//        org.junit.Assert.assertNotNull(colorSpace20);
//        org.junit.Assert.assertNotNull(textAnchor22);
//        org.junit.Assert.assertNotNull(layer24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(layer28);
//        org.junit.Assert.assertNotNull(collection29);
//        org.junit.Assert.assertNotNull(axisLocation32);
//        org.junit.Assert.assertNotNull(axisLocation34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(date38);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        categoryAxis0.setLabelToolTip("hi!");
        categoryAxis0.clearCategoryLabelToolTips();
        double double5 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.plot.Plot plot6 = null;
        categoryAxis0.setPlot(plot6);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        boolean boolean2 = numberAxis1.getAutoRangeIncludesZero();
        java.awt.Shape shape3 = numberAxis1.getLeftArrow();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        java.awt.Color color27 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke29 = categoryAxis28.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color27, stroke29);
        categoryPlot0.setRangeGridlineStroke(stroke29);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone35 = dateAxis34.getTimeZone();
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = dateAxis34.java2DToValue((double) (short) 100, rectangle2D37, rectangleEdge38);
        dateAxis34.setLowerBound((double) (byte) 100);
        categoryPlot0.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis34, true);
        org.jfree.chart.axis.Timeline timeline44 = null;
        dateAxis34.setTimeline(timeline44);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 9.223372036854776E18d + "'", double39 == 9.223372036854776E18d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        java.awt.Color color27 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke29 = categoryAxis28.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color27, stroke29);
        categoryPlot0.setRangeGridlineStroke(stroke29);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone35 = dateAxis34.getTimeZone();
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = dateAxis34.java2DToValue((double) (short) 100, rectangle2D37, rectangleEdge38);
        dateAxis34.setLowerBound((double) (byte) 100);
        categoryPlot0.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis34, true);
        categoryPlot0.setAnchorValue((double) '4');
        categoryPlot0.setRangeCrosshairVisible(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent48 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent48);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 9.223372036854776E18d + "'", double39 == 9.223372036854776E18d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkOutsideLength((float) (byte) 100);
        categoryAxis0.setMaximumCategoryLabelLines((int) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color8, jFreeChart9, chartChangeEventType10);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color8, stroke12);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color15, jFreeChart16, chartChangeEventType17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color15, stroke19);
        valueMarker13.setOutlineStroke(stroke19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace23 = color22.getColorSpace();
        valueMarker13.setLabelPaint((java.awt.Paint) color22);
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker13.setLabelTextAnchor(textAnchor25);
        org.jfree.chart.util.Layer layer27 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str28 = layer27.toString();
        boolean boolean30 = categoryPlot5.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker13, layer27, true);
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection32 = categoryPlot5.getRangeMarkers(layer31);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = null;
        categoryPlot5.rendererChanged(rendererChangeEvent33);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot5.setRangeAxisLocation(axisLocation35);
        boolean boolean37 = categoryAxis0.equals((java.lang.Object) categoryPlot5);
        java.awt.Paint paint38 = categoryPlot5.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(colorSpace23);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNotNull(layer27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Layer.FOREGROUND" + "'", str28.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color2, color3, color4, color5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color7, color8, color9, color10 };
        java.awt.Paint[] paintArray12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke stroke15 = null;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        java.awt.Shape shape17 = null;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray14, strokeArray16, shapeArray18);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        categoryPlot0.setWeight((int) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot0.getDomainAxis();
        categoryPlot0.setWeight((-256));
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNull(categoryAxis23);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        boolean boolean2 = numberAxis1.getAutoRangeIncludesZero();
        double double3 = numberAxis1.getUpperBound();
        java.awt.Font font4 = numberAxis1.getTickLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis6.setNegativeArrowVisible(true);
        float float9 = dateAxis6.getTickMarkOutsideLength();
        dateAxis6.setAutoRangeMinimumSize((double) 1);
        boolean boolean12 = dateAxis6.isAxisLineVisible();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis14.configure();
        boolean boolean16 = dateAxis14.isAutoRange();
        org.jfree.data.time.DateRange dateRange17 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis14.setRangeWithMargins((org.jfree.data.Range) dateRange17);
        dateAxis6.setRange((org.jfree.data.Range) dateRange17, false, true);
        numberAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange17);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateRange17);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        categoryAxis0.setFixedDimension((double) 10.0f);
        boolean boolean4 = categoryAxis0.isTickMarksVisible();
        boolean boolean5 = categoryAxis0.isTickLabelsVisible();
        categoryAxis0.setCategoryMargin((double) 3);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke6 = intervalMarker5.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot7.getDomainAxis();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart12, chartChangeEventType13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke19 = categoryAxis18.getTickMarkStroke();
        categoryAxis18.setLabelToolTip("hi!");
        categoryAxis18.setLabel("");
        boolean boolean24 = layer17.equals((java.lang.Object) categoryAxis18);
        boolean boolean25 = categoryPlot7.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker16, layer17);
        boolean boolean26 = categoryPlot0.removeDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) intervalMarker5, layer17);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        int int30 = categoryPlot0.getIndexOf(categoryItemRenderer29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        categoryPlot0.setRenderer(categoryItemRenderer31, true);
        org.jfree.chart.util.SortOrder sortOrder34 = org.jfree.chart.util.SortOrder.DESCENDING;
        categoryPlot0.setColumnRenderingOrder(sortOrder34);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(sortOrder34);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        double double4 = rectangleInsets2.calculateBottomInset((double) 1);
        double double6 = rectangleInsets2.trimHeight((double) (-1));
        double double8 = rectangleInsets2.calculateBottomInset((double) 'a');
        double double9 = rectangleInsets2.getLeft();
        double double11 = rectangleInsets2.calculateBottomInset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-7.0d) + "'", double6 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        xYPlot0.clearDomainAxes();
        boolean boolean13 = xYPlot0.isOutlineVisible();
        double double14 = xYPlot0.getRangeCrosshairValue();
        xYPlot0.mapDatasetToRangeAxis(13, 1);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            xYPlot0.drawOutline(graphics2D18, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection27 = categoryPlot0.getRangeMarkers(layer26);
        categoryPlot0.clearAnnotations();
        java.awt.Stroke stroke29 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke29);
        java.util.List list31 = categoryPlot0.getCategories();
        org.jfree.chart.plot.Plot plot32 = categoryPlot0.getParent();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(list31);
        org.junit.Assert.assertNull(plot32);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation26);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = categoryPlot0.getDomainAxisForDataset(0);
        org.jfree.data.general.DatasetGroup datasetGroup30 = categoryPlot0.getDatasetGroup();
        java.util.List list31 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace32);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNull(categoryAxis29);
        org.junit.Assert.assertNull(datasetGroup30);
        org.junit.Assert.assertNotNull(list31);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        java.awt.Color color5 = java.awt.Color.yellow;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int8 = color7.getTransparency();
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color7);
        org.jfree.chart.util.Layer layer11 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection12 = xYPlot0.getRangeMarkers((int) ' ', layer11);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder13 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder13);
        java.awt.Color color15 = java.awt.Color.GRAY;
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color15);
        int int17 = color15.getRed();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(layer11);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(seriesRenderingOrder13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 128 + "'", int17 == 128);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        java.util.List list12 = xYPlot0.getAnnotations();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = categoryPlot13.getDomainAxis();
        java.awt.Paint paint16 = categoryPlot13.getBackgroundPaint();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color19 = java.awt.Color.WHITE;
        java.awt.Color color20 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray21 = new java.awt.Paint[] { color17, color18, color19, color20 };
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray26 = new java.awt.Paint[] { color22, color23, color24, color25 };
        java.awt.Paint[] paintArray27 = null;
        java.awt.Stroke stroke28 = null;
        java.awt.Stroke[] strokeArray29 = new java.awt.Stroke[] { stroke28 };
        java.awt.Stroke stroke30 = null;
        java.awt.Stroke[] strokeArray31 = new java.awt.Stroke[] { stroke30 };
        java.awt.Shape shape32 = null;
        java.awt.Shape[] shapeArray33 = new java.awt.Shape[] { shape32 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier34 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray21, paintArray26, paintArray27, strokeArray29, strokeArray31, shapeArray33);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart39 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType40 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent41 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color38, jFreeChart39, chartChangeEventType40);
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color38, stroke42);
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart46 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType47 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent48 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color45, jFreeChart46, chartChangeEventType47);
        java.awt.Stroke stroke49 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker50 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color45, stroke49);
        valueMarker43.setOutlineStroke(stroke49);
        java.awt.Color color52 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace53 = color52.getColorSpace();
        valueMarker43.setLabelPaint((java.awt.Paint) color52);
        org.jfree.chart.text.TextAnchor textAnchor55 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker43.setLabelTextAnchor(textAnchor55);
        org.jfree.chart.util.Layer layer57 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str58 = layer57.toString();
        boolean boolean60 = categoryPlot35.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker43, layer57, true);
        org.jfree.chart.axis.AxisLocation axisLocation61 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot35.setRangeAxisLocation(axisLocation61);
        boolean boolean63 = defaultDrawingSupplier34.equals((java.lang.Object) axisLocation61);
        categoryPlot13.setRangeAxisLocation(axisLocation61, true);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent66 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot13);
        xYPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot13);
        org.jfree.chart.axis.AxisLocation axisLocation69 = null;
        try {
            categoryPlot13.setRangeAxisLocation((int) (byte) -1, axisLocation69, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNull(categoryAxis15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(paintArray26);
        org.junit.Assert.assertNotNull(strokeArray29);
        org.junit.Assert.assertNotNull(strokeArray31);
        org.junit.Assert.assertNotNull(shapeArray33);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(colorSpace53);
        org.junit.Assert.assertNotNull(textAnchor55);
        org.junit.Assert.assertNotNull(layer57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "Layer.FOREGROUND" + "'", str58.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(axisLocation61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand1 = numberAxis0.getMarkerBand();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = numberAxis0.getMarkerBand();
        numberAxis0.setLabelAngle((double) 5);
        org.junit.Assert.assertNull(markerAxisBand1);
        org.junit.Assert.assertNull(markerAxisBand2);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        float float3 = intervalMarker2.getAlpha();
        intervalMarker2.setStartValue((double) (-1L));
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = intervalMarker2.getLabelOffset();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot7.getFixedDomainAxisSpace();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color11 = java.awt.Color.WHITE;
        java.awt.Color color12 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color9, color10, color11, color12 };
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { color14, color15, color16, color17 };
        java.awt.Paint[] paintArray19 = null;
        java.awt.Stroke stroke20 = null;
        java.awt.Stroke[] strokeArray21 = new java.awt.Stroke[] { stroke20 };
        java.awt.Stroke stroke22 = null;
        java.awt.Stroke[] strokeArray23 = new java.awt.Stroke[] { stroke22 };
        java.awt.Shape shape24 = null;
        java.awt.Shape[] shapeArray25 = new java.awt.Shape[] { shape24 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier26 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray13, paintArray18, paintArray19, strokeArray21, strokeArray23, shapeArray25);
        categoryPlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier26);
        categoryPlot7.setWeight((int) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = categoryPlot7.getDomainAxisForDataset(3);
        java.awt.Stroke stroke32 = categoryPlot7.getRangeGridlineStroke();
        intervalMarker2.setStroke(stroke32);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.8f + "'", float3 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(strokeArray21);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertNotNull(shapeArray25);
        org.junit.Assert.assertNull(categoryAxis31);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation26);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis31);
        dateAxis31.setAutoTickUnitSelection(false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(axisLocation26);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        xYPlot0.setRangeGridlinesVisible(false);
        java.awt.Stroke stroke33 = xYPlot0.getDomainGridlineStroke();
        java.awt.Stroke stroke34 = xYPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.setNegativeArrowVisible(true);
        float float4 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setAutoRangeMinimumSize((double) 1);
        boolean boolean7 = dateAxis1.isAxisLineVisible();
        dateAxis1.setLowerBound(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        dateAxis1.setTickLabelInsets(rectangleInsets10);
        double double12 = rectangleInsets10.getLeft();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 8.0d + "'", double12 == 8.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        java.awt.Color color27 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke29 = categoryAxis28.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color27, stroke29);
        categoryPlot0.setRangeGridlineStroke(stroke29);
        java.awt.Color color33 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke35 = categoryAxis34.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color33, stroke35);
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean38 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker36, layer37);
        org.jfree.chart.text.TextAnchor textAnchor39 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        valueMarker36.setLabelTextAnchor(textAnchor39);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(textAnchor39);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        java.awt.Color color27 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke29 = categoryAxis28.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color27, stroke29);
        categoryPlot0.setRangeGridlineStroke(stroke29);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke32);
        categoryPlot0.setRangeCrosshairValue((double) 64, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke38 = categoryAxis37.getTickMarkStroke();
        categoryAxis37.setFixedDimension((double) 10.0f);
        boolean boolean41 = categoryAxis37.isTickMarksVisible();
        categoryAxis37.setTickMarksVisible(true);
        categoryAxis37.setTickMarkInsideLength((float) 1);
        categoryPlot0.setDomainAxis(categoryAxis37);
        categoryAxis37.setMaximumCategoryLabelLines(1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis(128);
        boolean boolean4 = categoryPlot0.isDomainGridlinesVisible();
        java.awt.Paint paint5 = categoryPlot0.getOutlinePaint();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        int int3 = categoryPlot0.getRangeAxisCount();
        categoryPlot0.setDomainGridlinesVisible(false);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        boolean boolean10 = categoryPlot0.render(graphics2D6, rectangle2D7, 11, plotRenderingInfo9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke13 = categoryAxis12.getTickMarkStroke();
        float float14 = categoryAxis12.getTickMarkOutsideLength();
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis12.setLabelFont(font15);
        double double17 = categoryAxis12.getCategoryMargin();
        categoryPlot0.setDomainAxis((int) (byte) 1, categoryAxis12);
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 2.0f + "'", float14 == 2.0f);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent26 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker8);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = valueMarker8.getLabelAnchor();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace29 = color28.getColorSpace();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent30 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color28);
        boolean boolean31 = rectangleAnchor27.equals((java.lang.Object) chartChangeEvent30);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(colorSpace29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setLabelToolTip("hi!");
        categoryAxis1.setLabel("");
        boolean boolean7 = layer0.equals((java.lang.Object) categoryAxis1);
        categoryAxis1.setLowerMargin((double) 0L);
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis(128);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset5 = categoryPlot0.getDataset();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNull(categoryDataset5);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        float float2 = categoryAxis0.getTickMarkOutsideLength();
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis0.setLabelFont(font3);
        double double5 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis0.getLabelInsets();
        java.lang.String str7 = rectangleInsets6.toString();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str7.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        xYPlot0.clearDomainAxes();
        boolean boolean13 = xYPlot0.isOutlineVisible();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder16 = xYPlot0.getDatasetRenderingOrder();
        java.lang.String str17 = datasetRenderingOrder16.toString();
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str17.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke6 = intervalMarker5.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot7.getDomainAxis();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart12, chartChangeEventType13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke19 = categoryAxis18.getTickMarkStroke();
        categoryAxis18.setLabelToolTip("hi!");
        categoryAxis18.setLabel("");
        boolean boolean24 = layer17.equals((java.lang.Object) categoryAxis18);
        boolean boolean25 = categoryPlot7.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker16, layer17);
        boolean boolean26 = categoryPlot0.removeDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) intervalMarker5, layer17);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        int int30 = categoryPlot0.getIndexOf(categoryItemRenderer29);
        java.awt.Paint paint31 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.setNegativeArrowVisible(true);
        float float4 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setAutoRangeMinimumSize((double) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color17, jFreeChart18, chartChangeEventType19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color17, stroke21);
        valueMarker15.setOutlineStroke(stroke21);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace25 = color24.getColorSpace();
        valueMarker15.setLabelPaint((java.awt.Paint) color24);
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker15.setLabelTextAnchor(textAnchor27);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str30 = layer29.toString();
        boolean boolean32 = categoryPlot7.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker15, layer29, true);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        categoryPlot7.clearRangeMarkers();
        org.jfree.chart.plot.Plot plot35 = categoryPlot7.getRootPlot();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(colorSpace25);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Layer.FOREGROUND" + "'", str30.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(plot35);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        java.awt.Color color27 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke29 = categoryAxis28.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color27, stroke29);
        categoryPlot0.setRangeGridlineStroke(stroke29);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke32);
        categoryPlot0.setRangeCrosshairValue((double) 64, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke38 = categoryAxis37.getTickMarkStroke();
        categoryAxis37.setFixedDimension((double) 10.0f);
        boolean boolean41 = categoryAxis37.isTickMarksVisible();
        categoryAxis37.setTickMarksVisible(true);
        categoryAxis37.setTickMarkInsideLength((float) 1);
        categoryPlot0.setDomainAxis(categoryAxis37);
        boolean boolean47 = categoryAxis37.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        xYPlot0.clearDomainAxes();
        boolean boolean13 = xYPlot0.isOutlineVisible();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder16 = xYPlot0.getDatasetRenderingOrder();
        java.awt.Stroke stroke17 = xYPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation26);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        int int30 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis32 = categoryPlot0.getRangeAxisForDataset(0);
        categoryPlot0.clearRangeAxes();
        categoryPlot0.clearAnnotations();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNull(valueAxis32);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke6 = intervalMarker5.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot7.getDomainAxis();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart12, chartChangeEventType13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke19 = categoryAxis18.getTickMarkStroke();
        categoryAxis18.setLabelToolTip("hi!");
        categoryAxis18.setLabel("");
        boolean boolean24 = layer17.equals((java.lang.Object) categoryAxis18);
        boolean boolean25 = categoryPlot7.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker16, layer17);
        boolean boolean26 = categoryPlot0.removeDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) intervalMarker5, layer17);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        int int30 = categoryPlot0.getIndexOf(categoryItemRenderer29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        categoryPlot0.setRenderer(categoryItemRenderer31, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        categoryPlot0.setRenderer(categoryItemRenderer34, false);
        java.util.List list37 = categoryPlot0.getCategories();
        org.jfree.chart.axis.ValueAxis valueAxis38 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNull(list37);
        org.junit.Assert.assertNull(valueAxis38);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker8);
        boolean boolean10 = datasetRenderingOrder0.equals((java.lang.Object) valueMarker8);
        java.lang.Object obj11 = null;
        boolean boolean12 = datasetRenderingOrder0.equals(obj11);
        java.lang.String str13 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str1.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str13.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getRangeAxis(1);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        xYPlot0.notifyListeners(plotChangeEvent7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        xYPlot0.datasetChanged(datasetChangeEvent9);
        xYPlot0.setRangeCrosshairValue(0.0d);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        java.awt.Paint paint3 = xYPlot0.getRangeGridlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot4.getRangeAxis(128);
        java.awt.Stroke stroke8 = categoryPlot4.getDomainGridlineStroke();
        xYPlot0.setDomainZeroBaselineStroke(stroke8);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(stroke8);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
//        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
//        float float2 = categoryAxis0.getTickMarkOutsideLength();
//        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
//        categoryAxis0.setLabelFont(font3);
//        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = categoryAxis0.getCategoryLabelPositions();
//        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
//        java.awt.geom.Rectangle2D rectangle2D9 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
//        double double11 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor6, (int) (short) 0, (int) ' ', rectangle2D9, rectangleEdge10);
//        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
//        dateAxis14.configure();
//        boolean boolean16 = dateAxis14.isAutoRange();
//        java.awt.Shape shape17 = dateAxis14.getLeftArrow();
//        java.awt.geom.Rectangle2D rectangle2D19 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
//        double double21 = dateAxis14.java2DToValue((double) 0.0f, rectangle2D19, rectangleEdge20);
//        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
//        java.util.TimeZone timeZone24 = dateAxis23.getTimeZone();
//        dateAxis14.setTimeZone(timeZone24);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date12, timeZone24);
//        java.lang.String str27 = day26.toString();
//        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) day26);
//        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
//        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        org.jfree.chart.JFreeChart jFreeChart33 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType34 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent35 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color32, jFreeChart33, chartChangeEventType34);
//        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color32, stroke36);
//        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        org.jfree.chart.JFreeChart jFreeChart40 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType41 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent42 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color39, jFreeChart40, chartChangeEventType41);
//        java.awt.Stroke stroke43 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color39, stroke43);
//        valueMarker37.setOutlineStroke(stroke43);
//        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        java.awt.color.ColorSpace colorSpace47 = color46.getColorSpace();
//        valueMarker37.setLabelPaint((java.awt.Paint) color46);
//        org.jfree.chart.text.TextAnchor textAnchor49 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
//        valueMarker37.setLabelTextAnchor(textAnchor49);
//        org.jfree.chart.util.Layer layer51 = org.jfree.chart.util.Layer.FOREGROUND;
//        java.lang.String str52 = layer51.toString();
//        boolean boolean54 = categoryPlot29.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker37, layer51, true);
//        org.jfree.chart.util.Layer layer55 = org.jfree.chart.util.Layer.BACKGROUND;
//        java.util.Collection collection56 = categoryPlot29.getRangeMarkers(layer55);
//        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot29.getLegendItems();
//        java.awt.Paint paint58 = categoryPlot29.getRangeCrosshairPaint();
//        boolean boolean59 = day26.equals((java.lang.Object) categoryPlot29);
//        org.junit.Assert.assertNotNull(stroke1);
//        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
//        org.junit.Assert.assertNotNull(font3);
//        org.junit.Assert.assertNotNull(categoryLabelPositions5);
//        org.junit.Assert.assertNotNull(categoryAnchor6);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(shape17);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "13-June-2019" + "'", str27.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(color32);
//        org.junit.Assert.assertNotNull(stroke36);
//        org.junit.Assert.assertNotNull(color39);
//        org.junit.Assert.assertNotNull(stroke43);
//        org.junit.Assert.assertNotNull(color46);
//        org.junit.Assert.assertNotNull(colorSpace47);
//        org.junit.Assert.assertNotNull(textAnchor49);
//        org.junit.Assert.assertNotNull(layer51);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Layer.FOREGROUND" + "'", str52.equals("Layer.FOREGROUND"));
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(layer55);
//        org.junit.Assert.assertNotNull(collection56);
//        org.junit.Assert.assertNotNull(legendItemCollection57);
//        org.junit.Assert.assertNotNull(paint58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.setNegativeArrowVisible(true);
        float float4 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setAutoRangeMinimumSize((double) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color17, jFreeChart18, chartChangeEventType19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color17, stroke21);
        valueMarker15.setOutlineStroke(stroke21);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace25 = color24.getColorSpace();
        valueMarker15.setLabelPaint((java.awt.Paint) color24);
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker15.setLabelTextAnchor(textAnchor27);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str30 = layer29.toString();
        boolean boolean32 = categoryPlot7.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker15, layer29, true);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        categoryPlot7.clearRangeMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        boolean boolean37 = numberAxis36.getAutoRangeIncludesZero();
        org.jfree.data.Range range38 = categoryPlot7.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis36);
        org.jfree.data.RangeType rangeType39 = numberAxis36.getRangeType();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(colorSpace25);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Layer.FOREGROUND" + "'", str30.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(range38);
        org.junit.Assert.assertNotNull(rangeType39);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        java.awt.Color color9 = java.awt.Color.red;
        float[] floatArray14 = new float[] { 100L, 10.0f, (-1), 0L };
        float[] floatArray15 = color9.getComponents(floatArray14);
        float[] floatArray16 = java.awt.Color.RGBtoHSB(100, (int) ' ', 0, floatArray14);
        float[] floatArray17 = color3.getComponents(colorSpace5, floatArray14);
        float[] floatArray18 = color0.getColorComponents(floatArray14);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot0.getRangeAxisEdge((int) (short) 0);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        xYPlot0.notifyListeners(plotChangeEvent7);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = xYPlot0.getRenderer((int) (byte) -1);
        xYPlot0.setDomainCrosshairValue((double) '#');
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(xYItemRenderer10);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        categoryPlot0.setAnchorValue((double) 0, true);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = dateAxis10.getLabelInsets();
        double double13 = rectangleInsets11.calculateBottomInset((double) 1);
        double double15 = rectangleInsets11.trimHeight((double) (-1));
        org.jfree.chart.util.UnitType unitType16 = rectangleInsets11.getUnitType();
        double double18 = rectangleInsets11.calculateLeftOutset(0.0d);
        categoryPlot0.setAxisOffset(rectangleInsets11);
        double double21 = rectangleInsets11.calculateBottomInset(1.0d);
        double double22 = rectangleInsets11.getTop();
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.0d + "'", double13 == 3.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-7.0d) + "'", double15 == (-7.0d));
        org.junit.Assert.assertNotNull(unitType16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.0d + "'", double18 == 3.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 3.0d + "'", double22 == 3.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke6 = intervalMarker5.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot7.getDomainAxis();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart12, chartChangeEventType13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke19 = categoryAxis18.getTickMarkStroke();
        categoryAxis18.setLabelToolTip("hi!");
        categoryAxis18.setLabel("");
        boolean boolean24 = layer17.equals((java.lang.Object) categoryAxis18);
        boolean boolean25 = categoryPlot7.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker16, layer17);
        boolean boolean26 = categoryPlot0.removeDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) intervalMarker5, layer17);
        java.lang.String str27 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke29 = categoryAxis28.getTickMarkStroke();
        float float30 = categoryAxis28.getTickMarkOutsideLength();
        java.awt.Font font31 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis28.setLabelFont(font31);
        double double33 = categoryAxis28.getCategoryMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = categoryAxis28.getLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = categoryAxis28.getTickLabelInsets();
        categoryPlot0.setInsets(rectangleInsets35, true);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 2.0f + "'", float30 == 2.0f);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.2d + "'", double33 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(rectangleInsets35);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.util.List list16 = null;
        xYPlot13.drawDomainTickBands(graphics2D14, rectangle2D15, list16);
        java.awt.Color color18 = java.awt.Color.yellow;
        xYPlot13.setRangeCrosshairPaint((java.awt.Paint) color18);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color18);
        double double21 = xYPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot0.getRangeAxis((int) (byte) 0);
        org.jfree.chart.axis.ValueAxis valueAxis25 = xYPlot0.getRangeAxisForDataset((int) (byte) 0);
        boolean boolean26 = xYPlot0.isRangeZoomable();
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getRangeAxis(1);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        xYPlot0.notifyListeners(plotChangeEvent7);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis10.setNegativeArrowVisible(true);
        float float13 = dateAxis10.getTickMarkOutsideLength();
        dateAxis10.setAutoRangeMinimumSize((double) 1);
        boolean boolean16 = dateAxis10.isAxisLineVisible();
        dateAxis10.setRangeAboutValue((double) 10L, 0.05d);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis10);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart24 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType25 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color23, jFreeChart24, chartChangeEventType25);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color23, stroke27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) 11, (java.awt.Paint) color23, stroke29);
        dateAxis10.setAxisLineStroke(stroke29);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke33 = categoryAxis32.getTickMarkStroke();
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace36 = color35.getColorSpace();
        categoryAxis32.setTickLabelPaint((java.lang.Comparable) 1.0f, (java.awt.Paint) color35);
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis41.setNegativeArrowVisible(true);
        java.awt.Shape shape44 = dateAxis41.getUpArrow();
        java.awt.Shape shape45 = dateAxis41.getRightArrow();
        dateAxis39.setUpArrow(shape45);
        boolean boolean47 = color35.equals((java.lang.Object) shape45);
        dateAxis10.setUpArrow(shape45);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(colorSpace36);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        boolean boolean2 = numberAxis1.getAutoRangeIncludesZero();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = numberAxis1.getMarkerBand();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis5.configure();
        boolean boolean7 = dateAxis5.isAutoRange();
        org.jfree.data.time.DateRange dateRange8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange8);
        numberAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange8);
        org.jfree.data.RangeType rangeType11 = null;
        try {
            numberAxis1.setRangeType(rangeType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(markerAxisBand3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateRange8);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot0.getDomainAxisEdge((int) (byte) 0);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisLocation axisLocation31 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation((int) (byte) 0, axisLocation31, true);
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace34);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(axisLocation31);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        dateAxis1.setRange((double) (short) 0, (double) (short) 10);
        java.awt.Shape shape6 = dateAxis1.getDownArrow();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition7 = dateAxis1.getTickMarkPosition();
        dateAxis1.setAxisLineVisible(true);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(dateTickMarkPosition7);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        double double4 = rectangleInsets2.calculateBottomInset((double) 1);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color7, jFreeChart8, chartChangeEventType9);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke11);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker12);
        org.jfree.chart.text.TextAnchor textAnchor14 = valueMarker12.getLabelTextAnchor();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) valueMarker12);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = valueMarker12.getLabelOffsetType();
        java.awt.Color color18 = java.awt.Color.magenta;
        java.awt.Color color19 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        float[] floatArray20 = null;
        float[] floatArray21 = color19.getRGBComponents(floatArray20);
        float[] floatArray22 = color18.getRGBColorComponents(floatArray20);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        java.util.List list26 = null;
        xYPlot23.drawDomainTickBands(graphics2D24, rectangle2D25, list26);
        org.jfree.chart.plot.IntervalMarker intervalMarker31 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot23.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker31, layer32, true);
        java.util.List list35 = xYPlot23.getAnnotations();
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot23.setDomainCrosshairStroke(stroke36);
        org.jfree.chart.plot.CategoryMarker categoryMarker38 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0, (java.awt.Paint) color18, stroke36);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType39 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        categoryMarker38.setLabelOffsetType(lengthAdjustmentType39);
        try {
            java.awt.geom.Rectangle2D rectangle2D41 = rectangleInsets2.createAdjustedRectangle(rectangle2D5, lengthAdjustmentType16, lengthAdjustmentType39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(lengthAdjustmentType16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(lengthAdjustmentType39);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        categoryPlot0.setRenderer(categoryItemRenderer1);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace4 = categoryPlot3.getFixedDomainAxisSpace();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot3.getRangeAxis(128);
        java.awt.Stroke stroke7 = categoryPlot3.getDomainGridlineStroke();
        categoryPlot0.setDomainGridlineStroke(stroke7);
        org.junit.Assert.assertNull(axisSpace4);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(stroke7);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
//        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        org.jfree.chart.JFreeChart jFreeChart6 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
//        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
//        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        org.jfree.chart.JFreeChart jFreeChart13 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
//        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
//        valueMarker10.setOutlineStroke(stroke16);
//        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
//        valueMarker10.setLabelPaint((java.awt.Paint) color19);
//        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
//        valueMarker10.setLabelTextAnchor(textAnchor22);
//        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
//        java.lang.String str25 = layer24.toString();
//        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
//        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
//        java.util.Collection collection29 = categoryPlot2.getRangeMarkers(layer28);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
//        categoryPlot2.rendererChanged(rendererChangeEvent30);
//        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
//        categoryPlot2.setRangeAxisLocation(axisLocation32);
//        org.jfree.chart.axis.AxisLocation axisLocation34 = axisLocation32.getOpposite();
//        int int35 = day0.compareTo((java.lang.Object) axisLocation34);
//        java.lang.String str36 = day0.toString();
//        java.util.Date date37 = day0.getEnd();
//        long long38 = day0.getSerialIndex();
//        java.util.Date date39 = day0.getStart();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertNotNull(color5);
//        org.junit.Assert.assertNotNull(stroke9);
//        org.junit.Assert.assertNotNull(color12);
//        org.junit.Assert.assertNotNull(stroke16);
//        org.junit.Assert.assertNotNull(color19);
//        org.junit.Assert.assertNotNull(colorSpace20);
//        org.junit.Assert.assertNotNull(textAnchor22);
//        org.junit.Assert.assertNotNull(layer24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(layer28);
//        org.junit.Assert.assertNotNull(collection29);
//        org.junit.Assert.assertNotNull(axisLocation32);
//        org.junit.Assert.assertNotNull(axisLocation34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 43629L + "'", long38 == 43629L);
//        org.junit.Assert.assertNotNull(date39);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font2 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 4);
        double double3 = categoryAxis0.getUpperMargin();
        categoryAxis0.setCategoryMargin(0.0d);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat1 = numberAxis0.getNumberFormatOverride();
        numberAxis0.setLowerMargin((double) 11);
        org.junit.Assert.assertNull(numberFormat1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke3 = categoryAxis2.getTickMarkStroke();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart10 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType11 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color9, jFreeChart10, chartChangeEventType11);
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color9, stroke13);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart17 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType18 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color16, jFreeChart17, chartChangeEventType18);
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color16, stroke20);
        valueMarker14.setOutlineStroke(stroke20);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace24 = color23.getColorSpace();
        valueMarker14.setLabelPaint((java.awt.Paint) color23);
        org.jfree.chart.text.TextAnchor textAnchor26 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker14.setLabelTextAnchor(textAnchor26);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str29 = layer28.toString();
        boolean boolean31 = categoryPlot6.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker14, layer28, true);
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean34 = xYPlot4.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker14, layer32, true);
        org.jfree.chart.LegendItemCollection legendItemCollection35 = null;
        xYPlot4.setFixedLegendItems(legendItemCollection35);
        xYPlot4.setRangeCrosshairLockedOnData(false);
        boolean boolean39 = xYPlot4.isRangeCrosshairLockedOnData();
        java.awt.Paint paint41 = xYPlot4.getQuadrantPaint((int) (byte) 0);
        java.awt.Paint paint42 = xYPlot4.getBackgroundPaint();
        java.awt.Stroke stroke43 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, (java.awt.Paint) color1, stroke3, paint42, stroke43, (float) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(colorSpace24);
        org.junit.Assert.assertNotNull(textAnchor26);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Layer.FOREGROUND" + "'", str29.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(paint41);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        dateAxis1.setLowerBound((double) (-1L));
        dateAxis1.setRangeWithMargins((double) 11, (double) 64);
        dateAxis1.setLowerBound((double) (byte) 100);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone3 = dateAxis2.getTimeZone();
        dateAxis2.setRange((double) (short) 0, (double) (short) 10);
        boolean boolean8 = dateAxis2.isHiddenValue((long) 10);
        org.jfree.chart.plot.Plot plot9 = dateAxis2.getPlot();
        java.util.Date date10 = dateAxis2.getMaximumDate();
        org.jfree.data.Range range11 = dateAxis2.getDefaultAutoRange();
        double double12 = dateAxis2.getUpperBound();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = dateAxis14.getLabelInsets();
        dateAxis14.setLowerBound((double) (-1L));
        dateAxis14.setRangeWithMargins((double) 11, (double) 64);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer21);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(plot9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        dateAxis1.setNegativeArrowVisible(false);
        dateAxis1.setAutoTickUnitSelection(true, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis10.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font14 = categoryAxis12.getTickLabelFont((java.lang.Comparable) 4);
        dateAxis10.setTickLabelFont(font14);
        dateAxis1.setTickLabelFont(font14);
        dateAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis20.configure();
        boolean boolean22 = dateAxis20.isAutoRange();
        org.jfree.data.time.DateRange dateRange23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis20.setRangeWithMargins((org.jfree.data.Range) dateRange23);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition25 = dateAxis20.getTickMarkPosition();
        dateAxis1.setTickMarkPosition(dateTickMarkPosition25);
        java.util.Date date27 = dateAxis1.getMinimumDate();
        dateAxis1.setLabel("UnitType.RELATIVE");
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dateRange23);
        org.junit.Assert.assertNotNull(dateTickMarkPosition25);
        org.junit.Assert.assertNotNull(date27);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        xYPlot0.setRangeGridlinesVisible(false);
        xYPlot0.setForegroundAlpha(0.0f);
        java.awt.geom.Point2D point2D35 = xYPlot0.getQuadrantOrigin();
        java.awt.Paint paint36 = xYPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        java.awt.Color color5 = java.awt.Color.yellow;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int8 = color7.getTransparency();
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color7);
        org.jfree.chart.util.Layer layer11 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection12 = xYPlot0.getRangeMarkers((int) ' ', layer11);
        xYPlot0.configureDomainAxes();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(layer11);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        int int3 = categoryPlot0.getRangeAxisCount();
        categoryPlot0.setDomainGridlinesVisible(false);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        boolean boolean10 = categoryPlot0.render(graphics2D6, rectangle2D7, 11, plotRenderingInfo9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke13 = categoryAxis12.getTickMarkStroke();
        float float14 = categoryAxis12.getTickMarkOutsideLength();
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis12.setLabelFont(font15);
        double double17 = categoryAxis12.getCategoryMargin();
        categoryPlot0.setDomainAxis((int) (byte) 1, categoryAxis12);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke21 = categoryAxis20.getTickMarkStroke();
        float float22 = categoryAxis20.getTickMarkOutsideLength();
        categoryAxis20.setAxisLineVisible(true);
        categoryPlot0.setDomainAxis(8, categoryAxis20);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = categoryPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 2.0f + "'", float14 == 2.0f);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 2.0f + "'", float22 == 2.0f);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE", timeZone1);
        boolean boolean3 = dateAxis2.isNegativeArrowVisible();
        java.lang.Class class4 = null;
        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone8 = dateAxis7.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date5, timeZone8);
        dateAxis2.setMinimumDate(date5);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date5);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day11.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        int int3 = categoryPlot0.getRangeAxisCount();
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.util.List list11 = null;
        xYPlot8.drawDomainTickBands(graphics2D9, rectangle2D10, list11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart22 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color21, jFreeChart22, chartChangeEventType23);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color21, stroke25);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart29 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType30 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color28, jFreeChart29, chartChangeEventType30);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color28, stroke32);
        valueMarker26.setOutlineStroke(stroke32);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace36 = color35.getColorSpace();
        valueMarker26.setLabelPaint((java.awt.Paint) color35);
        org.jfree.chart.text.TextAnchor textAnchor38 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker26.setLabelTextAnchor(textAnchor38);
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str41 = layer40.toString();
        boolean boolean43 = categoryPlot18.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker26, layer40, true);
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean46 = xYPlot16.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker26, layer44, true);
        xYPlot16.setRangeGridlinesVisible(false);
        xYPlot16.setForegroundAlpha(0.0f);
        java.awt.geom.Point2D point2D51 = xYPlot16.getQuadrantOrigin();
        xYPlot8.zoomDomainAxes((double) '4', (double) 11, plotRenderingInfo15, point2D51);
        categoryPlot0.zoomDomainAxes((double) 2.0f, plotRenderingInfo7, point2D51);
        java.awt.Paint paint54 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent55 = null;
        categoryPlot0.notifyListeners(plotChangeEvent55);
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(colorSpace36);
        org.junit.Assert.assertNotNull(textAnchor38);
        org.junit.Assert.assertNotNull(layer40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Layer.FOREGROUND" + "'", str41.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(point2D51);
        org.junit.Assert.assertNotNull(paint54);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE", timeZone1);
        boolean boolean3 = dateAxis2.isNegativeArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis5.configure();
        boolean boolean7 = dateAxis5.isAutoRange();
        org.jfree.data.time.DateRange dateRange8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange8);
        dateAxis2.setRange((org.jfree.data.Range) dateRange8);
        dateAxis2.setRange((double) (short) 10, (double) 11);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart22 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color21, jFreeChart22, chartChangeEventType23);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color21, stroke25);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart29 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType30 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color28, jFreeChart29, chartChangeEventType30);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color28, stroke32);
        valueMarker26.setOutlineStroke(stroke32);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace36 = color35.getColorSpace();
        valueMarker26.setLabelPaint((java.awt.Paint) color35);
        org.jfree.chart.text.TextAnchor textAnchor38 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker26.setLabelTextAnchor(textAnchor38);
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str41 = layer40.toString();
        boolean boolean43 = categoryPlot18.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker26, layer40, true);
        org.jfree.chart.axis.AxisLocation axisLocation44 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot18.setRangeAxisLocation(axisLocation44);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = categoryPlot18.getDomainAxisForDataset(0);
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = categoryPlot18.getRendererForDataset(categoryDataset48);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = categoryPlot18.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        try {
            org.jfree.chart.axis.AxisState axisState52 = dateAxis2.draw(graphics2D14, (double) 3, rectangle2D16, rectangle2D17, rectangleEdge50, plotRenderingInfo51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateRange8);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(colorSpace36);
        org.junit.Assert.assertNotNull(textAnchor38);
        org.junit.Assert.assertNotNull(layer40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Layer.FOREGROUND" + "'", str41.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNull(categoryAxis47);
        org.junit.Assert.assertNull(categoryItemRenderer49);
        org.junit.Assert.assertNotNull(rectangleEdge50);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke3 = intervalMarker2.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = intervalMarker2.getLabelOffset();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        float float2 = categoryAxis0.getTickMarkOutsideLength();
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis0.setLabelFont(font3);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = categoryAxis0.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor6, (int) (short) 0, (int) ' ', rectangle2D9, rectangleEdge10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.util.List list15 = null;
        xYPlot12.drawDomainTickBands(graphics2D13, rectangle2D14, list15);
        java.awt.Color color17 = java.awt.Color.yellow;
        xYPlot12.setRangeCrosshairPaint((java.awt.Paint) color17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int20 = color19.getTransparency();
        xYPlot12.setDomainZeroBaselinePaint((java.awt.Paint) color19);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection24 = xYPlot12.getRangeMarkers((int) ' ', layer23);
        java.lang.Class<?> wildcardClass25 = xYPlot12.getClass();
        boolean boolean26 = categoryAnchor6.equals((java.lang.Object) xYPlot12);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        dateAxis1.setLowerMargin((double) (short) 0);
        boolean boolean5 = dateAxis1.isVisible();
        dateAxis1.setTickMarksVisible(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke9 = categoryAxis8.getTickMarkStroke();
        float float10 = categoryAxis8.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = dateAxis12.getLabelInsets();
        double double15 = rectangleInsets13.calculateBottomInset((double) 1);
        double double17 = rectangleInsets13.trimHeight((double) (-1));
        categoryAxis8.setLabelInsets(rectangleInsets13);
        org.jfree.chart.util.UnitType unitType19 = rectangleInsets13.getUnitType();
        dateAxis1.setTickLabelInsets(rectangleInsets13);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15 == 3.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-7.0d) + "'", double17 == (-7.0d));
        org.junit.Assert.assertNotNull(unitType19);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis(128);
        org.jfree.chart.plot.Marker marker4 = null;
        try {
            categoryPlot0.addRangeMarker(marker4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNull(valueAxis3);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        boolean boolean2 = numberAxis1.getAutoRangeIncludesZero();
        double double3 = numberAxis1.getUpperBound();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.util.List list7 = null;
        xYPlot4.drawDomainTickBands(graphics2D5, rectangle2D6, list7);
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot4.getRangeAxis(1);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent11 = null;
        xYPlot4.notifyListeners(plotChangeEvent11);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis14.setNegativeArrowVisible(true);
        float float17 = dateAxis14.getTickMarkOutsideLength();
        dateAxis14.setAutoRangeMinimumSize((double) 1);
        boolean boolean20 = dateAxis14.isAxisLineVisible();
        dateAxis14.setRangeAboutValue((double) 10L, 0.05d);
        xYPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis14);
        java.util.Date date25 = dateAxis14.getMinimumDate();
        org.jfree.chart.plot.IntervalMarker intervalMarker28 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        double double29 = intervalMarker28.getStartValue();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone32 = dateAxis31.getTimeZone();
        dateAxis31.setRange((double) (short) 0, (double) (short) 10);
        boolean boolean36 = intervalMarker28.equals((java.lang.Object) dateAxis31);
        java.util.TimeZone timeZone37 = dateAxis31.getTimeZone();
        dateAxis14.setTimeZone(timeZone37);
        boolean boolean39 = numberAxis1.equals((java.lang.Object) dateAxis14);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 2.0f + "'", float17 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 11.0d + "'", double29 == 11.0d);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke6 = intervalMarker5.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot7.getDomainAxis();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart12, chartChangeEventType13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke19 = categoryAxis18.getTickMarkStroke();
        categoryAxis18.setLabelToolTip("hi!");
        categoryAxis18.setLabel("");
        boolean boolean24 = layer17.equals((java.lang.Object) categoryAxis18);
        boolean boolean25 = categoryPlot7.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker16, layer17);
        boolean boolean26 = categoryPlot0.removeDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) intervalMarker5, layer17);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        int int30 = categoryPlot0.getIndexOf(categoryItemRenderer29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray32 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer31 };
        categoryPlot0.setRenderers(categoryItemRendererArray32);
        categoryPlot0.clearRangeAxes();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(categoryItemRendererArray32);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.setNegativeArrowVisible(true);
        dateAxis1.setTickLabelsVisible(false);
        float float6 = dateAxis1.getTickMarkOutsideLength();
        java.lang.Object obj7 = dateAxis1.clone();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        double double3 = intervalMarker2.getStartValue();
        intervalMarker2.setEndValue((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.0d + "'", double3 == 11.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace4 = color3.getColorSpace();
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) 1.0f, (java.awt.Paint) color3);
        categoryAxis0.setFixedDimension((double) (short) 1);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(colorSpace4);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        xYPlot0.clearDomainAxes();
        boolean boolean13 = xYPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace14);
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot0.getDomainAxis(5);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(valueAxis17);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        double double4 = rectangleInsets2.calculateBottomInset((double) 1);
        double double6 = rectangleInsets2.trimHeight((double) (-1));
        double double8 = rectangleInsets2.calculateBottomInset((double) 'a');
        double double10 = rectangleInsets2.trimWidth((double) (byte) 0);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            rectangleInsets2.trim(rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-7.0d) + "'", double6 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-6.0d) + "'", double10 == (-6.0d));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot0.getRangeAxisEdge((int) (short) 0);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        xYPlot0.notifyListeners(plotChangeEvent7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.util.List list12 = null;
        xYPlot9.drawDomainTickBands(graphics2D10, rectangle2D11, list12);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer18 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot9.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker17, layer18, true);
        java.util.List list21 = xYPlot9.getAnnotations();
        java.awt.Stroke stroke22 = xYPlot9.getDomainGridlineStroke();
        xYPlot0.setRangeZeroBaselineStroke(stroke22);
        xYPlot0.configureDomainAxes();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(layer18);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.lang.Comparable comparable0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color4, jFreeChart5, chartChangeEventType6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color4, stroke8);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart12, chartChangeEventType13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke15);
        valueMarker9.setOutlineStroke(stroke15);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace19 = color18.getColorSpace();
        valueMarker9.setLabelPaint((java.awt.Paint) color18);
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker9.setLabelTextAnchor(textAnchor21);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str24 = layer23.toString();
        boolean boolean26 = categoryPlot1.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker9, layer23, true);
        org.jfree.chart.util.Layer layer27 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection28 = categoryPlot1.getRangeMarkers(layer27);
        double double29 = categoryPlot1.getRangeCrosshairValue();
        org.jfree.chart.plot.Plot plot30 = categoryPlot1.getRootPlot();
        java.awt.Paint paint31 = categoryPlot1.getBackgroundPaint();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        java.util.List list35 = null;
        xYPlot32.drawDomainTickBands(graphics2D33, rectangle2D34, list35);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = xYPlot32.getRangeAxisEdge((int) (short) 0);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent39 = null;
        xYPlot32.notifyListeners(plotChangeEvent39);
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        java.util.List list44 = null;
        xYPlot41.drawDomainTickBands(graphics2D42, rectangle2D43, list44);
        org.jfree.chart.plot.IntervalMarker intervalMarker49 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer50 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot41.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker49, layer50, true);
        java.util.List list53 = xYPlot41.getAnnotations();
        java.awt.Stroke stroke54 = xYPlot41.getDomainGridlineStroke();
        xYPlot32.setRangeZeroBaselineStroke(stroke54);
        java.awt.Color color56 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.image.ColorModel colorModel57 = null;
        java.awt.Rectangle rectangle58 = null;
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        java.awt.geom.AffineTransform affineTransform60 = null;
        java.awt.RenderingHints renderingHints61 = null;
        java.awt.PaintContext paintContext62 = color56.createContext(colorModel57, rectangle58, rectangle2D59, affineTransform60, renderingHints61);
        java.awt.Stroke stroke63 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker65 = new org.jfree.chart.plot.CategoryMarker(comparable0, paint31, stroke54, (java.awt.Paint) color56, stroke63, (float) 192);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(colorSpace19);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Layer.FOREGROUND" + "'", str24.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(layer27);
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(plot30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(layer50);
        org.junit.Assert.assertNotNull(list53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(paintContext62);
        org.junit.Assert.assertNotNull(stroke63);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        categoryPlot0.setAnchorValue((double) 0, true);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.util.SortOrder sortOrder9 = categoryPlot0.getRowRenderingOrder();
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(sortOrder9);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        java.awt.Color color27 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke29 = categoryAxis28.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color27, stroke29);
        categoryPlot0.setRangeGridlineStroke(stroke29);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke32);
        int int34 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation26);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        int int30 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace31);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        categoryPlot0.setRenderer(categoryItemRenderer33, true);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        try {
            categoryPlot0.setDomainAxisLocation((-16777216), axisLocation37, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(axisLocation37);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset(10.0d);
        double double3 = rectangleInsets0.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        xYPlot0.setRangeGridlinesVisible(false);
        xYPlot0.setForegroundAlpha(0.0f);
        java.awt.geom.Point2D point2D35 = xYPlot0.getQuadrantOrigin();
        xYPlot0.setForegroundAlpha((float) (byte) 10);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone41 = dateAxis40.getTimeZone();
        dateAxis40.setRange((double) (short) 0, (double) (short) 10);
        boolean boolean46 = dateAxis40.isHiddenValue((long) 10);
        org.jfree.chart.plot.Plot plot47 = dateAxis40.getPlot();
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis40, false);
        xYPlot0.clearRangeMarkers(11);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(plot47);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        xYPlot0.clearDomainAxes();
        boolean boolean13 = xYPlot0.isOutlineVisible();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        boolean boolean16 = xYPlot0.isDomainCrosshairLockedOnData();
        xYPlot0.configureDomainAxes();
        java.awt.Paint paint18 = xYPlot0.getBackgroundPaint();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder19 = xYPlot0.getSeriesRenderingOrder();
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(seriesRenderingOrder19);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(2.0d, (double) '#');
        intervalMarker2.setEndValue((double) 128);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer5);
        java.lang.Object obj7 = intervalMarker2.clone();
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color1, jFreeChart2, chartChangeEventType3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke5);
        java.awt.Color color7 = color1.brighter();
        int int8 = color1.getTransparency();
        int int9 = color1.getGreen();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        java.awt.Paint paint31 = xYPlot0.getDomainCrosshairPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        try {
            xYPlot0.handleClick((int) 'a', 128, plotRenderingInfo34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke6 = intervalMarker5.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot7.getDomainAxis();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart12, chartChangeEventType13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke19 = categoryAxis18.getTickMarkStroke();
        categoryAxis18.setLabelToolTip("hi!");
        categoryAxis18.setLabel("");
        boolean boolean24 = layer17.equals((java.lang.Object) categoryAxis18);
        boolean boolean25 = categoryPlot7.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker16, layer17);
        boolean boolean26 = categoryPlot0.removeDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) intervalMarker5, layer17);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        int int30 = categoryPlot0.getIndexOf(categoryItemRenderer29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        categoryPlot0.setRenderer(categoryItemRenderer31, true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation34 = null;
        try {
            boolean boolean36 = categoryPlot0.removeAnnotation(categoryAnnotation34, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot0.getRangeAxisEdge((int) (short) 0);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        xYPlot0.notifyListeners(plotChangeEvent7);
        boolean boolean9 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int12 = color11.getTransparency();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke13);
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color11);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        java.awt.Color color27 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke29 = categoryAxis28.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color27, stroke29);
        categoryPlot0.setRangeGridlineStroke(stroke29);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke32);
        categoryPlot0.clearRangeMarkers(100);
        categoryPlot0.setRangeCrosshairVisible(true);
        categoryPlot0.clearRangeMarkers();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape1 = numberAxis0.getDownArrow();
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_RED;
        numberAxis0.setTickLabelPaint((java.awt.Paint) color2);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((-1.0d), (double) 0.0f);
        java.awt.Stroke stroke3 = intervalMarker2.getStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke5 = categoryAxis4.getTickMarkStroke();
        float float6 = categoryAxis4.getTickMarkOutsideLength();
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis4.setLabelFont(font7);
        double double9 = categoryAxis4.getCategoryMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis4.getLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryAxis4.getTickLabelInsets();
        double double13 = rectangleInsets11.calculateLeftInset((double) 0.0f);
        java.lang.String str14 = rectangleInsets11.toString();
        intervalMarker2.setLabelOffset(rectangleInsets11);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2d + "'", double9 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str14.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str1.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        java.util.List list12 = xYPlot0.getAnnotations();
        java.awt.Stroke stroke13 = xYPlot0.getDomainGridlineStroke();
        double double14 = xYPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone18 = dateAxis17.getTimeZone();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = dateAxis17.java2DToValue((double) (short) 100, rectangle2D20, rectangleEdge21);
        xYPlot0.setDomainAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) dateAxis17);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE", timeZone25);
        boolean boolean27 = dateAxis26.isNegativeArrowVisible();
        java.awt.Shape shape28 = dateAxis26.getLeftArrow();
        int int29 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis26);
        java.util.Date date30 = dateAxis26.getMinimumDate();
        float float31 = dateAxis26.getTickMarkInsideLength();
        dateAxis26.setVerticalTickLabels(false);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 9.223372036854776E18d + "'", double22 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.0f + "'", float31 == 0.0f);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke6 = intervalMarker5.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot7.getDomainAxis();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart12, chartChangeEventType13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke19 = categoryAxis18.getTickMarkStroke();
        categoryAxis18.setLabelToolTip("hi!");
        categoryAxis18.setLabel("");
        boolean boolean24 = layer17.equals((java.lang.Object) categoryAxis18);
        boolean boolean25 = categoryPlot7.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker16, layer17);
        boolean boolean26 = categoryPlot0.removeDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) intervalMarker5, layer17);
        categoryPlot0.setRangeCrosshairValue((double) 128);
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.LEFT;
        boolean boolean32 = layer30.equals((java.lang.Object) rectangleAnchor31);
        java.util.Collection collection33 = categoryPlot0.getRangeMarkers(0, layer30);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis();
        int int36 = categoryAxis35.getMaximumCategoryLabelLines();
        categoryPlot0.setDomainAxis(15, categoryAxis35);
        org.jfree.chart.axis.AxisLocation axisLocation39 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.Object obj40 = null;
        boolean boolean41 = axisLocation39.equals(obj40);
        categoryPlot0.setDomainAxisLocation((int) (short) 100, axisLocation39, false);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation26);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = categoryPlot0.getDomainAxisForDataset(0);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone32 = dateAxis31.getTimeZone();
        dateAxis31.setNegativeArrowVisible(false);
        dateAxis31.setAutoTickUnitSelection(true, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = dateAxis31.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis40.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font44 = categoryAxis42.getTickLabelFont((java.lang.Comparable) 4);
        dateAxis40.setTickLabelFont(font44);
        dateAxis31.setTickLabelFont(font44);
        dateAxis31.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis50.configure();
        boolean boolean52 = dateAxis50.isAutoRange();
        org.jfree.data.time.DateRange dateRange53 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis50.setRangeWithMargins((org.jfree.data.Range) dateRange53);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition55 = dateAxis50.getTickMarkPosition();
        dateAxis31.setTickMarkPosition(dateTickMarkPosition55);
        java.util.Date date57 = dateAxis31.getMinimumDate();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis31);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNull(categoryAxis29);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(dateRange53);
        org.junit.Assert.assertNotNull(dateTickMarkPosition55);
        org.junit.Assert.assertNotNull(date57);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.setNegativeArrowVisible(true);
        dateAxis1.setRangeAboutValue(1.0E-8d, (double) 8);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(11);
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        double double5 = intervalMarker4.getStartValue();
        java.awt.Color color6 = java.awt.Color.orange;
        intervalMarker4.setLabelPaint((java.awt.Paint) color6);
        int int8 = objectList1.indexOf((java.lang.Object) intervalMarker4);
        objectList1.clear();
        objectList1.clear();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color17, jFreeChart18, chartChangeEventType19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color17, stroke21);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart25 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType26 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color24, jFreeChart25, chartChangeEventType26);
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color24, stroke28);
        valueMarker22.setOutlineStroke(stroke28);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace32 = color31.getColorSpace();
        valueMarker22.setLabelPaint((java.awt.Paint) color31);
        org.jfree.chart.text.TextAnchor textAnchor34 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker22.setLabelTextAnchor(textAnchor34);
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str37 = layer36.toString();
        boolean boolean39 = categoryPlot14.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker22, layer36, true);
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean42 = xYPlot12.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker22, layer40, true);
        xYPlot12.setRangeGridlinesVisible(false);
        xYPlot12.setForegroundAlpha(0.0f);
        java.awt.geom.Point2D point2D47 = xYPlot12.getQuadrantOrigin();
        xYPlot12.setDomainGridlinesVisible(true);
        org.jfree.chart.plot.IntervalMarker intervalMarker52 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke53 = intervalMarker52.getOutlineStroke();
        org.jfree.chart.util.Layer layer54 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean55 = xYPlot12.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker52, layer54);
        objectList1.set(255, (java.lang.Object) intervalMarker52);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 11.0d + "'", double5 == 11.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(colorSpace32);
        org.junit.Assert.assertNotNull(textAnchor34);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Layer.FOREGROUND" + "'", str37.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(layer40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(point2D47);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(layer54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis(128);
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace4, true);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis8.getLabelInsets();
        double double11 = rectangleInsets9.calculateBottomInset((double) 1);
        double double13 = rectangleInsets9.trimHeight((double) (-1));
        double double15 = rectangleInsets9.calculateBottomInset((double) 'a');
        double double16 = rectangleInsets9.getLeft();
        java.lang.String str17 = rectangleInsets9.toString();
        categoryPlot0.setInsets(rectangleInsets9);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0d + "'", double11 == 3.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-7.0d) + "'", double13 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15 == 3.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 3.0d + "'", double16 == 3.0d);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str17.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        dateAxis1.setLowerBound((double) (-1L));
        java.awt.Paint paint5 = dateAxis1.getTickLabelPaint();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot0.getDomainAxisEdge((int) (byte) 0);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        categoryPlot0.mapDatasetToRangeAxis(0, 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = categoryPlot0.getRangeAxisEdge(4);
        org.jfree.chart.axis.AxisSpace axisSpace35 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertNull(axisSpace35);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat3 = numberAxis2.getNumberFormatOverride();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, xYItemRenderer4);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace7 = categoryPlot6.getFixedDomainAxisSpace();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color10 = java.awt.Color.WHITE;
        java.awt.Color color11 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color8, color9, color10, color11 };
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray17 = new java.awt.Paint[] { color13, color14, color15, color16 };
        java.awt.Paint[] paintArray18 = null;
        java.awt.Stroke stroke19 = null;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] { stroke19 };
        java.awt.Stroke stroke21 = null;
        java.awt.Stroke[] strokeArray22 = new java.awt.Stroke[] { stroke21 };
        java.awt.Shape shape23 = null;
        java.awt.Shape[] shapeArray24 = new java.awt.Shape[] { shape23 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier25 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray12, paintArray17, paintArray18, strokeArray20, strokeArray22, shapeArray24);
        categoryPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier25);
        xYPlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier25);
        org.junit.Assert.assertNull(numberFormat3);
        org.junit.Assert.assertNull(axisSpace7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(strokeArray22);
        org.junit.Assert.assertNotNull(shapeArray24);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.awt.Color color0 = java.awt.Color.magenta;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color2, color3, color4, color5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color7, color8, color9, color10 };
        java.awt.Paint[] paintArray12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke stroke15 = null;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        java.awt.Shape shape17 = null;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray14, strokeArray16, shapeArray18);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        categoryPlot0.setWeight((int) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot0.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = dateAxis26.getLabelInsets();
        categoryPlot0.setRangeAxis(12, (org.jfree.chart.axis.ValueAxis) dateAxis26);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone31 = dateAxis30.getTimeZone();
        dateAxis30.setNegativeArrowVisible(false);
        java.awt.Shape shape34 = dateAxis30.getLeftArrow();
        dateAxis26.setDownArrow(shape34);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(shape34);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        intervalMarker2.setLabelTextAnchor(textAnchor3);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = intervalMarker2.getGradientPaintTransformer();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color7, jFreeChart8, chartChangeEventType9);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke11);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker12);
        org.jfree.chart.JFreeChart jFreeChart14 = markerChangeEvent13.getChart();
        org.jfree.chart.plot.Marker marker15 = markerChangeEvent13.getMarker();
        intervalMarker2.notifyListeners(markerChangeEvent13);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNull(gradientPaintTransformer5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(jFreeChart14);
        org.junit.Assert.assertNotNull(marker15);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        boolean boolean5 = xYPlot0.isRangeZeroBaselineVisible();
        xYPlot0.setBackgroundAlpha((float) '4');
        boolean boolean8 = xYPlot0.isDomainCrosshairLockedOnData();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart12, chartChangeEventType13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke15);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent17 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker16);
        org.jfree.chart.text.TextAnchor textAnchor18 = valueMarker16.getLabelTextAnchor();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) valueMarker16);
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean22 = xYPlot0.removeDomainMarker(255, (org.jfree.chart.plot.Marker) valueMarker16, layer20, true);
        java.awt.Font font23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        valueMarker16.setLabelFont(font23);
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        xYPlot25.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis29.configure();
        boolean boolean31 = dateAxis29.isAutoRange();
        java.awt.Shape shape32 = dateAxis29.getLeftArrow();
        org.jfree.data.Range range33 = dateAxis29.getDefaultAutoRange();
        int int34 = xYPlot25.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis29);
        int int35 = xYPlot25.getRangeAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis36 = xYPlot25.getDomainAxis();
        valueMarker16.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot25);
        xYPlot25.clearDomainMarkers();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNull(valueAxis36);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        float[] floatArray3 = null;
        float[] floatArray4 = java.awt.Color.RGBtoHSB(10, (-1), 0, floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        categoryPlot0.setAnchorValue((double) 0, true);
        double double7 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot10.drawDomainTickBands(graphics2D11, rectangle2D12, list13);
        java.awt.Color color15 = java.awt.Color.yellow;
        xYPlot10.setRangeCrosshairPaint((java.awt.Paint) color15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart25 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType26 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color24, jFreeChart25, chartChangeEventType26);
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color24, stroke28);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart32 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType33 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent34 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color31, jFreeChart32, chartChangeEventType33);
        java.awt.Stroke stroke35 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color31, stroke35);
        valueMarker29.setOutlineStroke(stroke35);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace39 = color38.getColorSpace();
        valueMarker29.setLabelPaint((java.awt.Paint) color38);
        org.jfree.chart.text.TextAnchor textAnchor41 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker29.setLabelTextAnchor(textAnchor41);
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str44 = layer43.toString();
        boolean boolean46 = categoryPlot21.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker29, layer43, true);
        org.jfree.chart.util.Layer layer47 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean49 = xYPlot19.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker29, layer47, true);
        xYPlot19.setRangeGridlinesVisible(false);
        xYPlot19.setForegroundAlpha(0.0f);
        java.awt.geom.Point2D point2D54 = xYPlot19.getQuadrantOrigin();
        xYPlot10.zoomRangeAxes((double) (byte) 1, plotRenderingInfo18, point2D54, false);
        categoryPlot0.zoomRangeAxes(0.05d, plotRenderingInfo9, point2D54);
        org.jfree.data.category.CategoryDataset categoryDataset58 = null;
        categoryPlot0.setDataset(categoryDataset58);
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(colorSpace39);
        org.junit.Assert.assertNotNull(textAnchor41);
        org.junit.Assert.assertNotNull(layer43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Layer.FOREGROUND" + "'", str44.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(layer47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(point2D54);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color6 = java.awt.Color.WHITE;
        java.awt.Color color7 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray8 = new java.awt.Paint[] { color4, color5, color6, color7 };
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color9, color10, color11, color12 };
        java.awt.Paint[] paintArray14 = null;
        java.awt.Stroke stroke15 = null;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        java.awt.Stroke stroke17 = null;
        java.awt.Stroke[] strokeArray18 = new java.awt.Stroke[] { stroke17 };
        java.awt.Shape shape19 = null;
        java.awt.Shape[] shapeArray20 = new java.awt.Shape[] { shape19 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray8, paintArray13, paintArray14, strokeArray16, strokeArray18, shapeArray20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color25, jFreeChart26, chartChangeEventType27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color25, stroke29);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart33 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType34 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent35 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color32, jFreeChart33, chartChangeEventType34);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color32, stroke36);
        valueMarker30.setOutlineStroke(stroke36);
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace40 = color39.getColorSpace();
        valueMarker30.setLabelPaint((java.awt.Paint) color39);
        org.jfree.chart.text.TextAnchor textAnchor42 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker30.setLabelTextAnchor(textAnchor42);
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str45 = layer44.toString();
        boolean boolean47 = categoryPlot22.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker30, layer44, true);
        org.jfree.chart.axis.AxisLocation axisLocation48 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot22.setRangeAxisLocation(axisLocation48);
        boolean boolean50 = defaultDrawingSupplier21.equals((java.lang.Object) axisLocation48);
        categoryPlot0.setRangeAxisLocation(axisLocation48, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation53 = categoryPlot0.getOrientation();
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(shapeArray20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(colorSpace40);
        org.junit.Assert.assertNotNull(textAnchor42);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Layer.FOREGROUND" + "'", str45.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(plotOrientation53);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 0, (float) (byte) 10, (float) 9);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getRangeAxis(1);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone9 = dateAxis8.getTimeZone();
        dateAxis8.setRange((double) (short) 0, (double) (short) 10);
        boolean boolean13 = dateAxis8.isVerticalTickLabels();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis8);
        int int15 = xYPlot0.getDomainAxisCount();
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        xYPlot0.setRangeZeroBaselineStroke(stroke16);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        java.util.List list12 = xYPlot0.getAnnotations();
        java.awt.Stroke stroke13 = xYPlot0.getDomainGridlineStroke();
        java.awt.Paint paint14 = xYPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot16.getFixedDomainAxisSpace();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart20 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType21 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color19, jFreeChart20, chartChangeEventType21);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color19, stroke23);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker24);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke28 = categoryAxis27.getTickMarkStroke();
        categoryAxis27.setLabelToolTip("hi!");
        categoryAxis27.setLabel("");
        boolean boolean33 = layer26.equals((java.lang.Object) categoryAxis27);
        boolean boolean34 = categoryPlot16.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker24, layer26);
        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str36 = layer35.toString();
        xYPlot0.addRangeMarker(128, (org.jfree.chart.plot.Marker) valueMarker24, layer35);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        xYPlot0.rendererChanged(rendererChangeEvent38);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(layer35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Layer.FOREGROUND" + "'", str36.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke6 = intervalMarker5.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot7.getDomainAxis();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart12, chartChangeEventType13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke19 = categoryAxis18.getTickMarkStroke();
        categoryAxis18.setLabelToolTip("hi!");
        categoryAxis18.setLabel("");
        boolean boolean24 = layer17.equals((java.lang.Object) categoryAxis18);
        boolean boolean25 = categoryPlot7.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker16, layer17);
        boolean boolean26 = categoryPlot0.removeDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) intervalMarker5, layer17);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        int int30 = categoryPlot0.getIndexOf(categoryItemRenderer29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        categoryPlot0.setRenderer(categoryItemRenderer31, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        categoryPlot0.setRenderer(categoryItemRenderer34, false);
        java.util.List list37 = categoryPlot0.getCategories();
        categoryPlot0.mapDatasetToDomainAxis(0, 15);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNull(list37);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        boolean boolean5 = xYPlot0.isRangeZeroBaselineVisible();
        xYPlot0.setBackgroundAlpha((float) '4');
        xYPlot0.clearAnnotations();
        boolean boolean9 = xYPlot0.isDomainCrosshairVisible();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color2, color3, color4, color5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color7, color8, color9, color10 };
        java.awt.Paint[] paintArray12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke stroke15 = null;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        java.awt.Shape shape17 = null;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray14, strokeArray16, shapeArray18);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        categoryPlot0.setWeight((int) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot0.getDomainAxis();
        java.awt.Paint paint24 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        categoryPlot0.setDataset((int) (short) 0, categoryDataset26);
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        java.util.List list31 = null;
        xYPlot28.drawDomainTickBands(graphics2D29, rectangle2D30, list31);
        org.jfree.chart.plot.IntervalMarker intervalMarker36 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot28.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker36, layer37, true);
        xYPlot28.clearDomainAxes();
        boolean boolean41 = xYPlot28.isOutlineVisible();
        xYPlot28.setRangeCrosshairLockedOnData(false);
        boolean boolean44 = xYPlot28.isDomainCrosshairLockedOnData();
        xYPlot28.configureDomainAxes();
        java.awt.Paint paint46 = xYPlot28.getBackgroundPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart51 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType52 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent53 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color50, jFreeChart51, chartChangeEventType52);
        java.awt.Stroke stroke54 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker55 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color50, stroke54);
        java.awt.Color color57 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart58 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType59 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent60 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color57, jFreeChart58, chartChangeEventType59);
        java.awt.Stroke stroke61 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker62 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color57, stroke61);
        valueMarker55.setOutlineStroke(stroke61);
        java.awt.Color color64 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace65 = color64.getColorSpace();
        valueMarker55.setLabelPaint((java.awt.Paint) color64);
        org.jfree.chart.text.TextAnchor textAnchor67 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker55.setLabelTextAnchor(textAnchor67);
        org.jfree.chart.util.Layer layer69 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str70 = layer69.toString();
        boolean boolean72 = categoryPlot47.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker55, layer69, true);
        java.awt.Color color74 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis75 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke76 = categoryAxis75.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker77 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color74, stroke76);
        categoryPlot47.setRangeGridlineStroke(stroke76);
        org.jfree.chart.axis.CategoryAxis categoryAxis79 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke80 = categoryAxis79.getTickMarkStroke();
        categoryPlot47.setRangeCrosshairStroke(stroke80);
        xYPlot28.setRangeZeroBaselineStroke(stroke80);
        org.jfree.chart.LegendItemCollection legendItemCollection83 = xYPlot28.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection83);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(colorSpace65);
        org.junit.Assert.assertNotNull(textAnchor67);
        org.junit.Assert.assertNotNull(layer69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "Layer.FOREGROUND" + "'", str70.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNotNull(stroke80);
        org.junit.Assert.assertNotNull(legendItemCollection83);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        xYPlot0.zoomRangeAxes((double) (short) 0, plotRenderingInfo32, point2D33, false);
        org.jfree.chart.axis.ValueAxis valueAxis36 = xYPlot0.getDomainAxis();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        int int38 = xYPlot0.indexOf(xYDataset37);
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.LEFT;
        boolean boolean41 = layer39.equals((java.lang.Object) rectangleAnchor40);
        java.util.Collection collection42 = xYPlot0.getDomainMarkers(layer39);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(valueAxis36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(collection42);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color2, color3, color4, color5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color7, color8, color9, color10 };
        java.awt.Paint[] paintArray12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke stroke15 = null;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        java.awt.Shape shape17 = null;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray14, strokeArray16, shapeArray18);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        org.jfree.data.general.DatasetGroup datasetGroup21 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot0.getDomainAxis((int) (byte) 10);
        java.awt.Stroke stroke24 = null;
        categoryPlot0.setOutlineStroke(stroke24);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNull(datasetGroup21);
        org.junit.Assert.assertNull(categoryAxis23);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        int int3 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot0.getRenderer(6);
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(categoryItemRenderer7);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        int int3 = categoryPlot0.getRangeAxisCount();
        categoryPlot0.setDomainGridlinesVisible(false);
        categoryPlot0.configureRangeAxes();
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.setNegativeArrowVisible(true);
        float float4 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setAutoRangeMinimumSize((double) 1);
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = dateAxis1.getTickUnit();
        java.text.DateFormat dateFormat8 = null;
        dateAxis1.setDateFormatOverride(dateFormat8);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(dateTickUnit7);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke3 = intervalMarker2.getOutlineStroke();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker10);
        intervalMarker2.notifyListeners(markerChangeEvent11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = intervalMarker2.getLabelAnchor();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(11);
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        double double5 = intervalMarker4.getStartValue();
        java.awt.Color color6 = java.awt.Color.orange;
        intervalMarker4.setLabelPaint((java.awt.Paint) color6);
        int int8 = objectList1.indexOf((java.lang.Object) intervalMarker4);
        java.lang.Object obj9 = intervalMarker4.clone();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 11.0d + "'", double5 == 11.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        dateAxis6.setRange((double) (short) 0, (double) (short) 10);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        xYPlot0.setRangeCrosshairValue((double) 1.0f);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart20 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType21 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color19, jFreeChart20, chartChangeEventType21);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color19, stroke23);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart27 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType28 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color26, jFreeChart27, chartChangeEventType28);
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color26, stroke30);
        valueMarker24.setOutlineStroke(stroke30);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace34 = color33.getColorSpace();
        valueMarker24.setLabelPaint((java.awt.Paint) color33);
        org.jfree.chart.text.TextAnchor textAnchor36 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker24.setLabelTextAnchor(textAnchor36);
        org.jfree.chart.util.Layer layer38 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str39 = layer38.toString();
        boolean boolean41 = categoryPlot16.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker24, layer38, true);
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean44 = xYPlot14.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker24, layer42, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        java.awt.geom.Point2D point2D47 = null;
        xYPlot14.zoomRangeAxes((double) (short) 0, plotRenderingInfo46, point2D47, false);
        org.jfree.chart.axis.ValueAxis valueAxis50 = xYPlot14.getDomainAxis();
        org.jfree.data.xy.XYDataset xYDataset51 = null;
        int int52 = xYPlot14.indexOf(xYDataset51);
        java.awt.Color color54 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart55 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType56 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent57 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color54, jFreeChart55, chartChangeEventType56);
        java.awt.Stroke stroke58 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker59 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color54, stroke58);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent60 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker59);
        org.jfree.chart.text.TextAnchor textAnchor61 = valueMarker59.getLabelTextAnchor();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent62 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) valueMarker59);
        boolean boolean63 = xYPlot14.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker59);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker59);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(colorSpace34);
        org.junit.Assert.assertNotNull(textAnchor36);
        org.junit.Assert.assertNotNull(layer38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Layer.FOREGROUND" + "'", str39.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(valueAxis50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(textAnchor61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color2, color3, color4, color5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color7, color8, color9, color10 };
        java.awt.Paint[] paintArray12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke stroke15 = null;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        java.awt.Shape shape17 = null;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray14, strokeArray16, shapeArray18);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        categoryPlot0.setWeight((int) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot0.getDomainAxis();
        java.awt.Paint paint24 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        categoryPlot0.setDataset((int) (short) 0, categoryDataset26);
        java.awt.Paint paint28 = categoryPlot0.getRangeCrosshairPaint();
        categoryPlot0.clearAnnotations();
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis31.setUpperBound((double) 8);
        dateAxis31.setLowerMargin((double) (byte) 1);
        org.jfree.data.Range range36 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis31);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(range36);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        float float2 = categoryAxis0.getTickMarkOutsideLength();
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis0.setLabelFont(font3);
        double double5 = categoryAxis0.getCategoryMargin();
        java.awt.Paint paint6 = null;
        try {
            categoryAxis0.setTickMarkPaint(paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent26 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker8);
        org.jfree.chart.plot.Marker marker27 = markerChangeEvent26.getMarker();
        java.lang.String str28 = markerChangeEvent26.toString();
        org.jfree.chart.plot.Marker marker29 = markerChangeEvent26.getMarker();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(marker27);
        org.junit.Assert.assertNotNull(marker29);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        categoryPlot0.setAnchorValue((double) 0, true);
        double double7 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot9.getFixedDomainAxisSpace();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke15 = intervalMarker14.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot16.getDomainAxis();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart21 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType22 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color20, jFreeChart21, chartChangeEventType22);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color20, stroke24);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke28 = categoryAxis27.getTickMarkStroke();
        categoryAxis27.setLabelToolTip("hi!");
        categoryAxis27.setLabel("");
        boolean boolean33 = layer26.equals((java.lang.Object) categoryAxis27);
        boolean boolean34 = categoryPlot16.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker25, layer26);
        boolean boolean35 = categoryPlot9.removeDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) intervalMarker14, layer26);
        categoryPlot9.setRangeCrosshairValue((double) 128);
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.LEFT;
        boolean boolean41 = layer39.equals((java.lang.Object) rectangleAnchor40);
        java.util.Collection collection42 = categoryPlot9.getRangeMarkers(0, layer39);
        java.util.Collection collection43 = categoryPlot0.getRangeMarkers((int) (byte) 100, layer39);
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertNull(collection43);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        xYPlot0.setDataset(64, xYDataset2);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        xYPlot0.setRangeGridlinesVisible(false);
        xYPlot0.setForegroundAlpha(0.0f);
        org.jfree.chart.plot.IntervalMarker intervalMarker37 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke38 = intervalMarker37.getOutlineStroke();
        xYPlot0.setDomainCrosshairStroke(stroke38);
        java.awt.Color color40 = org.jfree.chart.ChartColor.LIGHT_RED;
        xYPlot0.setNoDataMessagePaint((java.awt.Paint) color40);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        java.awt.geom.Point2D point2D44 = null;
        xYPlot0.zoomDomainAxes((double) (-256), plotRenderingInfo43, point2D44);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color40);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        xYPlot0.clearDomainAxes();
        int int13 = xYPlot0.getDatasetCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart19 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color18, jFreeChart19, chartChangeEventType20);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color18, stroke22);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color25, jFreeChart26, chartChangeEventType27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color25, stroke29);
        valueMarker23.setOutlineStroke(stroke29);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace33 = color32.getColorSpace();
        valueMarker23.setLabelPaint((java.awt.Paint) color32);
        org.jfree.chart.text.TextAnchor textAnchor35 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker23.setLabelTextAnchor(textAnchor35);
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str38 = layer37.toString();
        boolean boolean40 = categoryPlot15.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker23, layer37, true);
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection42 = categoryPlot15.getRangeMarkers(layer41);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent43 = null;
        categoryPlot15.rendererChanged(rendererChangeEvent43);
        org.jfree.chart.axis.AxisLocation axisLocation45 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot15.setRangeAxisLocation(axisLocation45);
        org.jfree.chart.axis.AxisLocation axisLocation47 = axisLocation45.getOpposite();
        xYPlot0.setDomainAxisLocation(100, axisLocation47, false);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(colorSpace33);
        org.junit.Assert.assertNotNull(textAnchor35);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Layer.FOREGROUND" + "'", str38.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertNotNull(collection42);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNotNull(axisLocation47);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color2, color3, color4, color5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color7, color8, color9, color10 };
        java.awt.Paint[] paintArray12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke stroke15 = null;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        java.awt.Shape shape17 = null;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray14, strokeArray16, shapeArray18);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        categoryPlot0.setWeight((int) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot0.getDomainAxisForDataset(3);
        java.awt.Stroke stroke25 = categoryPlot0.getRangeGridlineStroke();
        float float26 = categoryPlot0.getForegroundAlpha();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color2, color3, color4, color5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color7, color8, color9, color10 };
        java.awt.Paint[] paintArray12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke stroke15 = null;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        java.awt.Shape shape17 = null;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray14, strokeArray16, shapeArray18);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        categoryPlot0.setWeight((int) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot0.getDomainAxis();
        java.awt.Paint paint24 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        categoryPlot0.setDataset((int) (short) 0, categoryDataset26);
        java.awt.Paint paint28 = categoryPlot0.getRangeCrosshairPaint();
        categoryPlot0.clearAnnotations();
        java.awt.Stroke stroke30 = categoryPlot0.getOutlineStroke();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.Timeline timeline2 = null;
        dateAxis1.setTimeline(timeline2);
        java.awt.Stroke stroke4 = dateAxis1.getTickMarkStroke();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis6.configure();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis9.setNegativeArrowVisible(true);
        float float12 = dateAxis9.getTickMarkOutsideLength();
        dateAxis9.setAutoRangeMinimumSize((double) 1);
        boolean boolean15 = dateAxis9.isAxisLineVisible();
        dateAxis9.setLabelToolTip("hi!");
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis19.setNegativeArrowVisible(true);
        float float22 = dateAxis19.getTickMarkOutsideLength();
        dateAxis19.setAutoRangeMinimumSize((double) 1);
        org.jfree.chart.axis.DateTickUnit dateTickUnit25 = dateAxis19.getTickUnit();
        dateAxis9.setTickUnit(dateTickUnit25);
        org.jfree.data.general.Dataset dataset27 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent28 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) dateTickUnit25, dataset27);
        dateAxis6.setTickUnit(dateTickUnit25, true, false);
        dateAxis1.setTickUnit(dateTickUnit25, false, false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 2.0f + "'", float22 == 2.0f);
        org.junit.Assert.assertNotNull(dateTickUnit25);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE", timeZone1);
        boolean boolean3 = dateAxis2.isNegativeArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis5.configure();
        boolean boolean7 = dateAxis5.isAutoRange();
        org.jfree.data.time.DateRange dateRange8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange8);
        dateAxis2.setRange((org.jfree.data.Range) dateRange8);
        java.awt.Shape shape11 = dateAxis2.getUpArrow();
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis2.setRangeWithMargins(range12, true, true);
        try {
            dateAxis2.setRangeAboutValue((double) (short) 10, (-7.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (13.5) <= upper (6.5).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateRange8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(range12);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        dateAxis6.setRange((double) (short) 0, (double) (short) 10);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        dateAxis6.zoomRange(0.0d, (double) 64);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis16.configure();
        boolean boolean18 = dateAxis16.isAutoRange();
        org.jfree.data.time.DateRange dateRange19 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis16.setRangeWithMargins((org.jfree.data.Range) dateRange19);
        dateAxis6.setRange((org.jfree.data.Range) dateRange19);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(dateRange19);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        java.awt.Paint paint3 = xYPlot0.getRangeGridlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = xYPlot0.getDomainAxisEdge(3);
        java.awt.Color color6 = java.awt.Color.GREEN;
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color6);
        java.awt.Stroke stroke8 = xYPlot0.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation26);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = categoryPlot0.getDomainAxisForDataset(0);
        org.jfree.data.general.DatasetGroup datasetGroup30 = categoryPlot0.getDatasetGroup();
        int int31 = categoryPlot0.getWeight();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNull(categoryAxis29);
        org.junit.Assert.assertNull(datasetGroup30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.configure();
        java.awt.Paint paint3 = dateAxis1.getTickLabelPaint();
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        java.awt.Color color27 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke29 = categoryAxis28.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color27, stroke29);
        categoryPlot0.setRangeGridlineStroke(stroke29);
        org.jfree.chart.axis.AxisLocation axisLocation33 = categoryPlot0.getRangeAxisLocation((int) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke35 = categoryAxis34.getTickMarkStroke();
        categoryAxis34.setFixedDimension((double) 10.0f);
        boolean boolean38 = categoryAxis34.isTickMarksVisible();
        categoryAxis34.setTickMarksVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke42 = categoryAxis41.getTickMarkStroke();
        float float43 = categoryAxis41.getTickMarkOutsideLength();
        categoryAxis41.setAxisLineVisible(true);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions46 = categoryAxis41.getCategoryLabelPositions();
        categoryAxis34.setCategoryLabelPositions(categoryLabelPositions46);
        boolean boolean48 = axisLocation33.equals((java.lang.Object) categoryAxis34);
        java.util.Date date49 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.category.CategoryDataset categoryDataset51 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = null;
        try {
            double double55 = categoryAxis34.getCategorySeriesMiddle((java.lang.Comparable) date49, (java.lang.Comparable) true, categoryDataset51, (double) 1560452399999L, rectangle2D53, rectangleEdge54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 2.0f + "'", float43 == 2.0f);
        org.junit.Assert.assertNotNull(categoryLabelPositions46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(date49);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke3 = intervalMarker2.getOutlineStroke();
        intervalMarker2.setStartValue((double) 2.0f);
        intervalMarker2.setStartValue((double) 1);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        intervalMarker2.setLabelOffsetType(lengthAdjustmentType8);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(lengthAdjustmentType8);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = xYPlot0.getAxisOffset();
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.configure();
        boolean boolean3 = dateAxis1.isAutoRange();
        java.awt.Shape shape4 = dateAxis1.getLeftArrow();
        org.jfree.data.Range range5 = dateAxis1.getDefaultAutoRange();
        dateAxis1.setTickMarksVisible(false);
        double double8 = dateAxis1.getAutoRangeMinimumSize();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        org.jfree.chart.LegendItemCollection legendItemCollection31 = null;
        xYPlot0.setFixedLegendItems(legendItemCollection31);
        xYPlot0.setRangeCrosshairLockedOnData(false);
        java.awt.Paint paint35 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection36 = xYPlot0.getFixedLegendItems();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNull(legendItemCollection36);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        xYPlot0.setRangeGridlinesVisible(false);
        xYPlot0.setForegroundAlpha(0.0f);
        java.awt.geom.Point2D point2D35 = xYPlot0.getQuadrantOrigin();
        xYPlot0.setForegroundAlpha((float) (byte) 10);
        java.util.List list38 = xYPlot0.getAnnotations();
        xYPlot0.clearDomainMarkers(255);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertNotNull(list38);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        xYPlot0.clearDomainAxes();
        boolean boolean13 = xYPlot0.isOutlineVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot0.getRangeAxisEdge(12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart24 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType25 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color23, jFreeChart24, chartChangeEventType25);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color23, stroke27);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart31 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType32 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color30, jFreeChart31, chartChangeEventType32);
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color30, stroke34);
        valueMarker28.setOutlineStroke(stroke34);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace38 = color37.getColorSpace();
        valueMarker28.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.text.TextAnchor textAnchor40 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker28.setLabelTextAnchor(textAnchor40);
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str43 = layer42.toString();
        boolean boolean45 = categoryPlot20.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker28, layer42, true);
        org.jfree.chart.util.Layer layer46 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean48 = xYPlot18.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker28, layer46, true);
        xYPlot18.setRangeGridlinesVisible(false);
        xYPlot18.setForegroundAlpha(0.0f);
        java.awt.geom.Point2D point2D53 = xYPlot18.getQuadrantOrigin();
        xYPlot0.zoomRangeAxes((double) '#', plotRenderingInfo17, point2D53, true);
        org.jfree.chart.plot.Plot plot56 = xYPlot0.getParent();
        int int57 = xYPlot0.getWeight();
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(colorSpace38);
        org.junit.Assert.assertNotNull(textAnchor40);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Layer.FOREGROUND" + "'", str43.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(layer46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(point2D53);
        org.junit.Assert.assertNull(plot56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        float float3 = intervalMarker2.getAlpha();
        intervalMarker2.setStartValue((double) (-1L));
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = intervalMarker2.getLabelOffset();
        intervalMarker2.setEndValue((-6.0d));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.8f + "'", float3 == 0.8f);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test171");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        java.util.Date date2 = day0.getStart();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertNotNull(date2);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean2 = lengthAdjustmentType0.equals((java.lang.Object) 0.0f);
        java.lang.String str3 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CONTRACT" + "'", str3.equals("CONTRACT"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        float float3 = intervalMarker2.getAlpha();
        intervalMarker2.setStartValue((double) (-1L));
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color7, jFreeChart8, chartChangeEventType9);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke11);
        intervalMarker2.setOutlineStroke(stroke11);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.8f + "'", float3 == 0.8f);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        xYPlot0.setRangeGridlinesVisible(false);
        xYPlot0.setForegroundAlpha(0.0f);
        org.jfree.chart.plot.IntervalMarker intervalMarker37 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke38 = intervalMarker37.getOutlineStroke();
        xYPlot0.setDomainCrosshairStroke(stroke38);
        java.awt.Stroke stroke40 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = dateAxis43.getLabelInsets();
        dateAxis43.setLowerBound((double) (-1L));
        dateAxis43.setRangeWithMargins((double) 11, (double) 64);
        float float50 = dateAxis43.getTickMarkOutsideLength();
        java.util.TimeZone timeZone51 = dateAxis43.getTimeZone();
        xYPlot0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis43);
        org.jfree.chart.axis.AxisLocation axisLocation53 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.Object obj54 = null;
        boolean boolean55 = axisLocation53.equals(obj54);
        xYPlot0.setRangeAxisLocation(axisLocation53);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertTrue("'" + float50 + "' != '" + 2.0f + "'", float50 == 2.0f);
        org.junit.Assert.assertNotNull(timeZone51);
        org.junit.Assert.assertNotNull(axisLocation53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation26);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = categoryPlot0.getDomainAxisForDataset(0);
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation30, false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNull(categoryAxis29);
        org.junit.Assert.assertNotNull(axisLocation30);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        double double3 = dateAxis1.getFixedDimension();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone6 = dateAxis5.getTimeZone();
        dateAxis5.setRange((double) (short) 0, (double) (short) 10);
        java.awt.Shape shape10 = dateAxis5.getDownArrow();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition11 = dateAxis5.getTickMarkPosition();
        dateAxis1.setTickMarkPosition(dateTickMarkPosition11);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(dateTickMarkPosition11);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
//        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        org.jfree.chart.JFreeChart jFreeChart6 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
//        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
//        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        org.jfree.chart.JFreeChart jFreeChart13 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
//        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
//        valueMarker10.setOutlineStroke(stroke16);
//        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
//        valueMarker10.setLabelPaint((java.awt.Paint) color19);
//        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
//        valueMarker10.setLabelTextAnchor(textAnchor22);
//        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
//        java.lang.String str25 = layer24.toString();
//        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
//        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
//        java.util.Collection collection29 = categoryPlot2.getRangeMarkers(layer28);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
//        categoryPlot2.rendererChanged(rendererChangeEvent30);
//        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
//        categoryPlot2.setRangeAxisLocation(axisLocation32);
//        org.jfree.chart.axis.AxisLocation axisLocation34 = axisLocation32.getOpposite();
//        int int35 = day0.compareTo((java.lang.Object) axisLocation34);
//        java.lang.String str36 = day0.toString();
//        java.util.Date date37 = day0.getEnd();
//        long long38 = day0.getSerialIndex();
//        java.lang.Object obj39 = null;
//        int int40 = day0.compareTo(obj39);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertNotNull(color5);
//        org.junit.Assert.assertNotNull(stroke9);
//        org.junit.Assert.assertNotNull(color12);
//        org.junit.Assert.assertNotNull(stroke16);
//        org.junit.Assert.assertNotNull(color19);
//        org.junit.Assert.assertNotNull(colorSpace20);
//        org.junit.Assert.assertNotNull(textAnchor22);
//        org.junit.Assert.assertNotNull(layer24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(layer28);
//        org.junit.Assert.assertNotNull(collection29);
//        org.junit.Assert.assertNotNull(axisLocation32);
//        org.junit.Assert.assertNotNull(axisLocation34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 43629L + "'", long38 == 43629L);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        java.awt.Color color5 = java.awt.Color.yellow;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart15 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color14, jFreeChart15, chartChangeEventType16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color14, stroke18);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart22 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color21, jFreeChart22, chartChangeEventType23);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color21, stroke25);
        valueMarker19.setOutlineStroke(stroke25);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace29 = color28.getColorSpace();
        valueMarker19.setLabelPaint((java.awt.Paint) color28);
        org.jfree.chart.text.TextAnchor textAnchor31 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker19.setLabelTextAnchor(textAnchor31);
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str34 = layer33.toString();
        boolean boolean36 = categoryPlot11.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker19, layer33, true);
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean39 = xYPlot9.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker19, layer37, true);
        xYPlot9.setRangeGridlinesVisible(false);
        xYPlot9.setForegroundAlpha(0.0f);
        java.awt.geom.Point2D point2D44 = xYPlot9.getQuadrantOrigin();
        xYPlot0.zoomRangeAxes((double) (byte) 1, plotRenderingInfo8, point2D44, false);
        org.jfree.data.xy.XYDataset xYDataset47 = xYPlot0.getDataset();
        xYPlot0.setDomainCrosshairVisible(true);
        java.awt.Paint paint50 = xYPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(colorSpace29);
        org.junit.Assert.assertNotNull(textAnchor31);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Layer.FOREGROUND" + "'", str34.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(point2D44);
        org.junit.Assert.assertNull(xYDataset47);
        org.junit.Assert.assertNotNull(paint50);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.setNegativeArrowVisible(true);
        float float4 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setAutoRangeMinimumSize((double) 1);
        boolean boolean7 = dateAxis1.isAxisLineVisible();
        dateAxis1.setRangeAboutValue((double) 10L, 0.05d);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        boolean boolean13 = numberAxis12.getAutoRangeIncludesZero();
        double double14 = numberAxis12.getUpperBound();
        java.awt.Font font15 = numberAxis12.getTickLabelFont();
        dateAxis1.setLabelFont(font15);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke6 = intervalMarker5.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot7.getDomainAxis();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart12, chartChangeEventType13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke19 = categoryAxis18.getTickMarkStroke();
        categoryAxis18.setLabelToolTip("hi!");
        categoryAxis18.setLabel("");
        boolean boolean24 = layer17.equals((java.lang.Object) categoryAxis18);
        boolean boolean25 = categoryPlot7.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker16, layer17);
        boolean boolean26 = categoryPlot0.removeDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) intervalMarker5, layer17);
        categoryPlot0.setRangeCrosshairValue((double) 128);
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.LEFT;
        boolean boolean32 = layer30.equals((java.lang.Object) rectangleAnchor31);
        java.util.Collection collection33 = categoryPlot0.getRangeMarkers(0, layer30);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis();
        int int36 = categoryAxis35.getMaximumCategoryLabelLines();
        categoryPlot0.setDomainAxis(15, categoryAxis35);
        categoryPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.AxisLocation axisLocation41 = categoryPlot0.getDomainAxisLocation(0);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(axisLocation41);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        xYPlot0.clearDomainAxes();
        boolean boolean13 = xYPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace14);
        xYPlot0.setNoDataMessage("");
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        dateAxis1.setRange((double) (short) 0, (double) (short) 10);
        boolean boolean7 = dateAxis1.isHiddenValue((long) 10);
        java.text.DateFormat dateFormat8 = null;
        dateAxis1.setDateFormatOverride(dateFormat8);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        xYPlot0.clearDomainAxes();
        boolean boolean13 = xYPlot0.isOutlineVisible();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        boolean boolean16 = xYPlot0.isDomainCrosshairLockedOnData();
        xYPlot0.configureDomainAxes();
        java.awt.Paint paint18 = xYPlot0.getBackgroundPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart23 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType24 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color22, jFreeChart23, chartChangeEventType24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color22, stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart30 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType31 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent32 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color29, jFreeChart30, chartChangeEventType31);
        java.awt.Stroke stroke33 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color29, stroke33);
        valueMarker27.setOutlineStroke(stroke33);
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace37 = color36.getColorSpace();
        valueMarker27.setLabelPaint((java.awt.Paint) color36);
        org.jfree.chart.text.TextAnchor textAnchor39 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker27.setLabelTextAnchor(textAnchor39);
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str42 = layer41.toString();
        boolean boolean44 = categoryPlot19.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker27, layer41, true);
        java.awt.Color color46 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke48 = categoryAxis47.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker49 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color46, stroke48);
        categoryPlot19.setRangeGridlineStroke(stroke48);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke52 = categoryAxis51.getTickMarkStroke();
        categoryPlot19.setRangeCrosshairStroke(stroke52);
        xYPlot0.setRangeZeroBaselineStroke(stroke52);
        org.jfree.chart.LegendItemCollection legendItemCollection55 = xYPlot0.getLegendItems();
        xYPlot0.setDomainCrosshairValue((double) (byte) 10, false);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(colorSpace37);
        org.junit.Assert.assertNotNull(textAnchor39);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Layer.FOREGROUND" + "'", str42.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(legendItemCollection55);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(11);
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        double double5 = intervalMarker4.getStartValue();
        java.awt.Color color6 = java.awt.Color.orange;
        intervalMarker4.setLabelPaint((java.awt.Paint) color6);
        int int8 = objectList1.indexOf((java.lang.Object) intervalMarker4);
        objectList1.clear();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color13, jFreeChart14, chartChangeEventType15);
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color13, stroke17);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart21 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType22 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color20, jFreeChart21, chartChangeEventType22);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color20, stroke24);
        valueMarker18.setOutlineStroke(stroke24);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace28 = color27.getColorSpace();
        valueMarker18.setLabelPaint((java.awt.Paint) color27);
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker18.setLabelTextAnchor(textAnchor30);
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str33 = layer32.toString();
        boolean boolean35 = categoryPlot10.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker18, layer32, true);
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection37 = categoryPlot10.getRangeMarkers(layer36);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        categoryPlot10.rendererChanged(rendererChangeEvent38);
        org.jfree.chart.axis.AxisLocation axisLocation40 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot10.setRangeAxisLocation(axisLocation40);
        categoryPlot10.setBackgroundAlpha((float) (short) 100);
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        java.util.List list47 = null;
        xYPlot44.drawDomainTickBands(graphics2D45, rectangle2D46, list47);
        org.jfree.chart.plot.IntervalMarker intervalMarker52 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer53 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot44.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker52, layer53, true);
        java.util.List list56 = xYPlot44.getAnnotations();
        java.awt.Stroke stroke57 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot44.setDomainCrosshairStroke(stroke57);
        categoryPlot10.setRangeCrosshairStroke(stroke57);
        double double60 = categoryPlot10.getAnchorValue();
        boolean boolean61 = objectList1.equals((java.lang.Object) double60);
        org.jfree.chart.axis.DateAxis dateAxis63 = new org.jfree.chart.axis.DateAxis("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
        int int64 = objectList1.indexOf((java.lang.Object) dateAxis63);
        org.jfree.chart.axis.DateAxis dateAxis66 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis66.configure();
        boolean boolean68 = dateAxis66.isAutoRange();
        java.awt.Shape shape69 = dateAxis66.getLeftArrow();
        org.jfree.data.Range range70 = dateAxis66.getDefaultAutoRange();
        dateAxis63.setRangeWithMargins(range70, true, true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 11.0d + "'", double5 == 11.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(colorSpace28);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Layer.FOREGROUND" + "'", str33.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(layer53);
        org.junit.Assert.assertNotNull(list56);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(shape69);
        org.junit.Assert.assertNotNull(range70);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        java.awt.Color color27 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke29 = categoryAxis28.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color27, stroke29);
        categoryPlot0.setRangeGridlineStroke(stroke29);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone35 = dateAxis34.getTimeZone();
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = dateAxis34.java2DToValue((double) (short) 100, rectangle2D37, rectangleEdge38);
        dateAxis34.setLowerBound((double) (byte) 100);
        categoryPlot0.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis34, true);
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        java.util.List list47 = null;
        xYPlot44.drawDomainTickBands(graphics2D45, rectangle2D46, list47);
        java.awt.Color color49 = java.awt.Color.yellow;
        xYPlot44.setRangeCrosshairPaint((java.awt.Paint) color49);
        java.awt.Color color51 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int52 = color51.getTransparency();
        xYPlot44.setDomainZeroBaselinePaint((java.awt.Paint) color51);
        org.jfree.chart.util.Layer layer55 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection56 = xYPlot44.getRangeMarkers((int) ' ', layer55);
        java.util.Collection collection57 = categoryPlot0.getRangeMarkers(layer55);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 9.223372036854776E18d + "'", double39 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(layer55);
        org.junit.Assert.assertNull(collection56);
        org.junit.Assert.assertNotNull(collection57);
    }
}

