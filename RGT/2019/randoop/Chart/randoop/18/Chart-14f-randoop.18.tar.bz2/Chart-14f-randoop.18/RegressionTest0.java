import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.awt.Color color0 = java.awt.Color.WHITE;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray5 = new float[] { 1L, (short) -1, (byte) 0 };
        try {
            float[] floatArray6 = color0.getComponents(colorSpace1, floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color1, jFreeChart2, chartChangeEventType3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke5);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color8, jFreeChart9, chartChangeEventType10);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color8, stroke12);
        valueMarker6.setOutlineStroke(stroke12);
        boolean boolean16 = valueMarker6.equals((java.lang.Object) "");
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        categoryAxis0.setFixedDimension((double) 10.0f);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            org.jfree.chart.axis.AxisState axisState10 = categoryAxis0.draw(graphics2D4, (double) 100.0f, rectangle2D6, rectangle2D7, rectangleEdge8, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.awt.Shape shape2 = null;
        try {
            dateAxis1.setUpArrow(shape2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color2 = java.awt.Color.WHITE;
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray4 = new java.awt.Paint[] { color0, color1, color2, color3 };
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color5, color6, color7, color8 };
        java.awt.Paint[] paintArray10 = null;
        java.awt.Stroke stroke11 = null;
        java.awt.Stroke[] strokeArray12 = new java.awt.Stroke[] { stroke11 };
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Shape shape15 = null;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] { shape15 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray4, paintArray9, paintArray10, strokeArray12, strokeArray14, shapeArray16);
        java.lang.Object obj18 = defaultDrawingSupplier17.clone();
        try {
            java.awt.Paint paint19 = defaultDrawingSupplier17.getNextOutlinePaint();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets2.createOutsetRectangle(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        try {
            dateAxis1.setRange((double) 8, (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone2);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.awt.Color color2 = java.awt.Color.WHITE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Color color6 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray7 = new java.awt.Paint[] { color3, color4, color5, color6 };
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray12 = new java.awt.Paint[] { color8, color9, color10, color11 };
        java.awt.Paint[] paintArray13 = null;
        java.awt.Stroke stroke14 = null;
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] { stroke14 };
        java.awt.Stroke stroke16 = null;
        java.awt.Stroke[] strokeArray17 = new java.awt.Stroke[] { stroke16 };
        java.awt.Shape shape18 = null;
        java.awt.Shape[] shapeArray19 = new java.awt.Shape[] { shape18 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier20 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray7, paintArray12, paintArray13, strokeArray15, strokeArray17, shapeArray19);
        boolean boolean21 = color2.equals((java.lang.Object) strokeArray17);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart24 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType25 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color23, jFreeChart24, chartChangeEventType25);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color23, stroke27);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart31 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType32 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color30, jFreeChart31, chartChangeEventType32);
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color30, stroke34);
        valueMarker28.setOutlineStroke(stroke34);
        java.awt.Paint paint37 = null;
        java.awt.Stroke stroke38 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker40 = new org.jfree.chart.plot.IntervalMarker(1.0d, (double) 4, (java.awt.Paint) color2, stroke34, paint37, stroke38, (float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paintArray7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paintArray12);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(strokeArray17);
        org.junit.Assert.assertNotNull(shapeArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis0.getCategoryEnd((int) (byte) -1, 1, rectangle2D4, rectangleEdge5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            org.jfree.chart.axis.AxisState axisState13 = categoryAxis0.draw(graphics2D7, (double) 8, rectangle2D9, rectangle2D10, rectangleEdge11, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.awt.Color color0 = java.awt.Color.yellow;
        float[] floatArray2 = new float[] { (short) 1 };
        try {
            float[] floatArray3 = color0.getColorComponents(floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis1.java2DToValue((double) (short) 100, rectangle2D4, rectangleEdge5);
        dateAxis1.setLowerBound((double) (byte) 100);
        java.awt.Stroke stroke9 = dateAxis1.getAxisLineStroke();
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 9.223372036854776E18d + "'", double6 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color2 = java.awt.Color.WHITE;
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray4 = new java.awt.Paint[] { color0, color1, color2, color3 };
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color5, color6, color7, color8 };
        java.awt.Paint[] paintArray10 = null;
        java.awt.Stroke stroke11 = null;
        java.awt.Stroke[] strokeArray12 = new java.awt.Stroke[] { stroke11 };
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Shape shape15 = null;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] { shape15 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray4, paintArray9, paintArray10, strokeArray12, strokeArray14, shapeArray16);
        java.lang.Object obj18 = defaultDrawingSupplier17.clone();
        java.lang.Object obj19 = defaultDrawingSupplier17.clone();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(11);
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        try {
            objectList1.set((int) (short) -1, (java.lang.Object) textAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        try {
            java.awt.Color color1 = java.awt.Color.decode("DatasetRenderingOrder.REVERSE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"DatasetRenderingOrder.REVERSE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(4, (int) ' ', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.lang.Object obj0 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        categoryAxis0.setFixedDimension((double) 10.0f);
        boolean boolean4 = categoryAxis0.isTickMarksVisible();
        categoryAxis0.setTickMarksVisible(true);
        categoryAxis0.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.awt.Color color0 = java.awt.Color.darkGray;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 64 + "'", int1 == 64);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        boolean boolean2 = seriesRenderingOrder0.equals((java.lang.Object) 'a');
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.awt.Color color1 = java.awt.Color.red;
        java.awt.Stroke stroke2 = null;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 3.0d, (java.awt.Paint) color1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        java.lang.String str1 = seriesRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str1.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.lang.Object obj0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.configure();
        boolean boolean3 = dateAxis1.isAutoRange();
        org.jfree.data.Range range4 = dateAxis1.getDefaultAutoRange();
        double double5 = dateAxis1.getUpperBound();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        try {
            xYPlot0.handleClick((int) (short) 10, (int) (short) 1, plotRenderingInfo3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation31 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation31, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        double double4 = rectangleInsets2.calculateTopInset(0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color2 = java.awt.Color.WHITE;
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray4 = new java.awt.Paint[] { color0, color1, color2, color3 };
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color5, color6, color7, color8 };
        java.awt.Paint[] paintArray10 = null;
        java.awt.Stroke stroke11 = null;
        java.awt.Stroke[] strokeArray12 = new java.awt.Stroke[] { stroke11 };
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Shape shape15 = null;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] { shape15 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray4, paintArray9, paintArray10, strokeArray12, strokeArray14, shapeArray16);
        java.lang.Object obj18 = defaultDrawingSupplier17.clone();
        java.awt.Stroke stroke19 = defaultDrawingSupplier17.getNextStroke();
        try {
            java.awt.Paint paint20 = defaultDrawingSupplier17.getNextOutlinePaint();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNull(stroke19);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.awt.Color color0 = java.awt.Color.gray;
        java.lang.Object obj1 = null;
        boolean boolean2 = color0.equals(obj1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        org.jfree.data.RangeType rangeType2 = null;
        try {
            numberAxis1.setRangeType(rangeType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color2, color3, color4, color5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color7, color8, color9, color10 };
        java.awt.Paint[] paintArray12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke stroke15 = null;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        java.awt.Shape shape17 = null;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray14, strokeArray16, shapeArray18);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        categoryPlot0.setWeight((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        try {
            categoryPlot0.handleClick((int) (short) 0, (int) ' ', plotRenderingInfo25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(shapeArray18);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot0.getDomainAxisEdge((int) (byte) 0);
        categoryPlot0.clearDomainMarkers(4);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot0.getDomainAxisEdge((int) (byte) 0);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        boolean boolean32 = categoryPlot0.render(graphics2D28, rectangle2D29, 2, plotRenderingInfo31);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = null;
        try {
            dateAxis1.setTickMarkPosition(dateTickMarkPosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        categoryPlot0.setAnchorValue((double) 0, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection27 = categoryPlot0.getRangeMarkers(layer26);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent28);
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation30);
        boolean boolean32 = categoryPlot0.isRangeZoomable();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker8);
        boolean boolean10 = datasetRenderingOrder0.equals((java.lang.Object) valueMarker8);
        java.lang.Object obj11 = null;
        boolean boolean12 = datasetRenderingOrder0.equals(obj11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = categoryPlot13.getDomainAxis();
        java.awt.Paint paint16 = categoryPlot13.getBackgroundPaint();
        categoryPlot13.setAnchorValue((double) 0, true);
        double double20 = categoryPlot13.getRangeCrosshairValue();
        boolean boolean21 = datasetRenderingOrder0.equals((java.lang.Object) double20);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str1.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categoryAxis15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        xYPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE", timeZone1);
        boolean boolean3 = dateAxis2.isNegativeArrowVisible();
        try {
            dateAxis2.zoomRange((double) 100, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        xYPlot0.zoomRangeAxes((double) (short) 0, plotRenderingInfo32, point2D33, false);
        org.jfree.chart.axis.ValueAxis valueAxis36 = xYPlot0.getDomainAxis();
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        try {
            xYPlot0.drawOutline(graphics2D37, rectangle2D38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(valueAxis36);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        double double4 = rectangleInsets2.calculateBottomInset((double) 1);
        double double6 = rectangleInsets2.trimHeight((double) (-1));
        double double8 = rectangleInsets2.calculateRightInset((double) (short) -1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-7.0d) + "'", double6 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color2, color3, color4, color5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color7, color8, color9, color10 };
        java.awt.Paint[] paintArray12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke stroke15 = null;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        java.awt.Shape shape17 = null;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray14, strokeArray16, shapeArray18);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        categoryPlot0.zoomRangeAxes((double) 10L, 10.0d, plotRenderingInfo23, point2D24);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(shapeArray18);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(11);
        int int2 = objectList1.size();
        java.awt.Color color3 = java.awt.Color.YELLOW;
        boolean boolean4 = objectList1.equals((java.lang.Object) color3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getRangeAxis(1);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        xYPlot0.notifyListeners(plotChangeEvent7);
        java.lang.Object obj9 = xYPlot0.clone();
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        float float2 = categoryAxis0.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis4.getLabelInsets();
        double double7 = rectangleInsets5.calculateBottomInset((double) 1);
        double double9 = rectangleInsets5.trimHeight((double) (-1));
        categoryAxis0.setLabelInsets(rectangleInsets5);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.util.List list17 = null;
        xYPlot14.drawDomainTickBands(graphics2D15, rectangle2D16, list17);
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot14.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker22, layer23, true);
        xYPlot14.clearDomainAxes();
        boolean boolean27 = xYPlot14.isOutlineVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot14.getRangeAxisEdge(12);
        try {
            java.util.List list30 = categoryAxis0.refreshTicks(graphics2D11, axisState12, rectangle2D13, rectangleEdge29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-7.0d) + "'", double9 == (-7.0d));
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone2);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(tickUnitSource3);
        org.junit.Assert.assertNotNull(tickUnitSource4);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        java.lang.Object obj2 = numberAxis1.clone();
        org.jfree.data.RangeType rangeType3 = null;
        try {
            numberAxis1.setRangeType(rangeType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        java.awt.Color color27 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke29 = categoryAxis28.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color27, stroke29);
        categoryPlot0.setRangeGridlineStroke(stroke29);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke32);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation34 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke3 = intervalMarker2.getOutlineStroke();
        java.lang.String str4 = intervalMarker2.getLabel();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int int3 = java.awt.Color.HSBtoRGB((float) 0L, 2.0f, 10.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-245) + "'", int3 == (-245));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = null;
        try {
            categoryAxis0.setCategoryLabelPositions(categoryLabelPositions2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        categoryAxis0.setFixedDimension((double) 10.0f);
        boolean boolean4 = categoryAxis0.isTickMarksVisible();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.util.List list11 = null;
        xYPlot8.drawDomainTickBands(graphics2D9, rectangle2D10, list11);
        org.jfree.chart.plot.IntervalMarker intervalMarker16 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot8.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker16, layer17, true);
        xYPlot8.clearDomainAxes();
        boolean boolean21 = xYPlot8.isOutlineVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot8.getRangeAxisEdge(12);
        try {
            java.util.List list24 = categoryAxis0.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        java.awt.Color color27 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke29 = categoryAxis28.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color27, stroke29);
        categoryPlot0.setRangeGridlineStroke(stroke29);
        java.awt.Color color33 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke35 = categoryAxis34.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color33, stroke35);
        boolean boolean37 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker36);
        java.lang.Class class38 = null;
        try {
            java.util.EventListener[] eventListenerArray39 = valueMarker36.getListeners(class38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setTickMarksVisible(false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis0.getCategoryEnd((int) (byte) -1, 1, rectangle2D4, rectangleEdge5);
        java.lang.Comparable comparable7 = null;
        try {
            categoryAxis0.addCategoryLabelToolTip(comparable7, "DatasetRenderingOrder.REVERSE");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.configure();
        java.util.Date date3 = dateAxis1.getMaximumDate();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getRGBComponents(floatArray1);
        int int3 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot0.getDomainAxisEdge((int) (byte) 0);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        categoryPlot0.mapDatasetToRangeAxis(0, 100);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart41 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType42 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent43 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color40, jFreeChart41, chartChangeEventType42);
        java.awt.Stroke stroke44 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color40, stroke44);
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart48 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType49 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent50 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color47, jFreeChart48, chartChangeEventType49);
        java.awt.Stroke stroke51 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color47, stroke51);
        valueMarker45.setOutlineStroke(stroke51);
        java.awt.Color color54 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace55 = color54.getColorSpace();
        valueMarker45.setLabelPaint((java.awt.Paint) color54);
        org.jfree.chart.text.TextAnchor textAnchor57 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker45.setLabelTextAnchor(textAnchor57);
        org.jfree.chart.util.Layer layer59 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str60 = layer59.toString();
        boolean boolean62 = categoryPlot37.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker45, layer59, true);
        org.jfree.chart.util.Layer layer63 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean65 = xYPlot35.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker45, layer63, true);
        xYPlot35.setRangeGridlinesVisible(false);
        xYPlot35.setForegroundAlpha(0.0f);
        java.awt.geom.Point2D point2D70 = xYPlot35.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState71 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo72 = null;
        try {
            categoryPlot0.draw(graphics2D33, rectangle2D34, point2D70, plotState71, plotRenderingInfo72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(colorSpace55);
        org.junit.Assert.assertNotNull(textAnchor57);
        org.junit.Assert.assertNotNull(layer59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "Layer.FOREGROUND" + "'", str60.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(layer63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(point2D70);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        java.text.NumberFormat numberFormat2 = numberAxis1.getNumberFormatOverride();
        org.junit.Assert.assertNull(numberFormat2);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.awt.Color color0 = java.awt.Color.yellow;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-256) + "'", int1 == (-256));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int2 = color1.getTransparency();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke3);
        valueMarker4.setValue((double) (short) -1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color15, jFreeChart16, chartChangeEventType17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color15, stroke19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart23 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType24 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color22, jFreeChart23, chartChangeEventType24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color22, stroke26);
        valueMarker20.setOutlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace30 = color29.getColorSpace();
        valueMarker20.setLabelPaint((java.awt.Paint) color29);
        org.jfree.chart.text.TextAnchor textAnchor32 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker20.setLabelTextAnchor(textAnchor32);
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str35 = layer34.toString();
        boolean boolean37 = categoryPlot12.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker20, layer34, true);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot12.setRangeAxisLocation(axisLocation38);
        xYPlot0.setDomainAxisLocation(axisLocation38);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray41 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot0.setDomainAxes(valueAxisArray41);
        xYPlot0.mapDatasetToRangeAxis((int) (byte) 0, 0);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis48.setNegativeArrowVisible(true);
        float float51 = dateAxis48.getTickMarkOutsideLength();
        dateAxis48.setAutoRangeMinimumSize((double) 1);
        boolean boolean54 = dateAxis48.isAxisLineVisible();
        dateAxis48.setLabelToolTip("hi!");
        try {
            xYPlot0.setDomainAxis((-256), (org.jfree.chart.axis.ValueAxis) dateAxis48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(colorSpace30);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Layer.FOREGROUND" + "'", str35.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(valueAxisArray41);
        org.junit.Assert.assertTrue("'" + float51 + "' != '" + 2.0f + "'", float51 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        java.lang.Object obj2 = numberAxis1.clone();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.Color color1 = java.awt.Color.BLUE;
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color7, jFreeChart8, chartChangeEventType9);
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke11);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart15 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color14, jFreeChart15, chartChangeEventType16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color14, stroke18);
        valueMarker12.setOutlineStroke(stroke18);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace22 = color21.getColorSpace();
        valueMarker12.setLabelPaint((java.awt.Paint) color21);
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker12.setLabelTextAnchor(textAnchor24);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str27 = layer26.toString();
        boolean boolean29 = categoryPlot4.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker12, layer26, true);
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean32 = xYPlot2.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker12, layer30, true);
        xYPlot2.setRangeGridlinesVisible(false);
        java.awt.Stroke stroke35 = xYPlot2.getDomainGridlineStroke();
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart38 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType39 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent40 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color37, jFreeChart38, chartChangeEventType39);
        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color37, stroke41);
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart45 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType46 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent47 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color44, jFreeChart45, chartChangeEventType46);
        java.awt.Stroke stroke48 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker49 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color44, stroke48);
        valueMarker42.setOutlineStroke(stroke48);
        java.awt.Color color51 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace52 = color51.getColorSpace();
        valueMarker42.setLabelPaint((java.awt.Paint) color51);
        int int54 = color51.getGreen();
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker57 = new org.jfree.chart.plot.ValueMarker((double) 2.0f, (java.awt.Paint) color1, stroke35, (java.awt.Paint) color51, stroke55, 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(colorSpace22);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Layer.FOREGROUND" + "'", str27.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(colorSpace52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 255 + "'", int54 == 255);
        org.junit.Assert.assertNotNull(stroke55);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.Timeline timeline4 = null;
        dateAxis1.setTimeline(timeline4);
        dateAxis1.setLowerBound((double) (short) 10);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        boolean boolean2 = numberAxis1.getAutoRangeIncludesZero();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = numberAxis1.getMarkerBand();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.util.List list9 = null;
        xYPlot6.drawDomainTickBands(graphics2D7, rectangle2D8, list9);
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer15 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot6.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker14, layer15, true);
        xYPlot6.clearDomainAxes();
        boolean boolean19 = xYPlot6.isOutlineVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot6.getRangeAxisEdge(12);
        try {
            double double22 = numberAxis1.java2DToValue(0.2d, rectangle2D5, rectangleEdge21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(markerAxisBand3);
        org.junit.Assert.assertNotNull(layer15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.awt.Color color2 = java.awt.Color.getColor("DatasetRenderingOrder.REVERSE", 64);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        float float2 = categoryAxis0.getTickMarkOutsideLength();
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis0.setLabelFont(font3);
        double double5 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis0.getLabelInsets();
        double double7 = rectangleInsets6.getLeft();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.awt.Paint paint1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        java.awt.Color color29 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke31 = categoryAxis30.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color29, stroke31);
        categoryPlot2.setRangeGridlineStroke(stroke31);
        java.awt.Color color34 = java.awt.Color.RED;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart39 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType40 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent41 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color38, jFreeChart39, chartChangeEventType40);
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color38, stroke42);
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart46 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType47 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent48 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color45, jFreeChart46, chartChangeEventType47);
        java.awt.Stroke stroke49 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker50 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color45, stroke49);
        valueMarker43.setOutlineStroke(stroke49);
        java.awt.Color color52 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace53 = color52.getColorSpace();
        valueMarker43.setLabelPaint((java.awt.Paint) color52);
        org.jfree.chart.text.TextAnchor textAnchor55 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker43.setLabelTextAnchor(textAnchor55);
        org.jfree.chart.util.Layer layer57 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str58 = layer57.toString();
        boolean boolean60 = categoryPlot35.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker43, layer57, true);
        java.awt.Color color62 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke64 = categoryAxis63.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker65 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color62, stroke64);
        categoryPlot35.setRangeGridlineStroke(stroke64);
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker68 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 1, paint1, stroke31, (java.awt.Paint) color34, stroke64, (float) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(colorSpace53);
        org.junit.Assert.assertNotNull(textAnchor55);
        org.junit.Assert.assertNotNull(layer57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "Layer.FOREGROUND" + "'", str58.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(stroke64);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.setNegativeArrowVisible(true);
        float float4 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setLowerBound(100.0d);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.awt.Color color0 = java.awt.Color.lightGray;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        java.awt.Color color6 = java.awt.Color.red;
        float[] floatArray11 = new float[] { 100L, 10.0f, (-1), 0L };
        float[] floatArray12 = color6.getComponents(floatArray11);
        float[] floatArray13 = java.awt.Color.RGBtoHSB(100, (int) ' ', 0, floatArray11);
        float[] floatArray14 = color0.getColorComponents(colorSpace2, floatArray11);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        org.jfree.chart.LegendItemCollection legendItemCollection31 = null;
        xYPlot0.setFixedLegendItems(legendItemCollection31);
        java.util.List list33 = xYPlot0.getAnnotations();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(list33);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.setNegativeArrowVisible(true);
        java.awt.Shape shape4 = dateAxis1.getLeftArrow();
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color15, jFreeChart16, chartChangeEventType17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color15, stroke19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart23 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType24 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color22, jFreeChart23, chartChangeEventType24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color22, stroke26);
        valueMarker20.setOutlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace30 = color29.getColorSpace();
        valueMarker20.setLabelPaint((java.awt.Paint) color29);
        org.jfree.chart.text.TextAnchor textAnchor32 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker20.setLabelTextAnchor(textAnchor32);
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str35 = layer34.toString();
        boolean boolean37 = categoryPlot12.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker20, layer34, true);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot12.setRangeAxisLocation(axisLocation38);
        xYPlot0.setDomainAxisLocation(axisLocation38);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray41 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot0.setDomainAxes(valueAxisArray41);
        xYPlot0.mapDatasetToRangeAxis((int) (byte) 0, 0);
        int int46 = xYPlot0.getDomainAxisCount();
        xYPlot0.clearAnnotations();
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(colorSpace30);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Layer.FOREGROUND" + "'", str35.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(valueAxisArray41);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.String str1 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.RELATIVE" + "'", str1.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setLabelToolTip("hi!");
        categoryAxis1.setLabel("");
        boolean boolean7 = layer0.equals((java.lang.Object) categoryAxis1);
        categoryAxis1.setLabel("");
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 2);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE", timeZone1);
        boolean boolean3 = dateAxis2.isNegativeArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis5.configure();
        boolean boolean7 = dateAxis5.isAutoRange();
        org.jfree.data.time.DateRange dateRange8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange8);
        dateAxis2.setRange((org.jfree.data.Range) dateRange8);
        java.awt.Shape shape11 = dateAxis2.getUpArrow();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone14 = dateAxis13.getTimeZone();
        dateAxis13.setRange((double) (short) 0, (double) (short) 10);
        boolean boolean19 = dateAxis13.isHiddenValue((long) 10);
        org.jfree.chart.plot.Plot plot20 = dateAxis13.getPlot();
        java.util.Date date21 = dateAxis13.getMaximumDate();
        org.jfree.data.Range range22 = dateAxis13.getDefaultAutoRange();
        dateAxis2.setRangeWithMargins(range22);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateRange8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(plot20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(range22);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        java.awt.Font font31 = xYPlot0.getNoDataMessageFont();
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot0.getRangeAxis((int) (byte) 1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNull(valueAxis33);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color4, jFreeChart5, chartChangeEventType6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color4, stroke8);
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke12 = categoryAxis11.getTickMarkStroke();
        categoryAxis11.setLabelToolTip("hi!");
        categoryAxis11.setLabel("");
        boolean boolean17 = layer10.equals((java.lang.Object) categoryAxis11);
        boolean boolean18 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9, layer10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot0.setRenderer(categoryItemRenderer19, false);
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace22);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke26 = categoryAxis25.getTickMarkStroke();
        float float27 = categoryAxis25.getTickMarkOutsideLength();
        categoryAxis25.setAxisLineVisible(true);
        categoryPlot0.setDomainAxis(11, categoryAxis25, false);
        org.jfree.chart.util.SortOrder sortOrder32 = null;
        try {
            categoryPlot0.setColumnRenderingOrder(sortOrder32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(layer10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 2.0f + "'", float27 == 2.0f);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.util.List list10 = null;
        xYPlot7.drawDomainTickBands(graphics2D8, rectangle2D9, list10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot7.getRangeAxisEdge((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        try {
            org.jfree.chart.axis.AxisState axisState15 = dateAxis1.draw(graphics2D3, (double) 128, rectangle2D5, rectangle2D6, rectangleEdge13, plotRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        float float2 = categoryAxis0.getTickMarkOutsideLength();
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis0.setLabelFont(font3);
        double double5 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis0.getLabelInsets();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color15, jFreeChart16, chartChangeEventType17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color15, stroke19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart23 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType24 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color22, jFreeChart23, chartChangeEventType24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color22, stroke26);
        valueMarker20.setOutlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace30 = color29.getColorSpace();
        valueMarker20.setLabelPaint((java.awt.Paint) color29);
        org.jfree.chart.text.TextAnchor textAnchor32 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker20.setLabelTextAnchor(textAnchor32);
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str35 = layer34.toString();
        boolean boolean37 = categoryPlot12.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker20, layer34, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot12.getDomainAxisEdge((int) (byte) 0);
        try {
            double double40 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) 10.0f, (java.lang.Comparable) 0.2d, categoryDataset9, (double) 0, rectangle2D11, rectangleEdge39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(colorSpace30);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Layer.FOREGROUND" + "'", str35.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        xYPlot0.setRangeGridlinesVisible(false);
        xYPlot0.setForegroundAlpha(0.0f);
        java.awt.Stroke stroke35 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setDomainZeroBaselineStroke(stroke35);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str1.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color2, color3, color4, color5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color7, color8, color9, color10 };
        java.awt.Paint[] paintArray12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke stroke15 = null;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        java.awt.Shape shape17 = null;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray14, strokeArray16, shapeArray18);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        categoryPlot0.setWeight((int) (byte) 10);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        try {
            categoryPlot0.handleClick((-256), (-245), plotRenderingInfo27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(shapeArray18);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int1 = color0.getTransparency();
        int int2 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test146");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getMiddleMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color2, jFreeChart3, chartChangeEventType4);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color2, stroke6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) 11, (java.awt.Paint) color2, stroke8);
        int int10 = color2.getBlue();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 128 + "'", int10 == 128);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke3 = intervalMarker2.getOutlineStroke();
        intervalMarker2.setStartValue((double) 2.0f);
        intervalMarker2.setEndValue(4.0d);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        org.jfree.chart.LegendItemCollection legendItemCollection31 = null;
        xYPlot0.setFixedLegendItems(legendItemCollection31);
        xYPlot0.setRangeCrosshairLockedOnData(false);
        java.awt.Stroke stroke35 = xYPlot0.getOutlineStroke();
        int int36 = xYPlot0.getDatasetCount();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        java.awt.Color color5 = java.awt.Color.yellow;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart15 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color14, jFreeChart15, chartChangeEventType16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color14, stroke18);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart22 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color21, jFreeChart22, chartChangeEventType23);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color21, stroke25);
        valueMarker19.setOutlineStroke(stroke25);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace29 = color28.getColorSpace();
        valueMarker19.setLabelPaint((java.awt.Paint) color28);
        org.jfree.chart.text.TextAnchor textAnchor31 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker19.setLabelTextAnchor(textAnchor31);
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str34 = layer33.toString();
        boolean boolean36 = categoryPlot11.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker19, layer33, true);
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean39 = xYPlot9.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker19, layer37, true);
        xYPlot9.setRangeGridlinesVisible(false);
        xYPlot9.setForegroundAlpha(0.0f);
        java.awt.geom.Point2D point2D44 = xYPlot9.getQuadrantOrigin();
        xYPlot0.zoomRangeAxes((double) (byte) 1, plotRenderingInfo8, point2D44, false);
        xYPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(colorSpace29);
        org.junit.Assert.assertNotNull(textAnchor31);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Layer.FOREGROUND" + "'", str34.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(point2D44);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        dateAxis1.setRange((double) (short) 0, (double) (short) 10);
        boolean boolean7 = dateAxis1.isHiddenValue((long) 10);
        org.jfree.data.Range range8 = dateAxis1.getDefaultAutoRange();
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        java.awt.Color color27 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke29 = categoryAxis28.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color27, stroke29);
        categoryPlot0.setRangeGridlineStroke(stroke29);
        java.awt.Paint paint32 = null;
        try {
            categoryPlot0.setDomainGridlinePaint(paint32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 192 + "'", int1 == 192);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset(11.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftInset(100.0d);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis2.configure();
        boolean boolean4 = dateAxis2.isAutoRange();
        java.awt.Shape shape5 = dateAxis2.getLeftArrow();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = dateAxis2.java2DToValue((double) 0.0f, rectangle2D7, rectangleEdge8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone12 = dateAxis11.getTimeZone();
        dateAxis2.setTimeZone(timeZone12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date0, timeZone12);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = day14.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(timeZone12);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent9 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker8);
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke12 = categoryAxis11.getTickMarkStroke();
        categoryAxis11.setLabelToolTip("hi!");
        categoryAxis11.setLabel("");
        boolean boolean17 = layer10.equals((java.lang.Object) categoryAxis11);
        boolean boolean18 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker8, layer10);
        float float19 = categoryPlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(layer10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.5f + "'", float19 == 0.5f);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        double double4 = rectangleInsets2.calculateBottomInset((double) 1);
        double double6 = rectangleInsets2.trimHeight((double) (-1));
        double double8 = rectangleInsets2.calculateBottomInset((double) 'a');
        double double9 = rectangleInsets2.getLeft();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets2.createOutsetRectangle(rectangle2D10, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-7.0d) + "'", double6 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM" + "'", str1.equals("RectangleAnchor.BOTTOM"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color2 = java.awt.Color.red;
        float[] floatArray7 = new float[] { 100L, 10.0f, (-1), 0L };
        float[] floatArray8 = color2.getComponents(floatArray7);
        float[] floatArray9 = color1.getComponents(floatArray7);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color13, jFreeChart14, chartChangeEventType15);
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color13, stroke17);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart21 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType22 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color20, jFreeChart21, chartChangeEventType22);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color20, stroke24);
        valueMarker18.setOutlineStroke(stroke24);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace28 = color27.getColorSpace();
        valueMarker18.setLabelPaint((java.awt.Paint) color27);
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker18.setLabelTextAnchor(textAnchor30);
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str33 = layer32.toString();
        boolean boolean35 = categoryPlot10.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker18, layer32, true);
        java.awt.Color color37 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke39 = categoryAxis38.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color37, stroke39);
        categoryPlot10.setRangeGridlineStroke(stroke39);
        org.jfree.chart.plot.CategoryMarker categoryMarker42 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) ' ', (java.awt.Paint) color1, stroke39);
        java.lang.Comparable comparable43 = categoryMarker42.getKey();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(colorSpace28);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Layer.FOREGROUND" + "'", str33.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + comparable43 + "' != '" + ' ' + "'", comparable43.equals(' '));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color1, jFreeChart2, chartChangeEventType3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke5);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color8, jFreeChart9, chartChangeEventType10);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color8, stroke12);
        valueMarker6.setOutlineStroke(stroke12);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace16 = color15.getColorSpace();
        valueMarker6.setLabelPaint((java.awt.Paint) color15);
        java.lang.Class class18 = null;
        try {
            java.util.EventListener[] eventListenerArray19 = valueMarker6.getListeners(class18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(colorSpace16);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color2, color3, color4, color5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color7, color8, color9, color10 };
        java.awt.Paint[] paintArray12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke stroke15 = null;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        java.awt.Shape shape17 = null;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray14, strokeArray16, shapeArray18);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        categoryPlot0.setWeight((int) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot0.getDomainAxis();
        java.awt.Paint paint24 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace27 = categoryPlot26.getFixedDomainAxisSpace();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color30 = java.awt.Color.WHITE;
        java.awt.Color color31 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray32 = new java.awt.Paint[] { color28, color29, color30, color31 };
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray37 = new java.awt.Paint[] { color33, color34, color35, color36 };
        java.awt.Paint[] paintArray38 = null;
        java.awt.Stroke stroke39 = null;
        java.awt.Stroke[] strokeArray40 = new java.awt.Stroke[] { stroke39 };
        java.awt.Stroke stroke41 = null;
        java.awt.Stroke[] strokeArray42 = new java.awt.Stroke[] { stroke41 };
        java.awt.Shape shape43 = null;
        java.awt.Shape[] shapeArray44 = new java.awt.Shape[] { shape43 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier45 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray32, paintArray37, paintArray38, strokeArray40, strokeArray42, shapeArray44);
        categoryPlot26.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier45);
        categoryPlot26.setWeight((int) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = categoryPlot26.getDomainAxis();
        java.awt.Paint paint50 = categoryPlot26.getRangeCrosshairPaint();
        java.awt.Color color52 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color53 = java.awt.Color.red;
        float[] floatArray58 = new float[] { 100L, 10.0f, (-1), 0L };
        float[] floatArray59 = color53.getComponents(floatArray58);
        float[] floatArray60 = color52.getComponents(floatArray58);
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color64 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart65 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType66 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent67 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color64, jFreeChart65, chartChangeEventType66);
        java.awt.Stroke stroke68 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker69 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color64, stroke68);
        java.awt.Color color71 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart72 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType73 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent74 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color71, jFreeChart72, chartChangeEventType73);
        java.awt.Stroke stroke75 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker76 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color71, stroke75);
        valueMarker69.setOutlineStroke(stroke75);
        java.awt.Color color78 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace79 = color78.getColorSpace();
        valueMarker69.setLabelPaint((java.awt.Paint) color78);
        org.jfree.chart.text.TextAnchor textAnchor81 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker69.setLabelTextAnchor(textAnchor81);
        org.jfree.chart.util.Layer layer83 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str84 = layer83.toString();
        boolean boolean86 = categoryPlot61.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker69, layer83, true);
        java.awt.Color color88 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis89 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke90 = categoryAxis89.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker91 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color88, stroke90);
        categoryPlot61.setRangeGridlineStroke(stroke90);
        org.jfree.chart.plot.CategoryMarker categoryMarker93 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) ' ', (java.awt.Paint) color52, stroke90);
        categoryPlot26.addDomainMarker(categoryMarker93);
        org.jfree.chart.util.Layer layer95 = null;
        try {
            categoryPlot0.addDomainMarker((int) (byte) 100, categoryMarker93, layer95, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(axisSpace27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(paintArray32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paintArray37);
        org.junit.Assert.assertNotNull(strokeArray40);
        org.junit.Assert.assertNotNull(strokeArray42);
        org.junit.Assert.assertNotNull(shapeArray44);
        org.junit.Assert.assertNull(categoryAxis49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertNotNull(floatArray60);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNotNull(color78);
        org.junit.Assert.assertNotNull(colorSpace79);
        org.junit.Assert.assertNotNull(textAnchor81);
        org.junit.Assert.assertNotNull(layer83);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "Layer.FOREGROUND" + "'", str84.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(color88);
        org.junit.Assert.assertNotNull(stroke90);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        java.awt.Color color27 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke29 = categoryAxis28.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color27, stroke29);
        categoryPlot0.setRangeGridlineStroke(stroke29);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke32);
        categoryPlot0.setRangeCrosshairValue((double) 64, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke38 = categoryAxis37.getTickMarkStroke();
        categoryAxis37.setFixedDimension((double) 10.0f);
        boolean boolean41 = categoryAxis37.isTickMarksVisible();
        categoryAxis37.setTickMarksVisible(true);
        categoryAxis37.setTickMarkInsideLength((float) 1);
        categoryPlot0.setDomainAxis(categoryAxis37);
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        java.util.List list53 = null;
        xYPlot50.drawDomainTickBands(graphics2D51, rectangle2D52, list53);
        org.jfree.chart.plot.IntervalMarker intervalMarker58 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer59 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot50.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker58, layer59, true);
        xYPlot50.clearDomainAxes();
        boolean boolean63 = xYPlot50.isOutlineVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = xYPlot50.getRangeAxisEdge(12);
        try {
            double double66 = categoryAxis37.getCategoryEnd((-245), (int) (short) 1, rectangle2D49, rectangleEdge65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(layer59);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(rectangleEdge65);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        java.util.List list12 = xYPlot0.getAnnotations();
        boolean boolean13 = xYPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation26);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = categoryPlot0.getDomainAxisForDataset(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart35 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType36 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent37 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color34, jFreeChart35, chartChangeEventType36);
        java.awt.Stroke stroke38 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color34, stroke38);
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart42 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType43 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent44 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color41, jFreeChart42, chartChangeEventType43);
        java.awt.Stroke stroke45 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color41, stroke45);
        valueMarker39.setOutlineStroke(stroke45);
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace49 = color48.getColorSpace();
        valueMarker39.setLabelPaint((java.awt.Paint) color48);
        org.jfree.chart.text.TextAnchor textAnchor51 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker39.setLabelTextAnchor(textAnchor51);
        org.jfree.chart.util.Layer layer53 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str54 = layer53.toString();
        boolean boolean56 = categoryPlot31.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker39, layer53, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = categoryPlot31.getDomainAxisEdge((int) (byte) 0);
        categoryPlot31.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisLocation axisLocation62 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot31.setRangeAxisLocation((int) (byte) 0, axisLocation62, true);
        try {
            categoryPlot0.setDomainAxisLocation((int) (short) -1, axisLocation62);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNull(categoryAxis29);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(colorSpace49);
        org.junit.Assert.assertNotNull(textAnchor51);
        org.junit.Assert.assertNotNull(layer53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Layer.FOREGROUND" + "'", str54.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertNotNull(axisLocation62);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        xYPlot0.zoomRangeAxes((double) (short) 0, plotRenderingInfo32, point2D33, false);
        org.jfree.chart.axis.ValueAxis valueAxis36 = xYPlot0.getDomainAxis();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        int int38 = xYPlot0.indexOf(xYDataset37);
        org.jfree.chart.util.Layer layer40 = null;
        java.util.Collection collection41 = xYPlot0.getDomainMarkers(0, layer40);
        java.awt.Paint paint42 = xYPlot0.getRangeCrosshairPaint();
        java.awt.Stroke stroke43 = xYPlot0.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(valueAxis36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(stroke43);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color1, jFreeChart2, chartChangeEventType3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke5);
        double double7 = valueMarker6.getValue();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.configure();
        boolean boolean3 = dateAxis1.isAutoRange();
        java.awt.Shape shape4 = dateAxis1.getLeftArrow();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = dateAxis1.java2DToValue((double) 0.0f, rectangle2D6, rectangleEdge7);
        dateAxis1.setRangeWithMargins((double) 2.0f, (double) 12);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis13.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font17 = categoryAxis15.getTickLabelFont((java.lang.Comparable) 4);
        dateAxis13.setTickLabelFont(font17);
        dateAxis1.setLabelFont(font17);
        java.lang.String str20 = dateAxis1.getLabel();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str20.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis(128);
        categoryPlot0.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNull(valueAxis3);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        xYPlot0.clearDomainAxes();
        boolean boolean13 = xYPlot0.isOutlineVisible();
        double double14 = xYPlot0.getRangeCrosshairValue();
        java.awt.Paint paint15 = xYPlot0.getRangeTickBandPaint();
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(paint15);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color8, jFreeChart9, chartChangeEventType10);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color8, stroke12);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color15, jFreeChart16, chartChangeEventType17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color15, stroke19);
        valueMarker13.setOutlineStroke(stroke19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace23 = color22.getColorSpace();
        valueMarker13.setLabelPaint((java.awt.Paint) color22);
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker13.setLabelTextAnchor(textAnchor25);
        org.jfree.chart.util.Layer layer27 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str28 = layer27.toString();
        boolean boolean30 = categoryPlot5.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker13, layer27, true);
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean33 = xYPlot3.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker13, layer31, true);
        java.awt.Font font34 = xYPlot3.getNoDataMessageFont();
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 64, font34);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        java.util.List list40 = null;
        xYPlot37.drawDomainTickBands(graphics2D38, rectangle2D39, list40);
        org.jfree.chart.plot.IntervalMarker intervalMarker45 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer46 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot37.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker45, layer46, true);
        java.awt.Color color51 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart52 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType53 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent54 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color51, jFreeChart52, chartChangeEventType53);
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker56 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color51, stroke55);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent57 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker56);
        org.jfree.chart.text.TextAnchor textAnchor58 = valueMarker56.getLabelTextAnchor();
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace60 = categoryPlot59.getFixedDomainAxisSpace();
        java.awt.Color color62 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart63 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType64 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent65 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color62, jFreeChart63, chartChangeEventType64);
        java.awt.Stroke stroke66 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker67 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color62, stroke66);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent68 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker67);
        org.jfree.chart.util.Layer layer69 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis70 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke71 = categoryAxis70.getTickMarkStroke();
        categoryAxis70.setLabelToolTip("hi!");
        categoryAxis70.setLabel("");
        boolean boolean76 = layer69.equals((java.lang.Object) categoryAxis70);
        boolean boolean77 = categoryPlot59.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker67, layer69);
        xYPlot37.addDomainMarker(3, (org.jfree.chart.plot.Marker) valueMarker56, layer69);
        java.awt.geom.Rectangle2D rectangle2D79 = null;
        org.jfree.chart.plot.XYPlot xYPlot80 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D81 = null;
        java.awt.geom.Rectangle2D rectangle2D82 = null;
        java.util.List list83 = null;
        xYPlot80.drawDomainTickBands(graphics2D81, rectangle2D82, list83);
        org.jfree.chart.plot.IntervalMarker intervalMarker88 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer89 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot80.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker88, layer89, true);
        xYPlot80.clearDomainAxes();
        boolean boolean93 = xYPlot80.isOutlineVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge95 = xYPlot80.getRangeAxisEdge(12);
        org.jfree.chart.axis.AxisSpace axisSpace96 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace97 = categoryAxis0.reserveSpace(graphics2D36, (org.jfree.chart.plot.Plot) xYPlot37, rectangle2D79, rectangleEdge95, axisSpace96);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(colorSpace23);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNotNull(layer27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Layer.FOREGROUND" + "'", str28.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(layer46);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(textAnchor58);
        org.junit.Assert.assertNull(axisSpace60);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(layer69);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(layer89);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertNotNull(rectangleEdge95);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis1.java2DToValue((double) (short) 100, rectangle2D4, rectangleEdge5);
        dateAxis1.setAutoRangeMinimumSize((double) 1, true);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color15, jFreeChart16, chartChangeEventType17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color15, stroke19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart23 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType24 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color22, jFreeChart23, chartChangeEventType24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color22, stroke26);
        valueMarker20.setOutlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace30 = color29.getColorSpace();
        valueMarker20.setLabelPaint((java.awt.Paint) color29);
        org.jfree.chart.text.TextAnchor textAnchor32 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker20.setLabelTextAnchor(textAnchor32);
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str35 = layer34.toString();
        boolean boolean37 = categoryPlot12.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker20, layer34, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot12.getDomainAxisEdge((int) (byte) 0);
        try {
            double double40 = dateAxis1.lengthToJava2D((double) 100, rectangle2D11, rectangleEdge39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 9.223372036854776E18d + "'", double6 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(colorSpace30);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Layer.FOREGROUND" + "'", str35.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) (byte) 10, valueAxis3);
        java.awt.Paint paint5 = categoryPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        xYPlot0.clearDomainAxes();
        boolean boolean13 = xYPlot0.isOutlineVisible();
        double double14 = xYPlot0.getRangeCrosshairValue();
        xYPlot0.configureRangeAxes();
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.setNegativeArrowVisible(true);
        float float4 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setAutoRangeMinimumSize((double) 1);
        boolean boolean7 = dateAxis1.isAxisLineVisible();
        dateAxis1.setLowerBound(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        dateAxis1.setTickLabelInsets(rectangleInsets10);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = null;
        try {
            dateAxis1.setTickMarkPosition(dateTickMarkPosition12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        categoryAxis0.setFixedDimension((double) 10.0f);
        float float4 = categoryAxis0.getTickMarkInsideLength();
        int int5 = categoryAxis0.getCategoryLabelPositionOffset();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        boolean boolean5 = xYPlot0.isOutlineVisible();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color1, jFreeChart2);
        java.lang.Object obj4 = chartChangeEvent3.getSource();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        chartChangeEvent3.setType(chartChangeEventType5);
        boolean boolean7 = chartChangeEventType0.equals((java.lang.Object) chartChangeEventType5);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        float float2 = categoryAxis0.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis4.getLabelInsets();
        double double7 = rectangleInsets5.calculateBottomInset((double) 1);
        double double9 = rectangleInsets5.trimHeight((double) (-1));
        categoryAxis0.setLabelInsets(rectangleInsets5);
        org.jfree.chart.util.UnitType unitType11 = rectangleInsets5.getUnitType();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        java.lang.Object obj14 = numberAxis13.clone();
        boolean boolean15 = unitType11.equals(obj14);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-7.0d) + "'", double9 == (-7.0d));
        org.junit.Assert.assertNotNull(unitType11);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        float float2 = categoryAxis0.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis4.getLabelInsets();
        double double7 = rectangleInsets5.calculateBottomInset((double) 1);
        double double9 = rectangleInsets5.trimHeight((double) (-1));
        categoryAxis0.setLabelInsets(rectangleInsets5);
        org.jfree.chart.util.UnitType unitType11 = rectangleInsets5.getUnitType();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets5.createInsetRectangle(rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-7.0d) + "'", double9 == (-7.0d));
        org.junit.Assert.assertNotNull(unitType11);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        xYPlot0.zoomRangeAxes((double) (short) 0, plotRenderingInfo32, point2D33, false);
        org.jfree.chart.axis.ValueAxis valueAxis36 = xYPlot0.getDomainAxis();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        int int38 = xYPlot0.indexOf(xYDataset37);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent39 = null;
        xYPlot0.rendererChanged(rendererChangeEvent39);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(valueAxis36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setLabelToolTip("hi!");
        categoryAxis1.setLabel("");
        boolean boolean7 = layer0.equals((java.lang.Object) categoryAxis1);
        categoryAxis1.setLowerMargin((double) 0L);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.Plot plot11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.util.List list16 = null;
        xYPlot13.drawDomainTickBands(graphics2D14, rectangle2D15, list16);
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot13.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker21, layer22, true);
        xYPlot13.clearDomainAxes();
        boolean boolean26 = xYPlot13.isOutlineVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot13.getRangeAxisEdge(12);
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace30 = categoryAxis1.reserveSpace(graphics2D10, plot11, rectangle2D12, rectangleEdge28, axisSpace29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getRangeAxis(1);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        xYPlot0.notifyListeners(plotChangeEvent7);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis10.setNegativeArrowVisible(true);
        float float13 = dateAxis10.getTickMarkOutsideLength();
        dateAxis10.setAutoRangeMinimumSize((double) 1);
        boolean boolean16 = dateAxis10.isAxisLineVisible();
        dateAxis10.setRangeAboutValue((double) 10L, 0.05d);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis10);
        java.awt.Color color21 = java.awt.Color.orange;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color21);
        boolean boolean23 = xYPlot0.isDomainZeroBaselineVisible();
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.junit.Assert.assertNotNull(numberTickUnit0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke6 = intervalMarker5.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot7.getDomainAxis();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart12, chartChangeEventType13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke19 = categoryAxis18.getTickMarkStroke();
        categoryAxis18.setLabelToolTip("hi!");
        categoryAxis18.setLabel("");
        boolean boolean24 = layer17.equals((java.lang.Object) categoryAxis18);
        boolean boolean25 = categoryPlot7.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker16, layer17);
        boolean boolean26 = categoryPlot0.removeDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) intervalMarker5, layer17);
        categoryPlot0.clearRangeAxes();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot0.getDomainAxisEdge((int) (byte) 0);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.AxisLocation axisLocation31 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation((int) (byte) 0, axisLocation31, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation34 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation31, plotOrientation34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(axisLocation31);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EXPAND" + "'", str1.equals("EXPAND"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation26);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = categoryPlot0.getDomainAxisForDataset(0);
        org.jfree.chart.axis.AxisLocation axisLocation30 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation31 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation30, plotOrientation31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNull(categoryAxis29);
        org.junit.Assert.assertNotNull(axisLocation30);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        xYPlot0.setDataset(xYDataset2);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(11.0d);
        java.awt.Stroke stroke2 = valueMarker1.getStroke();
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        categoryAxis0.setFixedDimension((double) 10.0f);
        boolean boolean4 = categoryAxis0.isTickMarksVisible();
        categoryAxis0.setTickMarksVisible(true);
        categoryAxis0.setTickMarkInsideLength((float) 1);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.util.List list12 = null;
        xYPlot9.drawDomainTickBands(graphics2D10, rectangle2D11, list12);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot9.getRangeAxis(1);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = null;
        xYPlot9.notifyListeners(plotChangeEvent16);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis19.setNegativeArrowVisible(true);
        float float22 = dateAxis19.getTickMarkOutsideLength();
        dateAxis19.setAutoRangeMinimumSize((double) 1);
        boolean boolean25 = dateAxis19.isAxisLineVisible();
        dateAxis19.setRangeAboutValue((double) 10L, 0.05d);
        xYPlot9.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis19);
        java.util.Date date30 = dateAxis19.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis32.configure();
        boolean boolean34 = dateAxis32.isAutoRange();
        java.awt.Font font35 = dateAxis32.getLabelFont();
        categoryAxis0.setTickLabelFont((java.lang.Comparable) date30, font35);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 2.0f + "'", float22 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(font35);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE", timeZone1);
        java.util.TimeZone timeZone3 = null;
        try {
            dateAxis2.setTimeZone(timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        org.jfree.chart.LegendItemCollection legendItemCollection31 = null;
        xYPlot0.setFixedLegendItems(legendItemCollection31);
        xYPlot0.setRangeCrosshairLockedOnData(false);
        boolean boolean35 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint37 = xYPlot0.getQuadrantPaint((int) (byte) 0);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis39 = xYPlot0.getDomainAxisForDataset((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 10 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(paint37);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftInset(100.0d);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            rectangleInsets0.trim(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.setNegativeArrowVisible(true);
        java.awt.Shape shape4 = dateAxis1.getUpArrow();
        dateAxis1.setLabelURL("");
        java.lang.Object obj7 = dateAxis1.clone();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        java.util.List list12 = dateAxis1.refreshTicks(graphics2D8, axisState9, rectangle2D10, rectangleEdge11);
        try {
            dateAxis1.setAutoRangeMinimumSize(0.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(list12);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.setNegativeArrowVisible(true);
        float float4 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setAutoRangeMinimumSize((double) 1);
        org.jfree.chart.axis.DateTickUnit dateTickUnit7 = dateAxis1.getTickUnit();
        dateAxis1.setLowerBound((double) (short) 0);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(dateTickUnit7);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        try {
            java.awt.Color color1 = java.awt.Color.decode("SeriesRenderingOrder.REVERSE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SeriesRenderingOrder.REVERSE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        java.awt.Color color5 = java.awt.Color.yellow;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int8 = color7.getTransparency();
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color7);
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot0.getDomainAxis((int) (byte) 100);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(valueAxis11);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        java.awt.Color color27 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke29 = categoryAxis28.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color27, stroke29);
        categoryPlot0.setRangeGridlineStroke(stroke29);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke32);
        float float34 = categoryPlot0.getForegroundAlpha();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 1.0f + "'", float34 == 1.0f);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone7 = dateAxis6.getTimeZone();
        dateAxis6.setRange((double) (short) 0, (double) (short) 10);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis6);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color15 = java.awt.Color.WHITE;
        java.awt.Color color16 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray17 = new java.awt.Paint[] { color13, color14, color15, color16 };
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray22 = new java.awt.Paint[] { color18, color19, color20, color21 };
        java.awt.Paint[] paintArray23 = null;
        java.awt.Stroke stroke24 = null;
        java.awt.Stroke[] strokeArray25 = new java.awt.Stroke[] { stroke24 };
        java.awt.Stroke stroke26 = null;
        java.awt.Stroke[] strokeArray27 = new java.awt.Stroke[] { stroke26 };
        java.awt.Shape shape28 = null;
        java.awt.Shape[] shapeArray29 = new java.awt.Shape[] { shape28 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray17, paintArray22, paintArray23, strokeArray25, strokeArray27, shapeArray29);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart35 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType36 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent37 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color34, jFreeChart35, chartChangeEventType36);
        java.awt.Stroke stroke38 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color34, stroke38);
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart42 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType43 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent44 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color41, jFreeChart42, chartChangeEventType43);
        java.awt.Stroke stroke45 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color41, stroke45);
        valueMarker39.setOutlineStroke(stroke45);
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace49 = color48.getColorSpace();
        valueMarker39.setLabelPaint((java.awt.Paint) color48);
        org.jfree.chart.text.TextAnchor textAnchor51 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker39.setLabelTextAnchor(textAnchor51);
        org.jfree.chart.util.Layer layer53 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str54 = layer53.toString();
        boolean boolean56 = categoryPlot31.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker39, layer53, true);
        org.jfree.chart.axis.AxisLocation axisLocation57 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot31.setRangeAxisLocation(axisLocation57);
        boolean boolean59 = defaultDrawingSupplier30.equals((java.lang.Object) axisLocation57);
        try {
            xYPlot0.setRangeAxisLocation((int) (short) -1, axisLocation57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNotNull(shapeArray29);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(colorSpace49);
        org.junit.Assert.assertNotNull(textAnchor51);
        org.junit.Assert.assertNotNull(layer53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Layer.FOREGROUND" + "'", str54.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(axisLocation57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.configure();
        boolean boolean3 = dateAxis1.isAutoRange();
        java.awt.Shape shape4 = dateAxis1.getLeftArrow();
        java.lang.String str5 = dateAxis1.getLabelURL();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot0.getDomainAxisEdge((int) (byte) 0);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        java.awt.Color color30 = java.awt.Color.PINK;
        java.awt.Color color31 = color30.brighter();
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color31);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis34.setNegativeArrowVisible(true);
        float float37 = dateAxis34.getTickMarkOutsideLength();
        dateAxis34.setAutoRangeMinimumSize((double) 1);
        boolean boolean40 = dateAxis34.isAxisLineVisible();
        dateAxis34.setLabelToolTip("hi!");
        int int43 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis34);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 2.0f + "'", float37 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        float float3 = intervalMarker2.getAlpha();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = intervalMarker2.getGradientPaintTransformer();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.8f + "'", float3 == 0.8f);
        org.junit.Assert.assertNull(gradientPaintTransformer4);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getRangeAxis(1);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone9 = dateAxis8.getTimeZone();
        dateAxis8.setRange((double) (short) 0, (double) (short) 10);
        boolean boolean13 = dateAxis8.isVerticalTickLabels();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis8);
        xYPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkOutsideLength((float) (byte) 100);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color17, jFreeChart18, chartChangeEventType19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color17, stroke21);
        valueMarker15.setOutlineStroke(stroke21);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace25 = color24.getColorSpace();
        valueMarker15.setLabelPaint((java.awt.Paint) color24);
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker15.setLabelTextAnchor(textAnchor27);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str30 = layer29.toString();
        boolean boolean32 = categoryPlot7.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker15, layer29, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = categoryPlot7.getDomainAxisEdge((int) (byte) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        try {
            org.jfree.chart.axis.AxisState axisState36 = categoryAxis0.draw(graphics2D3, (double) 1L, rectangle2D5, rectangle2D6, rectangleEdge34, plotRenderingInfo35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(colorSpace25);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Layer.FOREGROUND" + "'", str30.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleEdge34);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        java.awt.Color color27 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke29 = categoryAxis28.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color27, stroke29);
        categoryPlot0.setRangeGridlineStroke(stroke29);
        java.awt.Color color33 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke35 = categoryAxis34.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color33, stroke35);
        boolean boolean37 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker36);
        org.jfree.chart.text.TextAnchor textAnchor38 = valueMarker36.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(textAnchor38);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot0.getRangeAxisEdge((int) (short) 0);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        xYPlot0.notifyListeners(plotChangeEvent7);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = xYPlot0.getRenderer((int) (byte) -1);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        xYPlot0.setInsets(rectangleInsets11);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D14 = rectangleInsets11.createOutsetRectangle(rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(xYItemRenderer10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test220");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
//        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        org.jfree.chart.JFreeChart jFreeChart7 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color6, jFreeChart7, chartChangeEventType8);
//        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color6, stroke10);
//        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        org.jfree.chart.JFreeChart jFreeChart14 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color13, jFreeChart14, chartChangeEventType15);
//        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color13, stroke17);
//        valueMarker11.setOutlineStroke(stroke17);
//        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        java.awt.color.ColorSpace colorSpace21 = color20.getColorSpace();
//        valueMarker11.setLabelPaint((java.awt.Paint) color20);
//        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
//        valueMarker11.setLabelTextAnchor(textAnchor23);
//        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.FOREGROUND;
//        java.lang.String str26 = layer25.toString();
//        boolean boolean28 = categoryPlot3.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker11, layer25, true);
//        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot3.getDomainAxisEdge((int) (byte) 0);
//        categoryPlot3.setRangeCrosshairLockedOnData(true);
//        categoryPlot3.mapDatasetToRangeAxis(0, 100);
//        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
//        categoryPlot3.setDataset((int) (byte) 100, categoryDataset37);
//        int int39 = day0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Calendar calendar40 = null;
//        try {
//            long long41 = day0.getLastMillisecond(calendar40);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNotNull(color6);
//        org.junit.Assert.assertNotNull(stroke10);
//        org.junit.Assert.assertNotNull(color13);
//        org.junit.Assert.assertNotNull(stroke17);
//        org.junit.Assert.assertNotNull(color20);
//        org.junit.Assert.assertNotNull(colorSpace21);
//        org.junit.Assert.assertNotNull(textAnchor23);
//        org.junit.Assert.assertNotNull(layer25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Layer.FOREGROUND" + "'", str26.equals("Layer.FOREGROUND"));
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge30);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent26 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker8);
        float float27 = valueMarker8.getAlpha();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 1.0f + "'", float27 == 1.0f);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        categoryAxis0.setFixedDimension((double) 10.0f);
        java.lang.String str4 = categoryAxis0.getLabel();
        java.awt.Paint paint5 = categoryAxis0.getAxisLinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke7 = categoryAxis6.getTickMarkStroke();
        categoryAxis6.setFixedDimension((double) 10.0f);
        java.awt.Font font11 = categoryAxis6.getTickLabelFont((java.lang.Comparable) 1.0d);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = categoryAxis6.getCategoryLabelPositions();
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions12);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(categoryLabelPositions12);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getRangeAxis(1);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone9 = dateAxis8.getTimeZone();
        dateAxis8.setRange((double) (short) 0, (double) (short) 10);
        boolean boolean13 = dateAxis8.isVerticalTickLabels();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis8);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation15 = null;
        try {
            boolean boolean17 = xYPlot0.removeAnnotation(xYAnnotation15, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        int int2 = day0.getDayOfMonth();
//        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
//        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        org.jfree.chart.JFreeChart jFreeChart7 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color6, jFreeChart7, chartChangeEventType8);
//        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color6, stroke10);
//        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        org.jfree.chart.JFreeChart jFreeChart14 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color13, jFreeChart14, chartChangeEventType15);
//        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color13, stroke17);
//        valueMarker11.setOutlineStroke(stroke17);
//        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        java.awt.color.ColorSpace colorSpace21 = color20.getColorSpace();
//        valueMarker11.setLabelPaint((java.awt.Paint) color20);
//        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
//        valueMarker11.setLabelTextAnchor(textAnchor23);
//        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.FOREGROUND;
//        java.lang.String str26 = layer25.toString();
//        boolean boolean28 = categoryPlot3.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker11, layer25, true);
//        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot3.getDomainAxisEdge((int) (byte) 0);
//        categoryPlot3.setRangeCrosshairLockedOnData(true);
//        categoryPlot3.mapDatasetToRangeAxis(0, 100);
//        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
//        categoryPlot3.setDataset((int) (byte) 100, categoryDataset37);
//        int int39 = day0.compareTo((java.lang.Object) (byte) 100);
//        java.util.Calendar calendar40 = null;
//        try {
//            long long41 = day0.getMiddleMillisecond(calendar40);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertNotNull(color6);
//        org.junit.Assert.assertNotNull(stroke10);
//        org.junit.Assert.assertNotNull(color13);
//        org.junit.Assert.assertNotNull(stroke17);
//        org.junit.Assert.assertNotNull(color20);
//        org.junit.Assert.assertNotNull(colorSpace21);
//        org.junit.Assert.assertNotNull(textAnchor23);
//        org.junit.Assert.assertNotNull(layer25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Layer.FOREGROUND" + "'", str26.equals("Layer.FOREGROUND"));
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge30);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        java.awt.Color color27 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke29 = categoryAxis28.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color27, stroke29);
        categoryPlot0.setRangeGridlineStroke(stroke29);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone35 = dateAxis34.getTimeZone();
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = dateAxis34.java2DToValue((double) (short) 100, rectangle2D37, rectangleEdge38);
        dateAxis34.setLowerBound((double) (byte) 100);
        categoryPlot0.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis34, true);
        categoryPlot0.setAnchorValue((double) 64, true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 9.223372036854776E18d + "'", double39 == 9.223372036854776E18d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        boolean boolean5 = xYPlot0.isRangeZeroBaselineVisible();
        xYPlot0.setBackgroundAlpha((float) '4');
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        xYPlot0.notifyListeners(plotChangeEvent8);
        java.awt.Image image10 = null;
        xYPlot0.setBackgroundImage(image10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        java.awt.Paint paint3 = xYPlot0.getRangeGridlinePaint();
        java.awt.Paint paint4 = null;
        try {
            xYPlot0.setRangeGridlinePaint(paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis(128);
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace4, true);
        boolean boolean7 = categoryPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str1.equals("RectangleAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color1, jFreeChart2, chartChangeEventType3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke5);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color8, jFreeChart9, chartChangeEventType10);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color8, stroke12);
        valueMarker6.setOutlineStroke(stroke12);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace16 = color15.getColorSpace();
        valueMarker6.setLabelPaint((java.awt.Paint) color15);
        int int18 = color15.getGreen();
        java.awt.Color color19 = java.awt.Color.magenta;
        java.awt.Color color20 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        float[] floatArray21 = null;
        float[] floatArray22 = color20.getRGBComponents(floatArray21);
        float[] floatArray23 = color19.getRGBColorComponents(floatArray21);
        float[] floatArray24 = color15.getRGBColorComponents(floatArray23);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(colorSpace16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 255 + "'", int18 == 255);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(2.0d, (double) '#');
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color6, jFreeChart7, chartChangeEventType8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color6, stroke10);
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color13, jFreeChart14, chartChangeEventType15);
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color13, stroke17);
        valueMarker11.setOutlineStroke(stroke17);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace21 = color20.getColorSpace();
        valueMarker11.setLabelPaint((java.awt.Paint) color20);
        org.jfree.chart.text.TextAnchor textAnchor23 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker11.setLabelTextAnchor(textAnchor23);
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str26 = layer25.toString();
        boolean boolean28 = categoryPlot3.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker11, layer25, true);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection30 = categoryPlot3.getRangeMarkers(layer29);
        categoryPlot3.clearAnnotations();
        boolean boolean32 = intervalMarker2.equals((java.lang.Object) categoryPlot3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(colorSpace21);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Layer.FOREGROUND" + "'", str26.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE", timeZone1);
        boolean boolean3 = dateAxis2.isNegativeArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis5.configure();
        boolean boolean7 = dateAxis5.isAutoRange();
        org.jfree.data.time.DateRange dateRange8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange8);
        dateAxis2.setRange((org.jfree.data.Range) dateRange8);
        java.awt.Font font11 = dateAxis2.getTickLabelFont();
        try {
            dateAxis2.setRange(11.0d, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateRange8);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        java.awt.Font font31 = xYPlot0.getNoDataMessageFont();
        xYPlot0.setDomainCrosshairValue(1.0d);
        java.awt.Color color34 = org.jfree.chart.ChartColor.DARK_YELLOW;
        xYPlot0.setNoDataMessagePaint((java.awt.Paint) color34);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = xYPlot0.getRenderer(10);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNull(xYItemRenderer38);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection27 = categoryPlot0.getRangeMarkers(layer26);
        boolean boolean28 = categoryPlot0.isOutlineVisible();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation26);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = categoryPlot0.getDomainAxisForDataset(0);
        org.jfree.data.general.DatasetGroup datasetGroup30 = categoryPlot0.getDatasetGroup();
        categoryPlot0.setRangeCrosshairValue(0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNull(categoryAxis29);
        org.junit.Assert.assertNull(datasetGroup30);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        xYPlot0.setRangeGridlinesVisible(false);
        xYPlot0.setForegroundAlpha(0.0f);
        java.awt.geom.Point2D point2D35 = xYPlot0.getQuadrantOrigin();
        xYPlot0.setForegroundAlpha((float) (byte) 10);
        xYPlot0.setBackgroundAlpha((float) (short) -1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(point2D35);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        double double4 = rectangleInsets2.calculateBottomInset((double) 1);
        double double6 = rectangleInsets2.extendWidth((-7.0d));
        double double7 = rectangleInsets2.getLeft();
        double double8 = rectangleInsets2.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color6 = java.awt.Color.WHITE;
        java.awt.Color color7 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray8 = new java.awt.Paint[] { color4, color5, color6, color7 };
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color9, color10, color11, color12 };
        java.awt.Paint[] paintArray14 = null;
        java.awt.Stroke stroke15 = null;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        java.awt.Stroke stroke17 = null;
        java.awt.Stroke[] strokeArray18 = new java.awt.Stroke[] { stroke17 };
        java.awt.Shape shape19 = null;
        java.awt.Shape[] shapeArray20 = new java.awt.Shape[] { shape19 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray8, paintArray13, paintArray14, strokeArray16, strokeArray18, shapeArray20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color25, jFreeChart26, chartChangeEventType27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color25, stroke29);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart33 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType34 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent35 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color32, jFreeChart33, chartChangeEventType34);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color32, stroke36);
        valueMarker30.setOutlineStroke(stroke36);
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace40 = color39.getColorSpace();
        valueMarker30.setLabelPaint((java.awt.Paint) color39);
        org.jfree.chart.text.TextAnchor textAnchor42 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker30.setLabelTextAnchor(textAnchor42);
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str45 = layer44.toString();
        boolean boolean47 = categoryPlot22.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker30, layer44, true);
        org.jfree.chart.axis.AxisLocation axisLocation48 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot22.setRangeAxisLocation(axisLocation48);
        boolean boolean50 = defaultDrawingSupplier21.equals((java.lang.Object) axisLocation48);
        categoryPlot0.setRangeAxisLocation(axisLocation48, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation53 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation48, plotOrientation53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(shapeArray20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(colorSpace40);
        org.junit.Assert.assertNotNull(textAnchor42);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Layer.FOREGROUND" + "'", str45.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color2, color3, color4, color5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color7, color8, color9, color10 };
        java.awt.Paint[] paintArray12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke stroke15 = null;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        java.awt.Shape shape17 = null;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray14, strokeArray16, shapeArray18);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        categoryPlot0.setWeight((int) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot0.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = dateAxis26.getLabelInsets();
        categoryPlot0.setRangeAxis(12, (org.jfree.chart.axis.ValueAxis) dateAxis26);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart33 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType34 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent35 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color32, jFreeChart33, chartChangeEventType34);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color32, stroke36);
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart40 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType41 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent42 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color39, jFreeChart40, chartChangeEventType41);
        java.awt.Stroke stroke43 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color39, stroke43);
        valueMarker37.setOutlineStroke(stroke43);
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace47 = color46.getColorSpace();
        valueMarker37.setLabelPaint((java.awt.Paint) color46);
        org.jfree.chart.text.TextAnchor textAnchor49 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker37.setLabelTextAnchor(textAnchor49);
        org.jfree.chart.util.Layer layer51 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str52 = layer51.toString();
        boolean boolean54 = categoryPlot29.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker37, layer51, true);
        org.jfree.chart.util.Layer layer55 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection56 = categoryPlot29.getRangeMarkers(layer55);
        org.jfree.chart.LegendItemCollection legendItemCollection57 = categoryPlot29.getLegendItems();
        java.awt.Paint paint58 = categoryPlot29.getRangeCrosshairPaint();
        dateAxis26.setTickMarkPaint(paint58);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(colorSpace47);
        org.junit.Assert.assertNotNull(textAnchor49);
        org.junit.Assert.assertNotNull(layer51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Layer.FOREGROUND" + "'", str52.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(layer55);
        org.junit.Assert.assertNotNull(collection56);
        org.junit.Assert.assertNotNull(legendItemCollection57);
        org.junit.Assert.assertNotNull(paint58);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        try {
            dateAxis1.zoomRange((double) 13, (double) (-245));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (13.0) <= upper (-245.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setLabelToolTip("hi!");
        categoryAxis1.setLabel("");
        boolean boolean7 = layer0.equals((java.lang.Object) categoryAxis1);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.util.List list14 = null;
        xYPlot11.drawDomainTickBands(graphics2D12, rectangle2D13, list14);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot11.getRangeAxisEdge((int) (short) 0);
        try {
            java.util.List list18 = categoryAxis1.refreshTicks(graphics2D8, axisState9, rectangle2D10, rectangleEdge17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        float float2 = categoryAxis0.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis4.getLabelInsets();
        double double7 = rectangleInsets5.calculateBottomInset((double) 1);
        double double9 = rectangleInsets5.trimHeight((double) (-1));
        categoryAxis0.setLabelInsets(rectangleInsets5);
        java.lang.String str11 = rectangleInsets5.toString();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-7.0d) + "'", double9 == (-7.0d));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str11.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        java.util.List list12 = xYPlot0.getAnnotations();
        java.awt.Stroke stroke13 = xYPlot0.getDomainGridlineStroke();
        java.awt.Paint paint14 = xYPlot0.getDomainGridlinePaint();
        int int15 = xYPlot0.getRangeAxisCount();
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color8, jFreeChart9, chartChangeEventType10);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color8, stroke12);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color15, jFreeChart16, chartChangeEventType17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color15, stroke19);
        valueMarker13.setOutlineStroke(stroke19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace23 = color22.getColorSpace();
        valueMarker13.setLabelPaint((java.awt.Paint) color22);
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker13.setLabelTextAnchor(textAnchor25);
        org.jfree.chart.util.Layer layer27 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str28 = layer27.toString();
        boolean boolean30 = categoryPlot5.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker13, layer27, true);
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean33 = xYPlot3.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker13, layer31, true);
        java.awt.Font font34 = xYPlot3.getNoDataMessageFont();
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 64, font34);
        float float36 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(colorSpace23);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNotNull(layer27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Layer.FOREGROUND" + "'", str28.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.0f + "'", float36 == 0.0f);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot0.getDomainAxisEdge((int) (byte) 0);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        boolean boolean33 = numberAxis32.getAutoRangeIncludesZero();
        double double34 = numberAxis32.getUpperBound();
        try {
            categoryPlot0.setRangeAxis((int) (short) -1, (org.jfree.chart.axis.ValueAxis) numberAxis32, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation26);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = categoryPlot0.getDomainAxisForDataset(0);
        org.jfree.data.category.CategoryDataset categoryDataset31 = categoryPlot0.getDataset((int) (byte) 10);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNull(categoryAxis29);
        org.junit.Assert.assertNull(categoryDataset31);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation26);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = categoryPlot0.getDomainAxisForDataset(0);
        org.jfree.data.general.DatasetGroup datasetGroup30 = categoryPlot0.getDatasetGroup();
        java.util.List list31 = categoryPlot0.getAnnotations();
        boolean boolean32 = categoryPlot0.isRangeZoomable();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNull(categoryAxis29);
        org.junit.Assert.assertNull(datasetGroup30);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis2.configure();
        boolean boolean4 = dateAxis2.isAutoRange();
        java.awt.Shape shape5 = dateAxis2.getLeftArrow();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = dateAxis2.java2DToValue((double) 0.0f, rectangle2D7, rectangleEdge8);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone12 = dateAxis11.getTimeZone();
        dateAxis2.setTimeZone(timeZone12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date0, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.next();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand1 = numberAxis0.getMarkerBand();
        numberAxis0.configure();
        try {
            numberAxis0.setRangeWithMargins((double) (byte) 100, (double) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (4.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(markerAxisBand1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        intervalMarker2.setLabelTextAnchor(textAnchor3);
        float float5 = intervalMarker2.getAlpha();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.8f + "'", float5 == 0.8f);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        xYPlot0.zoomRangeAxes((double) (short) 0, plotRenderingInfo32, point2D33, false);
        xYPlot0.setNoDataMessage("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis38 = xYPlot0.getRangeAxis();
        xYPlot0.configureRangeAxes();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(valueAxis38);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color2, color3, color4, color5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color7, color8, color9, color10 };
        java.awt.Paint[] paintArray12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke stroke15 = null;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        java.awt.Shape shape17 = null;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray14, strokeArray16, shapeArray18);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        categoryPlot0.setWeight((int) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot0.getDomainAxis();
        java.awt.Paint paint24 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.SortOrder sortOrder25 = null;
        try {
            categoryPlot0.setRowRenderingOrder(sortOrder25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        xYPlot0.drawAnnotations(graphics2D12, rectangle2D13, plotRenderingInfo14);
        org.junit.Assert.assertNotNull(layer9);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation26);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        try {
            categoryPlot0.drawOutline(graphics2D28, rectangle2D29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(axisLocation26);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke3 = intervalMarker2.getOutlineStroke();
        intervalMarker2.setStartValue((double) 2.0f);
        java.awt.Paint paint6 = intervalMarker2.getPaint();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = intervalMarker2.getGradientPaintTransformer();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(gradientPaintTransformer7);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(11);
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        double double5 = intervalMarker4.getStartValue();
        java.awt.Color color6 = java.awt.Color.orange;
        intervalMarker4.setLabelPaint((java.awt.Paint) color6);
        int int8 = objectList1.indexOf((java.lang.Object) intervalMarker4);
        org.jfree.chart.text.TextAnchor textAnchor9 = null;
        try {
            intervalMarker4.setLabelTextAnchor(textAnchor9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 11.0d + "'", double5 == 11.0d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        java.awt.Color color27 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke29 = categoryAxis28.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color27, stroke29);
        categoryPlot0.setRangeGridlineStroke(stroke29);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke32);
        categoryPlot0.clearRangeMarkers(100);
        categoryPlot0.setRangeCrosshairValue((double) (-1), true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.configure();
        java.text.DateFormat dateFormat3 = dateAxis1.getDateFormatOverride();
        org.junit.Assert.assertNull(dateFormat3);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection27 = categoryPlot0.getRangeMarkers(layer26);
        double double28 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.plot.Plot plot29 = categoryPlot0.getRootPlot();
        float float30 = plot29.getForegroundAlpha();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(plot29);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        xYPlot0.zoomRangeAxes((double) (short) 0, plotRenderingInfo32, point2D33, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder36 = xYPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder36);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0, jFreeChart1, chartChangeEventType2);
        int int4 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        float float2 = categoryAxis0.getTickMarkOutsideLength();
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis0.setLabelFont(font3);
        double double5 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis0.getLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis0.getTickLabelInsets();
        categoryAxis0.setCategoryMargin((double) ' ');
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        categoryAxis0.setFixedDimension((double) 10.0f);
        boolean boolean4 = categoryAxis0.isTickMarksVisible();
        categoryAxis0.setTickMarksVisible(true);
        categoryAxis0.setTickMarkInsideLength((float) 1);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.util.List list16 = null;
        xYPlot13.drawDomainTickBands(graphics2D14, rectangle2D15, list16);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot13.getRangeAxisEdge((int) (short) 0);
        try {
            double double20 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor9, (int) 'a', (int) (short) 10, rectangle2D12, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        java.awt.Color color27 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke29 = categoryAxis28.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color27, stroke29);
        categoryPlot0.setRangeGridlineStroke(stroke29);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke32);
        java.util.List list34 = categoryPlot0.getCategories();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(list34);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.RIGHT" + "'", str1.equals("RectangleAnchor.RIGHT"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        xYPlot0.clearDomainAxes();
        boolean boolean13 = xYPlot0.isOutlineVisible();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder14 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Stroke stroke15 = xYPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(seriesRenderingOrder14);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color4, jFreeChart5, chartChangeEventType6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color4, stroke8);
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke12 = categoryAxis11.getTickMarkStroke();
        categoryAxis11.setLabelToolTip("hi!");
        categoryAxis11.setLabel("");
        boolean boolean17 = layer10.equals((java.lang.Object) categoryAxis11);
        boolean boolean18 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9, layer10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot0.setRenderer(categoryItemRenderer19, false);
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace22);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke26 = categoryAxis25.getTickMarkStroke();
        float float27 = categoryAxis25.getTickMarkOutsideLength();
        categoryAxis25.setAxisLineVisible(true);
        categoryPlot0.setDomainAxis(11, categoryAxis25, false);
        categoryPlot0.clearDomainMarkers();
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(layer10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 2.0f + "'", float27 == 2.0f);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        java.util.List list12 = xYPlot0.getAnnotations();
        java.awt.Stroke stroke13 = xYPlot0.getDomainGridlineStroke();
        double double14 = xYPlot0.getRangeCrosshairValue();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis16 = xYPlot0.getDomainAxisForDataset(64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 64 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        dateAxis1.setNegativeArrowVisible(false);
        dateAxis1.setAutoTickUnitSelection(true, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis1.getLabelInsets();
        dateAxis1.setLowerBound((double) (short) 10);
        org.jfree.data.Range range11 = dateAxis1.getRange();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color17, jFreeChart18, chartChangeEventType19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color17, stroke21);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart25 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType26 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color24, jFreeChart25, chartChangeEventType26);
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color24, stroke28);
        valueMarker22.setOutlineStroke(stroke28);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace32 = color31.getColorSpace();
        valueMarker22.setLabelPaint((java.awt.Paint) color31);
        org.jfree.chart.text.TextAnchor textAnchor34 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker22.setLabelTextAnchor(textAnchor34);
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str37 = layer36.toString();
        boolean boolean39 = categoryPlot14.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker22, layer36, true);
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean42 = xYPlot12.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker22, layer40, true);
        org.jfree.chart.LegendItemCollection legendItemCollection43 = null;
        xYPlot12.setFixedLegendItems(legendItemCollection43);
        xYPlot12.setRangeCrosshairLockedOnData(false);
        java.awt.Stroke stroke47 = xYPlot12.getOutlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis50.configure();
        boolean boolean52 = dateAxis50.isAutoRange();
        java.awt.Shape shape53 = dateAxis50.getLeftArrow();
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        double double57 = dateAxis50.java2DToValue((double) 0.0f, rectangle2D55, rectangleEdge56);
        dateAxis50.setRangeWithMargins((double) 2.0f, (double) 12);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis62.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font66 = categoryAxis64.getTickLabelFont((java.lang.Comparable) 4);
        dateAxis62.setTickLabelFont(font66);
        dateAxis50.setLabelFont(font66);
        xYPlot12.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis50, true);
        java.awt.Paint paint71 = xYPlot12.getDomainZeroBaselinePaint();
        boolean boolean72 = dateAxis1.equals((java.lang.Object) paint71);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(colorSpace32);
        org.junit.Assert.assertNotNull(textAnchor34);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Layer.FOREGROUND" + "'", str37.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(layer40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(font66);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        xYPlot0.setRangeGridlinesVisible(false);
        xYPlot0.setForegroundAlpha(0.0f);
        java.awt.geom.Point2D point2D35 = xYPlot0.getQuadrantOrigin();
        xYPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        xYPlot0.setRenderer(xYItemRenderer38);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(point2D35);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        boolean boolean2 = numberAxis1.getAutoRangeIncludesZero();
        boolean boolean3 = numberAxis1.getAutoRangeStickyZero();
        java.text.NumberFormat numberFormat4 = numberAxis1.getNumberFormatOverride();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(numberFormat4);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.setNegativeArrowVisible(true);
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setTickMarkOutsideLength((float) 100);
        boolean boolean8 = dateAxis1.isPositiveArrowVisible();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        dateAxis1.setNegativeArrowVisible(false);
        dateAxis1.setAutoTickUnitSelection(true, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis10.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font14 = categoryAxis12.getTickLabelFont((java.lang.Comparable) 4);
        dateAxis10.setTickLabelFont(font14);
        dateAxis1.setTickLabelFont(font14);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone19 = dateAxis18.getTimeZone();
        dateAxis18.setRange((double) (short) 0, (double) (short) 10);
        boolean boolean24 = dateAxis18.isHiddenValue((long) 10);
        org.jfree.chart.plot.Plot plot25 = dateAxis18.getPlot();
        java.util.Date date26 = dateAxis18.getMaximumDate();
        org.jfree.data.Range range27 = dateAxis18.getDefaultAutoRange();
        dateAxis1.setRange(range27, true, false);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(plot25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(range27);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color2, color3, color4, color5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color7, color8, color9, color10 };
        java.awt.Paint[] paintArray12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke stroke15 = null;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        java.awt.Shape shape17 = null;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray14, strokeArray16, shapeArray18);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        org.jfree.data.general.DatasetGroup datasetGroup21 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot0.getDomainAxis((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        try {
            categoryPlot0.handleClick((int) (short) 1, 4, plotRenderingInfo26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNull(datasetGroup21);
        org.junit.Assert.assertNull(categoryAxis23);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        xYPlot0.zoomRangeAxes((double) (short) 0, plotRenderingInfo32, point2D33, false);
        org.jfree.chart.axis.ValueAxis valueAxis36 = xYPlot0.getDomainAxis();
        java.awt.Color color39 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke41 = categoryAxis40.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color39, stroke41);
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean45 = xYPlot0.removeDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) valueMarker42, layer43, true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(valueAxis36);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(layer43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getRangeAxis(1);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        xYPlot0.notifyListeners(plotChangeEvent7);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis10.setNegativeArrowVisible(true);
        float float13 = dateAxis10.getTickMarkOutsideLength();
        dateAxis10.setAutoRangeMinimumSize((double) 1);
        boolean boolean16 = dateAxis10.isAxisLineVisible();
        dateAxis10.setRangeAboutValue((double) 10L, 0.05d);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis10);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart24 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType25 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color23, jFreeChart24, chartChangeEventType25);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color23, stroke27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) 11, (java.awt.Paint) color23, stroke29);
        dateAxis10.setAxisLineStroke(stroke29);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone34 = dateAxis33.getTimeZone();
        dateAxis33.setNegativeArrowVisible(false);
        dateAxis33.setAutoTickUnitSelection(true, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = dateAxis33.getLabelInsets();
        dateAxis33.setLowerBound((double) (short) 10);
        org.jfree.data.Range range43 = dateAxis33.getRange();
        dateAxis10.setRange(range43, false, true);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(range43);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color2 = java.awt.Color.WHITE;
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray4 = new java.awt.Paint[] { color0, color1, color2, color3 };
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray9 = new java.awt.Paint[] { color5, color6, color7, color8 };
        java.awt.Paint[] paintArray10 = null;
        java.awt.Stroke stroke11 = null;
        java.awt.Stroke[] strokeArray12 = new java.awt.Stroke[] { stroke11 };
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Shape shape15 = null;
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] { shape15 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray4, paintArray9, paintArray10, strokeArray12, strokeArray14, shapeArray16);
        java.lang.Object obj18 = defaultDrawingSupplier17.clone();
        java.awt.Stroke stroke19 = defaultDrawingSupplier17.getNextStroke();
        java.lang.Object obj20 = defaultDrawingSupplier17.clone();
        java.awt.Stroke stroke21 = defaultDrawingSupplier17.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paintArray9);
        org.junit.Assert.assertNotNull(strokeArray12);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNull(stroke19);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNull(stroke21);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=0,g=192,b=0]" + "'", str1.equals("java.awt.Color[r=0,g=192,b=0]"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation26);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis31);
        dateAxis31.setAutoTickUnitSelection(true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(axisLocation26);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.configure();
        boolean boolean3 = dateAxis1.isAutoRange();
        java.awt.Shape shape4 = dateAxis1.getLeftArrow();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = dateAxis1.java2DToValue((double) 0.0f, rectangle2D6, rectangleEdge7);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace12 = categoryPlot11.getFixedDomainAxisSpace();
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot11.getRangeAxis(128);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot11.getDomainAxisEdge();
        try {
            double double16 = dateAxis1.java2DToValue((double) 1.0f, rectangle2D10, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        xYPlot0.zoomRangeAxes((double) (short) 0, plotRenderingInfo32, point2D33, false);
        org.jfree.chart.axis.ValueAxis valueAxis36 = xYPlot0.getDomainAxis();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        int int38 = xYPlot0.indexOf(xYDataset37);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder39 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.String str40 = datasetRenderingOrder39.toString();
        java.lang.String str41 = datasetRenderingOrder39.toString();
        java.lang.String str42 = datasetRenderingOrder39.toString();
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder39);
        java.awt.Paint paint44 = xYPlot0.getBackgroundPaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(valueAxis36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(datasetRenderingOrder39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str40.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str41.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str42.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("EXPAND", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke3 = intervalMarker2.getOutlineStroke();
        java.awt.Font font4 = null;
        try {
            intervalMarker2.setLabelFont(font4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        dateAxis1.setLowerBound((double) (-1L));
        dateAxis1.setRangeWithMargins((double) 11, (double) 64);
        float float8 = dateAxis1.getTickMarkOutsideLength();
        java.util.TimeZone timeZone9 = dateAxis1.getTimeZone();
        dateAxis1.setAutoRange(true);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
        org.junit.Assert.assertNotNull(timeZone9);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("EXPAND");
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        java.util.List list12 = xYPlot0.getAnnotations();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.util.List list17 = null;
        xYPlot0.drawDomainTickBands(graphics2D15, rectangle2D16, list17);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getRangeAxis(1);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        xYPlot0.notifyListeners(plotChangeEvent7);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis10.setNegativeArrowVisible(true);
        float float13 = dateAxis10.getTickMarkOutsideLength();
        dateAxis10.setAutoRangeMinimumSize((double) 1);
        boolean boolean16 = dateAxis10.isAxisLineVisible();
        dateAxis10.setRangeAboutValue((double) 10L, 0.05d);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis10);
        java.awt.Color color21 = java.awt.Color.orange;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color21);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot0.getDomainAxisForDataset((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index -1 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        xYPlot0.clearDomainAxes();
        boolean boolean13 = xYPlot0.isOutlineVisible();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder14 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Color color15 = java.awt.Color.green;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color15);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(seriesRenderingOrder14);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkOutsideLength((float) (byte) 100);
        categoryAxis0.setMaximumCategoryLabelLines((int) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke6 = categoryAxis5.getTickMarkStroke();
        float float7 = categoryAxis5.getTickMarkOutsideLength();
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis5.setLabelFont(font8);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = categoryAxis5.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor11 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis5.getCategoryJava2DCoordinate(categoryAnchor11, (int) (short) 0, (int) ' ', rectangle2D14, rectangleEdge15);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor11, 11, 9, rectangle2D19, rectangleEdge20);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
        org.junit.Assert.assertNotNull(categoryAnchor11);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        xYPlot0.clearDomainAxes();
        boolean boolean13 = xYPlot0.isOutlineVisible();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        boolean boolean16 = xYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.ValueAxis valueAxis18 = xYPlot0.getDomainAxis(0);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(valueAxis18);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
        int int2 = categoryAxis0.getMaximumCategoryLabelLines();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkOutsideLength((float) (byte) 100);
        categoryAxis0.setMaximumCategoryLabelLines((int) (short) 1);
        java.lang.Comparable comparable5 = null;
        try {
            categoryAxis0.removeCategoryLabelToolTip(comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.awt.Color color1 = java.awt.Color.magenta;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        float[] floatArray3 = null;
        float[] floatArray4 = color2.getRGBComponents(floatArray3);
        float[] floatArray5 = color1.getRGBColorComponents(floatArray3);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.util.List list9 = null;
        xYPlot6.drawDomainTickBands(graphics2D7, rectangle2D8, list9);
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer15 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot6.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker14, layer15, true);
        java.util.List list18 = xYPlot6.getAnnotations();
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot6.setDomainCrosshairStroke(stroke19);
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0, (java.awt.Paint) color1, stroke19);
        boolean boolean22 = categoryMarker21.getDrawAsLine();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(layer15);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        categoryPlot0.setAnchorValue((double) 0, true);
        double double7 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor8 = categoryPlot0.getDomainGridlinePosition();
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(categoryAnchor8);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.configure();
        boolean boolean3 = dateAxis1.isAutoRange();
        java.awt.Font font4 = dateAxis1.getLabelFont();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis6.getLabelInsets();
        dateAxis6.setLowerBound((double) (-1L));
        dateAxis6.setRangeWithMargins((double) 11, (double) 64);
        float float13 = dateAxis6.getTickMarkOutsideLength();
        java.util.TimeZone timeZone14 = dateAxis6.getTimeZone();
        dateAxis1.setTimeZone(timeZone14);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
        org.junit.Assert.assertNotNull(timeZone14);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getRangeAxis(1);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        xYPlot0.notifyListeners(plotChangeEvent7);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis10.setNegativeArrowVisible(true);
        float float13 = dateAxis10.getTickMarkOutsideLength();
        dateAxis10.setAutoRangeMinimumSize((double) 1);
        boolean boolean16 = dateAxis10.isAxisLineVisible();
        dateAxis10.setRangeAboutValue((double) 10L, 0.05d);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis10);
        java.util.Date date21 = dateAxis10.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis23.configure();
        boolean boolean25 = dateAxis23.isAutoRange();
        java.awt.Shape shape26 = dateAxis23.getLeftArrow();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = dateAxis23.java2DToValue((double) 0.0f, rectangle2D28, rectangleEdge29);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone33 = dateAxis32.getTimeZone();
        dateAxis23.setTimeZone(timeZone33);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date21, timeZone33);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(timeZone33);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        java.awt.Font font31 = xYPlot0.getNoDataMessageFont();
        xYPlot0.setWeight((int) (byte) 1);
        org.jfree.chart.axis.AxisSpace axisSpace34 = xYPlot0.getFixedRangeAxisSpace();
        boolean boolean35 = xYPlot0.isRangeZoomable();
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace36);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNull(axisSpace34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        boolean boolean2 = numberAxis1.getAutoRangeIncludesZero();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.util.List list9 = null;
        xYPlot6.drawDomainTickBands(graphics2D7, rectangle2D8, list9);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot6.getRangeAxisEdge((int) (short) 0);
        try {
            java.util.List list13 = numberAxis1.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        categoryPlot0.setAnchorValue((double) 0, true);
        double double7 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.util.List list13 = null;
        xYPlot10.drawDomainTickBands(graphics2D11, rectangle2D12, list13);
        java.awt.Color color15 = java.awt.Color.yellow;
        xYPlot10.setRangeCrosshairPaint((java.awt.Paint) color15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart25 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType26 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color24, jFreeChart25, chartChangeEventType26);
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color24, stroke28);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart32 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType33 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent34 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color31, jFreeChart32, chartChangeEventType33);
        java.awt.Stroke stroke35 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color31, stroke35);
        valueMarker29.setOutlineStroke(stroke35);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace39 = color38.getColorSpace();
        valueMarker29.setLabelPaint((java.awt.Paint) color38);
        org.jfree.chart.text.TextAnchor textAnchor41 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker29.setLabelTextAnchor(textAnchor41);
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str44 = layer43.toString();
        boolean boolean46 = categoryPlot21.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker29, layer43, true);
        org.jfree.chart.util.Layer layer47 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean49 = xYPlot19.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker29, layer47, true);
        xYPlot19.setRangeGridlinesVisible(false);
        xYPlot19.setForegroundAlpha(0.0f);
        java.awt.geom.Point2D point2D54 = xYPlot19.getQuadrantOrigin();
        xYPlot10.zoomRangeAxes((double) (byte) 1, plotRenderingInfo18, point2D54, false);
        categoryPlot0.zoomRangeAxes(0.05d, plotRenderingInfo9, point2D54);
        float float58 = categoryPlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(colorSpace39);
        org.junit.Assert.assertNotNull(textAnchor41);
        org.junit.Assert.assertNotNull(layer43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Layer.FOREGROUND" + "'", str44.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(layer47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(point2D54);
        org.junit.Assert.assertTrue("'" + float58 + "' != '" + 0.5f + "'", float58 == 0.5f);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        xYPlot0.zoomRangeAxes((double) (short) 0, plotRenderingInfo32, point2D33, false);
        org.jfree.chart.axis.ValueAxis valueAxis36 = xYPlot0.getDomainAxis();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        int int38 = xYPlot0.indexOf(xYDataset37);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder39 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.String str40 = datasetRenderingOrder39.toString();
        java.lang.String str41 = datasetRenderingOrder39.toString();
        java.lang.String str42 = datasetRenderingOrder39.toString();
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder39);
        org.jfree.chart.plot.Marker marker44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        java.util.List list48 = null;
        xYPlot45.drawDomainTickBands(graphics2D46, rectangle2D47, list48);
        org.jfree.chart.plot.IntervalMarker intervalMarker53 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer54 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot45.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker53, layer54, true);
        boolean boolean57 = xYPlot0.removeDomainMarker(marker44, layer54);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(valueAxis36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(datasetRenderingOrder39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str40.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str41.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str42.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertNotNull(layer54);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot0.getDomainAxisEdge((int) (byte) 0);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent30);
        int int32 = categoryPlot0.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 15 + "'", int32 == 15);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot0.getDomainAxisEdge((int) (byte) 0);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent30);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE", timeZone34);
        categoryPlot0.setRangeAxis(12, (org.jfree.chart.axis.ValueAxis) dateAxis35, true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(timeZone34);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        dateAxis1.setLowerBound((double) (-1L));
        dateAxis1.setRangeWithMargins((double) 11, (double) 64);
        dateAxis1.resizeRange((double) (short) 100);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.Timeline timeline4 = null;
        dateAxis1.setTimeline(timeline4);
        dateAxis1.setAutoRangeMinimumSize((double) 1L, false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        java.lang.Object obj2 = numberAxis1.clone();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = numberAxis1.getMarkerBand();
        numberAxis1.setLabelURL("SeriesRenderingOrder.REVERSE");
        boolean boolean6 = numberAxis1.getAutoRangeStickyZero();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNull(markerAxisBand3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        boolean boolean2 = numberAxis1.getAutoRangeIncludesZero();
        boolean boolean3 = numberAxis1.getAutoRangeIncludesZero();
        numberAxis1.resizeRange((double) (-245));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        int int3 = categoryPlot0.getRangeAxisCount();
        categoryPlot0.setDomainGridlinesVisible(false);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        boolean boolean10 = categoryPlot0.render(graphics2D6, rectangle2D7, 11, plotRenderingInfo9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke13 = categoryAxis12.getTickMarkStroke();
        float float14 = categoryAxis12.getTickMarkOutsideLength();
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis12.setLabelFont(font15);
        double double17 = categoryAxis12.getCategoryMargin();
        categoryPlot0.setDomainAxis((int) (byte) 1, categoryAxis12);
        float float19 = categoryAxis12.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 2.0f + "'", float14 == 2.0f);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        xYPlot0.setRangeGridlinesVisible(false);
        xYPlot0.setForegroundAlpha(0.0f);
        xYPlot0.setRangeCrosshairLockedOnData(true);
        boolean boolean37 = xYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = xYPlot0.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("Layer.FOREGROUND");
        org.jfree.chart.axis.Timeline timeline2 = null;
        dateAxis1.setTimeline(timeline2);
        dateAxis1.setUpperBound((double) 8);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        double double4 = rectangleInsets2.calculateBottomInset((double) 1);
        double double6 = rectangleInsets2.trimHeight((double) (-1));
        org.jfree.chart.util.UnitType unitType7 = rectangleInsets2.getUnitType();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean11 = lengthAdjustmentType9.equals((java.lang.Object) 0.0f);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean14 = lengthAdjustmentType12.equals((java.lang.Object) 0.0f);
        try {
            java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets2.createAdjustedRectangle(rectangle2D8, lengthAdjustmentType9, lengthAdjustmentType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-7.0d) + "'", double6 == (-7.0d));
        org.junit.Assert.assertNotNull(unitType7);
        org.junit.Assert.assertNotNull(lengthAdjustmentType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(9.223372036854776E18d, (double) '#', (double) 4, 0.0d);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
        org.junit.Assert.assertNotNull(unitType5);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.util.List list4 = null;
        xYPlot1.drawDomainTickBands(graphics2D2, rectangle2D3, list4);
        org.jfree.chart.plot.IntervalMarker intervalMarker9 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot1.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker9, layer10, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart17 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType18 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color16, jFreeChart17, chartChangeEventType18);
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color16, stroke20);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart24 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType25 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color23, jFreeChart24, chartChangeEventType25);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color23, stroke27);
        valueMarker21.setOutlineStroke(stroke27);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace31 = color30.getColorSpace();
        valueMarker21.setLabelPaint((java.awt.Paint) color30);
        org.jfree.chart.text.TextAnchor textAnchor33 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker21.setLabelTextAnchor(textAnchor33);
        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str36 = layer35.toString();
        boolean boolean38 = categoryPlot13.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker21, layer35, true);
        org.jfree.chart.axis.AxisLocation axisLocation39 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot13.setRangeAxisLocation(axisLocation39);
        xYPlot1.setDomainAxisLocation(axisLocation39);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray42 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot1.setDomainAxes(valueAxisArray42);
        xYPlot1.mapDatasetToRangeAxis((int) (byte) 0, 0);
        int int47 = xYPlot1.getDomainAxisCount();
        boolean boolean48 = textAnchor0.equals((java.lang.Object) xYPlot1);
        java.lang.String str49 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(layer10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(colorSpace31);
        org.junit.Assert.assertNotNull(textAnchor33);
        org.junit.Assert.assertNotNull(layer35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Layer.FOREGROUND" + "'", str36.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(valueAxisArray42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "TextAnchor.BASELINE_RIGHT" + "'", str49.equals("TextAnchor.BASELINE_RIGHT"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        boolean boolean2 = numberAxis1.getAutoRangeIncludesZero();
        double double3 = numberAxis1.getUpperBound();
        boolean boolean4 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = null;
        numberAxis1.setMarkerBand(markerAxisBand5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.setNegativeArrowVisible(true);
        float float4 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setAutoRangeMinimumSize((double) 1);
        boolean boolean7 = dateAxis1.isAxisLineVisible();
        dateAxis1.setLabelToolTip("hi!");
        dateAxis1.setLowerMargin((double) (short) 10);
        dateAxis1.setRangeWithMargins((double) 12, (double) 64);
        dateAxis1.setTickMarkInsideLength((float) (short) 1);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        xYPlot0.setRangeGridlinesVisible(false);
        xYPlot0.setForegroundAlpha(0.0f);
        org.jfree.chart.plot.IntervalMarker intervalMarker37 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke38 = intervalMarker37.getOutlineStroke();
        xYPlot0.setDomainCrosshairStroke(stroke38);
        java.awt.Color color40 = org.jfree.chart.ChartColor.LIGHT_RED;
        xYPlot0.setNoDataMessagePaint((java.awt.Paint) color40);
        double double42 = xYPlot0.getDomainCrosshairValue();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation43 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation43, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.junit.Assert.assertNotNull(dateTickUnit0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getRangeAxis(1);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color17, jFreeChart18, chartChangeEventType19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color17, stroke21);
        valueMarker15.setOutlineStroke(stroke21);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace25 = color24.getColorSpace();
        valueMarker15.setLabelPaint((java.awt.Paint) color24);
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker15.setLabelTextAnchor(textAnchor27);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str30 = layer29.toString();
        boolean boolean32 = categoryPlot7.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker15, layer29, true);
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection34 = categoryPlot7.getRangeMarkers(layer33);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent35 = null;
        categoryPlot7.rendererChanged(rendererChangeEvent35);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot7.setRangeAxisLocation(axisLocation37);
        categoryPlot7.setBackgroundAlpha((float) (short) 100);
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        java.util.List list44 = null;
        xYPlot41.drawDomainTickBands(graphics2D42, rectangle2D43, list44);
        org.jfree.chart.plot.IntervalMarker intervalMarker49 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer50 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot41.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker49, layer50, true);
        java.util.List list53 = xYPlot41.getAnnotations();
        java.awt.Stroke stroke54 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot41.setDomainCrosshairStroke(stroke54);
        categoryPlot7.setRangeCrosshairStroke(stroke54);
        xYPlot0.setRangeCrosshairStroke(stroke54);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(colorSpace25);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Layer.FOREGROUND" + "'", str30.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertNotNull(axisLocation37);
        org.junit.Assert.assertNotNull(layer50);
        org.junit.Assert.assertNotNull(list53);
        org.junit.Assert.assertNotNull(stroke54);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.configure();
        boolean boolean3 = dateAxis1.isAutoRange();
        java.awt.Shape shape4 = dateAxis1.getLeftArrow();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = dateAxis1.java2DToValue((double) 0.0f, rectangle2D6, rectangleEdge7);
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = dateAxis1.getTickUnit();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickUnit9);
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
//        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        org.jfree.chart.JFreeChart jFreeChart6 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
//        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
//        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        org.jfree.chart.JFreeChart jFreeChart13 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
//        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
//        valueMarker10.setOutlineStroke(stroke16);
//        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
//        valueMarker10.setLabelPaint((java.awt.Paint) color19);
//        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
//        valueMarker10.setLabelTextAnchor(textAnchor22);
//        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
//        java.lang.String str25 = layer24.toString();
//        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
//        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
//        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
//        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
//        java.util.TimeZone timeZone34 = dateAxis33.getTimeZone();
//        xYPlot0.setRangeAxis(2, (org.jfree.chart.axis.ValueAxis) dateAxis33, true);
//        dateAxis33.setAutoTickUnitSelection(true, true);
//        java.util.Date date40 = null;
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        long long42 = day41.getFirstMillisecond();
//        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
//        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        org.jfree.chart.JFreeChart jFreeChart47 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType48 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent49 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color46, jFreeChart47, chartChangeEventType48);
//        java.awt.Stroke stroke50 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color46, stroke50);
//        java.awt.Color color53 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        org.jfree.chart.JFreeChart jFreeChart54 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType55 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent56 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color53, jFreeChart54, chartChangeEventType55);
//        java.awt.Stroke stroke57 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker58 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color53, stroke57);
//        valueMarker51.setOutlineStroke(stroke57);
//        java.awt.Color color60 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        java.awt.color.ColorSpace colorSpace61 = color60.getColorSpace();
//        valueMarker51.setLabelPaint((java.awt.Paint) color60);
//        org.jfree.chart.text.TextAnchor textAnchor63 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
//        valueMarker51.setLabelTextAnchor(textAnchor63);
//        org.jfree.chart.util.Layer layer65 = org.jfree.chart.util.Layer.FOREGROUND;
//        java.lang.String str66 = layer65.toString();
//        boolean boolean68 = categoryPlot43.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker51, layer65, true);
//        org.jfree.chart.util.Layer layer69 = org.jfree.chart.util.Layer.BACKGROUND;
//        java.util.Collection collection70 = categoryPlot43.getRangeMarkers(layer69);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent71 = null;
//        categoryPlot43.rendererChanged(rendererChangeEvent71);
//        org.jfree.chart.axis.AxisLocation axisLocation73 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
//        categoryPlot43.setRangeAxisLocation(axisLocation73);
//        org.jfree.chart.axis.AxisLocation axisLocation75 = axisLocation73.getOpposite();
//        int int76 = day41.compareTo((java.lang.Object) axisLocation75);
//        java.lang.String str77 = day41.toString();
//        java.util.Date date78 = day41.getEnd();
//        try {
//            dateAxis33.setRange(date40, date78);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(color5);
//        org.junit.Assert.assertNotNull(stroke9);
//        org.junit.Assert.assertNotNull(color12);
//        org.junit.Assert.assertNotNull(stroke16);
//        org.junit.Assert.assertNotNull(color19);
//        org.junit.Assert.assertNotNull(colorSpace20);
//        org.junit.Assert.assertNotNull(textAnchor22);
//        org.junit.Assert.assertNotNull(layer24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(layer28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560409200000L + "'", long42 == 1560409200000L);
//        org.junit.Assert.assertNotNull(color46);
//        org.junit.Assert.assertNotNull(stroke50);
//        org.junit.Assert.assertNotNull(color53);
//        org.junit.Assert.assertNotNull(stroke57);
//        org.junit.Assert.assertNotNull(color60);
//        org.junit.Assert.assertNotNull(colorSpace61);
//        org.junit.Assert.assertNotNull(textAnchor63);
//        org.junit.Assert.assertNotNull(layer65);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "Layer.FOREGROUND" + "'", str66.equals("Layer.FOREGROUND"));
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertNotNull(layer69);
//        org.junit.Assert.assertNotNull(collection70);
//        org.junit.Assert.assertNotNull(axisLocation73);
//        org.junit.Assert.assertNotNull(axisLocation75);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "13-June-2019" + "'", str77.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date78);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        xYPlot0.clearDomainAxes();
        java.awt.Paint paint13 = null;
        xYPlot0.setRangeTickBandPaint(paint13);
        org.junit.Assert.assertNotNull(layer9);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis(128);
        java.awt.Stroke stroke4 = categoryPlot0.getDomainGridlineStroke();
        boolean boolean5 = categoryPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color1, jFreeChart2, chartChangeEventType3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke5);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker6);
        org.jfree.chart.text.TextAnchor textAnchor8 = valueMarker6.getLabelTextAnchor();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) valueMarker6);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = valueMarker6.getLabelOffsetType();
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart17 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType18 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color16, jFreeChart17, chartChangeEventType18);
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color16, stroke20);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart24 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType25 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color23, jFreeChart24, chartChangeEventType25);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color23, stroke27);
        valueMarker21.setOutlineStroke(stroke27);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace31 = color30.getColorSpace();
        valueMarker21.setLabelPaint((java.awt.Paint) color30);
        org.jfree.chart.text.TextAnchor textAnchor33 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker21.setLabelTextAnchor(textAnchor33);
        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str36 = layer35.toString();
        boolean boolean38 = categoryPlot13.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker21, layer35, true);
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean41 = xYPlot11.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker21, layer39, true);
        org.jfree.chart.LegendItemCollection legendItemCollection42 = null;
        xYPlot11.setFixedLegendItems(legendItemCollection42);
        xYPlot11.setRangeCrosshairLockedOnData(false);
        boolean boolean46 = xYPlot11.isRangeCrosshairLockedOnData();
        java.awt.Paint paint48 = xYPlot11.getQuadrantPaint((int) (byte) 0);
        valueMarker6.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot11);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(lengthAdjustmentType10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(colorSpace31);
        org.junit.Assert.assertNotNull(textAnchor33);
        org.junit.Assert.assertNotNull(layer35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Layer.FOREGROUND" + "'", str36.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(paint48);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        double double4 = rectangleInsets2.calculateBottomInset((double) 1);
        double double6 = rectangleInsets2.calculateBottomInset((double) ' ');
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets2.createOutsetRectangle(rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.0d + "'", double6 == 3.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color4, jFreeChart5, chartChangeEventType6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color4, stroke8);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart12, chartChangeEventType13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke15);
        valueMarker9.setOutlineStroke(stroke15);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace19 = color18.getColorSpace();
        valueMarker9.setLabelPaint((java.awt.Paint) color18);
        org.jfree.chart.text.TextAnchor textAnchor21 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker9.setLabelTextAnchor(textAnchor21);
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str24 = layer23.toString();
        boolean boolean26 = categoryPlot1.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker9, layer23, true);
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot1.setRangeAxisLocation(axisLocation27);
        categoryPlot1.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        categoryPlot1.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis32);
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis32);
        java.awt.Graphics2D graphics2D35 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        org.jfree.chart.plot.CrosshairState crosshairState39 = null;
        boolean boolean40 = xYPlot0.render(graphics2D35, rectangle2D36, (-245), plotRenderingInfo38, crosshairState39);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(colorSpace19);
        org.junit.Assert.assertNotNull(textAnchor21);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Layer.FOREGROUND" + "'", str24.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        int int3 = java.awt.Color.HSBtoRGB((float) ' ', (float) 10L, 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot0.getRangeAxisEdge((int) (short) 0);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        xYPlot0.notifyListeners(plotChangeEvent7);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = xYPlot0.getRenderer((int) (byte) -1);
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot0.getDomainAxis(128);
        boolean boolean13 = xYPlot0.isSubplot();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(xYItemRenderer10);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(11.0d);
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        java.lang.String str3 = textAnchor2.toString();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.CENTER" + "'", str3.equals("TextAnchor.CENTER"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        float float2 = categoryAxis0.getTickMarkOutsideLength();
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis0.setLabelFont(font3);
        float float5 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        java.lang.String str6 = categoryAxis0.getLabel();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.util.List list11 = null;
        xYPlot8.drawDomainTickBands(graphics2D9, rectangle2D10, list11);
        org.jfree.chart.plot.IntervalMarker intervalMarker16 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot8.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker16, layer17, true);
        xYPlot8.clearDomainAxes();
        boolean boolean21 = xYPlot8.isOutlineVisible();
        double double22 = xYPlot8.getRangeCrosshairValue();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot24.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = categoryPlot24.getDomainAxis();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart29 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType30 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color28, jFreeChart29, chartChangeEventType30);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color28, stroke32);
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke36 = categoryAxis35.getTickMarkStroke();
        categoryAxis35.setLabelToolTip("hi!");
        categoryAxis35.setLabel("");
        boolean boolean41 = layer34.equals((java.lang.Object) categoryAxis35);
        boolean boolean42 = categoryPlot24.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker33, layer34);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        categoryPlot24.setRenderer(categoryItemRenderer43, false);
        org.jfree.chart.axis.AxisSpace axisSpace46 = null;
        categoryPlot24.setFixedRangeAxisSpace(axisSpace46);
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = categoryPlot24.getDomainAxisEdge(4);
        org.jfree.chart.axis.AxisSpace axisSpace50 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace51 = categoryAxis0.reserveSpace(graphics2D7, (org.jfree.chart.plot.Plot) xYPlot8, rectangle2D23, rectangleEdge49, axisSpace50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNull(categoryAxis26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(rectangleEdge49);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        float float2 = categoryAxis0.getTickMarkOutsideLength();
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis0.setLabelFont(font3);
        float float5 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) (short) 0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.util.List list16 = null;
        xYPlot13.drawDomainTickBands(graphics2D14, rectangle2D15, list16);
        java.awt.Color color18 = java.awt.Color.yellow;
        xYPlot13.setRangeCrosshairPaint((java.awt.Paint) color18);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color18);
        double double21 = xYPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot0.getRangeAxis((int) (byte) 0);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone27 = dateAxis26.getTimeZone();
        dateAxis26.setRange((double) (short) 0, (double) (short) 10);
        boolean boolean32 = dateAxis26.isHiddenValue((long) 10);
        org.jfree.chart.plot.Plot plot33 = dateAxis26.getPlot();
        java.util.Date date34 = dateAxis26.getMaximumDate();
        try {
            xYPlot0.setRangeAxis((-256), (org.jfree.chart.axis.ValueAxis) dateAxis26, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(plot33);
        org.junit.Assert.assertNotNull(date34);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeAxes();
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation26);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis31);
        java.awt.Shape shape33 = null;
        try {
            dateAxis31.setUpArrow(shape33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(axisLocation26);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        xYPlot0.clearDomainAxes();
        boolean boolean13 = xYPlot0.isOutlineVisible();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder16 = xYPlot0.getDatasetRenderingOrder();
        java.awt.Paint paint17 = xYPlot0.getRangeGridlinePaint();
        boolean boolean18 = xYPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.CENTER");
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        dateAxis1.setRange((double) (short) 0, (double) (short) 10);
        boolean boolean7 = dateAxis1.isHiddenValue((long) 10);
        org.jfree.chart.plot.Plot plot8 = dateAxis1.getPlot();
        java.util.Date date9 = dateAxis1.getMaximumDate();
        org.jfree.data.Range range10 = dateAxis1.getDefaultAutoRange();
        double double11 = dateAxis1.getUpperBound();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE", timeZone13);
        boolean boolean15 = dateAxis14.isNegativeArrowVisible();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis17.configure();
        boolean boolean19 = dateAxis17.isAutoRange();
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis17.setRangeWithMargins((org.jfree.data.Range) dateRange20);
        dateAxis14.setRange((org.jfree.data.Range) dateRange20);
        java.awt.Font font23 = dateAxis14.getTickLabelFont();
        java.util.Date date24 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis14.setMaximumDate(date24);
        dateAxis1.setMaximumDate(date24);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(date24);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("ChartChangeEventType.DATASET_UPDATED", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot0.getDomainAxisEdge((int) (byte) 0);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot0.getRendererForDataset(categoryDataset28);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNull(categoryItemRenderer29);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color4, jFreeChart5, chartChangeEventType6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color4, stroke8);
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke12 = categoryAxis11.getTickMarkStroke();
        categoryAxis11.setLabelToolTip("hi!");
        categoryAxis11.setLabel("");
        boolean boolean17 = layer10.equals((java.lang.Object) categoryAxis11);
        boolean boolean18 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9, layer10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot0.setRenderer(categoryItemRenderer19, false);
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace22);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke26 = categoryAxis25.getTickMarkStroke();
        float float27 = categoryAxis25.getTickMarkOutsideLength();
        categoryAxis25.setAxisLineVisible(true);
        categoryPlot0.setDomainAxis(11, categoryAxis25, false);
        double double32 = categoryAxis25.getCategoryMargin();
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(layer10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 2.0f + "'", float27 == 2.0f);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.2d + "'", double32 == 0.2d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.util.List list16 = null;
        xYPlot13.drawDomainTickBands(graphics2D14, rectangle2D15, list16);
        java.awt.Color color18 = java.awt.Color.yellow;
        xYPlot13.setRangeCrosshairPaint((java.awt.Paint) color18);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color18);
        double double21 = xYPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot0.getRangeAxis((int) (byte) 0);
        xYPlot0.setRangeCrosshairVisible(false);
        float float26 = xYPlot0.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection27 = categoryPlot0.getRangeMarkers(layer26);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent28);
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation30);
        java.awt.Image image32 = null;
        categoryPlot0.setBackgroundImage(image32);
        categoryPlot0.setRangeCrosshairValue(0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertNotNull(axisLocation30);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        boolean boolean2 = numberAxis1.getAutoRangeIncludesZero();
        boolean boolean3 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color15, jFreeChart16, chartChangeEventType17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color15, stroke19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart23 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType24 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color22, jFreeChart23, chartChangeEventType24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color22, stroke26);
        valueMarker20.setOutlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace30 = color29.getColorSpace();
        valueMarker20.setLabelPaint((java.awt.Paint) color29);
        org.jfree.chart.text.TextAnchor textAnchor32 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker20.setLabelTextAnchor(textAnchor32);
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str35 = layer34.toString();
        boolean boolean37 = categoryPlot12.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker20, layer34, true);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot12.setRangeAxisLocation(axisLocation38);
        xYPlot0.setDomainAxisLocation(axisLocation38);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray41 = new org.jfree.chart.axis.ValueAxis[] {};
        xYPlot0.setDomainAxes(valueAxisArray41);
        xYPlot0.mapDatasetToRangeAxis((int) (byte) 0, 0);
        int int46 = xYPlot0.getDomainAxisCount();
        xYPlot0.configureDomainAxes();
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(colorSpace30);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Layer.FOREGROUND" + "'", str35.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(valueAxisArray41);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation26);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        int int30 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis32 = categoryPlot0.getRangeAxisForDataset(0);
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot0.getRangeAxisLocation(255);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertNotNull(axisLocation34);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        categoryPlot0.setAnchorValue((double) 0, true);
        org.jfree.data.category.CategoryDataset categoryDataset7 = categoryPlot0.getDataset();
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(categoryDataset7);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        xYPlot0.clearDomainAxes();
        boolean boolean13 = xYPlot0.isOutlineVisible();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder14 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot0.getAxisOffset();
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(seriesRenderingOrder14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation26);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = categoryPlot0.getDomainAxisForDataset(0);
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        java.util.List list33 = null;
        xYPlot30.drawDomainTickBands(graphics2D31, rectangle2D32, list33);
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot30.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker38, layer39, true);
        xYPlot30.clearDomainAxes();
        boolean boolean43 = xYPlot30.isOutlineVisible();
        xYPlot30.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder46 = xYPlot30.getDatasetRenderingOrder();
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder46);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNull(categoryAxis29);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder46);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        java.awt.Color color27 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke29 = categoryAxis28.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color27, stroke29);
        categoryPlot0.setRangeGridlineStroke(stroke29);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke32);
        categoryPlot0.setRangeCrosshairValue((double) 64, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke38 = categoryAxis37.getTickMarkStroke();
        categoryAxis37.setFixedDimension((double) 10.0f);
        boolean boolean41 = categoryAxis37.isTickMarksVisible();
        categoryAxis37.setTickMarksVisible(true);
        categoryAxis37.setTickMarkInsideLength((float) 1);
        categoryPlot0.setDomainAxis(categoryAxis37);
        categoryAxis37.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE", timeZone1);
        boolean boolean3 = dateAxis2.isNegativeArrowVisible();
        java.lang.Class class4 = null;
        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone8 = dateAxis7.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date5, timeZone8);
        dateAxis2.setMinimumDate(date5);
        dateAxis2.setVisible(false);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        float float2 = categoryAxis0.getTickMarkOutsideLength();
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis0.setLabelFont(font3);
        double double5 = categoryAxis0.getCategoryMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis0.getLabelInsets();
        double double8 = rectangleInsets6.calculateBottomInset((double) 192);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        float float2 = categoryAxis0.getTickMarkOutsideLength();
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis0.setLabelFont(font3);
        double double5 = categoryAxis0.getCategoryMargin();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) 1);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color13, jFreeChart14, chartChangeEventType15);
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color13, stroke17);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart21 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType22 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color20, jFreeChart21, chartChangeEventType22);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color20, stroke24);
        valueMarker18.setOutlineStroke(stroke24);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace28 = color27.getColorSpace();
        valueMarker18.setLabelPaint((java.awt.Paint) color27);
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker18.setLabelTextAnchor(textAnchor30);
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str33 = layer32.toString();
        boolean boolean35 = categoryPlot10.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker18, layer32, true);
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean38 = xYPlot8.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker18, layer36, true);
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone42 = dateAxis41.getTimeZone();
        xYPlot8.setRangeAxis(2, (org.jfree.chart.axis.ValueAxis) dateAxis41, true);
        boolean boolean45 = categoryAxis0.equals((java.lang.Object) 2);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(colorSpace28);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Layer.FOREGROUND" + "'", str33.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        categoryAxis0.setFixedDimension((double) 10.0f);
        java.lang.String str4 = categoryAxis0.getLabel();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) "DatasetRenderingOrder.REVERSE", "java.awt.Color[r=0,g=192,b=0]");
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke6 = intervalMarker5.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot7.getDomainAxis();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart12, chartChangeEventType13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke19 = categoryAxis18.getTickMarkStroke();
        categoryAxis18.setLabelToolTip("hi!");
        categoryAxis18.setLabel("");
        boolean boolean24 = layer17.equals((java.lang.Object) categoryAxis18);
        boolean boolean25 = categoryPlot7.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker16, layer17);
        boolean boolean26 = categoryPlot0.removeDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) intervalMarker5, layer17);
        categoryPlot0.clearDomainMarkers();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        boolean boolean5 = xYPlot0.isRangeZeroBaselineVisible();
        xYPlot0.setBackgroundAlpha((float) '4');
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        xYPlot0.notifyListeners(plotChangeEvent8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color13, jFreeChart14, chartChangeEventType15);
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color13, stroke17);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart21 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType22 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color20, jFreeChart21, chartChangeEventType22);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color20, stroke24);
        valueMarker18.setOutlineStroke(stroke24);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace28 = color27.getColorSpace();
        valueMarker18.setLabelPaint((java.awt.Paint) color27);
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker18.setLabelTextAnchor(textAnchor30);
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str33 = layer32.toString();
        boolean boolean35 = categoryPlot10.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker18, layer32, true);
        java.awt.Paint paint36 = valueMarker18.getLabelPaint();
        org.jfree.chart.util.Layer layer37 = null;
        try {
            xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker18, layer37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(colorSpace28);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Layer.FOREGROUND" + "'", str33.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color2, color3, color4, color5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color7, color8, color9, color10 };
        java.awt.Paint[] paintArray12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke stroke15 = null;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        java.awt.Shape shape17 = null;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray14, strokeArray16, shapeArray18);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        categoryPlot0.setWeight((int) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot0.getDomainAxis();
        java.awt.Paint paint24 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        categoryPlot0.setDataset((int) (short) 0, categoryDataset26);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart33 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType34 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent35 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color32, jFreeChart33, chartChangeEventType34);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color32, stroke36);
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart40 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType41 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent42 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color39, jFreeChart40, chartChangeEventType41);
        java.awt.Stroke stroke43 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color39, stroke43);
        valueMarker37.setOutlineStroke(stroke43);
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace47 = color46.getColorSpace();
        valueMarker37.setLabelPaint((java.awt.Paint) color46);
        org.jfree.chart.text.TextAnchor textAnchor49 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker37.setLabelTextAnchor(textAnchor49);
        org.jfree.chart.util.Layer layer51 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str52 = layer51.toString();
        boolean boolean54 = categoryPlot29.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker37, layer51, true);
        org.jfree.chart.axis.AxisLocation axisLocation55 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot29.setRangeAxisLocation(axisLocation55);
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = categoryPlot29.getDomainAxisForDataset(0);
        org.jfree.chart.plot.IntervalMarker intervalMarker61 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke62 = intervalMarker61.getOutlineStroke();
        intervalMarker61.setStartValue((double) 2.0f);
        intervalMarker61.setStartValue((double) 1);
        categoryPlot29.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker61);
        org.jfree.chart.util.Layer layer68 = null;
        boolean boolean70 = categoryPlot0.removeDomainMarker(13, (org.jfree.chart.plot.Marker) intervalMarker61, layer68, true);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(colorSpace47);
        org.junit.Assert.assertNotNull(textAnchor49);
        org.junit.Assert.assertNotNull(layer51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Layer.FOREGROUND" + "'", str52.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertNull(categoryAxis58);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        float float2 = categoryAxis0.getTickMarkOutsideLength();
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis0.setLabelFont(font3);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) (-16777216));
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 10, (float) 1, 100.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        xYPlot0.zoomRangeAxes((double) (short) 0, plotRenderingInfo32, point2D33, false);
        org.jfree.chart.axis.ValueAxis valueAxis36 = xYPlot0.getDomainAxis();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        int int38 = xYPlot0.indexOf(xYDataset37);
        org.jfree.chart.util.Layer layer40 = null;
        java.util.Collection collection41 = xYPlot0.getDomainMarkers(0, layer40);
        java.awt.Paint paint42 = xYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        int int44 = xYPlot0.getIndexOf(xYItemRenderer43);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis46 = xYPlot0.getDomainAxisForDataset((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 35 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(valueAxis36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        org.jfree.chart.LegendItemCollection legendItemCollection31 = null;
        xYPlot0.setFixedLegendItems(legendItemCollection31);
        xYPlot0.setRangeCrosshairLockedOnData(false);
        boolean boolean35 = xYPlot0.isRangeCrosshairLockedOnData();
        java.awt.Paint paint37 = xYPlot0.getQuadrantPaint((int) (byte) 0);
        java.lang.String str38 = xYPlot0.getNoDataMessage();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(paint37);
        org.junit.Assert.assertNull(str38);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(11.0d);
        org.jfree.chart.text.TextAnchor textAnchor2 = valueMarker1.getLabelTextAnchor();
        java.awt.Paint[] paintArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        boolean boolean4 = textAnchor2.equals((java.lang.Object) paintArray3);
        java.awt.Paint[] paintArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color9 = java.awt.Color.WHITE;
        java.awt.Color color10 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color7, color8, color9, color10 };
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray16 = new java.awt.Paint[] { color12, color13, color14, color15 };
        java.awt.Paint[] paintArray17 = null;
        java.awt.Stroke stroke18 = null;
        java.awt.Stroke[] strokeArray19 = new java.awt.Stroke[] { stroke18 };
        java.awt.Stroke stroke20 = null;
        java.awt.Stroke[] strokeArray21 = new java.awt.Stroke[] { stroke20 };
        java.awt.Shape shape22 = null;
        java.awt.Shape[] shapeArray23 = new java.awt.Shape[] { shape22 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier24 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray11, paintArray16, paintArray17, strokeArray19, strokeArray21, shapeArray23);
        java.awt.Stroke[] strokeArray25 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray26 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray3, paintArray5, paintArray6, strokeArray21, strokeArray25, shapeArray26);
        java.awt.Paint paint28 = defaultDrawingSupplier27.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paintArray16);
        org.junit.Assert.assertNotNull(strokeArray19);
        org.junit.Assert.assertNotNull(strokeArray21);
        org.junit.Assert.assertNotNull(shapeArray23);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertNotNull(shapeArray26);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        int int3 = categoryPlot0.getRangeAxisCount();
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.util.List list11 = null;
        xYPlot8.drawDomainTickBands(graphics2D9, rectangle2D10, list11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart22 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color21, jFreeChart22, chartChangeEventType23);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color21, stroke25);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart29 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType30 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color28, jFreeChart29, chartChangeEventType30);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color28, stroke32);
        valueMarker26.setOutlineStroke(stroke32);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace36 = color35.getColorSpace();
        valueMarker26.setLabelPaint((java.awt.Paint) color35);
        org.jfree.chart.text.TextAnchor textAnchor38 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker26.setLabelTextAnchor(textAnchor38);
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str41 = layer40.toString();
        boolean boolean43 = categoryPlot18.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker26, layer40, true);
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean46 = xYPlot16.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker26, layer44, true);
        xYPlot16.setRangeGridlinesVisible(false);
        xYPlot16.setForegroundAlpha(0.0f);
        java.awt.geom.Point2D point2D51 = xYPlot16.getQuadrantOrigin();
        xYPlot8.zoomDomainAxes((double) '4', (double) 11, plotRenderingInfo15, point2D51);
        categoryPlot0.zoomDomainAxes((double) 2.0f, plotRenderingInfo7, point2D51);
        categoryPlot0.clearRangeMarkers();
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(colorSpace36);
        org.junit.Assert.assertNotNull(textAnchor38);
        org.junit.Assert.assertNotNull(layer40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Layer.FOREGROUND" + "'", str41.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(point2D51);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        dateAxis1.setNegativeArrowVisible(false);
        dateAxis1.setAutoTickUnitSelection(true, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis10.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font14 = categoryAxis12.getTickLabelFont((java.lang.Comparable) 4);
        dateAxis10.setTickLabelFont(font14);
        dateAxis1.setTickLabelFont(font14);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis1.getStandardTickUnits();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot22.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot22.getDomainAxis();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart27 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType28 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color26, jFreeChart27, chartChangeEventType28);
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color26, stroke30);
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke34 = categoryAxis33.getTickMarkStroke();
        categoryAxis33.setLabelToolTip("hi!");
        categoryAxis33.setLabel("");
        boolean boolean39 = layer32.equals((java.lang.Object) categoryAxis33);
        boolean boolean40 = categoryPlot22.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker31, layer32);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        categoryPlot22.setRenderer(categoryItemRenderer41, false);
        org.jfree.chart.axis.AxisSpace axisSpace44 = null;
        categoryPlot22.setFixedRangeAxisSpace(axisSpace44);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = categoryPlot22.getDomainAxisEdge(4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        try {
            org.jfree.chart.axis.AxisState axisState49 = dateAxis1.draw(graphics2D18, (double) (byte) 0, rectangle2D20, rectangle2D21, rectangleEdge47, plotRenderingInfo48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(rectangleEdge47);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        java.awt.Font font31 = xYPlot0.getNoDataMessageFont();
        xYPlot0.setWeight((int) (byte) 1);
        org.jfree.chart.axis.AxisSpace axisSpace34 = xYPlot0.getFixedRangeAxisSpace();
        boolean boolean35 = xYPlot0.isRangeZoomable();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = null;
        xYPlot0.datasetChanged(datasetChangeEvent36);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray38 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot0.setRenderers(xYItemRendererArray38);
        org.jfree.chart.plot.IntervalMarker intervalMarker42 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke43 = intervalMarker42.getOutlineStroke();
        intervalMarker42.setStartValue((double) 2.0f);
        xYPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker42);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNull(axisSpace34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(xYItemRendererArray38);
        org.junit.Assert.assertNotNull(stroke43);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        java.awt.Font font31 = xYPlot0.getNoDataMessageFont();
        xYPlot0.setWeight((int) (byte) 1);
        org.jfree.chart.axis.AxisSpace axisSpace34 = xYPlot0.getFixedRangeAxisSpace();
        boolean boolean35 = xYPlot0.isRangeZoomable();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = null;
        xYPlot0.datasetChanged(datasetChangeEvent36);
        org.jfree.chart.event.PlotChangeListener plotChangeListener38 = null;
        xYPlot0.addChangeListener(plotChangeListener38);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNull(axisSpace34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        java.awt.Color color27 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke29 = categoryAxis28.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color27, stroke29);
        categoryPlot0.setRangeGridlineStroke(stroke29);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke32);
        categoryPlot0.clearRangeMarkers(100);
        float float36 = categoryPlot0.getForegroundAlpha();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 1.0f + "'", float36 == 1.0f);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color2, color3, color4, color5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color7, color8, color9, color10 };
        java.awt.Paint[] paintArray12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke stroke15 = null;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        java.awt.Shape shape17 = null;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray14, strokeArray16, shapeArray18);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        categoryPlot0.setWeight((int) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot0.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = dateAxis26.getLabelInsets();
        categoryPlot0.setRangeAxis(12, (org.jfree.chart.axis.ValueAxis) dateAxis26);
        dateAxis26.setAutoRangeMinimumSize((double) 9);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNotNull(rectangleInsets27);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection27 = categoryPlot0.getRangeMarkers(layer26);
        double double28 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNull(valueAxis29);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-245), (double) 100L, (double) 2.0f, (double) 1.0f);
        double double6 = rectangleInsets4.calculateTopOutset((double) 100);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-245.0d) + "'", double6 == (-245.0d));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot0.getDomainAxisEdge((int) (byte) 0);
        categoryPlot0.clearDomainMarkers(0);
        categoryPlot0.setRangeGridlinesVisible(true);
        try {
            categoryPlot0.setBackgroundImageAlpha((float) 192);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
//        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
//        float float2 = categoryAxis0.getTickMarkOutsideLength();
//        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
//        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis4.getLabelInsets();
//        double double7 = rectangleInsets5.calculateBottomInset((double) 1);
//        double double9 = rectangleInsets5.trimHeight((double) (-1));
//        categoryAxis0.setLabelInsets(rectangleInsets5);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        long long12 = day11.getFirstMillisecond();
//        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
//        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        org.jfree.chart.JFreeChart jFreeChart17 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType18 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color16, jFreeChart17, chartChangeEventType18);
//        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color16, stroke20);
//        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        org.jfree.chart.JFreeChart jFreeChart24 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType25 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color23, jFreeChart24, chartChangeEventType25);
//        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color23, stroke27);
//        valueMarker21.setOutlineStroke(stroke27);
//        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        java.awt.color.ColorSpace colorSpace31 = color30.getColorSpace();
//        valueMarker21.setLabelPaint((java.awt.Paint) color30);
//        org.jfree.chart.text.TextAnchor textAnchor33 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
//        valueMarker21.setLabelTextAnchor(textAnchor33);
//        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.FOREGROUND;
//        java.lang.String str36 = layer35.toString();
//        boolean boolean38 = categoryPlot13.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker21, layer35, true);
//        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.BACKGROUND;
//        java.util.Collection collection40 = categoryPlot13.getRangeMarkers(layer39);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent41 = null;
//        categoryPlot13.rendererChanged(rendererChangeEvent41);
//        org.jfree.chart.axis.AxisLocation axisLocation43 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
//        categoryPlot13.setRangeAxisLocation(axisLocation43);
//        org.jfree.chart.axis.AxisLocation axisLocation45 = axisLocation43.getOpposite();
//        int int46 = day11.compareTo((java.lang.Object) axisLocation45);
//        java.lang.String str47 = day11.toString();
//        java.util.Date date48 = day11.getEnd();
//        java.awt.Paint paint49 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) day11);
//        int int50 = day11.getYear();
//        org.junit.Assert.assertNotNull(stroke1);
//        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
//        org.junit.Assert.assertNotNull(rectangleInsets5);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-7.0d) + "'", double9 == (-7.0d));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertNotNull(color16);
//        org.junit.Assert.assertNotNull(stroke20);
//        org.junit.Assert.assertNotNull(color23);
//        org.junit.Assert.assertNotNull(stroke27);
//        org.junit.Assert.assertNotNull(color30);
//        org.junit.Assert.assertNotNull(colorSpace31);
//        org.junit.Assert.assertNotNull(textAnchor33);
//        org.junit.Assert.assertNotNull(layer35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Layer.FOREGROUND" + "'", str36.equals("Layer.FOREGROUND"));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(layer39);
//        org.junit.Assert.assertNotNull(collection40);
//        org.junit.Assert.assertNotNull(axisLocation43);
//        org.junit.Assert.assertNotNull(axisLocation45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "13-June-2019" + "'", str47.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(paint49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2019 + "'", int50 == 2019);
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        java.awt.Color color5 = java.awt.Color.yellow;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int8 = color7.getTransparency();
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color7);
        org.jfree.chart.axis.AxisLocation axisLocation11 = xYPlot0.getDomainAxisLocation((-1));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        categoryPlot0.setAnchorValue((double) 0, true);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.util.List list11 = null;
        xYPlot8.drawDomainTickBands(graphics2D9, rectangle2D10, list11);
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot8.getRangeAxis(1);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        xYPlot8.notifyListeners(plotChangeEvent15);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis18.setNegativeArrowVisible(true);
        float float21 = dateAxis18.getTickMarkOutsideLength();
        dateAxis18.setAutoRangeMinimumSize((double) 1);
        boolean boolean24 = dateAxis18.isAxisLineVisible();
        dateAxis18.setRangeAboutValue((double) 10L, 0.05d);
        xYPlot8.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis18);
        categoryPlot0.setRangeAxis(128, (org.jfree.chart.axis.ValueAxis) dateAxis18, false);
        dateAxis18.setAutoTickUnitSelection(true);
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 2.0f + "'", float21 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        boolean boolean2 = numberAxis1.getAutoRangeIncludesZero();
        boolean boolean3 = numberAxis1.getAutoRangeIncludesZero();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = numberAxis1.getMarkerBand();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(markerAxisBand4);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.setNegativeArrowVisible(true);
        float float4 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setAutoRangeMinimumSize((double) 1);
        boolean boolean7 = dateAxis1.isAxisLineVisible();
        dateAxis1.setLabelToolTip("hi!");
        dateAxis1.setLowerMargin((double) (short) 10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        dateAxis1.setTickLabelPaint((java.awt.Paint) color12);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color1, jFreeChart2, chartChangeEventType3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke5);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent7 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker6);
        org.jfree.chart.text.TextAnchor textAnchor8 = valueMarker6.getLabelTextAnchor();
        java.lang.String str9 = textAnchor8.toString();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TextAnchor.CENTER" + "'", str9.equals("TextAnchor.CENTER"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        java.awt.Color color5 = java.awt.Color.yellow;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart15 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color14, jFreeChart15, chartChangeEventType16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color14, stroke18);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart22 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color21, jFreeChart22, chartChangeEventType23);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color21, stroke25);
        valueMarker19.setOutlineStroke(stroke25);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace29 = color28.getColorSpace();
        valueMarker19.setLabelPaint((java.awt.Paint) color28);
        org.jfree.chart.text.TextAnchor textAnchor31 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker19.setLabelTextAnchor(textAnchor31);
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str34 = layer33.toString();
        boolean boolean36 = categoryPlot11.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker19, layer33, true);
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean39 = xYPlot9.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker19, layer37, true);
        xYPlot9.setRangeGridlinesVisible(false);
        xYPlot9.setForegroundAlpha(0.0f);
        java.awt.geom.Point2D point2D44 = xYPlot9.getQuadrantOrigin();
        xYPlot0.zoomRangeAxes((double) (byte) 1, plotRenderingInfo8, point2D44, false);
        org.jfree.data.xy.XYDataset xYDataset47 = xYPlot0.getDataset();
        xYPlot0.mapDatasetToDomainAxis((int) (byte) 1, 1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(colorSpace29);
        org.junit.Assert.assertNotNull(textAnchor31);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Layer.FOREGROUND" + "'", str34.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(point2D44);
        org.junit.Assert.assertNull(xYDataset47);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        java.awt.Font font31 = xYPlot0.getNoDataMessageFont();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart34 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType35 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent36 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color33, jFreeChart34, chartChangeEventType35);
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color33, stroke37);
        valueMarker38.setLabel("");
        boolean boolean41 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker38);
        java.awt.Paint paint42 = xYPlot0.getBackgroundPaint();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color2, color3, color4, color5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color7, color8, color9, color10 };
        java.awt.Paint[] paintArray12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke stroke15 = null;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        java.awt.Shape shape17 = null;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray14, strokeArray16, shapeArray18);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        categoryPlot0.setWeight((int) (byte) 10);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot25.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = categoryPlot25.getDomainAxis();
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart30 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType31 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent32 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color29, jFreeChart30, chartChangeEventType31);
        java.awt.Stroke stroke33 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color29, stroke33);
        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke37 = categoryAxis36.getTickMarkStroke();
        categoryAxis36.setLabelToolTip("hi!");
        categoryAxis36.setLabel("");
        boolean boolean42 = layer35.equals((java.lang.Object) categoryAxis36);
        boolean boolean43 = categoryPlot25.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker34, layer35);
        boolean boolean44 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker34);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        categoryPlot0.setRenderer(categoryItemRenderer45);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNull(categoryAxis27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(layer35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color2, color3, color4, color5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color7, color8, color9, color10 };
        java.awt.Paint[] paintArray12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke stroke15 = null;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        java.awt.Shape shape17 = null;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray14, strokeArray16, shapeArray18);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        categoryPlot0.setWeight((int) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot0.getDomainAxis();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation26 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNull(categoryAxis23);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        org.jfree.chart.LegendItemCollection legendItemCollection31 = null;
        xYPlot0.setFixedLegendItems(legendItemCollection31);
        xYPlot0.setRangeCrosshairLockedOnData(false);
        java.awt.Stroke stroke35 = xYPlot0.getOutlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis38.configure();
        boolean boolean40 = dateAxis38.isAutoRange();
        java.awt.Shape shape41 = dateAxis38.getLeftArrow();
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = dateAxis38.java2DToValue((double) 0.0f, rectangle2D43, rectangleEdge44);
        dateAxis38.setRangeWithMargins((double) 2.0f, (double) 12);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis50.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font54 = categoryAxis52.getTickLabelFont((java.lang.Comparable) 4);
        dateAxis50.setTickLabelFont(font54);
        dateAxis38.setLabelFont(font54);
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis38, true);
        java.awt.Paint paint59 = xYPlot0.getDomainZeroBaselinePaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray61 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer60 };
        xYPlot0.setRenderers(xYItemRendererArray61);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(xYItemRendererArray61);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand1 = numberAxis0.getMarkerBand();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = numberAxis0.getTickUnit();
        java.awt.Paint paint3 = numberAxis0.getTickMarkPaint();
        org.junit.Assert.assertNull(markerAxisBand1);
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertNotNull(paint3);
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
//        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        org.jfree.chart.JFreeChart jFreeChart6 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
//        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
//        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        org.jfree.chart.JFreeChart jFreeChart13 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
//        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
//        valueMarker10.setOutlineStroke(stroke16);
//        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
//        valueMarker10.setLabelPaint((java.awt.Paint) color19);
//        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
//        valueMarker10.setLabelTextAnchor(textAnchor22);
//        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
//        java.lang.String str25 = layer24.toString();
//        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
//        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
//        java.util.Collection collection29 = categoryPlot2.getRangeMarkers(layer28);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
//        categoryPlot2.rendererChanged(rendererChangeEvent30);
//        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
//        categoryPlot2.setRangeAxisLocation(axisLocation32);
//        org.jfree.chart.axis.AxisLocation axisLocation34 = axisLocation32.getOpposite();
//        int int35 = day0.compareTo((java.lang.Object) axisLocation34);
//        java.lang.String str36 = day0.toString();
//        java.util.Date date37 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day0.previous();
//        long long39 = day0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertNotNull(color5);
//        org.junit.Assert.assertNotNull(stroke9);
//        org.junit.Assert.assertNotNull(color12);
//        org.junit.Assert.assertNotNull(stroke16);
//        org.junit.Assert.assertNotNull(color19);
//        org.junit.Assert.assertNotNull(colorSpace20);
//        org.junit.Assert.assertNotNull(textAnchor22);
//        org.junit.Assert.assertNotNull(layer24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(layer28);
//        org.junit.Assert.assertNotNull(collection29);
//        org.junit.Assert.assertNotNull(axisLocation32);
//        org.junit.Assert.assertNotNull(axisLocation34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560409200000L + "'", long39 == 1560409200000L);
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.configure();
        boolean boolean3 = dateAxis1.isAutoRange();
        java.awt.Shape shape4 = dateAxis1.getLeftArrow();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = dateAxis1.java2DToValue((double) 0.0f, rectangle2D6, rectangleEdge7);
        dateAxis1.setRangeWithMargins((double) 2.0f, (double) 12);
        java.awt.Paint paint12 = null;
        try {
            dateAxis1.setLabelPaint(paint12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis(128);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.util.List list9 = null;
        xYPlot6.drawDomainTickBands(graphics2D7, rectangle2D8, list9);
        java.awt.Color color11 = java.awt.Color.yellow;
        xYPlot6.setRangeCrosshairPaint((java.awt.Paint) color11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart21 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType22 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color20, jFreeChart21, chartChangeEventType22);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color20, stroke24);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart28 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType29 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent30 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color27, jFreeChart28, chartChangeEventType29);
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color27, stroke31);
        valueMarker25.setOutlineStroke(stroke31);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace35 = color34.getColorSpace();
        valueMarker25.setLabelPaint((java.awt.Paint) color34);
        org.jfree.chart.text.TextAnchor textAnchor37 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker25.setLabelTextAnchor(textAnchor37);
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str40 = layer39.toString();
        boolean boolean42 = categoryPlot17.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker25, layer39, true);
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean45 = xYPlot15.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker25, layer43, true);
        xYPlot15.setRangeGridlinesVisible(false);
        xYPlot15.setForegroundAlpha(0.0f);
        java.awt.geom.Point2D point2D50 = xYPlot15.getQuadrantOrigin();
        xYPlot6.zoomRangeAxes((double) (byte) 1, plotRenderingInfo14, point2D50, false);
        categoryPlot0.zoomDomainAxes((double) 1560409200000L, plotRenderingInfo5, point2D50);
        org.jfree.chart.plot.ValueMarker valueMarker56 = new org.jfree.chart.plot.ValueMarker(11.0d);
        org.jfree.chart.text.TextAnchor textAnchor57 = valueMarker56.getLabelTextAnchor();
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot0.addRangeMarker(8, (org.jfree.chart.plot.Marker) valueMarker56, layer58);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(colorSpace35);
        org.junit.Assert.assertNotNull(textAnchor37);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Layer.FOREGROUND" + "'", str40.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(layer43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(point2D50);
        org.junit.Assert.assertNotNull(textAnchor57);
        org.junit.Assert.assertNotNull(layer58);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation26);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        int int30 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis32 = categoryPlot0.getRangeAxisForDataset(0);
        boolean boolean33 = categoryPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        dateAxis1.setRange((double) (short) 0, (double) (short) 10);
        boolean boolean7 = dateAxis1.isHiddenValue((long) 10);
        org.jfree.chart.plot.Plot plot8 = dateAxis1.getPlot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis1.setTickMarkPaint((java.awt.Paint) color9);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        float float2 = categoryAxis0.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis4.getLabelInsets();
        double double7 = rectangleInsets5.calculateBottomInset((double) 1);
        double double9 = rectangleInsets5.trimHeight((double) (-1));
        categoryAxis0.setLabelInsets(rectangleInsets5);
        double double12 = rectangleInsets5.calculateLeftOutset((double) 11);
        java.lang.String str13 = rectangleInsets5.toString();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D17 = rectangleInsets5.createOutsetRectangle(rectangle2D14, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-7.0d) + "'", double9 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]" + "'", str13.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        java.awt.Font font31 = xYPlot0.getNoDataMessageFont();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis33.setNegativeArrowVisible(true);
        java.awt.Shape shape36 = dateAxis33.getUpArrow();
        dateAxis33.setLabelURL("");
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis33);
        java.util.Date date40 = dateAxis33.getMaximumDate();
        dateAxis33.setLabelToolTip("RectangleAnchor.BOTTOM");
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(date40);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        xYPlot0.clearDomainAxes();
        boolean boolean13 = xYPlot0.isOutlineVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot0.getRangeAxisEdge(12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart24 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType25 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color23, jFreeChart24, chartChangeEventType25);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color23, stroke27);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart31 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType32 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color30, jFreeChart31, chartChangeEventType32);
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color30, stroke34);
        valueMarker28.setOutlineStroke(stroke34);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace38 = color37.getColorSpace();
        valueMarker28.setLabelPaint((java.awt.Paint) color37);
        org.jfree.chart.text.TextAnchor textAnchor40 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker28.setLabelTextAnchor(textAnchor40);
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str43 = layer42.toString();
        boolean boolean45 = categoryPlot20.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker28, layer42, true);
        org.jfree.chart.util.Layer layer46 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean48 = xYPlot18.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker28, layer46, true);
        xYPlot18.setRangeGridlinesVisible(false);
        xYPlot18.setForegroundAlpha(0.0f);
        java.awt.geom.Point2D point2D53 = xYPlot18.getQuadrantOrigin();
        xYPlot0.zoomRangeAxes((double) '#', plotRenderingInfo17, point2D53, true);
        org.jfree.chart.plot.Plot plot56 = xYPlot0.getParent();
        xYPlot0.mapDatasetToRangeAxis((int) (byte) 1, 192);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(colorSpace38);
        org.junit.Assert.assertNotNull(textAnchor40);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Layer.FOREGROUND" + "'", str43.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(layer46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(point2D53);
        org.junit.Assert.assertNull(plot56);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getRangeAxis(1);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone9 = dateAxis8.getTimeZone();
        dateAxis8.setRange((double) (short) 0, (double) (short) 10);
        boolean boolean13 = dateAxis8.isVerticalTickLabels();
        xYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis8);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.util.List list20 = null;
        xYPlot17.drawDomainTickBands(graphics2D18, rectangle2D19, list20);
        org.jfree.chart.plot.IntervalMarker intervalMarker25 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot17.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker25, layer26, true);
        java.util.List list29 = xYPlot17.getAnnotations();
        xYPlot0.drawRangeTickBands(graphics2D15, rectangle2D16, list29);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNotNull(list29);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color2, color3, color4, color5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color7, color8, color9, color10 };
        java.awt.Paint[] paintArray12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke stroke15 = null;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        java.awt.Shape shape17 = null;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray14, strokeArray16, shapeArray18);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        categoryPlot0.setWeight((int) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot0.getDomainAxis();
        java.awt.Paint paint24 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        categoryPlot0.setDataset((int) (short) 0, categoryDataset26);
        java.awt.Paint paint28 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = categoryPlot0.getDatasetRenderingOrder();
        categoryPlot0.mapDatasetToRangeAxis(2019, 1);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = categoryAxis0.getCategoryLabelPositions();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke6 = intervalMarker5.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot7.getDomainAxis();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart12, chartChangeEventType13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke19 = categoryAxis18.getTickMarkStroke();
        categoryAxis18.setLabelToolTip("hi!");
        categoryAxis18.setLabel("");
        boolean boolean24 = layer17.equals((java.lang.Object) categoryAxis18);
        boolean boolean25 = categoryPlot7.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker16, layer17);
        boolean boolean26 = categoryPlot0.removeDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) intervalMarker5, layer17);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        categoryPlot0.setAnchorValue(1.0d, true);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        dateAxis1.setNegativeArrowVisible(false);
        dateAxis1.setAutoTickUnitSelection(true, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis1.getLabelInsets();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis10.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font14 = categoryAxis12.getTickLabelFont((java.lang.Comparable) 4);
        dateAxis10.setTickLabelFont(font14);
        dateAxis1.setTickLabelFont(font14);
        dateAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart25 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType26 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color24, jFreeChart25, chartChangeEventType26);
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color24, stroke28);
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart32 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType33 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent34 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color31, jFreeChart32, chartChangeEventType33);
        java.awt.Stroke stroke35 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker36 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color31, stroke35);
        valueMarker29.setOutlineStroke(stroke35);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace39 = color38.getColorSpace();
        valueMarker29.setLabelPaint((java.awt.Paint) color38);
        org.jfree.chart.text.TextAnchor textAnchor41 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker29.setLabelTextAnchor(textAnchor41);
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str44 = layer43.toString();
        boolean boolean46 = categoryPlot21.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker29, layer43, true);
        org.jfree.chart.util.Layer layer47 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean49 = xYPlot19.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker29, layer47, true);
        java.awt.Font font50 = xYPlot19.getNoDataMessageFont();
        boolean boolean51 = dateAxis1.equals((java.lang.Object) font50);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(colorSpace39);
        org.junit.Assert.assertNotNull(textAnchor41);
        org.junit.Assert.assertNotNull(layer43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Layer.FOREGROUND" + "'", str44.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(layer47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        categoryAxis0.setLabelToolTip("hi!");
        categoryAxis0.setLabel("");
        java.awt.Font font6 = categoryAxis0.getLabelFont();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis(128);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.util.List list9 = null;
        xYPlot6.drawDomainTickBands(graphics2D7, rectangle2D8, list9);
        java.awt.Color color11 = java.awt.Color.yellow;
        xYPlot6.setRangeCrosshairPaint((java.awt.Paint) color11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart21 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType22 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color20, jFreeChart21, chartChangeEventType22);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color20, stroke24);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart28 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType29 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent30 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color27, jFreeChart28, chartChangeEventType29);
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color27, stroke31);
        valueMarker25.setOutlineStroke(stroke31);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace35 = color34.getColorSpace();
        valueMarker25.setLabelPaint((java.awt.Paint) color34);
        org.jfree.chart.text.TextAnchor textAnchor37 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker25.setLabelTextAnchor(textAnchor37);
        org.jfree.chart.util.Layer layer39 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str40 = layer39.toString();
        boolean boolean42 = categoryPlot17.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker25, layer39, true);
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean45 = xYPlot15.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker25, layer43, true);
        xYPlot15.setRangeGridlinesVisible(false);
        xYPlot15.setForegroundAlpha(0.0f);
        java.awt.geom.Point2D point2D50 = xYPlot15.getQuadrantOrigin();
        xYPlot6.zoomRangeAxes((double) (byte) 1, plotRenderingInfo14, point2D50, false);
        categoryPlot0.zoomDomainAxes((double) 1560409200000L, plotRenderingInfo5, point2D50);
        boolean boolean54 = categoryPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(colorSpace35);
        org.junit.Assert.assertNotNull(textAnchor37);
        org.junit.Assert.assertNotNull(layer39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Layer.FOREGROUND" + "'", str40.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(layer43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(point2D50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxis(128);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color8, jFreeChart9, chartChangeEventType10);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color8, stroke12);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color15, jFreeChart16, chartChangeEventType17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color15, stroke19);
        valueMarker13.setOutlineStroke(stroke19);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace23 = color22.getColorSpace();
        valueMarker13.setLabelPaint((java.awt.Paint) color22);
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker13.setLabelTextAnchor(textAnchor25);
        org.jfree.chart.util.Layer layer27 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str28 = layer27.toString();
        boolean boolean30 = categoryPlot5.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker13, layer27, true);
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection32 = categoryPlot5.getRangeMarkers(layer31);
        org.jfree.chart.LegendItemCollection legendItemCollection33 = categoryPlot5.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection33);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(colorSpace23);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNotNull(layer27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Layer.FOREGROUND" + "'", str28.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertNotNull(legendItemCollection33);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getRangeAxis(1);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        xYPlot0.notifyListeners(plotChangeEvent7);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent9 = null;
        xYPlot0.datasetChanged(datasetChangeEvent9);
        xYPlot0.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color2, color3, color4, color5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color7, color8, color9, color10 };
        java.awt.Paint[] paintArray12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke stroke15 = null;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        java.awt.Shape shape17 = null;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray14, strokeArray16, shapeArray18);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        org.jfree.data.general.DatasetGroup datasetGroup21 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.axis.AxisSpace axisSpace22 = categoryPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNull(datasetGroup21);
        org.junit.Assert.assertNull(axisSpace22);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color2, color3, color4, color5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color7, color8, color9, color10 };
        java.awt.Paint[] paintArray12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke stroke15 = null;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        java.awt.Shape shape17 = null;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray14, strokeArray16, shapeArray18);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        org.jfree.data.general.DatasetGroup datasetGroup21 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot0.getDomainAxisForDataset((int) (short) 0);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNull(datasetGroup21);
        org.junit.Assert.assertNull(categoryAxis23);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.awt.Shape shape2 = dateAxis1.getDownArrow();
        boolean boolean3 = dateAxis1.isPositiveArrowVisible();
        java.awt.Font font4 = dateAxis1.getLabelFont();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.BASELINE_RIGHT");
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        dateAxis1.setNegativeArrowVisible(false);
        dateAxis1.setAutoTickUnitSelection(true, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot8.getDomainAxis();
        java.awt.Paint paint11 = categoryPlot8.getBackgroundPaint();
        categoryPlot8.setAnchorValue((double) 0, true);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.util.List list19 = null;
        xYPlot16.drawDomainTickBands(graphics2D17, rectangle2D18, list19);
        org.jfree.chart.axis.ValueAxis valueAxis22 = xYPlot16.getRangeAxis(1);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent23 = null;
        xYPlot16.notifyListeners(plotChangeEvent23);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis26.setNegativeArrowVisible(true);
        float float29 = dateAxis26.getTickMarkOutsideLength();
        dateAxis26.setAutoRangeMinimumSize((double) 1);
        boolean boolean32 = dateAxis26.isAxisLineVisible();
        dateAxis26.setRangeAboutValue((double) 10L, 0.05d);
        xYPlot16.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis26);
        categoryPlot8.setRangeAxis(128, (org.jfree.chart.axis.ValueAxis) dateAxis26, false);
        java.awt.Color color39 = java.awt.Color.GREEN;
        categoryPlot8.setRangeGridlinePaint((java.awt.Paint) color39);
        boolean boolean41 = dateAxis1.hasListener((java.util.EventListener) categoryPlot8);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 2.0f + "'", float29 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke6 = intervalMarker5.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot7.getDomainAxis();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color11, jFreeChart12, chartChangeEventType13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color11, stroke15);
        org.jfree.chart.util.Layer layer17 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke19 = categoryAxis18.getTickMarkStroke();
        categoryAxis18.setLabelToolTip("hi!");
        categoryAxis18.setLabel("");
        boolean boolean24 = layer17.equals((java.lang.Object) categoryAxis18);
        boolean boolean25 = categoryPlot7.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker16, layer17);
        boolean boolean26 = categoryPlot0.removeDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) intervalMarker5, layer17);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        int int30 = categoryPlot0.getIndexOf(categoryItemRenderer29);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(layer17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        xYPlot0.clearDomainAxes();
        boolean boolean13 = xYPlot0.isOutlineVisible();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        boolean boolean16 = xYPlot0.isDomainCrosshairLockedOnData();
        java.awt.Color color17 = java.awt.Color.GRAY;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color17);
        java.awt.Color color25 = java.awt.Color.red;
        float[] floatArray30 = new float[] { 100L, 10.0f, (-1), 0L };
        float[] floatArray31 = color25.getComponents(floatArray30);
        float[] floatArray32 = java.awt.Color.RGBtoHSB(100, (int) ' ', 0, floatArray30);
        float[] floatArray33 = java.awt.Color.RGBtoHSB(128, 1, 0, floatArray32);
        float[] floatArray34 = color17.getColorComponents(floatArray32);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis0.getCategoryEnd((int) (byte) -1, 1, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color7);
        java.util.EventListener eventListener9 = null;
        boolean boolean10 = categoryAxis0.hasListener(eventListener9);
        categoryAxis0.setCategoryMargin((double) (byte) 0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        float float2 = categoryAxis0.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis4.getLabelInsets();
        double double7 = rectangleInsets5.calculateBottomInset((double) 1);
        double double9 = rectangleInsets5.trimHeight((double) (-1));
        categoryAxis0.setLabelInsets(rectangleInsets5);
        double double12 = rectangleInsets5.trimWidth((double) 10);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-7.0d) + "'", double9 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation26);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke29 = categoryAxis28.getTickMarkStroke();
        categoryAxis28.setFixedDimension((double) 10.0f);
        java.lang.String str32 = categoryAxis28.getLabel();
        java.util.List list33 = categoryPlot0.getCategoriesForAxis(categoryAxis28);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertNotNull(list33);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color1, jFreeChart2, chartChangeEventType3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke5);
        valueMarker6.setLabel("");
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart15 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color14, jFreeChart15, chartChangeEventType16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color14, stroke18);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart22 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color21, jFreeChart22, chartChangeEventType23);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color21, stroke25);
        valueMarker19.setOutlineStroke(stroke25);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace29 = color28.getColorSpace();
        valueMarker19.setLabelPaint((java.awt.Paint) color28);
        org.jfree.chart.text.TextAnchor textAnchor31 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker19.setLabelTextAnchor(textAnchor31);
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str34 = layer33.toString();
        boolean boolean36 = categoryPlot11.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker19, layer33, true);
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean39 = xYPlot9.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker19, layer37, true);
        org.jfree.chart.LegendItemCollection legendItemCollection40 = null;
        xYPlot9.setFixedLegendItems(legendItemCollection40);
        xYPlot9.setRangeCrosshairLockedOnData(false);
        java.awt.Paint paint44 = xYPlot9.getRangeZeroBaselinePaint();
        valueMarker6.setPaint(paint44);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(colorSpace29);
        org.junit.Assert.assertNotNull(textAnchor31);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Layer.FOREGROUND" + "'", str34.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.configure();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font5 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 4);
        dateAxis1.setTickLabelFont(font5);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis8.configure();
        boolean boolean10 = dateAxis8.isAutoRange();
        java.awt.Shape shape11 = dateAxis8.getLeftArrow();
        org.jfree.data.Range range12 = dateAxis8.getDefaultAutoRange();
        dateAxis1.setRangeWithMargins(range12);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(range12);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color4, jFreeChart5, chartChangeEventType6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color4, stroke8);
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke12 = categoryAxis11.getTickMarkStroke();
        categoryAxis11.setLabelToolTip("hi!");
        categoryAxis11.setLabel("");
        boolean boolean17 = layer10.equals((java.lang.Object) categoryAxis11);
        boolean boolean18 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9, layer10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot0.setRenderer(categoryItemRenderer19, false);
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace22);
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke27 = categoryAxis26.getTickMarkStroke();
        categoryAxis26.setLabelToolTip("hi!");
        categoryAxis26.setLabel("");
        int int32 = categoryAxis26.getMaximumCategoryLabelLines();
        categoryAxis26.addCategoryLabelToolTip((java.lang.Comparable) 2.0f, "SeriesRenderingOrder.REVERSE");
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        boolean boolean38 = numberAxis37.getAutoRangeIncludesZero();
        boolean boolean39 = numberAxis37.getAutoRangeStickyZero();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, (org.jfree.chart.axis.ValueAxis) numberAxis37, categoryItemRenderer40);
        int int42 = categoryPlot0.getDomainAxisIndex(categoryAxis26);
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(layer10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        java.awt.Color color27 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke29 = categoryAxis28.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color27, stroke29);
        categoryPlot0.setRangeGridlineStroke(stroke29);
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone35 = dateAxis34.getTimeZone();
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = dateAxis34.java2DToValue((double) (short) 100, rectangle2D37, rectangleEdge38);
        dateAxis34.setLowerBound((double) (byte) 100);
        categoryPlot0.setRangeAxis(10, (org.jfree.chart.axis.ValueAxis) dateAxis34, true);
        categoryPlot0.setAnchorValue((double) '4');
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        categoryPlot0.setRenderer(categoryItemRenderer46, true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 9.223372036854776E18d + "'", double39 == 9.223372036854776E18d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        categoryPlot0.setAnchorValue((double) 0, true);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = dateAxis10.getLabelInsets();
        double double13 = rectangleInsets11.calculateBottomInset((double) 1);
        double double15 = rectangleInsets11.trimHeight((double) (-1));
        org.jfree.chart.util.UnitType unitType16 = rectangleInsets11.getUnitType();
        double double18 = rectangleInsets11.calculateLeftOutset(0.0d);
        categoryPlot0.setAxisOffset(rectangleInsets11);
        double double21 = rectangleInsets11.calculateBottomInset(1.0d);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets11.createOutsetRectangle(rectangle2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.0d + "'", double13 == 3.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-7.0d) + "'", double15 == (-7.0d));
        org.junit.Assert.assertNotNull(unitType16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.0d + "'", double18 == 3.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21 == 3.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.setNegativeArrowVisible(true);
        dateAxis1.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.util.List list12 = null;
        xYPlot9.drawDomainTickBands(graphics2D10, rectangle2D11, list12);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot9.getRangeAxisEdge((int) (short) 0);
        try {
            java.util.List list16 = dateAxis1.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        boolean boolean2 = numberAxis1.getAutoRangeIncludesZero();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = numberAxis1.getMarkerBand();
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis5.configure();
        boolean boolean7 = dateAxis5.isAutoRange();
        org.jfree.data.time.DateRange dateRange8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis5.setRangeWithMargins((org.jfree.data.Range) dateRange8);
        numberAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange8);
        numberAxis1.setAutoRangeStickyZero(false);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart20 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType21 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color19, jFreeChart20, chartChangeEventType21);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color19, stroke23);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart27 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType28 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color26, jFreeChart27, chartChangeEventType28);
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color26, stroke30);
        valueMarker24.setOutlineStroke(stroke30);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace34 = color33.getColorSpace();
        valueMarker24.setLabelPaint((java.awt.Paint) color33);
        org.jfree.chart.text.TextAnchor textAnchor36 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker24.setLabelTextAnchor(textAnchor36);
        org.jfree.chart.util.Layer layer38 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str39 = layer38.toString();
        boolean boolean41 = categoryPlot16.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker24, layer38, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot16.getDomainAxisEdge((int) (byte) 0);
        categoryPlot16.setRangeCrosshairLockedOnData(true);
        categoryPlot16.mapDatasetToRangeAxis(0, 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = categoryPlot16.getRangeAxisEdge(4);
        try {
            java.util.List list51 = numberAxis1.refreshTicks(graphics2D13, axisState14, rectangle2D15, rectangleEdge50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(markerAxisBand3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateRange8);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(colorSpace34);
        org.junit.Assert.assertNotNull(textAnchor36);
        org.junit.Assert.assertNotNull(layer38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Layer.FOREGROUND" + "'", str39.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNotNull(rectangleEdge50);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxisForDataset((int) (short) 10);
        org.junit.Assert.assertNull(categoryAxis2);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        java.awt.Color color5 = java.awt.Color.yellow;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart15 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color14, jFreeChart15, chartChangeEventType16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color14, stroke18);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart22 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType23 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color21, jFreeChart22, chartChangeEventType23);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color21, stroke25);
        valueMarker19.setOutlineStroke(stroke25);
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace29 = color28.getColorSpace();
        valueMarker19.setLabelPaint((java.awt.Paint) color28);
        org.jfree.chart.text.TextAnchor textAnchor31 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker19.setLabelTextAnchor(textAnchor31);
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str34 = layer33.toString();
        boolean boolean36 = categoryPlot11.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker19, layer33, true);
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean39 = xYPlot9.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker19, layer37, true);
        xYPlot9.setRangeGridlinesVisible(false);
        xYPlot9.setForegroundAlpha(0.0f);
        java.awt.geom.Point2D point2D44 = xYPlot9.getQuadrantOrigin();
        xYPlot0.zoomRangeAxes((double) (byte) 1, plotRenderingInfo8, point2D44, false);
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart49 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType50 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent51 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color48, jFreeChart49, chartChangeEventType50);
        java.awt.Stroke stroke52 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker53 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color48, stroke52);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent54 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker53);
        org.jfree.chart.text.TextAnchor textAnchor55 = valueMarker53.getLabelTextAnchor();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent56 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) valueMarker53);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        int int58 = categoryAxis57.getMaximumCategoryLabelLines();
        boolean boolean59 = valueMarker53.equals((java.lang.Object) categoryAxis57);
        boolean boolean60 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker53);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(colorSpace29);
        org.junit.Assert.assertNotNull(textAnchor31);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Layer.FOREGROUND" + "'", str34.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(point2D44);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(textAnchor55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis1.java2DToValue((double) (short) 100, rectangle2D4, rectangleEdge5);
        dateAxis1.setAutoRangeMinimumSize((double) 1, true);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis11.setNegativeArrowVisible(true);
        float float14 = dateAxis11.getTickMarkOutsideLength();
        dateAxis11.setAutoRangeMinimumSize((double) 1);
        boolean boolean17 = dateAxis11.isAxisLineVisible();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis19.configure();
        boolean boolean21 = dateAxis19.isAutoRange();
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis19.setRangeWithMargins((org.jfree.data.Range) dateRange22);
        dateAxis11.setRange((org.jfree.data.Range) dateRange22, false, true);
        dateAxis1.setRange((org.jfree.data.Range) dateRange22, false, false);
        boolean boolean31 = dateAxis1.isHiddenValue((long) '4');
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 9.223372036854776E18d + "'", double6 == 9.223372036854776E18d);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 2.0f + "'", float14 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        float float2 = categoryAxis0.getTickMarkOutsideLength();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis4.getLabelInsets();
        double double7 = rectangleInsets5.calculateBottomInset((double) 1);
        double double9 = rectangleInsets5.trimHeight((double) (-1));
        categoryAxis0.setLabelInsets(rectangleInsets5);
        categoryAxis0.setTickMarkOutsideLength((float) 64);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-7.0d) + "'", double9 == (-7.0d));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.util.List list16 = null;
        xYPlot13.drawDomainTickBands(graphics2D14, rectangle2D15, list16);
        java.awt.Color color18 = java.awt.Color.yellow;
        xYPlot13.setRangeCrosshairPaint((java.awt.Paint) color18);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color18);
        double double21 = xYPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot0.getRangeAxis((int) (byte) 0);
        org.jfree.chart.axis.ValueAxis valueAxis25 = xYPlot0.getRangeAxisForDataset((int) (byte) 0);
        java.awt.Paint paint27 = xYPlot0.getQuadrantPaint(3);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNull(paint27);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = dateAxis1.getLabelInsets();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4);
        java.lang.Object obj6 = chartChangeEvent5.getSource();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        chartChangeEvent5.setType(chartChangeEventType7);
        boolean boolean9 = rectangleInsets2.equals((java.lang.Object) chartChangeEvent5);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        java.awt.Color color5 = java.awt.Color.yellow;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int8 = color7.getTransparency();
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color7);
        org.jfree.chart.util.Layer layer11 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection12 = xYPlot0.getRangeMarkers((int) ' ', layer11);
        xYPlot0.mapDatasetToDomainAxis((int) (byte) 100, 11);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(layer11);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.setNegativeArrowVisible(true);
        float float4 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setAutoRangeMinimumSize((double) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color17, jFreeChart18, chartChangeEventType19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color17, stroke21);
        valueMarker15.setOutlineStroke(stroke21);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace25 = color24.getColorSpace();
        valueMarker15.setLabelPaint((java.awt.Paint) color24);
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker15.setLabelTextAnchor(textAnchor27);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str30 = layer29.toString();
        boolean boolean32 = categoryPlot7.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker15, layer29, true);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        categoryPlot7.clearRangeMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        boolean boolean37 = numberAxis36.getAutoRangeIncludesZero();
        org.jfree.data.Range range38 = categoryPlot7.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis36);
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot();
        xYPlot41.setRangeCrosshairVisible(true);
        java.awt.Paint paint44 = xYPlot41.getRangeGridlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = xYPlot41.getDomainAxisEdge(3);
        try {
            double double47 = numberAxis36.valueToJava2D((double) (byte) 0, rectangle2D40, rectangleEdge46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(colorSpace25);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Layer.FOREGROUND" + "'", str30.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(range38);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(rectangleEdge46);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color0);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        java.awt.Color color9 = java.awt.Color.red;
        float[] floatArray14 = new float[] { 100L, 10.0f, (-1), 0L };
        float[] floatArray15 = color9.getComponents(floatArray14);
        float[] floatArray16 = java.awt.Color.RGBtoHSB(100, (int) ' ', 0, floatArray14);
        float[] floatArray17 = color3.getComponents(colorSpace5, floatArray14);
        float[] floatArray18 = color0.getComponents(floatArray17);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.setNegativeArrowVisible(true);
        float float4 = dateAxis1.getTickMarkOutsideLength();
        dateAxis1.setAutoRangeMinimumSize((double) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart18 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent20 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color17, jFreeChart18, chartChangeEventType19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color17, stroke21);
        valueMarker15.setOutlineStroke(stroke21);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace25 = color24.getColorSpace();
        valueMarker15.setLabelPaint((java.awt.Paint) color24);
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker15.setLabelTextAnchor(textAnchor27);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str30 = layer29.toString();
        boolean boolean32 = categoryPlot7.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker15, layer29, true);
        dateAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        categoryPlot7.clearRangeMarkers();
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        boolean boolean37 = numberAxis36.getAutoRangeIncludesZero();
        org.jfree.data.Range range38 = categoryPlot7.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis36);
        boolean boolean39 = numberAxis36.getAutoRangeIncludesZero();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(colorSpace25);
        org.junit.Assert.assertNotNull(textAnchor27);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Layer.FOREGROUND" + "'", str30.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(range38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color4, jFreeChart5, chartChangeEventType6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color4, stroke8);
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke12 = categoryAxis11.getTickMarkStroke();
        categoryAxis11.setLabelToolTip("hi!");
        categoryAxis11.setLabel("");
        boolean boolean17 = layer10.equals((java.lang.Object) categoryAxis11);
        boolean boolean18 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9, layer10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot0.setRenderer(categoryItemRenderer19, false);
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace22);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke26 = categoryAxis25.getTickMarkStroke();
        float float27 = categoryAxis25.getTickMarkOutsideLength();
        categoryAxis25.setAxisLineVisible(true);
        categoryPlot0.setDomainAxis(11, categoryAxis25, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker34 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke35 = intervalMarker34.getOutlineStroke();
        intervalMarker34.setStartValue((double) 2.0f);
        intervalMarker34.setStartValue((double) 1);
        boolean boolean40 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker34);
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(layer10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 2.0f + "'", float27 == 2.0f);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        dateAxis1.setLowerMargin((double) (short) 0);
        boolean boolean5 = dateAxis1.isVisible();
        dateAxis1.setAutoRangeMinimumSize(100.0d, true);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand1 = numberAxis0.getMarkerBand();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart10 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType11 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color9, jFreeChart10, chartChangeEventType11);
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color9, stroke13);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart17 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType18 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color16, jFreeChart17, chartChangeEventType18);
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color16, stroke20);
        valueMarker14.setOutlineStroke(stroke20);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace24 = color23.getColorSpace();
        valueMarker14.setLabelPaint((java.awt.Paint) color23);
        org.jfree.chart.text.TextAnchor textAnchor26 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker14.setLabelTextAnchor(textAnchor26);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str29 = layer28.toString();
        boolean boolean31 = categoryPlot6.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker14, layer28, true);
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean34 = xYPlot4.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker14, layer32, true);
        java.awt.Font font35 = xYPlot4.getNoDataMessageFont();
        xYPlot4.setDomainCrosshairValue(1.0d);
        java.awt.Color color38 = org.jfree.chart.ChartColor.DARK_YELLOW;
        xYPlot4.setNoDataMessagePaint((java.awt.Paint) color38);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = xYPlot4.getRangeAxisEdge();
        try {
            double double41 = numberAxis0.valueToJava2D((double) 9, rectangle2D3, rectangleEdge40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(markerAxisBand1);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(colorSpace24);
        org.junit.Assert.assertNotNull(textAnchor26);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Layer.FOREGROUND" + "'", str29.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(rectangleEdge40);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color6 = java.awt.Color.WHITE;
        java.awt.Color color7 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray8 = new java.awt.Paint[] { color4, color5, color6, color7 };
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color9, color10, color11, color12 };
        java.awt.Paint[] paintArray14 = null;
        java.awt.Stroke stroke15 = null;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        java.awt.Stroke stroke17 = null;
        java.awt.Stroke[] strokeArray18 = new java.awt.Stroke[] { stroke17 };
        java.awt.Shape shape19 = null;
        java.awt.Shape[] shapeArray20 = new java.awt.Shape[] { shape19 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray8, paintArray13, paintArray14, strokeArray16, strokeArray18, shapeArray20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color25, jFreeChart26, chartChangeEventType27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color25, stroke29);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart33 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType34 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent35 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color32, jFreeChart33, chartChangeEventType34);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color32, stroke36);
        valueMarker30.setOutlineStroke(stroke36);
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace40 = color39.getColorSpace();
        valueMarker30.setLabelPaint((java.awt.Paint) color39);
        org.jfree.chart.text.TextAnchor textAnchor42 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker30.setLabelTextAnchor(textAnchor42);
        org.jfree.chart.util.Layer layer44 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str45 = layer44.toString();
        boolean boolean47 = categoryPlot22.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker30, layer44, true);
        org.jfree.chart.axis.AxisLocation axisLocation48 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot22.setRangeAxisLocation(axisLocation48);
        boolean boolean50 = defaultDrawingSupplier21.equals((java.lang.Object) axisLocation48);
        categoryPlot0.setRangeAxisLocation(axisLocation48, true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent53 = null;
        categoryPlot0.axisChanged(axisChangeEvent53);
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = categoryPlot0.getRangeAxisEdge((int) (byte) -1);
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paintArray8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(shapeArray20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(colorSpace40);
        org.junit.Assert.assertNotNull(textAnchor42);
        org.junit.Assert.assertNotNull(layer44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Layer.FOREGROUND" + "'", str45.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(rectangleEdge56);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        xYPlot0.zoomRangeAxes((double) (short) 0, plotRenderingInfo32, point2D33, false);
        org.jfree.chart.axis.ValueAxis valueAxis36 = xYPlot0.getDomainAxis();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        int int38 = xYPlot0.indexOf(xYDataset37);
        org.jfree.chart.util.Layer layer40 = null;
        java.util.Collection collection41 = xYPlot0.getDomainMarkers(0, layer40);
        java.awt.Paint paint42 = xYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        int int44 = xYPlot0.getIndexOf(xYItemRenderer43);
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int46 = color45.getTransparency();
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color45);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(valueAxis36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot0.getDomainAxisEdge((int) (byte) 0);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        categoryPlot0.mapDatasetToRangeAxis(0, 100);
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        categoryPlot0.setDataset((int) (byte) 100, categoryDataset34);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = categoryPlot0.getDomainAxisForDataset(192);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNull(categoryAxis37);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("SeriesRenderingOrder.REVERSE");
        boolean boolean2 = numberAxis1.getAutoRangeIncludesZero();
        org.jfree.data.Range range3 = numberAxis1.getDefaultAutoRange();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = categoryAxis0.getCategoryEnd((int) (byte) -1, 1, rectangle2D4, rectangleEdge5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color7);
        categoryAxis0.setCategoryLabelPositionOffset(0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        categoryAxis0.setFixedDimension((double) 10.0f);
        java.lang.String str4 = categoryAxis0.getLabel();
        java.awt.Paint paint5 = categoryAxis0.getAxisLinePaint();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot9.getFixedDomainAxisSpace();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot9.getRangeAxis(128);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot9.getDomainAxisEdge();
        try {
            double double14 = categoryAxis0.getCategoryStart(12, 0, rectangle2D8, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        java.awt.Font font31 = xYPlot0.getNoDataMessageFont();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis33.setNegativeArrowVisible(true);
        java.awt.Shape shape36 = dateAxis33.getUpArrow();
        dateAxis33.setLabelURL("");
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis33);
        java.util.Date date40 = dateAxis33.getMaximumDate();
        dateAxis33.setTickMarkOutsideLength((float) (byte) -1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(date40);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        int int3 = categoryPlot0.getRangeAxisCount();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = dateAxis6.getLabelInsets();
        double double9 = rectangleInsets7.calculateBottomInset((double) 1);
        double double11 = rectangleInsets7.trimHeight((double) (-1));
        double double13 = rectangleInsets7.calculateBottomInset((double) 'a');
        double double14 = rectangleInsets7.getLeft();
        categoryPlot0.setAxisOffset(rectangleInsets7);
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-7.0d) + "'", double11 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.0d + "'", double13 == 3.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.0d + "'", double14 == 3.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        java.awt.Color color5 = java.awt.Color.yellow;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int8 = color7.getTransparency();
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color7);
        org.jfree.chart.util.Layer layer11 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection12 = xYPlot0.getRangeMarkers((int) ' ', layer11);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder13 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder13);
        boolean boolean15 = xYPlot0.isRangeZoomable();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(layer11);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(seriesRenderingOrder13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot0.getDomainAxisEdge((int) (byte) 0);
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        categoryPlot0.mapDatasetToRangeAxis(0, 100);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = categoryPlot0.getRangeAxisEdge(4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        categoryPlot0.setRenderer((int) (byte) 1, categoryItemRenderer36);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(rectangleEdge34);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color4, jFreeChart5, chartChangeEventType6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color4, stroke8);
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke12 = categoryAxis11.getTickMarkStroke();
        categoryAxis11.setLabelToolTip("hi!");
        categoryAxis11.setLabel("");
        boolean boolean17 = layer10.equals((java.lang.Object) categoryAxis11);
        boolean boolean18 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9, layer10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot0.setRenderer(categoryItemRenderer19, false);
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace22);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke26 = categoryAxis25.getTickMarkStroke();
        float float27 = categoryAxis25.getTickMarkOutsideLength();
        categoryAxis25.setAxisLineVisible(true);
        categoryPlot0.setDomainAxis(11, categoryAxis25, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = categoryPlot0.getDomainAxisForDataset(255);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        try {
            categoryPlot0.setRenderer((int) (byte) -1, categoryItemRenderer35, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(layer10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 2.0f + "'", float27 == 2.0f);
        org.junit.Assert.assertNull(categoryAxis33);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        java.awt.Paint paint31 = xYPlot0.getDomainCrosshairPaint();
        xYPlot0.zoom(3.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot0.getRangeAxisEdge((int) (short) 0);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = null;
        xYPlot0.notifyListeners(plotChangeEvent7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.util.List list12 = null;
        xYPlot9.drawDomainTickBands(graphics2D10, rectangle2D11, list12);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer18 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot9.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker17, layer18, true);
        java.util.List list21 = xYPlot9.getAnnotations();
        java.awt.Stroke stroke22 = xYPlot9.getDomainGridlineStroke();
        xYPlot0.setRangeZeroBaselineStroke(stroke22);
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot0.addChangeListener(plotChangeListener24);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(layer18);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        boolean boolean5 = xYPlot0.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = xYPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot0.getDomainAxisEdge((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        float float2 = categoryAxis0.getTickMarkOutsideLength();
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis0.setLabelFont(font3);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = categoryAxis0.getCategoryLabelPositions();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor6, (int) (short) 0, (int) ' ', rectangle2D9, rectangleEdge10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = categoryAxis0.getCategoryLabelPositions();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions12);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        java.awt.Color color27 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke29 = categoryAxis28.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color27, stroke29);
        categoryPlot0.setRangeGridlineStroke(stroke29);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke32);
        categoryPlot0.clearRangeMarkers(100);
        int int36 = categoryPlot0.getDatasetCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot37.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = categoryPlot37.getDomainAxis();
        java.awt.Paint paint40 = categoryPlot37.getBackgroundPaint();
        categoryPlot37.setAnchorValue((double) 0, true);
        categoryPlot37.setRangeCrosshairLockedOnData(true);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = dateAxis47.getLabelInsets();
        double double50 = rectangleInsets48.calculateBottomInset((double) 1);
        double double52 = rectangleInsets48.trimHeight((double) (-1));
        org.jfree.chart.util.UnitType unitType53 = rectangleInsets48.getUnitType();
        double double55 = rectangleInsets48.calculateLeftOutset(0.0d);
        categoryPlot37.setAxisOffset(rectangleInsets48);
        categoryPlot0.setInsets(rectangleInsets48);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNull(categoryAxis39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 3.0d + "'", double50 == 3.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + (-7.0d) + "'", double52 == (-7.0d));
        org.junit.Assert.assertNotNull(unitType53);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 3.0d + "'", double55 == 3.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        java.awt.Font font31 = xYPlot0.getNoDataMessageFont();
        xYPlot0.setDomainCrosshairValue(1.0d);
        java.awt.Color color34 = org.jfree.chart.ChartColor.DARK_YELLOW;
        xYPlot0.setNoDataMessagePaint((java.awt.Paint) color34);
        java.lang.String str36 = color34.toString();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "java.awt.Color[r=192,g=192,b=0]" + "'", str36.equals("java.awt.Color[r=192,g=192,b=0]"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        java.awt.Color color5 = java.awt.Color.yellow;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int8 = color7.getTransparency();
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color7);
        org.jfree.chart.util.Layer layer11 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection12 = xYPlot0.getRangeMarkers((int) ' ', layer11);
        java.lang.Class<?> wildcardClass13 = xYPlot0.getClass();
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart20 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType21 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color19, jFreeChart20, chartChangeEventType21);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color19, stroke23);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart27 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType28 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color26, jFreeChart27, chartChangeEventType28);
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color26, stroke30);
        valueMarker24.setOutlineStroke(stroke30);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace34 = color33.getColorSpace();
        valueMarker24.setLabelPaint((java.awt.Paint) color33);
        org.jfree.chart.text.TextAnchor textAnchor36 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker24.setLabelTextAnchor(textAnchor36);
        org.jfree.chart.util.Layer layer38 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str39 = layer38.toString();
        boolean boolean41 = categoryPlot16.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker24, layer38, true);
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean44 = xYPlot14.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker24, layer42, true);
        java.awt.Font font45 = xYPlot14.getNoDataMessageFont();
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis47.setNegativeArrowVisible(true);
        java.awt.Shape shape50 = dateAxis47.getUpArrow();
        dateAxis47.setLabelURL("");
        xYPlot14.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis47);
        java.util.Date date54 = dateAxis47.getMaximumDate();
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis56.configure();
        boolean boolean58 = dateAxis56.isAutoRange();
        java.awt.Shape shape59 = dateAxis56.getLeftArrow();
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = null;
        double double63 = dateAxis56.java2DToValue((double) 0.0f, rectangle2D61, rectangleEdge62);
        org.jfree.chart.axis.DateAxis dateAxis65 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone66 = dateAxis65.getTimeZone();
        dateAxis56.setTimeZone(timeZone66);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date54, timeZone66);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(layer11);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(colorSpace34);
        org.junit.Assert.assertNotNull(textAnchor36);
        org.junit.Assert.assertNotNull(layer38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Layer.FOREGROUND" + "'", str39.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNull(regularTimePeriod68);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis4.configure();
        boolean boolean6 = dateAxis4.isAutoRange();
        java.awt.Shape shape7 = dateAxis4.getLeftArrow();
        org.jfree.data.Range range8 = dateAxis4.getDefaultAutoRange();
        int int9 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color10);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        xYPlot0.setRangeGridlinesVisible(false);
        xYPlot0.setForegroundAlpha(0.0f);
        java.awt.geom.Point2D point2D35 = xYPlot0.getQuadrantOrigin();
        xYPlot0.setForegroundAlpha((float) (byte) 10);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis40.setNegativeArrowVisible(true);
        float float43 = dateAxis40.getTickMarkOutsideLength();
        dateAxis40.setAutoRangeMinimumSize((double) 1);
        org.jfree.chart.axis.DateTickUnit dateTickUnit46 = dateAxis40.getTickUnit();
        try {
            xYPlot0.setDomainAxis((int) (byte) -1, (org.jfree.chart.axis.ValueAxis) dateAxis40, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 2.0f + "'", float43 == 2.0f);
        org.junit.Assert.assertNotNull(dateTickUnit46);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        dateAxis1.setNegativeArrowVisible(false);
        dateAxis1.setAutoTickUnitSelection(true, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = dateAxis1.getLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = dateAxis1.getLabelInsets();
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke2 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setLabelToolTip("hi!");
        categoryAxis1.setLabel("");
        boolean boolean7 = layer0.equals((java.lang.Object) categoryAxis1);
        categoryAxis1.setCategoryLabelPositionOffset(1);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10);
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color2, color3, color4, color5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color7, color8, color9, color10 };
        java.awt.Paint[] paintArray12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke stroke15 = null;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        java.awt.Shape shape17 = null;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray14, strokeArray16, shapeArray18);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        org.jfree.data.general.DatasetGroup datasetGroup21 = categoryPlot0.getDatasetGroup();
        int int22 = categoryPlot0.getBackgroundImageAlignment();
        categoryPlot0.clearRangeMarkers((int) (short) 10);
        org.jfree.chart.util.SortOrder sortOrder25 = categoryPlot0.getColumnRenderingOrder();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNull(datasetGroup21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 15 + "'", int22 == 15);
        org.junit.Assert.assertNotNull(sortOrder25);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        java.awt.Color color5 = java.awt.Color.yellow;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        int int8 = color7.getTransparency();
        xYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color7);
        org.jfree.chart.util.Layer layer11 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection12 = xYPlot0.getRangeMarkers((int) ' ', layer11);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder13 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart19 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color18, jFreeChart19, chartChangeEventType20);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color18, stroke22);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color25, jFreeChart26, chartChangeEventType27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color25, stroke29);
        valueMarker23.setOutlineStroke(stroke29);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace33 = color32.getColorSpace();
        valueMarker23.setLabelPaint((java.awt.Paint) color32);
        org.jfree.chart.text.TextAnchor textAnchor35 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker23.setLabelTextAnchor(textAnchor35);
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str38 = layer37.toString();
        boolean boolean40 = categoryPlot15.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker23, layer37, true);
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection42 = categoryPlot15.getRangeMarkers(layer41);
        org.jfree.chart.LegendItemCollection legendItemCollection43 = categoryPlot15.getLegendItems();
        boolean boolean44 = seriesRenderingOrder13.equals((java.lang.Object) categoryPlot15);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(layer11);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNotNull(seriesRenderingOrder13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(colorSpace33);
        org.junit.Assert.assertNotNull(textAnchor35);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Layer.FOREGROUND" + "'", str38.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertNotNull(collection42);
        org.junit.Assert.assertNotNull(legendItemCollection43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone3 = dateAxis2.getTimeZone();
        boolean boolean4 = seriesRenderingOrder0.equals((java.lang.Object) timeZone3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) (-245));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.util.List list3 = null;
        xYPlot0.drawDomainTickBands(graphics2D1, rectangle2D2, list3);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot0.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker8, layer9, true);
        xYPlot0.clearDomainAxes();
        boolean boolean13 = xYPlot0.isOutlineVisible();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder16 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        java.util.List list22 = null;
        xYPlot19.drawDomainTickBands(graphics2D20, rectangle2D21, list22);
        java.awt.Color color24 = java.awt.Color.yellow;
        xYPlot19.setRangeCrosshairPaint((java.awt.Paint) color24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart34 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType35 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent36 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color33, jFreeChart34, chartChangeEventType35);
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color33, stroke37);
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart41 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType42 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent43 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color40, jFreeChart41, chartChangeEventType42);
        java.awt.Stroke stroke44 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color40, stroke44);
        valueMarker38.setOutlineStroke(stroke44);
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace48 = color47.getColorSpace();
        valueMarker38.setLabelPaint((java.awt.Paint) color47);
        org.jfree.chart.text.TextAnchor textAnchor50 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker38.setLabelTextAnchor(textAnchor50);
        org.jfree.chart.util.Layer layer52 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str53 = layer52.toString();
        boolean boolean55 = categoryPlot30.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker38, layer52, true);
        org.jfree.chart.util.Layer layer56 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean58 = xYPlot28.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker38, layer56, true);
        xYPlot28.setRangeGridlinesVisible(false);
        xYPlot28.setForegroundAlpha(0.0f);
        java.awt.geom.Point2D point2D63 = xYPlot28.getQuadrantOrigin();
        xYPlot19.zoomRangeAxes((double) (byte) 1, plotRenderingInfo27, point2D63, false);
        xYPlot0.zoomDomainAxes(1.0d, plotRenderingInfo18, point2D63, true);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder16);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(colorSpace48);
        org.junit.Assert.assertNotNull(textAnchor50);
        org.junit.Assert.assertNotNull(layer52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "Layer.FOREGROUND" + "'", str53.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(layer56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(point2D63);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        org.jfree.chart.LegendItemCollection legendItemCollection31 = null;
        xYPlot0.setFixedLegendItems(legendItemCollection31);
        xYPlot0.setRangeCrosshairLockedOnData(false);
        boolean boolean35 = xYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace36);
        boolean boolean38 = xYPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        java.util.TimeZone timeZone2 = dateAxis1.getTimeZone();
        dateAxis1.setRange((double) (short) 0, (double) (short) 10);
        boolean boolean6 = dateAxis1.isVerticalTickLabels();
        boolean boolean7 = dateAxis1.isNegativeArrowVisible();
        double double8 = dateAxis1.getLabelAngle();
        dateAxis1.setPositiveArrowVisible(true);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection27 = categoryPlot0.getRangeMarkers(layer26);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent28);
        org.jfree.chart.plot.IntervalMarker intervalMarker32 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        double double33 = intervalMarker32.getStartValue();
        org.jfree.chart.util.Layer layer34 = null;
        boolean boolean35 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker32, layer34);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent36);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 11.0d + "'", double33 == 11.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        categoryPlot0.setRangeAxis((int) (byte) 10, valueAxis3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke7 = categoryAxis6.getTickMarkStroke();
        categoryAxis6.setLabelToolTip("hi!");
        categoryAxis6.clearCategoryLabelToolTips();
        double double11 = categoryAxis6.getCategoryMargin();
        try {
            categoryPlot0.setDomainAxis((int) (byte) -1, categoryAxis6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        org.jfree.chart.plot.Plot plot31 = xYPlot0.getParent();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(plot31);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        xYPlot0.setRangeGridlinesVisible(false);
        java.awt.Stroke stroke33 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis35.setNegativeArrowVisible(true);
        float float38 = dateAxis35.getTickMarkOutsideLength();
        dateAxis35.setAutoRangeMinimumSize((double) 1);
        boolean boolean41 = dateAxis35.isAxisLineVisible();
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis43.configure();
        boolean boolean45 = dateAxis43.isAutoRange();
        org.jfree.data.time.DateRange dateRange46 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis43.setRangeWithMargins((org.jfree.data.Range) dateRange46);
        dateAxis35.setRange((org.jfree.data.Range) dateRange46, false, true);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 2.0f + "'", float38 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(dateRange46);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke1 = categoryAxis0.getTickMarkStroke();
        float float2 = categoryAxis0.getTickMarkOutsideLength();
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis0.setLabelFont(font3);
        float float5 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        java.lang.String str6 = categoryAxis0.getLabel();
        java.lang.Object obj7 = categoryAxis0.clone();
        categoryAxis0.setTickMarkOutsideLength((float) 192);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.util.List list4 = null;
        xYPlot1.drawDomainTickBands(graphics2D2, rectangle2D3, list4);
        org.jfree.chart.plot.IntervalMarker intervalMarker9 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot1.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker9, layer10, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart17 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType18 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color16, jFreeChart17, chartChangeEventType18);
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color16, stroke20);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart24 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType25 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent26 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color23, jFreeChart24, chartChangeEventType25);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color23, stroke27);
        valueMarker21.setOutlineStroke(stroke27);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace31 = color30.getColorSpace();
        valueMarker21.setLabelPaint((java.awt.Paint) color30);
        org.jfree.chart.text.TextAnchor textAnchor33 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker21.setLabelTextAnchor(textAnchor33);
        org.jfree.chart.util.Layer layer35 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str36 = layer35.toString();
        boolean boolean38 = categoryPlot13.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker21, layer35, true);
        org.jfree.chart.axis.AxisLocation axisLocation39 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot13.setRangeAxisLocation(axisLocation39);
        xYPlot1.setDomainAxisLocation(axisLocation39);
        int int42 = objectList0.indexOf((java.lang.Object) xYPlot1);
        org.junit.Assert.assertNotNull(layer10);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(colorSpace31);
        org.junit.Assert.assertNotNull(textAnchor33);
        org.junit.Assert.assertNotNull(layer35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Layer.FOREGROUND" + "'", str36.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        java.awt.Color color27 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke29 = categoryAxis28.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color27, stroke29);
        categoryPlot0.setRangeGridlineStroke(stroke29);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke32);
        categoryPlot0.clearRangeMarkers(100);
        int int36 = categoryPlot0.getDatasetCount();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent37 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent37);
        java.awt.Color color40 = java.awt.Color.magenta;
        java.awt.Color color41 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        float[] floatArray42 = null;
        float[] floatArray43 = color41.getRGBComponents(floatArray42);
        float[] floatArray44 = color40.getRGBColorComponents(floatArray42);
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        java.util.List list48 = null;
        xYPlot45.drawDomainTickBands(graphics2D46, rectangle2D47, list48);
        org.jfree.chart.plot.IntervalMarker intervalMarker53 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer54 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot45.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker53, layer54, true);
        java.util.List list57 = xYPlot45.getAnnotations();
        java.awt.Stroke stroke58 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot45.setDomainCrosshairStroke(stroke58);
        org.jfree.chart.plot.CategoryMarker categoryMarker60 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0, (java.awt.Paint) color40, stroke58);
        categoryPlot0.setRangeGridlineStroke(stroke58);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(layer54);
        org.junit.Assert.assertNotNull(list57);
        org.junit.Assert.assertNotNull(stroke58);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis();
        int int3 = categoryPlot0.getRangeAxisCount();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot0.removeChangeListener(plotChangeListener5);
        org.junit.Assert.assertNull(categoryAxis2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
//        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        org.jfree.chart.JFreeChart jFreeChart6 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
//        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
//        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        org.jfree.chart.JFreeChart jFreeChart13 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
//        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
//        valueMarker10.setOutlineStroke(stroke16);
//        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
//        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
//        valueMarker10.setLabelPaint((java.awt.Paint) color19);
//        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
//        valueMarker10.setLabelTextAnchor(textAnchor22);
//        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
//        java.lang.String str25 = layer24.toString();
//        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
//        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
//        java.util.Collection collection29 = categoryPlot2.getRangeMarkers(layer28);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
//        categoryPlot2.rendererChanged(rendererChangeEvent30);
//        org.jfree.chart.axis.AxisLocation axisLocation32 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
//        categoryPlot2.setRangeAxisLocation(axisLocation32);
//        org.jfree.chart.axis.AxisLocation axisLocation34 = axisLocation32.getOpposite();
//        int int35 = day0.compareTo((java.lang.Object) axisLocation34);
//        java.lang.String str36 = day0.toString();
//        java.util.Date date37 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day0.previous();
//        java.lang.String str39 = day0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertNotNull(color5);
//        org.junit.Assert.assertNotNull(stroke9);
//        org.junit.Assert.assertNotNull(color12);
//        org.junit.Assert.assertNotNull(stroke16);
//        org.junit.Assert.assertNotNull(color19);
//        org.junit.Assert.assertNotNull(colorSpace20);
//        org.junit.Assert.assertNotNull(textAnchor22);
//        org.junit.Assert.assertNotNull(layer24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(layer28);
//        org.junit.Assert.assertNotNull(collection29);
//        org.junit.Assert.assertNotNull(axisLocation32);
//        org.junit.Assert.assertNotNull(axisLocation34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "13-June-2019" + "'", str39.equals("13-June-2019"));
//    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        java.awt.Color color27 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke29 = categoryAxis28.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color27, stroke29);
        categoryPlot0.setRangeGridlineStroke(stroke29);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke32);
        categoryPlot0.clearRangeMarkers(100);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        categoryPlot0.setDataset(0, categoryDataset39);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color2 = java.awt.Color.red;
        float[] floatArray7 = new float[] { 100L, 10.0f, (-1), 0L };
        float[] floatArray8 = color2.getComponents(floatArray7);
        float[] floatArray9 = color1.getComponents(floatArray7);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color13, jFreeChart14, chartChangeEventType15);
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color13, stroke17);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart21 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType22 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color20, jFreeChart21, chartChangeEventType22);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color20, stroke24);
        valueMarker18.setOutlineStroke(stroke24);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace28 = color27.getColorSpace();
        valueMarker18.setLabelPaint((java.awt.Paint) color27);
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker18.setLabelTextAnchor(textAnchor30);
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str33 = layer32.toString();
        boolean boolean35 = categoryPlot10.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker18, layer32, true);
        java.awt.Color color37 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke39 = categoryAxis38.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color37, stroke39);
        categoryPlot10.setRangeGridlineStroke(stroke39);
        org.jfree.chart.plot.CategoryMarker categoryMarker42 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) ' ', (java.awt.Paint) color1, stroke39);
        java.awt.Color color43 = java.awt.Color.magenta;
        categoryMarker42.setLabelPaint((java.awt.Paint) color43);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(colorSpace28);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Layer.FOREGROUND" + "'", str33.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(color43);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Color color2 = color1.darker();
        java.awt.Color color4 = java.awt.Color.magenta;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        float[] floatArray6 = null;
        float[] floatArray7 = color5.getRGBComponents(floatArray6);
        float[] floatArray8 = color4.getRGBColorComponents(floatArray6);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.util.List list12 = null;
        xYPlot9.drawDomainTickBands(graphics2D10, rectangle2D11, list12);
        org.jfree.chart.plot.IntervalMarker intervalMarker17 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        org.jfree.chart.util.Layer layer18 = org.jfree.chart.util.Layer.BACKGROUND;
        xYPlot9.addDomainMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker17, layer18, true);
        java.util.List list21 = xYPlot9.getAnnotations();
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot9.setDomainCrosshairStroke(stroke22);
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 0, (java.awt.Paint) color4, stroke22);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color1, stroke22);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(layer18);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        java.awt.Font font31 = xYPlot0.getNoDataMessageFont();
        xYPlot0.setDomainCrosshairValue(1.0d);
        java.awt.Color color34 = org.jfree.chart.ChartColor.DARK_YELLOW;
        xYPlot0.setNoDataMessagePaint((java.awt.Paint) color34);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.event.PlotChangeListener plotChangeListener37 = null;
        xYPlot0.removeChangeListener(plotChangeListener37);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.awt.Color color1 = java.awt.Color.red;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Stroke stroke3 = categoryAxis2.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker(11.0d, (java.awt.Paint) color1, stroke3);
        double double5 = valueMarker4.getValue();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 11.0d + "'", double5 == 11.0d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color2, color3, color4, color5 };
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color7, color8, color9, color10 };
        java.awt.Paint[] paintArray12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Stroke[] strokeArray14 = new java.awt.Stroke[] { stroke13 };
        java.awt.Stroke stroke15 = null;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke15 };
        java.awt.Shape shape17 = null;
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] { shape17 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray11, paintArray12, strokeArray14, strokeArray16, shapeArray18);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier19);
        categoryPlot0.setWeight((int) (byte) 10);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot0.getDomainAxis();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = dateAxis26.getLabelInsets();
        categoryPlot0.setRangeAxis(12, (org.jfree.chart.axis.ValueAxis) dateAxis26);
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace29);
        org.jfree.chart.LegendItemCollection legendItemCollection31 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection31);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(strokeArray14);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertNotNull(rectangleInsets27);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color5, jFreeChart6, chartChangeEventType7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color5, stroke9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color12, jFreeChart13, chartChangeEventType14);
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color12, stroke16);
        valueMarker10.setOutlineStroke(stroke16);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        valueMarker10.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker10.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str25 = layer24.toString();
        boolean boolean27 = categoryPlot2.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker10, layer24, true);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) valueMarker10, layer28, true);
        xYPlot0.setRangeGridlinesVisible(false);
        xYPlot0.setForegroundAlpha(0.0f);
        org.jfree.chart.plot.IntervalMarker intervalMarker37 = new org.jfree.chart.plot.IntervalMarker((double) 11, (double) 0.0f);
        java.awt.Stroke stroke38 = intervalMarker37.getOutlineStroke();
        xYPlot0.setDomainCrosshairStroke(stroke38);
        java.awt.Stroke stroke40 = xYPlot0.getDomainGridlineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis42 = xYPlot0.getRangeAxis(15);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNull(valueAxis42);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("DatasetRenderingOrder.REVERSE");
        dateAxis1.configure();
        boolean boolean3 = dateAxis1.isAutoRange();
        java.awt.Shape shape4 = dateAxis1.getLeftArrow();
        boolean boolean5 = dateAxis1.isPositiveArrowVisible();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color3, jFreeChart4, chartChangeEventType5);
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color3, stroke7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color10, jFreeChart11, chartChangeEventType12);
        java.awt.Stroke stroke14 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color10, stroke14);
        valueMarker8.setOutlineStroke(stroke14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        valueMarker8.setLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        valueMarker8.setLabelTextAnchor(textAnchor20);
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str23 = layer22.toString();
        boolean boolean25 = categoryPlot0.removeDomainMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker8, layer22, true);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection27 = categoryPlot0.getRangeMarkers(layer26);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent28);
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation30);
        categoryPlot0.setBackgroundAlpha((float) (short) 100);
        double double34 = categoryPlot0.getAnchorValue();
        categoryPlot0.clearRangeMarkers();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Layer.FOREGROUND" + "'", str23.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }
}

