import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        try {
            org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValues3.getTimePeriod((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 100, (long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        try {
            org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValues3.getTimePeriod((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            year0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue7 = timePeriodValues3.getDataItem((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getLastMillisecond();
        java.util.Date date5 = year3.getStart();
        boolean boolean6 = year0.equals((java.lang.Object) year3);
        java.util.Calendar calendar7 = null;
        try {
            year3.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getLastMillisecond();
        java.util.Date date5 = year3.getStart();
        boolean boolean6 = year0.equals((java.lang.Object) year3);
        java.util.Calendar calendar7 = null;
        try {
            year0.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        java.lang.Object obj6 = timePeriodValues3.clone();
        try {
            org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValues3.getTimePeriod((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getLastMillisecond();
        java.lang.String str3 = year0.toString();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getLastMillisecond();
        java.util.Date date5 = year3.getStart();
        boolean boolean6 = year0.equals((java.lang.Object) year3);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year3.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = regularTimePeriod2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '4', 4, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            day0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (byte) 10);
        try {
            java.lang.Number number15 = timePeriodValues3.getValue((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (short) 1);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        timePeriodValues3.setDescription("");
        try {
            java.lang.Number number11 = timePeriodValues3.getValue((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (byte) 10);
        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (byte) 1 + "'", comparable14.equals((byte) 1));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getLastMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 100, "TimePeriodValue[2019,1.0]", "");
        try {
            java.lang.Number number5 = timePeriodValues3.getValue((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
        java.util.Date date12 = day0.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getStart();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date12, date14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        boolean boolean10 = timePeriodValues3.isEmpty();
        try {
            org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValues3.getTimePeriod((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test037");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        java.util.Date date12 = day0.getEnd();
//        long long13 = day0.getMiddleMillisecond();
//        int int14 = day0.getYear();
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = day0.getFirstMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        long long6 = year4.getFirstMillisecond();
        long long7 = year4.getFirstMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year4.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) (short) 1);
        java.lang.String str18 = timePeriodValue17.toString();
        timePeriodValues3.add(timePeriodValue17);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener20);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str18.equals("TimePeriodValue[2019,1.0]"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        long long4 = regularTimePeriod3.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1530561599999L + "'", long4 == 1530561599999L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy(0, (int) (short) 100);
        boolean boolean7 = timePeriodValues6.isEmpty();
        int int8 = timePeriodValues6.getMaxMiddleIndex();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test043");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getDayOfMonth();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day2.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy(0, (int) (short) 100);
        timePeriodValues6.setNotify(false);
        timePeriodValues6.setRangeDescription("hi!");
        org.junit.Assert.assertNotNull(timePeriodValues6);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        java.lang.Comparable comparable9 = timePeriodValues3.getKey();
        try {
            org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValues3.getTimePeriod(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 1 + "'", comparable9.equals((byte) 1));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener5);
        try {
            org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValues3.getTimePeriod((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        try {
            timePeriodValues3.delete(2, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 0, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (short) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues7.createCopy(0, (int) (short) 100);
        boolean boolean11 = timePeriodValues10.isEmpty();
        boolean boolean12 = timePeriodValue3.equals((java.lang.Object) timePeriodValues10);
        timePeriodValues10.setKey((java.lang.Comparable) 1562097599999L);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue16 = timePeriodValues10.getDataItem((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getLastMillisecond();
        java.util.Date date5 = year3.getStart();
        boolean boolean6 = year0.equals((java.lang.Object) year3);
        int int7 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        long long12 = day0.getLastMillisecond();
//        long long13 = day0.getSerialIndex();
//        int int14 = day0.getYear();
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560495599999L + "'", long12 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43629L + "'", long13 == 43629L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year5.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (short) 1);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValues3.getTimePeriod((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener11);
        try {
            timePeriodValues3.delete((int) (byte) -1, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        java.lang.Object obj6 = timePeriodValues3.clone();
        boolean boolean7 = timePeriodValues3.getNotify();
        org.jfree.data.time.TimePeriod timePeriod8 = null;
        try {
            timePeriodValues3.add(timePeriod8, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        java.util.Date date3 = day0.getEnd();
        java.lang.Class<?> wildcardClass4 = date3.getClass();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getLastMillisecond();
        java.util.Date date7 = year5.getStart();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertNotNull(date7);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test061");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1, timeZone3);
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getStart();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
//        boolean boolean9 = day4.equals((java.lang.Object) day8);
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = day4.getMiddleMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (short) 1);
        java.lang.Object obj13 = timePeriodValue12.clone();
        timePeriodValues3.add(timePeriodValue12);
        java.lang.Number number15 = timePeriodValue12.getValue();
        java.lang.String str16 = timePeriodValue12.toString();
        java.lang.String str17 = timePeriodValue12.toString();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str16.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str17.equals("TimePeriodValue[2019,1.0]"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (short) 1);
        java.lang.Object obj13 = timePeriodValue12.clone();
        timePeriodValues3.add(timePeriodValue12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year15, (double) 100.0f);
        org.jfree.data.time.TimePeriod timePeriod18 = null;
        try {
            timePeriodValues3.add(timePeriod18, (java.lang.Number) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        try {
            timePeriodValues3.update(2019, (java.lang.Number) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        int int6 = timePeriodValues3.getMinStartIndex();
        boolean boolean7 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
        int int15 = timePeriodValues3.getMinMiddleIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod17 = timePeriodValues3.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (byte) 1 + "'", comparable14.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        long long6 = year4.getFirstMillisecond();
        boolean boolean8 = year4.equals((java.lang.Object) 100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (byte) 10);
        java.util.Date date14 = year10.getEnd();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = year10.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) -1, 5, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        java.util.Date date3 = day0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener10);
        java.lang.Class<?> wildcardClass12 = timePeriodValues7.getClass();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        java.util.Date date15 = year13.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getLastMillisecond();
        java.util.Date date18 = year16.getStart();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date18, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date15, timeZone19);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date3, date15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod21);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getLastMillisecond();
        java.util.Date date5 = year3.getStart();
        boolean boolean6 = year0.equals((java.lang.Object) year3);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year3.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(8, (-1), 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (short) 1);
        java.lang.String str4 = timePeriodValue3.toString();
        timePeriodValue3.setValue((java.lang.Number) 9);
        timePeriodValue3.setValue((java.lang.Number) 1.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str4.equals("TimePeriodValue[2019,1.0]"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (short) 1);
        java.lang.Object obj13 = timePeriodValue12.clone();
        timePeriodValues3.add(timePeriodValue12);
        java.lang.Number number15 = timePeriodValue12.getValue();
        timePeriodValue12.setValue((java.lang.Number) (short) 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 0, (-1), 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener13);
        try {
            java.lang.Number number16 = timePeriodValues3.getValue(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.util.Calendar calendar2 = null;
        try {
            day0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        java.util.Date date5 = day3.getEnd();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        try {
            timePeriodValues3.delete(2, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test083");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
//        int int8 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener9);
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getStart();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date15, timeZone17);
//        int int19 = day18.getDayOfMonth();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getStart();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
//        boolean boolean23 = day18.equals((java.lang.Object) day22);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day22, (double) 10);
//        try {
//            org.jfree.data.time.TimePeriod timePeriod27 = timePeriodValues3.getTimePeriod((int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (short) 1);
        java.lang.Object obj13 = timePeriodValue12.clone();
        timePeriodValues3.add(timePeriodValue12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year15, (double) 100.0f);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener18);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        java.lang.String str10 = seriesChangeEvent9.toString();
        java.lang.Object obj11 = seriesChangeEvent9.getSource();
        java.lang.String str12 = seriesChangeEvent9.toString();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener7);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener9);
        java.lang.Class<?> wildcardClass11 = timePeriodValues6.getClass();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        java.util.Date date17 = year15.getStart();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date14, timeZone18);
        int int21 = year0.compareTo((java.lang.Object) wildcardClass11);
        java.util.Calendar calendar22 = null;
        try {
            long long23 = year0.getMiddleMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getLastMillisecond();
        java.util.Date date5 = year3.getStart();
        boolean boolean6 = year0.equals((java.lang.Object) year3);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year0.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setRangeDescription("");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue9 = timePeriodValues3.getDataItem(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        boolean boolean6 = simpleTimePeriod2.equals((java.lang.Object) 1560409200000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        long long4 = year0.getMiddleMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            year0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test091");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getDayOfMonth();
//        long long4 = day2.getFirstMillisecond();
//        java.util.Calendar calendar5 = null;
//        try {
//            day2.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        long long5 = day3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        long long5 = day3.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day3.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues9.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues9.removePropertyChangeListener(propertyChangeListener12);
        int int14 = timePeriodValues9.getMinEndIndex();
        try {
            int int15 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodValues9);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy(0, (int) (short) 100);
        timePeriodValues6.setNotify(false);
        int int9 = timePeriodValues6.getMinStartIndex();
        int int10 = timePeriodValues6.getItemCount();
        try {
            timePeriodValues6.update(12, (java.lang.Number) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy(0, (int) (short) 100);
        boolean boolean8 = timePeriodValues3.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test097");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
//        int int8 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener9);
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getStart();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date15, timeZone17);
//        int int19 = day18.getDayOfMonth();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getStart();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
//        boolean boolean23 = day18.equals((java.lang.Object) day22);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day22, (double) 10);
//        long long26 = day22.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560452399999L + "'", long26 == 1560452399999L);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener5);
        int int7 = timePeriodValues3.getItemCount();
        try {
            org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues3.getTimePeriod((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.getNotify();
        try {
            timePeriodValues3.delete((int) (short) 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test100");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getDayOfMonth();
//        int int4 = day2.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.previous();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day2.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        long long3 = year0.getSerialIndex();
        long long4 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.String str3 = seriesException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: 2019" + "'", str3.equals("org.jfree.data.general.SeriesException: 2019"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.lang.Number number11 = null;
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year9, number11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year9.next();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        try {
            timePeriodValues3.update(0, (java.lang.Number) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        java.lang.String str5 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year4);
        long long8 = year4.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(2019L, (long) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        timePeriodValues3.setKey((java.lang.Comparable) 2);
        int int11 = timePeriodValues3.getMaxEndIndex();
        timePeriodValues3.setDomainDescription("");
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        java.lang.Comparable comparable6 = null;
        try {
            timePeriodValues3.setKey(comparable6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        try {
            java.lang.Number number10 = timePeriodValues3.getValue((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 100, (long) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
        int int13 = day0.compareTo((java.lang.Object) 0L);
        java.util.Calendar calendar14 = null;
        try {
            long long15 = day0.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        long long12 = simpleTimePeriod11.getStartMillis();
        java.util.Date date13 = simpleTimePeriod11.getEnd();
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone14);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(regularTimePeriod15);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(6, (int) '#', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy(0, (int) (short) 100);
        timePeriodValues6.setNotify(false);
        int int9 = timePeriodValues6.getMinStartIndex();
        java.lang.Object obj10 = timePeriodValues6.clone();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (short) 1);
        java.lang.Object obj13 = timePeriodValue12.clone();
        timePeriodValues3.add(timePeriodValue12);
        try {
            org.jfree.data.time.TimePeriod timePeriod16 = timePeriodValues3.getTimePeriod(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (byte) 10);
        java.util.Date date14 = year10.getEnd();
        java.util.Calendar calendar15 = null;
        try {
            year10.peg(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) 1560495599999L);
        timePeriodValue6.setValue((java.lang.Number) 2019L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getLastMillisecond();
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
//        int int8 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener9);
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.next();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod16, (java.lang.Number) 0);
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = timePeriodValues3.getDataItem((int) (short) 0);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.util.Date date22 = day21.getStart();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date22, timeZone24);
//        int int26 = day25.getDayOfMonth();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.util.Date date28 = day27.getStart();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
//        boolean boolean30 = day25.equals((java.lang.Object) day29);
//        boolean boolean31 = timePeriodValue20.equals((java.lang.Object) day29);
//        java.lang.Object obj32 = timePeriodValue20.clone();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(timePeriodValue20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 13 + "'", int26 == 13);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(obj32);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TimePeriodValue[2019,1.0]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues3.getMaxEndIndex();
        boolean boolean9 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        java.util.Date date22 = day19.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date11, date22);
        try {
            int int25 = simpleTimePeriod23.compareTo((java.lang.Object) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Character cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) -1, 11, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1);
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test127");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getDayOfMonth();
//        int int4 = day2.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.previous();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day2.getMiddleMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1, timeZone3);
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getStart();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
//        boolean boolean9 = day4.equals((java.lang.Object) day8);
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate10);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(serialDate10);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        int int4 = timePeriodValues3.getMaxEndIndex();
        try {
            java.lang.Number number6 = timePeriodValues3.getValue((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        timePeriodValues3.setDescription("");
        boolean boolean10 = timePeriodValues3.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener11);
        int int13 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (short) 1);
        java.lang.Object obj13 = timePeriodValue12.clone();
        timePeriodValues3.add(timePeriodValue12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year15, (double) 100.0f);
        java.lang.Number number19 = timePeriodValues3.getValue(0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 1.0d + "'", number19.equals(1.0d));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriod timePeriod9 = null;
        try {
            timePeriodValues3.add(timePeriod9, (double) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.getNotify();
        timePeriodValues3.setDescription("13-June-2019");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 100, "TimePeriodValue[2019,1.0]", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        int int5 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        java.lang.String str5 = year4.toString();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year4.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        java.util.Date date6 = year4.getStart();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        java.lang.String str10 = year8.toString();
        int int11 = year0.compareTo((java.lang.Object) year8);
        int int12 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener11);
        timePeriodValues3.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener15);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        java.lang.String str3 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("2019");
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray9 = seriesException8.getSuppressed();
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray12 = seriesException11.getSuppressed();
        seriesException8.addSuppressed((java.lang.Throwable) seriesException11);
        seriesException6.addSuppressed((java.lang.Throwable) seriesException8);
        boolean boolean15 = simpleTimePeriod2.equals((java.lang.Object) seriesException8);
        java.lang.Throwable[] throwableArray16 = seriesException8.getSuppressed();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) 'a', 4, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener5);
        int int7 = timePeriodValues3.getItemCount();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue9 = timePeriodValues3.getDataItem((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560495599999L + "'", long2 == 1560495599999L);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener23);
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener25);
        int int27 = timePeriodValues22.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener28 = null;
        timePeriodValues22.removeChangeListener(seriesChangeListener28);
        boolean boolean30 = day18.equals((java.lang.Object) timePeriodValues22);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test144");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
//        int int8 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener9);
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timePeriodValues18.addPropertyChangeListener(propertyChangeListener19);
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timePeriodValues18.addPropertyChangeListener(propertyChangeListener21);
//        java.lang.Class<?> wildcardClass23 = timePeriodValues18.getClass();
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
//        boolean boolean25 = day14.equals((java.lang.Object) wildcardClass23);
//        java.util.Date date26 = day14.getEnd();
//        long long27 = day14.getMiddleMillisecond();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        long long29 = year28.getLastMillisecond();
//        java.util.Date date30 = year28.getStart();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date30, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.next();
//        boolean boolean34 = day14.equals((java.lang.Object) year32);
//        timePeriodValues13.setKey((java.lang.Comparable) year32);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener36 = null;
//        timePeriodValues13.addChangeListener(seriesChangeListener36);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues13);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560452399999L + "'", long27 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        java.util.Date date12 = day0.getEnd();
//        long long13 = day0.getMiddleMillisecond();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getLastMillisecond();
//        java.util.Date date16 = year14.getStart();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date16, timeZone17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
//        boolean boolean20 = day0.equals((java.lang.Object) year18);
//        java.util.Calendar calendar21 = null;
//        try {
//            long long22 = year18.getLastMillisecond(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        timePeriodValues3.setKey((java.lang.Comparable) 2);
        int int11 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 0.0d);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 0.0d + "'", obj2.equals(0.0d));
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
//        int int8 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener9);
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
//        timePeriodValues3.setRangeDescription("1-January-2019");
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getStart();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date17, timeZone19);
//        int int21 = day20.getDayOfMonth();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getStart();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
//        boolean boolean25 = day20.equals((java.lang.Object) day24);
//        org.jfree.data.time.SerialDate serialDate26 = day24.getSerialDate();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(serialDate26);
//        int int28 = day27.getMonth();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day27, (double) 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues13);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 13 + "'", int21 == 13);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1560452399999L, (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (java.lang.Number) 43466L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (short) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener10);
        java.lang.Class<?> wildcardClass12 = timePeriodValues7.getClass();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        java.lang.Number number15 = null;
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year13, number15);
        boolean boolean17 = timePeriodValue3.equals((java.lang.Object) number15);
        java.lang.Number number18 = timePeriodValue3.getValue();
        timePeriodValue3.setValue((java.lang.Number) (-1.0f));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.0d + "'", number18.equals(1.0d));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        java.util.Date date22 = day19.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date11, date22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener7);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener9);
        java.lang.Class<?> wildcardClass11 = timePeriodValues6.getClass();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        java.util.Date date17 = year15.getStart();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date14, timeZone18);
        int int21 = year0.compareTo((java.lang.Object) wildcardClass11);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timePeriodValues25.addPropertyChangeListener(propertyChangeListener26);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues25.addPropertyChangeListener(propertyChangeListener28);
        java.lang.Class<?> wildcardClass30 = timePeriodValues25.getClass();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getLastMillisecond();
        java.util.Date date33 = year31.getStart();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getLastMillisecond();
        java.util.Date date36 = year34.getStart();
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date36, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date33, timeZone37);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        long long41 = year40.getLastMillisecond();
        java.util.Date date42 = year40.getStart();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date42, timeZone43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date33, timeZone43);
        java.lang.Class<?> wildcardClass46 = date33.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        long long50 = simpleTimePeriod49.getStartMillis();
        java.util.Date date51 = simpleTimePeriod49.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener56 = null;
        timePeriodValues55.addPropertyChangeListener(propertyChangeListener56);
        java.beans.PropertyChangeListener propertyChangeListener58 = null;
        timePeriodValues55.addPropertyChangeListener(propertyChangeListener58);
        java.lang.Class<?> wildcardClass60 = timePeriodValues55.getClass();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        long long62 = year61.getLastMillisecond();
        java.util.Date date63 = year61.getStart();
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
        long long65 = year64.getLastMillisecond();
        java.util.Date date66 = year64.getStart();
        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year(date66, timeZone67);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass60, date63, timeZone67);
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date51, timeZone67);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod71 = new org.jfree.data.time.SimpleTimePeriod(date33, date51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1577865599999L + "'", long35 == 1577865599999L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-1L) + "'", long50 == (-1L));
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(wildcardClass60);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1577865599999L + "'", long62 == 1577865599999L);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1577865599999L + "'", long65 == 1577865599999L);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(timeZone67);
        org.junit.Assert.assertNull(regularTimePeriod69);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        java.util.Date date3 = day0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener10);
        java.lang.Class<?> wildcardClass12 = timePeriodValues7.getClass();
        int int13 = timePeriodValues7.getMinMiddleIndex();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) (short) 1);
        java.lang.Number number18 = timePeriodValue17.getValue();
        boolean boolean19 = timePeriodValues7.equals((java.lang.Object) number18);
        int int20 = day0.compareTo((java.lang.Object) number18);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.0d + "'", number18.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date6, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date2, timeZone8);
        java.lang.Class<?> wildcardClass11 = year10.getClass();
        java.util.Calendar calendar12 = null;
        try {
            year10.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        long long5 = day3.getFirstMillisecond();
        long long6 = day3.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod16, (java.lang.Number) 0);
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = timePeriodValues3.getDataItem((int) (short) 0);
        java.lang.Number number21 = timePeriodValue20.getValue();
        java.lang.String str22 = timePeriodValue20.toString();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(timePeriodValue20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0 + "'", number21.equals(0));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TimePeriodValue[2020,0]" + "'", str22.equals("TimePeriodValue[2020,0]"));
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getLastMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) (short) 1);
        java.lang.String str18 = timePeriodValue17.toString();
        timePeriodValues3.add(timePeriodValue17);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.next();
        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) regularTimePeriod22);
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str18.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TimePeriodValue[2020,0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1, timeZone3);
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getStart();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
//        boolean boolean9 = day4.equals((java.lang.Object) day8);
//        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day4, (java.lang.Number) 0.0d);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        int int6 = timePeriodValues3.getMinStartIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValues3.getTimePeriod((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        int int5 = day3.getDayOfMonth();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day3.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1L));
        boolean boolean2 = timePeriodValues1.getNotify();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getLastMillisecond();
        java.lang.Object obj4 = null;
        int int5 = year0.compareTo(obj4);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getLastMillisecond();
        java.util.Date date5 = year3.getStart();
        boolean boolean6 = year0.equals((java.lang.Object) year3);
        int int7 = year3.getYear();
        long long8 = year3.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        java.lang.Object obj6 = timePeriodValues3.clone();
        boolean boolean7 = timePeriodValues3.getNotify();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (byte) 1 + "'", comparable8.equals((byte) 1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod16, (java.lang.Number) 0);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener19);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod16, (java.lang.Number) 0);
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = timePeriodValues3.getDataItem((int) (short) 0);
        java.lang.Number number21 = timePeriodValue20.getValue();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timePeriodValues25.addPropertyChangeListener(propertyChangeListener26);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues25.addPropertyChangeListener(propertyChangeListener28);
        int int30 = timePeriodValues25.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timePeriodValues25.removeChangeListener(seriesChangeListener31);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = timePeriodValues25.createCopy((int) (short) -1, (-1));
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        long long37 = year36.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year36.next();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) regularTimePeriod38, (java.lang.Number) 0);
        boolean boolean41 = timePeriodValue20.equals((java.lang.Object) regularTimePeriod38);
        org.jfree.data.time.TimePeriodValue timePeriodValue43 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod38, (java.lang.Number) 10L);
        java.lang.Number number44 = timePeriodValue43.getValue();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(timePeriodValue20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0 + "'", number21.equals(0));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1577865599999L + "'", long37 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 10L + "'", number44.equals(10L));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (short) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues7.createCopy(0, (int) (short) 100);
        boolean boolean11 = timePeriodValues10.isEmpty();
        boolean boolean12 = timePeriodValue3.equals((java.lang.Object) timePeriodValues10);
        timePeriodValues10.setKey((java.lang.Comparable) 1562097599999L);
        java.lang.String str15 = timePeriodValues10.getDescription();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 100, "TimePeriodValue[2019,1.0]", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        int int5 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.fireSeriesChanged();
        int int12 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (short) 1);
        java.lang.Object obj13 = timePeriodValue12.clone();
        timePeriodValues3.add(timePeriodValue12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year15, (double) 100.0f);
        java.lang.Object obj18 = null;
        boolean boolean19 = year15.equals(obj18);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "", "");
        int int24 = year15.compareTo((java.lang.Object) timePeriodValues23);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timePeriodValues23.removeChangeListener(seriesChangeListener25);
        int int27 = timePeriodValues23.getMinMiddleIndex();
        boolean boolean28 = timePeriodValues23.isEmpty();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (35) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        java.util.Date date12 = day0.getEnd();
//        long long13 = day0.getMiddleMillisecond();
//        int int14 = day0.getYear();
//        int int15 = day0.getYear();
//        java.util.Calendar calendar16 = null;
//        try {
//            long long17 = day0.getLastMillisecond(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timePeriodValues3.isEmpty();
        int int7 = timePeriodValues3.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener10);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
        java.util.Date date12 = day0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 10L);
        int int15 = day0.getYear();
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        timePeriodValues13.setRangeDescription("2019");
        timePeriodValues13.setRangeDescription("");
        java.lang.String str18 = timePeriodValues13.getDescription();
        java.lang.Comparable comparable19 = timePeriodValues13.getKey();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + (byte) 1 + "'", comparable19.equals((byte) 1));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("2019");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray6 = seriesException5.getSuppressed();
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray9 = seriesException8.getSuppressed();
        seriesException5.addSuppressed((java.lang.Throwable) seriesException8);
        seriesException3.addSuppressed((java.lang.Throwable) seriesException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.String str15 = timePeriodFormatException14.toString();
        seriesException3.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.Class<?> wildcardClass17 = timePeriodFormatException14.getClass();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues7.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues7.removeChangeListener(seriesChangeListener10);
        int int12 = timePeriodValues7.getMaxEndIndex();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (double) (short) 1);
        java.lang.Object obj17 = timePeriodValue16.clone();
        timePeriodValues7.add(timePeriodValue16);
        java.lang.String str19 = timePeriodValue16.toString();
        timePeriodValues3.add(timePeriodValue16);
        try {
            org.jfree.data.time.TimePeriod timePeriod22 = timePeriodValues3.getTimePeriod((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str19.equals("TimePeriodValue[2019,1.0]"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        java.util.Date date2 = day1.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener7);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener9);
        java.lang.Class<?> wildcardClass11 = timePeriodValues6.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        java.util.Date date13 = null;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues18.addPropertyChangeListener(propertyChangeListener19);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues18.addPropertyChangeListener(propertyChangeListener21);
        java.lang.Class<?> wildcardClass23 = timePeriodValues18.getClass();
        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
        boolean boolean25 = day14.equals((java.lang.Object) wildcardClass23);
        java.lang.Class class26 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timePeriodValues30.addPropertyChangeListener(propertyChangeListener31);
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timePeriodValues30.addPropertyChangeListener(propertyChangeListener33);
        java.lang.Class<?> wildcardClass35 = timePeriodValues30.getClass();
        java.lang.Class class36 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass35);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
        java.util.Date date38 = day37.getStart();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        long long40 = year39.getLastMillisecond();
        java.util.Date date41 = year39.getStart();
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date41, timeZone42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
        java.util.Date date45 = day44.getStart();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date45, timeZone47);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date41, timeZone47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date38, timeZone47);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        long long54 = simpleTimePeriod53.getStartMillis();
        java.util.Date date55 = simpleTimePeriod53.getEnd();
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
        java.util.Date date57 = day56.getStart();
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date57);
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date57, timeZone59);
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date55, timeZone59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date38, timeZone59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone59);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(class26);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(class36);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-1L) + "'", long54 == (-1L));
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertNull(regularTimePeriod64);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        timePeriodValues3.setDomainDescription("2019");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getLastMillisecond();
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        java.lang.Object obj5 = null;
        boolean boolean6 = year0.equals(obj5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year0.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("13-June-2019");
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        java.util.Date date22 = day19.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date11, date22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getLastMillisecond();
        java.util.Date date26 = year24.getStart();
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date26, timeZone27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        java.util.Date date30 = day29.getStart();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date30, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date26, timeZone32);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        int int36 = year34.compareTo((java.lang.Object) day35);
        int int37 = simpleTimePeriod23.compareTo((java.lang.Object) year34);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        long long39 = year38.getLastMillisecond();
        long long40 = year38.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener45 = null;
        timePeriodValues44.addPropertyChangeListener(propertyChangeListener45);
        java.beans.PropertyChangeListener propertyChangeListener47 = null;
        timePeriodValues44.addPropertyChangeListener(propertyChangeListener47);
        java.lang.Class<?> wildcardClass49 = timePeriodValues44.getClass();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        long long51 = year50.getLastMillisecond();
        java.util.Date date52 = year50.getStart();
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        long long54 = year53.getLastMillisecond();
        java.util.Date date55 = year53.getStart();
        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date55, timeZone56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date52, timeZone56);
        int int59 = year38.compareTo((java.lang.Object) wildcardClass49);
        org.jfree.data.time.TimePeriodValues timePeriodValues63 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener64 = null;
        timePeriodValues63.addPropertyChangeListener(propertyChangeListener64);
        java.beans.PropertyChangeListener propertyChangeListener66 = null;
        timePeriodValues63.addPropertyChangeListener(propertyChangeListener66);
        java.lang.Class<?> wildcardClass68 = timePeriodValues63.getClass();
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year();
        long long70 = year69.getLastMillisecond();
        java.util.Date date71 = year69.getStart();
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year();
        long long73 = year72.getLastMillisecond();
        java.util.Date date74 = year72.getStart();
        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(date74, timeZone75);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass68, date71, timeZone75);
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        long long79 = year78.getLastMillisecond();
        java.util.Date date80 = year78.getStart();
        java.util.TimeZone timeZone81 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year(date80, timeZone81);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date71, timeZone81);
        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day();
        java.util.Date date85 = day84.getStart();
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date85);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod87 = new org.jfree.data.time.SimpleTimePeriod(date71, date85);
        boolean boolean88 = simpleTimePeriod23.equals((java.lang.Object) simpleTimePeriod87);
        org.jfree.data.time.TimePeriodValue timePeriodValue90 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod87, (java.lang.Number) (byte) 1);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1562097599999L + "'", long40 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1577865599999L + "'", long51 == 1577865599999L);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1577865599999L + "'", long54 == 1577865599999L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(timeZone56);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertNotNull(wildcardClass68);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1577865599999L + "'", long70 == 1577865599999L);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1577865599999L + "'", long73 == 1577865599999L);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(timeZone75);
        org.junit.Assert.assertNull(regularTimePeriod77);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 1577865599999L + "'", long79 == 1577865599999L);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNotNull(timeZone81);
        org.junit.Assert.assertNull(regularTimePeriod83);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 'a', (long) 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) (short) 1);
        java.lang.String str18 = timePeriodValue17.toString();
        timePeriodValues3.add(timePeriodValue17);
        java.lang.String str20 = timePeriodValues3.getDescription();
        int int21 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str18.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        java.util.Date date12 = day0.getEnd();
//        long long13 = day0.getMiddleMillisecond();
//        int int14 = day0.getYear();
//        int int15 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day0.previous();
//        java.util.Date date17 = day0.getEnd();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
//        long long19 = year18.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy(0, (int) (short) 100);
        timePeriodValues6.setNotify(false);
        java.lang.Object obj9 = timePeriodValues6.clone();
        timePeriodValues6.setNotify(true);
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) (short) 1);
        java.lang.Number number14 = timePeriodValue13.getValue();
        boolean boolean15 = timePeriodValues3.equals((java.lang.Object) number14);
        try {
            timePeriodValues3.update(0, (java.lang.Number) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1.0d + "'", number14.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (short) 1);
        java.lang.Object obj13 = timePeriodValue12.clone();
        timePeriodValues3.add(timePeriodValue12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year15, (double) 100.0f);
        java.lang.Object obj18 = null;
        boolean boolean19 = year15.equals(obj18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year15.previous();
        java.util.Calendar calendar21 = null;
        try {
            long long22 = year15.getLastMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test194");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        java.util.Date date12 = day0.getEnd();
//        long long13 = day0.getMiddleMillisecond();
//        long long14 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560495599999L + "'", long14 == 1560495599999L);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues3.getRangeDescription();
        try {
            java.lang.Number number10 = timePeriodValues3.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        try {
            timePeriodValues3.delete(0, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test197");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        java.util.Date date12 = day0.getEnd();
//        long long13 = day0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day0.previous();
//        java.lang.String str15 = day0.toString();
//        java.util.Calendar calendar16 = null;
//        try {
//            long long17 = day0.getLastMillisecond(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "13-June-2019" + "'", str15.equals("13-June-2019"));
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 100, "TimePeriodValue[2019,1.0]", "");
        boolean boolean4 = timePeriodValues3.isEmpty();
        try {
            timePeriodValues3.update(10, (java.lang.Number) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test200");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        java.util.Date date12 = day0.getEnd();
//        long long13 = day0.getMiddleMillisecond();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getLastMillisecond();
//        java.util.Date date16 = year14.getStart();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date16, timeZone17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
//        boolean boolean20 = day0.equals((java.lang.Object) year18);
//        boolean boolean22 = day0.equals((java.lang.Object) 2019L);
//        int int23 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 13 + "'", int23 == 13);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 5, 1546415999999L);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues6.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues6.removePropertyChangeListener(propertyChangeListener9);
        int int11 = timePeriodValues6.getMinEndIndex();
        try {
            int int12 = simpleTimePeriod2.compareTo((java.lang.Object) int11);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.lang.Number number11 = null;
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year9, number11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener13);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener15);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        int int4 = timePeriodValues3.getMaxEndIndex();
        try {
            org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValues3.getTimePeriod(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray7 = seriesException6.getSuppressed();
        seriesException3.addSuppressed((java.lang.Throwable) seriesException6);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable[] throwableArray10 = seriesException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        java.util.Date date22 = day19.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date11, date22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date22);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.util.Date date0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getLastMillisecond();
        java.util.Date date3 = year1.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.util.Date date7 = day6.getStart();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date3, timeZone9);
        try {
            org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date0, timeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener11);
        timePeriodValues3.setNotify(false);
        int int15 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.getNotify();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesException: 2019");
        timePeriodValues3.delete(2019, 0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) (short) 1);
        java.lang.String str18 = timePeriodValue17.toString();
        timePeriodValues3.add(timePeriodValue17);
        java.lang.String str20 = timePeriodValue17.toString();
        timePeriodValue17.setValue((java.lang.Number) 9);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str18.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str20.equals("TimePeriodValue[2019,1.0]"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        java.util.Date date6 = year4.getStart();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        java.lang.String str10 = year8.toString();
        int int11 = year0.compareTo((java.lang.Object) year8);
        boolean boolean13 = year8.equals((java.lang.Object) 9);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        long long6 = year4.getFirstMillisecond();
        long long7 = year4.getFirstMillisecond();
        java.lang.String str8 = year4.toString();
        long long9 = year4.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getDayOfMonth();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day2.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timePeriodValues3.isEmpty();
        int int7 = timePeriodValues3.getMinEndIndex();
        int int8 = timePeriodValues3.getMinEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date6, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date2, timeZone8);
        java.lang.Class<?> wildcardClass11 = year10.getClass();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year10.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues7.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues7.removeChangeListener(seriesChangeListener10);
        int int12 = timePeriodValues7.getMaxEndIndex();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (double) (short) 1);
        java.lang.Object obj17 = timePeriodValue16.clone();
        timePeriodValues7.add(timePeriodValue16);
        java.lang.String str19 = timePeriodValue16.toString();
        timePeriodValues3.add(timePeriodValue16);
        int int21 = timePeriodValues3.getItemCount();
        int int22 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str19.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
//        int int8 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener9);
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.next();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod16, (java.lang.Number) 0);
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = timePeriodValues3.getDataItem((int) (short) 0);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.util.Date date22 = day21.getStart();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date22, timeZone24);
//        int int26 = day25.getDayOfMonth();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.util.Date date28 = day27.getStart();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
//        boolean boolean30 = day25.equals((java.lang.Object) day29);
//        boolean boolean31 = timePeriodValue20.equals((java.lang.Object) day29);
//        timePeriodValue20.setValue((java.lang.Number) 10.0d);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(timePeriodValue20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 13 + "'", int26 == 13);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test217");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1, timeZone3);
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getStart();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
//        boolean boolean9 = day4.equals((java.lang.Object) day8);
//        java.util.Date date10 = day4.getEnd();
//        long long11 = day4.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560495599999L + "'", long11 == 1560495599999L);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 100, "TimePeriodValue[2019,1.0]", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues7.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues7.removeChangeListener(seriesChangeListener13);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues7.createCopy((int) (short) -1, (-1));
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.next();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) regularTimePeriod20, (java.lang.Number) 0);
        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) timePeriodValues7);
        int int24 = timePeriodValues7.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1, timeZone3);
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getStart();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
//        boolean boolean9 = day4.equals((java.lang.Object) day8);
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
//        int int12 = day11.getMonth();
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = day11.getLastMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test220");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1, timeZone3);
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getStart();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
//        boolean boolean9 = day4.equals((java.lang.Object) day8);
//        long long10 = day4.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43629L + "'", long10 == 43629L);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        int int4 = day3.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy(0, (int) (short) 100);
        org.jfree.data.time.TimePeriod timePeriod7 = null;
        try {
            timePeriodValues6.add(timePeriod7, (java.lang.Number) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues6);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) 1560495599999L);
        java.lang.Number number7 = timePeriodValue6.getValue();
        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue6.getPeriod();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.560495599999E12d + "'", number7.equals(1.560495599999E12d));
        org.junit.Assert.assertNotNull(timePeriod8);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
        int int15 = timePeriodValues3.getMinEndIndex();
        java.lang.String str16 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (byte) 1 + "'", comparable14.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (31) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546372799999L + "'", long4 == 1546372799999L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.Calendar calendar3 = null;
        try {
            year0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 0.0d);
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=0.0]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=0.0]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=0.0]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=0.0]"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.lang.Comparable comparable6 = timePeriodValues3.getKey();
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (byte) 1 + "'", comparable6.equals((byte) 1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.lang.Number number11 = null;
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year9, number11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener13);
        int int15 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        long long3 = year2.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) (short) 1);
        java.lang.String str18 = timePeriodValue17.toString();
        timePeriodValues3.add(timePeriodValue17);
        java.lang.Object obj20 = timePeriodValue17.clone();
        java.lang.String str21 = timePeriodValue17.toString();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str18.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str21.equals("TimePeriodValue[2019,1.0]"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 100, "TimePeriodValue[2019,1.0]", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues7.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues7.removeChangeListener(seriesChangeListener13);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues7.createCopy((int) (short) -1, (-1));
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.next();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) regularTimePeriod20, (java.lang.Number) 0);
        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) timePeriodValues7);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getLastMillisecond();
        java.util.Date date26 = year24.getStart();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getLastMillisecond();
        java.util.Date date29 = year27.getStart();
        boolean boolean30 = year24.equals((java.lang.Object) year27);
        java.lang.Number number31 = null;
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year24, number31);
        long long33 = year24.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 2019L + "'", long33 == 2019L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        java.lang.String str11 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setNotify(true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        boolean boolean11 = timePeriodValues3.equals((java.lang.Object) 1.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (short) 1);
        java.lang.Object obj13 = timePeriodValue12.clone();
        timePeriodValues3.add(timePeriodValue12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year15, (double) 100.0f);
        java.lang.Object obj18 = null;
        boolean boolean19 = year15.equals(obj18);
        java.util.Calendar calendar20 = null;
        try {
            long long21 = year15.getFirstMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        long long19 = day18.getSerialIndex();
        long long20 = day18.getLastMillisecond();
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day18.next();
        long long24 = day18.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43466L + "'", long19 == 43466L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546415999999L + "'", long20 == 1546415999999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 43466L + "'", long22 == 43466L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546372799999L + "'", long24 == 1546372799999L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        java.util.Date date22 = day19.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date11, date22);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date22, "2019", "org.jfree.data.general.SeriesException: 2019");
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timePeriodValues30.addPropertyChangeListener(propertyChangeListener31);
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timePeriodValues30.addPropertyChangeListener(propertyChangeListener33);
        java.lang.Class<?> wildcardClass35 = timePeriodValues30.getClass();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        long long37 = year36.getLastMillisecond();
        java.lang.Number number38 = null;
        timePeriodValues30.add((org.jfree.data.time.TimePeriod) year36, number38);
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues43.addPropertyChangeListener(propertyChangeListener44);
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timePeriodValues43.addPropertyChangeListener(propertyChangeListener46);
        java.lang.Class<?> wildcardClass48 = timePeriodValues43.getClass();
        int int49 = timePeriodValues43.getMinMiddleIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        long long51 = year50.getLastMillisecond();
        timePeriodValues43.add((org.jfree.data.time.TimePeriod) year50, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        long long55 = year54.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue57 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year54, (double) (short) 1);
        java.lang.String str58 = timePeriodValue57.toString();
        timePeriodValues43.add(timePeriodValue57);
        java.lang.String str60 = timePeriodValue57.toString();
        timePeriodValues30.add(timePeriodValue57);
        timePeriodValues26.add(timePeriodValue57);
        int int63 = timePeriodValues26.getMinStartIndex();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1577865599999L + "'", long37 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1577865599999L + "'", long51 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1577865599999L + "'", long55 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str58.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str60.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        java.util.Date date6 = year4.getStart();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        java.lang.String str10 = year8.toString();
        int int11 = year0.compareTo((java.lang.Object) year8);
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year8.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener5);
//        boolean boolean7 = timePeriodValues3.getNotify();
//        timePeriodValues3.setDescription("org.jfree.data.general.SeriesException: 2019");
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timePeriodValues14.addPropertyChangeListener(propertyChangeListener17);
//        java.lang.Class<?> wildcardClass19 = timePeriodValues14.getClass();
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
//        boolean boolean21 = day10.equals((java.lang.Object) wildcardClass19);
//        java.util.Date date22 = day10.getEnd();
//        long long23 = day10.getMiddleMillisecond();
//        int int24 = day10.getYear();
//        int int25 = day10.getDayOfMonth();
//        boolean boolean26 = timePeriodValues3.equals((java.lang.Object) int25);
//        int int27 = timePeriodValues3.getMinStartIndex();
//        int int28 = timePeriodValues3.getMaxEndIndex();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560452399999L + "'", long23 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 13 + "'", int25 == 13);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 100, "TimePeriodValue[2019,1.0]", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day3.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (short) 1);
        java.lang.Object obj13 = timePeriodValue12.clone();
        timePeriodValues3.add(timePeriodValue12);
        timePeriodValues3.setDomainDescription("TimePeriodValue[2019,1.0]");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue18 = timePeriodValues3.getDataItem(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date6, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date2, timeZone8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        long long12 = year10.getMiddleMillisecond();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = year10.getMiddleMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1L));
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener4);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (short) 1);
        java.lang.Object obj13 = timePeriodValue12.clone();
        timePeriodValues3.add(timePeriodValue12);
        java.lang.String str15 = timePeriodValue12.toString();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getLastMillisecond();
        java.util.Date date18 = year16.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getLastMillisecond();
        java.util.Date date21 = year19.getStart();
        boolean boolean22 = year16.equals((java.lang.Object) year19);
        int int23 = year19.getYear();
        boolean boolean24 = timePeriodValue12.equals((java.lang.Object) int23);
        timePeriodValue12.setValue((java.lang.Number) 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str15.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        java.util.Date date12 = day0.getEnd();
//        long long13 = day0.getMiddleMillisecond();
//        int int14 = day0.getYear();
//        boolean boolean16 = day0.equals((java.lang.Object) (byte) 0);
//        java.lang.String str17 = day0.toString();
//        long long18 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43629L + "'", long18 == 43629L);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        java.util.Date date22 = day19.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date11, date22);
        long long24 = simpleTimePeriod23.getStartMillis();
        java.util.Date date25 = simpleTimePeriod23.getEnd();
        long long26 = simpleTimePeriod23.getStartMillis();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getLastMillisecond();
        java.util.Date date29 = year27.getStart();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date29, timeZone30);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        java.util.Date date33 = day32.getStart();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date33, timeZone35);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date29, timeZone35);
        java.lang.Class<?> wildcardClass38 = year37.getClass();
        int int39 = simpleTimePeriod23.compareTo((java.lang.Object) year37);
        try {
            int int41 = simpleTimePeriod23.compareTo((java.lang.Object) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Long cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        java.util.Date date22 = day19.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date11, date22);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues27.addPropertyChangeListener(propertyChangeListener28);
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timePeriodValues27.addPropertyChangeListener(propertyChangeListener30);
        java.lang.Class<?> wildcardClass32 = timePeriodValues27.getClass();
        int int33 = timePeriodValues27.getMinMiddleIndex();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getLastMillisecond();
        timePeriodValues27.add((org.jfree.data.time.TimePeriod) year34, (java.lang.Number) (byte) 10);
        java.util.Date date38 = year34.getEnd();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        int int40 = simpleTimePeriod23.compareTo((java.lang.Object) day39);
        java.util.Calendar calendar41 = null;
        try {
            long long42 = day39.getLastMillisecond(calendar41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1577865599999L + "'", long35 == 1577865599999L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        boolean boolean6 = timePeriodValues3.isEmpty();
//        timePeriodValues3.setRangeDescription("");
//        timePeriodValues3.setDescription("hi!");
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timePeriodValues15.addPropertyChangeListener(propertyChangeListener16);
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues15.addPropertyChangeListener(propertyChangeListener18);
//        java.lang.Class<?> wildcardClass20 = timePeriodValues15.getClass();
//        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass20);
//        boolean boolean22 = day11.equals((java.lang.Object) wildcardClass20);
//        java.util.Date date23 = day11.getEnd();
//        long long24 = day11.getMiddleMillisecond();
//        int int25 = day11.getYear();
//        int int26 = day11.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day11.previous();
//        java.util.Date date28 = day11.getEnd();
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year29, (double) 11);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(class21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560452399999L + "'", long24 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(date28);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.lang.String str4 = day3.toString();
        java.lang.String str5 = day3.toString();
        long long6 = day3.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1-January-2019" + "'", str4.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1-January-2019" + "'", str5.equals("1-January-2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 43466L + "'", long6 == 43466L);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        timePeriodValues3.setKey((java.lang.Comparable) 2);
        int int11 = timePeriodValues3.getMaxEndIndex();
        timePeriodValues3.setKey((java.lang.Comparable) 7);
        timePeriodValues3.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: 2019");
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues6.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues6.removeChangeListener(seriesChangeListener9);
        int int11 = timePeriodValues6.getMaxEndIndex();
        boolean boolean12 = year0.equals((java.lang.Object) timePeriodValues6);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues6.createCopy(12, (int) (byte) 0);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getLastMillisecond();
        java.util.Date date18 = year16.getStart();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date18, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.next();
        long long22 = year20.getFirstMillisecond();
        long long23 = year20.getFirstMillisecond();
        java.lang.String str24 = year20.toString();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean26 = year20.equals((java.lang.Object) timeZone25);
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year20, (java.lang.Number) 100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 31, (long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (short) 1);
        java.util.Calendar calendar4 = null;
        try {
            year0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timePeriodValues3.isEmpty();
        int int7 = timePeriodValues3.getMaxEndIndex();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        timePeriodValues3.setKey((java.lang.Comparable) 1560495599999L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (byte) 1 + "'", comparable8.equals((byte) 1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        timePeriodValues3.setDescription("");
        int int10 = timePeriodValues3.getItemCount();
        java.lang.String str11 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("2019");
        try {
            org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValues3.getTimePeriod(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date6, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date2, timeZone8);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year10.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone8);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        java.lang.Object obj10 = seriesChangeEvent9.getSource();
        java.lang.String str11 = seriesChangeEvent9.toString();
        java.lang.Class<?> wildcardClass12 = seriesChangeEvent9.getClass();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1L));
        boolean boolean2 = timePeriodValues1.isEmpty();
        boolean boolean4 = timePeriodValues1.equals((java.lang.Object) (-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test265");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        java.util.Date date12 = day0.getEnd();
//        long long13 = day0.getMiddleMillisecond();
//        int int14 = day0.getYear();
//        int int15 = day0.getYear();
//        java.util.Calendar calendar16 = null;
//        try {
//            day0.peg(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesChangeEvent[source=0.0]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[2019,1.0]");
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        int int14 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=0.0]");
        java.lang.Object obj17 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date6, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date2, timeZone8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        int int12 = year10.compareTo((java.lang.Object) day11);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = day11.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timePeriodValues3.isEmpty();
        int int7 = timePeriodValues3.getMaxEndIndex();
        int int8 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        long long19 = day18.getSerialIndex();
        long long20 = day18.getLastMillisecond();
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day18.next();
        long long24 = day18.getFirstMillisecond();
        long long25 = day18.getSerialIndex();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43466L + "'", long19 == 43466L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546415999999L + "'", long20 == 1546415999999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 43466L + "'", long22 == 43466L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 43466L + "'", long25 == 43466L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timePeriodValues3.isEmpty();
        int int7 = timePeriodValues3.getMaxEndIndex();
        timePeriodValues3.fireSeriesChanged();
        try {
            org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValues3.getTimePeriod((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
//        int int8 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener9);
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getStart();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date15, timeZone17);
//        int int19 = day18.getDayOfMonth();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getStart();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
//        boolean boolean23 = day18.equals((java.lang.Object) day22);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day22, (double) 10);
//        timePeriodValues3.setNotify(true);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date6, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date2, timeZone8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod11, (double) 9);
        java.lang.String str14 = timePeriodValue13.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TimePeriodValue[2020,9.0]" + "'", str14.equals("TimePeriodValue[2020,9.0]"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        timePeriodValues3.setKey((java.lang.Comparable) 2);
        int int11 = timePeriodValues3.getMaxEndIndex();
        int int12 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("13-June-2019");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: 13-June-2019" + "'", str2.equals("org.jfree.data.general.SeriesException: 13-June-2019"));
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getMonth();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        java.lang.Object obj5 = null;
//        int int6 = day0.compareTo(obj5);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timePeriodValues3.isEmpty();
        timePeriodValues3.setRangeDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues12.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues12.removeChangeListener(seriesChangeListener15);
        int int17 = timePeriodValues12.getMaxEndIndex();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year18, (double) (short) 1);
        java.lang.Object obj22 = timePeriodValue21.clone();
        timePeriodValues12.add(timePeriodValue21);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) year24, (double) 100.0f);
        java.lang.Object obj27 = null;
        boolean boolean28 = year24.equals(obj27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year24.previous();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod29, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        java.util.Date date6 = year4.getStart();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date2, timeZone7);
        long long10 = year9.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1562097599999L + "'", long10 == 1562097599999L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        int int5 = year4.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
        java.util.Date date12 = day0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 10L);
        java.lang.Object obj15 = timePeriodValue14.clone();
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(obj15);
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.Object obj2 = null;
//        int int3 = day0.compareTo(obj2);
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getMonth();
//        java.lang.String str3 = day0.toString();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) (short) 1);
        java.lang.String str18 = timePeriodValue17.toString();
        timePeriodValues3.add(timePeriodValue17);
        java.lang.Object obj20 = timePeriodValue17.clone();
        java.lang.Object obj21 = timePeriodValue17.clone();
        timePeriodValue17.setValue((java.lang.Number) 1560495599999L);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str18.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        long long4 = year0.getMiddleMillisecond();
        long long5 = year0.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[2020,9.0]");
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        java.util.Date date12 = day0.getEnd();
//        long long13 = day0.getMiddleMillisecond();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getLastMillisecond();
//        java.util.Date date16 = year14.getStart();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date16, timeZone17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
//        boolean boolean20 = day0.equals((java.lang.Object) year18);
//        long long21 = year18.getSerialIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long21, "org.jfree.data.general.SeriesException: 2019", "org.jfree.data.general.SeriesException: 2019");
//        int int25 = timePeriodValues24.getMinStartIndex();
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 2019L + "'", long21 == 2019L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        java.lang.String str5 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        long long7 = year4.getSerialIndex();
        long long8 = year4.getLastMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year4.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) (short) 1);
        java.lang.String str18 = timePeriodValue17.toString();
        timePeriodValues3.add(timePeriodValue17);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.next();
        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) regularTimePeriod22);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener24);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str18.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timePeriodValues3.isEmpty();
        int int7 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues11.addPropertyChangeListener(propertyChangeListener12);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues11.addPropertyChangeListener(propertyChangeListener14);
        int int16 = timePeriodValues11.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues11.removeChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = timePeriodValues11.createCopy((int) (short) -1, (-1));
        boolean boolean22 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=0.0]");
        int int25 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 1, (int) (byte) 0, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1, timeZone3);
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getStart();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
//        boolean boolean9 = day4.equals((java.lang.Object) day8);
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
//        int int12 = day11.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        long long19 = day18.getSerialIndex();
        long long20 = day18.getLastMillisecond();
        int int21 = day18.getDayOfMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day18);
        java.lang.String str23 = timePeriodValues22.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues22.addPropertyChangeListener(propertyChangeListener24);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43466L + "'", long19 == 43466L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546415999999L + "'", long20 == 1546415999999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getLastMillisecond();
        java.util.Date date5 = year3.getStart();
        boolean boolean6 = year0.equals((java.lang.Object) year3);
        int int7 = year3.getYear();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year3.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1, timeZone3);
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getStart();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
//        boolean boolean9 = day4.equals((java.lang.Object) day8);
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
//        java.lang.Object obj12 = null;
//        int int13 = day11.compareTo(obj12);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("1-January-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        java.lang.Comparable comparable5 = timePeriodValues3.getKey();
        int int6 = timePeriodValues3.getMinEndIndex();
        int int7 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (byte) 1 + "'", comparable5.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test299");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        long long3 = day2.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43629L + "'", long3 == 43629L);
//    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 4);
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray9 = seriesException8.getSuppressed();
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray12 = seriesException11.getSuppressed();
        seriesException8.addSuppressed((java.lang.Throwable) seriesException11);
        java.lang.Throwable[] throwableArray14 = seriesException11.getSuppressed();
        java.lang.Throwable[] throwableArray15 = seriesException11.getSuppressed();
        try {
            int int16 = simpleTimePeriod2.compareTo((java.lang.Object) seriesException11);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.general.SeriesException cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues7.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues7.removeChangeListener(seriesChangeListener10);
        int int12 = timePeriodValues7.getMaxEndIndex();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (double) (short) 1);
        java.lang.Object obj17 = timePeriodValue16.clone();
        timePeriodValues7.add(timePeriodValue16);
        java.lang.String str19 = timePeriodValue16.toString();
        timePeriodValues3.add(timePeriodValue16);
        try {
            timePeriodValues3.delete((int) (byte) -1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str19.equals("TimePeriodValue[2019,1.0]"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener7);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener9);
        java.lang.Class<?> wildcardClass11 = timePeriodValues6.getClass();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        java.util.Date date17 = year15.getStart();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date14, timeZone18);
        int int21 = year0.compareTo((java.lang.Object) wildcardClass11);
        java.util.Calendar calendar22 = null;
        try {
            long long23 = year0.getLastMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        java.util.Date date12 = day0.getEnd();
//        long long13 = day0.getMiddleMillisecond();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getLastMillisecond();
//        java.util.Date date16 = year14.getStart();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date16, timeZone17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
//        boolean boolean20 = day0.equals((java.lang.Object) year18);
//        int int21 = day0.getYear();
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        long long3 = year2.getLastMillisecond();
//        long long4 = year2.getLastMillisecond();
//        java.lang.String str5 = year2.toString();
//        int int6 = day0.compareTo((java.lang.Object) str5);
//        long long7 = day0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.previous();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        java.lang.Object obj6 = timePeriodValues3.clone();
        boolean boolean7 = timePeriodValues3.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener8);
        java.lang.Comparable comparable10 = timePeriodValues3.getKey();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (byte) 1 + "'", comparable10.equals((byte) 1));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        int int9 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (short) 1);
        java.lang.Object obj13 = timePeriodValue12.clone();
        timePeriodValues3.add(timePeriodValue12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year15, (double) 100.0f);
        java.lang.Object obj18 = null;
        boolean boolean19 = timePeriodValues3.equals(obj18);
        java.lang.Object obj20 = null;
        boolean boolean21 = timePeriodValues3.equals(obj20);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long3);
        try {
            timePeriodValues4.update(5, (java.lang.Number) 2019L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass8);
        java.lang.Object obj19 = seriesChangeEvent18.getSource();
        java.lang.Object obj20 = seriesChangeEvent18.getSource();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        long long19 = day18.getSerialIndex();
        long long20 = day18.getLastMillisecond();
        int int21 = day18.getDayOfMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day18);
        int int23 = timePeriodValues22.getMaxEndIndex();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43466L + "'", long19 == 43466L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546415999999L + "'", long20 == 1546415999999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (short) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener10);
        java.lang.Class<?> wildcardClass12 = timePeriodValues7.getClass();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        java.lang.Number number15 = null;
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year13, number15);
        boolean boolean17 = timePeriodValue3.equals((java.lang.Object) number15);
        java.lang.String str18 = timePeriodValue3.toString();
        java.lang.Object obj19 = timePeriodValue3.clone();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str18.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        int int10 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.delete((int) (short) 100, 13);
        try {
            timePeriodValues3.delete(3, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1560452399999L, (long) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timePeriodValues3.isEmpty();
        int int7 = timePeriodValues3.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        boolean boolean10 = timePeriodValues3.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener11);
        int int13 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test316");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1, timeZone3);
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getStart();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
//        boolean boolean9 = day4.equals((java.lang.Object) day8);
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        int int11 = day8.getMonth();
//        java.util.Calendar calendar12 = null;
//        try {
//            day8.peg(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (short) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues7.createCopy(0, (int) (short) 100);
        boolean boolean11 = timePeriodValues10.isEmpty();
        boolean boolean12 = timePeriodValue3.equals((java.lang.Object) timePeriodValues10);
        java.lang.Comparable comparable13 = timePeriodValues10.getKey();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue15 = timePeriodValues10.getDataItem((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (byte) 1 + "'", comparable13.equals((byte) 1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (byte) 1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener7);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener9);
        java.lang.Class<?> wildcardClass11 = timePeriodValues6.getClass();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        java.util.Date date17 = year15.getStart();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date14, timeZone18);
        int int21 = year0.compareTo((java.lang.Object) wildcardClass11);
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(class22);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (byte) 10);
        java.util.Date date14 = year10.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        int int16 = day15.getMonth();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = day15.getFirstMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        java.lang.Object obj6 = timePeriodValues3.clone();
        java.lang.String str7 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("2019");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray6 = seriesException5.getSuppressed();
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray9 = seriesException8.getSuppressed();
        seriesException5.addSuppressed((java.lang.Throwable) seriesException8);
        seriesException3.addSuppressed((java.lang.Throwable) seriesException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.String str15 = timePeriodFormatException14.toString();
        seriesException3.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        java.lang.Throwable throwable17 = null;
        try {
            timePeriodFormatException14.addSuppressed(throwable17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (byte) 10);
        java.util.Date date14 = year10.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        int int16 = day15.getMonth();
        int int17 = day15.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day15.next();
        int int19 = day15.getMonth();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 31 + "'", int17 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 12 + "'", int19 == 12);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 8, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (byte) 10);
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (byte) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues19.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues19.removePropertyChangeListener(propertyChangeListener22);
        int int24 = timePeriodValues19.getMinEndIndex();
        boolean boolean25 = timePeriodValue15.equals((java.lang.Object) int24);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) serialDate2);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues7.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues7.removeChangeListener(seriesChangeListener10);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener12);
        boolean boolean14 = timePeriodValues3.equals((java.lang.Object) propertyChangeListener12);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener13);
        int int15 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        long long4 = year0.getMiddleMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date6, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date2, timeZone8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        int int12 = year10.compareTo((java.lang.Object) day11);
        org.jfree.data.time.SerialDate serialDate13 = day11.getSerialDate();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate13);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = day14.getFirstMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(31, 5, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        long long5 = day3.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        java.util.Calendar calendar8 = null;
        try {
            day7.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate6);
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener5);
//        boolean boolean7 = timePeriodValues3.getNotify();
//        timePeriodValues3.setDescription("org.jfree.data.general.SeriesException: 2019");
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timePeriodValues14.addPropertyChangeListener(propertyChangeListener17);
//        java.lang.Class<?> wildcardClass19 = timePeriodValues14.getClass();
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
//        boolean boolean21 = day10.equals((java.lang.Object) wildcardClass19);
//        java.util.Date date22 = day10.getEnd();
//        long long23 = day10.getMiddleMillisecond();
//        int int24 = day10.getYear();
//        int int25 = day10.getDayOfMonth();
//        boolean boolean26 = timePeriodValues3.equals((java.lang.Object) int25);
//        int int27 = timePeriodValues3.getMinStartIndex();
//        java.lang.String str28 = timePeriodValues3.getRangeDescription();
//        int int29 = timePeriodValues3.getMinMiddleIndex();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560452399999L + "'", long23 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 13 + "'", int25 == 13);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        long long6 = year4.getLastMillisecond();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        long long9 = year7.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues13.addPropertyChangeListener(propertyChangeListener14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues13.addPropertyChangeListener(propertyChangeListener16);
        java.lang.Class<?> wildcardClass18 = timePeriodValues13.getClass();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getLastMillisecond();
        java.util.Date date21 = year19.getStart();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getLastMillisecond();
        java.util.Date date24 = year22.getStart();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date24, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date21, timeZone25);
        int int28 = year7.compareTo((java.lang.Object) wildcardClass18);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        java.util.Date date30 = day29.getStart();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date30, timeZone32);
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timePeriodValues37.addPropertyChangeListener(propertyChangeListener38);
        java.beans.PropertyChangeListener propertyChangeListener40 = null;
        timePeriodValues37.addPropertyChangeListener(propertyChangeListener40);
        java.lang.Class<?> wildcardClass42 = timePeriodValues37.getClass();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        long long44 = year43.getLastMillisecond();
        java.util.Date date45 = year43.getStart();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        long long47 = year46.getLastMillisecond();
        java.util.Date date48 = year46.getStart();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date48, timeZone49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date45, timeZone49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date30, timeZone49);
        int int53 = year4.compareTo((java.lang.Object) date30);
        int int54 = year4.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1562097599999L + "'", long9 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1577865599999L + "'", long44 == 1577865599999L);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1577865599999L + "'", long47 == 1577865599999L);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 2019 + "'", int54 == 2019);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (byte) 10);
        java.lang.String str14 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj15 = timePeriodValues3.clone();
        java.lang.Class<?> wildcardClass16 = timePeriodValues3.getClass();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 100, "TimePeriodValue[2019,1.0]", "");
        boolean boolean4 = timePeriodValues3.isEmpty();
        java.lang.String str5 = timePeriodValues3.getDescription();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod16, (java.lang.Number) 0);
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = timePeriodValues3.getDataItem((int) (short) 0);
        java.lang.Number number21 = timePeriodValue20.getValue();
        org.jfree.data.time.TimePeriod timePeriod22 = timePeriodValue20.getPeriod();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(timePeriodValue20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0 + "'", number21.equals(0));
        org.junit.Assert.assertNotNull(timePeriod22);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues3.getMinEndIndex();
        java.lang.String str11 = timePeriodValues3.getDescription();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        timePeriodValues13.setRangeDescription("2019");
        timePeriodValues13.setRangeDescription("");
        java.lang.String str18 = timePeriodValues13.getDescription();
        timePeriodValues13.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timePeriodValues24.addPropertyChangeListener(propertyChangeListener25);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timePeriodValues24.addPropertyChangeListener(propertyChangeListener27);
        java.lang.Class<?> wildcardClass29 = timePeriodValues24.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues24);
        java.lang.String str31 = seriesChangeEvent30.toString();
        java.lang.Object obj32 = seriesChangeEvent30.getSource();
        boolean boolean33 = timePeriodValues13.equals((java.lang.Object) seriesChangeEvent30);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener34 = null;
        timePeriodValues13.removeChangeListener(seriesChangeListener34);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test339");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        long long3 = day2.getLastMillisecond();
//        java.lang.String str4 = day2.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        java.lang.String str5 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        java.util.Calendar calendar7 = null;
        try {
            year4.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        java.lang.String str4 = day3.toString();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timePeriodValues9.addPropertyChangeListener(propertyChangeListener12);
//        java.lang.Class<?> wildcardClass14 = timePeriodValues9.getClass();
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
//        boolean boolean16 = day5.equals((java.lang.Object) wildcardClass14);
//        java.util.Date date17 = day5.getEnd();
//        long long18 = day5.getMiddleMillisecond();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        long long20 = year19.getLastMillisecond();
//        java.util.Date date21 = year19.getStart();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21, timeZone22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.next();
//        boolean boolean25 = day5.equals((java.lang.Object) year23);
//        boolean boolean26 = day3.equals((java.lang.Object) day5);
//        java.util.Calendar calendar27 = null;
//        try {
//            long long28 = day5.getFirstMillisecond(calendar27);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1-January-2019" + "'", str4.equals("1-January-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560452399999L + "'", long18 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy(0, (int) (short) 100);
        timePeriodValues6.setNotify(false);
        int int9 = timePeriodValues6.getMinStartIndex();
        int int10 = timePeriodValues6.getItemCount();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year11.previous();
        long long15 = year11.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year11.previous();
        long long17 = regularTimePeriod16.getMiddleMillisecond();
        java.util.Date date18 = regularTimePeriod16.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        java.util.Date date20 = year19.getStart();
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) year19, (double) (byte) 10);
        int int23 = timePeriodValues6.getMinStartIndex();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1562097599999L + "'", long15 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1530561599999L + "'", long17 == 1530561599999L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TimePeriodValue[2019,1.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        java.util.Date date22 = day19.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date11, date22);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date22, "2019", "org.jfree.data.general.SeriesException: 2019");
        int int27 = timePeriodValues26.getItemCount();
        int int28 = timePeriodValues26.getItemCount();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getLastMillisecond();
        java.lang.String str5 = year0.toString();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year0.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getMiddleMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            day0.peg(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560495599999L + "'", long1 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560452399999L + "'", long2 == 1560452399999L);
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        timePeriodValues3.setRangeDescription("1-January-2019");
        int int16 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues12.setNotify(false);
        timePeriodValues12.setRangeDescription("");
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues20.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timePeriodValues20.removeChangeListener(seriesChangeListener23);
        int int25 = timePeriodValues20.getMaxEndIndex();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        long long27 = year26.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue29 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year26, (double) (short) 1);
        java.lang.Object obj30 = timePeriodValue29.clone();
        timePeriodValues20.add(timePeriodValue29);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) year32, (double) 100.0f);
        timePeriodValues12.setKey((java.lang.Comparable) 100.0f);
        boolean boolean36 = timePeriodValues3.equals((java.lang.Object) 100.0f);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy(0, (int) (short) 100);
        timePeriodValues6.setNotify(false);
        int int9 = timePeriodValues6.getMinStartIndex();
        timePeriodValues6.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: 2019");
        timePeriodValues6.setDescription("hi!");
        timePeriodValues6.fireSeriesChanged();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        java.util.Date date12 = day0.getEnd();
//        long long13 = day0.getMiddleMillisecond();
//        int int14 = day0.getYear();
//        int int15 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day0.previous();
//        java.util.Date date17 = day0.getEnd();
//        int int19 = day0.compareTo((java.lang.Object) 100.0f);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        java.util.Date date22 = day19.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date11, date22);
        long long24 = simpleTimePeriod23.getStartMillis();
        java.util.Date date25 = simpleTimePeriod23.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date25);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues6.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues6.removeChangeListener(seriesChangeListener9);
        int int11 = timePeriodValues6.getMaxEndIndex();
        boolean boolean12 = year0.equals((java.lang.Object) timePeriodValues6);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues6.createCopy(12, (int) (byte) 0);
        try {
            java.lang.Number number17 = timePeriodValues15.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timePeriodValues15);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        java.lang.Comparable comparable9 = timePeriodValues3.getKey();
        int int10 = timePeriodValues3.getItemCount();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue12 = timePeriodValues3.getDataItem(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 1 + "'", comparable9.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 100, "TimePeriodValue[2019,1.0]", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        java.lang.Object obj5 = null;
        boolean boolean6 = timePeriodValues3.equals(obj5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getLastMillisecond();
        java.util.Date date3 = year0.getStart();
        java.util.Date date4 = year0.getStart();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        int int2 = day0.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day0.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues3.getRangeDescription();
        boolean boolean9 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        long long15 = simpleTimePeriod14.getStartMillis();
        java.util.Date date16 = simpleTimePeriod14.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        java.util.Date date19 = year17.getStart();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.next();
        long long23 = year21.getFirstMillisecond();
        long long24 = year21.getFirstMillisecond();
        java.lang.String str25 = year21.toString();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean27 = year21.equals((java.lang.Object) timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date16, timeZone26);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2019" + "'", str25.equals("2019"));
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(regularTimePeriod28);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[2019,1.0]");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: TimePeriodValue[2019,1.0]" + "'", str2.equals("org.jfree.data.general.SeriesException: TimePeriodValue[2019,1.0]"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Time");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        int int2 = day1.getMonth();
        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
        java.util.Date date4 = day1.getEnd();
        java.lang.Class<?> wildcardClass5 = date4.getClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        java.util.Date date8 = year6.getStart();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.util.Date date12 = day11.getStart();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date12, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date8, timeZone14);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date4, timeZone14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener24);
        java.lang.Class<?> wildcardClass26 = timePeriodValues21.getClass();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getLastMillisecond();
        java.util.Date date29 = year27.getStart();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        long long31 = year30.getLastMillisecond();
        java.util.Date date32 = year30.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date32, timeZone33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date29, timeZone33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone33);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNull(regularTimePeriod36);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        java.lang.Object obj6 = timePeriodValues3.clone();
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (byte) 1 + "'", comparable7.equals((byte) 1));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 4);
        java.lang.Number number7 = timePeriodValue6.getValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 4.0d + "'", number7.equals(4.0d));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.lang.String str3 = year0.toString();
        boolean boolean5 = year0.equals((java.lang.Object) 6);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.Object obj2 = null;
//        int int3 = day0.compareTo(obj2);
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 10L);
//        int int8 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 100);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue3 = timePeriodValues1.getDataItem(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy(0, (int) (short) 100);
        timePeriodValues6.setNotify(false);
        int int9 = timePeriodValues6.getMinStartIndex();
        int int10 = timePeriodValues6.getItemCount();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year11.previous();
        long long15 = year11.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year11.previous();
        long long17 = regularTimePeriod16.getMiddleMillisecond();
        java.util.Date date18 = regularTimePeriod16.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        java.util.Date date20 = year19.getStart();
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) year19, (double) (byte) 10);
        java.lang.Comparable comparable23 = timePeriodValues6.getKey();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1562097599999L + "'", long15 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1530561599999L + "'", long17 == 1530561599999L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (byte) 1 + "'", comparable23.equals((byte) 1));
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        java.util.Date date12 = day0.getEnd();
//        long long13 = day0.getMiddleMillisecond();
//        int int14 = day0.getYear();
//        int int15 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day0.previous();
//        int int17 = day0.getMonth();
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.lang.Number number11 = null;
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year9, number11);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues16.addPropertyChangeListener(propertyChangeListener17);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.addPropertyChangeListener(propertyChangeListener19);
        java.lang.Class<?> wildcardClass21 = timePeriodValues16.getClass();
        int int22 = timePeriodValues16.getMinMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getLastMillisecond();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year27, (double) (short) 1);
        java.lang.String str31 = timePeriodValue30.toString();
        timePeriodValues16.add(timePeriodValue30);
        java.lang.String str33 = timePeriodValue30.toString();
        timePeriodValues3.add(timePeriodValue30);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener35);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str31.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str33.equals("TimePeriodValue[2019,1.0]"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        long long19 = day18.getSerialIndex();
        long long20 = day18.getLastMillisecond();
        int int21 = day18.getDayOfMonth();
        long long22 = day18.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day18.next();
        long long24 = day18.getFirstMillisecond();
        java.util.Calendar calendar25 = null;
        try {
            long long26 = day18.getMiddleMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43466L + "'", long19 == 43466L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546415999999L + "'", long20 == 1546415999999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 43466L + "'", long22 == 43466L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: 2019");
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        java.util.Date date22 = day19.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date11, date22);
        long long24 = simpleTimePeriod23.getStartMillis();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getLastMillisecond();
        long long27 = year25.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timePeriodValues31.addPropertyChangeListener(propertyChangeListener32);
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues31.addPropertyChangeListener(propertyChangeListener34);
        java.lang.Class<?> wildcardClass36 = timePeriodValues31.getClass();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        long long38 = year37.getLastMillisecond();
        java.util.Date date39 = year37.getStart();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        long long41 = year40.getLastMillisecond();
        java.util.Date date42 = year40.getStart();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date42, timeZone43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date39, timeZone43);
        int int46 = year25.compareTo((java.lang.Object) wildcardClass36);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener51 = null;
        timePeriodValues50.addPropertyChangeListener(propertyChangeListener51);
        java.beans.PropertyChangeListener propertyChangeListener53 = null;
        timePeriodValues50.addPropertyChangeListener(propertyChangeListener53);
        java.lang.Class<?> wildcardClass55 = timePeriodValues50.getClass();
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        long long57 = year56.getLastMillisecond();
        java.util.Date date58 = year56.getStart();
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        long long60 = year59.getLastMillisecond();
        java.util.Date date61 = year59.getStart();
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year(date61, timeZone62);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date58, timeZone62);
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year();
        long long66 = year65.getLastMillisecond();
        java.util.Date date67 = year65.getStart();
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date67, timeZone68);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date58, timeZone68);
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day();
        java.util.Date date72 = day71.getStart();
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date72);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod74 = new org.jfree.data.time.SimpleTimePeriod(date58, date72);
        try {
            int int75 = simpleTimePeriod23.compareTo((java.lang.Object) date58);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.util.Date cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1562097599999L + "'", long27 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1577865599999L + "'", long38 == 1577865599999L);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1577865599999L + "'", long57 == 1577865599999L);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1577865599999L + "'", long60 == 1577865599999L);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNull(regularTimePeriod64);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1577865599999L + "'", long66 == 1577865599999L);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(date72);
    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test376");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
//        int int8 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener9);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener11);
//        timePeriodValues3.setNotify(false);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int16 = day15.getMonth();
//        java.lang.Object obj17 = null;
//        int int18 = day15.compareTo(obj17);
//        java.lang.String str19 = day15.toString();
//        org.jfree.data.time.SerialDate serialDate20 = day15.getSerialDate();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) (byte) 10);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "13-June-2019" + "'", str19.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate20);
//    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        long long6 = year4.getFirstMillisecond();
        long long7 = year4.getFirstMillisecond();
        int int9 = year4.compareTo((java.lang.Object) 43466L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test378");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
//        long long3 = year2.getLastMillisecond();
//        long long4 = year2.getLastMillisecond();
//        java.lang.String str5 = year2.toString();
//        int int6 = day0.compareTo((java.lang.Object) str5);
//        long long7 = day0.getSerialIndex();
//        int int8 = day0.getMonth();
//        java.util.Calendar calendar9 = null;
//        try {
//            day0.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43629L + "'", long7 == 43629L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test379");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
//        int int8 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener9);
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getStart();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date15, timeZone17);
//        int int19 = day18.getDayOfMonth();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getStart();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
//        boolean boolean23 = day18.equals((java.lang.Object) day22);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day22, (double) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day22.next();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: 13-June-2019");
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "1-January-2019", "2019", "TimePeriodValue[2019,1.0]");
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        java.lang.String str6 = year4.toString();
        java.util.Date date7 = year4.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        long long19 = day18.getSerialIndex();
        long long20 = day18.getLastMillisecond();
        int int21 = day18.getDayOfMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day18);
        java.util.Calendar calendar23 = null;
        try {
            long long24 = day18.getLastMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43466L + "'", long19 == 43466L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546415999999L + "'", long20 == 1546415999999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 100, "TimePeriodValue[2019,1.0]", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues7.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues7.removeChangeListener(seriesChangeListener13);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues7.createCopy((int) (short) -1, (-1));
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.next();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) regularTimePeriod20, (java.lang.Number) 0);
        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) timePeriodValues7);
        timePeriodValues7.setNotify(false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        java.lang.String str4 = day3.toString();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timePeriodValues9.addPropertyChangeListener(propertyChangeListener12);
//        java.lang.Class<?> wildcardClass14 = timePeriodValues9.getClass();
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
//        boolean boolean16 = day5.equals((java.lang.Object) wildcardClass14);
//        java.util.Date date17 = day5.getEnd();
//        long long18 = day5.getMiddleMillisecond();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        long long20 = year19.getLastMillisecond();
//        java.util.Date date21 = year19.getStart();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21, timeZone22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.next();
//        boolean boolean25 = day5.equals((java.lang.Object) year23);
//        boolean boolean26 = day3.equals((java.lang.Object) day5);
//        java.util.Calendar calendar27 = null;
//        try {
//            long long28 = day3.getLastMillisecond(calendar27);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1-January-2019" + "'", str4.equals("1-January-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560452399999L + "'", long18 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
        int int15 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener16);
        timePeriodValues3.setRangeDescription("1-January-2019");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (byte) 1 + "'", comparable14.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
//        int int8 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener9);
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timePeriodValues18.addPropertyChangeListener(propertyChangeListener19);
//        java.beans.PropertyChangeListener propertyChangeListener21 = null;
//        timePeriodValues18.addPropertyChangeListener(propertyChangeListener21);
//        java.lang.Class<?> wildcardClass23 = timePeriodValues18.getClass();
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass23);
//        boolean boolean25 = day14.equals((java.lang.Object) wildcardClass23);
//        java.util.Date date26 = day14.getEnd();
//        long long27 = day14.getMiddleMillisecond();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
//        long long29 = year28.getLastMillisecond();
//        java.util.Date date30 = year28.getStart();
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date30, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.next();
//        boolean boolean34 = day14.equals((java.lang.Object) year32);
//        timePeriodValues13.setKey((java.lang.Comparable) year32);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener36 = null;
//        timePeriodValues13.removeChangeListener(seriesChangeListener36);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues13);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560452399999L + "'", long27 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1546329600000L, (long) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getLastMillisecond();
        java.lang.String str3 = year0.toString();
        int int4 = year0.getYear();
        java.util.Calendar calendar5 = null;
        try {
            year0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
        int int15 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener16);
        timePeriodValues3.setDomainDescription("");
        int int20 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timePeriodValues24.addPropertyChangeListener(propertyChangeListener25);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timePeriodValues24.addPropertyChangeListener(propertyChangeListener27);
        java.lang.Class<?> wildcardClass29 = timePeriodValues24.getClass();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        long long31 = year30.getLastMillisecond();
        java.util.Date date32 = year30.getStart();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        long long34 = year33.getLastMillisecond();
        java.util.Date date35 = year33.getStart();
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date35, timeZone36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date32, timeZone36);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date32);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
        int int41 = day40.getMonth();
        org.jfree.data.time.SerialDate serialDate42 = day40.getSerialDate();
        java.util.Date date43 = day40.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod(date32, date43);
        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener49 = null;
        timePeriodValues48.addPropertyChangeListener(propertyChangeListener49);
        java.beans.PropertyChangeListener propertyChangeListener51 = null;
        timePeriodValues48.addPropertyChangeListener(propertyChangeListener51);
        java.lang.Class<?> wildcardClass53 = timePeriodValues48.getClass();
        int int54 = timePeriodValues48.getMinMiddleIndex();
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        long long56 = year55.getLastMillisecond();
        timePeriodValues48.add((org.jfree.data.time.TimePeriod) year55, (java.lang.Number) (byte) 10);
        java.util.Date date59 = year55.getEnd();
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date59);
        int int61 = simpleTimePeriod44.compareTo((java.lang.Object) day60);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day60, 1.0d);
        java.lang.Object obj64 = timePeriodValues3.clone();
        try {
            java.lang.Number number66 = timePeriodValues3.getValue((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (byte) 1 + "'", comparable14.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1577865599999L + "'", long56 == 1577865599999L);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(obj64);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        java.lang.Comparable comparable5 = timePeriodValues3.getKey();
        boolean boolean6 = timePeriodValues3.isEmpty();
        int int7 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (byte) 1 + "'", comparable5.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues3);
        java.lang.String str10 = seriesChangeEvent9.toString();
        java.lang.String str11 = seriesChangeEvent9.toString();
        java.lang.Object obj12 = seriesChangeEvent9.getSource();
        java.lang.Object obj13 = seriesChangeEvent9.getSource();
        java.lang.String str14 = seriesChangeEvent9.toString();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(obj13);
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        java.util.Date date12 = day0.getEnd();
//        long long13 = day0.getMiddleMillisecond();
//        int int14 = day0.getYear();
//        int int15 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day0.previous();
//        java.util.Date date17 = day0.getEnd();
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
//        java.lang.String str19 = year18.toString();
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        java.util.Date date22 = day19.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date11, date22);
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date11);
        boolean boolean25 = timePeriodValues24.getNotify();
        int int26 = timePeriodValues24.getMinEndIndex();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
        java.util.Date date12 = day0.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 10L);
        int int15 = day0.getMonth();
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test397");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        java.util.Date date12 = day0.getEnd();
//        long long13 = day0.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues17.addPropertyChangeListener(propertyChangeListener18);
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timePeriodValues17.addPropertyChangeListener(propertyChangeListener20);
//        java.lang.Class<?> wildcardClass22 = timePeriodValues17.getClass();
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
//        long long24 = year23.getLastMillisecond();
//        java.util.Date date25 = year23.getStart();
//        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
//        long long27 = year26.getLastMillisecond();
//        java.util.Date date28 = year26.getStart();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date28, timeZone29);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date25, timeZone29);
//        boolean boolean32 = day0.equals((java.lang.Object) regularTimePeriod31);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues6.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues6.removeChangeListener(seriesChangeListener9);
        int int11 = timePeriodValues6.getMaxEndIndex();
        boolean boolean12 = year0.equals((java.lang.Object) timePeriodValues6);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        int int14 = day13.getMonth();
        java.lang.Object obj15 = null;
        int int16 = day13.compareTo(obj15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues20.addPropertyChangeListener(propertyChangeListener21);
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timePeriodValues20.addPropertyChangeListener(propertyChangeListener23);
        int int25 = timePeriodValues20.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener26 = null;
        timePeriodValues20.removeChangeListener(seriesChangeListener26);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = timePeriodValues20.createCopy((int) (short) -1, (-1));
        java.lang.Comparable comparable31 = timePeriodValues20.getKey();
        int int32 = timePeriodValues20.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timePeriodValues20.removePropertyChangeListener(propertyChangeListener33);
        timePeriodValues20.setDomainDescription("");
        int int37 = timePeriodValues20.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener42 = null;
        timePeriodValues41.addPropertyChangeListener(propertyChangeListener42);
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues41.addPropertyChangeListener(propertyChangeListener44);
        java.lang.Class<?> wildcardClass46 = timePeriodValues41.getClass();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year();
        long long48 = year47.getLastMillisecond();
        java.util.Date date49 = year47.getStart();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        long long51 = year50.getLastMillisecond();
        java.util.Date date52 = year50.getStart();
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date52, timeZone53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date49, timeZone53);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date49);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
        int int58 = day57.getMonth();
        org.jfree.data.time.SerialDate serialDate59 = day57.getSerialDate();
        java.util.Date date60 = day57.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod61 = new org.jfree.data.time.SimpleTimePeriod(date49, date60);
        org.jfree.data.time.TimePeriodValues timePeriodValues65 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener66 = null;
        timePeriodValues65.addPropertyChangeListener(propertyChangeListener66);
        java.beans.PropertyChangeListener propertyChangeListener68 = null;
        timePeriodValues65.addPropertyChangeListener(propertyChangeListener68);
        java.lang.Class<?> wildcardClass70 = timePeriodValues65.getClass();
        int int71 = timePeriodValues65.getMinMiddleIndex();
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year();
        long long73 = year72.getLastMillisecond();
        timePeriodValues65.add((org.jfree.data.time.TimePeriod) year72, (java.lang.Number) (byte) 10);
        java.util.Date date76 = year72.getEnd();
        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day(date76);
        int int78 = simpleTimePeriod61.compareTo((java.lang.Object) day77);
        timePeriodValues20.add((org.jfree.data.time.TimePeriod) day77, 1.0d);
        java.lang.Object obj81 = timePeriodValues20.clone();
        boolean boolean82 = day13.equals(obj81);
        int int83 = year0.compareTo((java.lang.Object) day13);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues30);
        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + (byte) 1 + "'", comparable31.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1577865599999L + "'", long48 == 1577865599999L);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1577865599999L + "'", long51 == 1577865599999L);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 6 + "'", int58 == 6);
        org.junit.Assert.assertNotNull(serialDate59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1577865599999L + "'", long73 == 1577865599999L);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
        org.junit.Assert.assertNotNull(obj81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod16, (java.lang.Number) 0);
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = timePeriodValues3.getDataItem((int) (short) 0);
        java.lang.Number number21 = timePeriodValue20.getValue();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timePeriodValues25.addPropertyChangeListener(propertyChangeListener26);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues25.addPropertyChangeListener(propertyChangeListener28);
        int int30 = timePeriodValues25.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timePeriodValues25.removeChangeListener(seriesChangeListener31);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = timePeriodValues25.createCopy((int) (short) -1, (-1));
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        long long37 = year36.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year36.next();
        timePeriodValues25.add((org.jfree.data.time.TimePeriod) regularTimePeriod38, (java.lang.Number) 0);
        boolean boolean41 = timePeriodValue20.equals((java.lang.Object) regularTimePeriod38);
        java.lang.String str42 = timePeriodValue20.toString();
        timePeriodValue20.setValue((java.lang.Number) (short) 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(timePeriodValue20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0 + "'", number21.equals(0));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1577865599999L + "'", long37 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "TimePeriodValue[2020,0]" + "'", str42.equals("TimePeriodValue[2020,0]"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) '4', (long) 2019);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date4);
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.Object obj2 = null;
//        int int3 = day0.compareTo(obj2);
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        int int6 = day0.getDayOfMonth();
//        int int7 = day0.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 13 + "'", int6 == 13);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener8);
        int int10 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setDescription("TimePeriodValue[2020,0]");
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy(0, (int) (short) 100);
        timePeriodValues6.setNotify(false);
        int int9 = timePeriodValues6.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues6.createCopy(12, 3);
        timePeriodValues12.setDomainDescription("2019");
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues12);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 100, "TimePeriodValue[2019,1.0]", "");
        boolean boolean4 = timePeriodValues3.isEmpty();
        int int5 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues3.createCopy(4, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues8);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timePeriodValues3.isEmpty();
        int int7 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues11.addPropertyChangeListener(propertyChangeListener12);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues11.addPropertyChangeListener(propertyChangeListener14);
        int int16 = timePeriodValues11.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues11.removeChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = timePeriodValues11.createCopy((int) (short) -1, (-1));
        boolean boolean22 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=0.0]");
        try {
            timePeriodValues3.delete((int) (byte) -1, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.Object obj2 = null;
//        int int3 = day0.compareTo(obj2);
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (double) 10L);
//        java.lang.String str8 = day0.toString();
//        java.util.Calendar calendar9 = null;
//        try {
//            long long10 = day0.getMiddleMillisecond(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "13-June-2019" + "'", str8.equals("13-June-2019"));
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        java.util.Date date22 = day19.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date11, date22);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date22, "2019", "org.jfree.data.general.SeriesException: 2019");
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timePeriodValues30.addPropertyChangeListener(propertyChangeListener31);
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timePeriodValues30.addPropertyChangeListener(propertyChangeListener33);
        java.lang.Class<?> wildcardClass35 = timePeriodValues30.getClass();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        long long37 = year36.getLastMillisecond();
        java.lang.Number number38 = null;
        timePeriodValues30.add((org.jfree.data.time.TimePeriod) year36, number38);
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues43.addPropertyChangeListener(propertyChangeListener44);
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timePeriodValues43.addPropertyChangeListener(propertyChangeListener46);
        java.lang.Class<?> wildcardClass48 = timePeriodValues43.getClass();
        int int49 = timePeriodValues43.getMinMiddleIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        long long51 = year50.getLastMillisecond();
        timePeriodValues43.add((org.jfree.data.time.TimePeriod) year50, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        long long55 = year54.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue57 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year54, (double) (short) 1);
        java.lang.String str58 = timePeriodValue57.toString();
        timePeriodValues43.add(timePeriodValue57);
        java.lang.String str60 = timePeriodValue57.toString();
        timePeriodValues30.add(timePeriodValue57);
        timePeriodValues26.add(timePeriodValue57);
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        long long64 = year63.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue66 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year63, (double) (short) 1);
        java.lang.Object obj67 = timePeriodValue66.clone();
        java.lang.Number number68 = timePeriodValue66.getValue();
        boolean boolean69 = timePeriodValue57.equals((java.lang.Object) number68);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1577865599999L + "'", long37 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1577865599999L + "'", long51 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1577865599999L + "'", long55 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str58.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str60.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1577865599999L + "'", long64 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj67);
        org.junit.Assert.assertTrue("'" + number68 + "' != '" + 1.0d + "'", number68.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMinEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test409");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1, timeZone3);
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getStart();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
//        boolean boolean9 = day4.equals((java.lang.Object) day8);
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        int int11 = day8.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day8.next();
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = regularTimePeriod12.getMiddleMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        long long4 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        long long6 = regularTimePeriod5.getMiddleMillisecond();
        java.util.Date date7 = regularTimePeriod5.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        java.util.Date date9 = year8.getStart();
        java.util.Date date10 = year8.getEnd();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1530561599999L + "'", long6 == 1530561599999L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
        int int15 = timePeriodValues3.getMinEndIndex();
        int int16 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (byte) 1 + "'", comparable14.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.lang.Number number11 = null;
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year9, number11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener13);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues18.addPropertyChangeListener(propertyChangeListener19);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues18.addPropertyChangeListener(propertyChangeListener21);
        java.lang.Class<?> wildcardClass23 = timePeriodValues18.getClass();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getLastMillisecond();
        java.util.Date date26 = year24.getStart();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getLastMillisecond();
        java.util.Date date29 = year27.getStart();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date29, timeZone30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date26, timeZone30);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass23);
        boolean boolean34 = timePeriodValues3.equals((java.lang.Object) seriesChangeEvent33);
        java.lang.Object obj35 = seriesChangeEvent33.getSource();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(obj35);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        timePeriodValues3.setKey((java.lang.Comparable) 2);
        int int11 = timePeriodValues3.getMaxEndIndex();
        timePeriodValues3.setKey((java.lang.Comparable) 7);
        int int14 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year15, (double) (short) 1);
        java.lang.String str19 = timePeriodValue18.toString();
        timePeriodValues3.add(timePeriodValue18);
        java.lang.String str21 = timePeriodValue18.toString();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str19.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str21.equals("TimePeriodValue[2019,1.0]"));
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
//        long long3 = simpleTimePeriod2.getStartMillis();
//        java.util.Date date4 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timePeriodValues8.addPropertyChangeListener(propertyChangeListener9);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timePeriodValues8.addPropertyChangeListener(propertyChangeListener11);
//        java.lang.Class<?> wildcardClass13 = timePeriodValues8.getClass();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getLastMillisecond();
//        java.util.Date date16 = year14.getStart();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        long long18 = year17.getLastMillisecond();
//        java.util.Date date19 = year17.getStart();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19, timeZone20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date16, timeZone20);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date4, timeZone20);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.util.Date date25 = day24.getStart();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date25, timeZone27);
//        int int29 = day28.getDayOfMonth();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.util.Date date31 = day30.getStart();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
//        boolean boolean33 = day28.equals((java.lang.Object) day32);
//        java.util.Date date34 = day28.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod(date4, date34);
//        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener40 = null;
//        timePeriodValues39.addPropertyChangeListener(propertyChangeListener40);
//        java.beans.PropertyChangeListener propertyChangeListener42 = null;
//        timePeriodValues39.addPropertyChangeListener(propertyChangeListener42);
//        java.lang.Class<?> wildcardClass44 = timePeriodValues39.getClass();
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
//        long long46 = year45.getLastMillisecond();
//        java.util.Date date47 = year45.getStart();
//        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
//        long long49 = year48.getLastMillisecond();
//        java.util.Date date50 = year48.getStart();
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date50, timeZone51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date47, timeZone51);
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date47);
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        int int56 = day55.getMonth();
//        org.jfree.data.time.SerialDate serialDate57 = day55.getSerialDate();
//        java.util.Date date58 = day55.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod59 = new org.jfree.data.time.SimpleTimePeriod(date47, date58);
//        org.jfree.data.time.TimePeriodValues timePeriodValues60 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date47);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod63 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
//        long long64 = simpleTimePeriod63.getStartMillis();
//        java.util.Date date65 = simpleTimePeriod63.getEnd();
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        java.util.Date date67 = day66.getStart();
//        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day(date67);
//        java.util.TimeZone timeZone69 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date67, timeZone69);
//        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(date65, timeZone69);
//        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(date47, timeZone69);
//        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date4, timeZone69);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 13 + "'", int29 == 13);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(wildcardClass44);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1577865599999L + "'", long46 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1577865599999L + "'", long49 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNull(regularTimePeriod53);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 6 + "'", int56 == 6);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-1L) + "'", long64 == (-1L));
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(timeZone69);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        timePeriodValues3.setDescription("");
        boolean boolean10 = timePeriodValues3.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        java.util.Date date15 = year13.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues19.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timePeriodValues19.removeChangeListener(seriesChangeListener22);
        int int24 = timePeriodValues19.getMaxEndIndex();
        boolean boolean25 = year13.equals((java.lang.Object) timePeriodValues19);
        int int26 = year13.getYear();
        timePeriodValues3.setKey((java.lang.Comparable) year13);
        try {
            timePeriodValues3.update(6, (java.lang.Number) (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener13);
        java.lang.Object obj15 = timePeriodValues3.clone();
        int int16 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (4) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray7 = seriesException6.getSuppressed();
        seriesException3.addSuppressed((java.lang.Throwable) seriesException6);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str10 = seriesException1.toString();
        java.lang.String str11 = seriesException1.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesException: 2019" + "'", str10.equals("org.jfree.data.general.SeriesException: 2019"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: 2019" + "'", str11.equals("org.jfree.data.general.SeriesException: 2019"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener5);
        boolean boolean7 = timePeriodValues3.getNotify();
        timePeriodValues3.setRangeDescription("TimePeriodValue[2019,1.0]");
        int int10 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.lang.Number number11 = null;
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year9, number11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener13);
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues18.addPropertyChangeListener(propertyChangeListener19);
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timePeriodValues18.addPropertyChangeListener(propertyChangeListener21);
        java.lang.Class<?> wildcardClass23 = timePeriodValues18.getClass();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getLastMillisecond();
        java.util.Date date26 = year24.getStart();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getLastMillisecond();
        java.util.Date date29 = year27.getStart();
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date29, timeZone30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass23, date26, timeZone30);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) wildcardClass23);
        boolean boolean34 = timePeriodValues3.equals((java.lang.Object) seriesChangeEvent33);
        java.lang.Comparable comparable35 = timePeriodValues3.getKey();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + comparable35 + "' != '" + (byte) 1 + "'", comparable35.equals((byte) 1));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        long long6 = year4.getFirstMillisecond();
        long long7 = year4.getFirstMillisecond();
        java.lang.String str8 = year4.toString();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        boolean boolean10 = year4.equals((java.lang.Object) timeZone9);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year4.getMiddleMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues6.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues6.removeChangeListener(seriesChangeListener9);
        int int11 = timePeriodValues6.getMaxEndIndex();
        boolean boolean12 = year0.equals((java.lang.Object) timePeriodValues6);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues6.createCopy(12, (int) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues19.addPropertyChangeListener(propertyChangeListener20);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues19.addPropertyChangeListener(propertyChangeListener22);
        java.lang.Class<?> wildcardClass24 = timePeriodValues19.getClass();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getLastMillisecond();
        java.util.Date date27 = year25.getStart();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        long long29 = year28.getLastMillisecond();
        java.util.Date date30 = year28.getStart();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date30, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date27, timeZone31);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date27);
        long long35 = day34.getSerialIndex();
        long long36 = day34.getLastMillisecond();
        int int37 = day34.getDayOfMonth();
        long long38 = day34.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day34.next();
        long long40 = day34.getFirstMillisecond();
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) day34, (java.lang.Number) 1.0f);
        org.jfree.data.time.SerialDate serialDate43 = day34.getSerialDate();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 43466L + "'", long35 == 43466L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1546415999999L + "'", long36 == 1546415999999L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 43466L + "'", long38 == 43466L);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1546329600000L + "'", long40 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate43);
    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test423");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
//        long long4 = year0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
//        long long6 = regularTimePeriod5.getMiddleMillisecond();
//        java.util.Date date7 = regularTimePeriod5.getStart();
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod5, "TimePeriodValue[2020,0]", "1-January-2019");
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.lang.String str15 = timePeriodValues14.getDescription();
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timePeriodValues14.addPropertyChangeListener(propertyChangeListener16);
//        boolean boolean18 = timePeriodValues14.getNotify();
//        timePeriodValues14.setDescription("org.jfree.data.general.SeriesException: 2019");
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener26 = null;
//        timePeriodValues25.addPropertyChangeListener(propertyChangeListener26);
//        java.beans.PropertyChangeListener propertyChangeListener28 = null;
//        timePeriodValues25.addPropertyChangeListener(propertyChangeListener28);
//        java.lang.Class<?> wildcardClass30 = timePeriodValues25.getClass();
//        java.lang.Class class31 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass30);
//        boolean boolean32 = day21.equals((java.lang.Object) wildcardClass30);
//        java.util.Date date33 = day21.getEnd();
//        long long34 = day21.getMiddleMillisecond();
//        int int35 = day21.getYear();
//        int int36 = day21.getDayOfMonth();
//        boolean boolean37 = timePeriodValues14.equals((java.lang.Object) int36);
//        int int38 = timePeriodValues14.getMinStartIndex();
//        boolean boolean39 = timePeriodValues10.equals((java.lang.Object) int38);
//        int int40 = timePeriodValues10.getMinMiddleIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1530561599999L + "'", long6 == 1530561599999L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNull(str15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(class31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560452399999L + "'", long34 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 13 + "'", int36 == 13);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
//    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues8.addPropertyChangeListener(propertyChangeListener9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues8.addPropertyChangeListener(propertyChangeListener11);
        java.lang.Class<?> wildcardClass13 = timePeriodValues8.getClass();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        java.util.Date date16 = year14.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        java.util.Date date19 = year17.getStart();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date16, timeZone20);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date4, timeZone20);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod22);
    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "13-June-2019" + "'", str2.equals("13-June-2019"));
//    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues16.addPropertyChangeListener(propertyChangeListener17);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.addPropertyChangeListener(propertyChangeListener19);
        java.lang.Class<?> wildcardClass21 = timePeriodValues16.getClass();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getLastMillisecond();
        java.util.Date date24 = year22.getStart();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getLastMillisecond();
        java.util.Date date27 = year25.getStart();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27, timeZone28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date24, timeZone28);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date24);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        int int33 = day32.getMonth();
        org.jfree.data.time.SerialDate serialDate34 = day32.getSerialDate();
        java.util.Date date35 = day32.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod(date24, date35);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        long long38 = year37.getLastMillisecond();
        java.util.Date date39 = year37.getStart();
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date39, timeZone40);
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        java.util.Date date43 = day42.getStart();
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date43, timeZone45);
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date39, timeZone45);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
        int int49 = year47.compareTo((java.lang.Object) day48);
        int int50 = simpleTimePeriod36.compareTo((java.lang.Object) year47);
        java.util.Date date51 = simpleTimePeriod36.getStart();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        long long53 = year52.getLastMillisecond();
        long long54 = year52.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues58 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener59 = null;
        timePeriodValues58.addPropertyChangeListener(propertyChangeListener59);
        java.beans.PropertyChangeListener propertyChangeListener61 = null;
        timePeriodValues58.addPropertyChangeListener(propertyChangeListener61);
        java.lang.Class<?> wildcardClass63 = timePeriodValues58.getClass();
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
        long long65 = year64.getLastMillisecond();
        java.util.Date date66 = year64.getStart();
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year();
        long long68 = year67.getLastMillisecond();
        java.util.Date date69 = year67.getStart();
        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(date69, timeZone70);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass63, date66, timeZone70);
        int int73 = year52.compareTo((java.lang.Object) wildcardClass63);
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day();
        java.util.Date date75 = day74.getStart();
        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(date75);
        java.util.TimeZone timeZone77 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day(date75, timeZone77);
        org.jfree.data.time.TimePeriodValues timePeriodValues82 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener83 = null;
        timePeriodValues82.addPropertyChangeListener(propertyChangeListener83);
        java.beans.PropertyChangeListener propertyChangeListener85 = null;
        timePeriodValues82.addPropertyChangeListener(propertyChangeListener85);
        java.lang.Class<?> wildcardClass87 = timePeriodValues82.getClass();
        org.jfree.data.time.Year year88 = new org.jfree.data.time.Year();
        long long89 = year88.getLastMillisecond();
        java.util.Date date90 = year88.getStart();
        org.jfree.data.time.Year year91 = new org.jfree.data.time.Year();
        long long92 = year91.getLastMillisecond();
        java.util.Date date93 = year91.getStart();
        java.util.TimeZone timeZone94 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year95 = new org.jfree.data.time.Year(date93, timeZone94);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod96 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass87, date90, timeZone94);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod97 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass63, date75, timeZone94);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod98 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date51, timeZone94);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1577865599999L + "'", long38 == 1577865599999L);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1577865599999L + "'", long53 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1562097599999L + "'", long54 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1577865599999L + "'", long65 == 1577865599999L);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1577865599999L + "'", long68 == 1577865599999L);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(timeZone70);
        org.junit.Assert.assertNull(regularTimePeriod72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(timeZone77);
        org.junit.Assert.assertNotNull(wildcardClass87);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 1577865599999L + "'", long89 == 1577865599999L);
        org.junit.Assert.assertNotNull(date90);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 1577865599999L + "'", long92 == 1577865599999L);
        org.junit.Assert.assertNotNull(date93);
        org.junit.Assert.assertNotNull(timeZone94);
        org.junit.Assert.assertNull(regularTimePeriod96);
        org.junit.Assert.assertNull(regularTimePeriod97);
        org.junit.Assert.assertNotNull(regularTimePeriod98);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        java.lang.String str5 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year4);
        java.lang.String str8 = year4.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.lang.Number number11 = null;
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year9, number11);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues16.addPropertyChangeListener(propertyChangeListener17);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues16.addPropertyChangeListener(propertyChangeListener19);
        java.lang.Class<?> wildcardClass21 = timePeriodValues16.getClass();
        int int22 = timePeriodValues16.getMinMiddleIndex();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getLastMillisecond();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year23, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue30 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year27, (double) (short) 1);
        java.lang.String str31 = timePeriodValue30.toString();
        timePeriodValues16.add(timePeriodValue30);
        java.lang.String str33 = timePeriodValue30.toString();
        timePeriodValues3.add(timePeriodValue30);
        java.lang.Number number35 = null;
        timePeriodValue30.setValue(number35);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str31.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str33.equals("TimePeriodValue[2019,1.0]"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timePeriodValues3.isEmpty();
        int int7 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues11.addPropertyChangeListener(propertyChangeListener12);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues11.addPropertyChangeListener(propertyChangeListener14);
        int int16 = timePeriodValues11.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues11.removeChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = timePeriodValues11.createCopy((int) (short) -1, (-1));
        boolean boolean22 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = timePeriodValues3.createCopy((int) (short) 10, 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timePeriodValues25);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy(0, (int) (short) 100);
        timePeriodValues6.setNotify(false);
        int int9 = timePeriodValues6.getMinStartIndex();
        int int10 = timePeriodValues6.getItemCount();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year11.previous();
        long long15 = year11.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year11.previous();
        long long17 = regularTimePeriod16.getMiddleMillisecond();
        java.util.Date date18 = regularTimePeriod16.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        java.util.Date date20 = year19.getStart();
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) year19, (double) (byte) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year19.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year19.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues28.addPropertyChangeListener(propertyChangeListener29);
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timePeriodValues28.addPropertyChangeListener(propertyChangeListener31);
        java.lang.Class<?> wildcardClass33 = timePeriodValues28.getClass();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getLastMillisecond();
        java.lang.Number number36 = null;
        timePeriodValues28.add((org.jfree.data.time.TimePeriod) year34, number36);
        int int38 = timePeriodValues28.getMinEndIndex();
        int int39 = year19.compareTo((java.lang.Object) int38);
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1562097599999L + "'", long15 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1530561599999L + "'", long17 == 1530561599999L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1577865599999L + "'", long35 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        long long19 = day18.getSerialIndex();
        long long20 = day18.getLastMillisecond();
        int int21 = day18.getDayOfMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day18);
        java.lang.String str23 = timePeriodValues22.getDomainDescription();
        int int24 = timePeriodValues22.getMinStartIndex();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43466L + "'", long19 == 43466L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546415999999L + "'", long20 == 1546415999999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timePeriodValues3.isEmpty();
        int int7 = timePeriodValues3.getMinEndIndex();
        int int8 = timePeriodValues3.getMinEndIndex();
        int int9 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        long long5 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        int int6 = timePeriodValues3.getMinStartIndex();
        int int7 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (short) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues7.createCopy(0, (int) (short) 100);
        boolean boolean11 = timePeriodValues10.isEmpty();
        boolean boolean12 = timePeriodValue3.equals((java.lang.Object) timePeriodValues10);
        int int13 = timePeriodValues10.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date6, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date2, timeZone8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        int int12 = year10.compareTo((java.lang.Object) day11);
        java.lang.Class<?> wildcardClass13 = year10.getClass();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        long long6 = year4.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues10.addPropertyChangeListener(propertyChangeListener11);
        boolean boolean13 = timePeriodValues10.isEmpty();
        timePeriodValues10.setRangeDescription("");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year16.next();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) regularTimePeriod19, (double) 0);
        boolean boolean22 = year4.equals((java.lang.Object) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (double) 1560495599999L);
        java.lang.Number number7 = timePeriodValue6.getValue();
        java.lang.Object obj8 = timePeriodValue6.clone();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.560495599999E12d + "'", number7.equals(1.560495599999E12d));
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TimePeriodValue[2020,9.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("13-June-2019");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getMonth();
//        java.lang.String str3 = day0.toString();
//        long long4 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues8.addPropertyChangeListener(propertyChangeListener9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues8.addPropertyChangeListener(propertyChangeListener11);
        java.lang.Class<?> wildcardClass13 = timePeriodValues8.getClass();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        java.util.Date date16 = year14.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        java.util.Date date19 = year17.getStart();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date16, timeZone20);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date16);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        int int25 = day24.getMonth();
        org.jfree.data.time.SerialDate serialDate26 = day24.getSerialDate();
        java.util.Date date27 = day24.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(date16, date27);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date16);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        long long33 = simpleTimePeriod32.getStartMillis();
        java.util.Date date34 = simpleTimePeriod32.getEnd();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        java.util.Date date36 = day35.getStart();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date36, timeZone38);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date34, timeZone38);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date16, timeZone38);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(date4, date16);
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date16);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1L) + "'", long33 == (-1L));
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone38);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) (short) 1);
        java.lang.String str18 = timePeriodValue17.toString();
        timePeriodValues3.add(timePeriodValue17);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        int int21 = day20.getMonth();
        boolean boolean22 = timePeriodValue17.equals((java.lang.Object) day20);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str18.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (short) 1);
        java.lang.Object obj13 = timePeriodValue12.clone();
        timePeriodValues3.add(timePeriodValue12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year15, (double) 100.0f);
        java.lang.Object obj18 = null;
        boolean boolean19 = year15.equals(obj18);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "", "");
        int int24 = year15.compareTo((java.lang.Object) timePeriodValues23);
        java.lang.String str25 = timePeriodValues23.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.String str7 = seriesException1.toString();
        java.lang.Class<?> wildcardClass8 = seriesException1.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = timePeriodValues13.createCopy(0, (int) (short) 100);
        timePeriodValues16.setNotify(false);
        int int19 = timePeriodValues16.getMinStartIndex();
        int int20 = timePeriodValues16.getItemCount();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year21.previous();
        long long25 = year21.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year21.previous();
        long long27 = regularTimePeriod26.getMiddleMillisecond();
        java.util.Date date28 = regularTimePeriod26.getStart();
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date28);
        java.util.Date date30 = year29.getStart();
        timePeriodValues16.add((org.jfree.data.time.TimePeriod) year29, (double) (byte) 10);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        long long34 = year33.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year33.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.previous();
        long long37 = year33.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year33.previous();
        long long39 = regularTimePeriod38.getMiddleMillisecond();
        java.util.Date date40 = regularTimePeriod38.getStart();
        boolean boolean41 = timePeriodValues16.equals((java.lang.Object) date40);
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timePeriodValues45.addPropertyChangeListener(propertyChangeListener46);
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timePeriodValues45.addPropertyChangeListener(propertyChangeListener48);
        java.lang.Class<?> wildcardClass50 = timePeriodValues45.getClass();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
        long long52 = year51.getLastMillisecond();
        java.util.Date date53 = year51.getStart();
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        long long55 = year54.getLastMillisecond();
        java.util.Date date56 = year54.getStart();
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date56, timeZone57);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date53, timeZone57);
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date53);
        org.jfree.data.time.TimePeriodValues timePeriodValues64 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener65 = null;
        timePeriodValues64.addPropertyChangeListener(propertyChangeListener65);
        java.beans.PropertyChangeListener propertyChangeListener67 = null;
        timePeriodValues64.addPropertyChangeListener(propertyChangeListener67);
        java.lang.Class<?> wildcardClass69 = timePeriodValues64.getClass();
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year();
        long long71 = year70.getLastMillisecond();
        java.util.Date date72 = year70.getStart();
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year();
        long long74 = year73.getLastMillisecond();
        java.util.Date date75 = year73.getStart();
        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date75, timeZone76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass69, date72, timeZone76);
        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day(date72);
        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day();
        int int81 = day80.getMonth();
        org.jfree.data.time.SerialDate serialDate82 = day80.getSerialDate();
        java.util.Date date83 = day80.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod84 = new org.jfree.data.time.SimpleTimePeriod(date72, date83);
        org.jfree.data.time.TimePeriodValues timePeriodValues85 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date72);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod88 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        long long89 = simpleTimePeriod88.getStartMillis();
        java.util.Date date90 = simpleTimePeriod88.getEnd();
        org.jfree.data.time.Day day91 = new org.jfree.data.time.Day();
        java.util.Date date92 = day91.getStart();
        org.jfree.data.time.Day day93 = new org.jfree.data.time.Day(date92);
        java.util.TimeZone timeZone94 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day95 = new org.jfree.data.time.Day(date92, timeZone94);
        org.jfree.data.time.Day day96 = new org.jfree.data.time.Day(date90, timeZone94);
        org.jfree.data.time.Year year97 = new org.jfree.data.time.Year(date72, timeZone94);
        org.jfree.data.time.Year year98 = new org.jfree.data.time.Year(date53, timeZone94);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod99 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date40, timeZone94);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesException: 2019" + "'", str7.equals("org.jfree.data.general.SeriesException: 2019"));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(timePeriodValues16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1562097599999L + "'", long25 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1530561599999L + "'", long27 == 1530561599999L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1562097599999L + "'", long37 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1530561599999L + "'", long39 == 1530561599999L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1577865599999L + "'", long52 == 1577865599999L);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1577865599999L + "'", long55 == 1577865599999L);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(wildcardClass69);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1577865599999L + "'", long71 == 1577865599999L);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 1577865599999L + "'", long74 == 1577865599999L);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(timeZone76);
        org.junit.Assert.assertNull(regularTimePeriod78);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 6 + "'", int81 == 6);
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + (-1L) + "'", long89 == (-1L));
        org.junit.Assert.assertNotNull(date90);
        org.junit.Assert.assertNotNull(date92);
        org.junit.Assert.assertNotNull(timeZone94);
        org.junit.Assert.assertNull(regularTimePeriod99);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        int int14 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener15);
        timePeriodValues3.setDescription("TimePeriodValue[2019,1.0]");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getMonth();
        java.lang.Object obj21 = null;
        int int22 = day19.compareTo(obj21);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day19, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (short) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener10);
        java.lang.Class<?> wildcardClass12 = timePeriodValues7.getClass();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        java.lang.Number number15 = null;
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year13, number15);
        boolean boolean17 = timePeriodValue3.equals((java.lang.Object) number15);
        java.lang.String str18 = timePeriodValue3.toString();
        java.lang.Number number19 = null;
        timePeriodValue3.setValue(number19);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str18.equals("TimePeriodValue[2019,1.0]"));
    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        java.util.Date date12 = day0.getEnd();
//        long long13 = day0.getMiddleMillisecond();
//        int int14 = day0.getYear();
//        int int15 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day0.previous();
//        java.util.Date date17 = day0.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 100);
//        int int20 = timePeriodValues19.getMinMiddleIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timePeriodValues19.addChangeListener(seriesChangeListener21);
//        int int23 = timePeriodValues19.getMaxMiddleIndex();
//        boolean boolean24 = day0.equals((java.lang.Object) int23);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        long long19 = day18.getSerialIndex();
        long long20 = day18.getLastMillisecond();
        int int21 = day18.getDayOfMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day18);
        java.lang.String str23 = timePeriodValues22.getDomainDescription();
        boolean boolean24 = timePeriodValues22.getNotify();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43466L + "'", long19 == 43466L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546415999999L + "'", long20 == 1546415999999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 100, "TimePeriodValue[2019,1.0]", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues7.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues7.removeChangeListener(seriesChangeListener13);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues7.createCopy((int) (short) -1, (-1));
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.next();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) regularTimePeriod20, (java.lang.Number) 0);
        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) timePeriodValues7);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getLastMillisecond();
        java.util.Date date26 = year24.getStart();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getLastMillisecond();
        java.util.Date date29 = year27.getStart();
        boolean boolean30 = year24.equals((java.lang.Object) year27);
        java.lang.Number number31 = null;
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year24, number31);
        long long33 = year24.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1577865599999L + "'", long33 == 1577865599999L);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        long long6 = simpleTimePeriod2.getStartMillis();
        java.util.Date date7 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.String str7 = seriesException1.toString();
        java.lang.Class<?> wildcardClass8 = seriesException1.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        int int11 = day10.getMonth();
        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
        java.util.Date date13 = day10.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues17.addPropertyChangeListener(propertyChangeListener18);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues17.addPropertyChangeListener(propertyChangeListener20);
        java.lang.Class<?> wildcardClass22 = timePeriodValues17.getClass();
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        java.util.Date date25 = day24.getStart();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        long long27 = year26.getLastMillisecond();
        java.util.Date date28 = year26.getStart();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date28, timeZone29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        java.util.Date date32 = day31.getStart();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date32);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date32, timeZone34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date28, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date25, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date13, timeZone34);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesException: 2019" + "'", str7.equals("org.jfree.data.general.SeriesException: 2019"));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(class23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNull(regularTimePeriod38);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) '4', (long) 2019);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        java.util.Date date6 = year4.getStart();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date6, timeZone12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date3, timeZone12);
        java.util.Calendar calendar16 = null;
        try {
            year15.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone12);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 100, "TimePeriodValue[2019,1.0]", "");
        boolean boolean4 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener5);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        java.lang.Comparable comparable9 = timePeriodValues3.getKey();
        int int10 = timePeriodValues3.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener17);
        int int19 = timePeriodValues14.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timePeriodValues14.removeChangeListener(seriesChangeListener20);
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = timePeriodValues14.createCopy((int) (short) -1, (-1));
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year25.next();
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) regularTimePeriod27, (java.lang.Number) 0);
        java.lang.Number number30 = null;
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod27, number30);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 1 + "'", comparable9.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy(0, (int) (short) 100);
        timePeriodValues6.setNotify(false);
        java.lang.Object obj9 = timePeriodValues6.clone();
        try {
            java.lang.Number number11 = timePeriodValues6.getValue(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertNotNull(obj9);
    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test458");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        long long12 = day0.getLastMillisecond();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getMonth();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        long long16 = year15.getLastMillisecond();
//        long long17 = year15.getLastMillisecond();
//        java.lang.String str18 = year15.toString();
//        int int19 = day13.compareTo((java.lang.Object) str18);
//        long long20 = day13.getSerialIndex();
//        boolean boolean21 = day0.equals((java.lang.Object) long20);
//        java.util.Calendar calendar22 = null;
//        try {
//            day0.peg(calendar22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560495599999L + "'", long12 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 43629L + "'", long20 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getLastMillisecond();
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        long long6 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        java.util.Date date22 = day19.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date11, date22);
        long long24 = simpleTimePeriod23.getStartMillis();
        java.util.Date date25 = simpleTimePeriod23.getEnd();
        java.util.TimeZone timeZone26 = null;
        try {
            org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25, timeZone26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (double) (short) 1);
        java.lang.String str15 = timePeriodValue14.toString();
        timePeriodValue14.setValue((java.lang.Number) 9);
        java.lang.Object obj18 = timePeriodValue14.clone();
        timePeriodValues3.add(timePeriodValue14);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str15.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues8.addPropertyChangeListener(propertyChangeListener9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues8.addPropertyChangeListener(propertyChangeListener11);
        java.lang.Class<?> wildcardClass13 = timePeriodValues8.getClass();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        java.util.Date date16 = year14.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        java.util.Date date19 = year17.getStart();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date16, timeZone20);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date4, timeZone20);
        org.jfree.data.general.SeriesException seriesException25 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray26 = seriesException25.getSuppressed();
        org.jfree.data.general.SeriesException seriesException28 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray29 = seriesException28.getSuppressed();
        seriesException25.addSuppressed((java.lang.Throwable) seriesException28);
        org.jfree.data.general.SeriesException seriesException32 = new org.jfree.data.general.SeriesException("");
        seriesException25.addSuppressed((java.lang.Throwable) seriesException32);
        boolean boolean34 = day23.equals((java.lang.Object) seriesException25);
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day23, (java.lang.Number) (short) 0);
        org.jfree.data.time.TimePeriodValue timePeriodValue38 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day23, (java.lang.Number) 13);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (short) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener10);
        java.lang.Class<?> wildcardClass12 = timePeriodValues7.getClass();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        java.lang.Number number15 = null;
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year13, number15);
        boolean boolean17 = timePeriodValue3.equals((java.lang.Object) number15);
        java.lang.String str18 = timePeriodValue3.toString();
        org.jfree.data.time.TimePeriod timePeriod19 = timePeriodValue3.getPeriod();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str18.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertNotNull(timePeriod19);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(class10);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        java.util.Date date22 = day19.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date11, date22);
        long long24 = simpleTimePeriod23.getStartMillis();
        java.util.Date date25 = simpleTimePeriod23.getEnd();
        long long26 = simpleTimePeriod23.getStartMillis();
        long long27 = simpleTimePeriod23.getStartMillis();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener13);
        int int15 = timePeriodValues3.getMaxEndIndex();
        try {
            timePeriodValues3.update(4, (java.lang.Number) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener7);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener9);
        java.lang.Class<?> wildcardClass11 = timePeriodValues6.getClass();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        java.util.Date date17 = year15.getStart();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date14, timeZone18);
        int int21 = year0.compareTo((java.lang.Object) wildcardClass11);
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timePeriodValues25.addPropertyChangeListener(propertyChangeListener26);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues25.addPropertyChangeListener(propertyChangeListener28);
        java.lang.Class<?> wildcardClass30 = timePeriodValues25.getClass();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getLastMillisecond();
        java.util.Date date33 = year31.getStart();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getLastMillisecond();
        java.util.Date date36 = year34.getStart();
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date36, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date33, timeZone37);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        long long41 = year40.getLastMillisecond();
        java.util.Date date42 = year40.getStart();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date42, timeZone43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date33, timeZone43);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
        java.util.Date date47 = day46.getStart();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date47);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod(date33, date47);
        java.util.Date date50 = simpleTimePeriod49.getStart();
        java.util.Date date51 = simpleTimePeriod49.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues55.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener58 = null;
        timePeriodValues55.removeChangeListener(seriesChangeListener58);
        int int60 = timePeriodValues55.getMaxEndIndex();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        long long62 = year61.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue64 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year61, (double) (short) 1);
        java.lang.Object obj65 = timePeriodValue64.clone();
        timePeriodValues55.add(timePeriodValue64);
        timePeriodValues55.setDescription("2019");
        timePeriodValues55.setNotify(false);
        boolean boolean71 = simpleTimePeriod49.equals((java.lang.Object) false);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1577865599999L + "'", long35 == 1577865599999L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1577865599999L + "'", long62 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj65);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues11.addPropertyChangeListener(propertyChangeListener12);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues11.addPropertyChangeListener(propertyChangeListener14);
        java.lang.Class<?> wildcardClass16 = timePeriodValues11.getClass();
        int int17 = timePeriodValues11.getMinMiddleIndex();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getLastMillisecond();
        timePeriodValues11.add((org.jfree.data.time.TimePeriod) year18, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year22, (double) (short) 1);
        java.lang.String str26 = timePeriodValue25.toString();
        timePeriodValues11.add(timePeriodValue25);
        java.lang.Object obj28 = timePeriodValue25.clone();
        java.lang.Object obj29 = timePeriodValue25.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = timePeriodValues33.createCopy(0, (int) (short) 100);
        timePeriodValues36.setNotify(false);
        int int39 = timePeriodValues36.getMinStartIndex();
        timePeriodValues36.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: 2019");
        timePeriodValues36.setDescription("hi!");
        boolean boolean44 = timePeriodValue25.equals((java.lang.Object) timePeriodValues36);
        timePeriodValues3.add(timePeriodValue25);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str26.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(timePeriodValues36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
//        int int8 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener9);
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.next();
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod16, (java.lang.Number) 0);
//        org.jfree.data.time.TimePeriodValue timePeriodValue20 = timePeriodValues3.getDataItem((int) (short) 0);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.util.Date date22 = day21.getStart();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date22, timeZone24);
//        int int26 = day25.getDayOfMonth();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.util.Date date28 = day27.getStart();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
//        boolean boolean30 = day25.equals((java.lang.Object) day29);
//        boolean boolean31 = timePeriodValue20.equals((java.lang.Object) day29);
//        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1L));
//        int int34 = day29.compareTo((java.lang.Object) (-1L));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(timePeriodValue20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 13 + "'", int26 == 13);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (short) 1);
        java.lang.String str4 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) '4', (long) 2019);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.lang.String str8 = timePeriodValues7.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener9);
        int int11 = timePeriodValues7.getItemCount();
        boolean boolean12 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues7);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        long long6 = year4.getLastMillisecond();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        long long9 = year7.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues13.addPropertyChangeListener(propertyChangeListener14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues13.addPropertyChangeListener(propertyChangeListener16);
        java.lang.Class<?> wildcardClass18 = timePeriodValues13.getClass();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getLastMillisecond();
        java.util.Date date21 = year19.getStart();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getLastMillisecond();
        java.util.Date date24 = year22.getStart();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date24, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date21, timeZone25);
        int int28 = year7.compareTo((java.lang.Object) wildcardClass18);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        java.util.Date date30 = day29.getStart();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date30, timeZone32);
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener38 = null;
        timePeriodValues37.addPropertyChangeListener(propertyChangeListener38);
        java.beans.PropertyChangeListener propertyChangeListener40 = null;
        timePeriodValues37.addPropertyChangeListener(propertyChangeListener40);
        java.lang.Class<?> wildcardClass42 = timePeriodValues37.getClass();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        long long44 = year43.getLastMillisecond();
        java.util.Date date45 = year43.getStart();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        long long47 = year46.getLastMillisecond();
        java.util.Date date48 = year46.getStart();
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date48, timeZone49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date45, timeZone49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date30, timeZone49);
        int int53 = year4.compareTo((java.lang.Object) date30);
        java.util.Calendar calendar54 = null;
        try {
            long long55 = year4.getFirstMillisecond(calendar54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1562097599999L + "'", long9 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1577865599999L + "'", long44 == 1577865599999L);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1577865599999L + "'", long47 == 1577865599999L);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener5);
        int int7 = timePeriodValues3.getItemCount();
        int int8 = timePeriodValues3.getMinStartIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue10 = timePeriodValues3.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 11L + "'", long3 == 11L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 11L + "'", long4 == 11L);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) '4', (long) 2019);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        boolean boolean5 = simpleTimePeriod2.equals((java.lang.Object) 100.0f);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (short) 1);
        java.lang.Number number4 = timePeriodValue3.getValue();
        java.lang.Object obj5 = timePeriodValue3.clone();
        java.lang.String str6 = timePeriodValue3.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0d + "'", number4.equals(1.0d));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str6.equals("TimePeriodValue[2019,1.0]"));
    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        java.util.Date date12 = day0.getEnd();
//        long long13 = day0.getMiddleMillisecond();
//        int int14 = day0.getYear();
//        int int15 = day0.getDayOfMonth();
//        long long16 = day0.getSerialIndex();
//        java.util.Date date17 = day0.getStart();
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 13 + "'", int15 == 13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43629L + "'", long16 == 43629L);
//        org.junit.Assert.assertNotNull(date17);
//    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener10);
    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (short) 1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues7.createCopy(0, (int) (short) 100);
//        boolean boolean11 = timePeriodValues10.isEmpty();
//        boolean boolean12 = timePeriodValue3.equals((java.lang.Object) timePeriodValues10);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener18 = null;
//        timePeriodValues17.addPropertyChangeListener(propertyChangeListener18);
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timePeriodValues17.addPropertyChangeListener(propertyChangeListener20);
//        java.lang.Class<?> wildcardClass22 = timePeriodValues17.getClass();
//        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
//        boolean boolean24 = day13.equals((java.lang.Object) wildcardClass22);
//        java.util.Date date25 = day13.getEnd();
//        long long26 = day13.getMiddleMillisecond();
//        int int27 = day13.getYear();
//        int int28 = day13.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day13.previous();
//        java.util.Date date30 = day13.getEnd();
//        timePeriodValues10.add((org.jfree.data.time.TimePeriod) day13, (double) 1546415999999L);
//        java.util.Calendar calendar33 = null;
//        try {
//            day13.peg(calendar33);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertNotNull(timePeriodValues10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560452399999L + "'", long26 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date30);
//    }

//    @Test
//    public void test480() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test480");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (short) 1);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getStart();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
//        long long7 = day6.getLastMillisecond();
//        boolean boolean8 = timePeriodValue3.equals((java.lang.Object) long7);
//        java.lang.Number number9 = timePeriodValue3.getValue();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560495599999L + "'", long7 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1.0d + "'", number9.equals(1.0d));
//    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener5);
        int int7 = timePeriodValues3.getItemCount();
        timePeriodValues3.setRangeDescription("TimePeriodValue[2020,9.0]");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date6, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date2, timeZone8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        int int12 = year10.compareTo((java.lang.Object) day11);
        org.jfree.data.time.SerialDate serialDate13 = day11.getSerialDate();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day11, "", "");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        timePeriodValues13.setRangeDescription("2019");
        timePeriodValues13.setRangeDescription("");
        java.lang.String str18 = timePeriodValues13.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener19);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
        int int13 = day0.compareTo((java.lang.Object) 0L);
        org.jfree.data.time.SerialDate serialDate14 = day0.getSerialDate();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(serialDate14);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (short) 1);
        java.lang.Object obj13 = timePeriodValue12.clone();
        timePeriodValues3.add(timePeriodValue12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year15, (double) 100.0f);
        java.lang.Object obj18 = null;
        boolean boolean19 = year15.equals(obj18);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "", "");
        int int24 = year15.compareTo((java.lang.Object) timePeriodValues23);
        int int25 = timePeriodValues23.getItemCount();
        boolean boolean26 = timePeriodValues23.isEmpty();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        java.lang.String str14 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setRangeDescription("");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

//    @Test
//    public void test487() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test487");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1, timeZone3);
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getStart();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
//        boolean boolean9 = day4.equals((java.lang.Object) day8);
//        java.util.Date date10 = day4.getEnd();
//        java.util.Date date11 = day4.getEnd();
//        java.lang.String str12 = day4.toString();
//        long long13 = day4.getFirstMillisecond();
//        java.util.Calendar calendar14 = null;
//        try {
//            long long15 = day4.getMiddleMillisecond(calendar14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "13-June-2019" + "'", str12.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.Object obj2 = null;
//        int int3 = day0.compareTo(obj2);
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener8 = null;
//        timePeriodValues7.addPropertyChangeListener(propertyChangeListener8);
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timePeriodValues7.addPropertyChangeListener(propertyChangeListener10);
//        int int12 = timePeriodValues7.getMaxStartIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
//        timePeriodValues7.removeChangeListener(seriesChangeListener13);
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues7.createCopy((int) (short) -1, (-1));
//        java.lang.Comparable comparable18 = timePeriodValues7.getKey();
//        int int19 = timePeriodValues7.getMinMiddleIndex();
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timePeriodValues7.removePropertyChangeListener(propertyChangeListener20);
//        timePeriodValues7.setDomainDescription("");
//        int int24 = timePeriodValues7.getMinMiddleIndex();
//        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener29 = null;
//        timePeriodValues28.addPropertyChangeListener(propertyChangeListener29);
//        java.beans.PropertyChangeListener propertyChangeListener31 = null;
//        timePeriodValues28.addPropertyChangeListener(propertyChangeListener31);
//        java.lang.Class<?> wildcardClass33 = timePeriodValues28.getClass();
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
//        long long35 = year34.getLastMillisecond();
//        java.util.Date date36 = year34.getStart();
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
//        long long38 = year37.getLastMillisecond();
//        java.util.Date date39 = year37.getStart();
//        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date39, timeZone40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date36, timeZone40);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date36);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        int int45 = day44.getMonth();
//        org.jfree.data.time.SerialDate serialDate46 = day44.getSerialDate();
//        java.util.Date date47 = day44.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod(date36, date47);
//        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener53 = null;
//        timePeriodValues52.addPropertyChangeListener(propertyChangeListener53);
//        java.beans.PropertyChangeListener propertyChangeListener55 = null;
//        timePeriodValues52.addPropertyChangeListener(propertyChangeListener55);
//        java.lang.Class<?> wildcardClass57 = timePeriodValues52.getClass();
//        int int58 = timePeriodValues52.getMinMiddleIndex();
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
//        long long60 = year59.getLastMillisecond();
//        timePeriodValues52.add((org.jfree.data.time.TimePeriod) year59, (java.lang.Number) (byte) 10);
//        java.util.Date date63 = year59.getEnd();
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date63);
//        int int65 = simpleTimePeriod48.compareTo((java.lang.Object) day64);
//        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day64, 1.0d);
//        java.lang.Object obj68 = timePeriodValues7.clone();
//        boolean boolean69 = day0.equals(obj68);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues74 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener75 = null;
//        timePeriodValues74.addPropertyChangeListener(propertyChangeListener75);
//        java.beans.PropertyChangeListener propertyChangeListener77 = null;
//        timePeriodValues74.addPropertyChangeListener(propertyChangeListener77);
//        java.lang.Class<?> wildcardClass79 = timePeriodValues74.getClass();
//        java.lang.Class class80 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass79);
//        boolean boolean81 = day70.equals((java.lang.Object) wildcardClass79);
//        java.util.Date date82 = day70.getEnd();
//        long long83 = day70.getMiddleMillisecond();
//        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year();
//        long long85 = year84.getLastMillisecond();
//        java.util.Date date86 = year84.getStart();
//        java.util.TimeZone timeZone87 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year88 = new org.jfree.data.time.Year(date86, timeZone87);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = year88.next();
//        boolean boolean90 = day70.equals((java.lang.Object) year88);
//        boolean boolean92 = day70.equals((java.lang.Object) 2019L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = day70.next();
//        boolean boolean94 = day0.equals((java.lang.Object) day70);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues17);
//        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + (byte) 1 + "'", comparable18.equals((byte) 1));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1577865599999L + "'", long35 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1577865599999L + "'", long38 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(timeZone40);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 6 + "'", int45 == 6);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(wildcardClass57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1577865599999L + "'", long60 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
//        org.junit.Assert.assertNotNull(obj68);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertNotNull(wildcardClass79);
//        org.junit.Assert.assertNotNull(class80);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 1560452399999L + "'", long83 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1577865599999L + "'", long85 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date86);
//        org.junit.Assert.assertNotNull(timeZone87);
//        org.junit.Assert.assertNotNull(regularTimePeriod89);
//        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
//        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod93);
//        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues7.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues7.removeChangeListener(seriesChangeListener10);
        int int12 = timePeriodValues7.getMaxEndIndex();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (double) (short) 1);
        java.lang.Object obj17 = timePeriodValue16.clone();
        timePeriodValues7.add(timePeriodValue16);
        java.lang.String str19 = timePeriodValue16.toString();
        timePeriodValues3.add(timePeriodValue16);
        int int21 = timePeriodValues3.getItemCount();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) int21);
        java.lang.Object obj23 = seriesChangeEvent22.getSource();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str19.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + obj23 + "' != '" + 1 + "'", obj23.equals(1));
    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.Object obj2 = null;
//        int int3 = day0.compareTo(obj2);
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timePeriodValues8.addPropertyChangeListener(propertyChangeListener9);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timePeriodValues8.addPropertyChangeListener(propertyChangeListener11);
//        int int13 = timePeriodValues8.getMaxStartIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
//        timePeriodValues8.removeChangeListener(seriesChangeListener14);
//        org.jfree.data.time.TimePeriodValues timePeriodValues18 = timePeriodValues8.createCopy((int) (short) -1, (-1));
//        timePeriodValues8.setRangeDescription("1-January-2019");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timePeriodValues8.removeChangeListener(seriesChangeListener21);
//        java.lang.Object obj23 = timePeriodValues8.clone();
//        boolean boolean24 = day0.equals((java.lang.Object) timePeriodValues8);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues18);
//        org.junit.Assert.assertNotNull(obj23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        java.lang.Comparable comparable5 = timePeriodValues3.getKey();
        boolean boolean6 = timePeriodValues3.isEmpty();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getLastMillisecond();
        java.util.Date date9 = year7.getStart();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        java.util.Date date13 = year11.getStart();
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date13, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date9, timeZone14);
        timePeriodValues3.setKey((java.lang.Comparable) year16);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (byte) 1 + "'", comparable5.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone14);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        java.lang.Object obj6 = timePeriodValues3.clone();
        boolean boolean7 = timePeriodValues3.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener8);
        java.lang.String str10 = timePeriodValues3.getDescription();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (short) 1);
        java.lang.Object obj13 = timePeriodValue12.clone();
        timePeriodValues3.add(timePeriodValue12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year15, (double) 100.0f);
        java.lang.Object obj18 = null;
        boolean boolean19 = year15.equals(obj18);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "", "");
        int int24 = year15.compareTo((java.lang.Object) timePeriodValues23);
        int int25 = timePeriodValues23.getItemCount();
        java.lang.Class<?> wildcardClass26 = timePeriodValues23.getClass();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getLastMillisecond();
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        long long6 = year0.getLastMillisecond();
        long long7 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        timePeriodValues13.setRangeDescription("2019");
        int int16 = timePeriodValues13.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        java.util.Date date6 = year4.getStart();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        java.lang.String str10 = year8.toString();
        int int11 = year0.compareTo((java.lang.Object) year8);
        long long12 = year0.getMiddleMillisecond();
        long long13 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        int int11 = timePeriodValues3.getItemCount();
        int int12 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) '4', (long) 2019);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1L));
        java.beans.PropertyChangeListener propertyChangeListener2 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener2);
        timePeriodValues1.setDescription("hi!");
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (short) 1);
        java.lang.Object obj13 = timePeriodValue12.clone();
        timePeriodValues3.add(timePeriodValue12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year15, (double) 100.0f);
        int int18 = year15.getYear();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
    }
}

