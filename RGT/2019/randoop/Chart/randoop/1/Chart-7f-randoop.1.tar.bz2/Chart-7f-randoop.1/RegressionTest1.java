import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        java.lang.String str6 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.previous();
        long long8 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year4.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year4, (java.lang.Number) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timePeriodValues3.isEmpty();
        int int7 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues11.addPropertyChangeListener(propertyChangeListener12);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues11.addPropertyChangeListener(propertyChangeListener14);
        int int16 = timePeriodValues11.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues11.removeChangeListener(seriesChangeListener17);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = timePeriodValues11.createCopy((int) (short) -1, (-1));
        boolean boolean22 = timePeriodValues3.equals((java.lang.Object) (short) -1);
        java.lang.String str23 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        long long19 = day18.getSerialIndex();
        java.util.Calendar calendar20 = null;
        try {
            long long21 = day18.getLastMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43466L + "'", long19 == 43466L);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        java.util.Date date12 = day0.getEnd();
//        long long13 = day0.getMiddleMillisecond();
//        int int14 = day0.getYear();
//        long long15 = day0.getMiddleMillisecond();
//        int int16 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day0.next();
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560452399999L + "'", long15 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getLastMillisecond();
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        java.lang.Object obj5 = null;
        boolean boolean6 = year0.equals(obj5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getLastMillisecond();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day4.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy(0, (int) (short) 100);
        timePeriodValues6.setNotify(false);
        int int9 = timePeriodValues6.getMinStartIndex();
        int int10 = timePeriodValues6.getItemCount();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year11.previous();
        long long15 = year11.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year11.previous();
        long long17 = regularTimePeriod16.getMiddleMillisecond();
        java.util.Date date18 = regularTimePeriod16.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        java.util.Date date20 = year19.getStart();
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) year19, (double) (byte) 10);
        timePeriodValues6.setNotify(false);
        int int25 = timePeriodValues6.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues29.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
        timePeriodValues29.removeChangeListener(seriesChangeListener32);
        int int34 = timePeriodValues29.getMaxEndIndex();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        long long36 = year35.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue38 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year35, (double) (short) 1);
        java.lang.Object obj39 = timePeriodValue38.clone();
        timePeriodValues29.add(timePeriodValue38);
        java.lang.Number number41 = timePeriodValue38.getValue();
        java.lang.String str42 = timePeriodValue38.toString();
        timePeriodValues6.add(timePeriodValue38);
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1562097599999L + "'", long15 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1530561599999L + "'", long17 == 1530561599999L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577865599999L + "'", long36 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 1.0d + "'", number41.equals(1.0d));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str42.equals("TimePeriodValue[2019,1.0]"));
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.Object obj2 = null;
//        int int3 = day0.compareTo(obj2);
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getMiddleMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("2019");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray6 = seriesException5.getSuppressed();
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray9 = seriesException8.getSuppressed();
        seriesException5.addSuppressed((java.lang.Throwable) seriesException8);
        seriesException3.addSuppressed((java.lang.Throwable) seriesException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.String str15 = timePeriodFormatException14.toString();
        seriesException3.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("");
        seriesException3.addSuppressed((java.lang.Throwable) seriesException18);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str15.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod2);
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) (byte) 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (byte) 10);
        java.lang.String str14 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj15 = timePeriodValues3.clone();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener16);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        java.util.Date date6 = year4.getStart();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date2, timeZone7);
        int int10 = year9.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        java.util.Date date22 = day19.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date11, date22);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date22, "2019", "org.jfree.data.general.SeriesException: 2019");
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timePeriodValues30.addPropertyChangeListener(propertyChangeListener31);
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timePeriodValues30.addPropertyChangeListener(propertyChangeListener33);
        java.lang.Class<?> wildcardClass35 = timePeriodValues30.getClass();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        long long37 = year36.getLastMillisecond();
        java.lang.Number number38 = null;
        timePeriodValues30.add((org.jfree.data.time.TimePeriod) year36, number38);
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener44 = null;
        timePeriodValues43.addPropertyChangeListener(propertyChangeListener44);
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timePeriodValues43.addPropertyChangeListener(propertyChangeListener46);
        java.lang.Class<?> wildcardClass48 = timePeriodValues43.getClass();
        int int49 = timePeriodValues43.getMinMiddleIndex();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        long long51 = year50.getLastMillisecond();
        timePeriodValues43.add((org.jfree.data.time.TimePeriod) year50, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        long long55 = year54.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue57 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year54, (double) (short) 1);
        java.lang.String str58 = timePeriodValue57.toString();
        timePeriodValues43.add(timePeriodValue57);
        java.lang.String str60 = timePeriodValue57.toString();
        timePeriodValues30.add(timePeriodValue57);
        timePeriodValues26.add(timePeriodValue57);
        boolean boolean64 = timePeriodValue57.equals((java.lang.Object) 0.0d);
        timePeriodValue57.setValue((java.lang.Number) 1.0f);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1577865599999L + "'", long37 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1577865599999L + "'", long51 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1577865599999L + "'", long55 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str58.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str60.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        java.lang.String str6 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.previous();
        long long8 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year4.previous();
        long long10 = year4.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getLastMillisecond();
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 0, (long) (byte) 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (short) 1);
        java.lang.Object obj13 = timePeriodValue12.clone();
        timePeriodValues3.add(timePeriodValue12);
        java.lang.Object obj15 = timePeriodValue12.clone();
        timePeriodValue12.setValue((java.lang.Number) (-1.0d));
        timePeriodValue12.setValue((java.lang.Number) 0);
        org.jfree.data.time.TimePeriod timePeriod20 = timePeriodValue12.getPeriod();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(timePeriod20);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date6, timeZone8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date4, timeZone8);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener17);
        java.lang.Class<?> wildcardClass19 = timePeriodValues14.getClass();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getLastMillisecond();
        java.util.Date date22 = year20.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getLastMillisecond();
        java.util.Date date25 = year23.getStart();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date25, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date22, timeZone26);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timePeriodValues33.addPropertyChangeListener(propertyChangeListener34);
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timePeriodValues33.addPropertyChangeListener(propertyChangeListener36);
        java.lang.Class<?> wildcardClass38 = timePeriodValues33.getClass();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        long long40 = year39.getLastMillisecond();
        java.util.Date date41 = year39.getStart();
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year();
        long long43 = year42.getLastMillisecond();
        java.util.Date date44 = year42.getStart();
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date44, timeZone45);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date41, timeZone45);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date41);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
        int int50 = day49.getMonth();
        org.jfree.data.time.SerialDate serialDate51 = day49.getSerialDate();
        java.util.Date date52 = day49.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(date41, date52);
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date41);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod57 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        long long58 = simpleTimePeriod57.getStartMillis();
        java.util.Date date59 = simpleTimePeriod57.getEnd();
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
        java.util.Date date61 = day60.getStart();
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date61);
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date61, timeZone63);
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date59, timeZone63);
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date41, timeZone63);
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(date22, timeZone63);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod68 = new org.jfree.data.time.SimpleTimePeriod(date4, date22);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1577865599999L + "'", long43 == 1577865599999L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 6 + "'", int50 == 6);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-1L) + "'", long58 == (-1L));
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(timeZone63);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        int int2 = day1.getMonth();
        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
        java.util.Date date4 = day1.getEnd();
        java.lang.Class<?> wildcardClass5 = date4.getClass();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getLastMillisecond();
        java.util.Date date8 = year6.getStart();
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.util.Date date12 = day11.getStart();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date12, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date8, timeZone14);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date4, timeZone14);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener24);
        java.lang.Class<?> wildcardClass26 = timePeriodValues21.getClass();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getLastMillisecond();
        java.util.Date date29 = year27.getStart();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        long long31 = year30.getLastMillisecond();
        java.util.Date date32 = year30.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date32, timeZone33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date29, timeZone33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone33);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
        java.util.Date date39 = day38.getStart();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date39, timeZone41);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date4, timeZone41);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        long long45 = year44.getLastMillisecond();
        java.util.Date date46 = year44.getStart();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date46);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        long long49 = year48.getLastMillisecond();
        java.util.Date date50 = year48.getStart();
        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date50, timeZone51);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date46, timeZone51);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date4, timeZone51);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1577865599999L + "'", long45 == 1577865599999L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1577865599999L + "'", long49 == 1577865599999L);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(timeZone51);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        java.lang.String str5 = year4.toString();
        java.util.Date date6 = year4.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues10.addPropertyChangeListener(propertyChangeListener11);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.addPropertyChangeListener(propertyChangeListener13);
        java.lang.Class<?> wildcardClass15 = timePeriodValues10.getClass();
        int int16 = timePeriodValues10.getMinMiddleIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        timePeriodValues10.add((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year21, (double) (short) 1);
        java.lang.String str25 = timePeriodValue24.toString();
        timePeriodValues10.add(timePeriodValue24);
        java.lang.Object obj27 = timePeriodValue24.clone();
        java.lang.Object obj28 = timePeriodValue24.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = timePeriodValues32.createCopy(0, (int) (short) 100);
        timePeriodValues35.setNotify(false);
        int int38 = timePeriodValues35.getMinStartIndex();
        timePeriodValues35.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: 2019");
        timePeriodValues35.setDescription("hi!");
        boolean boolean43 = timePeriodValue24.equals((java.lang.Object) timePeriodValues35);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        long long45 = year44.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year44.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year44.previous();
        long long48 = year44.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year44.previous();
        long long50 = year44.getLastMillisecond();
        timePeriodValues35.setKey((java.lang.Comparable) year44);
        int int52 = year4.compareTo((java.lang.Object) timePeriodValues35);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str25.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(timePeriodValues35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1577865599999L + "'", long45 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1562097599999L + "'", long48 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1577865599999L + "'", long50 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        long long3 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560495599999L + "'", long3 == 1560495599999L);
//    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.Object obj2 = null;
//        int int3 = day0.compareTo(obj2);
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = day6.getMiddleMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        timePeriodValues13.setRangeDescription("2019");
        timePeriodValues13.setRangeDescription("");
        java.lang.String str18 = timePeriodValues13.getDescription();
        timePeriodValues13.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timePeriodValues24.addPropertyChangeListener(propertyChangeListener25);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timePeriodValues24.addPropertyChangeListener(propertyChangeListener27);
        java.lang.Class<?> wildcardClass29 = timePeriodValues24.getClass();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues24);
        java.lang.String str31 = seriesChangeEvent30.toString();
        java.lang.Object obj32 = seriesChangeEvent30.getSource();
        boolean boolean33 = timePeriodValues13.equals((java.lang.Object) seriesChangeEvent30);
        timePeriodValues13.setDescription("");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues6.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues6.removeChangeListener(seriesChangeListener9);
        int int11 = timePeriodValues6.getMaxEndIndex();
        boolean boolean12 = year0.equals((java.lang.Object) timePeriodValues6);
        try {
            org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValues6.getTimePeriod((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.String str7 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("2019");
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray12 = seriesException11.getSuppressed();
        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray15 = seriesException14.getSuppressed();
        seriesException11.addSuppressed((java.lang.Throwable) seriesException14);
        seriesException9.addSuppressed((java.lang.Throwable) seriesException11);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException11);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesException: 2019" + "'", str7.equals("org.jfree.data.general.SeriesException: 2019"));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        java.util.Date date22 = day19.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date11, date22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getLastMillisecond();
        java.util.Date date26 = year24.getStart();
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date26, timeZone27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        java.util.Date date30 = day29.getStart();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date30, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date26, timeZone32);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        int int36 = year34.compareTo((java.lang.Object) day35);
        int int37 = simpleTimePeriod23.compareTo((java.lang.Object) year34);
        long long38 = year34.getLastMillisecond();
        java.util.Date date39 = year34.getStart();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date39);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1577865599999L + "'", long38 == 1577865599999L);
        org.junit.Assert.assertNotNull(date39);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (short) 1);
        java.lang.Object obj4 = timePeriodValue3.clone();
        java.lang.String str5 = timePeriodValue3.toString();
        java.lang.Number number6 = timePeriodValue3.getValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str5.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (short) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues7.createCopy(0, (int) (short) 100);
        boolean boolean11 = timePeriodValues10.isEmpty();
        boolean boolean12 = timePeriodValue3.equals((java.lang.Object) timePeriodValues10);
        timePeriodValues10.setKey((java.lang.Comparable) 1562097599999L);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues10.addPropertyChangeListener(propertyChangeListener15);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 100, "TimePeriodValue[2019,1.0]", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        java.lang.Class<?> wildcardClass5 = timePeriodValues3.getClass();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
        int int15 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener16);
        try {
            timePeriodValues3.delete(7, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (byte) 1 + "'", comparable14.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        java.util.Date date3 = day0.getEnd();
        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        java.util.Date date22 = day19.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date11, date22);
        long long24 = simpleTimePeriod23.getStartMillis();
        java.util.Date date25 = simpleTimePeriod23.getEnd();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod23, (java.lang.Number) 8);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) '4', (int) 'a', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 0, 1546415999999L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        long long19 = day18.getSerialIndex();
        int int20 = day18.getYear();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43466L + "'", long19 == 43466L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.String str7 = seriesException1.toString();
        java.lang.Class<?> wildcardClass8 = seriesException1.getClass();
        java.lang.Throwable[] throwableArray9 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesException: 2019" + "'", str7.equals("org.jfree.data.general.SeriesException: 2019"));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy(0, (int) (short) 100);
        timePeriodValues6.setNotify(false);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues12.addPropertyChangeListener(propertyChangeListener13);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues12.addPropertyChangeListener(propertyChangeListener15);
        java.lang.Class<?> wildcardClass17 = timePeriodValues12.getClass();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getLastMillisecond();
        java.util.Date date20 = year18.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getLastMillisecond();
        java.util.Date date23 = year21.getStart();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23, timeZone24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date20, timeZone24);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        int int29 = day28.getMonth();
        org.jfree.data.time.SerialDate serialDate30 = day28.getSerialDate();
        java.util.Date date31 = day28.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date20, date31);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date31, "2019", "org.jfree.data.general.SeriesException: 2019");
        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener40 = null;
        timePeriodValues39.addPropertyChangeListener(propertyChangeListener40);
        java.beans.PropertyChangeListener propertyChangeListener42 = null;
        timePeriodValues39.addPropertyChangeListener(propertyChangeListener42);
        java.lang.Class<?> wildcardClass44 = timePeriodValues39.getClass();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        long long46 = year45.getLastMillisecond();
        java.lang.Number number47 = null;
        timePeriodValues39.add((org.jfree.data.time.TimePeriod) year45, number47);
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener53 = null;
        timePeriodValues52.addPropertyChangeListener(propertyChangeListener53);
        java.beans.PropertyChangeListener propertyChangeListener55 = null;
        timePeriodValues52.addPropertyChangeListener(propertyChangeListener55);
        java.lang.Class<?> wildcardClass57 = timePeriodValues52.getClass();
        int int58 = timePeriodValues52.getMinMiddleIndex();
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        long long60 = year59.getLastMillisecond();
        timePeriodValues52.add((org.jfree.data.time.TimePeriod) year59, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        long long64 = year63.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue66 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year63, (double) (short) 1);
        java.lang.String str67 = timePeriodValue66.toString();
        timePeriodValues52.add(timePeriodValue66);
        java.lang.String str69 = timePeriodValue66.toString();
        timePeriodValues39.add(timePeriodValue66);
        timePeriodValues35.add(timePeriodValue66);
        timePeriodValues6.add(timePeriodValue66);
        int int73 = timePeriodValues6.getMaxEndIndex();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1577865599999L + "'", long46 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1577865599999L + "'", long60 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1577865599999L + "'", long64 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str67.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str69.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        java.util.Date date22 = day19.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date11, date22);
        long long24 = simpleTimePeriod23.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues28.addPropertyChangeListener(propertyChangeListener29);
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timePeriodValues28.addPropertyChangeListener(propertyChangeListener31);
        java.lang.Class<?> wildcardClass33 = timePeriodValues28.getClass();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getLastMillisecond();
        java.util.Date date36 = year34.getStart();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        long long38 = year37.getLastMillisecond();
        java.util.Date date39 = year37.getStart();
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date39, timeZone40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date36, timeZone40);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
        int int45 = day44.getMonth();
        org.jfree.data.time.SerialDate serialDate46 = day44.getSerialDate();
        java.util.Date date47 = day44.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod(date36, date47);
        org.jfree.data.time.TimePeriodValues timePeriodValues49 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date36);
        boolean boolean50 = simpleTimePeriod23.equals((java.lang.Object) timePeriodValues49);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener51 = null;
        timePeriodValues49.removeChangeListener(seriesChangeListener51);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1577865599999L + "'", long35 == 1577865599999L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1577865599999L + "'", long38 == 1577865599999L);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 6 + "'", int45 == 6);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        java.util.Date date12 = day0.getEnd();
//        long long13 = day0.getMiddleMillisecond();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getLastMillisecond();
//        java.util.Date date16 = year14.getStart();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date16, timeZone17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
//        boolean boolean20 = day0.equals((java.lang.Object) year18);
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        long long22 = year21.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year21, (double) (short) 1);
//        java.lang.String str25 = timePeriodValue24.toString();
//        boolean boolean26 = day0.equals((java.lang.Object) str25);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str25.equals("TimePeriodValue[2019,1.0]"));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        java.util.Date date12 = day0.getEnd();
//        long long13 = day0.getMiddleMillisecond();
//        int int14 = day0.getYear();
//        boolean boolean16 = day0.equals((java.lang.Object) (byte) 0);
//        java.lang.String str17 = day0.toString();
//        int int18 = day0.getDayOfMonth();
//        java.util.Date date19 = day0.getEnd();
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 13 + "'", int18 == 13);
//        org.junit.Assert.assertNotNull(date19);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        java.lang.String str6 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.previous();
        long long8 = year4.getSerialIndex();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) long8);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        long long5 = day3.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate6 = day3.getSerialDate();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate6);
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day7, "TimePeriodValue[2019,1.0]", "TimePeriodValue[2020,9.0]");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        int int3 = day0.getYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        long long5 = day3.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, (java.lang.Number) 10.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day3.next();
        int int9 = day3.getYear();
        java.util.Date date10 = day3.getEnd();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = day3.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        int int5 = year0.getYear();
        java.util.Calendar calendar6 = null;
        try {
            year0.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (short) 1);
//        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues7.createCopy(0, (int) (short) 100);
//        boolean boolean11 = timePeriodValues10.isEmpty();
//        boolean boolean12 = timePeriodValue3.equals((java.lang.Object) timePeriodValues10);
//        timePeriodValues10.setDomainDescription("1-January-2019");
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener20 = null;
//        timePeriodValues19.addPropertyChangeListener(propertyChangeListener20);
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timePeriodValues19.addPropertyChangeListener(propertyChangeListener22);
//        java.lang.Class<?> wildcardClass24 = timePeriodValues19.getClass();
//        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
//        boolean boolean26 = day15.equals((java.lang.Object) wildcardClass24);
//        long long27 = day15.getLastMillisecond();
//        long long28 = day15.getSerialIndex();
//        timePeriodValues10.add((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) 10L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertNotNull(timePeriodValues10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560495599999L + "'", long27 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 43629L + "'", long28 == 43629L);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(3, 3, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (97) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
//        long long4 = year0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
//        long long6 = regularTimePeriod5.getMiddleMillisecond();
//        java.util.Date date7 = regularTimePeriod5.getStart();
//        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener14 = null;
//        timePeriodValues13.addPropertyChangeListener(propertyChangeListener14);
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timePeriodValues13.addPropertyChangeListener(propertyChangeListener16);
//        java.lang.Class<?> wildcardClass18 = timePeriodValues13.getClass();
//        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
//        boolean boolean20 = day9.equals((java.lang.Object) wildcardClass18);
//        java.util.Date date21 = day9.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date7, date21);
//        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener27 = null;
//        timePeriodValues26.addPropertyChangeListener(propertyChangeListener27);
//        java.beans.PropertyChangeListener propertyChangeListener29 = null;
//        timePeriodValues26.addPropertyChangeListener(propertyChangeListener29);
//        int int31 = timePeriodValues26.getMaxStartIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener32 = null;
//        timePeriodValues26.removeChangeListener(seriesChangeListener32);
//        org.jfree.data.time.TimePeriodValues timePeriodValues36 = timePeriodValues26.createCopy((int) (short) -1, (-1));
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener42 = null;
//        timePeriodValues41.addPropertyChangeListener(propertyChangeListener42);
//        java.beans.PropertyChangeListener propertyChangeListener44 = null;
//        timePeriodValues41.addPropertyChangeListener(propertyChangeListener44);
//        java.lang.Class<?> wildcardClass46 = timePeriodValues41.getClass();
//        java.lang.Class class47 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass46);
//        boolean boolean48 = day37.equals((java.lang.Object) wildcardClass46);
//        java.util.Date date49 = day37.getEnd();
//        long long50 = day37.getMiddleMillisecond();
//        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
//        long long52 = year51.getLastMillisecond();
//        java.util.Date date53 = year51.getStart();
//        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date53, timeZone54);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = year55.next();
//        boolean boolean57 = day37.equals((java.lang.Object) year55);
//        timePeriodValues36.setKey((java.lang.Comparable) year55);
//        try {
//            int int59 = simpleTimePeriod22.compareTo((java.lang.Object) timePeriodValues36);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertNotNull(regularTimePeriod3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1530561599999L + "'", long6 == 1530561599999L);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(wildcardClass18);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues36);
//        org.junit.Assert.assertNotNull(wildcardClass46);
//        org.junit.Assert.assertNotNull(class47);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560452399999L + "'", long50 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1577865599999L + "'", long52 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertNotNull(timeZone54);
//        org.junit.Assert.assertNotNull(regularTimePeriod56);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        java.util.Date date22 = day19.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date11, date22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getLastMillisecond();
        java.util.Date date26 = year24.getStart();
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date26, timeZone27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        java.util.Date date30 = day29.getStart();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date30, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date26, timeZone32);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        int int36 = year34.compareTo((java.lang.Object) day35);
        int int37 = simpleTimePeriod23.compareTo((java.lang.Object) year34);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        long long39 = year38.getLastMillisecond();
        long long40 = year38.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener45 = null;
        timePeriodValues44.addPropertyChangeListener(propertyChangeListener45);
        java.beans.PropertyChangeListener propertyChangeListener47 = null;
        timePeriodValues44.addPropertyChangeListener(propertyChangeListener47);
        java.lang.Class<?> wildcardClass49 = timePeriodValues44.getClass();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        long long51 = year50.getLastMillisecond();
        java.util.Date date52 = year50.getStart();
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        long long54 = year53.getLastMillisecond();
        java.util.Date date55 = year53.getStart();
        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date55, timeZone56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date52, timeZone56);
        int int59 = year38.compareTo((java.lang.Object) wildcardClass49);
        org.jfree.data.time.TimePeriodValues timePeriodValues63 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener64 = null;
        timePeriodValues63.addPropertyChangeListener(propertyChangeListener64);
        java.beans.PropertyChangeListener propertyChangeListener66 = null;
        timePeriodValues63.addPropertyChangeListener(propertyChangeListener66);
        java.lang.Class<?> wildcardClass68 = timePeriodValues63.getClass();
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year();
        long long70 = year69.getLastMillisecond();
        java.util.Date date71 = year69.getStart();
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year();
        long long73 = year72.getLastMillisecond();
        java.util.Date date74 = year72.getStart();
        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(date74, timeZone75);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass68, date71, timeZone75);
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        long long79 = year78.getLastMillisecond();
        java.util.Date date80 = year78.getStart();
        java.util.TimeZone timeZone81 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year(date80, timeZone81);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date71, timeZone81);
        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day();
        java.util.Date date85 = day84.getStart();
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date85);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod87 = new org.jfree.data.time.SimpleTimePeriod(date71, date85);
        boolean boolean88 = simpleTimePeriod23.equals((java.lang.Object) simpleTimePeriod87);
        java.util.Date date89 = simpleTimePeriod87.getStart();
        java.util.Date date90 = simpleTimePeriod87.getStart();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1562097599999L + "'", long40 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1577865599999L + "'", long51 == 1577865599999L);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1577865599999L + "'", long54 == 1577865599999L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(timeZone56);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertNotNull(wildcardClass68);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1577865599999L + "'", long70 == 1577865599999L);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1577865599999L + "'", long73 == 1577865599999L);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(timeZone75);
        org.junit.Assert.assertNull(regularTimePeriod77);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 1577865599999L + "'", long79 == 1577865599999L);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertNotNull(timeZone81);
        org.junit.Assert.assertNull(regularTimePeriod83);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(date89);
        org.junit.Assert.assertNotNull(date90);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        java.util.Date date12 = day0.getEnd();
//        long long13 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560409200000L + "'", long13 == 1560409200000L);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
        int int15 = timePeriodValues3.getMinMiddleIndex();
        boolean boolean16 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener17);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (byte) 1 + "'", comparable14.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        long long5 = day3.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, (java.lang.Number) 10.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day3.next();
        int int9 = day3.getYear();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = day3.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2);
        long long6 = year5.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener5);
        int int7 = timePeriodValues3.getItemCount();
        int int8 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.delete((int) (byte) 100, (int) (short) 1);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: 2019");
        java.lang.Class<?> wildcardClass2 = timePeriodFormatException1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 100, "TimePeriodValue[2019,1.0]", "");
        int int4 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener5);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener5);
        int int7 = timePeriodValues3.getItemCount();
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = null;
        try {
            timePeriodValues3.add(timePeriodValue11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day2.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues7.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues7.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues7.removeChangeListener(seriesChangeListener13);
        boolean boolean15 = day2.equals((java.lang.Object) seriesChangeListener13);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date6, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date2, timeZone8);
        java.lang.Class<?> wildcardClass11 = year10.getClass();
        java.lang.String str12 = year10.toString();
        long long13 = year10.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562097599999L + "'", long13 == 1562097599999L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.lang.Object obj2 = null;
        int int3 = day0.compareTo(obj2);
        int int4 = day0.getMonth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy(0, (int) (short) 100);
        int int7 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener7);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener9);
        java.lang.Class<?> wildcardClass11 = timePeriodValues6.getClass();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        java.util.Date date17 = year15.getStart();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date14, timeZone18);
        int int21 = year0.compareTo((java.lang.Object) wildcardClass11);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getLastMillisecond();
        java.util.Date date24 = year22.getStart();
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date24, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date24);
        int int28 = year0.compareTo((java.lang.Object) date24);
        java.lang.String str29 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2019" + "'", str29.equals("2019"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(7, 4, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        timePeriodValues3.setRangeDescription("1-January-2019");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener16);
        int int18 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (short) 1);
        java.lang.Object obj13 = timePeriodValue12.clone();
        timePeriodValues3.add(timePeriodValue12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year15, (double) 100.0f);
        java.lang.Object obj18 = null;
        boolean boolean19 = year15.equals(obj18);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "", "");
        int int24 = year15.compareTo((java.lang.Object) timePeriodValues23);
        long long25 = year15.getSerialIndex();
        long long26 = year15.getFirstMillisecond();
        java.util.Date date27 = year15.getStart();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date27);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 2019L + "'", long25 == 2019L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertNotNull(date27);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener5);
//        boolean boolean7 = timePeriodValues3.getNotify();
//        timePeriodValues3.setDescription("org.jfree.data.general.SeriesException: 2019");
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timePeriodValues14.addPropertyChangeListener(propertyChangeListener17);
//        java.lang.Class<?> wildcardClass19 = timePeriodValues14.getClass();
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
//        boolean boolean21 = day10.equals((java.lang.Object) wildcardClass19);
//        java.util.Date date22 = day10.getEnd();
//        long long23 = day10.getMiddleMillisecond();
//        int int24 = day10.getYear();
//        int int25 = day10.getDayOfMonth();
//        boolean boolean26 = timePeriodValues3.equals((java.lang.Object) int25);
//        int int27 = timePeriodValues3.getMinStartIndex();
//        try {
//            java.lang.Number number29 = timePeriodValues3.getValue((int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560452399999L + "'", long23 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 13 + "'", int25 == 13);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
        int int13 = day0.compareTo((java.lang.Object) 0L);
        org.jfree.data.time.SerialDate serialDate14 = day0.getSerialDate();
        org.jfree.data.time.SerialDate serialDate15 = day0.getSerialDate();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues19.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues19.removePropertyChangeListener(propertyChangeListener22);
        int int24 = timePeriodValues19.getMinEndIndex();
        int int25 = day0.compareTo((java.lang.Object) int24);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        java.util.Date date12 = day0.getEnd();
//        long long13 = day0.getMiddleMillisecond();
//        int int14 = day0.getYear();
//        java.util.Date date15 = day0.getEnd();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertNotNull(date15);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        int int9 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.lang.Number number11 = null;
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year9, number11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener13);
        int int15 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener16);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        timePeriodValues13.setRangeDescription("2019");
        timePeriodValues13.setRangeDescription("");
        java.lang.String str18 = timePeriodValues13.getDescription();
        boolean boolean19 = timePeriodValues13.isEmpty();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=0.0]");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) (short) 1);
        java.lang.String str18 = timePeriodValue17.toString();
        timePeriodValues3.add(timePeriodValue17);
        java.lang.Object obj20 = timePeriodValue17.clone();
        java.lang.Object obj21 = timePeriodValue17.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = timePeriodValues25.createCopy(0, (int) (short) 100);
        timePeriodValues28.setNotify(false);
        int int31 = timePeriodValues28.getMinStartIndex();
        timePeriodValues28.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: 2019");
        timePeriodValues28.setDescription("hi!");
        boolean boolean36 = timePeriodValue17.equals((java.lang.Object) timePeriodValues28);
        org.jfree.data.time.TimePeriod timePeriod37 = timePeriodValue17.getPeriod();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str18.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(timePeriodValues28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(timePeriod37);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date6, timeZone8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date4, timeZone8);
        org.jfree.data.time.SerialDate serialDate11 = day10.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day10.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        java.util.Date date22 = day19.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date11, date22);
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timePeriodValues24.addChangeListener(seriesChangeListener25);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        long long2 = year0.getMiddleMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues6.addPropertyChangeListener(propertyChangeListener7);
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timePeriodValues6.addPropertyChangeListener(propertyChangeListener9);
//        java.lang.Class<?> wildcardClass11 = timePeriodValues6.getClass();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        long long13 = year12.getLastMillisecond();
//        java.util.Date date14 = year12.getStart();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        long long16 = year15.getLastMillisecond();
//        java.util.Date date17 = year15.getStart();
//        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17, timeZone18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date14, timeZone18);
//        int int21 = year0.compareTo((java.lang.Object) wildcardClass11);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        java.util.Date date23 = day22.getStart();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23, timeZone25);
//        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener31 = null;
//        timePeriodValues30.addPropertyChangeListener(propertyChangeListener31);
//        java.beans.PropertyChangeListener propertyChangeListener33 = null;
//        timePeriodValues30.addPropertyChangeListener(propertyChangeListener33);
//        java.lang.Class<?> wildcardClass35 = timePeriodValues30.getClass();
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
//        long long37 = year36.getLastMillisecond();
//        java.util.Date date38 = year36.getStart();
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
//        long long40 = year39.getLastMillisecond();
//        java.util.Date date41 = year39.getStart();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date41, timeZone42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date38, timeZone42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date23, timeZone42);
//        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        java.util.Date date48 = day47.getStart();
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date48);
//        int int50 = day49.getDayOfMonth();
//        int int51 = day49.getYear();
//        int int52 = day49.getYear();
//        java.util.Date date53 = day49.getStart();
//        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
//        long long55 = year54.getLastMillisecond();
//        java.util.Date date56 = year54.getStart();
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date56, timeZone57);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year58.next();
//        long long60 = year58.getFirstMillisecond();
//        long long61 = year58.getFirstMillisecond();
//        java.lang.String str62 = year58.toString();
//        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        boolean boolean64 = year58.equals((java.lang.Object) timeZone63);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date53, timeZone63);
//        org.jfree.data.time.TimePeriodValue timePeriodValue67 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod65, (double) 1546372799999L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(timeZone18);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1577865599999L + "'", long37 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(class46);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 13 + "'", int50 == 13);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2019 + "'", int51 == 2019);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1577865599999L + "'", long55 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1546329600000L + "'", long60 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1546329600000L + "'", long61 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "2019" + "'", str62.equals("2019"));
//        org.junit.Assert.assertNotNull(timeZone63);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod65);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (13) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMinEndIndex();
        timePeriodValues3.setDomainDescription("TimePeriodValue[2020,9.0]");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        long long4 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        long long6 = regularTimePeriod5.getMiddleMillisecond();
        java.util.Date date7 = regularTimePeriod5.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues13.addPropertyChangeListener(propertyChangeListener14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues13.addPropertyChangeListener(propertyChangeListener16);
        java.lang.Class<?> wildcardClass18 = timePeriodValues13.getClass();
        java.lang.Class class19 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass18);
        boolean boolean20 = day9.equals((java.lang.Object) wildcardClass18);
        java.util.Date date21 = day9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date7, date21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date7);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1530561599999L + "'", long6 == 1530561599999L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date6, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date2, timeZone8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year10.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod11, (double) 9);
        java.lang.Number number14 = timePeriodValue13.getValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 9.0d + "'", number14.equals(9.0d));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues6.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues6.removeChangeListener(seriesChangeListener9);
        int int11 = timePeriodValues6.getMaxEndIndex();
        boolean boolean12 = year0.equals((java.lang.Object) timePeriodValues6);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues6.createCopy(12, (int) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues19.addPropertyChangeListener(propertyChangeListener20);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues19.addPropertyChangeListener(propertyChangeListener22);
        java.lang.Class<?> wildcardClass24 = timePeriodValues19.getClass();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getLastMillisecond();
        java.util.Date date27 = year25.getStart();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        long long29 = year28.getLastMillisecond();
        java.util.Date date30 = year28.getStart();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date30, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date27, timeZone31);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date27);
        long long35 = day34.getSerialIndex();
        long long36 = day34.getLastMillisecond();
        int int37 = day34.getDayOfMonth();
        long long38 = day34.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day34.next();
        long long40 = day34.getFirstMillisecond();
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) day34, (java.lang.Number) 1.0f);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        int int44 = day43.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue46 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day43, (java.lang.Number) 2019);
        timePeriodValues6.add(timePeriodValue46);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 43466L + "'", long35 == 43466L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1546415999999L + "'", long36 == 1546415999999L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 43466L + "'", long38 == 43466L);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1546329600000L + "'", long40 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day3.previous();
        long long5 = day3.getFirstMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day3, (java.lang.Number) 10.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues11.addPropertyChangeListener(propertyChangeListener12);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues11.addPropertyChangeListener(propertyChangeListener14);
        java.lang.Class<?> wildcardClass16 = timePeriodValues11.getClass();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        java.util.Date date19 = year17.getStart();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getLastMillisecond();
        java.util.Date date22 = year20.getStart();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date22, timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date19, timeZone23);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date19);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        int int28 = day27.getMonth();
        org.jfree.data.time.SerialDate serialDate29 = day27.getSerialDate();
        java.util.Date date30 = day27.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(date19, date30);
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date30, "2019", "org.jfree.data.general.SeriesException: 2019");
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener39 = null;
        timePeriodValues38.addPropertyChangeListener(propertyChangeListener39);
        java.beans.PropertyChangeListener propertyChangeListener41 = null;
        timePeriodValues38.addPropertyChangeListener(propertyChangeListener41);
        java.lang.Class<?> wildcardClass43 = timePeriodValues38.getClass();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        long long45 = year44.getLastMillisecond();
        java.lang.Number number46 = null;
        timePeriodValues38.add((org.jfree.data.time.TimePeriod) year44, number46);
        org.jfree.data.time.TimePeriodValues timePeriodValues51 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener52 = null;
        timePeriodValues51.addPropertyChangeListener(propertyChangeListener52);
        java.beans.PropertyChangeListener propertyChangeListener54 = null;
        timePeriodValues51.addPropertyChangeListener(propertyChangeListener54);
        java.lang.Class<?> wildcardClass56 = timePeriodValues51.getClass();
        int int57 = timePeriodValues51.getMinMiddleIndex();
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
        long long59 = year58.getLastMillisecond();
        timePeriodValues51.add((org.jfree.data.time.TimePeriod) year58, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        long long63 = year62.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue65 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year62, (double) (short) 1);
        java.lang.String str66 = timePeriodValue65.toString();
        timePeriodValues51.add(timePeriodValue65);
        java.lang.String str68 = timePeriodValue65.toString();
        timePeriodValues38.add(timePeriodValue65);
        timePeriodValues34.add(timePeriodValue65);
        boolean boolean71 = day3.equals((java.lang.Object) timePeriodValue65);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1577865599999L + "'", long45 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1577865599999L + "'", long59 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1577865599999L + "'", long63 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str66.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str68.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        timePeriodValues3.setKey((java.lang.Comparable) 2);
        int int11 = timePeriodValues3.getMaxEndIndex();
        int int12 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) '4', (long) 2019);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.previous();
        long long8 = year4.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year4.previous();
        java.util.Date date10 = regularTimePeriod9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date3, date10);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod11, "hi!", "");
        timePeriodValues14.setDomainDescription("hi!");
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1562097599999L + "'", long8 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.lang.Object obj2 = null;
        int int3 = day0.compareTo(obj2);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues7.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues7.removeChangeListener(seriesChangeListener13);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues7.createCopy((int) (short) -1, (-1));
        java.lang.Comparable comparable18 = timePeriodValues7.getKey();
        int int19 = timePeriodValues7.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener20);
        timePeriodValues7.setDomainDescription("");
        int int24 = timePeriodValues7.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues28.addPropertyChangeListener(propertyChangeListener29);
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timePeriodValues28.addPropertyChangeListener(propertyChangeListener31);
        java.lang.Class<?> wildcardClass33 = timePeriodValues28.getClass();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getLastMillisecond();
        java.util.Date date36 = year34.getStart();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        long long38 = year37.getLastMillisecond();
        java.util.Date date39 = year37.getStart();
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date39, timeZone40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date36, timeZone40);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
        int int45 = day44.getMonth();
        org.jfree.data.time.SerialDate serialDate46 = day44.getSerialDate();
        java.util.Date date47 = day44.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod(date36, date47);
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener53 = null;
        timePeriodValues52.addPropertyChangeListener(propertyChangeListener53);
        java.beans.PropertyChangeListener propertyChangeListener55 = null;
        timePeriodValues52.addPropertyChangeListener(propertyChangeListener55);
        java.lang.Class<?> wildcardClass57 = timePeriodValues52.getClass();
        int int58 = timePeriodValues52.getMinMiddleIndex();
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        long long60 = year59.getLastMillisecond();
        timePeriodValues52.add((org.jfree.data.time.TimePeriod) year59, (java.lang.Number) (byte) 10);
        java.util.Date date63 = year59.getEnd();
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date63);
        int int65 = simpleTimePeriod48.compareTo((java.lang.Object) day64);
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day64, 1.0d);
        java.lang.Object obj68 = timePeriodValues7.clone();
        boolean boolean69 = day0.equals(obj68);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod72 = new org.jfree.data.time.SimpleTimePeriod((long) '4', (long) 2019);
        java.util.Date date73 = simpleTimePeriod72.getStart();
        boolean boolean74 = day0.equals((java.lang.Object) simpleTimePeriod72);
        org.jfree.data.time.TimePeriodValues timePeriodValues77 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) boolean74, "TimePeriodValue[2019,1.0]", "org.jfree.data.general.SeriesChangeEvent[source=0.0]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + (byte) 1 + "'", comparable18.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1577865599999L + "'", long35 == 1577865599999L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1577865599999L + "'", long38 == 1577865599999L);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 6 + "'", int45 == 6);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1577865599999L + "'", long60 == 1577865599999L);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(obj68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        timePeriodValues13.setRangeDescription("2019");
        timePeriodValues13.setRangeDescription("");
        java.lang.String str18 = timePeriodValues13.getDescription();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getLastMillisecond();
        java.util.Date date21 = year19.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21, timeZone22);
        java.lang.String str24 = year23.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.next();
        long long26 = year23.getSerialIndex();
        long long27 = year23.getLastMillisecond();
        boolean boolean28 = timePeriodValues13.equals((java.lang.Object) year23);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 2019L + "'", long26 == 2019L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1, timeZone3);
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getStart();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
//        boolean boolean9 = day4.equals((java.lang.Object) day8);
//        java.util.Date date10 = day4.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues14.createCopy(0, (int) (short) 100);
//        timePeriodValues17.setNotify(false);
//        int int20 = timePeriodValues17.getMinStartIndex();
//        int int21 = timePeriodValues17.getItemCount();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year22.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year22.previous();
//        long long26 = year22.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year22.previous();
//        long long28 = regularTimePeriod27.getMiddleMillisecond();
//        java.util.Date date29 = regularTimePeriod27.getStart();
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date29);
//        java.util.Date date31 = year30.getStart();
//        timePeriodValues17.add((org.jfree.data.time.TimePeriod) year30, (double) (byte) 10);
//        timePeriodValues17.setNotify(false);
//        int int36 = day4.compareTo((java.lang.Object) timePeriodValues17);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timePeriodValues17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1562097599999L + "'", long26 == 1562097599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1530561599999L + "'", long28 == 1530561599999L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues7.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues7.removeChangeListener(seriesChangeListener10);
        int int12 = timePeriodValues7.getMaxEndIndex();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (double) (short) 1);
        java.lang.Object obj17 = timePeriodValue16.clone();
        timePeriodValues7.add(timePeriodValue16);
        java.lang.String str19 = timePeriodValue16.toString();
        timePeriodValues3.add(timePeriodValue16);
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=2019]");
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str19.equals("TimePeriodValue[2019,1.0]"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        long long19 = day18.getSerialIndex();
        long long20 = day18.getLastMillisecond();
        int int21 = day18.getDayOfMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day18);
        java.util.Calendar calendar23 = null;
        try {
            long long24 = day18.getFirstMillisecond(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43466L + "'", long19 == 43466L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546415999999L + "'", long20 == 1546415999999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setDomainDescription("TimePeriodValue[2019,1.0]");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        java.util.Date date12 = year10.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues16.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timePeriodValues16.removeChangeListener(seriesChangeListener19);
        int int21 = timePeriodValues16.getMaxEndIndex();
        boolean boolean22 = year10.equals((java.lang.Object) timePeriodValues16);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 0.0d);
        int int25 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        long long12 = day0.getLastMillisecond();
//        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timePeriodValues16.addPropertyChangeListener(propertyChangeListener17);
//        java.beans.PropertyChangeListener propertyChangeListener19 = null;
//        timePeriodValues16.addPropertyChangeListener(propertyChangeListener19);
//        java.lang.Class<?> wildcardClass21 = timePeriodValues16.getClass();
//        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
//        long long23 = year22.getLastMillisecond();
//        java.util.Date date24 = year22.getStart();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
//        long long26 = year25.getLastMillisecond();
//        java.util.Date date27 = year25.getStart();
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27, timeZone28);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date24, timeZone28);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date24);
//        long long32 = day31.getSerialIndex();
//        long long33 = day31.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day31.next();
//        int int35 = day0.compareTo((java.lang.Object) day31);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560495599999L + "'", long12 == 1560495599999L);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 43466L + "'", long32 == 43466L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546415999999L + "'", long33 == 1546415999999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 163 + "'", int35 == 163);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener5);
        int int7 = timePeriodValues3.getItemCount();
        int int8 = timePeriodValues3.getMinStartIndex();
        boolean boolean9 = timePeriodValues3.isEmpty();
        try {
            org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValues3.getTimePeriod((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException8);
        java.lang.Throwable[] throwableArray10 = seriesException8.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 0);
        long long7 = simpleTimePeriod6.getStartMillis();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod6, (java.lang.Number) 11);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) (short) 1);
        java.lang.String str18 = timePeriodValue17.toString();
        timePeriodValues3.add(timePeriodValue17);
        java.lang.Object obj20 = timePeriodValue17.clone();
        java.lang.Object obj21 = timePeriodValue17.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = timePeriodValues25.createCopy(0, (int) (short) 100);
        timePeriodValues28.setNotify(false);
        int int31 = timePeriodValues28.getMinStartIndex();
        timePeriodValues28.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: 2019");
        timePeriodValues28.setDescription("hi!");
        boolean boolean36 = timePeriodValue17.equals((java.lang.Object) timePeriodValues28);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        long long38 = year37.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year37.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year37.previous();
        long long41 = year37.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year37.previous();
        long long43 = year37.getLastMillisecond();
        timePeriodValues28.setKey((java.lang.Comparable) year37);
        java.lang.String str45 = year37.toString();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str18.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(timePeriodValues28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1577865599999L + "'", long38 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1562097599999L + "'", long41 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1577865599999L + "'", long43 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "2019" + "'", str45.equals("2019"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray7 = seriesException1.getSuppressed();
        java.lang.String str8 = seriesException1.toString();
        java.lang.String str9 = seriesException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: 2019" + "'", str8.equals("org.jfree.data.general.SeriesException: 2019"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesException: 2019" + "'", str9.equals("org.jfree.data.general.SeriesException: 2019"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        java.util.Date date3 = day0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        long long6 = year4.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues10.addPropertyChangeListener(propertyChangeListener11);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.addPropertyChangeListener(propertyChangeListener13);
        java.lang.Class<?> wildcardClass15 = timePeriodValues10.getClass();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getLastMillisecond();
        java.util.Date date18 = year16.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getLastMillisecond();
        java.util.Date date21 = year19.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date18, timeZone22);
        int int25 = year4.compareTo((java.lang.Object) wildcardClass15);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timePeriodValues29.addPropertyChangeListener(propertyChangeListener30);
        java.beans.PropertyChangeListener propertyChangeListener32 = null;
        timePeriodValues29.addPropertyChangeListener(propertyChangeListener32);
        java.lang.Class<?> wildcardClass34 = timePeriodValues29.getClass();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        long long36 = year35.getLastMillisecond();
        java.util.Date date37 = year35.getStart();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        long long39 = year38.getLastMillisecond();
        java.util.Date date40 = year38.getStart();
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date40, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date37, timeZone41);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        long long45 = year44.getLastMillisecond();
        java.util.Date date46 = year44.getStart();
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date46, timeZone47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date37, timeZone47);
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date3, timeZone47);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577865599999L + "'", long36 == 1577865599999L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1577865599999L + "'", long45 == 1577865599999L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNull(regularTimePeriod49);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.lang.Object obj2 = null;
        int int3 = day0.compareTo(obj2);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues7.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues7.removeChangeListener(seriesChangeListener13);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues7.createCopy((int) (short) -1, (-1));
        java.lang.Comparable comparable18 = timePeriodValues7.getKey();
        int int19 = timePeriodValues7.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues7.removePropertyChangeListener(propertyChangeListener20);
        timePeriodValues7.setDomainDescription("");
        int int24 = timePeriodValues7.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener29 = null;
        timePeriodValues28.addPropertyChangeListener(propertyChangeListener29);
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timePeriodValues28.addPropertyChangeListener(propertyChangeListener31);
        java.lang.Class<?> wildcardClass33 = timePeriodValues28.getClass();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getLastMillisecond();
        java.util.Date date36 = year34.getStart();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        long long38 = year37.getLastMillisecond();
        java.util.Date date39 = year37.getStart();
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date39, timeZone40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date36, timeZone40);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
        int int45 = day44.getMonth();
        org.jfree.data.time.SerialDate serialDate46 = day44.getSerialDate();
        java.util.Date date47 = day44.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod(date36, date47);
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener53 = null;
        timePeriodValues52.addPropertyChangeListener(propertyChangeListener53);
        java.beans.PropertyChangeListener propertyChangeListener55 = null;
        timePeriodValues52.addPropertyChangeListener(propertyChangeListener55);
        java.lang.Class<?> wildcardClass57 = timePeriodValues52.getClass();
        int int58 = timePeriodValues52.getMinMiddleIndex();
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        long long60 = year59.getLastMillisecond();
        timePeriodValues52.add((org.jfree.data.time.TimePeriod) year59, (java.lang.Number) (byte) 10);
        java.util.Date date63 = year59.getEnd();
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date63);
        int int65 = simpleTimePeriod48.compareTo((java.lang.Object) day64);
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day64, 1.0d);
        java.lang.Object obj68 = timePeriodValues7.clone();
        boolean boolean69 = day0.equals(obj68);
        int int70 = day0.getMonth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + (byte) 1 + "'", comparable18.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1577865599999L + "'", long35 == 1577865599999L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1577865599999L + "'", long38 == 1577865599999L);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 6 + "'", int45 == 6);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1577865599999L + "'", long60 == 1577865599999L);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(obj68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 6 + "'", int70 == 6);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("2019");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray6 = seriesException5.getSuppressed();
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray9 = seriesException8.getSuppressed();
        seriesException5.addSuppressed((java.lang.Throwable) seriesException8);
        seriesException3.addSuppressed((java.lang.Throwable) seriesException5);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.Throwable[] throwableArray13 = seriesException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
        int int15 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener16);
        timePeriodValues3.setDomainDescription("");
        int int20 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener25 = null;
        timePeriodValues24.addPropertyChangeListener(propertyChangeListener25);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timePeriodValues24.addPropertyChangeListener(propertyChangeListener27);
        java.lang.Class<?> wildcardClass29 = timePeriodValues24.getClass();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        long long31 = year30.getLastMillisecond();
        java.util.Date date32 = year30.getStart();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        long long34 = year33.getLastMillisecond();
        java.util.Date date35 = year33.getStart();
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date35, timeZone36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass29, date32, timeZone36);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date32);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
        int int41 = day40.getMonth();
        org.jfree.data.time.SerialDate serialDate42 = day40.getSerialDate();
        java.util.Date date43 = day40.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod(date32, date43);
        org.jfree.data.time.TimePeriodValues timePeriodValues48 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener49 = null;
        timePeriodValues48.addPropertyChangeListener(propertyChangeListener49);
        java.beans.PropertyChangeListener propertyChangeListener51 = null;
        timePeriodValues48.addPropertyChangeListener(propertyChangeListener51);
        java.lang.Class<?> wildcardClass53 = timePeriodValues48.getClass();
        int int54 = timePeriodValues48.getMinMiddleIndex();
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
        long long56 = year55.getLastMillisecond();
        timePeriodValues48.add((org.jfree.data.time.TimePeriod) year55, (java.lang.Number) (byte) 10);
        java.util.Date date59 = year55.getEnd();
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date59);
        int int61 = simpleTimePeriod44.compareTo((java.lang.Object) day60);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day60, 1.0d);
        java.lang.Comparable comparable64 = timePeriodValues3.getKey();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (byte) 1 + "'", comparable14.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1577865599999L + "'", long56 == 1577865599999L);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertTrue("'" + comparable64 + "' != '" + (byte) 1 + "'", comparable64.equals((byte) 1));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues6.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues6.removeChangeListener(seriesChangeListener9);
        int int11 = timePeriodValues6.getMaxEndIndex();
        boolean boolean12 = year0.equals((java.lang.Object) timePeriodValues6);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues6.createCopy(12, (int) (byte) 0);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues19.addPropertyChangeListener(propertyChangeListener20);
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues19.addPropertyChangeListener(propertyChangeListener22);
        java.lang.Class<?> wildcardClass24 = timePeriodValues19.getClass();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getLastMillisecond();
        java.util.Date date27 = year25.getStart();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        long long29 = year28.getLastMillisecond();
        java.util.Date date30 = year28.getStart();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date30, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date27, timeZone31);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date27);
        long long35 = day34.getSerialIndex();
        long long36 = day34.getLastMillisecond();
        int int37 = day34.getDayOfMonth();
        long long38 = day34.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day34.next();
        long long40 = day34.getFirstMillisecond();
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) day34, (java.lang.Number) 1.0f);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        long long44 = year43.getLastMillisecond();
        long long45 = year43.getMiddleMillisecond();
        long long46 = year43.getLastMillisecond();
        java.lang.Class<?> wildcardClass47 = year43.getClass();
        int int48 = day34.compareTo((java.lang.Object) wildcardClass47);
        int int49 = day34.getYear();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 43466L + "'", long35 == 43466L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1546415999999L + "'", long36 == 1546415999999L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 43466L + "'", long38 == 43466L);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1546329600000L + "'", long40 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1577865599999L + "'", long44 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1562097599999L + "'", long45 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1577865599999L + "'", long46 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2019 + "'", int49 == 2019);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        java.util.Date date2 = year0.getStart();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.util.Date date6 = day5.getStart();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date6, timeZone8);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date2, timeZone8);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        int int12 = year10.compareTo((java.lang.Object) day11);
//        org.jfree.data.time.SerialDate serialDate13 = day11.getSerialDate();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
//        long long16 = day14.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560409200000L + "'", long16 == 1560409200000L);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        java.util.Date date6 = year4.getStart();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        java.lang.String str10 = year8.toString();
        int int11 = year0.compareTo((java.lang.Object) year8);
        long long12 = year0.getMiddleMillisecond();
        long long13 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562097599999L + "'", long12 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date6, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date2, timeZone8);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone8);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.Object obj2 = null;
//        int int3 = day0.compareTo(obj2);
//        java.lang.String str4 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate5);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (byte) 10);
        java.util.Date date14 = year10.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        long long16 = day15.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long16, "hi!", "TimePeriodValue[2020,0]");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue21 = timePeriodValues19.getDataItem((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        try {
            timePeriodValues3.delete(9, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year();
        long long3 = year2.getLastMillisecond();
        long long4 = year2.getLastMillisecond();
        java.lang.String str5 = year2.toString();
        int int6 = day0.compareTo((java.lang.Object) str5);
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("13-June-2019");
        int int9 = day0.compareTo((java.lang.Object) seriesException8);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day0, "org.jfree.data.time.TimePeriodFormatException: 2019", "org.jfree.data.general.SeriesChangeEvent[source=0.0]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        int int14 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=0.0]");
        int int17 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year0);
        java.lang.String str5 = seriesChangeEvent4.toString();
        java.lang.String str6 = seriesChangeEvent4.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2019]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=2019]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2019]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=2019]"));
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        java.util.Date date12 = day0.getEnd();
//        long long13 = day0.getMiddleMillisecond();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getLastMillisecond();
//        java.util.Date date16 = year14.getStart();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date16, timeZone17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
//        boolean boolean20 = day0.equals((java.lang.Object) year18);
//        int int21 = year18.getYear();
//        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) int21, "org.jfree.data.time.TimePeriodFormatException: 2019", "org.jfree.data.general.SeriesException: TimePeriodValue[2019,1.0]");
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) (short) 1);
        java.lang.String str18 = timePeriodValue17.toString();
        timePeriodValues3.add(timePeriodValue17);
        int int20 = timePeriodValues3.getMaxEndIndex();
        java.lang.Class<?> wildcardClass21 = timePeriodValues3.getClass();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str18.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Time");
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        long long6 = simpleTimePeriod2.getEndMillis();
        java.util.Date date7 = simpleTimePeriod2.getStart();
        long long8 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 11L + "'", long6 == 11L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesException: TimePeriodValue[2019,1.0]");
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues11.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues11.removeChangeListener(seriesChangeListener14);
        int int16 = timePeriodValues11.getMaxEndIndex();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (double) (short) 1);
        java.lang.Object obj21 = timePeriodValue20.clone();
        timePeriodValues11.add(timePeriodValue20);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        timePeriodValues11.add((org.jfree.data.time.TimePeriod) year23, (double) 100.0f);
        java.lang.Object obj26 = null;
        boolean boolean27 = year23.equals(obj26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year23.previous();
        timePeriodValues3.setKey((java.lang.Comparable) regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues8.addPropertyChangeListener(propertyChangeListener9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues8.addPropertyChangeListener(propertyChangeListener11);
        java.lang.Class<?> wildcardClass13 = timePeriodValues8.getClass();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        java.util.Date date16 = year14.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        java.util.Date date19 = year17.getStart();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date16, timeZone20);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date4, timeZone20);
        org.jfree.data.general.SeriesException seriesException25 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray26 = seriesException25.getSuppressed();
        org.jfree.data.general.SeriesException seriesException28 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray29 = seriesException28.getSuppressed();
        seriesException25.addSuppressed((java.lang.Throwable) seriesException28);
        org.jfree.data.general.SeriesException seriesException32 = new org.jfree.data.general.SeriesException("");
        seriesException25.addSuppressed((java.lang.Throwable) seriesException32);
        boolean boolean34 = day23.equals((java.lang.Object) seriesException25);
        org.jfree.data.time.TimePeriodValue timePeriodValue36 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day23, (java.lang.Number) (short) 0);
        java.lang.String str37 = day23.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "31-December-1969" + "'", str37.equals("31-December-1969"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: 2019");
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(5, 7, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) (short) 1);
        java.lang.String str18 = timePeriodValue17.toString();
        timePeriodValues3.add(timePeriodValue17);
        java.lang.Object obj20 = timePeriodValue17.clone();
        java.lang.Object obj21 = timePeriodValue17.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = timePeriodValues25.createCopy(0, (int) (short) 100);
        timePeriodValues28.setNotify(false);
        int int31 = timePeriodValues28.getMinStartIndex();
        timePeriodValues28.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: 2019");
        timePeriodValues28.setDescription("hi!");
        boolean boolean36 = timePeriodValue17.equals((java.lang.Object) timePeriodValues28);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        long long38 = year37.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year37.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year37.previous();
        long long41 = year37.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year37.previous();
        long long43 = year37.getLastMillisecond();
        timePeriodValues28.setKey((java.lang.Comparable) year37);
        long long45 = year37.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year37.next();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str18.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(timePeriodValues28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1577865599999L + "'", long38 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1562097599999L + "'", long41 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1577865599999L + "'", long43 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1546329600000L + "'", long45 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        long long4 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        int int6 = year0.getYear();
        long long7 = year0.getLastMillisecond();
        long long8 = year0.getSerialIndex();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year0.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getLastMillisecond();
//        java.util.Date date2 = year0.getStart();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        java.lang.String str4 = day3.toString();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener10 = null;
//        timePeriodValues9.addPropertyChangeListener(propertyChangeListener10);
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timePeriodValues9.addPropertyChangeListener(propertyChangeListener12);
//        java.lang.Class<?> wildcardClass14 = timePeriodValues9.getClass();
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
//        boolean boolean16 = day5.equals((java.lang.Object) wildcardClass14);
//        java.util.Date date17 = day5.getEnd();
//        long long18 = day5.getMiddleMillisecond();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
//        long long20 = year19.getLastMillisecond();
//        java.util.Date date21 = year19.getStart();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21, timeZone22);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.next();
//        boolean boolean25 = day5.equals((java.lang.Object) year23);
//        boolean boolean26 = day3.equals((java.lang.Object) day5);
//        java.util.Calendar calendar27 = null;
//        try {
//            day5.peg(calendar27);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1-January-2019" + "'", str4.equals("1-January-2019"));
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560452399999L + "'", long18 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod5, 0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize(class12);
        java.util.Date date14 = null;
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        int int16 = day15.getMonth();
        org.jfree.data.time.SerialDate serialDate17 = day15.getSerialDate();
        java.util.Date date18 = day15.getEnd();
        java.lang.Class<?> wildcardClass19 = date18.getClass();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getLastMillisecond();
        java.util.Date date22 = year20.getStart();
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date22, timeZone23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.util.Date date26 = day25.getStart();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date26, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date22, timeZone28);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date18, timeZone28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date14, timeZone28);
        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize(class12);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(class33);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getLastMillisecond();
        java.lang.String str5 = year0.toString();
        long long6 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1577865599999L + "'", long4 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        long long19 = day18.getSerialIndex();
        long long20 = day18.getLastMillisecond();
        int int21 = day18.getDayOfMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day18);
        try {
            java.lang.Number number24 = timePeriodValues22.getValue((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43466L + "'", long19 == 43466L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546415999999L + "'", long20 == 1546415999999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        java.lang.Comparable comparable5 = timePeriodValues3.getKey();
        java.lang.String str6 = timePeriodValues3.getRangeDescription();
        int int7 = timePeriodValues3.getMaxEndIndex();
        boolean boolean8 = timePeriodValues3.isEmpty();
        int int9 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (byte) 1 + "'", comparable5.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        java.util.Date date22 = day19.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date11, date22);
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date11);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        long long28 = simpleTimePeriod27.getStartMillis();
        java.util.Date date29 = simpleTimePeriod27.getEnd();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        java.util.Date date31 = day30.getStart();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date31, timeZone33);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date29, timeZone33);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date11, timeZone33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year36.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue39 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod37, (double) 6);
        java.lang.Object obj40 = timePeriodValue39.clone();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-1L) + "'", long28 == (-1L));
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(obj40);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        java.lang.Class class9 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        java.util.Date date10 = null;
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timePeriodValues14.addPropertyChangeListener(propertyChangeListener17);
        java.lang.Class<?> wildcardClass19 = timePeriodValues14.getClass();
        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        java.util.Date date22 = day21.getStart();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getLastMillisecond();
        java.util.Date date25 = year23.getStart();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date25, timeZone26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        java.util.Date date29 = day28.getStart();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date29, timeZone31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date25, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass19, date22, timeZone31);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        long long36 = year35.getLastMillisecond();
        java.util.Date date37 = year35.getStart();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        long long40 = year39.getLastMillisecond();
        java.util.Date date41 = year39.getStart();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        long long44 = year43.getLastMillisecond();
        java.util.Date date45 = year43.getStart();
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date45, timeZone46);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date41, timeZone46);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date37, timeZone46);
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date22, timeZone46);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone46);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1577865599999L + "'", long36 == 1577865599999L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1577865599999L + "'", long44 == 1577865599999L);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNull(regularTimePeriod51);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener7);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener9);
        java.lang.Class<?> wildcardClass11 = timePeriodValues6.getClass();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        java.util.Date date17 = year15.getStart();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date14, timeZone18);
        int int21 = year0.compareTo((java.lang.Object) wildcardClass11);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        java.util.Date date23 = day22.getStart();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23, timeZone25);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timePeriodValues30.addPropertyChangeListener(propertyChangeListener31);
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timePeriodValues30.addPropertyChangeListener(propertyChangeListener33);
        java.lang.Class<?> wildcardClass35 = timePeriodValues30.getClass();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        long long37 = year36.getLastMillisecond();
        java.util.Date date38 = year36.getStart();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        long long40 = year39.getLastMillisecond();
        java.util.Date date41 = year39.getStart();
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date41, timeZone42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date38, timeZone42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date23, timeZone42);
        java.lang.Class class46 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        java.lang.Class class47 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1577865599999L + "'", long37 == 1577865599999L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(class46);
        org.junit.Assert.assertNotNull(class47);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        java.util.Date date22 = day19.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date11, date22);
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date11);
        boolean boolean25 = timePeriodValues24.getNotify();
        timePeriodValues24.setDescription("1-January-2019");
        java.lang.Comparable comparable28 = timePeriodValues24.getKey();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(comparable28);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy(0, (int) (short) 100);
        timePeriodValues6.setNotify(false);
        int int9 = timePeriodValues6.getMinStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues6.createCopy(12, 3);
        try {
            org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValues12.getTimePeriod(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues12);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        java.util.Date date11 = year9.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        int int20 = day19.getMonth();
        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
        java.util.Date date22 = day19.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date11, date22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getLastMillisecond();
        java.util.Date date26 = year24.getStart();
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date26, timeZone27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        java.util.Date date30 = day29.getStart();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date30, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date26, timeZone32);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        int int36 = year34.compareTo((java.lang.Object) day35);
        int int37 = simpleTimePeriod23.compareTo((java.lang.Object) year34);
        java.util.Date date38 = year34.getEnd();
        java.util.Calendar calendar39 = null;
        try {
            long long40 = year34.getFirstMillisecond(calendar39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(date38);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        java.lang.String str5 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
        long long7 = year4.getSerialIndex();
        long long8 = year4.getLastMillisecond();
        long long9 = year4.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        java.lang.String str6 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.previous();
        long long8 = year4.getSerialIndex();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year4.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getMonth();
//        java.lang.Object obj2 = null;
//        int int3 = day0.compareTo(obj2);
//        java.lang.String str4 = day0.toString();
//        java.lang.String str5 = day0.toString();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-June-2019" + "'", str4.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-June-2019" + "'", str5.equals("13-June-2019"));
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setDomainDescription("TimePeriodValue[2019,1.0]");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        java.util.Date date12 = year10.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues16.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timePeriodValues16.removeChangeListener(seriesChangeListener19);
        int int21 = timePeriodValues16.getMaxEndIndex();
        boolean boolean22 = year10.equals((java.lang.Object) timePeriodValues16);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 0.0d);
        boolean boolean25 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("TimePeriodValue[2019,1.0]");
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        timePeriodValues13.setRangeDescription("2019");
        timePeriodValues13.setRangeDescription("");
        java.lang.String str18 = timePeriodValues13.getDescription();
        timePeriodValues13.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timePeriodValues13.removeChangeListener(seriesChangeListener21);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        long long26 = simpleTimePeriod25.getStartMillis();
        java.util.Date date27 = simpleTimePeriod25.getEnd();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        java.util.Date date29 = day28.getStart();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date29, timeZone31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date27, timeZone31);
        org.jfree.data.time.SerialDate serialDate34 = day33.getSerialDate();
        boolean boolean35 = timePeriodValues13.equals((java.lang.Object) serialDate34);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1L) + "'", long26 == (-1L));
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues8.addPropertyChangeListener(propertyChangeListener9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues8.addPropertyChangeListener(propertyChangeListener11);
        java.lang.Class<?> wildcardClass13 = timePeriodValues8.getClass();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        java.util.Date date16 = year14.getStart();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getLastMillisecond();
        java.util.Date date19 = year17.getStart();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date16, timeZone20);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date4, timeZone20);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent24 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod22);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (short) 1);
        java.lang.Object obj13 = timePeriodValue12.clone();
        timePeriodValues3.add(timePeriodValue12);
        timePeriodValues3.setDescription("2019");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue18 = timePeriodValues3.getDataItem((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMinEndIndex();
        java.lang.Comparable comparable9 = timePeriodValues3.getKey();
        java.lang.String str10 = timePeriodValues3.getDescription();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 1 + "'", comparable9.equals((byte) 1));
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize(class12);
        java.util.Date date14 = null;
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date14, timeZone15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        long long20 = simpleTimePeriod19.getStartMillis();
        java.util.Date date21 = simpleTimePeriod19.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timePeriodValues25.addPropertyChangeListener(propertyChangeListener26);
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues25.addPropertyChangeListener(propertyChangeListener28);
        java.lang.Class<?> wildcardClass30 = timePeriodValues25.getClass();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getLastMillisecond();
        java.util.Date date33 = year31.getStart();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getLastMillisecond();
        java.util.Date date36 = year34.getStart();
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date36, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass30, date33, timeZone37);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date33);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
        int int42 = day41.getMonth();
        org.jfree.data.time.SerialDate serialDate43 = day41.getSerialDate();
        java.util.Date date44 = day41.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod(date33, date44);
        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date33);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        long long50 = simpleTimePeriod49.getStartMillis();
        java.util.Date date51 = simpleTimePeriod49.getEnd();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
        java.util.Date date53 = day52.getStart();
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date53);
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date53, timeZone55);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date51, timeZone55);
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date33, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date21, timeZone55);
        org.jfree.data.time.TimePeriodValues timePeriodValues60 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date21);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1577865599999L + "'", long35 == 1577865599999L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-1L) + "'", long50 == (-1L));
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        long long4 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        java.lang.String str6 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year9, (double) (short) 1);
        java.lang.Object obj13 = timePeriodValue12.clone();
        timePeriodValues3.add(timePeriodValue12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year15, (double) 100.0f);
        java.lang.Object obj18 = null;
        boolean boolean19 = year15.equals(obj18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year15.next();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.lang.String str4 = timePeriodValues3.getDescription();
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener5);
//        boolean boolean7 = timePeriodValues3.getNotify();
//        timePeriodValues3.setDescription("org.jfree.data.general.SeriesException: 2019");
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timePeriodValues14.addPropertyChangeListener(propertyChangeListener15);
//        java.beans.PropertyChangeListener propertyChangeListener17 = null;
//        timePeriodValues14.addPropertyChangeListener(propertyChangeListener17);
//        java.lang.Class<?> wildcardClass19 = timePeriodValues14.getClass();
//        java.lang.Class class20 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass19);
//        boolean boolean21 = day10.equals((java.lang.Object) wildcardClass19);
//        java.util.Date date22 = day10.getEnd();
//        long long23 = day10.getMiddleMillisecond();
//        int int24 = day10.getYear();
//        int int25 = day10.getDayOfMonth();
//        boolean boolean26 = timePeriodValues3.equals((java.lang.Object) int25);
//        int int27 = timePeriodValues3.getMinStartIndex();
//        java.beans.PropertyChangeListener propertyChangeListener28 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener28);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertNotNull(class20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560452399999L + "'", long23 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 13 + "'", int25 == 13);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        timePeriodValues3.setDescription("");
        int int10 = timePeriodValues3.getItemCount();
        java.lang.String str11 = timePeriodValues3.getDescription();
        timePeriodValues3.setDescription("2019");
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues17.addPropertyChangeListener(propertyChangeListener18);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues17.addPropertyChangeListener(propertyChangeListener20);
        java.lang.Class<?> wildcardClass22 = timePeriodValues17.getClass();
        int int23 = timePeriodValues17.getMinMiddleIndex();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getLastMillisecond();
        timePeriodValues17.add((org.jfree.data.time.TimePeriod) year24, (java.lang.Number) (byte) 10);
        java.util.Date date28 = year24.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.lang.String str34 = timePeriodValues33.getDescription();
        java.lang.Comparable comparable35 = timePeriodValues33.getKey();
        java.lang.String str36 = timePeriodValues33.getRangeDescription();
        int int37 = day29.compareTo((java.lang.Object) str36);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day29, (double) 1560409200000L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + comparable35 + "' != '" + (byte) 1 + "'", comparable35.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        java.lang.Comparable comparable14 = timePeriodValues3.getKey();
        int int15 = timePeriodValues3.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener16);
        int int18 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getLastMillisecond();
        java.util.Date date21 = year19.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21, timeZone22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        java.util.Date date25 = day24.getStart();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date25, timeZone27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date21, timeZone27);
        timePeriodValues3.setKey((java.lang.Comparable) date21);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + (byte) 1 + "'", comparable14.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577865599999L + "'", long20 == 1577865599999L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone27);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        timePeriodValues3.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener10);
        timePeriodValues3.setRangeDescription("");
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        java.util.Date date12 = day0.getEnd();
//        long long13 = day0.getMiddleMillisecond();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getLastMillisecond();
//        java.util.Date date16 = year14.getStart();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date16, timeZone17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
//        boolean boolean20 = day0.equals((java.lang.Object) year18);
//        boolean boolean22 = day0.equals((java.lang.Object) 2019L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day0.next();
//        long long24 = regularTimePeriod23.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560538799999L + "'", long24 == 1560538799999L);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1L));
        java.lang.Class<?> wildcardClass2 = timePeriodValues1.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues10.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues10.removeChangeListener(seriesChangeListener13);
        int int15 = timePeriodValues10.getMaxEndIndex();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year16, (double) (short) 1);
        java.lang.Object obj20 = timePeriodValue19.clone();
        timePeriodValues10.add(timePeriodValue19);
        java.lang.String str22 = timePeriodValue19.toString();
        timePeriodValues6.add(timePeriodValue19);
        java.lang.Object obj24 = timePeriodValue19.clone();
        timePeriodValues1.add(timePeriodValue19);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str22.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod16, (java.lang.Number) 0);
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = timePeriodValues3.getDataItem((int) (short) 0);
        int int21 = timePeriodValues3.getMaxEndIndex();
        int int22 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(timePeriodValue20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener5);
        int int7 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        java.util.Date date12 = day0.getEnd();
//        long long13 = day0.getMiddleMillisecond();
//        int int14 = day0.getYear();
//        long long15 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day0, (java.lang.Number) 13);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560409200000L + "'", long15 == 1560409200000L);
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
//        long long3 = simpleTimePeriod2.getStartMillis();
//        java.util.Date date4 = simpleTimePeriod2.getEnd();
//        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener9 = null;
//        timePeriodValues8.addPropertyChangeListener(propertyChangeListener9);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timePeriodValues8.addPropertyChangeListener(propertyChangeListener11);
//        java.lang.Class<?> wildcardClass13 = timePeriodValues8.getClass();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
//        long long15 = year14.getLastMillisecond();
//        java.util.Date date16 = year14.getStart();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
//        long long18 = year17.getLastMillisecond();
//        java.util.Date date19 = year17.getStart();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19, timeZone20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date16, timeZone20);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date4, timeZone20);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.util.Date date25 = day24.getStart();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date25, timeZone27);
//        int int29 = day28.getDayOfMonth();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        java.util.Date date31 = day30.getStart();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
//        boolean boolean33 = day28.equals((java.lang.Object) day32);
//        java.util.Date date34 = day28.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod(date4, date34);
//        long long36 = simpleTimePeriod35.getEndMillis();
//        java.util.Date date37 = simpleTimePeriod35.getStart();
//        long long38 = simpleTimePeriod35.getStartMillis();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 13 + "'", int29 == 13);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560495599999L + "'", long36 == 1560495599999L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 11L + "'", long38 == 11L);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("2019");
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray9 = seriesException8.getSuppressed();
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray12 = seriesException11.getSuppressed();
        seriesException8.addSuppressed((java.lang.Throwable) seriesException11);
        seriesException6.addSuppressed((java.lang.Throwable) seriesException8);
        boolean boolean15 = simpleTimePeriod2.equals((java.lang.Object) seriesException8);
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 0.0d);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        long long3 = year0.getSerialIndex();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        java.util.Date date6 = year4.getStart();
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date6, timeZone7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        java.lang.String str10 = year8.toString();
        int int11 = year0.compareTo((java.lang.Object) year8);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues15.addPropertyChangeListener(propertyChangeListener16);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.addPropertyChangeListener(propertyChangeListener18);
        java.lang.Class<?> wildcardClass20 = timePeriodValues15.getClass();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getLastMillisecond();
        java.lang.Number number23 = null;
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) year21, number23);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timePeriodValues15.removeChangeListener(seriesChangeListener25);
        int int27 = timePeriodValues15.getMinStartIndex();
        int int28 = year8.compareTo((java.lang.Object) timePeriodValues15);
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = timePeriodValues15.createCopy(3, (int) (short) -1);
        java.lang.Object obj32 = timePeriodValues31.clone();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues31);
        org.junit.Assert.assertNotNull(obj32);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy(0, (int) (short) 100);
        timePeriodValues6.fireSeriesChanged();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getLastMillisecond();
        java.util.Date date10 = year8.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date10, timeZone11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
        long long14 = year12.getLastMillisecond();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        long long17 = year15.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener22);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timePeriodValues21.addPropertyChangeListener(propertyChangeListener24);
        java.lang.Class<?> wildcardClass26 = timePeriodValues21.getClass();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getLastMillisecond();
        java.util.Date date29 = year27.getStart();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        long long31 = year30.getLastMillisecond();
        java.util.Date date32 = year30.getStart();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date32, timeZone33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date29, timeZone33);
        int int36 = year15.compareTo((java.lang.Object) wildcardClass26);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
        java.util.Date date38 = day37.getStart();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        java.util.TimeZone timeZone40 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date38, timeZone40);
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timePeriodValues45.addPropertyChangeListener(propertyChangeListener46);
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timePeriodValues45.addPropertyChangeListener(propertyChangeListener48);
        java.lang.Class<?> wildcardClass50 = timePeriodValues45.getClass();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
        long long52 = year51.getLastMillisecond();
        java.util.Date date53 = year51.getStart();
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        long long55 = year54.getLastMillisecond();
        java.util.Date date56 = year54.getStart();
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date56, timeZone57);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass50, date53, timeZone57);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass26, date38, timeZone57);
        int int61 = year12.compareTo((java.lang.Object) date38);
        org.jfree.data.time.TimePeriodValue timePeriodValue63 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year12, (java.lang.Number) 4);
        timePeriodValues6.add(timePeriodValue63);
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1562097599999L + "'", long17 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1577865599999L + "'", long52 == 1577865599999L);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1577865599999L + "'", long55 == 1577865599999L);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNull(regularTimePeriod59);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getLastMillisecond();
        int int3 = year0.getYear();
        long long4 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues3.setNotify(false);
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setDomainDescription("TimePeriodValue[2019,1.0]");
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        java.util.Date date12 = year10.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues16.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timePeriodValues16.removeChangeListener(seriesChangeListener19);
        int int21 = timePeriodValues16.getMaxEndIndex();
        boolean boolean22 = year10.equals((java.lang.Object) timePeriodValues16);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) 0.0d);
        boolean boolean25 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener26);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy(0, (int) (short) 100);
        timePeriodValues6.setNotify(false);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues12.addPropertyChangeListener(propertyChangeListener13);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timePeriodValues12.addPropertyChangeListener(propertyChangeListener15);
        java.lang.Class<?> wildcardClass17 = timePeriodValues12.getClass();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getLastMillisecond();
        java.util.Date date20 = year18.getStart();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getLastMillisecond();
        java.util.Date date23 = year21.getStart();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23, timeZone24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date20, timeZone24);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        int int29 = day28.getMonth();
        org.jfree.data.time.SerialDate serialDate30 = day28.getSerialDate();
        java.util.Date date31 = day28.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date20, date31);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date31, "2019", "org.jfree.data.general.SeriesException: 2019");
        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener40 = null;
        timePeriodValues39.addPropertyChangeListener(propertyChangeListener40);
        java.beans.PropertyChangeListener propertyChangeListener42 = null;
        timePeriodValues39.addPropertyChangeListener(propertyChangeListener42);
        java.lang.Class<?> wildcardClass44 = timePeriodValues39.getClass();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        long long46 = year45.getLastMillisecond();
        java.lang.Number number47 = null;
        timePeriodValues39.add((org.jfree.data.time.TimePeriod) year45, number47);
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener53 = null;
        timePeriodValues52.addPropertyChangeListener(propertyChangeListener53);
        java.beans.PropertyChangeListener propertyChangeListener55 = null;
        timePeriodValues52.addPropertyChangeListener(propertyChangeListener55);
        java.lang.Class<?> wildcardClass57 = timePeriodValues52.getClass();
        int int58 = timePeriodValues52.getMinMiddleIndex();
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year();
        long long60 = year59.getLastMillisecond();
        timePeriodValues52.add((org.jfree.data.time.TimePeriod) year59, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        long long64 = year63.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue66 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year63, (double) (short) 1);
        java.lang.String str67 = timePeriodValue66.toString();
        timePeriodValues52.add(timePeriodValue66);
        java.lang.String str69 = timePeriodValue66.toString();
        timePeriodValues39.add(timePeriodValue66);
        timePeriodValues35.add(timePeriodValue66);
        timePeriodValues6.add(timePeriodValue66);
        org.jfree.data.time.TimePeriodValues timePeriodValues76 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener77 = null;
        timePeriodValues76.addPropertyChangeListener(propertyChangeListener77);
        boolean boolean79 = timePeriodValues76.isEmpty();
        timePeriodValues76.setRangeDescription("");
        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year();
        long long83 = year82.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = year82.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = year82.next();
        timePeriodValues76.add((org.jfree.data.time.TimePeriod) regularTimePeriod85, (double) 0);
        boolean boolean88 = timePeriodValue66.equals((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1577865599999L + "'", long46 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1577865599999L + "'", long60 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1577865599999L + "'", long64 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str67.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str69.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 1577865599999L + "'", long83 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod84);
        org.junit.Assert.assertNotNull(regularTimePeriod85);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
        timePeriodValues13.setRangeDescription("2019");
        timePeriodValues13.setRangeDescription("");
        java.lang.String str18 = timePeriodValues13.getDescription();
        timePeriodValues13.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timePeriodValues13.removeChangeListener(seriesChangeListener21);
        java.lang.Comparable comparable23 = timePeriodValues13.getKey();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues13);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + (byte) 1 + "'", comparable23.equals((byte) 1));
    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test164");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        long long12 = day0.getLastMillisecond();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getMonth();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
//        long long16 = year15.getLastMillisecond();
//        long long17 = year15.getLastMillisecond();
//        java.lang.String str18 = year15.toString();
//        int int19 = day13.compareTo((java.lang.Object) str18);
//        long long20 = day13.getSerialIndex();
//        boolean boolean21 = day0.equals((java.lang.Object) long20);
//        long long22 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560495599999L + "'", long12 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019" + "'", str18.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 43629L + "'", long20 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560495599999L + "'", long22 == 1560495599999L);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) serialDate2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
        java.util.Calendar calendar3 = null;
        try {
            day0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(serialDate2);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
//        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
//        long long10 = year9.getLastMillisecond();
//        java.util.Date date11 = year9.getStart();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
//        long long13 = year12.getLastMillisecond();
//        java.util.Date date14 = year12.getStart();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date11, timeZone15);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date11);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        int int20 = day19.getMonth();
//        org.jfree.data.time.SerialDate serialDate21 = day19.getSerialDate();
//        java.util.Date date22 = day19.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date11, date22);
//        org.jfree.data.time.TimePeriodValues timePeriodValues27 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener28 = null;
//        timePeriodValues27.addPropertyChangeListener(propertyChangeListener28);
//        java.beans.PropertyChangeListener propertyChangeListener30 = null;
//        timePeriodValues27.addPropertyChangeListener(propertyChangeListener30);
//        java.lang.Class<?> wildcardClass32 = timePeriodValues27.getClass();
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
//        long long34 = year33.getLastMillisecond();
//        java.util.Date date35 = year33.getStart();
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
//        long long37 = year36.getLastMillisecond();
//        java.util.Date date38 = year36.getStart();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date38, timeZone39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date35, timeZone39);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date35);
//        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener47 = null;
//        timePeriodValues46.addPropertyChangeListener(propertyChangeListener47);
//        java.beans.PropertyChangeListener propertyChangeListener49 = null;
//        timePeriodValues46.addPropertyChangeListener(propertyChangeListener49);
//        java.lang.Class<?> wildcardClass51 = timePeriodValues46.getClass();
//        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
//        long long53 = year52.getLastMillisecond();
//        java.util.Date date54 = year52.getStart();
//        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year();
//        long long56 = year55.getLastMillisecond();
//        java.util.Date date57 = year55.getStart();
//        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date57, timeZone58);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date54, timeZone58);
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date54);
//        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
//        int int63 = day62.getMonth();
//        org.jfree.data.time.SerialDate serialDate64 = day62.getSerialDate();
//        java.util.Date date65 = day62.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod66 = new org.jfree.data.time.SimpleTimePeriod(date54, date65);
//        org.jfree.data.time.TimePeriodValues timePeriodValues67 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date54);
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod70 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
//        long long71 = simpleTimePeriod70.getStartMillis();
//        java.util.Date date72 = simpleTimePeriod70.getEnd();
//        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day();
//        java.util.Date date74 = day73.getStart();
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day(date74);
//        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day(date74, timeZone76);
//        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day(date72, timeZone76);
//        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year(date54, timeZone76);
//        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year(date35, timeZone76);
//        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day(date22, timeZone76);
//        java.lang.String str82 = day81.toString();
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1577865599999L + "'", long34 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1577865599999L + "'", long37 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNull(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(wildcardClass51);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1577865599999L + "'", long53 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1577865599999L + "'", long56 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(timeZone58);
//        org.junit.Assert.assertNull(regularTimePeriod60);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 6 + "'", int63 == 6);
//        org.junit.Assert.assertNotNull(serialDate64);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-1L) + "'", long71 == (-1L));
//        org.junit.Assert.assertNotNull(date72);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertNotNull(timeZone76);
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "13-June-2019" + "'", str82.equals("13-June-2019"));
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timePeriodValues3.isEmpty();
        timePeriodValues3.setRangeDescription("");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year9.next();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) regularTimePeriod12, (double) 0);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        int int16 = day15.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day15, (java.lang.Number) 2019);
        timePeriodValues3.add(timePeriodValue18);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date1, timeZone3);
//        int int5 = day4.getDayOfMonth();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getStart();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date7);
//        boolean boolean9 = day4.equals((java.lang.Object) day8);
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate10);
//        int int12 = day11.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day11.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day11.next();
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = day11.getMiddleMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getLastMillisecond();
        java.util.Date date6 = year4.getStart();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getLastMillisecond();
        java.util.Date date10 = year8.getStart();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date10, timeZone11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date6, timeZone11);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date2, timeZone11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        timePeriodValues3.setDescription("");
        boolean boolean10 = timePeriodValues3.getNotify();
        java.lang.String str11 = timePeriodValues3.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener12);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (short) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener10);
        java.lang.Class<?> wildcardClass12 = timePeriodValues7.getClass();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        java.lang.Number number15 = null;
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) year13, number15);
        boolean boolean17 = timePeriodValue3.equals((java.lang.Object) number15);
        java.lang.Object obj18 = timePeriodValue3.clone();
        org.jfree.data.time.TimePeriod timePeriod19 = timePeriodValue3.getPeriod();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(timePeriod19);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) -1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues7.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues7.removeChangeListener(seriesChangeListener10);
        int int12 = timePeriodValues7.getMaxEndIndex();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (double) (short) 1);
        java.lang.Object obj17 = timePeriodValue16.clone();
        timePeriodValues7.add(timePeriodValue16);
        java.lang.String str19 = timePeriodValue16.toString();
        timePeriodValues3.add(timePeriodValue16);
        int int21 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str19.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.lang.String str3 = year0.toString();
        long long4 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str2.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 100, "TimePeriodValue[2019,1.0]", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues7.addPropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues7.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues7.removeChangeListener(seriesChangeListener13);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues7.createCopy((int) (short) -1, (-1));
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.next();
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) regularTimePeriod20, (java.lang.Number) 0);
        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) timePeriodValues7);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        long long25 = year24.getLastMillisecond();
        java.util.Date date26 = year24.getStart();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getLastMillisecond();
        java.util.Date date29 = year27.getStart();
        boolean boolean30 = year24.equals((java.lang.Object) year27);
        java.lang.Number number31 = null;
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year24, number31);
        int int33 = year24.getYear();
        java.lang.String str34 = year24.toString();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2019" + "'", str34.equals("2019"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) -1, (long) 11);
        long long3 = simpleTimePeriod2.getStartMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        long long6 = simpleTimePeriod2.getStartMillis();
        long long7 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 11L + "'", long7 == 11L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) (short) 1);
        java.lang.String str4 = timePeriodValue3.toString();
        timePeriodValue3.setValue((java.lang.Number) 9);
        java.lang.String str7 = timePeriodValue3.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str4.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TimePeriodValue[2019,9]" + "'", str7.equals("TimePeriodValue[2019,9]"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        long long4 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.previous();
        long long6 = regularTimePeriod5.getMiddleMillisecond();
        java.util.Date date7 = regularTimePeriod5.getStart();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1562097599999L + "'", long4 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1530561599999L + "'", long6 == 1530561599999L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1530561599999L + "'", long10 == 1530561599999L);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
//        java.beans.PropertyChangeListener propertyChangeListener6 = null;
//        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
//        int int8 = timePeriodValues3.getMaxStartIndex();
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
//        timePeriodValues3.removeChangeListener(seriesChangeListener9);
//        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy((int) (short) -1, (-1));
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getStart();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date15, timeZone17);
//        int int19 = day18.getDayOfMonth();
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getStart();
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
//        boolean boolean23 = day18.equals((java.lang.Object) day22);
//        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day22, (double) 10);
//        timePeriodValues3.setRangeDescription("1-January-2019");
//        java.lang.Comparable comparable28 = timePeriodValues3.getKey();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(timePeriodValues13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 13 + "'", int19 == 13);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + (byte) 1 + "'", comparable28.equals((byte) 1));
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("2019");
        java.lang.Throwable[] throwableArray5 = seriesException4.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.String str7 = seriesException1.toString();
        java.lang.Throwable[] throwableArray8 = seriesException1.getSuppressed();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        int int10 = day9.getMonth();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        long long13 = year11.getLastMillisecond();
        java.lang.String str14 = year11.toString();
        int int15 = day9.compareTo((java.lang.Object) str14);
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("13-June-2019");
        int int18 = day9.compareTo((java.lang.Object) seriesException17);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException17);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesException: 2019" + "'", str7.equals("org.jfree.data.general.SeriesException: 2019"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener7);
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener9);
        java.lang.Class<?> wildcardClass11 = timePeriodValues6.getClass();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getLastMillisecond();
        java.util.Date date14 = year12.getStart();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getLastMillisecond();
        java.util.Date date17 = year15.getStart();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date17, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date14, timeZone18);
        int int21 = year0.compareTo((java.lang.Object) wildcardClass11);
        java.util.Calendar calendar22 = null;
        try {
            long long23 = year0.getFirstMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1577865599999L + "'", long16 == 1577865599999L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy(0, (int) (short) 100);
        timePeriodValues6.setNotify(false);
        int int9 = timePeriodValues6.getMinStartIndex();
        int int10 = timePeriodValues6.getItemCount();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year11.previous();
        long long15 = year11.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year11.previous();
        long long17 = regularTimePeriod16.getMiddleMillisecond();
        java.util.Date date18 = regularTimePeriod16.getStart();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        java.util.Date date20 = year19.getStart();
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) year19, (double) (byte) 10);
        timePeriodValues6.setNotify(false);
        int int25 = timePeriodValues6.getMaxStartIndex();
        timePeriodValues6.setDescription("TimePeriodValue[2019,1.0]");
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1562097599999L + "'", long15 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1530561599999L + "'", long17 == 1530561599999L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Date date2 = year0.getStart();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2, timeZone3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        java.lang.String str6 = year4.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.previous();
        long long8 = year4.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year4.previous();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, (double) (short) 1);
        java.lang.String str14 = timePeriodValue13.toString();
        timePeriodValue13.setValue((java.lang.Number) 9);
        int int17 = year4.compareTo((java.lang.Object) timePeriodValue13);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2019" + "'", str6.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str14.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.lang.String str4 = timePeriodValues3.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener5);
        int int7 = timePeriodValues3.getItemCount();
        int int8 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener11);
        java.lang.Comparable comparable13 = timePeriodValues3.getKey();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + comparable13 + "' != '" + (byte) 1 + "'", comparable13.equals((byte) 1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy(0, (int) (short) 100);
        timePeriodValues6.setNotify(false);
        java.lang.Comparable comparable9 = timePeriodValues6.getKey();
        int int10 = timePeriodValues6.getMaxStartIndex();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + (byte) 1 + "'", comparable9.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        long long2 = year0.getMiddleMillisecond();
        long long3 = year0.getLastMillisecond();
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year0);
        long long6 = year0.getLastMillisecond();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) long6);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1562097599999L + "'", long2 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timePeriodValues3.isEmpty();
        timePeriodValues3.fireSeriesChanged();
        try {
            timePeriodValues3.update((int) (byte) 1, (java.lang.Number) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (byte) 10);
        java.lang.String str14 = timePeriodValues3.getDomainDescription();
        java.lang.Object obj15 = timePeriodValues3.clone();
        int int16 = timePeriodValues3.getMinMiddleIndex();
        try {
            java.lang.Number number18 = timePeriodValues3.getValue(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues3.getClass();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getLastMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year10, (java.lang.Number) (byte) 10);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (double) (short) 1);
        java.lang.String str18 = timePeriodValue17.toString();
        timePeriodValues3.add(timePeriodValue17);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.next();
        boolean boolean23 = timePeriodValues3.equals((java.lang.Object) regularTimePeriod22);
        boolean boolean24 = timePeriodValues3.getNotify();
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "TimePeriodValue[2019,1.0]" + "'", str18.equals("TimePeriodValue[2019,1.0]"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 0);
        long long3 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
        timePeriodValues7.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues7.removeChangeListener(seriesChangeListener10);
        int int12 = timePeriodValues7.getMaxEndIndex();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (double) (short) 1);
        java.lang.Object obj17 = timePeriodValue16.clone();
        timePeriodValues7.add(timePeriodValue16);
        java.lang.Object obj19 = timePeriodValue16.clone();
        timePeriodValue16.setValue((java.lang.Number) (-1.0d));
        timePeriodValue16.setValue((java.lang.Number) 0);
        try {
            int int24 = simpleTimePeriod2.compareTo((java.lang.Object) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(obj19);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (byte) 1, "", "");
//        java.beans.PropertyChangeListener propertyChangeListener5 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener5);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timePeriodValues4.addPropertyChangeListener(propertyChangeListener7);
//        java.lang.Class<?> wildcardClass9 = timePeriodValues4.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        boolean boolean11 = day0.equals((java.lang.Object) wildcardClass9);
//        java.util.Date date12 = day0.getEnd();
//        long long13 = day0.getMiddleMillisecond();
//        int int14 = day0.getYear();
//        int int15 = day0.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day0.previous();
//        long long17 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate18 = day0.getSerialDate();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        int int20 = day19.getMonth();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
//        long long22 = year21.getLastMillisecond();
//        long long23 = year21.getLastMillisecond();
//        java.lang.String str24 = year21.toString();
//        int int25 = day19.compareTo((java.lang.Object) str24);
//        long long26 = day19.getSerialIndex();
//        int int27 = day0.compareTo((java.lang.Object) day19);
//        java.lang.String str28 = day0.toString();
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560452399999L + "'", long13 == 1560452399999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560409200000L + "'", long17 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2019" + "'", str24.equals("2019"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 43629L + "'", long26 == 43629L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13-June-2019" + "'", str28.equals("13-June-2019"));
//    }
//}

