import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paintArray0, jFreeChart1, chartChangeEventType2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        chartChangeEvent3.setType(chartChangeEventType4);
        java.lang.String str6 = chartChangeEventType4.toString();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str6.equals("ChartChangeEventType.NEW_DATASET"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition4, true);
        java.awt.Stroke stroke8 = statisticalBarRenderer0.lookupSeriesStroke(0);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color5 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("ThreadContext", font4, (java.awt.Paint) color5);
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font4);
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color10 = java.awt.Color.MAGENTA;
        int int11 = color10.getRed();
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("hi!", font9, (java.awt.Paint) color10, (float) 'a');
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("HorizontalAlignment.RIGHT", font4, (java.awt.Paint) color10);
        java.awt.Font font21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color22 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment23 = new org.jfree.chart.text.TextFragment("ThreadContext", font21, (java.awt.Paint) color22);
        org.jfree.chart.text.TextLine textLine24 = new org.jfree.chart.text.TextLine("", font21);
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("hi!", font21);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.lang.Object obj29 = textTitle25.draw(graphics2D26, rectangle2D27, (java.lang.Object) (byte) 100);
        java.awt.Font font31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color32 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment33 = new org.jfree.chart.text.TextFragment("ThreadContext", font31, (java.awt.Paint) color32);
        textTitle25.setFont(font31);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("RangeType.FULL", font31);
        java.awt.Color color38 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color39 = java.awt.Color.getColor("", color38);
        java.awt.Color color40 = java.awt.Color.getColor("ThreadContext", color39);
        org.jfree.chart.axis.AxisSpace axisSpace41 = new org.jfree.chart.axis.AxisSpace();
        axisSpace41.setBottom((double) '#');
        double double44 = axisSpace41.getLeft();
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.lang.Object obj47 = null;
        boolean boolean48 = rectangleEdge46.equals(obj47);
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge46);
        axisSpace41.ensureAtLeast((double) 100, rectangleEdge46);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment51 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor52 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean53 = horizontalAlignment51.equals((java.lang.Object) textAnchor52);
        org.jfree.chart.util.VerticalAlignment verticalAlignment54 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.lang.String str55 = verticalAlignment54.toString();
        org.jfree.chart.block.FlowArrangement flowArrangement56 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement56.clear();
        org.jfree.chart.LegendItemSource legendItemSource58 = null;
        org.jfree.chart.title.LegendTitle legendTitle59 = new org.jfree.chart.title.LegendTitle(legendItemSource58);
        org.jfree.chart.LegendItemSource legendItemSource60 = null;
        org.jfree.chart.title.LegendTitle legendTitle61 = new org.jfree.chart.title.LegendTitle(legendItemSource60);
        double double62 = legendTitle61.getHeight();
        flowArrangement56.add((org.jfree.chart.block.Block) legendTitle59, (java.lang.Object) double62);
        legendTitle59.setWidth((double) (byte) -1);
        java.awt.Paint paint66 = legendTitle59.getItemPaint();
        boolean boolean67 = verticalAlignment54.equals((java.lang.Object) paint66);
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double70 = rectangleInsets68.trimWidth((double) 1L);
        java.lang.String str71 = rectangleInsets68.toString();
        org.jfree.chart.title.TextTitle textTitle72 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font31, (java.awt.Paint) color40, rectangleEdge46, horizontalAlignment51, verticalAlignment54, rectangleInsets68);
        org.jfree.chart.LegendItemSource legendItemSource73 = null;
        org.jfree.chart.title.LegendTitle legendTitle74 = new org.jfree.chart.title.LegendTitle(legendItemSource73);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor75 = legendTitle74.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor76 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition77 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor75, textBlockAnchor76);
        org.jfree.chart.axis.CategoryAxis categoryAxis79 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color80 = java.awt.Color.RED;
        categoryAxis79.setLabelPaint((java.awt.Paint) color80);
        categoryAxis79.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint84 = categoryAxis79.getTickLabelPaint();
        java.awt.Stroke stroke85 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets86 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder87 = new org.jfree.chart.block.LineBorder(paint84, stroke85, rectangleInsets86);
        java.awt.Stroke stroke88 = lineBorder87.getStroke();
        java.awt.Paint paint89 = lineBorder87.getPaint();
        boolean boolean90 = rectangleAnchor75.equals((java.lang.Object) paint89);
        textBlock14.addLine("TextAnchor.BASELINE_RIGHT", font31, paint89);
        boolean boolean92 = axisLocation0.equals((java.lang.Object) paint89);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(obj29);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertNotNull(horizontalAlignment51);
        org.junit.Assert.assertNotNull(textAnchor52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(verticalAlignment54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "VerticalAlignment.CENTER" + "'", str55.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + (-7.0d) + "'", double70 == (-7.0d));
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str71.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertNotNull(rectangleAnchor75);
        org.junit.Assert.assertNotNull(textBlockAnchor76);
        org.junit.Assert.assertNotNull(color80);
        org.junit.Assert.assertNotNull(paint84);
        org.junit.Assert.assertNotNull(stroke85);
        org.junit.Assert.assertNotNull(rectangleInsets86);
        org.junit.Assert.assertNotNull(stroke88);
        org.junit.Assert.assertNotNull(paint89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color2 = java.awt.Color.MAGENTA;
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis1.getLabelURL();
        boolean boolean5 = categoryAxis1.isVisible();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = null;
        numberAxis6.setMarkerBand(markerAxisBand7);
        java.awt.Stroke stroke9 = numberAxis6.getTickMarkStroke();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis6.setUpArrow(shape11);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color18 = java.awt.Color.RED;
        categoryAxis17.setLabelPaint((java.awt.Paint) color18);
        float[] floatArray24 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray25 = color18.getRGBColorComponents(floatArray24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape28);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity32 = new org.jfree.chart.entity.TickLabelEntity(shape28, "", "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity35 = new org.jfree.chart.entity.TickLabelEntity(shape28, "hi!", "RectangleConstraintType.RANGE");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke37 = defaultDrawingSupplier36.getNextOutlineStroke();
        java.awt.Color color38 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("", "ThreadContext", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "DatasetRenderingOrder.FORWARD", true, shape11, true, (java.awt.Paint) color14, true, (java.awt.Paint) color18, stroke26, false, shape28, stroke37, (java.awt.Paint) color38);
        java.awt.Paint paint40 = legendItem39.getLinePaint();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer41 = legendItem39.getFillPaintTransformer();
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(gradientPaintTransformer41);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean5 = textAnchor3.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.CategoryTick categoryTick7 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 14.0d, textBlock1, textBlockAnchor2, textAnchor3, 14.0d);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double10 = categoryAxis9.getLabelAngle();
        categoryAxis9.setLowerMargin((double) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color15 = java.awt.Color.RED;
        categoryAxis14.setLabelPaint((java.awt.Paint) color15);
        categoryAxis14.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint19 = categoryAxis14.getTickLabelPaint();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder22 = new org.jfree.chart.block.LineBorder(paint19, stroke20, rectangleInsets21);
        categoryAxis9.setAxisLineStroke(stroke20);
        boolean boolean24 = categoryTick7.equals((java.lang.Object) stroke20);
        java.lang.Comparable comparable25 = categoryTick7.getCategory();
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + 14.0d + "'", comparable25.equals(14.0d));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        org.jfree.data.Range range5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) 0, range5);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint8.toUnconstrainedWidth();
        boolean boolean10 = numberAxis1.equals((java.lang.Object) rectangleConstraint9);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        org.jfree.chart.axis.Axis axis12 = axisChangeEvent11.getAxis();
        java.lang.String str13 = axisChangeEvent11.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(axis12);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        java.awt.Stroke stroke4 = numberAxis1.getTickMarkStroke();
        double double5 = numberAxis1.getUpperBound();
        double double6 = numberAxis1.getAutoRangeMinimumSize();
        numberAxis1.setAutoTickUnitSelection(false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-8d + "'", double6 == 1.0E-8d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.RendererState rendererState2 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = rendererState2.getInfo();
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState4 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo3);
        categoryItemRendererState4.setBarWidth((double) (-1L));
        org.junit.Assert.assertNotNull(plotRenderingInfo3);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        java.lang.String str1 = tickType0.toString();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MINOR" + "'", str1.equals("MINOR"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setForegroundAlpha((float) (-1));
        int int3 = categoryPlot0.getWeight();
        boolean boolean4 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke7 = valueMarker6.getOutlineStroke();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        valueMarker6.setLabelOffsetType(lengthAdjustmentType8);
        org.jfree.chart.util.Layer layer10 = null;
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker6, layer10);
        java.awt.Stroke stroke12 = null;
        try {
            categoryPlot0.setDomainGridlineStroke(stroke12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(lengthAdjustmentType8);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color5 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("ThreadContext", font4, (java.awt.Paint) color5);
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font4);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!", font4);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.lang.Object obj12 = textTitle8.draw(graphics2D9, rectangle2D10, (java.lang.Object) (byte) 100);
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color15 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("ThreadContext", font14, (java.awt.Paint) color15);
        textTitle8.setFont(font14);
        org.jfree.chart.block.LabelBlock labelBlock18 = new org.jfree.chart.block.LabelBlock("ThreadContext", font14);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double23 = categoryAxis22.getLabelAngle();
        categoryAxis22.setLowerMargin((double) 0);
        categoryAxis22.setUpperMargin(0.0d);
        java.lang.String str28 = categoryAxis22.getLabel();
        double double29 = categoryAxis22.getUpperMargin();
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke33 = valueMarker32.getOutlineStroke();
        java.awt.Paint paint34 = valueMarker32.getOutlinePaint();
        categoryAxis22.setTickLabelPaint((java.lang.Comparable) 10.0d, paint34);
        try {
            java.lang.Object obj36 = labelBlock18.draw(graphics2D19, rectangle2D20, (java.lang.Object) categoryAxis22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("ChartChangeEventType.NEW_DATASET", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color2 = java.awt.Color.RED;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        float[] floatArray8 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray9 = color2.getRGBColorComponents(floatArray8);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color12 = java.awt.Color.RED;
        categoryAxis11.setLabelPaint((java.awt.Paint) color12);
        float[] floatArray18 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray19 = color12.getRGBColorComponents(floatArray18);
        float[] floatArray20 = color2.getRGBComponents(floatArray19);
        java.awt.Color color21 = color2.darker();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.block.BlockContainer blockContainer3 = null;
        legendTitle1.setWrapper(blockContainer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.lang.Object obj8 = legendTitle1.draw(graphics2D5, rectangle2D6, (java.lang.Object) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = barRenderer0.getSeriesNegativeItemLabelPosition((int) (short) 1);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean5 = categoryLabelPosition3.equals((java.lang.Object) categoryLabelPosition4);
        org.jfree.chart.text.TextAnchor textAnchor6 = categoryLabelPosition3.getRotationAnchor();
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke9 = valueMarker8.getOutlineStroke();
        boolean boolean10 = categoryLabelPosition3.equals((java.lang.Object) valueMarker8);
        java.awt.Font font11 = valueMarker8.getLabelFont();
        barRenderer0.setBaseItemLabelFont(font11);
        org.junit.Assert.assertNotNull(itemLabelPosition2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setForegroundAlpha((float) (-1));
        org.jfree.chart.LegendItemCollection legendItemCollection3 = categoryPlot0.getLegendItems();
        categoryPlot0.setDomainGridlinesVisible(true);
        java.awt.Paint paint6 = categoryPlot0.getOutlinePaint();
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color11 = java.awt.Color.RED;
        categoryAxis10.setLabelPaint((java.awt.Paint) color11);
        float[] floatArray17 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray18 = color11.getRGBColorComponents(floatArray17);
        org.jfree.chart.title.LegendGraphic legendGraphic19 = new org.jfree.chart.title.LegendGraphic(shape8, (java.awt.Paint) color11);
        java.awt.Shape shape20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity21 = new org.jfree.chart.entity.LegendItemEntity(shape20);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity24 = new org.jfree.chart.entity.TickLabelEntity(shape20, "", "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity27 = new org.jfree.chart.entity.TickLabelEntity(shape20, "hi!", "RectangleConstraintType.RANGE");
        legendGraphic19.setLine(shape20);
        java.awt.Shape shape29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape29, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color36 = java.awt.Color.RED;
        categoryAxis35.setLabelPaint((java.awt.Paint) color36);
        float[] floatArray42 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray43 = color36.getRGBColorComponents(floatArray42);
        org.jfree.chart.title.LegendGraphic legendGraphic44 = new org.jfree.chart.title.LegendGraphic(shape33, (java.awt.Paint) color36);
        java.awt.Shape shape45 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape49 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape45, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color52 = java.awt.Color.RED;
        categoryAxis51.setLabelPaint((java.awt.Paint) color52);
        float[] floatArray58 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray59 = color52.getRGBColorComponents(floatArray58);
        org.jfree.chart.title.LegendGraphic legendGraphic60 = new org.jfree.chart.title.LegendGraphic(shape49, (java.awt.Paint) color52);
        legendGraphic44.setLinePaint((java.awt.Paint) color52);
        legendGraphic44.setID("TextAnchor.BASELINE_RIGHT");
        java.awt.Paint paint64 = legendGraphic44.getLinePaint();
        try {
            org.jfree.chart.LegendItem legendItem65 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "RangeType.FULL", shape20, paint64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertNotNull(paint64);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = null;
        numberAxis6.setMarkerBand(markerAxisBand7);
        java.awt.Stroke stroke9 = numberAxis6.getTickMarkStroke();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis6.setUpArrow(shape11);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color18 = java.awt.Color.RED;
        categoryAxis17.setLabelPaint((java.awt.Paint) color18);
        float[] floatArray24 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray25 = color18.getRGBColorComponents(floatArray24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape28);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity32 = new org.jfree.chart.entity.TickLabelEntity(shape28, "", "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity35 = new org.jfree.chart.entity.TickLabelEntity(shape28, "hi!", "RectangleConstraintType.RANGE");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke37 = defaultDrawingSupplier36.getNextOutlineStroke();
        java.awt.Color color38 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("", "ThreadContext", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "DatasetRenderingOrder.FORWARD", true, shape11, true, (java.awt.Paint) color14, true, (java.awt.Paint) color18, stroke26, false, shape28, stroke37, (java.awt.Paint) color38);
        java.awt.Paint paint40 = legendItem39.getOutlinePaint();
        java.awt.Paint paint41 = legendItem39.getFillPaint();
        java.awt.Paint paint42 = legendItem39.getOutlinePaint();
        java.lang.String str43 = legendItem39.getDescription();
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "ThreadContext" + "'", str43.equals("ThreadContext"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke2 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke5 = valueMarker4.getOutlineStroke();
        statisticalBarRenderer0.setErrorIndicatorStroke(stroke5);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = statisticalBarRenderer7.getPositiveItemLabelPosition((int) '#', (int) (byte) -1);
        statisticalBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition10, false);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.setForegroundAlpha((float) (-1));
        int int17 = categoryPlot14.getWeight();
        boolean boolean18 = categoryPlot14.isRangeZoomable();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            statisticalBarRenderer0.drawDomainGridline(graphics2D13, categoryPlot14, rectangle2D19, 4.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 'a');
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendTitle3.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor4, textBlockAnchor5);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions1, categoryLabelPosition6);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 'a');
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = legendTitle11.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor12, textBlockAnchor13);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions15 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions9, categoryLabelPosition14);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions7, categoryLabelPosition14);
        java.awt.Font font18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color19 = java.awt.Color.MAGENTA;
        int int20 = color19.getRed();
        org.jfree.chart.text.TextFragment textFragment22 = new org.jfree.chart.text.TextFragment("hi!", font18, (java.awt.Paint) color19, (float) 'a');
        boolean boolean23 = categoryLabelPositions7.equals((java.lang.Object) color19);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertNotNull(categoryLabelPositions15);
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 255 + "'", int20 == 255);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        int int1 = tickUnits0.size();
        try {
            org.jfree.chart.axis.TickUnit tickUnit3 = tickUnits0.getCeilingTickUnit((double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        numberAxis1.setLabelURL("LGPL");
        numberAxis1.resizeRange((double) 10L, (double) 100);
        org.jfree.data.RangeType rangeType9 = numberAxis1.getRangeType();
        org.junit.Assert.assertNotNull(rangeType9);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        categoryAxis1.setLowerMargin((double) 0);
        categoryAxis1.setLabel("hi!");
        categoryAxis1.setLabel("hi!");
        categoryAxis1.setAxisLineVisible(true);
        int int11 = categoryAxis1.getMaximumCategoryLabelLines();
        java.lang.Comparable comparable12 = null;
        try {
            categoryAxis1.removeCategoryLabelToolTip(comparable12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset45);
        java.lang.Number number49 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset45);
        org.jfree.data.Range range51 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset45, (double) 1L);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + (-1.0d) + "'", number49.equals((-1.0d)));
        org.junit.Assert.assertNotNull(range51);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        categoryAxis1.setFixedDimension((-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) itemLabelAnchor0, jFreeChart1, (int) '#', (-1));
        int int5 = chartProgressEvent4.getPercent();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) 1L);
        double double4 = rectangleInsets0.trimWidth((double) 1L);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color5);
        int int7 = color5.getBlue();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.0d) + "'", double2 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-7.0d) + "'", double4 == (-7.0d));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color4 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("ThreadContext", font3, (java.awt.Paint) color4);
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("", font3);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("hi!", font3);
        boolean boolean8 = textTitle7.getNotify();
        textTitle7.setWidth((double) 100.0f);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        numberAxis1.setTickMarkInsideLength((float) 100L);
        boolean boolean6 = numberAxis1.isPositiveArrowVisible();
        java.awt.Shape shape7 = numberAxis1.getUpArrow();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        double double3 = statisticalBarRenderer0.getItemMargin();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color6 = java.awt.Color.RED;
        categoryAxis5.setLabelPaint((java.awt.Paint) color6);
        float[] floatArray12 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray13 = color6.getRGBColorComponents(floatArray12);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color16 = java.awt.Color.RED;
        categoryAxis15.setLabelPaint((java.awt.Paint) color16);
        float[] floatArray22 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray23 = color16.getRGBColorComponents(floatArray22);
        float[] floatArray24 = color6.getRGBComponents(floatArray23);
        statisticalBarRenderer0.setErrorIndicatorPaint((java.awt.Paint) color6);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat5 = numberAxis1.getNumberFormatOverride();
        numberAxis1.setTickLabelsVisible(true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(numberFormat5);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "NOID", "{0}", "SortOrder.DESCENDING");
        basicProjectInfo4.setName("ChartEntity: tooltip = ");
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        java.awt.Shape shape5 = numberAxis1.getRightArrow();
        numberAxis1.setLowerMargin(100.0d);
        numberAxis1.setUpperMargin(100.0d);
        numberAxis1.configure();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 10L, 1.0f, 0.0d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 10L, 1.0f, 0.0d };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 10L, 1.0f, 0.0d };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray7, numberArray11, numberArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("-3,-3,3,3", "-3,-3,3,3", numberArray16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleConstraintType.RANGE", "ThreadContext", numberArray16);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(categoryDataset18);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke2 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke5 = valueMarker4.getOutlineStroke();
        statisticalBarRenderer0.setErrorIndicatorStroke(stroke5);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = statisticalBarRenderer7.getPositiveItemLabelPosition((int) '#', (int) (byte) -1);
        statisticalBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition10, false);
        double double13 = statisticalBarRenderer0.getItemLabelAnchorOffset();
        boolean boolean15 = statisticalBarRenderer0.isSeriesVisibleInLegend(4);
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        numberAxis1.setLabelURL("LGPL");
        numberAxis1.resizeRange((double) 10L, (double) 100);
        numberAxis1.setNegativeArrowVisible(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = null;
        numberAxis1.setMarkerBand(markerAxisBand11);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor6 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.TickType tickType11 = org.jfree.chart.axis.TickType.MINOR;
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.NumberTick numberTick17 = new org.jfree.chart.axis.NumberTick(tickType11, (double) 'a', "DatasetRenderingOrder.FORWARD", textAnchor14, textAnchor15, 4.0d);
        org.jfree.chart.text.TextAnchor textAnchor18 = numberTick17.getTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        java.awt.Shape shape21 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D8, (float) (short) 0, (-1.0f), textAnchor18, (double) (-1L), textAnchor20);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor6, textAnchor20);
        try {
            java.awt.Shape shape23 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("CONTRACT", graphics2D1, (float) 15, (float) 0L, textAnchor4, 9.0d, textAnchor20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(itemLabelAnchor6);
        org.junit.Assert.assertNotNull(tickType11);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNull(shape21);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setLeft((double) (byte) -1);
        java.lang.Object obj3 = axisSpace0.clone();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey((int) 'a');
        int int4 = keyedObjects0.getIndex((java.lang.Comparable) (byte) 0);
        int int6 = keyedObjects0.getIndex((java.lang.Comparable) (short) 10);
        org.junit.Assert.assertNull(comparable2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getMinimumBarLength();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = statisticalBarRenderer0.getSeriesItemLabelGenerator((-2));
        java.awt.Font font5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double8 = categoryAxis7.getLabelAngle();
        categoryAxis7.setLowerMargin((double) 0);
        categoryAxis7.setUpperMargin(0.0d);
        java.lang.String str13 = categoryAxis7.getLabel();
        double double14 = categoryAxis7.getUpperMargin();
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke18 = valueMarker17.getOutlineStroke();
        java.awt.Paint paint19 = valueMarker17.getOutlinePaint();
        categoryAxis7.setTickLabelPaint((java.lang.Comparable) 10.0d, paint19);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer24 = new org.jfree.chart.text.G2TextMeasurer(graphics2D23);
        org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("", font5, paint19, 0.0f, 4, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer24);
        statisticalBarRenderer0.setBaseItemLabelPaint(paint19);
        java.awt.Paint paint28 = statisticalBarRenderer0.lookupSeriesPaint((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(textBlock25);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Shape shape1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity2 = new org.jfree.chart.entity.LegendItemEntity(shape1);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity5 = new org.jfree.chart.entity.TickLabelEntity(shape1, "", "");
        boolean boolean6 = textLine0.equals((java.lang.Object) tickLabelEntity5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D8 = textLine0.calculateDimensions(graphics2D7);
        size2D8.setWidth(0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand13 = null;
        numberAxis12.setMarkerBand(markerAxisBand13);
        java.awt.Stroke stroke15 = numberAxis12.getTickMarkStroke();
        boolean boolean16 = size2D8.equals((java.lang.Object) numberAxis12);
        java.lang.Object obj17 = size2D8.clone();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(size2D8);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(obj17);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        java.util.Locale locale1 = null;
//        java.lang.ClassLoader classLoader2 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
//        try {
//            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("ChartEntity: tooltip = ", locale1, classLoader2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(classLoader2);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        java.awt.Shape shape5 = numberAxis1.getRightArrow();
        numberAxis1.setLabelToolTip("LGPL");
        numberAxis1.setAutoRange(true);
        java.awt.Shape shape10 = numberAxis1.getUpArrow();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        categoryAxis1.setLowerMargin((double) 0);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions5);
        double double7 = categoryAxis1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getMinimumBarLength();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = statisticalBarRenderer0.getSeriesItemLabelGenerator((-2));
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color7 = java.awt.Color.getColor("", color6);
        java.awt.Color color8 = java.awt.Color.getColor("ThreadContext", color7);
        statisticalBarRenderer0.setBasePaint((java.awt.Paint) color7);
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        double double13 = legendTitle12.getWidth();
        legendTitle12.setHeight((double) (byte) 10);
        java.awt.Font font16 = legendTitle12.getItemFont();
        java.awt.Stroke stroke17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean18 = legendTitle12.equals((java.lang.Object) stroke17);
        statisticalBarRenderer0.setSeriesOutlineStroke((int) (short) 0, stroke17, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) '4', 10.0f);
        numberAxis1.setUpArrow(shape4);
        numberAxis1.setRangeAboutValue((double) 1.0f, 44.0d);
        boolean boolean9 = numberAxis1.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        java.awt.Font font4 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 10.0d);
        double double5 = categoryAxis1.getLabelAngle();
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        categoryAxis1.setAxisLinePaint(paint6);
        categoryAxis1.setTickLabelsVisible(false);
        int int10 = categoryAxis1.getMaximumCategoryLabelLines();
        categoryAxis1.setLabelToolTip("RectangleConstraintType.RANGE");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        java.awt.Stroke stroke4 = numberAxis1.getTickMarkStroke();
        numberAxis1.setUpperMargin((double) 0.5f);
        double double7 = numberAxis1.getLowerBound();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        shapeList0.clear();
        java.lang.Object obj2 = shapeList0.clone();
        int int3 = shapeList0.size();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setForegroundAlpha((float) (-1));
        int int3 = categoryPlot0.getWeight();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        java.util.List list5 = categoryPlot0.getCategoriesForAxis(categoryAxis4);
        categoryPlot0.clearAnnotations();
        categoryPlot0.setRangeCrosshairValue((double) (-1));
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        try {
            categoryPlot0.setRangeAxisLocation((int) (byte) -1, axisLocation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        org.jfree.data.Range range5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) 0, range5);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint8.toUnconstrainedWidth();
        boolean boolean10 = numberAxis1.equals((java.lang.Object) rectangleConstraint9);
        java.lang.String str11 = rectangleConstraint9.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=1.0, height=0.0]" + "'", str11.equals("RectangleConstraint[LengthConstraintType.NONE: width=1.0, height=0.0]"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((-1.0d));
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 0.5f, (java.lang.Number) 14.0d);
        org.jfree.data.KeyedObjects keyedObjects3 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable5 = keyedObjects3.getKey((int) 'a');
        int int7 = keyedObjects3.getIndex((java.lang.Comparable) (byte) 0);
        java.util.List list8 = keyedObjects3.getKeys();
        boolean boolean9 = meanAndStandardDeviation2.equals((java.lang.Object) list8);
        org.junit.Assert.assertNull(comparable5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable1 = null;
        int int2 = defaultStatisticalCategoryDataset0.getRowIndex(comparable1);
        int int3 = defaultStatisticalCategoryDataset0.getRowCount();
        org.jfree.data.Range range5 = defaultStatisticalCategoryDataset0.getRangeBounds(false);
        defaultStatisticalCategoryDataset0.add((-1.0d), (double) 10L, (java.lang.Comparable) 0.0f, (java.lang.Comparable) 10.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        java.lang.Comparable comparable48 = null;
        org.jfree.data.general.PieDataset pieDataset50 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset47, comparable48, (double) (-1.0f));
        boolean boolean51 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset47);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(pieDataset50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateY();
        blockParams0.setTranslateX((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        java.awt.Stroke stroke4 = numberAxis1.getTickMarkStroke();
        numberAxis1.setUpperMargin((double) 0.5f);
        double double7 = numberAxis1.getUpperMargin();
        numberAxis1.setVerticalTickLabels(false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5d + "'", double7 == 0.5d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        int int1 = paintList0.size();
        org.jfree.chart.axis.TickType tickType2 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean3 = paintList0.equals((java.lang.Object) tickType2);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int6 = color5.getRed();
        try {
            paintList0.setPaint((int) (short) -1, (java.awt.Paint) color5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(tickType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        java.lang.String str2 = numberTickUnit1.toString();
        int int3 = numberTickUnit1.getMinorTickCount();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[size=10]" + "'", str2.equals("[size=10]"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getMinimumBarLength();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = statisticalBarRenderer0.getSeriesItemLabelGenerator((-2));
        boolean boolean6 = statisticalBarRenderer0.isItemLabelVisible(0, 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) '#', (int) (byte) -1);
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke6 = valueMarker5.getOutlineStroke();
        java.awt.Paint paint7 = valueMarker5.getOutlinePaint();
        java.awt.Paint paint8 = valueMarker5.getLabelPaint();
        java.awt.Stroke stroke9 = valueMarker5.getOutlineStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke9);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = statisticalBarRenderer0.getGradientPaintTransformer();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = statisticalBarRenderer12.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke14 = statisticalBarRenderer12.getBaseStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke14);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(gradientPaintTransformer11);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.add((java.lang.Number) 35.0d, (java.lang.Number) 100.0d, (java.lang.Comparable) (short) 100, (java.lang.Comparable) (short) 1);
        int int6 = defaultStatisticalCategoryDataset0.getColumnCount();
        java.lang.Number number9 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) 1L, (java.lang.Comparable) '#');
        int int10 = defaultStatisticalCategoryDataset0.getRowCount();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Color color2 = java.awt.Color.darkGray;
        textTitle1.setBackgroundPaint((java.awt.Paint) color2);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint((double) 0, range3);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint4.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType7 = rectangleConstraint6.getHeightConstraintType();
        org.jfree.data.Range range9 = null;
        org.jfree.data.Range range11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) 0, range11);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint12.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range1, lengthConstraintType7, 0.0d, range9, lengthConstraintType15);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType17 = rectangleConstraint16.getWidthConstraintType();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
        org.junit.Assert.assertNotNull(lengthConstraintType7);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNotNull(lengthConstraintType17);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        java.awt.Font font4 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 10.0d);
        double double5 = categoryAxis1.getLabelAngle();
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        categoryAxis1.setAxisLinePaint(paint6);
        categoryAxis1.setTickLabelsVisible(false);
        int int10 = categoryAxis1.getMaximumCategoryLabelLines();
        double double11 = categoryAxis1.getCategoryMargin();
        java.awt.Font font12 = categoryAxis1.getTickLabelFont();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        java.awt.Paint paint3 = legendTitle1.getItemPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) '4', 10.0f);
        numberAxis1.setUpArrow(shape4);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis1.setMarkerBand(markerAxisBand6);
        double double8 = numberAxis1.getLowerBound();
        numberAxis1.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D(4.0d, (double) '#');
        size2D2.height = 10L;
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RangeType.FULL", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        java.awt.Font font4 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 10.0d);
        double double5 = categoryAxis1.getLabelAngle();
        java.awt.Shape shape6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color13 = java.awt.Color.RED;
        categoryAxis12.setLabelPaint((java.awt.Paint) color13);
        float[] floatArray19 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray20 = color13.getRGBColorComponents(floatArray19);
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape10, (java.awt.Paint) color13);
        java.awt.Shape shape22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape22, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color29 = java.awt.Color.RED;
        categoryAxis28.setLabelPaint((java.awt.Paint) color29);
        float[] floatArray35 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray36 = color29.getRGBColorComponents(floatArray35);
        org.jfree.chart.title.LegendGraphic legendGraphic37 = new org.jfree.chart.title.LegendGraphic(shape26, (java.awt.Paint) color29);
        legendGraphic21.setLinePaint((java.awt.Paint) color29);
        boolean boolean39 = categoryAxis1.equals((java.lang.Object) legendGraphic21);
        legendGraphic21.setLineVisible(false);
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int43 = color42.getBlue();
        legendGraphic21.setLinePaint((java.awt.Paint) color42);
        legendGraphic21.setShapeFilled(false);
        legendGraphic21.setShapeOutlineVisible(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 255 + "'", int43 == 255);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        java.awt.Shape shape5 = numberAxis1.getRightArrow();
        numberAxis1.setLabelToolTip("LGPL");
        numberAxis1.setLowerMargin((double) (short) 0);
        boolean boolean10 = numberAxis1.isPositiveArrowVisible();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double3 = categoryAxis2.getLabelAngle();
        java.awt.Font font5 = categoryAxis2.getTickLabelFont((java.lang.Comparable) 10.0d);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("-3,-3,3,3", font5);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = textTitle6.getPosition();
        boolean boolean8 = textTitle6.getNotify();
        textTitle6.setToolTipText("");
        textTitle6.setExpandToFitSpace(false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        java.awt.Shape shape5 = numberAxis1.getRightArrow();
        numberAxis1.setLowerMargin(100.0d);
        double double8 = numberAxis1.getUpperMargin();
        numberAxis1.resizeRange((double) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.util.List list1 = projectInfo0.getContributors();
//        java.lang.String str2 = projectInfo0.getVersion();
//        projectInfo0.setVersion("VerticalAlignment.CENTER");
//        java.lang.String str5 = projectInfo0.getCopyright();
//        java.lang.String str6 = projectInfo0.toString();
//        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo11 = new org.jfree.chart.ui.BasicProjectInfo("ThreadContext", "LGPL", "hi!", "ThreadContext");
//        projectInfo0.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo11);
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(list1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VerticalAlignment.CENTER" + "'", str2.equals("VerticalAlignment.CENTER"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "LGPL" + "'", str5.equals("LGPL"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "JFreeChart version VerticalAlignment.CENTER.\nLGPL.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:ThreadContext ThreadContext (hi!).(C)opyright 2000-2007, by Object Refinery Limited and Contributors ThreadContext (hi!).JFreeChart VerticalAlignment.CENTER (http://www.jfree.org/jfreechart/index.html).ThreadContext ThreadContext (hi!).ThreadContext ThreadContext (hi!).\nJFreeChart LICENCE TERMS:\nRectangleConstraintType.RANGE" + "'", str6.equals("JFreeChart version VerticalAlignment.CENTER.\nLGPL.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:ThreadContext ThreadContext (hi!).(C)opyright 2000-2007, by Object Refinery Limited and Contributors ThreadContext (hi!).JFreeChart VerticalAlignment.CENTER (http://www.jfree.org/jfreechart/index.html).ThreadContext ThreadContext (hi!).ThreadContext ThreadContext (hi!).\nJFreeChart LICENCE TERMS:\nRectangleConstraintType.RANGE"));
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        java.awt.Stroke stroke4 = numberAxis1.getTickMarkStroke();
        numberAxis1.setUpperMargin((double) (-1));
        org.jfree.chart.axis.TickUnitSource tickUnitSource7 = numberAxis1.getStandardTickUnits();
        java.awt.Paint paint8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        numberAxis1.setAxisLinePaint(paint8);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(tickUnitSource7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double3 = categoryAxis2.getLabelAngle();
        java.awt.Font font5 = categoryAxis2.getTickLabelFont((java.lang.Comparable) 10.0d);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("-3,-3,3,3", font5);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = textTitle6.getPosition();
        boolean boolean8 = textTitle6.getNotify();
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getHeight();
        org.jfree.chart.block.BlockContainer blockContainer12 = null;
        legendTitle10.setWrapper(blockContainer12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double16 = rectangleInsets14.trimWidth((double) 1L);
        double double17 = rectangleInsets14.getBottom();
        double double19 = rectangleInsets14.calculateRightOutset((double) 0L);
        double double21 = rectangleInsets14.extendHeight((double) 10.0f);
        legendTitle10.setItemLabelPadding(rectangleInsets14);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double25 = rectangleInsets23.trimWidth((double) 1L);
        double double27 = rectangleInsets23.trimWidth((double) 1L);
        legendTitle10.setPadding(rectangleInsets23);
        textTitle6.setMargin(rectangleInsets23);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent30 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle6);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-7.0d) + "'", double16 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2.0d + "'", double17 == 2.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 14.0d + "'", double21 == 14.0d);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + (-7.0d) + "'", double25 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-7.0d) + "'", double27 == (-7.0d));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset45);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double51 = categoryAxis50.getLabelAngle();
        categoryAxis50.setLowerMargin((double) 0);
        categoryAxis50.setLabel("hi!");
        int int56 = categoryAxis50.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis58.setAutoRange(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer61 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator62 = null;
        statisticalBarRenderer61.setBaseItemLabelGenerator(categoryItemLabelGenerator62);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition65 = null;
        statisticalBarRenderer61.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition65, true);
        boolean boolean68 = statisticalBarRenderer61.isDrawBarOutline();
        boolean boolean69 = statisticalBarRenderer61.getAutoPopulateSeriesPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis50, (org.jfree.chart.axis.ValueAxis) numberAxis58, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer61);
        java.lang.Object obj71 = categoryPlot70.clone();
        categoryPlot70.setRangeCrosshairValue((double) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation75 = categoryPlot70.getDomainAxisLocation(100);
        categoryPlot70.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(obj71);
        org.junit.Assert.assertNotNull(axisLocation75);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition4, true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke8 = defaultDrawingSupplier7.getNextOutlineStroke();
        java.awt.Stroke stroke9 = defaultDrawingSupplier7.getNextStroke();
        statisticalBarRenderer0.setErrorIndicatorStroke(stroke9);
        java.awt.Paint paint12 = null;
        statisticalBarRenderer0.setSeriesPaint(128, paint12);
        double double14 = statisticalBarRenderer0.getBase();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(1.0d, (double) (byte) 0, 14.0d, (double) 10);
        java.awt.Paint paint5 = blockBorder4.getPaint();
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(128);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.TickType tickType6 = org.jfree.chart.axis.TickType.MINOR;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.NumberTick numberTick12 = new org.jfree.chart.axis.NumberTick(tickType6, (double) 'a', "DatasetRenderingOrder.FORWARD", textAnchor9, textAnchor10, 4.0d);
        org.jfree.chart.text.TextAnchor textAnchor13 = numberTick12.getTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        java.awt.Shape shape16 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D3, (float) (short) 0, (-1.0f), textAnchor13, (double) (-1L), textAnchor15);
        int int17 = objectList1.indexOf((java.lang.Object) textAnchor13);
        org.junit.Assert.assertNotNull(tickType6);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNull(shape16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        org.jfree.data.Range range5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) 0, range5);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint8.toUnconstrainedWidth();
        boolean boolean10 = numberAxis1.equals((java.lang.Object) rectangleConstraint9);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint9.toUnconstrainedWidth();
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getMinimumBarLength();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = statisticalBarRenderer0.getSeriesItemLabelGenerator((-2));
        java.awt.Font font5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double8 = categoryAxis7.getLabelAngle();
        categoryAxis7.setLowerMargin((double) 0);
        categoryAxis7.setUpperMargin(0.0d);
        java.lang.String str13 = categoryAxis7.getLabel();
        double double14 = categoryAxis7.getUpperMargin();
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke18 = valueMarker17.getOutlineStroke();
        java.awt.Paint paint19 = valueMarker17.getOutlinePaint();
        categoryAxis7.setTickLabelPaint((java.lang.Comparable) 10.0d, paint19);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer24 = new org.jfree.chart.text.G2TextMeasurer(graphics2D23);
        org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("", font5, paint19, 0.0f, 4, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer24);
        statisticalBarRenderer0.setBaseItemLabelPaint(paint19);
        statisticalBarRenderer0.setBaseSeriesVisibleInLegend(true, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(textBlock25);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.MAGENTA;
        int int3 = color2.getRed();
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!", font1, (java.awt.Paint) color2, (float) 'a');
        java.awt.Font font6 = textFragment5.getFont();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean14 = categoryLabelPosition12.equals((java.lang.Object) categoryLabelPosition13);
        org.jfree.chart.text.TextAnchor textAnchor15 = categoryLabelPosition13.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.axis.NumberTick numberTick18 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0.2d, "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", textAnchor15, textAnchor16, (double) 4);
        try {
            textFragment5.draw(graphics2D7, 10.0f, (float) 100, textAnchor16, (float) 15, (float) 128, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(textAnchor16);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        categoryAxis1.setLowerMargin((double) 0);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions5);
        java.awt.Stroke stroke7 = categoryAxis1.getTickMarkStroke();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number3 = defaultStatisticalCategoryDataset0.getStdDevValue((java.lang.Comparable) "VerticalAlignment.CENTER", (java.lang.Comparable) (short) 10);
        int int5 = defaultStatisticalCategoryDataset0.getRowIndex((java.lang.Comparable) 100);
        defaultStatisticalCategoryDataset0.add((double) 100.0f, (double) 4, (java.lang.Comparable) (-1), (java.lang.Comparable) 2);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, false);
        double double13 = range12.getCentralValue();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) '#', (int) (byte) -1);
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke6 = valueMarker5.getOutlineStroke();
        java.awt.Paint paint7 = valueMarker5.getOutlinePaint();
        java.awt.Paint paint8 = valueMarker5.getLabelPaint();
        java.awt.Stroke stroke9 = valueMarker5.getOutlineStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke9);
        statisticalBarRenderer0.setBaseItemLabelsVisible(false);
        java.awt.Shape shape14 = statisticalBarRenderer0.getSeriesShape((int) (short) 1);
        statisticalBarRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(shape14);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition4, true);
        double double7 = statisticalBarRenderer0.getBase();
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke12 = valueMarker11.getOutlineStroke();
        barRenderer9.setBaseOutlineStroke(stroke12);
        statisticalBarRenderer0.setSeriesOutlineStroke((int) ' ', stroke12, true);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        valueMarker1.setLabelOffsetType(lengthAdjustmentType3);
        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo10 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "LGPL", "hi!", "RectangleConstraintType.RANGE");
        projectInfo5.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo10);
        boolean boolean12 = valueMarker1.equals((java.lang.Object) basicProjectInfo10);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
        org.junit.Assert.assertNotNull(projectInfo5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        double double6 = legendTitle5.getHeight();
        flowArrangement0.add((org.jfree.chart.block.Block) legendTitle3, (java.lang.Object) double6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = legendTitle3.getLegendItemGraphicAnchor();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double4 = categoryAxis3.getLabelAngle();
        java.awt.Font font6 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 10.0d);
        double double7 = categoryAxis3.getLabelAngle();
        java.awt.Shape shape8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape8, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color15 = java.awt.Color.RED;
        categoryAxis14.setLabelPaint((java.awt.Paint) color15);
        float[] floatArray21 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray22 = color15.getRGBColorComponents(floatArray21);
        org.jfree.chart.title.LegendGraphic legendGraphic23 = new org.jfree.chart.title.LegendGraphic(shape12, (java.awt.Paint) color15);
        java.awt.Shape shape24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape24, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color31 = java.awt.Color.RED;
        categoryAxis30.setLabelPaint((java.awt.Paint) color31);
        float[] floatArray37 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray38 = color31.getRGBColorComponents(floatArray37);
        org.jfree.chart.title.LegendGraphic legendGraphic39 = new org.jfree.chart.title.LegendGraphic(shape28, (java.awt.Paint) color31);
        legendGraphic23.setLinePaint((java.awt.Paint) color31);
        boolean boolean41 = categoryAxis3.equals((java.lang.Object) legendGraphic23);
        java.awt.Stroke stroke42 = null;
        legendGraphic23.setOutlineStroke(stroke42);
        java.awt.Color color44 = java.awt.Color.black;
        flowArrangement0.add((org.jfree.chart.block.Block) legendGraphic23, (java.lang.Object) color44);
        int int46 = color44.getBlue();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        double[] doubleArray10 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray17 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray24 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray31 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray38 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray45 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray46 = new double[][] { doubleArray10, doubleArray17, doubleArray24, doubleArray31, doubleArray38, doubleArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset47, (int) (short) 0);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer51 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) pieDataset49, (java.lang.Comparable) "ThreadContext");
        java.lang.Object obj52 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) legendItemBlockContainer51);
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double56 = categoryAxis55.getLabelAngle();
        java.awt.Font font58 = categoryAxis55.getTickLabelFont((java.lang.Comparable) 10.0d);
        org.jfree.chart.title.TextTitle textTitle59 = new org.jfree.chart.title.TextTitle("-3,-3,3,3", font58);
        boolean boolean60 = legendItemBlockContainer51.equals((java.lang.Object) textTitle59);
        java.lang.Comparable comparable61 = legendItemBlockContainer51.getSeriesKey();
        java.lang.String str62 = legendItemBlockContainer51.getToolTipText();
        java.lang.Object obj63 = legendItemBlockContainer51.clone();
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + comparable61 + "' != '" + "ThreadContext" + "'", comparable61.equals("ThreadContext"));
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertNotNull(obj63);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleAnchor.CENTER");
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = shapeList0.getShape((-1));
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine();
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color7 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("ThreadContext", font6, (java.awt.Paint) color7);
        textLine4.addFragment(textFragment8);
        boolean boolean10 = horizontalAlignment3.equals((java.lang.Object) textFragment8);
        boolean boolean11 = shapeList0.equals((java.lang.Object) textFragment8);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis14.setUpperBound((double) 1L);
        boolean boolean17 = numberAxis14.getAutoRangeIncludesZero();
        java.awt.Shape shape18 = numberAxis14.getRightArrow();
        shapeList0.setShape(128, shape18);
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.clone(shape18);
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNull(shape20);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        java.awt.Stroke stroke4 = numberAxis1.getTickMarkStroke();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis1.setUpArrow(shape6);
        try {
            numberAxis1.setRangeWithMargins((double) 10, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.RendererState rendererState2 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = rendererState2.getInfo();
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState4 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo3);
        double double5 = categoryItemRendererState4.getSeriesRunningTotal();
        org.junit.Assert.assertNotNull(plotRenderingInfo3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis2.setMarkerBand(markerAxisBand3);
        java.awt.Stroke stroke5 = numberAxis2.getTickMarkStroke();
        numberAxis2.setUpperMargin((double) (-1));
        org.jfree.chart.event.AxisChangeListener axisChangeListener8 = null;
        numberAxis2.removeChangeListener(axisChangeListener8);
        boolean boolean10 = unitType0.equals((java.lang.Object) numberAxis2);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (byte) 1, (float) (-1L));
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        numberAxis1.setLabelURL("LGPL");
        numberAxis1.setAutoRangeStickyZero(false);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.lang.Object obj11 = null;
        boolean boolean12 = rectangleEdge10.equals(obj11);
        try {
            double double13 = numberAxis1.valueToJava2D((double) 'a', rectangle2D9, rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) 1L);
        double double4 = rectangleInsets0.trimWidth((double) (short) 100);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.0d) + "'", double2 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 92.0d + "'", double4 == 92.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition4, true);
        double double7 = statisticalBarRenderer0.getBase();
        statisticalBarRenderer0.setSeriesItemLabelsVisible((int) (short) 1, false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) '#', (int) (byte) -1);
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke6 = valueMarker5.getOutlineStroke();
        java.awt.Paint paint7 = valueMarker5.getOutlinePaint();
        java.awt.Paint paint8 = valueMarker5.getLabelPaint();
        java.awt.Stroke stroke9 = valueMarker5.getOutlineStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke9);
        statisticalBarRenderer0.setBaseItemLabelsVisible(false);
        double double13 = statisticalBarRenderer0.getBase();
        java.awt.Stroke stroke14 = statisticalBarRenderer0.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double19 = categoryAxis18.getLabelAngle();
        categoryAxis18.setLowerMargin((double) 0);
        categoryAxis18.setLabel("hi!");
        categoryAxis18.setTickMarksVisible(true);
        org.jfree.chart.event.AxisChangeListener axisChangeListener26 = null;
        categoryAxis18.addChangeListener(axisChangeListener26);
        int int28 = categoryAxis18.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = null;
        numberAxis30.setMarkerBand(markerAxisBand31);
        org.jfree.data.Range range34 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = new org.jfree.chart.block.RectangleConstraint((double) 0, range34);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = rectangleConstraint35.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint38 = rectangleConstraint37.toUnconstrainedWidth();
        boolean boolean39 = numberAxis30.equals((java.lang.Object) rectangleConstraint38);
        org.jfree.chart.util.Layer layer40 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo41 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo41);
        try {
            statisticalBarRenderer0.drawAnnotations(graphics2D15, rectangle2D16, categoryAxis18, (org.jfree.chart.axis.ValueAxis) numberAxis30, layer40, plotRenderingInfo42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(rectangleConstraint37);
        org.junit.Assert.assertNotNull(rectangleConstraint38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("ThreadContext");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name ThreadContext, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.awt.Paint paint0 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        java.awt.Shape shape2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        double[] doubleArray12 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray19 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray26 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray33 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray40 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray47 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray48 = new double[][] { doubleArray12, doubleArray19, doubleArray26, doubleArray33, doubleArray40, doubleArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray48);
        org.jfree.data.general.PieDataset pieDataset51 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset49, (int) (short) 0);
        legendItemEntity3.setDataset((org.jfree.data.general.Dataset) pieDataset51);
        org.jfree.data.general.PieDataset pieDataset55 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset51, (java.lang.Comparable) (-1.0d), 0.2d);
        org.jfree.data.category.CategoryDataset categoryDataset56 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) "RectangleConstraintType.RANGE", (org.jfree.data.KeyedValues) pieDataset51);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent57 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) paint0, (org.jfree.data.general.Dataset) categoryDataset56);
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNotNull(pieDataset51);
        org.junit.Assert.assertNotNull(pieDataset55);
        org.junit.Assert.assertNotNull(categoryDataset56);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("RangeType.FULL");
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setForegroundAlpha((float) (-1));
        org.jfree.chart.LegendItemCollection legendItemCollection3 = categoryPlot0.getLegendItems();
        categoryPlot0.configureDomainAxes();
        org.junit.Assert.assertNotNull(legendItemCollection3);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.lang.String str1 = verticalAlignment0.toString();
        org.jfree.chart.block.FlowArrangement flowArrangement2 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement2.clear();
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        double double8 = legendTitle7.getHeight();
        flowArrangement2.add((org.jfree.chart.block.Block) legendTitle5, (java.lang.Object) double8);
        legendTitle5.setWidth((double) (byte) -1);
        java.awt.Paint paint12 = legendTitle5.getItemPaint();
        boolean boolean13 = verticalAlignment0.equals((java.lang.Object) paint12);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand20 = null;
        numberAxis19.setMarkerBand(markerAxisBand20);
        java.awt.Stroke stroke22 = numberAxis19.getTickMarkStroke();
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis19.setUpArrow(shape24);
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape24, (double) (byte) 10, 1.0E-8d);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand31 = null;
        numberAxis30.setMarkerBand(markerAxisBand31);
        java.awt.Stroke stroke33 = numberAxis30.getTickMarkStroke();
        java.awt.Color color35 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color36 = java.awt.Color.getColor("", color35);
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "hi!", shape28, stroke33, (java.awt.Paint) color35);
        java.awt.Shape shape38 = legendItem37.getShape();
        boolean boolean39 = verticalAlignment0.equals((java.lang.Object) legendItem37);
        org.jfree.data.general.Dataset dataset40 = legendItem37.getDataset();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.CENTER" + "'", str1.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(dataset40);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Shape[] shapeArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        boolean boolean2 = datasetRenderingOrder0.equals((java.lang.Object) shapeArray1);
        java.lang.String str3 = datasetRenderingOrder0.toString();
        java.lang.String str4 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(shapeArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str3.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str4.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.jfree.chart.text.TextBlock textBlock2 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean6 = textAnchor4.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.CategoryTick categoryTick8 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 14.0d, textBlock2, textBlockAnchor3, textAnchor4, 14.0d);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double11 = categoryAxis10.getLabelAngle();
        categoryAxis10.setLowerMargin((double) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color16 = java.awt.Color.RED;
        categoryAxis15.setLabelPaint((java.awt.Paint) color16);
        categoryAxis15.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint20 = categoryAxis15.getTickLabelPaint();
        java.awt.Stroke stroke21 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder23 = new org.jfree.chart.block.LineBorder(paint20, stroke21, rectangleInsets22);
        categoryAxis10.setAxisLineStroke(stroke21);
        boolean boolean25 = categoryTick8.equals((java.lang.Object) stroke21);
        boolean boolean26 = rectangleAnchor0.equals((java.lang.Object) categoryTick8);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        numberAxis1.setLabelURL("LGPL");
        numberAxis1.setAutoRangeStickyZero(false);
        numberAxis1.setLabelAngle((double) 10.0f);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        java.awt.Paint paint3 = valueMarker1.getOutlinePaint();
        java.awt.Paint paint4 = valueMarker1.getLabelPaint();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = valueMarker6.getLabelOffsetType();
        java.lang.String str8 = lengthAdjustmentType7.toString();
        valueMarker1.setLabelOffsetType(lengthAdjustmentType7);
        java.awt.Stroke stroke10 = valueMarker1.getOutlineStroke();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "CONTRACT" + "'", str8.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        boolean boolean5 = itemLabelAnchor2.equals((java.lang.Object) legendTitle4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color8 = java.awt.Color.RED;
        categoryAxis7.setLabelPaint((java.awt.Paint) color8);
        categoryAxis7.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint12 = categoryAxis7.getTickLabelPaint();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder15 = new org.jfree.chart.block.LineBorder(paint12, stroke13, rectangleInsets14);
        legendTitle4.setFrame((org.jfree.chart.block.BlockFrame) lineBorder15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = new org.jfree.chart.axis.AxisSpace();
        axisSpace17.setBottom((double) '#');
        java.lang.String str20 = axisSpace17.toString();
        double double21 = axisSpace17.getBottom();
        org.jfree.chart.axis.AxisSpace axisSpace23 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisSpace23.add(0.0d, rectangleEdge25);
        boolean boolean27 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge25);
        axisSpace17.add(0.05d, rectangleEdge25);
        legendTitle4.setLegendItemGraphicEdge(rectangleEdge25);
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis1, rectangleEdge25);
        java.util.List list31 = axisCollection0.getAxesAtBottom();
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 35.0d + "'", double21 == 35.0d);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(list31);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        org.jfree.data.Range range5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) 0, range5);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint8.toUnconstrainedWidth();
        boolean boolean10 = numberAxis1.equals((java.lang.Object) rectangleConstraint9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand13 = null;
        numberAxis12.setMarkerBand(markerAxisBand13);
        java.awt.Stroke stroke15 = numberAxis12.getTickMarkStroke();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis12.setUpArrow(shape17);
        numberAxis1.setUpArrow(shape17);
        boolean boolean20 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.setLowerBound((double) 0L);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = null;
        numberAxis6.setMarkerBand(markerAxisBand7);
        java.awt.Stroke stroke9 = numberAxis6.getTickMarkStroke();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis6.setUpArrow(shape11);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color18 = java.awt.Color.RED;
        categoryAxis17.setLabelPaint((java.awt.Paint) color18);
        float[] floatArray24 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray25 = color18.getRGBColorComponents(floatArray24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape28);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity32 = new org.jfree.chart.entity.TickLabelEntity(shape28, "", "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity35 = new org.jfree.chart.entity.TickLabelEntity(shape28, "hi!", "RectangleConstraintType.RANGE");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke37 = defaultDrawingSupplier36.getNextOutlineStroke();
        java.awt.Color color38 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("", "ThreadContext", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "DatasetRenderingOrder.FORWARD", true, shape11, true, (java.awt.Paint) color14, true, (java.awt.Paint) color18, stroke26, false, shape28, stroke37, (java.awt.Paint) color38);
        java.awt.Paint paint40 = legendItem39.getLinePaint();
        java.awt.Paint paint41 = legendItem39.getLinePaint();
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("NOID");
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.FORWARD");
        java.lang.Comparable comparable2 = null;
        try {
            java.awt.Font font3 = categoryAxis1.getTickLabelFont(comparable2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.clear();
        blockContainer0.setHeight(9.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.CENTER" + "'", str1.equals("ItemLabelAnchor.CENTER"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.clear();
        java.awt.Shape shape2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color9 = java.awt.Color.RED;
        categoryAxis8.setLabelPaint((java.awt.Paint) color9);
        float[] floatArray15 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray16 = color9.getRGBColorComponents(floatArray15);
        org.jfree.chart.title.LegendGraphic legendGraphic17 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color9);
        blockContainer0.add((org.jfree.chart.block.Block) legendGraphic17);
        java.awt.Shape shape19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape19, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color26 = java.awt.Color.RED;
        categoryAxis25.setLabelPaint((java.awt.Paint) color26);
        float[] floatArray32 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray33 = color26.getRGBColorComponents(floatArray32);
        org.jfree.chart.title.LegendGraphic legendGraphic34 = new org.jfree.chart.title.LegendGraphic(shape23, (java.awt.Paint) color26);
        legendGraphic17.setOutlinePaint((java.awt.Paint) color26);
        java.awt.Stroke stroke36 = legendGraphic17.getLineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double39 = rectangleInsets37.trimWidth((double) 1L);
        double double41 = rectangleInsets37.trimWidth((double) 1L);
        legendGraphic17.setPadding(rectangleInsets37);
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke45 = valueMarker44.getOutlineStroke();
        java.awt.Paint paint46 = valueMarker44.getOutlinePaint();
        java.awt.Stroke stroke47 = valueMarker44.getStroke();
        boolean boolean48 = legendGraphic17.equals((java.lang.Object) valueMarker44);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition49 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition50 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean51 = categoryLabelPosition49.equals((java.lang.Object) categoryLabelPosition50);
        java.lang.Class<?> wildcardClass52 = categoryLabelPosition49.getClass();
        try {
            java.util.EventListener[] eventListenerArray53 = valueMarker44.getListeners((java.lang.Class) wildcardClass52);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Lorg.jfree.chart.axis.CategoryLabelPosition; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNull(stroke36);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + (-7.0d) + "'", double39 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + (-7.0d) + "'", double41 == (-7.0d));
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(wildcardClass52);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double4 = categoryAxis3.getLabelAngle();
        java.awt.Font font6 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 10.0d);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("-3,-3,3,3", font6);
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("ThreadContext", font6);
        labelBlock8.setPadding((-7.8d), Double.NaN, (double) 8, (double) 10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = defaultStatisticalCategoryDataset0.getRangeBounds(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setForegroundAlpha((float) (-1));
        int int6 = categoryPlot3.getWeight();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        java.util.List list8 = categoryPlot3.getCategoriesForAxis(categoryAxis7);
        categoryPlot3.clearAnnotations();
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot3.setOrientation(plotOrientation10);
        defaultStatisticalCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot3);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(plotOrientation10);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double3 = categoryAxis2.getLabelAngle();
        categoryAxis2.setLowerMargin((double) 0);
        categoryAxis2.setUpperMargin(0.0d);
        java.lang.String str8 = categoryAxis2.getLabel();
        double double9 = categoryAxis2.getUpperMargin();
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        double double13 = legendTitle12.getWidth();
        legendTitle12.setHeight((double) (byte) 10);
        java.awt.Font font16 = legendTitle12.getItemFont();
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("", font16);
        categoryAxis2.setTickLabelFont(font16);
        boolean boolean19 = legendItemCollection0.equals((java.lang.Object) categoryAxis2);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = null;
        try {
            legendItemCollection0.addAll(legendItemCollection20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 'a', "DatasetRenderingOrder.FORWARD", textAnchor3, textAnchor4, 4.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double9 = rectangleInsets7.trimWidth((double) 1L);
        double double11 = rectangleInsets7.trimWidth((double) 1L);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder(rectangleInsets7, (java.awt.Paint) color12);
        boolean boolean14 = numberTick6.equals((java.lang.Object) rectangleInsets7);
        double double16 = rectangleInsets7.calculateLeftInset((double) 10.0f);
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-7.0d) + "'", double9 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-7.0d) + "'", double11 == (-7.0d));
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.util.Iterator iterator1 = legendItemCollection0.iterator();
        try {
            org.jfree.chart.LegendItem legendItem3 = legendItemCollection0.get(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iterator1);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paintArray0, jFreeChart1, chartChangeEventType2);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        chartChangeEvent3.setType(chartChangeEventType4);
        java.awt.Paint[] paintArray6 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) paintArray6, jFreeChart7, chartChangeEventType8);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        chartChangeEvent9.setType(chartChangeEventType10);
        chartChangeEvent3.setType(chartChangeEventType10);
        org.jfree.chart.JFreeChart jFreeChart13 = chartChangeEvent3.getChart();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(chartChangeEventType8);
        org.junit.Assert.assertNotNull(chartChangeEventType10);
        org.junit.Assert.assertNull(jFreeChart13);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color5 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("ThreadContext", font4, (java.awt.Paint) color5);
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font4);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!", font4);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.lang.Object obj12 = textTitle8.draw(graphics2D9, rectangle2D10, (java.lang.Object) (byte) 100);
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color15 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("ThreadContext", font14, (java.awt.Paint) color15);
        textTitle8.setFont(font14);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("RangeType.FULL", font14);
        java.lang.String str19 = textTitle18.getURLText();
        java.lang.String str20 = textTitle18.getID();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setForegroundAlpha((float) (-1));
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent3 = null;
        categoryPlot0.markerChanged(markerChangeEvent3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double6 = statisticalBarRenderer5.getMinimumBarLength();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = statisticalBarRenderer5.getSeriesItemLabelGenerator((-2));
        int int9 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer5);
        boolean boolean10 = categoryPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat5 = numberAxis1.getNumberFormatOverride();
        numberAxis1.setTickMarkOutsideLength(0.0f);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(numberFormat5);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        java.awt.Font font4 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 10.0d);
        double double5 = categoryAxis1.getLabelAngle();
        java.awt.Shape shape6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color13 = java.awt.Color.RED;
        categoryAxis12.setLabelPaint((java.awt.Paint) color13);
        float[] floatArray19 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray20 = color13.getRGBColorComponents(floatArray19);
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape10, (java.awt.Paint) color13);
        java.awt.Shape shape22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape22, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color29 = java.awt.Color.RED;
        categoryAxis28.setLabelPaint((java.awt.Paint) color29);
        float[] floatArray35 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray36 = color29.getRGBColorComponents(floatArray35);
        org.jfree.chart.title.LegendGraphic legendGraphic37 = new org.jfree.chart.title.LegendGraphic(shape26, (java.awt.Paint) color29);
        legendGraphic21.setLinePaint((java.awt.Paint) color29);
        boolean boolean39 = categoryAxis1.equals((java.lang.Object) legendGraphic21);
        legendGraphic21.setLineVisible(false);
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int43 = color42.getBlue();
        legendGraphic21.setLinePaint((java.awt.Paint) color42);
        legendGraphic21.setShapeFilled(false);
        java.lang.Object obj47 = legendGraphic21.clone();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 255 + "'", int43 == 255);
        org.junit.Assert.assertNotNull(obj47);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getLGPL();
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color5 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("ThreadContext", font4, (java.awt.Paint) color5);
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font4);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!", font4);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.lang.Object obj12 = textTitle8.draw(graphics2D9, rectangle2D10, (java.lang.Object) (byte) 100);
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color15 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("ThreadContext", font14, (java.awt.Paint) color15);
        textTitle8.setFont(font14);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("RangeType.FULL", font14);
        java.lang.String str19 = textTitle18.getURLText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine();
        java.awt.Font font23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color24 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment25 = new org.jfree.chart.text.TextFragment("ThreadContext", font23, (java.awt.Paint) color24);
        textLine21.addFragment(textFragment25);
        boolean boolean27 = horizontalAlignment20.equals((java.lang.Object) textFragment25);
        textTitle18.setTextAlignment(horizontalAlignment20);
        java.awt.Font font32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color33 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment34 = new org.jfree.chart.text.TextFragment("ThreadContext", font32, (java.awt.Paint) color33);
        org.jfree.chart.text.TextLine textLine35 = new org.jfree.chart.text.TextLine("", font32);
        java.awt.Font font37 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color38 = java.awt.Color.MAGENTA;
        int int39 = color38.getRed();
        org.jfree.chart.text.TextFragment textFragment41 = new org.jfree.chart.text.TextFragment("hi!", font37, (java.awt.Paint) color38, (float) 'a');
        org.jfree.chart.text.TextBlock textBlock42 = org.jfree.chart.text.TextUtilities.createTextBlock("HorizontalAlignment.RIGHT", font32, (java.awt.Paint) color38);
        textTitle18.setFont(font32);
        textTitle18.setURLText("ItemLabelAnchor.CENTER");
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 255 + "'", int39 == 255);
        org.junit.Assert.assertNotNull(textBlock42);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = null;
        numberAxis6.setMarkerBand(markerAxisBand7);
        java.awt.Stroke stroke9 = numberAxis6.getTickMarkStroke();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis6.setUpArrow(shape11);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color18 = java.awt.Color.RED;
        categoryAxis17.setLabelPaint((java.awt.Paint) color18);
        float[] floatArray24 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray25 = color18.getRGBColorComponents(floatArray24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape28);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity32 = new org.jfree.chart.entity.TickLabelEntity(shape28, "", "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity35 = new org.jfree.chart.entity.TickLabelEntity(shape28, "hi!", "RectangleConstraintType.RANGE");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke37 = defaultDrawingSupplier36.getNextOutlineStroke();
        java.awt.Color color38 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("", "ThreadContext", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "DatasetRenderingOrder.FORWARD", true, shape11, true, (java.awt.Paint) color14, true, (java.awt.Paint) color18, stroke26, false, shape28, stroke37, (java.awt.Paint) color38);
        java.awt.Paint paint40 = legendItem39.getOutlinePaint();
        java.awt.Paint paint41 = legendItem39.getFillPaint();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer42 = legendItem39.getFillPaintTransformer();
        java.awt.Stroke stroke43 = legendItem39.getLineStroke();
        legendItem39.setSeriesIndex((int) (byte) 1);
        boolean boolean46 = legendItem39.isShapeVisible();
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(gradientPaintTransformer42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        legendTitle1.setHeight((double) (byte) 10);
        java.awt.Font font5 = legendTitle1.getItemFont();
        org.jfree.chart.block.BlockContainer blockContainer6 = legendTitle1.getItemContainer();
        org.jfree.chart.LegendItemSource legendItemSource7 = null;
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle(legendItemSource7);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = legendTitle8.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor9, textBlockAnchor10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color14 = java.awt.Color.RED;
        categoryAxis13.setLabelPaint((java.awt.Paint) color14);
        categoryAxis13.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint18 = categoryAxis13.getTickLabelPaint();
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder(paint18, stroke19, rectangleInsets20);
        java.awt.Stroke stroke22 = lineBorder21.getStroke();
        java.awt.Paint paint23 = lineBorder21.getPaint();
        boolean boolean24 = rectangleAnchor9.equals((java.lang.Object) paint23);
        legendTitle1.setLegendItemGraphicAnchor(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(blockContainer6);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey((int) 'a');
        java.lang.Comparable comparable3 = null;
        keyedObjects0.addObject(comparable3, (java.lang.Object) 1);
        int int6 = keyedObjects0.getItemCount();
        org.junit.Assert.assertNull(comparable2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
//        java.util.ResourceBundle.clearCache(classLoader0);
//        java.util.ResourceBundle.clearCache(classLoader0);
//        org.junit.Assert.assertNotNull(classLoader0);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        numberAxis1.setLabelURL("LGPL");
        numberAxis1.resizeRange((double) 10L, (double) 100);
        numberAxis1.setNegativeArrowVisible(true);
        double double11 = numberAxis1.getLowerBound();
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 95.0d + "'", double11 == 95.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean7 = categoryLabelPosition5.equals((java.lang.Object) categoryLabelPosition6);
        org.jfree.chart.text.TextAnchor textAnchor8 = categoryLabelPosition5.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions4, categoryLabelPosition5);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition10 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions11 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean14 = categoryLabelPosition12.equals((java.lang.Object) categoryLabelPosition13);
        org.jfree.chart.text.TextAnchor textAnchor15 = categoryLabelPosition12.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions11, categoryLabelPosition12);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition17 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition18 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean19 = categoryLabelPosition17.equals((java.lang.Object) categoryLabelPosition18);
        org.jfree.chart.text.TextAnchor textAnchor20 = categoryLabelPosition18.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions21 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition5, categoryLabelPosition10, categoryLabelPosition12, categoryLabelPosition18);
        java.lang.Object obj22 = textTitle1.draw(graphics2D2, rectangle2D3, (java.lang.Object) categoryLabelPosition18);
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(categoryLabelPositions11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(textAnchor20);
        org.junit.Assert.assertNull(obj22);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean2 = categoryLabelPosition0.equals((java.lang.Object) categoryLabelPosition1);
        org.jfree.chart.text.TextAnchor textAnchor3 = categoryLabelPosition0.getRotationAnchor();
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke6 = valueMarker5.getOutlineStroke();
        boolean boolean7 = categoryLabelPosition0.equals((java.lang.Object) valueMarker5);
        valueMarker5.setValue((double) 100L);
        try {
            valueMarker5.setAlpha((float) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke2 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke5 = valueMarker4.getOutlineStroke();
        statisticalBarRenderer0.setErrorIndicatorStroke(stroke5);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = statisticalBarRenderer7.getPositiveItemLabelPosition((int) '#', (int) (byte) -1);
        statisticalBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition10, false);
        double double13 = statisticalBarRenderer0.getItemLabelAnchorOffset();
        java.awt.Paint paint15 = statisticalBarRenderer0.lookupSeriesOutlinePaint(4);
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        int int3 = java.awt.Color.HSBtoRGB((float) (byte) 10, (float) 0L, (float) 0L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("CONTRACT");
        java.awt.Graphics2D graphics2D2 = null;
        try {
            org.jfree.chart.util.Size2D size2D3 = textLine1.calculateDimensions(graphics2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        categoryAxis1.setLowerMargin((double) 0);
        categoryAxis1.setLabel("hi!");
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) (short) 0, "java.awt.Color[r=192,g=192,b=0]");
        categoryAxis1.setTickLabelsVisible(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = categoryPlot0.getColumnRenderingOrder();
        categoryPlot0.clearAnnotations();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        categoryPlot0.setRenderer((int) (byte) 1, categoryItemRenderer4);
        org.junit.Assert.assertNotNull(sortOrder1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("ThreadContext", "SortOrder.DESCENDING", "CONTRACT", "[size=10]");
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setLeft((double) (byte) -1);
        double double3 = axisSpace0.getTop();
        axisSpace0.setRight((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset45);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double51 = categoryAxis50.getLabelAngle();
        categoryAxis50.setLowerMargin((double) 0);
        categoryAxis50.setLabel("hi!");
        int int56 = categoryAxis50.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis58.setAutoRange(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer61 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator62 = null;
        statisticalBarRenderer61.setBaseItemLabelGenerator(categoryItemLabelGenerator62);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition65 = null;
        statisticalBarRenderer61.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition65, true);
        boolean boolean68 = statisticalBarRenderer61.isDrawBarOutline();
        boolean boolean69 = statisticalBarRenderer61.getAutoPopulateSeriesPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis50, (org.jfree.chart.axis.ValueAxis) numberAxis58, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer61);
        java.lang.Object obj71 = categoryPlot70.clone();
        categoryPlot70.setRangeCrosshairValue((double) (short) 10);
        categoryPlot70.setRangeCrosshairValue(1.0E-8d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(obj71);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("CONTRACT");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.TickType tickType9 = org.jfree.chart.axis.TickType.MINOR;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.NumberTick numberTick15 = new org.jfree.chart.axis.NumberTick(tickType9, (double) 'a', "DatasetRenderingOrder.FORWARD", textAnchor12, textAnchor13, 4.0d);
        org.jfree.chart.text.TextAnchor textAnchor16 = numberTick15.getTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        java.awt.Shape shape19 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D6, (float) (short) 0, (-1.0f), textAnchor16, (double) (-1L), textAnchor18);
        try {
            textLine1.draw(graphics2D2, (float) (byte) 100, 2.0f, textAnchor18, (float) 'a', (float) (byte) 100, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickType9);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNull(shape19);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = defaultDrawingSupplier0.clone();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextStroke();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        numberAxis1.setLabelURL("LGPL");
        numberAxis1.setAutoRangeStickyZero(false);
        java.awt.Font font8 = numberAxis1.getLabelFont();
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalBarRenderer0.getNegativeItemLabelPosition((int) (byte) 0, (int) (byte) -1);
        boolean boolean4 = statisticalBarRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Color color9 = java.awt.Color.getHSBColor((float) (short) -1, (float) (byte) 10, (float) (short) 0);
        statisticalBarRenderer0.setSeriesFillPaint(128, (java.awt.Paint) color9);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.Object obj2 = jFreeChartResources0.getObject("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double7 = rectangleInsets5.trimWidth((double) 1L);
        double double9 = rectangleInsets5.trimWidth((double) 1L);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder(rectangleInsets5, (java.awt.Paint) color10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = blockBorder11.getInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        org.jfree.chart.renderer.RendererState rendererState15 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo14);
        java.awt.geom.Rectangle2D rectangle2D16 = plotRenderingInfo14.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D19 = rectangleInsets12.createOutsetRectangle(rectangle2D16, true, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double22 = rectangleInsets20.trimWidth((double) 1L);
        double double24 = rectangleInsets20.trimWidth((double) 1L);
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder26 = new org.jfree.chart.block.BlockBorder(rectangleInsets20, (java.awt.Paint) color25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = blockBorder26.getInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo28);
        org.jfree.chart.renderer.RendererState rendererState30 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo29);
        java.awt.geom.Rectangle2D rectangle2D31 = plotRenderingInfo29.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets27.createOutsetRectangle(rectangle2D31, true, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot36.setForegroundAlpha((float) (-1));
        int int39 = categoryPlot36.getWeight();
        boolean boolean40 = categoryPlot36.isRangeZoomable();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo43 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo43);
        org.jfree.chart.renderer.RendererState rendererState45 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo44);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = rendererState45.getInfo();
        java.awt.geom.Point2D point2D47 = null;
        categoryPlot36.zoomRangeAxes((double) (byte) 10, (double) (short) 10, plotRenderingInfo46, point2D47);
        try {
            org.jfree.chart.axis.AxisState axisState49 = categoryAxis1.draw(graphics2D3, 97.0d, rectangle2D19, rectangle2D34, rectangleEdge35, plotRenderingInfo46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-7.0d) + "'", double7 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-7.0d) + "'", double9 == (-7.0d));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-7.0d) + "'", double22 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-7.0d) + "'", double24 == (-7.0d));
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(plotRenderingInfo46);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number3 = defaultStatisticalCategoryDataset0.getStdDevValue((java.lang.Comparable) "VerticalAlignment.CENTER", (java.lang.Comparable) (short) 10);
        int int5 = defaultStatisticalCategoryDataset0.getRowIndex((java.lang.Comparable) "hi!");
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setForegroundAlpha((float) (-1));
        defaultStatisticalCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot6);
        java.lang.Number number10 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertEquals((double) number10, Double.NaN, 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 'a', "DatasetRenderingOrder.FORWARD", textAnchor3, textAnchor4, 4.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double9 = rectangleInsets7.trimWidth((double) 1L);
        double double11 = rectangleInsets7.trimWidth((double) 1L);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder(rectangleInsets7, (java.awt.Paint) color12);
        boolean boolean14 = numberTick6.equals((java.lang.Object) rectangleInsets7);
        double double16 = rectangleInsets7.calculateRightOutset(0.5d);
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-7.0d) + "'", double9 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-7.0d) + "'", double11 == (-7.0d));
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = valueMarker2.getLabelOffsetType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker2.setLabelAnchor(rectangleAnchor4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement10 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment6, verticalAlignment7, (double) 255, (double) 1.0f);
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement11.clear();
        double[] doubleArray21 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray28 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray35 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray42 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray49 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray56 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray57 = new double[][] { doubleArray21, doubleArray28, doubleArray35, doubleArray42, doubleArray49, doubleArray56 };
        org.jfree.data.category.CategoryDataset categoryDataset58 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray57);
        org.jfree.data.general.PieDataset pieDataset60 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset58, (int) (short) 0);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer62 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement11, (org.jfree.data.general.Dataset) pieDataset60, (java.lang.Comparable) "ThreadContext");
        org.jfree.chart.block.BlockFrame blockFrame63 = legendItemBlockContainer62.getFrame();
        java.awt.Color color64 = java.awt.Color.BLACK;
        columnArrangement10.add((org.jfree.chart.block.Block) legendItemBlockContainer62, (java.lang.Object) color64);
        valueMarker2.setLabelPaint((java.awt.Paint) color64);
        boolean boolean67 = itemLabelAnchor0.equals((java.lang.Object) valueMarker2);
        org.jfree.chart.axis.TickType tickType68 = org.jfree.chart.axis.TickType.MINOR;
        org.jfree.chart.text.TextAnchor textAnchor71 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor72 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.NumberTick numberTick74 = new org.jfree.chart.axis.NumberTick(tickType68, (double) 'a', "DatasetRenderingOrder.FORWARD", textAnchor71, textAnchor72, 4.0d);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition75 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor72);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(categoryDataset58);
        org.junit.Assert.assertNotNull(pieDataset60);
        org.junit.Assert.assertNotNull(blockFrame63);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(tickType68);
        org.junit.Assert.assertNotNull(textAnchor71);
        org.junit.Assert.assertNotNull(textAnchor72);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getMinimumBarLength();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = statisticalBarRenderer0.getSeriesItemLabelGenerator((-2));
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color7 = java.awt.Color.getColor("", color6);
        java.awt.Color color8 = java.awt.Color.getColor("ThreadContext", color7);
        statisticalBarRenderer0.setBasePaint((java.awt.Paint) color7);
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = null;
        statisticalBarRenderer0.setSeriesURLGenerator((int) (short) 10, categoryURLGenerator13);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        double[] doubleArray10 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray17 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray24 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray31 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray38 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray45 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray46 = new double[][] { doubleArray10, doubleArray17, doubleArray24, doubleArray31, doubleArray38, doubleArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset47, (int) (short) 0);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer51 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) pieDataset49, (java.lang.Comparable) "ThreadContext");
        java.lang.Object obj52 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) legendItemBlockContainer51);
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double56 = categoryAxis55.getLabelAngle();
        java.awt.Font font58 = categoryAxis55.getTickLabelFont((java.lang.Comparable) 10.0d);
        org.jfree.chart.title.TextTitle textTitle59 = new org.jfree.chart.title.TextTitle("-3,-3,3,3", font58);
        boolean boolean60 = legendItemBlockContainer51.equals((java.lang.Object) textTitle59);
        double double61 = legendItemBlockContainer51.getContentXOffset();
        legendItemBlockContainer51.setHeight(0.5d);
        java.awt.Graphics2D graphics2D64 = null;
        org.jfree.data.Range range65 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint67 = new org.jfree.chart.block.RectangleConstraint(range65, (double) 255);
        try {
            org.jfree.chart.util.Size2D size2D68 = legendItemBlockContainer51.arrange(graphics2D64, rectangleConstraint67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset45);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double51 = categoryAxis50.getLabelAngle();
        categoryAxis50.setLowerMargin((double) 0);
        categoryAxis50.setLabel("hi!");
        int int56 = categoryAxis50.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis58.setAutoRange(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer61 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator62 = null;
        statisticalBarRenderer61.setBaseItemLabelGenerator(categoryItemLabelGenerator62);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition65 = null;
        statisticalBarRenderer61.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition65, true);
        boolean boolean68 = statisticalBarRenderer61.isDrawBarOutline();
        boolean boolean69 = statisticalBarRenderer61.getAutoPopulateSeriesPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis50, (org.jfree.chart.axis.ValueAxis) numberAxis58, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer61);
        java.lang.Object obj71 = categoryPlot70.clone();
        categoryPlot70.setRangeCrosshairValue((double) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation75 = categoryPlot70.getDomainAxisLocation(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge76 = categoryPlot70.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(obj71);
        org.junit.Assert.assertNotNull(axisLocation75);
        org.junit.Assert.assertNotNull(rectangleEdge76);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("ThreadContext", "LGPL", "hi!", "ThreadContext");
//        org.jfree.chart.ui.ProjectInfo projectInfo5 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str6 = projectInfo5.getCopyright();
//        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo12 = new org.jfree.chart.ui.BasicProjectInfo("ThreadContext", "ThreadContext", "hi!", "-3,-3,3,3", "");
//        projectInfo5.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo12);
//        basicProjectInfo4.addLibrary((org.jfree.chart.ui.Library) projectInfo5);
//        org.junit.Assert.assertNotNull(projectInfo5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "LGPL" + "'", str6.equals("LGPL"));
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.FlowArrangement flowArrangement1 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement1.clear();
        double[] doubleArray11 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray18 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray25 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray32 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray39 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray46 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray47 = new double[][] { doubleArray11, doubleArray18, doubleArray25, doubleArray32, doubleArray39, doubleArray46 };
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray47);
        org.jfree.data.general.PieDataset pieDataset50 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset48, (int) (short) 0);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer52 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement1, (org.jfree.data.general.Dataset) pieDataset50, (java.lang.Comparable) "ThreadContext");
        java.lang.Comparable comparable53 = legendItemBlockContainer52.getSeriesKey();
        legendItemBlockContainer52.setToolTipText("CONTRACT");
        java.awt.Graphics2D graphics2D56 = null;
        org.jfree.data.Range range58 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint59 = new org.jfree.chart.block.RectangleConstraint((double) ' ', range58);
        double double60 = rectangleConstraint59.getWidth();
        try {
            org.jfree.chart.util.Size2D size2D61 = borderArrangement0.arrange((org.jfree.chart.block.BlockContainer) legendItemBlockContainer52, graphics2D56, rectangleConstraint59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNotNull(pieDataset50);
        org.junit.Assert.assertTrue("'" + comparable53 + "' != '" + "ThreadContext" + "'", comparable53.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 32.0d + "'", double60 == 32.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        java.awt.Shape shape5 = numberAxis1.getRightArrow();
        numberAxis1.setLowerMargin(100.0d);
        numberAxis1.setUpperMargin(100.0d);
        numberAxis1.setVerticalTickLabels(true);
        try {
            numberAxis1.setRangeAboutValue((double) '4', (double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (52.5) <= upper (51.5).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey((int) 'a');
        try {
            keyedObjects0.removeValue((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(comparable2);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset45);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double51 = categoryAxis50.getLabelAngle();
        categoryAxis50.setLowerMargin((double) 0);
        categoryAxis50.setLabel("hi!");
        int int56 = categoryAxis50.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis58.setAutoRange(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer61 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator62 = null;
        statisticalBarRenderer61.setBaseItemLabelGenerator(categoryItemLabelGenerator62);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition65 = null;
        statisticalBarRenderer61.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition65, true);
        boolean boolean68 = statisticalBarRenderer61.isDrawBarOutline();
        boolean boolean69 = statisticalBarRenderer61.getAutoPopulateSeriesPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis50, (org.jfree.chart.axis.ValueAxis) numberAxis58, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer61);
        java.lang.Object obj71 = categoryPlot70.clone();
        categoryPlot70.clearRangeMarkers();
        org.jfree.chart.plot.PlotOrientation plotOrientation73 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot70.setOrientation(plotOrientation73);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(obj71);
        org.junit.Assert.assertNotNull(plotOrientation73);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = blockBorder1.getInsets();
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets2.getUnitType();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(unitType3);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        categoryPlot0.setForegroundAlpha((float) (-1));
//        int int3 = categoryPlot0.getWeight();
//        boolean boolean4 = categoryPlot0.isRangeZoomable();
//        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
//        java.awt.Stroke stroke7 = valueMarker6.getOutlineStroke();
//        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
//        valueMarker6.setLabelOffsetType(lengthAdjustmentType8);
//        org.jfree.chart.util.Layer layer10 = null;
//        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker6, layer10);
//        org.jfree.chart.ui.ProjectInfo projectInfo12 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str13 = projectInfo12.getCopyright();
//        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo19 = new org.jfree.chart.ui.BasicProjectInfo("ThreadContext", "ThreadContext", "hi!", "-3,-3,3,3", "");
//        projectInfo12.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo19);
//        boolean boolean21 = categoryPlot0.equals((java.lang.Object) projectInfo12);
//        org.jfree.chart.axis.AxisSpace axisSpace22 = categoryPlot0.getFixedDomainAxisSpace();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertNotNull(stroke7);
//        org.junit.Assert.assertNotNull(lengthAdjustmentType8);
//        org.junit.Assert.assertNotNull(projectInfo12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "LGPL" + "'", str13.equals("LGPL"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNull(axisSpace22);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = shapeList0.getShape((-1));
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine();
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color7 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("ThreadContext", font6, (java.awt.Paint) color7);
        textLine4.addFragment(textFragment8);
        boolean boolean10 = horizontalAlignment3.equals((java.lang.Object) textFragment8);
        boolean boolean11 = shapeList0.equals((java.lang.Object) textFragment8);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis13.setUpperBound((double) 1L);
        java.awt.Font font16 = numberAxis13.getLabelFont();
        boolean boolean17 = shapeList0.equals((java.lang.Object) font16);
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        java.awt.Stroke stroke4 = numberAxis1.getTickMarkStroke();
        numberAxis1.setUpperMargin((double) (-1));
        boolean boolean7 = numberAxis1.isPositiveArrowVisible();
        java.lang.Object obj8 = numberAxis1.clone();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        statisticalBarRenderer9.setBaseItemLabelGenerator(categoryItemLabelGenerator10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = null;
        statisticalBarRenderer9.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition13, true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke17 = defaultDrawingSupplier16.getNextOutlineStroke();
        java.awt.Stroke stroke18 = defaultDrawingSupplier16.getNextStroke();
        statisticalBarRenderer9.setErrorIndicatorStroke(stroke18);
        java.awt.Paint paint22 = statisticalBarRenderer9.getItemFillPaint((int) ' ', (int) (short) 1);
        numberAxis1.setTickLabelPaint(paint22);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.FlowArrangement flowArrangement1 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement1.clear();
        double[] doubleArray11 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray18 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray25 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray32 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray39 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray46 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray47 = new double[][] { doubleArray11, doubleArray18, doubleArray25, doubleArray32, doubleArray39, doubleArray46 };
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray47);
        org.jfree.data.general.PieDataset pieDataset50 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset48, (int) (short) 0);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer52 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement1, (org.jfree.data.general.Dataset) pieDataset50, (java.lang.Comparable) "ThreadContext");
        java.lang.Comparable comparable53 = legendItemBlockContainer52.getSeriesKey();
        legendItemBlockContainer52.setToolTipText("CONTRACT");
        java.awt.Graphics2D graphics2D56 = null;
        org.jfree.data.Range range58 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint59 = new org.jfree.chart.block.RectangleConstraint((double) 0, range58);
        try {
            org.jfree.chart.util.Size2D size2D60 = flowArrangement0.arrange((org.jfree.chart.block.BlockContainer) legendItemBlockContainer52, graphics2D56, rectangleConstraint59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNotNull(pieDataset50);
        org.junit.Assert.assertTrue("'" + comparable53 + "' != '" + "ThreadContext" + "'", comparable53.equals("ThreadContext"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset45);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double51 = categoryAxis50.getLabelAngle();
        categoryAxis50.setLowerMargin((double) 0);
        categoryAxis50.setLabel("hi!");
        int int56 = categoryAxis50.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis58.setAutoRange(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer61 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator62 = null;
        statisticalBarRenderer61.setBaseItemLabelGenerator(categoryItemLabelGenerator62);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition65 = null;
        statisticalBarRenderer61.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition65, true);
        boolean boolean68 = statisticalBarRenderer61.isDrawBarOutline();
        boolean boolean69 = statisticalBarRenderer61.getAutoPopulateSeriesPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis50, (org.jfree.chart.axis.ValueAxis) numberAxis58, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer61);
        org.jfree.chart.LegendItemSource legendItemSource72 = null;
        org.jfree.chart.title.LegendTitle legendTitle73 = new org.jfree.chart.title.LegendTitle(legendItemSource72);
        double double74 = legendTitle73.getWidth();
        legendTitle73.setHeight((double) (byte) 10);
        java.awt.Font font77 = legendTitle73.getItemFont();
        java.awt.Stroke stroke78 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean79 = legendTitle73.equals((java.lang.Object) stroke78);
        statisticalBarRenderer61.setSeriesOutlineStroke((int) (byte) 10, stroke78);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(font77);
        org.junit.Assert.assertNotNull(stroke78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = shapeList0.getShape((-1));
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine();
        java.awt.Font font6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color7 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("ThreadContext", font6, (java.awt.Paint) color7);
        textLine4.addFragment(textFragment8);
        boolean boolean10 = horizontalAlignment3.equals((java.lang.Object) textFragment8);
        boolean boolean11 = shapeList0.equals((java.lang.Object) textFragment8);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis14.setUpperBound((double) 1L);
        boolean boolean17 = numberAxis14.getAutoRangeIncludesZero();
        java.awt.Shape shape18 = numberAxis14.getRightArrow();
        shapeList0.setShape(128, shape18);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand28 = null;
        numberAxis27.setMarkerBand(markerAxisBand28);
        java.awt.Stroke stroke30 = numberAxis27.getTickMarkStroke();
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis27.setUpArrow(shape32);
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color39 = java.awt.Color.RED;
        categoryAxis38.setLabelPaint((java.awt.Paint) color39);
        float[] floatArray45 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray46 = color39.getRGBColorComponents(floatArray45);
        java.awt.Stroke stroke47 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape49 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity50 = new org.jfree.chart.entity.LegendItemEntity(shape49);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity53 = new org.jfree.chart.entity.TickLabelEntity(shape49, "", "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity56 = new org.jfree.chart.entity.TickLabelEntity(shape49, "hi!", "RectangleConstraintType.RANGE");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier57 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke58 = defaultDrawingSupplier57.getNextOutlineStroke();
        java.awt.Color color59 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem60 = new org.jfree.chart.LegendItem("", "ThreadContext", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "DatasetRenderingOrder.FORWARD", true, shape32, true, (java.awt.Paint) color35, true, (java.awt.Paint) color39, stroke47, false, shape49, stroke58, (java.awt.Paint) color59);
        shapeList0.setShape(0, shape32);
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(color59);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        statisticalBarRenderer1.setBaseItemLabelGenerator(categoryItemLabelGenerator2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        statisticalBarRenderer1.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition5, true);
        double double8 = statisticalBarRenderer1.getBase();
        double[] doubleArray17 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray24 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray31 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray38 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray45 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray52 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray53 = new double[][] { doubleArray17, doubleArray24, doubleArray31, doubleArray38, doubleArray45, doubleArray52 };
        org.jfree.data.category.CategoryDataset categoryDataset54 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray53);
        org.jfree.data.general.PieDataset pieDataset56 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset54, (int) (short) 0);
        org.jfree.data.Range range57 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset54);
        org.jfree.data.Range range58 = statisticalBarRenderer1.findRangeBounds(categoryDataset54);
        boolean boolean59 = lengthAdjustmentType0.equals((java.lang.Object) categoryDataset54);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(categoryDataset54);
        org.junit.Assert.assertNotNull(pieDataset56);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = null;
        numberAxis6.setMarkerBand(markerAxisBand7);
        java.awt.Stroke stroke9 = numberAxis6.getTickMarkStroke();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis6.setUpArrow(shape11);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color18 = java.awt.Color.RED;
        categoryAxis17.setLabelPaint((java.awt.Paint) color18);
        float[] floatArray24 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray25 = color18.getRGBColorComponents(floatArray24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape28);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity32 = new org.jfree.chart.entity.TickLabelEntity(shape28, "", "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity35 = new org.jfree.chart.entity.TickLabelEntity(shape28, "hi!", "RectangleConstraintType.RANGE");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke37 = defaultDrawingSupplier36.getNextOutlineStroke();
        java.awt.Color color38 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("", "ThreadContext", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "DatasetRenderingOrder.FORWARD", true, shape11, true, (java.awt.Paint) color14, true, (java.awt.Paint) color18, stroke26, false, shape28, stroke37, (java.awt.Paint) color38);
        java.awt.Paint paint40 = legendItem39.getLinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double43 = categoryAxis42.getLabelAngle();
        java.awt.Font font45 = categoryAxis42.getTickLabelFont((java.lang.Comparable) 10.0d);
        double double46 = categoryAxis42.getLabelAngle();
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color49 = java.awt.Color.RED;
        categoryAxis48.setLabelPaint((java.awt.Paint) color49);
        categoryAxis48.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint53 = categoryAxis48.getTickLabelPaint();
        java.awt.Stroke stroke54 = categoryAxis48.getTickMarkStroke();
        categoryAxis42.setTickMarkStroke(stroke54);
        boolean boolean56 = legendItem39.equals((java.lang.Object) categoryAxis42);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo59 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo59);
        org.jfree.chart.renderer.RendererState rendererState61 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo60);
        java.awt.geom.Rectangle2D rectangle2D62 = plotRenderingInfo60.getDataArea();
        org.jfree.chart.axis.CategoryAxis categoryAxis65 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double66 = categoryAxis65.getLabelAngle();
        java.awt.Font font68 = categoryAxis65.getTickLabelFont((java.lang.Comparable) 10.0d);
        org.jfree.chart.title.TextTitle textTitle69 = new org.jfree.chart.title.TextTitle("-3,-3,3,3", font68);
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = textTitle69.getPosition();
        java.awt.Paint paint71 = textTitle69.getPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = org.jfree.chart.util.RectangleEdge.RIGHT;
        textTitle69.setPosition(rectangleEdge72);
        double double74 = categoryAxis42.getCategoryMiddle(0, 3, rectangle2D62, rectangleEdge72);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(font68);
        org.junit.Assert.assertNotNull(rectangleEdge70);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertNotNull(rectangleEdge72);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 0, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint4.toUnconstrainedWidth();
        org.jfree.data.Range range6 = rectangleConstraint4.getHeightRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint4.toFixedHeight((double) 1.0f);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        org.jfree.data.Range range5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) 0, range5);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint8.toUnconstrainedWidth();
        boolean boolean10 = numberAxis1.equals((java.lang.Object) rectangleConstraint9);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        numberAxis1.setAutoRange(false);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke3 = null;
        try {
            statisticalBarRenderer0.setSeriesOutlineStroke((-2), stroke3, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition1);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        categoryAxis1.setLowerMargin((double) 0);
        categoryAxis1.setUpperMargin(0.0d);
        java.lang.String str7 = categoryAxis1.getLabel();
        double double8 = categoryAxis1.getUpperMargin();
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke12 = valueMarker11.getOutlineStroke();
        java.awt.Paint paint13 = valueMarker11.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 10.0d, paint13);
        categoryAxis1.setMaximumCategoryLabelLines(1);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color19 = java.awt.Color.MAGENTA;
        categoryAxis18.setTickMarkPaint((java.awt.Paint) color19);
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color19);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions22 = categoryAxis1.getCategoryLabelPositions();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(categoryLabelPositions22);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        plotRenderingInfo1.setDataArea(rectangle2D2);
        int int4 = plotRenderingInfo1.getSubplotCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = categoryPlot0.getDomainAxis(2);
        categoryPlot0.setAnchorValue(35.0d, true);
        categoryPlot0.setBackgroundImageAlignment((int) (byte) 10);
        org.junit.Assert.assertNull(categoryAxis2);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker1.setLabelAnchor(rectangleAnchor3);
        java.awt.Color color5 = java.awt.Color.blue;
        valueMarker1.setLabelPaint((java.awt.Paint) color5);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset45);
        boolean boolean51 = range48.intersects((double) 1.0f, 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint53 = new org.jfree.chart.block.RectangleConstraint(range48, 2.0d);
        org.jfree.chart.block.BlockContainer blockContainer54 = new org.jfree.chart.block.BlockContainer();
        blockContainer54.clear();
        java.awt.Shape shape56 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape60 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape56, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color63 = java.awt.Color.RED;
        categoryAxis62.setLabelPaint((java.awt.Paint) color63);
        float[] floatArray69 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray70 = color63.getRGBColorComponents(floatArray69);
        org.jfree.chart.title.LegendGraphic legendGraphic71 = new org.jfree.chart.title.LegendGraphic(shape60, (java.awt.Paint) color63);
        blockContainer54.add((org.jfree.chart.block.Block) legendGraphic71);
        java.awt.Shape shape73 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape77 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape73, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis79 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color80 = java.awt.Color.RED;
        categoryAxis79.setLabelPaint((java.awt.Paint) color80);
        float[] floatArray86 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray87 = color80.getRGBColorComponents(floatArray86);
        org.jfree.chart.title.LegendGraphic legendGraphic88 = new org.jfree.chart.title.LegendGraphic(shape77, (java.awt.Paint) color80);
        legendGraphic71.setOutlinePaint((java.awt.Paint) color80);
        java.awt.Stroke stroke90 = legendGraphic71.getLineStroke();
        legendGraphic71.setShapeVisible(true);
        java.awt.Paint paint93 = null;
        legendGraphic71.setOutlinePaint(paint93);
        boolean boolean95 = range48.equals((java.lang.Object) paint93);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(floatArray69);
        org.junit.Assert.assertNotNull(floatArray70);
        org.junit.Assert.assertNotNull(shape73);
        org.junit.Assert.assertNotNull(shape77);
        org.junit.Assert.assertNotNull(color80);
        org.junit.Assert.assertNotNull(floatArray86);
        org.junit.Assert.assertNotNull(floatArray87);
        org.junit.Assert.assertNull(stroke90);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 0, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint4.toUnconstrainedWidth();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = rectangleConstraint4.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint4.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        try {
            java.lang.Object obj3 = jFreeChartResources0.getObject("{0}");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key {0}");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNotNull(strEnumeration1);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        double double3 = legendTitle2.getWidth();
        legendTitle2.setHeight((double) (byte) 10);
        java.awt.Font font6 = legendTitle2.getItemFont();
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("", font6);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color11 = java.awt.Color.RED;
        categoryAxis10.setLabelPaint((java.awt.Paint) color11);
        categoryAxis10.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint15 = categoryAxis10.getTickLabelPaint();
        java.awt.Stroke stroke16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder18 = new org.jfree.chart.block.LineBorder(paint15, stroke16, rectangleInsets17);
        java.awt.Stroke stroke19 = lineBorder18.getStroke();
        java.awt.Paint paint20 = lineBorder18.getPaint();
        boolean boolean21 = categoryLabelPositions8.equals((java.lang.Object) lineBorder18);
        boolean boolean22 = textFragment7.equals((java.lang.Object) lineBorder18);
        java.awt.Paint paint23 = textFragment7.getPaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(categoryLabelPositions8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray2 = null;
        try {
            float[] floatArray3 = color0.getColorComponents(colorSpace1, floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color6 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("ThreadContext", font5, (java.awt.Paint) color6);
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font5);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!", font5);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.lang.Object obj13 = textTitle9.draw(graphics2D10, rectangle2D11, (java.lang.Object) (byte) 100);
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color16 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("ThreadContext", font15, (java.awt.Paint) color16);
        textTitle9.setFont(font15);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("RangeType.FULL", font15);
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color23 = java.awt.Color.getColor("", color22);
        java.awt.Color color24 = java.awt.Color.getColor("ThreadContext", color23);
        org.jfree.chart.axis.AxisSpace axisSpace25 = new org.jfree.chart.axis.AxisSpace();
        axisSpace25.setBottom((double) '#');
        double double28 = axisSpace25.getLeft();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.lang.Object obj31 = null;
        boolean boolean32 = rectangleEdge30.equals(obj31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge30);
        axisSpace25.ensureAtLeast((double) 100, rectangleEdge30);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment35 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor36 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean37 = horizontalAlignment35.equals((java.lang.Object) textAnchor36);
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.lang.String str39 = verticalAlignment38.toString();
        org.jfree.chart.block.FlowArrangement flowArrangement40 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement40.clear();
        org.jfree.chart.LegendItemSource legendItemSource42 = null;
        org.jfree.chart.title.LegendTitle legendTitle43 = new org.jfree.chart.title.LegendTitle(legendItemSource42);
        org.jfree.chart.LegendItemSource legendItemSource44 = null;
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle(legendItemSource44);
        double double46 = legendTitle45.getHeight();
        flowArrangement40.add((org.jfree.chart.block.Block) legendTitle43, (java.lang.Object) double46);
        legendTitle43.setWidth((double) (byte) -1);
        java.awt.Paint paint50 = legendTitle43.getItemPaint();
        boolean boolean51 = verticalAlignment38.equals((java.lang.Object) paint50);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double54 = rectangleInsets52.trimWidth((double) 1L);
        java.lang.String str55 = rectangleInsets52.toString();
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font15, (java.awt.Paint) color24, rectangleEdge30, horizontalAlignment35, verticalAlignment38, rectangleInsets52);
        java.awt.Color color60 = java.awt.Color.getHSBColor((float) 1L, (float) 4, (float) (byte) 10);
        textTitle56.setPaint((java.awt.Paint) color60);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(horizontalAlignment35);
        org.junit.Assert.assertNotNull(textAnchor36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "VerticalAlignment.CENTER" + "'", str39.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + (-7.0d) + "'", double54 == (-7.0d));
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str55.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertNotNull(color60);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        java.lang.String str2 = axisLocation0.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str2.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        java.awt.Stroke stroke4 = numberAxis1.getTickMarkStroke();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis1.setUpArrow(shape6);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape6, (double) (byte) 10, 1.0E-8d);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.clone(shape10);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(128);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color5 = java.awt.Color.RED;
        categoryAxis4.setLabelPaint((java.awt.Paint) color5);
        categoryAxis4.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint9 = categoryAxis4.getTickLabelPaint();
        java.awt.Stroke stroke10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder12 = new org.jfree.chart.block.LineBorder(paint9, stroke10, rectangleInsets11);
        java.awt.Stroke stroke13 = lineBorder12.getStroke();
        java.awt.Paint paint14 = lineBorder12.getPaint();
        objectList1.set((int) (short) 1, (java.lang.Object) paint14);
        java.lang.Object obj17 = objectList1.get(3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(obj17);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor3);
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = legendTitle6.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor7, textBlockAnchor8);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = categoryLabelPosition9.getLabelAnchor();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = null;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean15 = categoryLabelPosition13.equals((java.lang.Object) categoryLabelPosition14);
        org.jfree.chart.text.TextAnchor textAnchor16 = categoryLabelPosition13.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions17 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions12, categoryLabelPosition13);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition18 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions19 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition20 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition21 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean22 = categoryLabelPosition20.equals((java.lang.Object) categoryLabelPosition21);
        org.jfree.chart.text.TextAnchor textAnchor23 = categoryLabelPosition20.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions24 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions19, categoryLabelPosition20);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition25 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition26 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean27 = categoryLabelPosition25.equals((java.lang.Object) categoryLabelPosition26);
        org.jfree.chart.text.TextAnchor textAnchor28 = categoryLabelPosition26.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions29 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition13, categoryLabelPosition18, categoryLabelPosition20, categoryLabelPosition26);
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions30 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition4, categoryLabelPosition9, categoryLabelPosition11, categoryLabelPosition20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'left' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(categoryLabelPositions12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(categoryLabelPositions17);
        org.junit.Assert.assertNotNull(categoryLabelPositions19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertNotNull(categoryLabelPositions24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(textAnchor28);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CONTRACT");
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset45);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double51 = categoryAxis50.getLabelAngle();
        categoryAxis50.setLowerMargin((double) 0);
        categoryAxis50.setLabel("hi!");
        int int56 = categoryAxis50.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis58.setAutoRange(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer61 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator62 = null;
        statisticalBarRenderer61.setBaseItemLabelGenerator(categoryItemLabelGenerator62);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition65 = null;
        statisticalBarRenderer61.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition65, true);
        boolean boolean68 = statisticalBarRenderer61.isDrawBarOutline();
        boolean boolean69 = statisticalBarRenderer61.getAutoPopulateSeriesPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis50, (org.jfree.chart.axis.ValueAxis) numberAxis58, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer61);
        java.lang.Object obj71 = categoryPlot70.clone();
        categoryPlot70.clearRangeMarkers();
        categoryPlot70.setOutlineVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation75 = categoryPlot70.getDomainAxisLocation();
        categoryPlot70.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(obj71);
        org.junit.Assert.assertNotNull(axisLocation75);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        boolean boolean5 = itemLabelAnchor2.equals((java.lang.Object) legendTitle4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color8 = java.awt.Color.RED;
        categoryAxis7.setLabelPaint((java.awt.Paint) color8);
        categoryAxis7.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint12 = categoryAxis7.getTickLabelPaint();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder15 = new org.jfree.chart.block.LineBorder(paint12, stroke13, rectangleInsets14);
        legendTitle4.setFrame((org.jfree.chart.block.BlockFrame) lineBorder15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = new org.jfree.chart.axis.AxisSpace();
        axisSpace17.setBottom((double) '#');
        java.lang.String str20 = axisSpace17.toString();
        double double21 = axisSpace17.getBottom();
        org.jfree.chart.axis.AxisSpace axisSpace23 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisSpace23.add(0.0d, rectangleEdge25);
        boolean boolean27 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge25);
        axisSpace17.add(0.05d, rectangleEdge25);
        legendTitle4.setLegendItemGraphicEdge(rectangleEdge25);
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis1, rectangleEdge25);
        java.util.List list31 = axisCollection0.getAxesAtTop();
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 35.0d + "'", double21 == 35.0d);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(list31);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color6 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("ThreadContext", font5, (java.awt.Paint) color6);
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font5);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!", font5);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.lang.Object obj13 = textTitle9.draw(graphics2D10, rectangle2D11, (java.lang.Object) (byte) 100);
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color16 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("ThreadContext", font15, (java.awt.Paint) color16);
        textTitle9.setFont(font15);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("RangeType.FULL", font15);
        java.lang.String str20 = textTitle19.getURLText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine();
        java.awt.Font font24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color25 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment26 = new org.jfree.chart.text.TextFragment("ThreadContext", font24, (java.awt.Paint) color25);
        textLine22.addFragment(textFragment26);
        boolean boolean28 = horizontalAlignment21.equals((java.lang.Object) textFragment26);
        textTitle19.setTextAlignment(horizontalAlignment21);
        java.awt.Font font34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color35 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment36 = new org.jfree.chart.text.TextFragment("ThreadContext", font34, (java.awt.Paint) color35);
        org.jfree.chart.text.TextLine textLine37 = new org.jfree.chart.text.TextLine("", font34);
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("hi!", font34);
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        java.lang.Object obj42 = textTitle38.draw(graphics2D39, rectangle2D40, (java.lang.Object) (byte) 100);
        java.awt.Font font44 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color45 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment46 = new org.jfree.chart.text.TextFragment("ThreadContext", font44, (java.awt.Paint) color45);
        textTitle38.setFont(font44);
        org.jfree.chart.block.LabelBlock labelBlock48 = new org.jfree.chart.block.LabelBlock("ThreadContext", font44);
        textTitle19.setFont(font44);
        org.jfree.chart.text.TextLine textLine50 = new org.jfree.chart.text.TextLine("ChartEntity: tooltip = ", font44);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNull(obj42);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(color45);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        double double3 = statisticalBarRenderer0.getItemLabelAnchorOffset();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.Axis axis1 = null;
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color5 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("ThreadContext", font4, (java.awt.Paint) color5);
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font4);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double10 = categoryAxis9.getLabelAngle();
        categoryAxis9.setLowerMargin((double) 0);
        categoryAxis9.setLabel("hi!");
        categoryAxis9.setTickMarksVisible(true);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions17 = categoryAxis9.getCategoryLabelPositions();
        boolean boolean18 = textLine7.equals((java.lang.Object) categoryLabelPositions17);
        org.jfree.chart.axis.AxisCollection axisCollection19 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor21 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.LegendItemSource legendItemSource22 = null;
        org.jfree.chart.title.LegendTitle legendTitle23 = new org.jfree.chart.title.LegendTitle(legendItemSource22);
        boolean boolean24 = itemLabelAnchor21.equals((java.lang.Object) legendTitle23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color27 = java.awt.Color.RED;
        categoryAxis26.setLabelPaint((java.awt.Paint) color27);
        categoryAxis26.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint31 = categoryAxis26.getTickLabelPaint();
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder34 = new org.jfree.chart.block.LineBorder(paint31, stroke32, rectangleInsets33);
        legendTitle23.setFrame((org.jfree.chart.block.BlockFrame) lineBorder34);
        org.jfree.chart.axis.AxisSpace axisSpace36 = new org.jfree.chart.axis.AxisSpace();
        axisSpace36.setBottom((double) '#');
        java.lang.String str39 = axisSpace36.toString();
        double double40 = axisSpace36.getBottom();
        org.jfree.chart.axis.AxisSpace axisSpace42 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisSpace42.add(0.0d, rectangleEdge44);
        boolean boolean46 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge44);
        axisSpace36.add(0.05d, rectangleEdge44);
        legendTitle23.setLegendItemGraphicEdge(rectangleEdge44);
        axisCollection19.add((org.jfree.chart.axis.Axis) numberAxis20, rectangleEdge44);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition50 = categoryLabelPositions17.getLabelPosition(rectangleEdge44);
        try {
            axisCollection0.add(axis1, rectangleEdge44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 35.0d + "'", double40 == 35.0d);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(categoryLabelPosition50);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 0L, (float) (-1L), (float) (short) 1);
        java.awt.Paint paint9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand12 = null;
        numberAxis11.setMarkerBand(markerAxisBand12);
        java.awt.Stroke stroke14 = numberAxis11.getTickMarkStroke();
        java.awt.Paint paint15 = null;
        try {
            org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("ClassContext", "", "hi!", "", shape8, paint9, stroke14, paint15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        org.jfree.chart.event.MarkerChangeListener markerChangeListener3 = null;
        valueMarker1.removeChangeListener(markerChangeListener3);
        java.lang.Object obj5 = valueMarker1.clone();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        org.jfree.chart.block.BlockBorder blockBorder3 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean4 = statisticalBarRenderer0.equals((java.lang.Object) blockBorder3);
        boolean boolean5 = statisticalBarRenderer0.getIncludeBaseInRange();
        org.junit.Assert.assertNotNull(blockBorder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        categoryAxis1.setLowerMargin((double) 0);
        categoryAxis1.setLabel("hi!");
        categoryAxis1.setLabel("hi!");
        categoryAxis1.setAxisLineVisible(true);
        categoryAxis1.setUpperMargin((double) 128);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition4, true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke8 = defaultDrawingSupplier7.getNextOutlineStroke();
        java.awt.Stroke stroke9 = defaultDrawingSupplier7.getNextStroke();
        statisticalBarRenderer0.setErrorIndicatorStroke(stroke9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = statisticalBarRenderer0.getNegativeItemLabelPositionFallback();
        java.awt.Stroke stroke12 = statisticalBarRenderer0.getErrorIndicatorStroke();
        statisticalBarRenderer0.setSeriesCreateEntities((int) (byte) 10, (java.lang.Boolean) false, true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.TickType tickType5 = org.jfree.chart.axis.TickType.MINOR;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.NumberTick numberTick11 = new org.jfree.chart.axis.NumberTick(tickType5, (double) 'a', "DatasetRenderingOrder.FORWARD", textAnchor8, textAnchor9, 4.0d);
        org.jfree.chart.text.TextAnchor textAnchor12 = numberTick11.getTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        java.awt.Shape shape15 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D2, (float) (short) 0, (-1.0f), textAnchor12, (double) (-1L), textAnchor14);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor14);
        org.jfree.chart.text.TextAnchor textAnchor17 = itemLabelPosition16.getRotationAnchor();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor18 = itemLabelPosition16.getItemLabelAnchor();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(tickType5);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNull(shape15);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertNotNull(itemLabelAnchor18);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        java.awt.Paint paint3 = valueMarker1.getOutlinePaint();
        java.awt.Stroke stroke4 = valueMarker1.getStroke();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = valueMarker1.getLabelOffsetType();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(lengthAdjustmentType5);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) '4', 10.0f);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity5 = new org.jfree.chart.entity.TickLabelEntity(shape2, "ChartChangeEventType.NEW_DATASET", "");
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean5 = textAnchor3.equals((java.lang.Object) (byte) 100);
        org.jfree.chart.axis.CategoryTick categoryTick7 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 14.0d, textBlock1, textBlockAnchor2, textAnchor3, 14.0d);
        java.lang.Comparable comparable8 = categoryTick7.getCategory();
        org.jfree.chart.text.TextAnchor textAnchor9 = categoryTick7.getRotationAnchor();
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 14.0d + "'", comparable8.equals(14.0d));
        org.junit.Assert.assertNotNull(textAnchor9);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) 500, (double) (-1.0f), (int) (byte) 0, (java.lang.Comparable) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset45);
        double double49 = range48.getUpperBound();
        double double50 = range48.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint52 = new org.jfree.chart.block.RectangleConstraint(range48, (double) (short) -1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 44.0d + "'", double49 == 44.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 44.0d + "'", double50 == 44.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(0.0d, (double) 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setBottom((double) '#');
        java.lang.String str3 = axisSpace0.toString();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = axisSpace0.reserved(rectangle2D4, rectangleEdge5);
        axisSpace0.setTop((double) (byte) 0);
        org.junit.Assert.assertNull(rectangle2D6);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 10, 100.0f);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.clone(shape7);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color13 = java.awt.Color.getColor("", color12);
        java.awt.Color color14 = java.awt.Color.getColor("ThreadContext", color13);
        java.awt.Color color16 = java.awt.Color.GREEN;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.block.BlockContainer blockContainer19 = new org.jfree.chart.block.BlockContainer();
        blockContainer19.clear();
        java.awt.Shape shape21 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape21, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color28 = java.awt.Color.RED;
        categoryAxis27.setLabelPaint((java.awt.Paint) color28);
        float[] floatArray34 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray35 = color28.getRGBColorComponents(floatArray34);
        org.jfree.chart.title.LegendGraphic legendGraphic36 = new org.jfree.chart.title.LegendGraphic(shape25, (java.awt.Paint) color28);
        blockContainer19.add((org.jfree.chart.block.Block) legendGraphic36);
        java.awt.Shape shape38 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape42 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape38, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color45 = java.awt.Color.RED;
        categoryAxis44.setLabelPaint((java.awt.Paint) color45);
        float[] floatArray51 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray52 = color45.getRGBColorComponents(floatArray51);
        org.jfree.chart.title.LegendGraphic legendGraphic53 = new org.jfree.chart.title.LegendGraphic(shape42, (java.awt.Paint) color45);
        legendGraphic36.setOutlinePaint((java.awt.Paint) color45);
        java.awt.Shape shape55 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity56 = new org.jfree.chart.entity.LegendItemEntity(shape55);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity59 = new org.jfree.chart.entity.TickLabelEntity(shape55, "", "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity62 = new org.jfree.chart.entity.TickLabelEntity(shape55, "hi!", "RectangleConstraintType.RANGE");
        legendGraphic36.setLine(shape55);
        org.jfree.chart.plot.ValueMarker valueMarker65 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke66 = valueMarker65.getOutlineStroke();
        java.awt.Paint paint67 = valueMarker65.getOutlinePaint();
        java.awt.Stroke stroke68 = valueMarker65.getStroke();
        java.awt.Paint paint69 = null;
        org.jfree.chart.LegendItem legendItem70 = new org.jfree.chart.LegendItem("AxisLocation.BOTTOM_OR_LEFT", "java.awt.Color[r=192,g=192,b=0]", "", "MINOR", true, shape8, true, (java.awt.Paint) color13, true, (java.awt.Paint) color16, stroke17, false, shape55, stroke68, paint69);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(floatArray51);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNotNull(stroke68);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.clear();
        java.awt.Shape shape2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color9 = java.awt.Color.RED;
        categoryAxis8.setLabelPaint((java.awt.Paint) color9);
        float[] floatArray15 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray16 = color9.getRGBColorComponents(floatArray15);
        org.jfree.chart.title.LegendGraphic legendGraphic17 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color9);
        blockContainer0.add((org.jfree.chart.block.Block) legendGraphic17);
        java.awt.Shape shape19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape19, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color26 = java.awt.Color.RED;
        categoryAxis25.setLabelPaint((java.awt.Paint) color26);
        float[] floatArray32 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray33 = color26.getRGBColorComponents(floatArray32);
        org.jfree.chart.title.LegendGraphic legendGraphic34 = new org.jfree.chart.title.LegendGraphic(shape23, (java.awt.Paint) color26);
        legendGraphic17.setOutlinePaint((java.awt.Paint) color26);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType36 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer37 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType36);
        java.lang.Object obj38 = standardGradientPaintTransformer37.clone();
        double[] doubleArray47 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray54 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray61 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray68 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray75 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray82 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray83 = new double[][] { doubleArray47, doubleArray54, doubleArray61, doubleArray68, doubleArray75, doubleArray82 };
        org.jfree.data.category.CategoryDataset categoryDataset84 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray83);
        boolean boolean85 = standardGradientPaintTransformer37.equals((java.lang.Object) doubleArray83);
        boolean boolean86 = color26.equals((java.lang.Object) standardGradientPaintTransformer37);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(gradientPaintTransformType36);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(categoryDataset84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition4, true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke8 = defaultDrawingSupplier7.getNextOutlineStroke();
        java.awt.Stroke stroke9 = defaultDrawingSupplier7.getNextStroke();
        statisticalBarRenderer0.setErrorIndicatorStroke(stroke9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = statisticalBarRenderer0.getNegativeItemLabelPositionFallback();
        java.awt.Stroke stroke12 = statisticalBarRenderer0.getErrorIndicatorStroke();
        java.awt.Stroke stroke15 = statisticalBarRenderer0.getItemStroke(0, 15);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke2 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke5 = valueMarker4.getOutlineStroke();
        statisticalBarRenderer0.setErrorIndicatorStroke(stroke5);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = statisticalBarRenderer7.getPositiveItemLabelPosition((int) '#', (int) (byte) -1);
        statisticalBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition10, false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        statisticalBarRenderer14.setBaseItemLabelGenerator(categoryItemLabelGenerator15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        statisticalBarRenderer14.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition18, true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke22 = defaultDrawingSupplier21.getNextOutlineStroke();
        java.awt.Stroke stroke23 = defaultDrawingSupplier21.getNextStroke();
        statisticalBarRenderer14.setErrorIndicatorStroke(stroke23);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = statisticalBarRenderer14.getNegativeItemLabelPositionFallback();
        java.awt.Stroke stroke26 = statisticalBarRenderer14.getErrorIndicatorStroke();
        statisticalBarRenderer0.setSeriesStroke(10, stroke26);
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(itemLabelPosition25);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        double[] doubleArray10 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray17 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray24 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray31 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray38 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray45 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray46 = new double[][] { doubleArray10, doubleArray17, doubleArray24, doubleArray31, doubleArray38, doubleArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset47, (int) (short) 0);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer51 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) pieDataset49, (java.lang.Comparable) "ThreadContext");
        java.lang.Object obj52 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) legendItemBlockContainer51);
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double56 = categoryAxis55.getLabelAngle();
        java.awt.Font font58 = categoryAxis55.getTickLabelFont((java.lang.Comparable) 10.0d);
        org.jfree.chart.title.TextTitle textTitle59 = new org.jfree.chart.title.TextTitle("-3,-3,3,3", font58);
        boolean boolean60 = legendItemBlockContainer51.equals((java.lang.Object) textTitle59);
        java.awt.Graphics2D graphics2D61 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double64 = rectangleInsets62.trimWidth((double) 1L);
        double double66 = rectangleInsets62.trimWidth((double) 1L);
        java.awt.Color color67 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder68 = new org.jfree.chart.block.BlockBorder(rectangleInsets62, (java.awt.Paint) color67);
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = blockBorder68.getInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo70 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo70);
        org.jfree.chart.renderer.RendererState rendererState72 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo71);
        java.awt.geom.Rectangle2D rectangle2D73 = plotRenderingInfo71.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D76 = rectangleInsets69.createOutsetRectangle(rectangle2D73, true, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot77 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis79 = categoryPlot77.getDomainAxis(2);
        categoryPlot77.setAnchorValue(35.0d, true);
        try {
            java.lang.Object obj83 = legendItemBlockContainer51.draw(graphics2D61, rectangle2D76, (java.lang.Object) 35.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + (-7.0d) + "'", double64 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + (-7.0d) + "'", double66 == (-7.0d));
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertNotNull(rectangle2D76);
        org.junit.Assert.assertNull(categoryAxis79);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("DatasetRenderingOrder.FORWARD", "JFreeChart version VerticalAlignment.CENTER.\nLGPL.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:ThreadContext ThreadContext (hi!).(C)opyright 2000-2007, by Object Refinery Limited and Contributors ThreadContext (hi!).JFreeChart VerticalAlignment.CENTER (http://www.jfree.org/jfreechart/index.html).ThreadContext ThreadContext (hi!).ThreadContext ThreadContext (hi!).\nJFreeChart LICENCE TERMS:\nRectangleConstraintType.RANGE", "", "JFreeChart version VerticalAlignment.CENTER.\nLGPL.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:ThreadContext ThreadContext (hi!).(C)opyright 2000-2007, by Object Refinery Limited and Contributors ThreadContext (hi!).JFreeChart VerticalAlignment.CENTER (http://www.jfree.org/jfreechart/index.html).ThreadContext ThreadContext (hi!).ThreadContext ThreadContext (hi!).\nJFreeChart LICENCE TERMS:\nRectangleConstraintType.RANGE", "DatasetRenderingOrder.FORWARD");
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setBottom((double) '#');
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = axisSpace0.reserved(rectangle2D3, rectangleEdge4);
        java.awt.Shape shape6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color13 = java.awt.Color.RED;
        categoryAxis12.setLabelPaint((java.awt.Paint) color13);
        float[] floatArray19 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray20 = color13.getRGBColorComponents(floatArray19);
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape10, (java.awt.Paint) color13);
        java.lang.Object obj22 = legendGraphic21.clone();
        legendGraphic21.setShapeVisible(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendGraphic21.setShapeAnchor(rectangleAnchor25);
        org.jfree.chart.axis.AxisSpace axisSpace27 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisSpace27.add(0.0d, rectangleEdge29);
        double double31 = axisSpace27.getTop();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisSpace27.add(0.0d, rectangleEdge33);
        boolean boolean35 = legendGraphic21.equals((java.lang.Object) axisSpace27);
        double double36 = axisSpace27.getRight();
        axisSpace0.ensureAtLeast(axisSpace27);
        org.junit.Assert.assertNull(rectangle2D5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double4 = categoryAxis3.getLabelAngle();
        java.awt.Font font6 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 10.0d);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("-3,-3,3,3", font6);
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("ThreadContext", font6);
        boolean boolean10 = labelBlock8.equals((java.lang.Object) 1.0E-8d);
        labelBlock8.setToolTipText("ThreadContext");
        double double13 = labelBlock8.getContentYOffset();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setForegroundAlpha((float) (-1));
        int int3 = categoryPlot0.getWeight();
        boolean boolean4 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke7 = valueMarker6.getOutlineStroke();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        valueMarker6.setLabelOffsetType(lengthAdjustmentType8);
        org.jfree.chart.util.Layer layer10 = null;
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker6, layer10);
        float float12 = categoryPlot0.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(lengthAdjustmentType8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + (-1.0f) + "'", float12 == (-1.0f));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (byte) -1);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot3.getColumnRenderingOrder();
        valueMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot3);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        plotRenderingInfo9.setDataArea(rectangle2D10);
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot3.zoomRangeAxes((double) (-2), (double) (short) 100, plotRenderingInfo9, point2D12);
        categoryPlot3.setRangeCrosshairValue((-6.0d), false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(sortOrder4);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setForegroundAlpha((float) (-1));
        int int3 = categoryPlot0.getWeight();
        boolean boolean4 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo7);
        org.jfree.chart.renderer.RendererState rendererState9 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = rendererState9.getInfo();
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 10, (double) (short) 10, plotRenderingInfo10, point2D11);
        boolean boolean13 = categoryPlot0.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(plotRenderingInfo10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        statisticalBarRenderer0.setIncludeBaseInRange(false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) '#', (int) (byte) -1);
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke6 = valueMarker5.getOutlineStroke();
        java.awt.Paint paint7 = valueMarker5.getOutlinePaint();
        java.awt.Paint paint8 = valueMarker5.getLabelPaint();
        java.awt.Stroke stroke9 = valueMarker5.getOutlineStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke9);
        statisticalBarRenderer0.setBaseItemLabelsVisible(false);
        double double13 = statisticalBarRenderer0.getBase();
        java.awt.Stroke stroke14 = statisticalBarRenderer0.getBaseOutlineStroke();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = statisticalBarRenderer0.getBaseToolTipGenerator();
        java.awt.Paint paint18 = statisticalBarRenderer0.getItemOutlinePaint(0, (int) 'a');
        java.awt.Paint paint21 = statisticalBarRenderer0.getItemPaint((-2), 0);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition4, true);
        boolean boolean7 = statisticalBarRenderer0.isDrawBarOutline();
        boolean boolean8 = statisticalBarRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Paint paint9 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        statisticalBarRenderer0.setBaseFillPaint(paint9);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double3 = categoryAxis2.getLabelAngle();
        java.awt.Font font5 = categoryAxis2.getTickLabelFont((java.lang.Comparable) 10.0d);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("-3,-3,3,3", font5);
        textTitle6.setNotify(false);
        org.jfree.chart.text.TextFragment textFragment10 = new org.jfree.chart.text.TextFragment("");
        java.awt.Paint paint11 = textFragment10.getPaint();
        boolean boolean12 = textTitle6.equals((java.lang.Object) textFragment10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        int int1 = paintList0.size();
        org.jfree.chart.axis.TickType tickType2 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean3 = paintList0.equals((java.lang.Object) tickType2);
        java.lang.Object obj4 = null;
        boolean boolean5 = paintList0.equals(obj4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(tickType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition4, true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke8 = defaultDrawingSupplier7.getNextOutlineStroke();
        java.awt.Stroke stroke9 = defaultDrawingSupplier7.getNextStroke();
        statisticalBarRenderer0.setErrorIndicatorStroke(stroke9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = statisticalBarRenderer0.getNegativeItemLabelPositionFallback();
        java.awt.Stroke stroke12 = statisticalBarRenderer0.getErrorIndicatorStroke();
        java.awt.Shape shape14 = statisticalBarRenderer0.lookupSeriesShape((int) ' ');
        statisticalBarRenderer0.setBaseCreateEntities(true);
        java.awt.Paint paint18 = statisticalBarRenderer0.lookupSeriesFillPaint((int) (byte) 10);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis2.setUpperBound((double) 1L);
        boolean boolean5 = numberAxis2.getAutoRangeIncludesZero();
        java.awt.Shape shape6 = numberAxis2.getRightArrow();
        numberAxis2.setLowerMargin(100.0d);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setForegroundAlpha((float) (-1));
        int int12 = categoryPlot9.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation14 = axisLocation13.getOpposite();
        categoryPlot9.setDomainAxisLocation(axisLocation13, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation13, plotOrientation17);
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis2, rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset45);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double51 = categoryAxis50.getLabelAngle();
        categoryAxis50.setLowerMargin((double) 0);
        categoryAxis50.setLabel("hi!");
        int int56 = categoryAxis50.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis58.setAutoRange(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer61 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator62 = null;
        statisticalBarRenderer61.setBaseItemLabelGenerator(categoryItemLabelGenerator62);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition65 = null;
        statisticalBarRenderer61.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition65, true);
        boolean boolean68 = statisticalBarRenderer61.isDrawBarOutline();
        boolean boolean69 = statisticalBarRenderer61.getAutoPopulateSeriesPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis50, (org.jfree.chart.axis.ValueAxis) numberAxis58, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer61);
        java.lang.Object obj71 = categoryPlot70.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double74 = rectangleInsets72.trimWidth((double) 1L);
        double double76 = rectangleInsets72.trimWidth((double) 1L);
        double double78 = rectangleInsets72.calculateTopOutset((double) (byte) 10);
        categoryPlot70.setInsets(rectangleInsets72);
        org.jfree.chart.axis.NumberAxis numberAxis82 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis82.setUpperBound((double) 1L);
        boolean boolean85 = numberAxis82.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat86 = numberAxis82.getNumberFormatOverride();
        categoryPlot70.setRangeAxis((int) 'a', (org.jfree.chart.axis.ValueAxis) numberAxis82, false);
        int int89 = categoryPlot70.getRangeAxisCount();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(obj71);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + (-7.0d) + "'", double74 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + (-7.0d) + "'", double76 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 2.0d + "'", double78 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertNull(numberFormat86);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 98 + "'", int89 == 98);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("");
        try {
            java.lang.String str4 = jFreeChartResources0.getString("HorizontalAlignment.RIGHT");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key HorizontalAlignment.RIGHT");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean2 = categoryLabelPosition0.equals((java.lang.Object) categoryLabelPosition1);
        org.jfree.chart.text.TextAnchor textAnchor3 = categoryLabelPosition1.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType4 = categoryLabelPosition1.getWidthType();
        java.lang.String str5 = categoryLabelWidthType4.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(categoryLabelWidthType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "CategoryLabelWidthType.CATEGORY" + "'", str5.equals("CategoryLabelWidthType.CATEGORY"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = null;
        numberAxis7.setMarkerBand(markerAxisBand8);
        java.awt.Stroke stroke10 = numberAxis7.getTickMarkStroke();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis7.setUpArrow(shape12);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color19 = java.awt.Color.RED;
        categoryAxis18.setLabelPaint((java.awt.Paint) color19);
        float[] floatArray25 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray26 = color19.getRGBColorComponents(floatArray25);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity30 = new org.jfree.chart.entity.LegendItemEntity(shape29);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity33 = new org.jfree.chart.entity.TickLabelEntity(shape29, "", "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity36 = new org.jfree.chart.entity.TickLabelEntity(shape29, "hi!", "RectangleConstraintType.RANGE");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier37 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke38 = defaultDrawingSupplier37.getNextOutlineStroke();
        java.awt.Color color39 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("", "ThreadContext", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "DatasetRenderingOrder.FORWARD", true, shape12, true, (java.awt.Paint) color15, true, (java.awt.Paint) color19, stroke27, false, shape29, stroke38, (java.awt.Paint) color39);
        java.awt.Paint paint41 = legendItem40.getOutlinePaint();
        legendItemCollection0.add(legendItem40);
        java.lang.Comparable comparable43 = legendItem40.getSeriesKey();
        java.awt.Paint paint44 = legendItem40.getOutlinePaint();
        java.lang.String str45 = legendItem40.getLabel();
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNull(comparable43);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 0);
        objectList1.clear();
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getMinimumBarLength();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = statisticalBarRenderer0.getSeriesItemLabelGenerator((-2));
        java.awt.Font font5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double8 = categoryAxis7.getLabelAngle();
        categoryAxis7.setLowerMargin((double) 0);
        categoryAxis7.setUpperMargin(0.0d);
        java.lang.String str13 = categoryAxis7.getLabel();
        double double14 = categoryAxis7.getUpperMargin();
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke18 = valueMarker17.getOutlineStroke();
        java.awt.Paint paint19 = valueMarker17.getOutlinePaint();
        categoryAxis7.setTickLabelPaint((java.lang.Comparable) 10.0d, paint19);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer24 = new org.jfree.chart.text.G2TextMeasurer(graphics2D23);
        org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("", font5, paint19, 0.0f, 4, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer24);
        statisticalBarRenderer0.setBaseItemLabelPaint(paint19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = statisticalBarRenderer0.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(textBlock25);
        org.junit.Assert.assertNull(itemLabelPosition27);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.text.NumberFormat numberFormat1 = numberAxis0.getNumberFormatOverride();
        org.junit.Assert.assertNull(numberFormat1);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Shape shape1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity2 = new org.jfree.chart.entity.LegendItemEntity(shape1);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity5 = new org.jfree.chart.entity.TickLabelEntity(shape1, "", "");
        boolean boolean6 = textLine0.equals((java.lang.Object) tickLabelEntity5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D8 = textLine0.calculateDimensions(graphics2D7);
        java.awt.Shape shape11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape11, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color18 = java.awt.Color.RED;
        categoryAxis17.setLabelPaint((java.awt.Paint) color18);
        float[] floatArray24 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray25 = color18.getRGBColorComponents(floatArray24);
        org.jfree.chart.title.LegendGraphic legendGraphic26 = new org.jfree.chart.title.LegendGraphic(shape15, (java.awt.Paint) color18);
        java.lang.Object obj27 = legendGraphic26.clone();
        legendGraphic26.setShapeVisible(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendGraphic26.setShapeAnchor(rectangleAnchor30);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = legendGraphic26.getShapeAnchor();
        java.awt.geom.Rectangle2D rectangle2D33 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D8, (double) '#', 32.0d, rectangleAnchor32);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(size2D8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(rectangle2D33);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition4, true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke8 = defaultDrawingSupplier7.getNextOutlineStroke();
        java.awt.Stroke stroke9 = defaultDrawingSupplier7.getNextStroke();
        statisticalBarRenderer0.setErrorIndicatorStroke(stroke9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = statisticalBarRenderer0.getNegativeItemLabelPositionFallback();
        java.awt.Stroke stroke12 = statisticalBarRenderer0.getErrorIndicatorStroke();
        java.awt.Shape shape14 = statisticalBarRenderer0.lookupSeriesShape((int) ' ');
        statisticalBarRenderer0.setBaseCreateEntities(true);
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        statisticalBarRenderer0.setBaseFillPaint(paint17);
        java.awt.Stroke stroke20 = statisticalBarRenderer0.getSeriesOutlineStroke((int) (short) 100);
        java.awt.Paint paint23 = statisticalBarRenderer0.getItemOutlinePaint((int) (short) 0, 4);
        java.awt.Shape shape26 = statisticalBarRenderer0.getItemShape((int) ' ', (-2));
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(stroke20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(shape26);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        java.awt.Stroke stroke4 = numberAxis1.getTickMarkStroke();
        double double5 = numberAxis1.getUpperBound();
        double double6 = numberAxis1.getAutoRangeMinimumSize();
        boolean boolean7 = numberAxis1.isPositiveArrowVisible();
        double double8 = numberAxis1.getUpperBound();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-8d + "'", double6 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        double[] doubleArray9 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray16 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray23 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray30 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray37 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray44 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray45);
        org.jfree.data.general.PieDataset pieDataset48 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset46, (int) (short) 0);
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset46);
        boolean boolean52 = range49.intersects((double) 1.0f, 0.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint54 = new org.jfree.chart.block.RectangleConstraint(range49, 2.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint55 = new org.jfree.chart.block.RectangleConstraint((double) 2.0f, range49);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType56 = rectangleConstraint55.getHeightConstraintType();
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(pieDataset48);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType56);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 0, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = rectangleConstraint4.getHeightConstraintType();
        java.lang.String str6 = lengthConstraintType5.toString();
        org.jfree.chart.block.FlowArrangement flowArrangement7 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement7.clear();
        double[] doubleArray17 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray24 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray31 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray38 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray45 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray52 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray53 = new double[][] { doubleArray17, doubleArray24, doubleArray31, doubleArray38, doubleArray45, doubleArray52 };
        org.jfree.data.category.CategoryDataset categoryDataset54 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray53);
        org.jfree.data.general.PieDataset pieDataset56 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset54, (int) (short) 0);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer58 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement7, (org.jfree.data.general.Dataset) pieDataset56, (java.lang.Comparable) "ThreadContext");
        java.lang.Object obj59 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) legendItemBlockContainer58);
        boolean boolean60 = lengthConstraintType5.equals((java.lang.Object) legendItemBlockContainer58);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleConstraintType.RANGE" + "'", str6.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(categoryDataset54);
        org.junit.Assert.assertNotNull(pieDataset56);
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        categoryAxis1.setLowerMargin((double) 0);
        categoryAxis1.setUpperMargin(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double9 = rectangleInsets7.trimWidth((double) 1L);
        double double11 = rectangleInsets7.trimWidth((double) 1L);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder(rectangleInsets7, (java.awt.Paint) color12);
        boolean boolean14 = categoryAxis1.equals((java.lang.Object) rectangleInsets7);
        categoryAxis1.setTickMarkOutsideLength((float) 10);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryAxis1.getTickLabelInsets();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-7.0d) + "'", double9 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-7.0d) + "'", double11 == (-7.0d));
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.awt.Shape shape1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity2 = new org.jfree.chart.entity.LegendItemEntity(shape1);
        double[] doubleArray11 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray18 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray25 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray32 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray39 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray46 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray47 = new double[][] { doubleArray11, doubleArray18, doubleArray25, doubleArray32, doubleArray39, doubleArray46 };
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray47);
        org.jfree.data.general.PieDataset pieDataset50 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset48, (int) (short) 0);
        legendItemEntity2.setDataset((org.jfree.data.general.Dataset) pieDataset50);
        org.jfree.data.general.PieDataset pieDataset54 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset50, (java.lang.Comparable) (-1.0d), 0.2d);
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) "RectangleConstraintType.RANGE", (org.jfree.data.KeyedValues) pieDataset50);
        boolean boolean56 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset50);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNotNull(pieDataset50);
        org.junit.Assert.assertNotNull(pieDataset54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition4, true);
        java.awt.Paint paint7 = statisticalBarRenderer0.getBaseFillPaint();
        boolean boolean9 = statisticalBarRenderer0.isSeriesVisible(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = statisticalBarRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator10);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getMinimumBarLength();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = statisticalBarRenderer0.getSeriesItemLabelGenerator((-2));
        java.awt.Font font5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double8 = categoryAxis7.getLabelAngle();
        categoryAxis7.setLowerMargin((double) 0);
        categoryAxis7.setUpperMargin(0.0d);
        java.lang.String str13 = categoryAxis7.getLabel();
        double double14 = categoryAxis7.getUpperMargin();
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke18 = valueMarker17.getOutlineStroke();
        java.awt.Paint paint19 = valueMarker17.getOutlinePaint();
        categoryAxis7.setTickLabelPaint((java.lang.Comparable) 10.0d, paint19);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer24 = new org.jfree.chart.text.G2TextMeasurer(graphics2D23);
        org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("", font5, paint19, 0.0f, 4, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer24);
        statisticalBarRenderer0.setBaseItemLabelPaint(paint19);
        double double27 = statisticalBarRenderer0.getBase();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(textBlock25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer4.getSeriesNegativeItemLabelPosition((int) (short) 1);
        java.awt.Stroke stroke7 = barRenderer4.getBaseOutlineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand15 = null;
        numberAxis14.setMarkerBand(markerAxisBand15);
        java.awt.Stroke stroke17 = numberAxis14.getTickMarkStroke();
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis14.setUpArrow(shape19);
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape19, (double) (byte) 10, 1.0E-8d);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand26 = null;
        numberAxis25.setMarkerBand(markerAxisBand26);
        java.awt.Stroke stroke28 = numberAxis25.getTickMarkStroke();
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color31 = java.awt.Color.getColor("", color30);
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "hi!", shape23, stroke28, (java.awt.Paint) color30);
        java.awt.Shape shape33 = legendItem32.getShape();
        barRenderer4.setSeriesShape(255, shape33, false);
        java.awt.Paint paint36 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem(attributedString0, "NOID", "ThreadContext", "DatasetRenderingOrder.FORWARD", shape33, paint36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape4);
        java.awt.Paint paint10 = null;
        try {
            org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem(attributedString0, "-3,-3,3,3", "NOID", "", shape4, paint10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        shapeList0.clear();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo6 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "LGPL", "hi!", "RectangleConstraintType.RANGE");
        java.lang.String str7 = basicProjectInfo6.getVersion();
        boolean boolean8 = shapeList0.equals((java.lang.Object) basicProjectInfo6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "LGPL" + "'", str7.equals("LGPL"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        boolean boolean3 = standardGradientPaintTransformer1.equals((java.lang.Object) itemLabelAnchor2);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke3 = valueMarker2.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker2.setLabelAnchor(rectangleAnchor4);
        java.lang.Class<?> wildcardClass6 = valueMarker2.getClass();
        java.io.InputStream inputStream7 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("DatasetRenderingOrder.FORWARD", (java.lang.Class) wildcardClass6);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(inputStream7);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition4, true);
        boolean boolean7 = statisticalBarRenderer0.isDrawBarOutline();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator8, true);
        java.awt.Stroke stroke12 = statisticalBarRenderer0.lookupSeriesStroke(0);
        java.awt.Paint paint14 = statisticalBarRenderer0.getSeriesFillPaint((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(paint14);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape0, "", "");
        tickLabelEntity4.setURLText("CONTRACT");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator7 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator8 = null;
        try {
            java.lang.String str9 = tickLabelEntity4.getImageMapAreaTag(toolTipTagFragmentGenerator7, uRLTagFragmentGenerator8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset45);
        boolean boolean51 = range48.intersects((double) 1.0f, 0.0d);
        boolean boolean54 = range48.intersects((double) 2.0f, (double) 8);
        double double55 = range48.getUpperBound();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 44.0d + "'", double55 == 44.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset45);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double51 = categoryAxis50.getLabelAngle();
        categoryAxis50.setLowerMargin((double) 0);
        categoryAxis50.setLabel("hi!");
        int int56 = categoryAxis50.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis58.setAutoRange(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer61 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator62 = null;
        statisticalBarRenderer61.setBaseItemLabelGenerator(categoryItemLabelGenerator62);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition65 = null;
        statisticalBarRenderer61.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition65, true);
        boolean boolean68 = statisticalBarRenderer61.isDrawBarOutline();
        boolean boolean69 = statisticalBarRenderer61.getAutoPopulateSeriesPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis50, (org.jfree.chart.axis.ValueAxis) numberAxis58, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer61);
        java.lang.Object obj71 = categoryPlot70.clone();
        categoryPlot70.setRangeCrosshairValue((double) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation75 = categoryPlot70.getDomainAxisLocation(100);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo77 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo78 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo77);
        java.awt.geom.Point2D point2D79 = null;
        categoryPlot70.zoomRangeAxes((double) 100L, plotRenderingInfo78, point2D79);
        boolean boolean81 = categoryPlot70.isDomainZoomable();
        java.util.List list82 = categoryPlot70.getAnnotations();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(obj71);
        org.junit.Assert.assertNotNull(axisLocation75);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(list82);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 'a');
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = legendTitle3.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor4, textBlockAnchor5);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions1, categoryLabelPosition6);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition8 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean10 = categoryLabelPosition8.equals((java.lang.Object) categoryLabelPosition9);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions11 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions1, categoryLabelPosition9);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = categoryLabelPosition9.getCategoryAnchor();
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(categoryLabelPositions11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot3.getColumnRenderingOrder();
        valueMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot3);
        java.awt.Paint paint6 = categoryPlot3.getRangeCrosshairPaint();
        org.jfree.chart.util.SortOrder sortOrder7 = categoryPlot3.getRowRenderingOrder();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(sortOrder7);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        boolean boolean5 = itemLabelAnchor2.equals((java.lang.Object) legendTitle4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color8 = java.awt.Color.RED;
        categoryAxis7.setLabelPaint((java.awt.Paint) color8);
        categoryAxis7.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint12 = categoryAxis7.getTickLabelPaint();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder15 = new org.jfree.chart.block.LineBorder(paint12, stroke13, rectangleInsets14);
        legendTitle4.setFrame((org.jfree.chart.block.BlockFrame) lineBorder15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = new org.jfree.chart.axis.AxisSpace();
        axisSpace17.setBottom((double) '#');
        java.lang.String str20 = axisSpace17.toString();
        double double21 = axisSpace17.getBottom();
        org.jfree.chart.axis.AxisSpace axisSpace23 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisSpace23.add(0.0d, rectangleEdge25);
        boolean boolean27 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge25);
        axisSpace17.add(0.05d, rectangleEdge25);
        legendTitle4.setLegendItemGraphicEdge(rectangleEdge25);
        axisCollection0.add((org.jfree.chart.axis.Axis) numberAxis1, rectangleEdge25);
        boolean boolean31 = numberAxis1.isAutoRange();
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 35.0d + "'", double21 == 35.0d);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable1 = null;
        int int2 = defaultStatisticalCategoryDataset0.getRowIndex(comparable1);
        int int3 = defaultStatisticalCategoryDataset0.getRowCount();
        org.jfree.data.Range range5 = defaultStatisticalCategoryDataset0.getRangeBounds(false);
        defaultStatisticalCategoryDataset0.validateObject();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) 1L);
        double double3 = rectangleInsets0.getTop();
        double double5 = rectangleInsets0.calculateLeftOutset(1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.0d) + "'", double2 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setForegroundAlpha((float) (-1));
        int int3 = categoryPlot0.getWeight();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getLabelAngle();
        categoryAxis6.setLowerMargin((double) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color12 = java.awt.Color.RED;
        categoryAxis11.setLabelPaint((java.awt.Paint) color12);
        categoryAxis11.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint16 = categoryAxis11.getTickLabelPaint();
        java.awt.Stroke stroke17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder(paint16, stroke17, rectangleInsets18);
        categoryAxis6.setAxisLineStroke(stroke17);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryAxis6.setTickMarkPaint((java.awt.Paint) color21);
        categoryAxis6.setTickMarksVisible(false);
        java.awt.Font font25 = categoryAxis6.getTickLabelFont();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator27 = null;
        statisticalBarRenderer26.setBaseItemLabelGenerator(categoryItemLabelGenerator27);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = null;
        statisticalBarRenderer26.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition30, true);
        java.awt.Paint paint33 = statisticalBarRenderer26.getBaseFillPaint();
        boolean boolean34 = statisticalBarRenderer26.getIncludeBaseInRange();
        java.awt.Paint paint35 = statisticalBarRenderer26.getErrorIndicatorPaint();
        org.jfree.chart.text.TextFragment textFragment36 = new org.jfree.chart.text.TextFragment("AxisLocation.BOTTOM_OR_LEFT", font25, paint35);
        categoryPlot0.setNoDataMessageFont(font25);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        java.awt.Font font4 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 10.0d);
        double double5 = categoryAxis1.getLabelAngle();
        java.awt.Shape shape6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color13 = java.awt.Color.RED;
        categoryAxis12.setLabelPaint((java.awt.Paint) color13);
        float[] floatArray19 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray20 = color13.getRGBColorComponents(floatArray19);
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape10, (java.awt.Paint) color13);
        java.awt.Shape shape22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape22, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color29 = java.awt.Color.RED;
        categoryAxis28.setLabelPaint((java.awt.Paint) color29);
        float[] floatArray35 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray36 = color29.getRGBColorComponents(floatArray35);
        org.jfree.chart.title.LegendGraphic legendGraphic37 = new org.jfree.chart.title.LegendGraphic(shape26, (java.awt.Paint) color29);
        legendGraphic21.setLinePaint((java.awt.Paint) color29);
        boolean boolean39 = categoryAxis1.equals((java.lang.Object) legendGraphic21);
        legendGraphic21.setLineVisible(false);
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int43 = color42.getBlue();
        legendGraphic21.setLinePaint((java.awt.Paint) color42);
        legendGraphic21.setShapeFilled(false);
        legendGraphic21.setShapeVisible(true);
        boolean boolean49 = legendGraphic21.isShapeOutlineVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 255 + "'", int43 == 255);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        org.jfree.data.Range range5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) 0, range5);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint8.toUnconstrainedWidth();
        boolean boolean10 = numberAxis1.equals((java.lang.Object) rectangleConstraint9);
        org.jfree.data.RangeType rangeType11 = numberAxis1.getRangeType();
        boolean boolean12 = numberAxis1.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rangeType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 'a', "DatasetRenderingOrder.FORWARD", textAnchor3, textAnchor4, 4.0d);
        org.jfree.chart.text.TextAnchor textAnchor7 = numberTick6.getRotationAnchor();
        double double8 = numberTick6.getAngle();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        double[] doubleArray10 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray17 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray24 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray31 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray38 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray45 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray46 = new double[][] { doubleArray10, doubleArray17, doubleArray24, doubleArray31, doubleArray38, doubleArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset47, (int) (short) 0);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer51 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) pieDataset49, (java.lang.Comparable) "ThreadContext");
        java.lang.Object obj52 = legendItemBlockContainer51.clone();
        java.lang.String str53 = legendItemBlockContainer51.getToolTipText();
        java.awt.Graphics2D graphics2D54 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint55 = null;
        try {
            org.jfree.chart.util.Size2D size2D56 = legendItemBlockContainer51.arrange(graphics2D54, rectangleConstraint55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertNull(str53);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        categoryAxis1.setLowerMargin((double) 0);
        categoryAxis1.setLabel("hi!");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        double double9 = numberTickUnit8.getSize();
        java.awt.Paint paint10 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) numberTickUnit8);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color2 = java.awt.Color.RED;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 3);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        org.jfree.data.Range range5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) 0, range5);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint8.toUnconstrainedWidth();
        boolean boolean10 = numberAxis1.equals((java.lang.Object) rectangleConstraint9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand13 = null;
        numberAxis12.setMarkerBand(markerAxisBand13);
        java.awt.Stroke stroke15 = numberAxis12.getTickMarkStroke();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis12.setUpArrow(shape17);
        numberAxis1.setUpArrow(shape17);
        boolean boolean20 = numberAxis1.isNegativeArrowVisible();
        numberAxis1.configure();
        numberAxis1.setVisible(false);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis2.setUpperBound((double) 1L);
        java.awt.Font font5 = numberAxis2.getLabelFont();
        java.awt.Shape shape6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color13 = java.awt.Color.RED;
        categoryAxis12.setLabelPaint((java.awt.Paint) color13);
        float[] floatArray19 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray20 = color13.getRGBColorComponents(floatArray19);
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape10, (java.awt.Paint) color13);
        org.jfree.chart.block.LabelBlock labelBlock22 = new org.jfree.chart.block.LabelBlock("", font5, (java.awt.Paint) color13);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset45);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double51 = categoryAxis50.getLabelAngle();
        categoryAxis50.setLowerMargin((double) 0);
        categoryAxis50.setLabel("hi!");
        int int56 = categoryAxis50.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis58.setAutoRange(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer61 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator62 = null;
        statisticalBarRenderer61.setBaseItemLabelGenerator(categoryItemLabelGenerator62);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition65 = null;
        statisticalBarRenderer61.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition65, true);
        boolean boolean68 = statisticalBarRenderer61.isDrawBarOutline();
        boolean boolean69 = statisticalBarRenderer61.getAutoPopulateSeriesPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis50, (org.jfree.chart.axis.ValueAxis) numberAxis58, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer61);
        org.jfree.chart.LegendItemSource legendItemSource71 = null;
        org.jfree.chart.title.LegendTitle legendTitle72 = new org.jfree.chart.title.LegendTitle(legendItemSource71);
        double double73 = legendTitle72.getWidth();
        legendTitle72.setHeight((double) (byte) 10);
        java.awt.Font font76 = legendTitle72.getItemFont();
        categoryPlot70.setNoDataMessageFont(font76);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(font76);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color2 = java.awt.Color.MAGENTA;
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis1.getLabelURL();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategoryEnd((int) 'a', 4, rectangle2D7, rectangleEdge8);
        boolean boolean10 = categoryAxis1.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.ChartColor chartColor8 = new org.jfree.chart.ChartColor((int) ' ', 1, 100);
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder(3.0d, (double) 255, (double) (byte) 1, (double) (-1.0f), (java.awt.Paint) chartColor8);
        java.awt.Color color10 = java.awt.Color.getColor("JFreeChart version VerticalAlignment.CENTER.\nLGPL.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:ThreadContext ThreadContext (hi!).(C)opyright 2000-2007, by Object Refinery Limited and Contributors ThreadContext (hi!).JFreeChart VerticalAlignment.CENTER (http://www.jfree.org/jfreechart/index.html).ThreadContext ThreadContext (hi!).ThreadContext ThreadContext (hi!).\nJFreeChart LICENCE TERMS:\nRectangleConstraintType.RANGE", (java.awt.Color) chartColor8);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        java.awt.Font font4 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 10.0d);
        double double5 = categoryAxis1.getLabelAngle();
        java.awt.Shape shape6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color13 = java.awt.Color.RED;
        categoryAxis12.setLabelPaint((java.awt.Paint) color13);
        float[] floatArray19 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray20 = color13.getRGBColorComponents(floatArray19);
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape10, (java.awt.Paint) color13);
        java.awt.Shape shape22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape22, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color29 = java.awt.Color.RED;
        categoryAxis28.setLabelPaint((java.awt.Paint) color29);
        float[] floatArray35 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray36 = color29.getRGBColorComponents(floatArray35);
        org.jfree.chart.title.LegendGraphic legendGraphic37 = new org.jfree.chart.title.LegendGraphic(shape26, (java.awt.Paint) color29);
        legendGraphic21.setLinePaint((java.awt.Paint) color29);
        boolean boolean39 = categoryAxis1.equals((java.lang.Object) legendGraphic21);
        legendGraphic21.setLineVisible(false);
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int43 = color42.getBlue();
        legendGraphic21.setLinePaint((java.awt.Paint) color42);
        legendGraphic21.setShapeFilled(false);
        java.awt.Shape shape47 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape51 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape47, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment52 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment53 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement56 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment52, verticalAlignment53, (double) 255, (double) 1.0f);
        org.jfree.chart.block.BlockContainer blockContainer57 = new org.jfree.chart.block.BlockContainer();
        blockContainer57.clear();
        java.awt.Shape shape59 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape63 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape59, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis65 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color66 = java.awt.Color.RED;
        categoryAxis65.setLabelPaint((java.awt.Paint) color66);
        float[] floatArray72 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray73 = color66.getRGBColorComponents(floatArray72);
        org.jfree.chart.title.LegendGraphic legendGraphic74 = new org.jfree.chart.title.LegendGraphic(shape63, (java.awt.Paint) color66);
        blockContainer57.add((org.jfree.chart.block.Block) legendGraphic74);
        org.jfree.chart.plot.ValueMarker valueMarker77 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke78 = valueMarker77.getOutlineStroke();
        java.awt.Paint paint79 = valueMarker77.getOutlinePaint();
        legendGraphic74.setLinePaint(paint79);
        org.jfree.chart.axis.AxisSpace axisSpace81 = new org.jfree.chart.axis.AxisSpace();
        axisSpace81.setBottom((double) '#');
        java.lang.String str84 = axisSpace81.toString();
        double double85 = axisSpace81.getBottom();
        double double86 = axisSpace81.getBottom();
        columnArrangement56.add((org.jfree.chart.block.Block) legendGraphic74, (java.lang.Object) double86);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor88 = legendGraphic74.getShapeAnchor();
        java.awt.Shape shape91 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape47, rectangleAnchor88, (double) 1.0f, (double) 'a');
        legendGraphic21.setShapeLocation(rectangleAnchor88);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 255 + "'", int43 == 255);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(floatArray72);
        org.junit.Assert.assertNotNull(floatArray73);
        org.junit.Assert.assertNotNull(stroke78);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 35.0d + "'", double85 == 35.0d);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 35.0d + "'", double86 == 35.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor88);
        org.junit.Assert.assertNotNull(shape91);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("LGPL", graphics2D1, (float) 100L, (float) (short) 10, (double) 100L, (float) 4, (float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        java.awt.Stroke stroke4 = numberAxis1.getTickMarkStroke();
        numberAxis1.setUpperMargin((double) 0.5f);
        java.awt.Paint paint7 = numberAxis1.getLabelPaint();
        java.util.EventListener eventListener8 = null;
        boolean boolean9 = numberAxis1.hasListener(eventListener8);
        numberAxis1.setLowerBound((double) (-1));
        numberAxis1.resizeRange((double) (-1L), (double) (-2));
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        java.awt.Shape shape5 = numberAxis1.getRightArrow();
        numberAxis1.setLabelToolTip("LGPL");
        double[] doubleArray16 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray23 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray30 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray37 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray44 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray51 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray52 = new double[][] { doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44, doubleArray51 };
        org.jfree.data.category.CategoryDataset categoryDataset53 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray52);
        org.jfree.data.general.PieDataset pieDataset55 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset53, (int) (short) 0);
        org.jfree.data.Range range56 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset53);
        double double57 = range56.getUpperBound();
        double double58 = range56.getLength();
        numberAxis1.setRange(range56, false, false);
        org.jfree.data.Range range63 = org.jfree.data.Range.shift(range56, (double) (byte) -1);
        double double64 = range56.getCentralValue();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(categoryDataset53);
        org.junit.Assert.assertNotNull(pieDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 44.0d + "'", double57 == 44.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 44.0d + "'", double58 == 44.0d);
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 22.0d + "'", double64 == 22.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.lang.Object obj2 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        java.awt.Font font4 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 10.0d);
        double double5 = categoryAxis1.getLabelAngle();
        java.awt.Shape shape6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color13 = java.awt.Color.RED;
        categoryAxis12.setLabelPaint((java.awt.Paint) color13);
        float[] floatArray19 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray20 = color13.getRGBColorComponents(floatArray19);
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape10, (java.awt.Paint) color13);
        java.awt.Shape shape22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape22, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color29 = java.awt.Color.RED;
        categoryAxis28.setLabelPaint((java.awt.Paint) color29);
        float[] floatArray35 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray36 = color29.getRGBColorComponents(floatArray35);
        org.jfree.chart.title.LegendGraphic legendGraphic37 = new org.jfree.chart.title.LegendGraphic(shape26, (java.awt.Paint) color29);
        legendGraphic21.setLinePaint((java.awt.Paint) color29);
        boolean boolean39 = categoryAxis1.equals((java.lang.Object) legendGraphic21);
        double double40 = legendGraphic21.getWidth();
        java.awt.Font font42 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double45 = categoryAxis44.getLabelAngle();
        categoryAxis44.setLowerMargin((double) 0);
        categoryAxis44.setUpperMargin(0.0d);
        java.lang.String str50 = categoryAxis44.getLabel();
        double double51 = categoryAxis44.getUpperMargin();
        org.jfree.chart.plot.ValueMarker valueMarker54 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke55 = valueMarker54.getOutlineStroke();
        java.awt.Paint paint56 = valueMarker54.getOutlinePaint();
        categoryAxis44.setTickLabelPaint((java.lang.Comparable) 10.0d, paint56);
        java.awt.Graphics2D graphics2D60 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer61 = new org.jfree.chart.text.G2TextMeasurer(graphics2D60);
        org.jfree.chart.text.TextBlock textBlock62 = org.jfree.chart.text.TextUtilities.createTextBlock("", font42, paint56, 0.0f, 4, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer61);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment63 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock62.setLineAlignment(horizontalAlignment63);
        java.awt.Graphics2D graphics2D65 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor68 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor69 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition70 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor68, textBlockAnchor69);
        java.awt.Shape shape74 = textBlock62.calculateBounds(graphics2D65, (float) 8, (float) (-1), textBlockAnchor69, (float) 0, (float) 10L, (double) ' ');
        legendGraphic21.setLine(shape74);
        legendGraphic21.setShapeFilled(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "hi!" + "'", str50.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(textBlock62);
        org.junit.Assert.assertNotNull(horizontalAlignment63);
        org.junit.Assert.assertNotNull(rectangleAnchor68);
        org.junit.Assert.assertNotNull(textBlockAnchor69);
        org.junit.Assert.assertNotNull(shape74);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Shape shape1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity2 = new org.jfree.chart.entity.LegendItemEntity(shape1);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity5 = new org.jfree.chart.entity.TickLabelEntity(shape1, "", "");
        boolean boolean6 = textLine0.equals((java.lang.Object) tickLabelEntity5);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.util.Size2D size2D8 = textLine0.calculateDimensions(graphics2D7);
        double double9 = size2D8.getWidth();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor12, textBlockAnchor13);
        java.awt.geom.Rectangle2D rectangle2D15 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D8, (double) (-2), (double) '4', rectangleAnchor12);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(size2D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertNotNull(rectangle2D15);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test313");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.util.List list1 = projectInfo0.getContributors();
//        org.jfree.chart.ui.ProjectInfo projectInfo2 = org.jfree.chart.JFreeChart.INFO;
//        java.util.List list3 = projectInfo2.getContributors();
//        java.lang.String str4 = projectInfo2.getVersion();
//        projectInfo2.setVersion("VerticalAlignment.CENTER");
//        java.lang.String str7 = projectInfo2.getCopyright();
//        java.lang.String str8 = projectInfo2.toString();
//        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo2);
//        java.lang.String str10 = projectInfo2.getInfo();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertNotNull(list1);
//        org.junit.Assert.assertNotNull(projectInfo2);
//        org.junit.Assert.assertNotNull(list3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "VerticalAlignment.CENTER" + "'", str4.equals("VerticalAlignment.CENTER"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "LGPL" + "'", str7.equals("LGPL"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "JFreeChart version VerticalAlignment.CENTER.\nLGPL.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:ThreadContext ThreadContext (hi!).(C)opyright 2000-2007, by Object Refinery Limited and Contributors ThreadContext (hi!).JFreeChart VerticalAlignment.CENTER (http://www.jfree.org/jfreechart/index.html).ThreadContext ThreadContext (hi!).ThreadContext ThreadContext (hi!).ThreadContext LGPL (ThreadContext).ThreadContext ThreadContext (hi!).ThreadContext ThreadContext (hi!).\nJFreeChart LICENCE TERMS:\nRectangleConstraintType.RANGE" + "'", str8.equals("JFreeChart version VerticalAlignment.CENTER.\nLGPL.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:http://www.jfree.org/jfreechart/index.html\nCONTRIBUTORS:Eric Alexander (-).Richard Atkinson (richard_c_atkinson@ntlworld.com).David Basten (-).David Berry (-).Chris Boek (-).Zoheb Borbora (-).Anthony Boulestreau (-).Jeremy Bowman (-).Nicolas Brodu (-).Jody Brownell (-).David Browning (-).Soren Caspersen (-).Chuanhao Chiu (-).Brian Cole (-).Pascal Collet (-).Martin Cordova (-).Paolo Cova (-).Mike Duffy (-).Don Elliott (-).Jonathan Gabbai (-).David Gilbert (david.gilbert@object-refinery.com).Serge V. Grachov (-).Daniel Gredler (-).Hans-Jurgen Greiner (-).Joao Guilherme Del Valle (-).Aiman Han (-).Cameron Hayne (-).Jon Iles (-).Wolfgang Irler (-).Sergei Ivanov (-).Adriaan Joubert (-).Darren Jung (-).Xun Kang (-).Bill Kelemen (-).Norbert Kiesel (-).Gideon Krause (-).Pierre-Marie Le Biot (-).Arnaud Lelievre (-).Wolfgang Lenhard (-).David Li (-).Yan Liu (-).Tin Luu (-).Craig MacFarlane (-).Achilleus Mantzios (-).Thomas Meier (-).Jim Moore (-).Jonathan Nash (-).Barak Naveh (-).David M. O'Donnell (-).Krzysztof Paz (-).Tomer Peretz (-).Xavier Poinsard (-).Andrzej Porebski (-).Viktor Rajewski (-).Eduardo Ramalho (-).Michael Rauch (-).Cameron Riley (-).Klaus Rheinwald (-).Dan Rivett (d.rivett@ukonline.co.uk).Scott Sams (-).Michel Santos (-).Thierry Saura (-).Andreas Schneider (-).Jean-Luc SCHWAB (-).Bryan Scott (-).Tobias Selb (-).Mofeed Shahin (-).Pady Srinivasan (-).Greg Steckman (-).Roger Studner (-).Irv Thomae (-).Eric Thomas (-).Rich Unger (-).Daniel van Enckevort (-).Laurence Vanhelsuwe (-).Sylvain Vieujot (-).Jelai Wang (-).Mark Watson (www.markwatson.com).Alex Weber (-).Matthew Wright (-).Benoit Xhenseval (-).Christian W. Zuckschwerdt (Christian.Zuckschwerdt@Informatik.Uni-Oldenburg.de).Hari (-).Sam (oldman) (-).\nOTHER LIBRARIES USED BY JFreeChart:ThreadContext ThreadContext (hi!).(C)opyright 2000-2007, by Object Refinery Limited and Contributors ThreadContext (hi!).JFreeChart VerticalAlignment.CENTER (http://www.jfree.org/jfreechart/index.html).ThreadContext ThreadContext (hi!).ThreadContext ThreadContext (hi!).ThreadContext LGPL (ThreadContext).ThreadContext ThreadContext (hi!).ThreadContext ThreadContext (hi!).\nJFreeChart LICENCE TERMS:\nRectangleConstraintType.RANGE"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "http://www.jfree.org/jfreechart/index.html" + "'", str10.equals("http://www.jfree.org/jfreechart/index.html"));
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = null;
        numberAxis6.setMarkerBand(markerAxisBand7);
        java.awt.Stroke stroke9 = numberAxis6.getTickMarkStroke();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis6.setUpArrow(shape11);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color18 = java.awt.Color.RED;
        categoryAxis17.setLabelPaint((java.awt.Paint) color18);
        float[] floatArray24 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray25 = color18.getRGBColorComponents(floatArray24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape28);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity32 = new org.jfree.chart.entity.TickLabelEntity(shape28, "", "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity35 = new org.jfree.chart.entity.TickLabelEntity(shape28, "hi!", "RectangleConstraintType.RANGE");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke37 = defaultDrawingSupplier36.getNextOutlineStroke();
        java.awt.Color color38 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("", "ThreadContext", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "DatasetRenderingOrder.FORWARD", true, shape11, true, (java.awt.Paint) color14, true, (java.awt.Paint) color18, stroke26, false, shape28, stroke37, (java.awt.Paint) color38);
        java.awt.Paint paint40 = legendItem39.getOutlinePaint();
        org.jfree.data.general.Dataset dataset41 = legendItem39.getDataset();
        java.lang.String str42 = legendItem39.getToolTipText();
        java.lang.String str43 = legendItem39.getURLText();
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNull(dataset41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str42.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str43.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color2 = java.awt.Color.RED;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        categoryAxis1.setMaximumCategoryLabelLines((int) (short) -1);
        categoryAxis1.setVisible(true);
        categoryAxis1.setTickMarkOutsideLength((float) (-1));
        java.lang.String str10 = categoryAxis1.getLabelURL();
        categoryAxis1.setLabelURL("RectangleConstraintType.RANGE");
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker1.setLabelAnchor(rectangleAnchor3);
        java.lang.Class<?> wildcardClass5 = valueMarker1.getClass();
        float float6 = valueMarker1.getAlpha();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.8f + "'", float6 == 0.8f);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset45);
        boolean boolean51 = range48.intersects((double) 1.0f, 0.0d);
        boolean boolean54 = range48.intersects((double) 2.0f, (double) 8);
        boolean boolean56 = range48.contains(3.0d);
        double double57 = range48.getUpperBound();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 44.0d + "'", double57 == 44.0d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color2 = java.awt.Color.RED;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        categoryAxis1.setMaximumCategoryLabelLines((int) (short) -1);
        categoryAxis1.setVisible(true);
        categoryAxis1.setTickMarkOutsideLength((float) (-1));
        java.awt.Stroke stroke10 = categoryAxis1.getAxisLineStroke();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        boolean boolean4 = numberAxis1.isAutoRange();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = numberAxis1.getMarkerBand();
        java.awt.Paint paint6 = numberAxis1.getAxisLinePaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(markerAxisBand5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getMax();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) 1L);
        double double4 = rectangleInsets0.calculateBottomInset((-1.0d));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.0d) + "'", double2 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        java.awt.Font font4 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 10.0d);
        double double5 = categoryAxis1.getLabelAngle();
        java.awt.Shape shape6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color13 = java.awt.Color.RED;
        categoryAxis12.setLabelPaint((java.awt.Paint) color13);
        float[] floatArray19 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray20 = color13.getRGBColorComponents(floatArray19);
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape10, (java.awt.Paint) color13);
        java.awt.Shape shape22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape22, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color29 = java.awt.Color.RED;
        categoryAxis28.setLabelPaint((java.awt.Paint) color29);
        float[] floatArray35 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray36 = color29.getRGBColorComponents(floatArray35);
        org.jfree.chart.title.LegendGraphic legendGraphic37 = new org.jfree.chart.title.LegendGraphic(shape26, (java.awt.Paint) color29);
        legendGraphic21.setLinePaint((java.awt.Paint) color29);
        boolean boolean39 = categoryAxis1.equals((java.lang.Object) legendGraphic21);
        legendGraphic21.setLineVisible(false);
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int43 = color42.getBlue();
        legendGraphic21.setLinePaint((java.awt.Paint) color42);
        legendGraphic21.setShapeFilled(false);
        org.jfree.chart.block.FlowArrangement flowArrangement47 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement47.clear();
        org.jfree.chart.LegendItemSource legendItemSource49 = null;
        org.jfree.chart.title.LegendTitle legendTitle50 = new org.jfree.chart.title.LegendTitle(legendItemSource49);
        org.jfree.chart.LegendItemSource legendItemSource51 = null;
        org.jfree.chart.title.LegendTitle legendTitle52 = new org.jfree.chart.title.LegendTitle(legendItemSource51);
        double double53 = legendTitle52.getHeight();
        flowArrangement47.add((org.jfree.chart.block.Block) legendTitle50, (java.lang.Object) double53);
        legendTitle50.setWidth((double) (byte) -1);
        java.awt.Paint paint57 = legendTitle50.getItemPaint();
        legendGraphic21.setFillPaint(paint57);
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = legendGraphic21.getPadding();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 255 + "'", int43 == 255);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(rectangleInsets59);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        java.awt.Shape shape5 = numberAxis1.getRightArrow();
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity8 = new org.jfree.chart.entity.TickLabelEntity(shape5, "ItemLabelAnchor.CENTER", "");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        java.awt.Stroke stroke4 = numberAxis1.getTickMarkStroke();
        numberAxis1.setUpperMargin((double) 0.5f);
        java.awt.Paint paint7 = numberAxis1.getLabelPaint();
        java.awt.Font font8 = numberAxis1.getTickLabelFont();
        numberAxis1.setUpperMargin(22.0d);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double3 = categoryAxis2.getLabelAngle();
        categoryAxis2.setLowerMargin((double) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color8 = java.awt.Color.RED;
        categoryAxis7.setLabelPaint((java.awt.Paint) color8);
        categoryAxis7.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint12 = categoryAxis7.getTickLabelPaint();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder15 = new org.jfree.chart.block.LineBorder(paint12, stroke13, rectangleInsets14);
        categoryAxis2.setAxisLineStroke(stroke13);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryAxis2.setTickMarkPaint((java.awt.Paint) color17);
        categoryAxis2.setTickMarksVisible(false);
        java.awt.Font font21 = categoryAxis2.getTickLabelFont();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = null;
        statisticalBarRenderer22.setBaseItemLabelGenerator(categoryItemLabelGenerator23);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = null;
        statisticalBarRenderer22.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition26, true);
        java.awt.Paint paint29 = statisticalBarRenderer22.getBaseFillPaint();
        boolean boolean30 = statisticalBarRenderer22.getIncludeBaseInRange();
        java.awt.Paint paint31 = statisticalBarRenderer22.getErrorIndicatorPaint();
        org.jfree.chart.text.TextFragment textFragment32 = new org.jfree.chart.text.TextFragment("AxisLocation.BOTTOM_OR_LEFT", font21, paint31);
        float float33 = textFragment32.getBaselineOffset();
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.text.TextAnchor textAnchor37 = null;
        try {
            textFragment32.draw(graphics2D34, (float) 128, (float) 98, textAnchor37, (float) (-2), (float) 100L, Double.NaN);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 0.0f + "'", float33 == 0.0f);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj1 = standardCategorySeriesLabelGenerator0.clone();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getWidth();
        legendTitle3.setHeight((double) (byte) 10);
        java.awt.Font font7 = legendTitle3.getItemFont();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean9 = legendTitle3.equals((java.lang.Object) stroke8);
        org.jfree.chart.axis.AxisSpace axisSpace10 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisSpace10.add(0.0d, rectangleEdge12);
        double double14 = axisSpace10.getTop();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisSpace10.add(0.0d, rectangleEdge16);
        legendTitle3.setLegendItemGraphicEdge(rectangleEdge16);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge16);
        boolean boolean20 = standardCategorySeriesLabelGenerator0.equals((java.lang.Object) rectangleEdge19);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.awt.Font font1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double4 = categoryAxis3.getLabelAngle();
        categoryAxis3.setLowerMargin((double) 0);
        categoryAxis3.setUpperMargin(0.0d);
        java.lang.String str9 = categoryAxis3.getLabel();
        double double10 = categoryAxis3.getUpperMargin();
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke14 = valueMarker13.getOutlineStroke();
        java.awt.Paint paint15 = valueMarker13.getOutlinePaint();
        categoryAxis3.setTickLabelPaint((java.lang.Comparable) 10.0d, paint15);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer20 = new org.jfree.chart.text.G2TextMeasurer(graphics2D19);
        org.jfree.chart.text.TextBlock textBlock21 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint15, 0.0f, 4, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer20);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment22 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        textBlock21.setLineAlignment(horizontalAlignment22);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor28 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition29 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor27, textBlockAnchor28);
        java.awt.Shape shape33 = textBlock21.calculateBounds(graphics2D24, (float) 8, (float) (-1), textBlockAnchor28, (float) 0, (float) 10L, (double) ' ');
        org.jfree.chart.renderer.category.BarRenderer barRenderer34 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = barRenderer34.getSeriesNegativeItemLabelPosition((int) (short) 1);
        boolean boolean37 = textBlock21.equals((java.lang.Object) (short) 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(textBlock21);
        org.junit.Assert.assertNotNull(horizontalAlignment22);
        org.junit.Assert.assertNotNull(rectangleAnchor27);
        org.junit.Assert.assertNotNull(textBlockAnchor28);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(itemLabelPosition36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = null;
        numberAxis7.setMarkerBand(markerAxisBand8);
        java.awt.Stroke stroke10 = numberAxis7.getTickMarkStroke();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis7.setUpArrow(shape12);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color19 = java.awt.Color.RED;
        categoryAxis18.setLabelPaint((java.awt.Paint) color19);
        float[] floatArray25 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray26 = color19.getRGBColorComponents(floatArray25);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity30 = new org.jfree.chart.entity.LegendItemEntity(shape29);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity33 = new org.jfree.chart.entity.TickLabelEntity(shape29, "", "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity36 = new org.jfree.chart.entity.TickLabelEntity(shape29, "hi!", "RectangleConstraintType.RANGE");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier37 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke38 = defaultDrawingSupplier37.getNextOutlineStroke();
        java.awt.Color color39 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("", "ThreadContext", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "DatasetRenderingOrder.FORWARD", true, shape12, true, (java.awt.Paint) color15, true, (java.awt.Paint) color19, stroke27, false, shape29, stroke38, (java.awt.Paint) color39);
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color39, true);
        barRenderer0.setBaseCreateEntities(false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor46 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.axis.TickType tickType51 = org.jfree.chart.axis.TickType.MINOR;
        org.jfree.chart.text.TextAnchor textAnchor54 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor55 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.NumberTick numberTick57 = new org.jfree.chart.axis.NumberTick(tickType51, (double) 'a', "DatasetRenderingOrder.FORWARD", textAnchor54, textAnchor55, 4.0d);
        org.jfree.chart.text.TextAnchor textAnchor58 = numberTick57.getTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor60 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        java.awt.Shape shape61 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D48, (float) (short) 0, (-1.0f), textAnchor58, (double) (-1L), textAnchor60);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition62 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor46, textAnchor60);
        org.jfree.chart.text.TextAnchor textAnchor63 = itemLabelPosition62.getRotationAnchor();
        barRenderer0.setSeriesPositiveItemLabelPosition(255, itemLabelPosition62, false);
        boolean boolean66 = barRenderer0.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(itemLabelAnchor46);
        org.junit.Assert.assertNotNull(tickType51);
        org.junit.Assert.assertNotNull(textAnchor54);
        org.junit.Assert.assertNotNull(textAnchor55);
        org.junit.Assert.assertNotNull(textAnchor58);
        org.junit.Assert.assertNotNull(textAnchor60);
        org.junit.Assert.assertNull(shape61);
        org.junit.Assert.assertNotNull(textAnchor63);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker1.setLabelAnchor(rectangleAnchor3);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = valueMarker1.getLabelOffsetType();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(lengthAdjustmentType5);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition4, true);
        boolean boolean7 = statisticalBarRenderer0.isDrawBarOutline();
        boolean boolean8 = statisticalBarRenderer0.getBaseSeriesVisibleInLegend();
        double double9 = statisticalBarRenderer0.getUpperClip();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        java.awt.Stroke stroke4 = numberAxis1.getTickMarkStroke();
        double double5 = numberAxis1.getUpperBound();
        numberAxis1.zoomRange(Double.NaN, (double) 0L);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = defaultStatisticalCategoryDataset0.getRangeBounds(false);
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.data.general.DatasetChangeListener datasetChangeListener4 = null;
        defaultStatisticalCategoryDataset0.removeChangeListener(datasetChangeListener4);
        org.jfree.data.general.DatasetGroup datasetGroup6 = new org.jfree.data.general.DatasetGroup();
        java.lang.String str7 = datasetGroup6.getID();
        defaultStatisticalCategoryDataset0.setGroup(datasetGroup6);
        int int10 = defaultStatisticalCategoryDataset0.getRowIndex((java.lang.Comparable) 100.0f);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "NOID" + "'", str7.equals("NOID"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset45);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double51 = categoryAxis50.getLabelAngle();
        categoryAxis50.setLowerMargin((double) 0);
        categoryAxis50.setLabel("hi!");
        int int56 = categoryAxis50.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis58.setAutoRange(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer61 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator62 = null;
        statisticalBarRenderer61.setBaseItemLabelGenerator(categoryItemLabelGenerator62);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition65 = null;
        statisticalBarRenderer61.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition65, true);
        boolean boolean68 = statisticalBarRenderer61.isDrawBarOutline();
        boolean boolean69 = statisticalBarRenderer61.getAutoPopulateSeriesPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis50, (org.jfree.chart.axis.ValueAxis) numberAxis58, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer61);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer71 = categoryPlot70.getRenderer();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(categoryItemRenderer71);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke2 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        statisticalBarRenderer0.setSeriesToolTipGenerator(0, categoryToolTipGenerator4, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator7, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setForegroundAlpha((float) (-1));
        statisticalBarRenderer0.setPlot(categoryPlot10);
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        java.awt.Shape shape5 = numberAxis1.getRightArrow();
        numberAxis1.setLowerMargin(100.0d);
        numberAxis1.setUpperMargin(100.0d);
        java.awt.Shape shape10 = numberAxis1.getDownArrow();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset45);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double51 = categoryAxis50.getLabelAngle();
        categoryAxis50.setLowerMargin((double) 0);
        categoryAxis50.setLabel("hi!");
        int int56 = categoryAxis50.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis58.setAutoRange(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer61 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator62 = null;
        statisticalBarRenderer61.setBaseItemLabelGenerator(categoryItemLabelGenerator62);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition65 = null;
        statisticalBarRenderer61.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition65, true);
        boolean boolean68 = statisticalBarRenderer61.isDrawBarOutline();
        boolean boolean69 = statisticalBarRenderer61.getAutoPopulateSeriesPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis50, (org.jfree.chart.axis.ValueAxis) numberAxis58, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer61);
        categoryPlot70.clearRangeMarkers(10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer73 = categoryPlot70.getRenderer();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(categoryItemRenderer73);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset(10.0d);
        double double4 = rectangleInsets0.extendHeight((double) (-16777216));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.6777212E7d) + "'", double4 == (-1.6777212E7d));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        boolean boolean3 = itemLabelAnchor0.equals((java.lang.Object) legendTitle2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color6 = java.awt.Color.RED;
        categoryAxis5.setLabelPaint((java.awt.Paint) color6);
        categoryAxis5.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint10 = categoryAxis5.getTickLabelPaint();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder(paint10, stroke11, rectangleInsets12);
        legendTitle2.setFrame((org.jfree.chart.block.BlockFrame) lineBorder13);
        java.awt.Paint paint15 = legendTitle2.getItemPaint();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setForegroundAlpha((float) (-1));
        int int3 = categoryPlot0.getWeight();
        boolean boolean4 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo7);
        org.jfree.chart.renderer.RendererState rendererState9 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = rendererState9.getInfo();
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 10, (double) (short) 10, plotRenderingInfo10, point2D11);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryPlot0.setNoDataMessageFont(font13);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation15 = null;
        try {
            boolean boolean16 = categoryPlot0.removeAnnotation(categoryAnnotation15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(plotRenderingInfo10);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition4, true);
        java.awt.Paint paint7 = statisticalBarRenderer0.getBaseFillPaint();
        boolean boolean8 = statisticalBarRenderer0.getIncludeBaseInRange();
        java.awt.Paint paint9 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor10 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.TickType tickType15 = org.jfree.chart.axis.TickType.MINOR;
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor19 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.NumberTick numberTick21 = new org.jfree.chart.axis.NumberTick(tickType15, (double) 'a', "DatasetRenderingOrder.FORWARD", textAnchor18, textAnchor19, 4.0d);
        org.jfree.chart.text.TextAnchor textAnchor22 = numberTick21.getTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        java.awt.Shape shape25 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D12, (float) (short) 0, (-1.0f), textAnchor22, (double) (-1L), textAnchor24);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor10, textAnchor24);
        statisticalBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition26);
        java.awt.Font font32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color33 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment34 = new org.jfree.chart.text.TextFragment("ThreadContext", font32, (java.awt.Paint) color33);
        org.jfree.chart.text.TextLine textLine35 = new org.jfree.chart.text.TextLine("", font32);
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke38 = valueMarker37.getOutlineStroke();
        java.awt.Paint paint39 = valueMarker37.getOutlinePaint();
        org.jfree.chart.text.TextFragment textFragment40 = new org.jfree.chart.text.TextFragment("-3,-3,3,3", font32, paint39);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier41 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke42 = defaultDrawingSupplier41.getNextOutlineStroke();
        java.awt.Stroke stroke43 = defaultDrawingSupplier41.getNextStroke();
        java.awt.Paint paint44 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double47 = categoryAxis46.getLabelAngle();
        categoryAxis46.setLowerMargin((double) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color52 = java.awt.Color.RED;
        categoryAxis51.setLabelPaint((java.awt.Paint) color52);
        categoryAxis51.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint56 = categoryAxis51.getTickLabelPaint();
        java.awt.Stroke stroke57 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder59 = new org.jfree.chart.block.LineBorder(paint56, stroke57, rectangleInsets58);
        categoryAxis46.setAxisLineStroke(stroke57);
        org.jfree.chart.plot.ValueMarker valueMarker62 = new org.jfree.chart.plot.ValueMarker((double) 10L, paint39, stroke43, paint44, stroke57, (float) (short) 1);
        statisticalBarRenderer0.setBaseOutlineStroke(stroke43, false);
        java.lang.Boolean boolean66 = statisticalBarRenderer0.getSeriesItemLabelsVisible((int) ' ');
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(itemLabelAnchor10);
        org.junit.Assert.assertNotNull(tickType15);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNull(shape25);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNull(boolean66);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        java.awt.Color color3 = java.awt.Color.getColor("CONTRACT", (int) (short) 100);
        java.awt.Color color4 = java.awt.Color.getColor("RectangleConstraint[LengthConstraintType.NONE: width=1.0, height=0.0]", color3);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color7 = java.awt.Color.RED;
        categoryAxis6.setLabelPaint((java.awt.Paint) color7);
        float[] floatArray13 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray14 = color7.getRGBColorComponents(floatArray13);
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape4, (java.awt.Paint) color7);
        java.lang.Object obj16 = legendGraphic15.clone();
        legendGraphic15.setShapeVisible(false);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        legendGraphic15.setShapeAnchor(rectangleAnchor19);
        org.jfree.chart.axis.AxisSpace axisSpace21 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisSpace21.add(0.0d, rectangleEdge23);
        double double25 = axisSpace21.getTop();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisSpace21.add(0.0d, rectangleEdge27);
        boolean boolean29 = legendGraphic15.equals((java.lang.Object) axisSpace21);
        double double30 = axisSpace21.getRight();
        axisSpace21.setLeft((double) 3);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        java.awt.Stroke stroke4 = numberAxis1.getTickMarkStroke();
        double double5 = numberAxis1.getUpperBound();
        double double6 = numberAxis1.getAutoRangeMinimumSize();
        numberAxis1.setFixedAutoRange((double) 0L);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-8d + "'", double6 == 1.0E-8d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("CONTRACT", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        java.awt.Color color0 = java.awt.Color.magenta;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        boolean boolean3 = itemLabelAnchor0.equals((java.lang.Object) legendTitle2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color6 = java.awt.Color.RED;
        categoryAxis5.setLabelPaint((java.awt.Paint) color6);
        categoryAxis5.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint10 = categoryAxis5.getTickLabelPaint();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder(paint10, stroke11, rectangleInsets12);
        legendTitle2.setFrame((org.jfree.chart.block.BlockFrame) lineBorder13);
        java.awt.Stroke stroke15 = lineBorder13.getStroke();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.block.BlockContainer blockContainer3 = null;
        legendTitle1.setWrapper(blockContainer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color7 = java.awt.Color.RED;
        categoryAxis6.setLabelPaint((java.awt.Paint) color7);
        categoryAxis6.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint11 = categoryAxis6.getTickLabelPaint();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder(paint11, stroke12, rectangleInsets13);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = lineBorder14.getInsets();
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        double[] doubleArray9 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray16 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray23 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray30 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray37 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray44 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray45);
        org.jfree.data.general.PieDataset pieDataset48 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset46, (int) (short) 0);
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset46);
        double double50 = range49.getUpperBound();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint51 = new org.jfree.chart.block.RectangleConstraint((double) 15, range49);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(pieDataset48);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 44.0d + "'", double50 == 44.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset45);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double51 = categoryAxis50.getLabelAngle();
        categoryAxis50.setLowerMargin((double) 0);
        categoryAxis50.setLabel("hi!");
        int int56 = categoryAxis50.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis58.setAutoRange(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer61 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator62 = null;
        statisticalBarRenderer61.setBaseItemLabelGenerator(categoryItemLabelGenerator62);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition65 = null;
        statisticalBarRenderer61.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition65, true);
        boolean boolean68 = statisticalBarRenderer61.isDrawBarOutline();
        boolean boolean69 = statisticalBarRenderer61.getAutoPopulateSeriesPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis50, (org.jfree.chart.axis.ValueAxis) numberAxis58, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer61);
        java.lang.Object obj71 = categoryPlot70.clone();
        categoryPlot70.setRangeCrosshairValue((double) (byte) 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = categoryPlot70.getRangeAxisEdge();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray75 = null;
        try {
            categoryPlot70.setRangeAxes(valueAxisArray75);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(obj71);
        org.junit.Assert.assertNotNull(rectangleEdge74);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition4, true);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        java.awt.Paint paint9 = numberAxis8.getLabelPaint();
        statisticalBarRenderer0.setErrorIndicatorPaint(paint9);
        statisticalBarRenderer0.setBaseSeriesVisibleInLegend(false);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setForegroundAlpha((float) (-1));
        org.jfree.chart.LegendItemCollection legendItemCollection3 = categoryPlot0.getLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double7 = categoryAxis6.getLabelAngle();
        categoryAxis6.setLowerMargin((double) 0);
        categoryAxis6.setUpperMargin(0.0d);
        java.lang.String str12 = categoryAxis6.getLabel();
        double double13 = categoryAxis6.getUpperMargin();
        org.jfree.chart.LegendItemSource legendItemSource15 = null;
        org.jfree.chart.title.LegendTitle legendTitle16 = new org.jfree.chart.title.LegendTitle(legendItemSource15);
        double double17 = legendTitle16.getWidth();
        legendTitle16.setHeight((double) (byte) 10);
        java.awt.Font font20 = legendTitle16.getItemFont();
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("", font20);
        categoryAxis6.setTickLabelFont(font20);
        boolean boolean23 = legendItemCollection4.equals((java.lang.Object) categoryAxis6);
        legendItemCollection3.addAll(legendItemCollection4);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setForegroundAlpha((float) (-1));
        int int3 = categoryPlot0.getWeight();
        boolean boolean4 = categoryPlot0.isRangeZoomable();
        categoryPlot0.setRangeCrosshairVisible(true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = statisticalBarRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke2 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke5 = valueMarker4.getOutlineStroke();
        statisticalBarRenderer0.setErrorIndicatorStroke(stroke5);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = statisticalBarRenderer7.getNegativeItemLabelPosition((int) (byte) 0, (int) (byte) -1);
        boolean boolean11 = statisticalBarRenderer7.getBaseSeriesVisibleInLegend();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer7.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = null;
        try {
            statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((-16777216), itemLabelPosition15, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset45);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double51 = categoryAxis50.getLabelAngle();
        categoryAxis50.setLowerMargin((double) 0);
        categoryAxis50.setLabel("hi!");
        int int56 = categoryAxis50.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis58.setAutoRange(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer61 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator62 = null;
        statisticalBarRenderer61.setBaseItemLabelGenerator(categoryItemLabelGenerator62);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition65 = null;
        statisticalBarRenderer61.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition65, true);
        boolean boolean68 = statisticalBarRenderer61.isDrawBarOutline();
        boolean boolean69 = statisticalBarRenderer61.getAutoPopulateSeriesPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis50, (org.jfree.chart.axis.ValueAxis) numberAxis58, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer61);
        java.lang.Object obj71 = categoryPlot70.clone();
        categoryPlot70.setRangeCrosshairValue((double) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation75 = categoryPlot70.getDomainAxisLocation(100);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo77 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo78 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo77);
        java.awt.geom.Point2D point2D79 = null;
        categoryPlot70.zoomRangeAxes((double) 100L, plotRenderingInfo78, point2D79);
        org.jfree.chart.util.SortOrder sortOrder81 = null;
        try {
            categoryPlot70.setColumnRenderingOrder(sortOrder81);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(obj71);
        org.junit.Assert.assertNotNull(axisLocation75);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double[] doubleArray9 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray16 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray23 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray30 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray37 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray44 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray45);
        org.jfree.data.general.PieDataset pieDataset48 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset46, (int) (short) 0);
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset46);
        boolean boolean52 = range49.intersects((double) 1.0f, 0.0d);
        boolean boolean55 = range49.intersects((double) 2.0f, (double) 8);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint56 = new org.jfree.chart.block.RectangleConstraint(range0, range49);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(pieDataset48);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        java.util.Locale locale1 = null;
        java.lang.Class class2 = null;
        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
        java.util.ResourceBundle.clearCache(classLoader3);
        try {
            java.util.ResourceBundle resourceBundle5 = java.util.ResourceBundle.getBundle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", locale1, classLoader3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(classLoader3);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setAutoRange(false);
        java.awt.Shape shape4 = numberAxis1.getRightArrow();
        numberAxis1.setPositiveArrowVisible(false);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("java.awt.Color[r=192,g=192,b=0]");
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = null;
        numberAxis7.setMarkerBand(markerAxisBand8);
        java.awt.Stroke stroke10 = numberAxis7.getTickMarkStroke();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis7.setUpArrow(shape12);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color19 = java.awt.Color.RED;
        categoryAxis18.setLabelPaint((java.awt.Paint) color19);
        float[] floatArray25 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray26 = color19.getRGBColorComponents(floatArray25);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity30 = new org.jfree.chart.entity.LegendItemEntity(shape29);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity33 = new org.jfree.chart.entity.TickLabelEntity(shape29, "", "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity36 = new org.jfree.chart.entity.TickLabelEntity(shape29, "hi!", "RectangleConstraintType.RANGE");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier37 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke38 = defaultDrawingSupplier37.getNextOutlineStroke();
        java.awt.Color color39 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("", "ThreadContext", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "DatasetRenderingOrder.FORWARD", true, shape12, true, (java.awt.Paint) color15, true, (java.awt.Paint) color19, stroke27, false, shape29, stroke38, (java.awt.Paint) color39);
        java.awt.Paint paint41 = legendItem40.getOutlinePaint();
        legendItemCollection0.add(legendItem40);
        java.lang.Object obj43 = legendItemCollection0.clone();
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(obj43);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset45);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double51 = categoryAxis50.getLabelAngle();
        categoryAxis50.setLowerMargin((double) 0);
        categoryAxis50.setLabel("hi!");
        int int56 = categoryAxis50.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis58.setAutoRange(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer61 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator62 = null;
        statisticalBarRenderer61.setBaseItemLabelGenerator(categoryItemLabelGenerator62);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition65 = null;
        statisticalBarRenderer61.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition65, true);
        boolean boolean68 = statisticalBarRenderer61.isDrawBarOutline();
        boolean boolean69 = statisticalBarRenderer61.getAutoPopulateSeriesPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis50, (org.jfree.chart.axis.ValueAxis) numberAxis58, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer61);
        java.lang.Object obj71 = categoryPlot70.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets72 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double74 = rectangleInsets72.trimWidth((double) 1L);
        double double76 = rectangleInsets72.trimWidth((double) 1L);
        double double78 = rectangleInsets72.calculateTopOutset((double) (byte) 10);
        categoryPlot70.setInsets(rectangleInsets72);
        org.jfree.chart.axis.CategoryAxis categoryAxis82 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double83 = categoryAxis82.getLabelAngle();
        categoryAxis82.setLowerMargin((double) 0);
        categoryAxis82.setUpperMargin(0.0d);
        categoryPlot70.setDomainAxis(4, categoryAxis82, true);
        double double90 = categoryAxis82.getLowerMargin();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(obj71);
        org.junit.Assert.assertNotNull(rectangleInsets72);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + (-7.0d) + "'", double74 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + (-7.0d) + "'", double76 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 2.0d + "'", double78 == 2.0d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        numberAxis1.setTickMarkInsideLength((float) 100L);
        boolean boolean6 = numberAxis1.isPositiveArrowVisible();
        numberAxis1.setLowerBound((double) 0.8f);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = null;
        numberAxis7.setMarkerBand(markerAxisBand8);
        java.awt.Stroke stroke10 = numberAxis7.getTickMarkStroke();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis7.setUpArrow(shape12);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color19 = java.awt.Color.RED;
        categoryAxis18.setLabelPaint((java.awt.Paint) color19);
        float[] floatArray25 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray26 = color19.getRGBColorComponents(floatArray25);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity30 = new org.jfree.chart.entity.LegendItemEntity(shape29);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity33 = new org.jfree.chart.entity.TickLabelEntity(shape29, "", "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity36 = new org.jfree.chart.entity.TickLabelEntity(shape29, "hi!", "RectangleConstraintType.RANGE");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier37 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke38 = defaultDrawingSupplier37.getNextOutlineStroke();
        java.awt.Color color39 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("", "ThreadContext", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "DatasetRenderingOrder.FORWARD", true, shape12, true, (java.awt.Paint) color15, true, (java.awt.Paint) color19, stroke27, false, shape29, stroke38, (java.awt.Paint) color39);
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color39, true);
        boolean boolean43 = barRenderer0.getAutoPopulateSeriesShape();
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset45);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double51 = categoryAxis50.getLabelAngle();
        categoryAxis50.setLowerMargin((double) 0);
        categoryAxis50.setLabel("hi!");
        int int56 = categoryAxis50.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis58.setAutoRange(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer61 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator62 = null;
        statisticalBarRenderer61.setBaseItemLabelGenerator(categoryItemLabelGenerator62);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition65 = null;
        statisticalBarRenderer61.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition65, true);
        boolean boolean68 = statisticalBarRenderer61.isDrawBarOutline();
        boolean boolean69 = statisticalBarRenderer61.getAutoPopulateSeriesPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis50, (org.jfree.chart.axis.ValueAxis) numberAxis58, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer61);
        java.lang.Object obj71 = categoryPlot70.clone();
        categoryPlot70.setRangeCrosshairValue((double) (byte) 0);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset74 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range76 = defaultStatisticalCategoryDataset74.getRangeBounds(false);
        int int77 = defaultStatisticalCategoryDataset74.getColumnCount();
        org.jfree.data.general.DatasetChangeListener datasetChangeListener78 = null;
        defaultStatisticalCategoryDataset74.removeChangeListener(datasetChangeListener78);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer80 = categoryPlot70.getRendererForDataset((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset74);
        java.awt.Font font81 = categoryPlot70.getNoDataMessageFont();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(obj71);
        org.junit.Assert.assertNull(range76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNull(categoryItemRenderer80);
        org.junit.Assert.assertNotNull(font81);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot3.getColumnRenderingOrder();
        valueMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot3);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        plotRenderingInfo9.setDataArea(rectangle2D10);
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot3.zoomRangeAxes((double) (-2), (double) (short) 100, plotRenderingInfo9, point2D12);
        categoryPlot3.setAnchorValue(0.0d, true);
        org.jfree.data.category.CategoryDataset categoryDataset17 = categoryPlot3.getDataset();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertNull(categoryDataset17);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 10, 100.0f);
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.clone(shape6);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color10 = java.awt.Color.getColor("", color9);
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("", "RangeType.FULL", "SortOrder.DESCENDING", "ClassContext", shape7, (java.awt.Paint) color10);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = statisticalBarRenderer12.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke14 = statisticalBarRenderer12.getBaseStroke();
        statisticalBarRenderer12.setAutoPopulateSeriesStroke(false);
        java.lang.Boolean boolean18 = statisticalBarRenderer12.getSeriesCreateEntities((int) (short) 100);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand26 = null;
        numberAxis25.setMarkerBand(markerAxisBand26);
        java.awt.Stroke stroke28 = numberAxis25.getTickMarkStroke();
        java.awt.Shape shape30 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis25.setUpArrow(shape30);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color37 = java.awt.Color.RED;
        categoryAxis36.setLabelPaint((java.awt.Paint) color37);
        float[] floatArray43 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray44 = color37.getRGBColorComponents(floatArray43);
        java.awt.Stroke stroke45 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape47 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity48 = new org.jfree.chart.entity.LegendItemEntity(shape47);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity51 = new org.jfree.chart.entity.TickLabelEntity(shape47, "", "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity54 = new org.jfree.chart.entity.TickLabelEntity(shape47, "hi!", "RectangleConstraintType.RANGE");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier55 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke56 = defaultDrawingSupplier55.getNextOutlineStroke();
        java.awt.Color color57 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem58 = new org.jfree.chart.LegendItem("", "ThreadContext", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "DatasetRenderingOrder.FORWARD", true, shape30, true, (java.awt.Paint) color33, true, (java.awt.Paint) color37, stroke45, false, shape47, stroke56, (java.awt.Paint) color57);
        java.awt.Paint paint59 = legendItem58.getOutlinePaint();
        java.awt.Paint paint60 = legendItem58.getFillPaint();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer61 = legendItem58.getFillPaintTransformer();
        statisticalBarRenderer12.setGradientPaintTransformer(gradientPaintTransformer61);
        legendItem11.setFillPaintTransformer(gradientPaintTransformer61);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(boolean18);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(gradientPaintTransformer61);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        numberAxis1.setTickMarkInsideLength((float) 100L);
        boolean boolean6 = numberAxis1.isPositiveArrowVisible();
        numberAxis1.setFixedAutoRange(0.5d);
        double double9 = numberAxis1.getLowerBound();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset(10.0d);
        double double4 = rectangleInsets0.calculateBottomOutset(2.0d);
        double double5 = rectangleInsets0.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis5.setMarkerBand(markerAxisBand6);
        java.awt.Stroke stroke8 = numberAxis5.getTickMarkStroke();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis5.setUpArrow(shape10);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape10, (double) (byte) 10, 1.0E-8d);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand17 = null;
        numberAxis16.setMarkerBand(markerAxisBand17);
        java.awt.Stroke stroke19 = numberAxis16.getTickMarkStroke();
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color22 = java.awt.Color.getColor("", color21);
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "hi!", shape14, stroke19, (java.awt.Paint) color21);
        java.awt.Shape shape24 = legendItem23.getShape();
        java.lang.String str25 = legendItem23.getToolTipText();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str25.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape0, "", "");
        tickLabelEntity4.setURLText("ThreadContext");
        java.lang.Object obj7 = tickLabelEntity4.clone();
        java.lang.String str8 = tickLabelEntity4.getShapeCoords();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-3,-3,3,3" + "'", str8.equals("-3,-3,3,3"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        java.awt.Shape shape5 = numberAxis1.getRightArrow();
        numberAxis1.setLabelToolTip("LGPL");
        double[] doubleArray16 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray23 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray30 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray37 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray44 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray51 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray52 = new double[][] { doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44, doubleArray51 };
        org.jfree.data.category.CategoryDataset categoryDataset53 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray52);
        org.jfree.data.general.PieDataset pieDataset55 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset53, (int) (short) 0);
        org.jfree.data.Range range56 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset53);
        double double57 = range56.getUpperBound();
        double double58 = range56.getLength();
        numberAxis1.setRange(range56, false, false);
        org.jfree.data.Range range63 = org.jfree.data.Range.shift(range56, (double) (byte) -1);
        double double64 = range63.getCentralValue();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(categoryDataset53);
        org.junit.Assert.assertNotNull(pieDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 44.0d + "'", double57 == 44.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 44.0d + "'", double58 == 44.0d);
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 21.0d + "'", double64 == 21.0d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=192,g=192,b=0]", "hi!", "NOID", "-3,-3,3,3", "");
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        double[] doubleArray10 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray17 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray24 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray31 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray38 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray45 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray46 = new double[][] { doubleArray10, doubleArray17, doubleArray24, doubleArray31, doubleArray38, doubleArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset47, (int) (short) 0);
        legendItemEntity1.setDataset((org.jfree.data.general.Dataset) pieDataset49);
        java.lang.String str51 = legendItemEntity1.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(pieDataset49);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setForegroundAlpha((float) (-1));
        int int3 = categoryPlot0.getWeight();
        boolean boolean4 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo7);
        org.jfree.chart.renderer.RendererState rendererState9 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = rendererState9.getInfo();
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomRangeAxes((double) (byte) 10, (double) (short) 10, plotRenderingInfo10, point2D11);
        float float13 = categoryPlot0.getBackgroundAlpha();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(plotRenderingInfo10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        java.awt.Stroke stroke4 = numberAxis1.getTickMarkStroke();
        numberAxis1.setUpperMargin((double) 0.5f);
        java.awt.Paint paint7 = numberAxis1.getLabelPaint();
        java.util.EventListener eventListener8 = null;
        boolean boolean9 = numberAxis1.hasListener(eventListener8);
        numberAxis1.configure();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str1 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str1.equals("VerticalAlignment.BOTTOM"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        java.awt.Stroke stroke4 = numberAxis1.getTickMarkStroke();
        numberAxis1.setUpperMargin((double) (-1));
        org.jfree.chart.event.AxisChangeListener axisChangeListener7 = null;
        numberAxis1.removeChangeListener(axisChangeListener7);
        numberAxis1.centerRange((double) (byte) -1);
        numberAxis1.setLabel("");
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalBarRenderer0.getPositiveItemLabelPosition((int) '#', (int) (byte) -1);
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke6 = valueMarker5.getOutlineStroke();
        java.awt.Paint paint7 = valueMarker5.getOutlinePaint();
        java.awt.Paint paint8 = valueMarker5.getLabelPaint();
        java.awt.Stroke stroke9 = valueMarker5.getOutlineStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke9);
        statisticalBarRenderer0.setBaseItemLabelsVisible(false);
        double double13 = statisticalBarRenderer0.getBase();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = null;
        statisticalBarRenderer0.setBaseURLGenerator(categoryURLGenerator14);
        java.awt.Color color17 = java.awt.Color.MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color17);
        statisticalBarRenderer0.setSeriesOutlinePaint((int) (byte) 1, (java.awt.Paint) color17);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.data.function.Function2D function2D0 = null;
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str5 = numberTickUnit4.toString();
        java.lang.String str6 = numberTickUnit4.toString();
        try {
            org.jfree.data.xy.XYDataset xYDataset7 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (byte) -1, 32.0d, 3, (java.lang.Comparable) numberTickUnit4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[size=1]" + "'", str5.equals("[size=1]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[size=1]" + "'", str6.equals("[size=1]"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = defaultStatisticalCategoryDataset0.getRangeBounds(false);
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.data.general.DatasetChangeListener datasetChangeListener4 = null;
        defaultStatisticalCategoryDataset0.removeChangeListener(datasetChangeListener4);
        double double7 = defaultStatisticalCategoryDataset0.getRangeLowerBound(false);
        try {
            java.lang.Number number10 = defaultStatisticalCategoryDataset0.getStdDevValue(0, 98);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double3 = categoryAxis2.getLabelAngle();
        java.awt.Font font5 = categoryAxis2.getTickLabelFont((java.lang.Comparable) 10.0d);
        double double6 = categoryAxis2.getLabelAngle();
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape7, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color14 = java.awt.Color.RED;
        categoryAxis13.setLabelPaint((java.awt.Paint) color14);
        float[] floatArray20 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray21 = color14.getRGBColorComponents(floatArray20);
        org.jfree.chart.title.LegendGraphic legendGraphic22 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color14);
        java.awt.Shape shape23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape23, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color30 = java.awt.Color.RED;
        categoryAxis29.setLabelPaint((java.awt.Paint) color30);
        float[] floatArray36 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray37 = color30.getRGBColorComponents(floatArray36);
        org.jfree.chart.title.LegendGraphic legendGraphic38 = new org.jfree.chart.title.LegendGraphic(shape27, (java.awt.Paint) color30);
        legendGraphic22.setLinePaint((java.awt.Paint) color30);
        boolean boolean40 = categoryAxis2.equals((java.lang.Object) legendGraphic22);
        java.awt.Stroke stroke41 = null;
        legendGraphic22.setOutlineStroke(stroke41);
        org.jfree.data.KeyedObject keyedObject43 = new org.jfree.data.KeyedObject((java.lang.Comparable) 1, (java.lang.Object) legendGraphic22);
        java.lang.Comparable comparable44 = keyedObject43.getKey();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + comparable44 + "' != '" + 1 + "'", comparable44.equals(1));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getMinimumBarLength();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = statisticalBarRenderer0.getSeriesItemLabelGenerator((-2));
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = statisticalBarRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        boolean boolean3 = itemLabelAnchor0.equals((java.lang.Object) legendTitle2);
        java.awt.Font font9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color10 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("ThreadContext", font9, (java.awt.Paint) color10);
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("", font9);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("hi!", font9);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.lang.Object obj17 = textTitle13.draw(graphics2D14, rectangle2D15, (java.lang.Object) (byte) 100);
        java.awt.Font font19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color20 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("ThreadContext", font19, (java.awt.Paint) color20);
        textTitle13.setFont(font19);
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("RangeType.FULL", font19);
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color27 = java.awt.Color.getColor("", color26);
        java.awt.Color color28 = java.awt.Color.getColor("ThreadContext", color27);
        org.jfree.chart.axis.AxisSpace axisSpace29 = new org.jfree.chart.axis.AxisSpace();
        axisSpace29.setBottom((double) '#');
        double double32 = axisSpace29.getLeft();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.lang.Object obj35 = null;
        boolean boolean36 = rectangleEdge34.equals(obj35);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge34);
        axisSpace29.ensureAtLeast((double) 100, rectangleEdge34);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment39 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor40 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean41 = horizontalAlignment39.equals((java.lang.Object) textAnchor40);
        org.jfree.chart.util.VerticalAlignment verticalAlignment42 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.lang.String str43 = verticalAlignment42.toString();
        org.jfree.chart.block.FlowArrangement flowArrangement44 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement44.clear();
        org.jfree.chart.LegendItemSource legendItemSource46 = null;
        org.jfree.chart.title.LegendTitle legendTitle47 = new org.jfree.chart.title.LegendTitle(legendItemSource46);
        org.jfree.chart.LegendItemSource legendItemSource48 = null;
        org.jfree.chart.title.LegendTitle legendTitle49 = new org.jfree.chart.title.LegendTitle(legendItemSource48);
        double double50 = legendTitle49.getHeight();
        flowArrangement44.add((org.jfree.chart.block.Block) legendTitle47, (java.lang.Object) double50);
        legendTitle47.setWidth((double) (byte) -1);
        java.awt.Paint paint54 = legendTitle47.getItemPaint();
        boolean boolean55 = verticalAlignment42.equals((java.lang.Object) paint54);
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double58 = rectangleInsets56.trimWidth((double) 1L);
        java.lang.String str59 = rectangleInsets56.toString();
        org.jfree.chart.title.TextTitle textTitle60 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font19, (java.awt.Paint) color28, rectangleEdge34, horizontalAlignment39, verticalAlignment42, rectangleInsets56);
        legendTitle2.setVerticalAlignment(verticalAlignment42);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(obj17);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNotNull(horizontalAlignment39);
        org.junit.Assert.assertNotNull(textAnchor40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(verticalAlignment42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "VerticalAlignment.CENTER" + "'", str43.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + (-7.0d) + "'", double58 == (-7.0d));
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str59.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double3 = categoryAxis2.getLabelAngle();
        java.awt.Font font5 = categoryAxis2.getTickLabelFont((java.lang.Comparable) 10.0d);
        double double6 = categoryAxis2.getLabelAngle();
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape7, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color14 = java.awt.Color.RED;
        categoryAxis13.setLabelPaint((java.awt.Paint) color14);
        float[] floatArray20 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray21 = color14.getRGBColorComponents(floatArray20);
        org.jfree.chart.title.LegendGraphic legendGraphic22 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color14);
        java.awt.Shape shape23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape23, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color30 = java.awt.Color.RED;
        categoryAxis29.setLabelPaint((java.awt.Paint) color30);
        float[] floatArray36 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray37 = color30.getRGBColorComponents(floatArray36);
        org.jfree.chart.title.LegendGraphic legendGraphic38 = new org.jfree.chart.title.LegendGraphic(shape27, (java.awt.Paint) color30);
        legendGraphic22.setLinePaint((java.awt.Paint) color30);
        boolean boolean40 = categoryAxis2.equals((java.lang.Object) legendGraphic22);
        java.awt.Stroke stroke41 = null;
        legendGraphic22.setOutlineStroke(stroke41);
        org.jfree.data.KeyedObject keyedObject43 = new org.jfree.data.KeyedObject((java.lang.Comparable) 1, (java.lang.Object) legendGraphic22);
        java.lang.Object obj44 = keyedObject43.clone();
        java.lang.Object obj45 = keyedObject43.getObject();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertNotNull(obj45);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset45);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double51 = categoryAxis50.getLabelAngle();
        categoryAxis50.setLowerMargin((double) 0);
        categoryAxis50.setLabel("hi!");
        int int56 = categoryAxis50.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis58.setAutoRange(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer61 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator62 = null;
        statisticalBarRenderer61.setBaseItemLabelGenerator(categoryItemLabelGenerator62);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition65 = null;
        statisticalBarRenderer61.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition65, true);
        boolean boolean68 = statisticalBarRenderer61.isDrawBarOutline();
        boolean boolean69 = statisticalBarRenderer61.getAutoPopulateSeriesPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis50, (org.jfree.chart.axis.ValueAxis) numberAxis58, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer61);
        java.lang.Object obj71 = categoryPlot70.clone();
        categoryPlot70.setRangeCrosshairValue((double) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation75 = categoryPlot70.getDomainAxisLocation(100);
        categoryPlot70.configureDomainAxes();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(obj71);
        org.junit.Assert.assertNotNull(axisLocation75);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean2 = categoryLabelPosition0.equals((java.lang.Object) categoryLabelPosition1);
        org.jfree.chart.text.TextAnchor textAnchor3 = categoryLabelPosition0.getRotationAnchor();
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke6 = valueMarker5.getOutlineStroke();
        boolean boolean7 = categoryLabelPosition0.equals((java.lang.Object) valueMarker5);
        java.awt.Font font8 = valueMarker5.getLabelFont();
        valueMarker5.setAlpha(0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.clear();
        org.jfree.chart.block.BlockContainer blockContainer2 = new org.jfree.chart.block.BlockContainer();
        blockContainer2.clear();
        org.jfree.data.Range range5 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) 0, range7);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = rectangleConstraint8.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType11 = rectangleConstraint10.getHeightConstraintType();
        org.jfree.data.Range range13 = null;
        org.jfree.data.Range range15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) 0, range15);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = rectangleConstraint16.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType19 = rectangleConstraint18.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range5, lengthConstraintType11, 0.0d, range13, lengthConstraintType19);
        double double21 = range5.getLowerBound();
        double double22 = range5.getCentralValue();
        try {
            blockContainer0.add((org.jfree.chart.block.Block) blockContainer2, (java.lang.Object) range5);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.Range cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(rectangleConstraint10);
        org.junit.Assert.assertNotNull(lengthConstraintType11);
        org.junit.Assert.assertNotNull(rectangleConstraint18);
        org.junit.Assert.assertNotNull(lengthConstraintType19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.5d + "'", double22 == 0.5d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition4, true);
        boolean boolean8 = statisticalBarRenderer0.isSeriesItemLabelsVisible(100);
        org.jfree.chart.block.CenterArrangement centerArrangement10 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = null;
        statisticalBarRenderer11.setBaseItemLabelGenerator(categoryItemLabelGenerator12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = null;
        statisticalBarRenderer11.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition15, true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke19 = defaultDrawingSupplier18.getNextOutlineStroke();
        java.awt.Stroke stroke20 = defaultDrawingSupplier18.getNextStroke();
        statisticalBarRenderer11.setErrorIndicatorStroke(stroke20);
        boolean boolean22 = centerArrangement10.equals((java.lang.Object) stroke20);
        statisticalBarRenderer0.setSeriesOutlineStroke((int) (byte) 100, stroke20, false);
        statisticalBarRenderer0.removeAnnotations();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = statisticalBarRenderer26.getNegativeItemLabelPosition((int) (byte) 0, (int) (byte) -1);
        boolean boolean30 = statisticalBarRenderer26.getBaseSeriesVisibleInLegend();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator31 = statisticalBarRenderer26.getLegendItemLabelGenerator();
        statisticalBarRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator31);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator31);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean2 = categoryLabelPosition0.equals((java.lang.Object) categoryLabelPosition1);
        org.jfree.chart.text.TextAnchor textAnchor3 = categoryLabelPosition0.getRotationAnchor();
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke6 = valueMarker5.getOutlineStroke();
        boolean boolean7 = categoryLabelPosition0.equals((java.lang.Object) valueMarker5);
        java.awt.Font font8 = valueMarker5.getLabelFont();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = null;
        numberAxis10.setMarkerBand(markerAxisBand11);
        java.awt.Stroke stroke13 = numberAxis10.getTickMarkStroke();
        numberAxis10.setUpperMargin((double) (-1));
        boolean boolean16 = numberAxis10.isPositiveArrowVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double19 = rectangleInsets17.trimWidth((double) 1L);
        double double21 = rectangleInsets17.trimWidth((double) 1L);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder(rectangleInsets17, (java.awt.Paint) color22);
        numberAxis10.setTickMarkPaint((java.awt.Paint) color22);
        valueMarker5.setPaint((java.awt.Paint) color22);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-7.0d) + "'", double19 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-7.0d) + "'", double21 == (-7.0d));
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder4 = categoryPlot3.getColumnRenderingOrder();
        valueMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot3);
        categoryPlot3.setOutlineVisible(false);
        boolean boolean8 = categoryPlot3.isSubplot();
        org.jfree.chart.util.SortOrder sortOrder9 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean11 = sortOrder9.equals((java.lang.Object) categoryAxis10);
        categoryPlot3.setRowRenderingOrder(sortOrder9);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(sortOrder4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(sortOrder9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setForegroundAlpha((float) (-1));
        int int3 = categoryPlot0.getWeight();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        java.util.List list5 = categoryPlot0.getCategoriesForAxis(categoryAxis4);
        categoryPlot0.clearAnnotations();
        categoryPlot0.setRangeCrosshairValue((double) (-1));
        categoryPlot0.setRangeCrosshairValue(0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number3 = defaultStatisticalCategoryDataset0.getStdDevValue((java.lang.Comparable) "VerticalAlignment.CENTER", (java.lang.Comparable) (short) 10);
        int int5 = defaultStatisticalCategoryDataset0.getRowIndex((java.lang.Comparable) "hi!");
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setForegroundAlpha((float) (-1));
        defaultStatisticalCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot6);
        categoryPlot6.configureDomainAxes();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor11 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot6.setDomainGridlinePosition(categoryAnchor11);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(categoryAnchor11);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setForegroundAlpha((float) (-1));
        int int3 = categoryPlot0.getWeight();
        boolean boolean4 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = null;
        statisticalBarRenderer5.setBaseItemLabelGenerator(categoryItemLabelGenerator6);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer5, true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        java.awt.Stroke stroke4 = numberAxis1.getTickMarkStroke();
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis1.setUpArrow(shape6);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape6, (double) (byte) 10, 1.0E-8d);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape10, 2.0d, (float) 2, (float) 100L);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.clone(shape14);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color4 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("ThreadContext", font3, (java.awt.Paint) color4);
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("", font3);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("hi!", font3);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.lang.Object obj11 = textTitle7.draw(graphics2D8, rectangle2D9, (java.lang.Object) (byte) 100);
        textTitle7.setText("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint14 = textTitle7.getBackgroundPaint();
        boolean boolean15 = textTitle7.getExpandToFitSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = textTitle7.getPosition();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        double[] doubleArray9 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray16 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray23 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray30 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray37 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray44 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray45);
        org.jfree.data.general.PieDataset pieDataset48 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset46, (int) (short) 0);
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset46);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset50 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number53 = defaultStatisticalCategoryDataset50.getStdDevValue((java.lang.Comparable) "VerticalAlignment.CENTER", (java.lang.Comparable) (short) 10);
        int int55 = defaultStatisticalCategoryDataset50.getRowIndex((java.lang.Comparable) 100);
        defaultStatisticalCategoryDataset50.add((double) 100.0f, (double) 4, (java.lang.Comparable) (-1), (java.lang.Comparable) 2);
        org.jfree.data.Range range62 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset50, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint63 = new org.jfree.chart.block.RectangleConstraint(range49, range62);
        boolean boolean64 = categoryLabelPositions0.equals((java.lang.Object) rectangleConstraint63);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(pieDataset48);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertNull(number53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition4, true);
        double double7 = statisticalBarRenderer0.getBase();
        double[] doubleArray16 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray23 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray30 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray37 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray44 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray51 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray52 = new double[][] { doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44, doubleArray51 };
        org.jfree.data.category.CategoryDataset categoryDataset53 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray52);
        org.jfree.data.general.PieDataset pieDataset55 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset53, (int) (short) 0);
        org.jfree.data.Range range56 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset53);
        org.jfree.data.Range range57 = statisticalBarRenderer0.findRangeBounds(categoryDataset53);
        java.awt.Stroke stroke59 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        statisticalBarRenderer0.setSeriesOutlineStroke(0, stroke59);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(categoryDataset53);
        org.junit.Assert.assertNotNull(pieDataset55);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertNotNull(stroke59);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color2 = java.awt.Color.MAGENTA;
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis1.getLabelURL();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategoryEnd((int) 'a', 4, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        categoryAxis1.setTickMarkPaint(paint10);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition4, true);
        java.awt.Paint paint7 = statisticalBarRenderer0.getBaseFillPaint();
        boolean boolean8 = statisticalBarRenderer0.getIncludeBaseInRange();
        java.awt.Paint paint9 = statisticalBarRenderer0.getErrorIndicatorPaint();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor10 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.TickType tickType15 = org.jfree.chart.axis.TickType.MINOR;
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor19 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.NumberTick numberTick21 = new org.jfree.chart.axis.NumberTick(tickType15, (double) 'a', "DatasetRenderingOrder.FORWARD", textAnchor18, textAnchor19, 4.0d);
        org.jfree.chart.text.TextAnchor textAnchor22 = numberTick21.getTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor24 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        java.awt.Shape shape25 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D12, (float) (short) 0, (-1.0f), textAnchor22, (double) (-1L), textAnchor24);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor10, textAnchor24);
        statisticalBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition26);
        double double28 = statisticalBarRenderer0.getItemLabelAnchorOffset();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(itemLabelAnchor10);
        org.junit.Assert.assertNotNull(tickType15);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNull(shape25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.0d + "'", double28 == 2.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list1 = projectInfo0.getContributors();
        projectInfo0.setVersion("");
        java.awt.Image image4 = null;
        projectInfo0.setLogo(image4);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.block.BlockContainer blockContainer3 = null;
        legendTitle1.setWrapper(blockContainer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double7 = rectangleInsets5.trimWidth((double) 1L);
        double double8 = rectangleInsets5.getBottom();
        double double10 = rectangleInsets5.calculateRightOutset((double) 0L);
        double double12 = rectangleInsets5.extendHeight((double) 10.0f);
        legendTitle1.setItemLabelPadding(rectangleInsets5);
        double double15 = rectangleInsets5.calculateRightInset(9.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-7.0d) + "'", double7 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.0d + "'", double12 == 14.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        org.jfree.chart.block.BlockBorder blockBorder3 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean4 = statisticalBarRenderer0.equals((java.lang.Object) blockBorder3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = blockBorder3.getInsets();
        org.junit.Assert.assertNotNull(blockBorder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number3 = defaultStatisticalCategoryDataset0.getStdDevValue((java.lang.Comparable) "VerticalAlignment.CENTER", (java.lang.Comparable) (short) 10);
        int int5 = defaultStatisticalCategoryDataset0.getRowIndex((java.lang.Comparable) "hi!");
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setForegroundAlpha((float) (-1));
        defaultStatisticalCategoryDataset0.addChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot6);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand13 = null;
        numberAxis12.setMarkerBand(markerAxisBand13);
        java.awt.Stroke stroke15 = numberAxis12.getTickMarkStroke();
        numberAxis12.setUpperMargin((double) (-1));
        boolean boolean18 = numberAxis12.isPositiveArrowVisible();
        categoryPlot6.setRangeAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis12, true);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        legendTitle1.setHeight((double) (byte) 10);
        java.awt.Font font5 = legendTitle1.getItemFont();
        java.awt.Stroke stroke6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean7 = legendTitle1.equals((java.lang.Object) stroke6);
        org.jfree.chart.block.BlockContainer blockContainer8 = legendTitle1.getItemContainer();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double12 = rectangleInsets10.trimWidth((double) 1L);
        double double14 = rectangleInsets10.trimWidth((double) 1L);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder(rectangleInsets10, (java.awt.Paint) color15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = blockBorder16.getInsets();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo18);
        org.jfree.chart.renderer.RendererState rendererState20 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo19);
        java.awt.geom.Rectangle2D rectangle2D21 = plotRenderingInfo19.getDataArea();
        java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets17.createOutsetRectangle(rectangle2D21, true, false);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity27 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape) rectangle2D24, "ChartChangeEventType.NEW_DATASET", "VerticalAlignment.CENTER");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset28 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset28.add((java.lang.Number) 35.0d, (java.lang.Number) 100.0d, (java.lang.Comparable) (short) 100, (java.lang.Comparable) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot34.setForegroundAlpha((float) (-1));
        org.jfree.chart.LegendItemCollection legendItemCollection37 = categoryPlot34.getLegendItems();
        categoryPlot34.setDomainGridlinesVisible(true);
        boolean boolean40 = defaultStatisticalCategoryDataset28.hasListener((java.util.EventListener) categoryPlot34);
        categoryPlot34.mapDatasetToDomainAxis(100, 2);
        try {
            java.lang.Object obj44 = legendTitle1.draw(graphics2D9, rectangle2D24, (java.lang.Object) categoryPlot34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(blockContainer8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-7.0d) + "'", double12 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-7.0d) + "'", double14 == (-7.0d));
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(legendItemCollection37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = statisticalBarRenderer0.getNegativeItemLabelPosition((int) (byte) 0, (int) (byte) -1);
        boolean boolean4 = statisticalBarRenderer0.getBaseSeriesVisibleInLegend();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = statisticalBarRenderer0.getLegendItemLabelGenerator();
        java.awt.Stroke stroke7 = statisticalBarRenderer0.getSeriesStroke((int) (byte) 0);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator5);
        org.junit.Assert.assertNull(stroke7);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset45);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double51 = categoryAxis50.getLabelAngle();
        categoryAxis50.setLowerMargin((double) 0);
        categoryAxis50.setLabel("hi!");
        int int56 = categoryAxis50.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis58.setAutoRange(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer61 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator62 = null;
        statisticalBarRenderer61.setBaseItemLabelGenerator(categoryItemLabelGenerator62);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition65 = null;
        statisticalBarRenderer61.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition65, true);
        boolean boolean68 = statisticalBarRenderer61.isDrawBarOutline();
        boolean boolean69 = statisticalBarRenderer61.getAutoPopulateSeriesPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis50, (org.jfree.chart.axis.ValueAxis) numberAxis58, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer61);
        org.jfree.chart.LegendItemSource legendItemSource71 = null;
        org.jfree.chart.title.LegendTitle legendTitle72 = new org.jfree.chart.title.LegendTitle(legendItemSource71);
        double double73 = legendTitle72.getWidth();
        legendTitle72.setHeight((double) (byte) 10);
        java.awt.Font font76 = legendTitle72.getItemFont();
        java.awt.Stroke stroke77 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean78 = legendTitle72.equals((java.lang.Object) stroke77);
        legendTitle72.setHeight((double) 4);
        org.jfree.chart.util.RectangleInsets rectangleInsets81 = legendTitle72.getMargin();
        numberAxis58.setTickLabelInsets(rectangleInsets81);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(font76);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(rectangleInsets81);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition4, true);
        boolean boolean8 = statisticalBarRenderer0.isSeriesItemLabelsVisible(100);
        org.jfree.chart.block.CenterArrangement centerArrangement10 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = null;
        statisticalBarRenderer11.setBaseItemLabelGenerator(categoryItemLabelGenerator12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = null;
        statisticalBarRenderer11.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition15, true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke19 = defaultDrawingSupplier18.getNextOutlineStroke();
        java.awt.Stroke stroke20 = defaultDrawingSupplier18.getNextStroke();
        statisticalBarRenderer11.setErrorIndicatorStroke(stroke20);
        boolean boolean22 = centerArrangement10.equals((java.lang.Object) stroke20);
        statisticalBarRenderer0.setSeriesOutlineStroke((int) (byte) 100, stroke20, false);
        statisticalBarRenderer0.removeAnnotations();
        java.awt.Paint paint27 = null;
        statisticalBarRenderer0.setSeriesPaint(255, paint27, false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(4.0d);
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions2);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.AxisCollection axisCollection5 = new org.jfree.chart.axis.AxisCollection();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor7 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.LegendItemSource legendItemSource8 = null;
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle(legendItemSource8);
        boolean boolean10 = itemLabelAnchor7.equals((java.lang.Object) legendTitle9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color13 = java.awt.Color.RED;
        categoryAxis12.setLabelPaint((java.awt.Paint) color13);
        categoryAxis12.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint17 = categoryAxis12.getTickLabelPaint();
        java.awt.Stroke stroke18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder20 = new org.jfree.chart.block.LineBorder(paint17, stroke18, rectangleInsets19);
        legendTitle9.setFrame((org.jfree.chart.block.BlockFrame) lineBorder20);
        org.jfree.chart.axis.AxisSpace axisSpace22 = new org.jfree.chart.axis.AxisSpace();
        axisSpace22.setBottom((double) '#');
        java.lang.String str25 = axisSpace22.toString();
        double double26 = axisSpace22.getBottom();
        org.jfree.chart.axis.AxisSpace axisSpace28 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisSpace28.add(0.0d, rectangleEdge30);
        boolean boolean32 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge30);
        axisSpace22.add(0.05d, rectangleEdge30);
        legendTitle9.setLegendItemGraphicEdge(rectangleEdge30);
        axisCollection5.add((org.jfree.chart.axis.Axis) numberAxis6, rectangleEdge30);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition36 = categoryLabelPositions4.getLabelPosition(rectangleEdge30);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition37 = categoryLabelPositions2.getLabelPosition(rectangleEdge30);
        org.junit.Assert.assertNotNull(categoryLabelPositions2);
        org.junit.Assert.assertNotNull(itemLabelAnchor7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 35.0d + "'", double26 == 35.0d);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(categoryLabelPosition36);
        org.junit.Assert.assertNotNull(categoryLabelPosition37);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        double double1 = statisticalBarRenderer0.getMinimumBarLength();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = statisticalBarRenderer0.getSeriesItemLabelGenerator((-2));
        java.lang.Boolean boolean5 = statisticalBarRenderer0.getSeriesVisibleInLegend((int) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryItemLabelGenerator3);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker1.setLabelAnchor(rectangleAnchor3);
        java.lang.Class<?> wildcardClass5 = valueMarker1.getClass();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke8 = valueMarker7.getOutlineStroke();
        valueMarker1.setOutlineStroke(stroke8);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition4, true);
        boolean boolean7 = statisticalBarRenderer0.getAutoPopulateSeriesFillPaint();
        statisticalBarRenderer0.setAutoPopulateSeriesShape(false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }
}

