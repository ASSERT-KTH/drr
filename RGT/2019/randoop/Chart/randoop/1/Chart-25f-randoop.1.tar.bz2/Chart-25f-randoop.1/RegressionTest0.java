import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (-1.0f), (float) (byte) 0, textAnchor4, 1.0d, 0.0f, 0.0f);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = legendTitle1.arrange(graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test007");
//        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 1, numberFormat1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getWidth();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        try {
            legendTitle1.setHorizontalAlignment(horizontalAlignment3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) 1L, (float) (short) 100, textAnchor4, (double) '#', textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) 'a', 100, rectangle2D6, rectangleEdge7);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = axisSpace0.expand(rectangle2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range1 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.combine(range0, range1);
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("ThreadContext");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        try {
            textLine1.draw(graphics2D2, (float) (short) 10, (float) (byte) 1, textAnchor5, (float) '4', (float) (byte) 10, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, (double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name hi!, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        java.lang.Object obj1 = tickUnits0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        boolean boolean2 = sortOrder0.equals((java.lang.Object) 1L);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) 4, (float) 1L, 35.0d, 100.0f, (float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.event.AxisChangeListener axisChangeListener2 = null;
        categoryAxis1.addChangeListener(axisChangeListener2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.Plot plot5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.axis.AxisSpace axisSpace8 = new org.jfree.chart.axis.AxisSpace();
        axisSpace8.setBottom((double) '#');
        try {
            org.jfree.chart.axis.AxisSpace axisSpace11 = categoryAxis1.reserveSpace(graphics2D4, plot5, rectangle2D6, rectangleEdge7, axisSpace8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test052");
//        java.util.Locale locale1 = null;
//        java.lang.Class class2 = null;
//        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
//        try {
//            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("", locale1, classLoader3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(classLoader3);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.lang.String str0 = org.jfree.chart.ui.Licences.GPL;
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.TOP;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color2 = java.awt.Color.MAGENTA;
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            java.util.List list8 = categoryAxis1.refreshTicks(graphics2D4, axisState5, rectangle2D6, rectangleEdge7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape0, "", "");
        java.lang.String str5 = tickLabelEntity4.getToolTipText();
        java.lang.String str6 = tickLabelEntity4.getToolTipText();
        java.lang.String str7 = tickLabelEntity4.getShapeCoords();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-3,-3,3,3" + "'", str7.equals("-3,-3,3,3"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity5 = new org.jfree.chart.entity.LegendItemEntity(shape4);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color9 = java.awt.Color.getColor("", color8);
        try {
            org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem(attributedString0, "", "hi!", "", shape4, stroke6, (java.awt.Paint) color8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        try {
            org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (java.lang.Comparable) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 255, (double) 1.0f);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.Range range8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) 0, range8);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint9.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = rectangleConstraint11.toUnconstrainedWidth();
        try {
            org.jfree.chart.util.Size2D size2D13 = columnArrangement4.arrange(blockContainer5, graphics2D6, rectangleConstraint12);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(rectangleConstraint12);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 255, (double) 1.0f);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.Range range7 = null;
        org.jfree.data.Range range8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint(range7, range8);
        try {
            org.jfree.chart.util.Size2D size2D10 = columnArrangement4.arrange(blockContainer5, graphics2D6, rectangleConstraint9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape4, (double) 0L, (float) (-1L), (float) (short) 1);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Font font12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color13 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("ThreadContext", font12, (java.awt.Paint) color13);
        try {
            org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem(attributedString0, "RectangleConstraintType.RANGE", "", "", shape4, (java.awt.Paint) color9, stroke10, (java.awt.Paint) color13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("ThreadContext", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        java.lang.Number number48 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset45);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + (-6.0d) + "'", number48.equals((-6.0d)));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.block.BlockContainer blockContainer3 = null;
        legendTitle1.setWrapper(blockContainer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            legendTitle1.draw(graphics2D5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) 1L);
        double double3 = rectangleInsets0.getBottom();
        double double5 = rectangleInsets0.calculateRightOutset((double) 0L);
        double double7 = rectangleInsets0.extendHeight((double) 10.0f);
        double double9 = rectangleInsets0.calculateLeftInset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.0d) + "'", double2 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 14.0d + "'", double7 == 14.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        double double4 = legendTitle3.getHeight();
        org.jfree.chart.block.BlockContainer blockContainer5 = null;
        legendTitle3.setWrapper(blockContainer5);
        flowArrangement0.add((org.jfree.chart.block.Block) blockContainer5, (java.lang.Object) (-1));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        java.awt.Font font4 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 10.0d);
        double double5 = categoryAxis1.getCategoryMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color7 = java.awt.Color.RED;
        categoryAxis6.setLabelPaint((java.awt.Paint) color7);
        float[] floatArray13 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray14 = color7.getRGBColorComponents(floatArray13);
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape4, (java.awt.Paint) color7);
        legendGraphic15.setShapeVisible(true);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            java.lang.Object obj21 = legendGraphic15.draw(graphics2D18, rectangle2D19, (java.lang.Object) 35.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            keyedObjects0.removeValue((java.lang.Comparable) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("ThreadContext", "ThreadContext", "hi!", "-3,-3,3,3", "");
        basicProjectInfo5.setName("");
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit(14.0d, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        java.awt.Font font4 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 10.0d);
        double double5 = categoryAxis1.getLabelAngle();
        java.awt.Shape shape6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color13 = java.awt.Color.RED;
        categoryAxis12.setLabelPaint((java.awt.Paint) color13);
        float[] floatArray19 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray20 = color13.getRGBColorComponents(floatArray19);
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape10, (java.awt.Paint) color13);
        java.awt.Shape shape22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape22, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color29 = java.awt.Color.RED;
        categoryAxis28.setLabelPaint((java.awt.Paint) color29);
        float[] floatArray35 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray36 = color29.getRGBColorComponents(floatArray35);
        org.jfree.chart.title.LegendGraphic legendGraphic37 = new org.jfree.chart.title.LegendGraphic(shape26, (java.awt.Paint) color29);
        legendGraphic21.setLinePaint((java.awt.Paint) color29);
        boolean boolean39 = categoryAxis1.equals((java.lang.Object) legendGraphic21);
        legendGraphic21.setMargin((double) '4', 100.0d, (double) (byte) 1, (double) 0L);
        java.awt.Graphics2D graphics2D45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        try {
            legendGraphic21.draw(graphics2D45, rectangle2D46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setBottom((double) '#');
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.axis.AxisSpace axisSpace4 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisSpace4.add(0.0d, rectangleEdge6);
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = axisSpace0.reserved(rectangle2D3, rectangleEdge6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("-3,-3,3,3", graphics2D1, (-7.0d), (float) 100, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) (short) 100, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.awt.Color color2 = java.awt.Color.getColor("", (int) (byte) 1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = null;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean4 = categoryLabelPosition2.equals((java.lang.Object) categoryLabelPosition3);
        org.jfree.chart.text.TextAnchor textAnchor5 = categoryLabelPosition2.getRotationAnchor();
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor5, 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'itemLabelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        categoryAxis1.setLowerMargin((double) 0);
        double double5 = categoryAxis1.getLabelAngle();
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        double double8 = legendTitle7.getWidth();
        legendTitle7.setHeight((double) (byte) 10);
        java.awt.Font font11 = legendTitle7.getItemFont();
        categoryAxis1.setLabelFont(font11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.clear();
        java.awt.Shape shape2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color9 = java.awt.Color.RED;
        categoryAxis8.setLabelPaint((java.awt.Paint) color9);
        float[] floatArray15 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray16 = color9.getRGBColorComponents(floatArray15);
        org.jfree.chart.title.LegendGraphic legendGraphic17 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color9);
        blockContainer0.add((org.jfree.chart.block.Block) legendGraphic17);
        boolean boolean19 = legendGraphic17.isShapeVisible();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        java.awt.Font font4 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 10.0d);
        double double5 = categoryAxis1.getLabelAngle();
        java.awt.Shape shape6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color13 = java.awt.Color.RED;
        categoryAxis12.setLabelPaint((java.awt.Paint) color13);
        float[] floatArray19 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray20 = color13.getRGBColorComponents(floatArray19);
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape10, (java.awt.Paint) color13);
        java.awt.Shape shape22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape22, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color29 = java.awt.Color.RED;
        categoryAxis28.setLabelPaint((java.awt.Paint) color29);
        float[] floatArray35 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray36 = color29.getRGBColorComponents(floatArray35);
        org.jfree.chart.title.LegendGraphic legendGraphic37 = new org.jfree.chart.title.LegendGraphic(shape26, (java.awt.Paint) color29);
        legendGraphic21.setLinePaint((java.awt.Paint) color29);
        boolean boolean39 = categoryAxis1.equals((java.lang.Object) legendGraphic21);
        java.awt.Stroke stroke40 = null;
        legendGraphic21.setOutlineStroke(stroke40);
        java.awt.Graphics2D graphics2D42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        try {
            legendGraphic21.draw(graphics2D42, rectangle2D43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getLicenceName();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "LGPL" + "'", str1.equals("LGPL"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) 1L);
        double double4 = rectangleInsets0.trimWidth((double) 1L);
        double double6 = rectangleInsets0.calculateTopOutset((double) (byte) 10);
        java.lang.String str7 = rectangleInsets0.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.0d) + "'", double2 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-7.0d) + "'", double4 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str7.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = valueMarker1.getLabelOffsetType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker1.setLabelAnchor(rectangleAnchor3);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent5 = null;
        valueMarker1.notifyListeners(markerChangeEvent5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color4 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("ThreadContext", font3, (java.awt.Paint) color4);
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("", font3);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke9 = valueMarker8.getOutlineStroke();
        java.awt.Paint paint10 = valueMarker8.getOutlinePaint();
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("-3,-3,3,3", font3, paint10);
        float float12 = textFragment11.getBaselineOffset();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        java.lang.Class class1 = null;
//        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", class1);
//        org.junit.Assert.assertNull(inputStream2);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color3 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("ThreadContext", font2, (java.awt.Paint) color3);
        textLine0.addFragment(textFragment4);
        org.jfree.chart.block.FlowArrangement flowArrangement6 = new org.jfree.chart.block.FlowArrangement();
        boolean boolean7 = textLine0.equals((java.lang.Object) flowArrangement6);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("-3,-3,3,3", graphics2D1, 10.0f, (float) (-1L), (double) (short) 0, (float) (short) 1, (float) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        double[] doubleArray10 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray17 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray24 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray31 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray38 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray45 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray46 = new double[][] { doubleArray10, doubleArray17, doubleArray24, doubleArray31, doubleArray38, doubleArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset47, (int) (short) 0);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer51 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) pieDataset49, (java.lang.Comparable) "ThreadContext");
        java.lang.Object obj52 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) legendItemBlockContainer51);
        java.awt.Graphics2D graphics2D53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor55 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        try {
            java.lang.Object obj56 = legendItemBlockContainer51.draw(graphics2D53, rectangle2D54, (java.lang.Object) rectangleAnchor55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertNotNull(rectangleAnchor55);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.Object obj1 = null;
        boolean boolean2 = datasetRenderingOrder0.equals(obj1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setAutoRange(false);
        java.awt.Color color4 = java.awt.Color.magenta;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color7 = java.awt.Color.RED;
        categoryAxis6.setLabelPaint((java.awt.Paint) color7);
        float[] floatArray13 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray14 = color7.getRGBColorComponents(floatArray13);
        float[] floatArray15 = color4.getComponents(floatArray14);
        numberAxis1.setTickLabelPaint((java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.awt.Font font0 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.TickUnit tickUnit1 = null;
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.getLargerTickUnit(tickUnit1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color2 = java.awt.Color.RED;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        categoryAxis1.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint6 = categoryAxis1.getTickLabelPaint();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder(paint6, stroke7, rectangleInsets8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = lineBorder9.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = lineBorder9.getInsets();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets11.createOutsetRectangle(rectangle2D12, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("-3,-3,3,3", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        java.awt.Font font4 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 10.0d);
        double double5 = categoryAxis1.getLabelAngle();
        java.awt.Paint paint6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        categoryAxis1.setAxisLinePaint(paint6);
        categoryAxis1.setVisible(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test133");
//        java.lang.Class class1 = null;
//        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("", class1);
//        org.junit.Assert.assertNotNull(uRL2);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.plot.Plot plot1 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart2 = new org.jfree.chart.JFreeChart("LGPL", plot1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker1.setLabelAnchor(rectangleAnchor3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor3, textBlockAnchor5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'labelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        boolean boolean2 = datasetRenderingOrder0.equals((java.lang.Object) categoryLabelPositions1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset45);
        boolean boolean51 = range48.intersects((double) 1.0f, 0.0d);
        double double53 = range48.constrain((double) (-1.0f));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.util.List list1 = blockContainer0.getBlocks();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color7 = java.awt.Color.RED;
        categoryAxis6.setLabelPaint((java.awt.Paint) color7);
        float[] floatArray13 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray14 = color7.getRGBColorComponents(floatArray13);
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape4, (java.awt.Paint) color7);
        java.lang.Object obj16 = legendGraphic15.clone();
        legendGraphic15.setShapeVisible(false);
        java.lang.Object obj19 = legendGraphic15.clone();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list1 = projectInfo0.getContributors();
        try {
            java.util.Collection collection2 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list1);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.getCeilingTickUnit((double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = plotRenderingInfo1.getSubplotInfo((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.awt.Color color0 = java.awt.Color.pink;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color3 = java.awt.Color.RED;
        categoryAxis2.setLabelPaint((java.awt.Paint) color3);
        float[] floatArray9 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray10 = color3.getRGBColorComponents(floatArray9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color13 = java.awt.Color.RED;
        categoryAxis12.setLabelPaint((java.awt.Paint) color13);
        float[] floatArray19 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray20 = color13.getRGBColorComponents(floatArray19);
        float[] floatArray21 = color3.getRGBComponents(floatArray20);
        float[] floatArray22 = color0.getColorComponents(floatArray20);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("ThreadContext");
        boolean boolean3 = textLine1.equals((java.lang.Object) 128);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setBottom((double) '#');
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = axisSpace0.shrink(rectangle2D3, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("LGPL", graphics2D1, (float) 100, (float) (byte) -1, (double) 0, (float) (-1L), (float) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        double double6 = legendTitle5.getHeight();
        flowArrangement0.add((org.jfree.chart.block.Block) legendTitle3, (java.lang.Object) double6);
        org.jfree.data.general.Dataset dataset8 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer10 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, dataset8, (java.lang.Comparable) "CONTRACT");
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color2 = java.awt.Color.RED;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        categoryAxis1.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint6 = categoryAxis1.getTickLabelPaint();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder(paint6, stroke7, rectangleInsets8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = lineBorder9.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = lineBorder9.getInsets();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            lineBorder9.draw(graphics2D12, rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        try {
            java.lang.Number number3 = defaultStatisticalCategoryDataset0.getMeanValue((int) '#', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        java.util.Locale locale1 = null;
//        java.lang.Class class2 = null;
//        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
//        java.util.ResourceBundle.Control control4 = null;
//        try {
//            java.util.ResourceBundle resourceBundle5 = java.util.ResourceBundle.getBundle("CONTRACT", locale1, classLoader3, control4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(classLoader3);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset45);
        boolean boolean50 = range48.equals((java.lang.Object) "ThreadContext");
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = shapeList0.getShape((-1));
        shapeList0.clear();
        java.awt.Shape shape5 = shapeList0.getShape(128);
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertNull(shape5);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("LGPL");
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (short) 10, (double) 'a', (double) (short) -1, (double) 0);
        java.awt.Paint paint5 = blockBorder4.getPaint();
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.add((java.lang.Number) 35.0d, (java.lang.Number) 100.0d, (java.lang.Comparable) (short) 100, (java.lang.Comparable) (short) 1);
        try {
            java.lang.Number number8 = defaultStatisticalCategoryDataset0.getValue((int) '#', 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        try {
            org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (java.lang.Comparable) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double3 = categoryAxis2.getLabelAngle();
        categoryAxis2.setLowerMargin((double) 0);
        categoryAxis2.setUpperMargin(0.0d);
        java.lang.String str8 = categoryAxis2.getLabel();
        double double9 = categoryAxis2.getUpperMargin();
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        double double13 = legendTitle12.getWidth();
        legendTitle12.setHeight((double) (byte) 10);
        java.awt.Font font16 = legendTitle12.getItemFont();
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("", font16);
        categoryAxis2.setTickLabelFont(font16);
        boolean boolean19 = legendItemCollection0.equals((java.lang.Object) categoryAxis2);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double23 = categoryAxis22.getLabelAngle();
        categoryAxis22.setLowerMargin((double) 0);
        categoryAxis22.setUpperMargin(0.0d);
        java.lang.String str28 = categoryAxis22.getLabel();
        double double29 = categoryAxis22.getUpperMargin();
        org.jfree.chart.LegendItemSource legendItemSource31 = null;
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle(legendItemSource31);
        double double33 = legendTitle32.getWidth();
        legendTitle32.setHeight((double) (byte) 10);
        java.awt.Font font36 = legendTitle32.getItemFont();
        org.jfree.chart.text.TextFragment textFragment37 = new org.jfree.chart.text.TextFragment("", font36);
        categoryAxis22.setTickLabelFont(font36);
        boolean boolean39 = legendItemCollection20.equals((java.lang.Object) categoryAxis22);
        legendItemCollection0.addAll(legendItemCollection20);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "hi!" + "'", str28.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean2 = categoryLabelPosition0.equals((java.lang.Object) categoryLabelPosition1);
        org.jfree.chart.text.TextAnchor textAnchor3 = categoryLabelPosition0.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType4 = categoryLabelPosition0.getWidthType();
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = legendTitle6.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition9 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor7, textBlockAnchor8);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition10 = null;
        org.jfree.chart.LegendItemSource legendItemSource11 = null;
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle(legendItemSource11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = legendTitle12.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition15 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor13, textBlockAnchor14);
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = new org.jfree.chart.axis.CategoryLabelPositions(categoryLabelPosition0, categoryLabelPosition9, categoryLabelPosition10, categoryLabelPosition15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'left' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(categoryLabelWidthType4);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.axis.AxisSpace axisSpace9 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisSpace9.add(0.0d, rectangleEdge11);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        try {
            org.jfree.chart.axis.AxisState axisState15 = numberAxis1.draw(graphics2D5, (double) 100L, rectangle2D7, rectangle2D8, rectangleEdge11, plotRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 8, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart1 = new org.jfree.chart.JFreeChart(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        java.awt.Shape shape5 = numberAxis1.getRightArrow();
        org.jfree.data.RangeType rangeType6 = numberAxis1.getRangeType();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(rangeType6);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation3 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 0.5f, (java.lang.Number) 14.0d);
        boolean boolean4 = itemLabelAnchor0.equals((java.lang.Object) 0.5f);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape0, "", "");
        java.lang.String str5 = tickLabelEntity4.getToolTipText();
        java.lang.String str6 = tickLabelEntity4.getURLText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((-1), (int) 'a', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.clear();
        java.awt.Shape shape2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color9 = java.awt.Color.RED;
        categoryAxis8.setLabelPaint((java.awt.Paint) color9);
        float[] floatArray15 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray16 = color9.getRGBColorComponents(floatArray15);
        org.jfree.chart.title.LegendGraphic legendGraphic17 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color9);
        blockContainer0.add((org.jfree.chart.block.Block) legendGraphic17);
        java.awt.Shape shape19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape19, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color26 = java.awt.Color.RED;
        categoryAxis25.setLabelPaint((java.awt.Paint) color26);
        float[] floatArray32 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray33 = color26.getRGBColorComponents(floatArray32);
        org.jfree.chart.title.LegendGraphic legendGraphic34 = new org.jfree.chart.title.LegendGraphic(shape23, (java.awt.Paint) color26);
        legendGraphic17.setOutlinePaint((java.awt.Paint) color26);
        int int36 = color26.getBlue();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color4 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("ThreadContext", font3, (java.awt.Paint) color4);
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("", font3);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("hi!", font3);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.lang.Object obj11 = textTitle7.draw(graphics2D8, rectangle2D9, (java.lang.Object) (byte) 100);
        textTitle7.setText("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.lang.String str14 = textTitle7.getToolTipText();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = null;
        numberAxis6.setMarkerBand(markerAxisBand7);
        java.awt.Stroke stroke9 = numberAxis6.getTickMarkStroke();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis6.setUpArrow(shape11);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color18 = java.awt.Color.RED;
        categoryAxis17.setLabelPaint((java.awt.Paint) color18);
        float[] floatArray24 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray25 = color18.getRGBColorComponents(floatArray24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape28);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity32 = new org.jfree.chart.entity.TickLabelEntity(shape28, "", "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity35 = new org.jfree.chart.entity.TickLabelEntity(shape28, "hi!", "RectangleConstraintType.RANGE");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke37 = defaultDrawingSupplier36.getNextOutlineStroke();
        java.awt.Color color38 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("", "ThreadContext", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "DatasetRenderingOrder.FORWARD", true, shape11, true, (java.awt.Paint) color14, true, (java.awt.Paint) color18, stroke26, false, shape28, stroke37, (java.awt.Paint) color38);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer40 = null;
        try {
            legendItem39.setFillPaintTransformer(gradientPaintTransformer40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'transformer' attribute.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color38);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        legendItemEntity1.setSeriesKey((java.lang.Comparable) "LGPL");
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 255, (double) 1.0f);
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement5.clear();
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray50 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray51 = new double[][] { doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43, doubleArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray51);
        org.jfree.data.general.PieDataset pieDataset54 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset52, (int) (short) 0);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer56 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement5, (org.jfree.data.general.Dataset) pieDataset54, (java.lang.Comparable) "ThreadContext");
        org.jfree.chart.block.BlockFrame blockFrame57 = legendItemBlockContainer56.getFrame();
        java.awt.Color color58 = java.awt.Color.BLACK;
        columnArrangement4.add((org.jfree.chart.block.Block) legendItemBlockContainer56, (java.lang.Object) color58);
        java.awt.Color color60 = java.awt.Color.darkGray;
        boolean boolean61 = columnArrangement4.equals((java.lang.Object) color60);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(pieDataset54);
        org.junit.Assert.assertNotNull(blockFrame57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) 1L);
        double double3 = rectangleInsets0.getBottom();
        double double5 = rectangleInsets0.calculateRightOutset((double) 0L);
        double double7 = rectangleInsets0.extendHeight((double) 10.0f);
        double double9 = rectangleInsets0.calculateBottomInset((double) 1L);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.0d) + "'", double2 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 14.0d + "'", double7 == 14.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("LGPL", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) 128, (double) 0L, (double) 128);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        categoryAxis1.setLowerMargin((double) 0);
        categoryAxis1.setLabel("hi!");
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = categoryAxis1.getCategoryLabelPositions();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.axis.AxisSpace axisSpace13 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisSpace13.add(0.0d, rectangleEdge15);
        boolean boolean17 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge15);
        try {
            double double18 = categoryAxis1.getCategoryEnd((int) (short) -1, 4, rectangle2D12, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.jfree.chart.axis.AxisSpace axisSpace1 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisSpace1.add(0.0d, rectangleEdge3);
        boolean boolean5 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge3);
        boolean boolean6 = datasetRenderingOrder0.equals((java.lang.Object) boolean5);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        double double6 = legendTitle5.getHeight();
        flowArrangement0.add((org.jfree.chart.block.Block) legendTitle3, (java.lang.Object) double6);
        legendTitle3.setWidth((double) (byte) -1);
        java.awt.Paint paint10 = legendTitle3.getItemPaint();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = null;
        try {
            legendTitle3.setLegendItemGraphicAnchor(rectangleAnchor11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' point.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color2 = java.awt.Color.RED;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        categoryAxis1.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint6 = categoryAxis1.getTickLabelPaint();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder(paint6, stroke7, rectangleInsets8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = lineBorder9.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = lineBorder9.getInsets();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets11.createInsetRectangle(rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.awt.Color color0 = java.awt.Color.BLUE;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 10);
        org.jfree.chart.block.FlowArrangement flowArrangement2 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement2.clear();
        double[] doubleArray12 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray19 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray26 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray33 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray40 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray47 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray48 = new double[][] { doubleArray12, doubleArray19, doubleArray26, doubleArray33, doubleArray40, doubleArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray48);
        org.jfree.data.general.PieDataset pieDataset51 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset49, (int) (short) 0);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer53 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement2, (org.jfree.data.general.Dataset) pieDataset51, (java.lang.Comparable) "ThreadContext");
        java.lang.Object obj54 = legendItemBlockContainer53.clone();
        boolean boolean55 = legendItemBlockContainer53.isEmpty();
        int int56 = numberTickUnit1.compareTo((java.lang.Object) legendItemBlockContainer53);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNotNull(pieDataset51);
        org.junit.Assert.assertNotNull(obj54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        double[] doubleArray9 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray16 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray23 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray30 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray37 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray44 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray45);
        org.jfree.data.general.PieDataset pieDataset48 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset46, (int) (short) 0);
        org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset46);
        java.lang.Number number50 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset46);
        try {
            java.lang.String str52 = standardCategorySeriesLabelGenerator0.generateLabel(categoryDataset46, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(pieDataset48);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertTrue("'" + number50 + "' != '" + (-1.0d) + "'", number50.equals((-1.0d)));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 0, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint4.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint5.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setFixedAutoRange((-1.0d));
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        axisSpace6.setBottom((double) '#');
        java.lang.String str9 = axisSpace6.toString();
        double double10 = axisSpace6.getBottom();
        org.jfree.chart.axis.AxisSpace axisSpace12 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisSpace12.add(0.0d, rectangleEdge14);
        boolean boolean16 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge14);
        axisSpace6.add(0.05d, rectangleEdge14);
        try {
            java.util.List list18 = numberAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 35.0d + "'", double10 == 35.0d);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color3 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("ThreadContext", font2, (java.awt.Paint) color3);
        textLine0.addFragment(textFragment4);
        org.jfree.chart.text.TextFragment textFragment6 = null;
        textLine0.addFragment(textFragment6);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        java.awt.Stroke stroke4 = numberAxis1.getTickMarkStroke();
        double double5 = numberAxis1.getUpperBound();
        double double6 = numberAxis1.getAutoRangeMinimumSize();
        java.lang.String str7 = numberAxis1.getLabel();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-8d + "'", double6 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-3,-3,3,3" + "'", str7.equals("-3,-3,3,3"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.lang.Object obj1 = null;
        boolean boolean2 = rectangleEdge0.equals(obj1);
        boolean boolean3 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double4 = categoryAxis3.getLabelAngle();
        java.awt.Font font6 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 10.0d);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("-3,-3,3,3", font6);
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("ThreadContext", font6);
        boolean boolean10 = labelBlock8.equals((java.lang.Object) 1.0E-8d);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor13 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        try {
            java.lang.Object obj14 = labelBlock8.draw(graphics2D11, rectangle2D12, (java.lang.Object) itemLabelAnchor13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor13);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.awt.Color color0 = java.awt.Color.GREEN;
        java.awt.Stroke stroke1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color4 = java.awt.Color.RED;
        categoryAxis3.setLabelPaint((java.awt.Paint) color4);
        categoryAxis3.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint8 = categoryAxis3.getTickLabelPaint();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder(paint8, stroke9, rectangleInsets10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = lineBorder11.getInsets();
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = lineBorder13.getInsets();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            lineBorder13.draw(graphics2D15, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (-1.0f), (double) 100L, 1, (java.lang.Comparable) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        java.awt.Shape shape5 = numberAxis1.getRightArrow();
        numberAxis1.setLowerMargin(100.0d);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.axis.AxisSpace axisSpace10 = new org.jfree.chart.axis.AxisSpace();
        axisSpace10.setBottom((double) '#');
        java.lang.String str13 = axisSpace10.toString();
        double double14 = axisSpace10.getBottom();
        org.jfree.chart.axis.AxisSpace axisSpace16 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisSpace16.add(0.0d, rectangleEdge18);
        boolean boolean20 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge18);
        axisSpace10.add(0.05d, rectangleEdge18);
        try {
            double double22 = numberAxis1.lengthToJava2D((double) 100L, rectangle2D9, rectangleEdge18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 35.0d + "'", double14 == 35.0d);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getCopyright();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo7 = new org.jfree.chart.ui.BasicProjectInfo("ThreadContext", "ThreadContext", "hi!", "-3,-3,3,3", "");
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo7);
        basicProjectInfo7.setName("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str1.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer();
        blockContainer1.clear();
        java.awt.Shape shape3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape3, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color10 = java.awt.Color.RED;
        categoryAxis9.setLabelPaint((java.awt.Paint) color10);
        float[] floatArray16 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray17 = color10.getRGBColorComponents(floatArray16);
        org.jfree.chart.title.LegendGraphic legendGraphic18 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color10);
        blockContainer1.add((org.jfree.chart.block.Block) legendGraphic18);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = legendGraphic18.getShapeAnchor();
        try {
            java.awt.geom.Point2D point2D21 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("DatasetRenderingOrder.FORWARD");
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = legendTitle1.getLegendItemGraphicAnchor();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            legendTitle1.setBounds(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 255, (double) 1.0f);
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement5.clear();
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray50 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray51 = new double[][] { doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43, doubleArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray51);
        org.jfree.data.general.PieDataset pieDataset54 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset52, (int) (short) 0);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer56 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement5, (org.jfree.data.general.Dataset) pieDataset54, (java.lang.Comparable) "ThreadContext");
        java.lang.Comparable comparable57 = legendItemBlockContainer56.getSeriesKey();
        java.awt.Graphics2D graphics2D58 = null;
        org.jfree.chart.axis.NumberAxis numberAxis60 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand61 = null;
        numberAxis60.setMarkerBand(markerAxisBand61);
        org.jfree.data.Range range64 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint65 = new org.jfree.chart.block.RectangleConstraint((double) 0, range64);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint67 = rectangleConstraint65.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint68 = rectangleConstraint67.toUnconstrainedWidth();
        boolean boolean69 = numberAxis60.equals((java.lang.Object) rectangleConstraint68);
        try {
            org.jfree.chart.util.Size2D size2D70 = columnArrangement4.arrange((org.jfree.chart.block.BlockContainer) legendItemBlockContainer56, graphics2D58, rectangleConstraint68);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(pieDataset54);
        org.junit.Assert.assertTrue("'" + comparable57 + "' != '" + "ThreadContext" + "'", comparable57.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(rectangleConstraint67);
        org.junit.Assert.assertNotNull(rectangleConstraint68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String[] strArray2 = jFreeChartResources0.getStringArray("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key (C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = valueMarker1.getLabelOffsetType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker1.setLabelAnchor(rectangleAnchor3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color7 = java.awt.Color.RED;
        categoryAxis6.setLabelPaint((java.awt.Paint) color7);
        int int9 = color7.getRed();
        int int10 = color7.getRed();
        valueMarker1.setPaint((java.awt.Paint) color7);
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        double double3 = legendTitle2.getWidth();
        legendTitle2.setHeight((double) (byte) 10);
        java.awt.Font font6 = legendTitle2.getItemFont();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color9 = java.awt.Color.MAGENTA;
        int int10 = color9.getRed();
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("hi!", font8, (java.awt.Paint) color9, (float) 'a');
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer15 = new org.jfree.chart.text.G2TextMeasurer(graphics2D14);
        try {
            org.jfree.chart.text.TextBlock textBlock16 = org.jfree.chart.text.TextUtilities.createTextBlock("RangeType.FULL", font6, (java.awt.Paint) color9, 0.5f, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean2 = categoryLabelPosition0.equals((java.lang.Object) categoryLabelPosition1);
        double[] doubleArray11 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray18 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray25 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray32 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray39 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray46 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray47 = new double[][] { doubleArray11, doubleArray18, doubleArray25, doubleArray32, doubleArray39, doubleArray46 };
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray47);
        org.jfree.data.general.PieDataset pieDataset50 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset48, (int) (short) 0);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent51 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryLabelPosition1, (org.jfree.data.general.Dataset) categoryDataset48);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNotNull(pieDataset50);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=192,g=192,b=0]" + "'", str1.equals("java.awt.Color[r=192,g=192,b=0]"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.get((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Boolean boolean2 = booleanList0.getBoolean((int) (byte) -1);
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setLeft((double) (byte) -1);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = axisSpace0.reserved(rectangle2D3, rectangleEdge4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge4);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = legendTitle4.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor5, textBlockAnchor6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color10 = java.awt.Color.RED;
        categoryAxis9.setLabelPaint((java.awt.Paint) color10);
        categoryAxis9.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint14 = categoryAxis9.getTickLabelPaint();
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder(paint14, stroke15, rectangleInsets16);
        java.awt.Stroke stroke18 = lineBorder17.getStroke();
        java.awt.Paint paint19 = lineBorder17.getPaint();
        boolean boolean20 = rectangleAnchor5.equals((java.lang.Object) paint19);
        try {
            java.awt.geom.Rectangle2D rectangle2D21 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 0.0d, 1.0E-8d, rectangleAnchor5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color2 = java.awt.Color.RED;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        categoryAxis1.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint6 = categoryAxis1.getTickLabelPaint();
        double double7 = categoryAxis1.getUpperMargin();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.awt.Color color0 = java.awt.Color.BLUE;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.awt.Color color0 = java.awt.Color.GREEN;
        java.awt.Stroke stroke1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color4 = java.awt.Color.RED;
        categoryAxis3.setLabelPaint((java.awt.Paint) color4);
        categoryAxis3.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint8 = categoryAxis3.getTickLabelPaint();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder(paint8, stroke9, rectangleInsets10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = lineBorder11.getInsets();
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = lineBorder13.getInsets();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets14.createInsetRectangle(rectangle2D15, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.clear();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            blockContainer0.setBounds(rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'bounds' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        categoryAxis1.setLowerMargin((double) 0);
        categoryAxis1.setUpperMargin(0.0d);
        java.lang.String str7 = categoryAxis1.getLabel();
        double double8 = categoryAxis1.getUpperMargin();
        org.jfree.chart.LegendItemSource legendItemSource10 = null;
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle(legendItemSource10);
        double double12 = legendTitle11.getWidth();
        legendTitle11.setHeight((double) (byte) 10);
        java.awt.Font font15 = legendTitle11.getItemFont();
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("", font15);
        categoryAxis1.setTickLabelFont(font15);
        org.jfree.chart.event.AxisChangeListener axisChangeListener18 = null;
        categoryAxis1.addChangeListener(axisChangeListener18);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        double double6 = legendTitle5.getHeight();
        flowArrangement0.add((org.jfree.chart.block.Block) legendTitle3, (java.lang.Object) double6);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement8.clear();
        double[] doubleArray18 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray25 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray32 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray39 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray46 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray53 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray54 = new double[][] { doubleArray18, doubleArray25, doubleArray32, doubleArray39, doubleArray46, doubleArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray54);
        org.jfree.data.general.PieDataset pieDataset57 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset55, (int) (short) 0);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer59 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement8, (org.jfree.data.general.Dataset) pieDataset57, (java.lang.Comparable) "ThreadContext");
        java.lang.Object obj60 = legendItemBlockContainer59.clone();
        java.awt.Graphics2D graphics2D61 = null;
        org.jfree.data.Range range63 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint64 = new org.jfree.chart.block.RectangleConstraint((double) 0, range63);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint66 = rectangleConstraint64.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint68 = rectangleConstraint64.toFixedWidth(0.0d);
        try {
            org.jfree.chart.util.Size2D size2D69 = flowArrangement0.arrange((org.jfree.chart.block.BlockContainer) legendItemBlockContainer59, graphics2D61, rectangleConstraint64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(pieDataset57);
        org.junit.Assert.assertNotNull(obj60);
        org.junit.Assert.assertNotNull(rectangleConstraint66);
        org.junit.Assert.assertNotNull(rectangleConstraint68);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable1 = null;
        int int2 = defaultStatisticalCategoryDataset0.getRowIndex(comparable1);
        int int3 = defaultStatisticalCategoryDataset0.getRowCount();
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color2 = java.awt.Color.RED;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        categoryAxis1.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint6 = categoryAxis1.getTickLabelPaint();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder(paint6, stroke7, rectangleInsets8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = lineBorder9.getInsets();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            lineBorder9.draw(graphics2D11, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 255, (double) 1.0f);
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement5.clear();
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray50 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray51 = new double[][] { doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43, doubleArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray51);
        org.jfree.data.general.PieDataset pieDataset54 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset52, (int) (short) 0);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer56 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement5, (org.jfree.data.general.Dataset) pieDataset54, (java.lang.Comparable) "ThreadContext");
        org.jfree.chart.block.BlockFrame blockFrame57 = legendItemBlockContainer56.getFrame();
        java.awt.Color color58 = java.awt.Color.BLACK;
        columnArrangement4.add((org.jfree.chart.block.Block) legendItemBlockContainer56, (java.lang.Object) color58);
        columnArrangement4.clear();
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(pieDataset54);
        org.junit.Assert.assertNotNull(blockFrame57);
        org.junit.Assert.assertNotNull(color58);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 0, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint4.toUnconstrainedWidth();
        double double6 = rectangleConstraint4.getWidth();
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNull(rectangleEdge1);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("VerticalAlignment.CENTER", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.geom.Point2D point2D2 = null;
        try {
            int int3 = plotRenderingInfo1.getSubplotIndex(point2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color4 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("ThreadContext", font3, (java.awt.Paint) color4);
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("", font3);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("hi!", font3);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.data.Range range10 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.Range range12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) 0, range12);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint13.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType16 = rectangleConstraint15.getHeightConstraintType();
        org.jfree.data.Range range18 = null;
        org.jfree.data.Range range20 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint((double) 0, range20);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = rectangleConstraint21.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType24 = rectangleConstraint23.getHeightConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = new org.jfree.chart.block.RectangleConstraint((double) 'a', range10, lengthConstraintType16, 0.0d, range18, lengthConstraintType24);
        try {
            org.jfree.chart.util.Size2D size2D26 = textTitle7.arrange(graphics2D8, rectangleConstraint25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
        org.junit.Assert.assertNotNull(lengthConstraintType16);
        org.junit.Assert.assertNotNull(rectangleConstraint23);
        org.junit.Assert.assertNotNull(lengthConstraintType24);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color2 = java.awt.Color.RED;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        categoryAxis1.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint6 = categoryAxis1.getTickLabelPaint();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder(paint6, stroke7, rectangleInsets8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = lineBorder9.getInsets();
        java.awt.Paint paint11 = lineBorder9.getPaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable1 = null;
        int int2 = defaultStatisticalCategoryDataset0.getRowIndex(comparable1);
        int int3 = defaultStatisticalCategoryDataset0.getRowCount();
        java.util.List list4 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisSpace0.add(0.0d, rectangleEdge2);
        axisSpace0.setTop(0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, (double) 0L, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setBottom((double) '#');
        java.lang.String str3 = axisSpace0.toString();
        double double4 = axisSpace0.getBottom();
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisSpace6.add(0.0d, rectangleEdge8);
        boolean boolean10 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge8);
        axisSpace0.add(0.05d, rectangleEdge8);
        double double12 = axisSpace0.getRight();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 35.0d + "'", double4 == 35.0d);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 'a', "DatasetRenderingOrder.FORWARD", textAnchor3, textAnchor4, 4.0d);
        java.lang.String str7 = textAnchor3.toString();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TextAnchor.BASELINE_RIGHT" + "'", str7.equals("TextAnchor.BASELINE_RIGHT"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) 1L);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            rectangleInsets0.trim(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.0d) + "'", double2 == (-7.0d));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) (short) 10, 100.0f);
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.clone(shape3);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape3, 44.0d, 0.0f, (float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double4 = categoryAxis3.getLabelAngle();
        java.awt.Font font6 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 10.0d);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("-3,-3,3,3", font6);
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("ThreadContext", font6);
        java.awt.Paint paint9 = labelBlock8.getPaint();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.data.Range range12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint((double) 0, range12);
        try {
            org.jfree.chart.util.Size2D size2D14 = labelBlock8.arrange(graphics2D10, rectangleConstraint13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        org.jfree.data.KeyToGroupMap keyToGroupMap48 = null;
        try {
            org.jfree.data.Range range49 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset45, keyToGroupMap48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        java.awt.Stroke stroke4 = numberAxis1.getTickMarkStroke();
        numberAxis1.setUpperMargin((double) 0.5f);
        java.awt.Paint paint7 = numberAxis1.getLabelPaint();
        org.jfree.chart.plot.Plot plot8 = numberAxis1.getPlot();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(plot8);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity5 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        legendItemEntity5.setSeriesKey((java.lang.Comparable) (byte) 10);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        java.awt.Font font4 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 10.0d);
        double double5 = categoryAxis1.getLabelAngle();
        java.awt.Shape shape6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color13 = java.awt.Color.RED;
        categoryAxis12.setLabelPaint((java.awt.Paint) color13);
        float[] floatArray19 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray20 = color13.getRGBColorComponents(floatArray19);
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape10, (java.awt.Paint) color13);
        java.awt.Shape shape22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape22, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color29 = java.awt.Color.RED;
        categoryAxis28.setLabelPaint((java.awt.Paint) color29);
        float[] floatArray35 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray36 = color29.getRGBColorComponents(floatArray35);
        org.jfree.chart.title.LegendGraphic legendGraphic37 = new org.jfree.chart.title.LegendGraphic(shape26, (java.awt.Paint) color29);
        legendGraphic21.setLinePaint((java.awt.Paint) color29);
        boolean boolean39 = categoryAxis1.equals((java.lang.Object) legendGraphic21);
        double double40 = categoryAxis1.getLabelAngle();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        int int1 = paintList0.size();
        java.awt.Paint paint3 = paintList0.getPaint((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        java.awt.Font font4 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 10.0d);
        float float5 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.RendererState rendererState2 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = rendererState2.getInfo();
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState4 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo3);
        double double5 = categoryItemRendererState4.getBarWidth();
        categoryItemRendererState4.setBarWidth((double) (byte) 100);
        org.junit.Assert.assertNotNull(plotRenderingInfo3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = null;
        numberAxis6.setMarkerBand(markerAxisBand7);
        java.awt.Stroke stroke9 = numberAxis6.getTickMarkStroke();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis6.setUpArrow(shape11);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color18 = java.awt.Color.RED;
        categoryAxis17.setLabelPaint((java.awt.Paint) color18);
        float[] floatArray24 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray25 = color18.getRGBColorComponents(floatArray24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape28);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity32 = new org.jfree.chart.entity.TickLabelEntity(shape28, "", "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity35 = new org.jfree.chart.entity.TickLabelEntity(shape28, "hi!", "RectangleConstraintType.RANGE");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke37 = defaultDrawingSupplier36.getNextOutlineStroke();
        java.awt.Color color38 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("", "ThreadContext", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "DatasetRenderingOrder.FORWARD", true, shape11, true, (java.awt.Paint) color14, true, (java.awt.Paint) color18, stroke26, false, shape28, stroke37, (java.awt.Paint) color38);
        boolean boolean40 = legendItem39.isShapeFilled();
        java.lang.Comparable comparable41 = legendItem39.getSeriesKey();
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(comparable41);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.awt.geom.Arc2D arc2D0 = null;
        java.awt.geom.Arc2D arc2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(arc2D0, arc2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color9 = java.awt.Color.RED;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke12 = valueMarker11.getOutlineStroke();
        java.awt.Paint paint13 = valueMarker11.getOutlinePaint();
        java.awt.Stroke stroke14 = valueMarker11.getStroke();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand23 = null;
        numberAxis22.setMarkerBand(markerAxisBand23);
        java.awt.Stroke stroke25 = numberAxis22.getTickMarkStroke();
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis22.setUpArrow(shape27);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color34 = java.awt.Color.RED;
        categoryAxis33.setLabelPaint((java.awt.Paint) color34);
        float[] floatArray40 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray41 = color34.getRGBColorComponents(floatArray40);
        java.awt.Stroke stroke42 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape44 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity45 = new org.jfree.chart.entity.LegendItemEntity(shape44);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity48 = new org.jfree.chart.entity.TickLabelEntity(shape44, "", "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity51 = new org.jfree.chart.entity.TickLabelEntity(shape44, "hi!", "RectangleConstraintType.RANGE");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier52 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke53 = defaultDrawingSupplier52.getNextOutlineStroke();
        java.awt.Color color54 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem55 = new org.jfree.chart.LegendItem("", "ThreadContext", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "DatasetRenderingOrder.FORWARD", true, shape27, true, (java.awt.Paint) color30, true, (java.awt.Paint) color34, stroke42, false, shape44, stroke53, (java.awt.Paint) color54);
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand63 = null;
        numberAxis62.setMarkerBand(markerAxisBand63);
        java.awt.Stroke stroke65 = numberAxis62.getTickMarkStroke();
        java.awt.Shape shape67 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis62.setUpArrow(shape67);
        java.awt.Color color70 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis73 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color74 = java.awt.Color.RED;
        categoryAxis73.setLabelPaint((java.awt.Paint) color74);
        float[] floatArray80 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray81 = color74.getRGBColorComponents(floatArray80);
        java.awt.Stroke stroke82 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape84 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity85 = new org.jfree.chart.entity.LegendItemEntity(shape84);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity88 = new org.jfree.chart.entity.TickLabelEntity(shape84, "", "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity91 = new org.jfree.chart.entity.TickLabelEntity(shape84, "hi!", "RectangleConstraintType.RANGE");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier92 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke93 = defaultDrawingSupplier92.getNextOutlineStroke();
        java.awt.Color color94 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem95 = new org.jfree.chart.LegendItem("", "ThreadContext", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "DatasetRenderingOrder.FORWARD", true, shape67, true, (java.awt.Paint) color70, true, (java.awt.Paint) color74, stroke82, false, shape84, stroke93, (java.awt.Paint) color94);
        java.awt.Paint paint96 = null;
        try {
            org.jfree.chart.LegendItem legendItem97 = new org.jfree.chart.LegendItem(attributedString0, "CONTRACT", "ThreadContext", "TextAnchor.BASELINE_RIGHT", true, shape5, false, (java.awt.Paint) color7, true, (java.awt.Paint) color9, stroke14, false, shape44, stroke82, paint96);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(shape67);
        org.junit.Assert.assertNotNull(color70);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertNotNull(floatArray80);
        org.junit.Assert.assertNotNull(floatArray81);
        org.junit.Assert.assertNotNull(stroke82);
        org.junit.Assert.assertNotNull(shape84);
        org.junit.Assert.assertNotNull(stroke93);
        org.junit.Assert.assertNotNull(color94);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        double[] doubleArray10 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray17 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray24 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray31 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray38 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray45 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray46 = new double[][] { doubleArray10, doubleArray17, doubleArray24, doubleArray31, doubleArray38, doubleArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset47, (int) (short) 0);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer51 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) pieDataset49, (java.lang.Comparable) "ThreadContext");
        java.lang.Object obj52 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) legendItemBlockContainer51);
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double56 = categoryAxis55.getLabelAngle();
        java.awt.Font font58 = categoryAxis55.getTickLabelFont((java.lang.Comparable) 10.0d);
        org.jfree.chart.title.TextTitle textTitle59 = new org.jfree.chart.title.TextTitle("-3,-3,3,3", font58);
        boolean boolean60 = legendItemBlockContainer51.equals((java.lang.Object) textTitle59);
        java.lang.Object obj61 = legendItemBlockContainer51.clone();
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(obj61);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        double[] doubleArray10 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray17 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray24 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray31 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray38 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray45 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray46 = new double[][] { doubleArray10, doubleArray17, doubleArray24, doubleArray31, doubleArray38, doubleArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset47, (int) (short) 0);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer51 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) pieDataset49, (java.lang.Comparable) "ThreadContext");
        java.lang.Object obj52 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) legendItemBlockContainer51);
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double56 = categoryAxis55.getLabelAngle();
        java.awt.Font font58 = categoryAxis55.getTickLabelFont((java.lang.Comparable) 10.0d);
        org.jfree.chart.title.TextTitle textTitle59 = new org.jfree.chart.title.TextTitle("-3,-3,3,3", font58);
        boolean boolean60 = legendItemBlockContainer51.equals((java.lang.Object) textTitle59);
        java.lang.String str61 = legendItemBlockContainer51.getToolTipText();
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(str61);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.awt.Color color1 = java.awt.Color.magenta;
        java.awt.Stroke stroke2 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker(1.0E-8d, (java.awt.Paint) color1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick(tickType0, (double) 'a', "DatasetRenderingOrder.FORWARD", textAnchor3, textAnchor4, 4.0d);
        org.jfree.chart.text.TextAnchor textAnchor7 = numberTick6.getRotationAnchor();
        double double8 = numberTick6.getValue();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 97.0d + "'", double8 == 97.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        double double6 = legendTitle5.getHeight();
        flowArrangement0.add((org.jfree.chart.block.Block) legendTitle3, (java.lang.Object) double6);
        java.awt.Color color8 = java.awt.Color.GREEN;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color12 = java.awt.Color.RED;
        categoryAxis11.setLabelPaint((java.awt.Paint) color12);
        categoryAxis11.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint16 = categoryAxis11.getTickLabelPaint();
        java.awt.Stroke stroke17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder19 = new org.jfree.chart.block.LineBorder(paint16, stroke17, rectangleInsets18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = lineBorder19.getInsets();
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color8, stroke9, rectangleInsets20);
        legendTitle3.setFrame((org.jfree.chart.block.BlockFrame) lineBorder21);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        java.awt.Font font4 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 10.0d);
        double double5 = categoryAxis1.getLabelAngle();
        java.awt.Shape shape6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color13 = java.awt.Color.RED;
        categoryAxis12.setLabelPaint((java.awt.Paint) color13);
        float[] floatArray19 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray20 = color13.getRGBColorComponents(floatArray19);
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape10, (java.awt.Paint) color13);
        java.awt.Shape shape22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape22, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color29 = java.awt.Color.RED;
        categoryAxis28.setLabelPaint((java.awt.Paint) color29);
        float[] floatArray35 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray36 = color29.getRGBColorComponents(floatArray35);
        org.jfree.chart.title.LegendGraphic legendGraphic37 = new org.jfree.chart.title.LegendGraphic(shape26, (java.awt.Paint) color29);
        legendGraphic21.setLinePaint((java.awt.Paint) color29);
        boolean boolean39 = categoryAxis1.equals((java.lang.Object) legendGraphic21);
        java.awt.Shape shape40 = legendGraphic21.getLine();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(shape40);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset45);
        double double50 = range48.constrain((double) (short) 1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) 'a');
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = legendTitle5.getLegendItemGraphicAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition8 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor6, textBlockAnchor7);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions3, categoryLabelPosition8);
        boolean boolean10 = standardGradientPaintTransformer1.equals((java.lang.Object) categoryLabelPositions9);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(categoryLabelPositions3);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        double double6 = legendTitle5.getHeight();
        flowArrangement0.add((org.jfree.chart.block.Block) legendTitle3, (java.lang.Object) double6);
        org.jfree.chart.block.FlowArrangement flowArrangement8 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement8.clear();
        double[] doubleArray18 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray25 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray32 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray39 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray46 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray53 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray54 = new double[][] { doubleArray18, doubleArray25, doubleArray32, doubleArray39, doubleArray46, doubleArray53 };
        org.jfree.data.category.CategoryDataset categoryDataset55 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray54);
        org.jfree.data.general.PieDataset pieDataset57 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset55, (int) (short) 0);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer59 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement8, (org.jfree.data.general.Dataset) pieDataset57, (java.lang.Comparable) "ThreadContext");
        java.lang.Comparable comparable60 = legendItemBlockContainer59.getSeriesKey();
        java.awt.Graphics2D graphics2D61 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint62 = null;
        try {
            org.jfree.chart.util.Size2D size2D63 = flowArrangement0.arrange((org.jfree.chart.block.BlockContainer) legendItemBlockContainer59, graphics2D61, rectangleConstraint62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(categoryDataset55);
        org.junit.Assert.assertNotNull(pieDataset57);
        org.junit.Assert.assertTrue("'" + comparable60 + "' != '" + "ThreadContext" + "'", comparable60.equals("ThreadContext"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double4 = categoryAxis3.getLabelAngle();
        java.awt.Font font6 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 10.0d);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("-3,-3,3,3", font6);
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("ThreadContext", font6);
        boolean boolean10 = labelBlock8.equals((java.lang.Object) 1.0E-8d);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) 8, (double) 2.0f);
        try {
            org.jfree.chart.util.Size2D size2D15 = labelBlock8.arrange(graphics2D11, rectangleConstraint14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setBottom((double) '#');
        double double3 = axisSpace0.getLeft();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.lang.Object obj6 = null;
        boolean boolean7 = rectangleEdge5.equals(obj6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge5);
        axisSpace0.ensureAtLeast((double) 100, rectangleEdge5);
        double double10 = axisSpace0.getBottom();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.awt.Color color0 = java.awt.Color.GREEN;
        java.awt.Stroke stroke1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color4 = java.awt.Color.RED;
        categoryAxis3.setLabelPaint((java.awt.Paint) color4);
        categoryAxis3.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint8 = categoryAxis3.getTickLabelPaint();
        java.awt.Stroke stroke9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder11 = new org.jfree.chart.block.LineBorder(paint8, stroke9, rectangleInsets10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = lineBorder11.getInsets();
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets12);
        double double15 = rectangleInsets12.calculateLeftInset(1.0E-8d);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker1.setLabelAnchor(rectangleAnchor3);
        java.lang.Class<?> wildcardClass5 = valueMarker1.getClass();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke8 = valueMarker7.getOutlineStroke();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        valueMarker7.setLabelOffsetType(lengthAdjustmentType9);
        valueMarker1.setLabelOffsetType(lengthAdjustmentType9);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color14 = java.awt.Color.RED;
        categoryAxis13.setLabelPaint((java.awt.Paint) color14);
        categoryAxis13.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint18 = categoryAxis13.getTickLabelPaint();
        java.awt.Stroke stroke19 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder21 = new org.jfree.chart.block.LineBorder(paint18, stroke19, rectangleInsets20);
        valueMarker1.setStroke(stroke19);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double25 = categoryAxis24.getLabelAngle();
        categoryAxis24.setLowerMargin((double) 0);
        categoryAxis24.setUpperMargin(0.0d);
        java.lang.String str30 = categoryAxis24.getLabel();
        double double31 = categoryAxis24.getUpperMargin();
        org.jfree.chart.LegendItemSource legendItemSource33 = null;
        org.jfree.chart.title.LegendTitle legendTitle34 = new org.jfree.chart.title.LegendTitle(legendItemSource33);
        double double35 = legendTitle34.getWidth();
        legendTitle34.setHeight((double) (byte) 10);
        java.awt.Font font38 = legendTitle34.getItemFont();
        org.jfree.chart.text.TextFragment textFragment39 = new org.jfree.chart.text.TextFragment("", font38);
        categoryAxis24.setTickLabelFont(font38);
        valueMarker1.setLabelFont(font38);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(lengthAdjustmentType9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "hi!" + "'", str30.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(font38);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number3 = defaultStatisticalCategoryDataset0.getStdDevValue((java.lang.Comparable) "VerticalAlignment.CENTER", (java.lang.Comparable) (short) 10);
        try {
            java.lang.Comparable comparable5 = defaultStatisticalCategoryDataset0.getColumnKey((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(number3);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        java.lang.Class class0 = null;
//        java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
//        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader1);
//        java.util.ResourceBundle.clearCache(classLoader1);
//        org.junit.Assert.assertNotNull(classLoader1);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.block.BlockContainer blockContainer3 = null;
        legendTitle1.setWrapper(blockContainer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double7 = rectangleInsets5.trimWidth((double) 1L);
        double double8 = rectangleInsets5.getBottom();
        double double10 = rectangleInsets5.calculateRightOutset((double) 0L);
        double double12 = rectangleInsets5.extendHeight((double) 10.0f);
        legendTitle1.setItemLabelPadding(rectangleInsets5);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double16 = rectangleInsets14.trimWidth((double) 1L);
        double double18 = rectangleInsets14.trimWidth((double) 1L);
        legendTitle1.setPadding(rectangleInsets14);
        java.lang.Object obj20 = legendTitle1.clone();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-7.0d) + "'", double7 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.0d + "'", double12 == 14.0d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-7.0d) + "'", double16 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-7.0d) + "'", double18 == (-7.0d));
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double3 = categoryAxis2.getLabelAngle();
        java.awt.Font font5 = categoryAxis2.getTickLabelFont((java.lang.Comparable) 10.0d);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color8 = java.awt.Color.getColor("", color7);
        org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=192,g=192,b=0]", font5, (java.awt.Paint) color8);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        java.awt.Paint paint3 = valueMarker1.getOutlinePaint();
        java.awt.Paint paint4 = valueMarker1.getLabelPaint();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = valueMarker6.getLabelOffsetType();
        java.lang.String str8 = lengthAdjustmentType7.toString();
        valueMarker1.setLabelOffsetType(lengthAdjustmentType7);
        java.awt.Color color10 = java.awt.Color.pink;
        valueMarker1.setPaint((java.awt.Paint) color10);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker1.setOutlineStroke(stroke12);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "CONTRACT" + "'", str8.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getCopyright();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo7 = new org.jfree.chart.ui.BasicProjectInfo("ThreadContext", "ThreadContext", "hi!", "-3,-3,3,3", "");
        projectInfo0.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo7);
        projectInfo0.setLicenceText("RectangleConstraintType.RANGE");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str1.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.function.Function2D function2D0 = null;
        java.lang.Comparable comparable4 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) 100L, (double) 10.0f, 8, comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) 1L);
        java.lang.String str3 = rectangleInsets0.toString();
        double double5 = rectangleInsets0.extendWidth((double) 1L);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.0d) + "'", double2 == (-7.0d));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str3.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 9.0d + "'", double5 == 9.0d);
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        java.util.Locale locale1 = null;
//        java.lang.Class class2 = null;
//        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
//        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader3);
//        java.util.ResourceBundle.Control control5 = null;
//        try {
//            java.util.ResourceBundle resourceBundle6 = java.util.ResourceBundle.getBundle("TextAnchor.BASELINE_RIGHT", locale1, classLoader3, control5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(classLoader3);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color2 = java.awt.Color.MAGENTA;
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis1.getLabelURL();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions5);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions8 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions5, categoryLabelPosition7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'left' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        java.awt.Stroke stroke4 = numberAxis1.getTickMarkStroke();
        numberAxis1.setUpperMargin((double) 0.5f);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double9 = categoryAxis8.getLabelAngle();
        java.awt.Font font11 = categoryAxis8.getTickLabelFont((java.lang.Comparable) 10.0d);
        double double12 = categoryAxis8.getLabelAngle();
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        categoryAxis8.setAxisLinePaint(paint13);
        numberAxis1.setTickMarkPaint(paint13);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.lang.Number[][] numberArray2 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "VerticalAlignment.CENTER", numberArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        boolean boolean3 = itemLabelAnchor0.equals((java.lang.Object) legendTitle2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color6 = java.awt.Color.RED;
        categoryAxis5.setLabelPaint((java.awt.Paint) color6);
        categoryAxis5.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint10 = categoryAxis5.getTickLabelPaint();
        java.awt.Stroke stroke11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder(paint10, stroke11, rectangleInsets12);
        legendTitle2.setFrame((org.jfree.chart.block.BlockFrame) lineBorder13);
        org.jfree.chart.axis.AxisSpace axisSpace15 = new org.jfree.chart.axis.AxisSpace();
        axisSpace15.setBottom((double) '#');
        java.lang.String str18 = axisSpace15.toString();
        double double19 = axisSpace15.getBottom();
        org.jfree.chart.axis.AxisSpace axisSpace21 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        axisSpace21.add(0.0d, rectangleEdge23);
        boolean boolean25 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge23);
        axisSpace15.add(0.05d, rectangleEdge23);
        legendTitle2.setLegendItemGraphicEdge(rectangleEdge23);
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType30 = valueMarker29.getLabelOffsetType();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker29.setLabelAnchor(rectangleAnchor31);
        legendTitle2.setLegendItemGraphicLocation(rectangleAnchor31);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 35.0d + "'", double19 == 35.0d);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType30);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.setMax(3.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.add((java.lang.Number) 35.0d, (java.lang.Number) 100.0d, (java.lang.Comparable) (short) 100, (java.lang.Comparable) (short) 1);
        try {
            java.lang.Comparable comparable7 = defaultStatisticalCategoryDataset0.getColumnKey((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "LGPL", "VerticalAlignment.CENTER", "CONTRACT");
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        double[] doubleArray10 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray17 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray24 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray31 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray38 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray45 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray46 = new double[][] { doubleArray10, doubleArray17, doubleArray24, doubleArray31, doubleArray38, doubleArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset47, (int) (short) 0);
        legendItemEntity1.setDataset((org.jfree.data.general.Dataset) pieDataset49);
        org.jfree.data.general.PieDataset pieDataset54 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset49, (java.lang.Comparable) 0.05d, 2.0d, (int) '#');
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertNotNull(pieDataset54);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        double double6 = legendTitle5.getHeight();
        flowArrangement0.add((org.jfree.chart.block.Block) legendTitle3, (java.lang.Object) double6);
        java.lang.String str8 = legendTitle3.getID();
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent9 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) legendTitle3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        java.awt.Font font4 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 10.0d);
        double double5 = categoryAxis1.getLabelAngle();
        java.awt.Shape shape6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color13 = java.awt.Color.RED;
        categoryAxis12.setLabelPaint((java.awt.Paint) color13);
        float[] floatArray19 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray20 = color13.getRGBColorComponents(floatArray19);
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape10, (java.awt.Paint) color13);
        java.awt.Shape shape22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape22, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color29 = java.awt.Color.RED;
        categoryAxis28.setLabelPaint((java.awt.Paint) color29);
        float[] floatArray35 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray36 = color29.getRGBColorComponents(floatArray35);
        org.jfree.chart.title.LegendGraphic legendGraphic37 = new org.jfree.chart.title.LegendGraphic(shape26, (java.awt.Paint) color29);
        legendGraphic21.setLinePaint((java.awt.Paint) color29);
        boolean boolean39 = categoryAxis1.equals((java.lang.Object) legendGraphic21);
        legendGraphic21.setLineVisible(false);
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int43 = color42.getBlue();
        legendGraphic21.setLinePaint((java.awt.Paint) color42);
        legendGraphic21.setShapeFilled(false);
        org.jfree.chart.block.FlowArrangement flowArrangement47 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement47.clear();
        org.jfree.chart.LegendItemSource legendItemSource49 = null;
        org.jfree.chart.title.LegendTitle legendTitle50 = new org.jfree.chart.title.LegendTitle(legendItemSource49);
        org.jfree.chart.LegendItemSource legendItemSource51 = null;
        org.jfree.chart.title.LegendTitle legendTitle52 = new org.jfree.chart.title.LegendTitle(legendItemSource51);
        double double53 = legendTitle52.getHeight();
        flowArrangement47.add((org.jfree.chart.block.Block) legendTitle50, (java.lang.Object) double53);
        legendTitle50.setWidth((double) (byte) -1);
        java.awt.Paint paint57 = legendTitle50.getItemPaint();
        legendGraphic21.setFillPaint(paint57);
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color61 = java.awt.Color.RED;
        categoryAxis60.setLabelPaint((java.awt.Paint) color61);
        int int63 = color61.getRed();
        int int64 = color61.getRed();
        legendGraphic21.setOutlinePaint((java.awt.Paint) color61);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 255 + "'", int43 == 255);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 255 + "'", int63 == 255);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 255 + "'", int64 == 255);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.clear();
        java.awt.Shape shape2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color9 = java.awt.Color.RED;
        categoryAxis8.setLabelPaint((java.awt.Paint) color9);
        float[] floatArray15 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray16 = color9.getRGBColorComponents(floatArray15);
        org.jfree.chart.title.LegendGraphic legendGraphic17 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color9);
        blockContainer0.add((org.jfree.chart.block.Block) legendGraphic17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = legendGraphic17.getShapeAnchor();
        java.lang.String str20 = rectangleAnchor19.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "RectangleAnchor.CENTER" + "'", str20.equals("RectangleAnchor.CENTER"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (int) (byte) 0);
        org.junit.Assert.assertNotNull(pieDataset2);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        numberAxis1.resizeRange((double) 100.0f);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity3 = new org.jfree.chart.entity.LegendItemEntity(shape2);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity6 = new org.jfree.chart.entity.TickLabelEntity(shape2, "", "");
        shapeList0.setShape(0, shape2);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        double[] doubleArray10 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray17 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray24 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray31 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray38 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray45 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray46 = new double[][] { doubleArray10, doubleArray17, doubleArray24, doubleArray31, doubleArray38, doubleArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset47, (int) (short) 0);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer51 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) pieDataset49, (java.lang.Comparable) "ThreadContext");
        java.lang.Object obj52 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) legendItemBlockContainer51);
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double56 = categoryAxis55.getLabelAngle();
        java.awt.Font font58 = categoryAxis55.getTickLabelFont((java.lang.Comparable) 10.0d);
        org.jfree.chart.title.TextTitle textTitle59 = new org.jfree.chart.title.TextTitle("-3,-3,3,3", font58);
        boolean boolean60 = legendItemBlockContainer51.equals((java.lang.Object) textTitle59);
        java.awt.Graphics2D graphics2D61 = null;
        org.jfree.chart.axis.NumberAxis numberAxis63 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand64 = null;
        numberAxis63.setMarkerBand(markerAxisBand64);
        org.jfree.data.Range range67 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint68 = new org.jfree.chart.block.RectangleConstraint((double) 0, range67);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint70 = rectangleConstraint68.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint71 = rectangleConstraint70.toUnconstrainedWidth();
        boolean boolean72 = numberAxis63.equals((java.lang.Object) rectangleConstraint71);
        try {
            org.jfree.chart.util.Size2D size2D73 = legendItemBlockContainer51.arrange(graphics2D61, rectangleConstraint71);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(rectangleConstraint70);
        org.junit.Assert.assertNotNull(rectangleConstraint71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        double[] doubleArray10 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray17 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray24 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray31 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray38 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray45 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray46 = new double[][] { doubleArray10, doubleArray17, doubleArray24, doubleArray31, doubleArray38, doubleArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset47, (int) (short) 0);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer51 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) pieDataset49, (java.lang.Comparable) "ThreadContext");
        java.lang.Object obj52 = legendItemBlockContainer51.clone();
        boolean boolean53 = legendItemBlockContainer51.isEmpty();
        java.awt.Graphics2D graphics2D54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        java.awt.Font font56 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        try {
            java.lang.Object obj57 = legendItemBlockContainer51.draw(graphics2D54, rectangle2D55, (java.lang.Object) font56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(font56);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        categoryAxis1.setLowerMargin((double) 0);
        double double5 = categoryAxis1.getLabelAngle();
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        double double8 = legendTitle7.getHeight();
        org.jfree.chart.block.BlockContainer blockContainer9 = null;
        legendTitle7.setWrapper(blockContainer9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double13 = rectangleInsets11.trimWidth((double) 1L);
        double double14 = rectangleInsets11.getBottom();
        double double16 = rectangleInsets11.calculateRightOutset((double) 0L);
        double double18 = rectangleInsets11.extendHeight((double) 10.0f);
        legendTitle7.setItemLabelPadding(rectangleInsets11);
        categoryAxis1.setLabelInsets(rectangleInsets11);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor21 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.axis.AxisSpace axisSpace25 = new org.jfree.chart.axis.AxisSpace();
        axisSpace25.setBottom((double) '#');
        double double28 = axisSpace25.getLeft();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.lang.Object obj31 = null;
        boolean boolean32 = rectangleEdge30.equals(obj31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge30);
        axisSpace25.ensureAtLeast((double) 100, rectangleEdge30);
        try {
            double double35 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor21, 1, 0, rectangle2D24, rectangleEdge30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-7.0d) + "'", double13 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 14.0d + "'", double18 == 14.0d);
        org.junit.Assert.assertNotNull(categoryAnchor21);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleEdge33);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setBottom((double) '#');
        java.lang.String str3 = axisSpace0.toString();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = axisSpace0.reserved(rectangle2D4, rectangleEdge5);
        double double7 = axisSpace0.getLeft();
        org.junit.Assert.assertNull(rectangle2D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        java.lang.String str1 = horizontalAlignment0.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.RIGHT" + "'", str1.equals("HorizontalAlignment.RIGHT"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker1.setLabelAnchor(rectangleAnchor3);
        java.lang.Class<?> wildcardClass5 = valueMarker1.getClass();
        org.jfree.chart.event.MarkerChangeListener markerChangeListener6 = null;
        valueMarker1.removeChangeListener(markerChangeListener6);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.RendererState rendererState2 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = rendererState2.getInfo();
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState4 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo3);
        java.awt.geom.Point2D point2D5 = null;
        try {
            int int6 = plotRenderingInfo3.getSubplotIndex(point2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotRenderingInfo3);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.lang.Object obj1 = defaultDrawingSupplier0.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color4 = java.awt.Color.MAGENTA;
        categoryAxis3.setTickMarkPaint((java.awt.Paint) color4);
        java.lang.String str6 = categoryAxis3.getLabelURL();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        categoryAxis3.setCategoryLabelPositions(categoryLabelPositions7);
        boolean boolean9 = defaultDrawingSupplier0.equals((java.lang.Object) categoryLabelPositions7);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.Range range46 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset45);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint48 = new org.jfree.chart.block.RectangleConstraint(range46, 0.05d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(range46);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean3 = categoryLabelPosition1.equals((java.lang.Object) categoryLabelPosition2);
        org.jfree.chart.text.TextAnchor textAnchor4 = categoryLabelPosition1.getRotationAnchor();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke7 = valueMarker6.getOutlineStroke();
        boolean boolean8 = categoryLabelPosition1.equals((java.lang.Object) valueMarker6);
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        java.awt.Paint paint3 = valueMarker1.getOutlinePaint();
        java.awt.Paint paint4 = valueMarker1.getLabelPaint();
        java.lang.Object obj5 = valueMarker1.clone();
        valueMarker1.setLabel("DatasetRenderingOrder.FORWARD");
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color2 = java.awt.Color.MAGENTA;
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color2);
        int int4 = color2.getTransparency();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double3 = categoryAxis2.getLabelAngle();
        java.awt.Font font5 = categoryAxis2.getTickLabelFont((java.lang.Comparable) 10.0d);
        double double6 = categoryAxis2.getLabelAngle();
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape7, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color14 = java.awt.Color.RED;
        categoryAxis13.setLabelPaint((java.awt.Paint) color14);
        float[] floatArray20 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray21 = color14.getRGBColorComponents(floatArray20);
        org.jfree.chart.title.LegendGraphic legendGraphic22 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color14);
        java.awt.Shape shape23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape23, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color30 = java.awt.Color.RED;
        categoryAxis29.setLabelPaint((java.awt.Paint) color30);
        float[] floatArray36 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray37 = color30.getRGBColorComponents(floatArray36);
        org.jfree.chart.title.LegendGraphic legendGraphic38 = new org.jfree.chart.title.LegendGraphic(shape27, (java.awt.Paint) color30);
        legendGraphic22.setLinePaint((java.awt.Paint) color30);
        boolean boolean40 = categoryAxis2.equals((java.lang.Object) legendGraphic22);
        java.awt.Stroke stroke41 = null;
        legendGraphic22.setOutlineStroke(stroke41);
        org.jfree.data.KeyedObject keyedObject43 = new org.jfree.data.KeyedObject((java.lang.Comparable) 1, (java.lang.Object) legendGraphic22);
        java.lang.String str44 = legendGraphic22.getID();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(str44);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        java.awt.Paint paint3 = valueMarker1.getOutlinePaint();
        java.awt.Color color6 = java.awt.Color.getColor("CONTRACT", (int) (short) 100);
        valueMarker1.setPaint((java.awt.Paint) color6);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color7 = java.awt.Color.RED;
        categoryAxis6.setLabelPaint((java.awt.Paint) color7);
        float[] floatArray13 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray14 = color7.getRGBColorComponents(floatArray13);
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape4, (java.awt.Paint) color7);
        java.awt.Paint paint16 = legendGraphic15.getOutlinePaint();
        legendGraphic15.setMargin((double) 100.0f, (double) (short) 0, (double) (short) -1, (double) (short) 100);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNull(paint16);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color5 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("ThreadContext", font4, (java.awt.Paint) color5);
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font4);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!", font4);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.lang.Object obj12 = textTitle8.draw(graphics2D9, rectangle2D10, (java.lang.Object) (byte) 100);
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color15 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("ThreadContext", font14, (java.awt.Paint) color15);
        textTitle8.setFont(font14);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("RangeType.FULL", font14);
        java.lang.String str19 = textTitle18.getURLText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine();
        java.awt.Font font23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color24 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment25 = new org.jfree.chart.text.TextFragment("ThreadContext", font23, (java.awt.Paint) color24);
        textLine21.addFragment(textFragment25);
        boolean boolean27 = horizontalAlignment20.equals((java.lang.Object) textFragment25);
        textTitle18.setTextAlignment(horizontalAlignment20);
        org.jfree.chart.block.BlockContainer blockContainer29 = new org.jfree.chart.block.BlockContainer();
        blockContainer29.clear();
        java.awt.Shape shape31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape31, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color38 = java.awt.Color.RED;
        categoryAxis37.setLabelPaint((java.awt.Paint) color38);
        float[] floatArray44 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray45 = color38.getRGBColorComponents(floatArray44);
        org.jfree.chart.title.LegendGraphic legendGraphic46 = new org.jfree.chart.title.LegendGraphic(shape35, (java.awt.Paint) color38);
        blockContainer29.add((org.jfree.chart.block.Block) legendGraphic46);
        java.awt.Shape shape48 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape52 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape48, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color55 = java.awt.Color.RED;
        categoryAxis54.setLabelPaint((java.awt.Paint) color55);
        float[] floatArray61 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray62 = color55.getRGBColorComponents(floatArray61);
        org.jfree.chart.title.LegendGraphic legendGraphic63 = new org.jfree.chart.title.LegendGraphic(shape52, (java.awt.Paint) color55);
        legendGraphic46.setOutlinePaint((java.awt.Paint) color55);
        java.awt.Stroke stroke65 = legendGraphic46.getLineStroke();
        legendGraphic46.setShapeVisible(false);
        boolean boolean68 = horizontalAlignment20.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(floatArray61);
        org.junit.Assert.assertNotNull(floatArray62);
        org.junit.Assert.assertNull(stroke65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double3 = categoryAxis2.getLabelAngle();
        categoryAxis2.setLowerMargin((double) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color8 = java.awt.Color.RED;
        categoryAxis7.setLabelPaint((java.awt.Paint) color8);
        categoryAxis7.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint12 = categoryAxis7.getTickLabelPaint();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder15 = new org.jfree.chart.block.LineBorder(paint12, stroke13, rectangleInsets14);
        categoryAxis2.setAxisLineStroke(stroke13);
        float float17 = categoryAxis2.getTickMarkOutsideLength();
        boolean boolean18 = tickUnits0.equals((java.lang.Object) float17);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit19 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        try {
            org.jfree.chart.axis.TickUnit tickUnit20 = tickUnits0.getLargerTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit19);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 2.0f + "'", float17 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(numberTickUnit19);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        double[] doubleArray9 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray16 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray23 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray30 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray37 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray44 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray45 = new double[][] { doubleArray9, doubleArray16, doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.jfree.data.category.CategoryDataset categoryDataset46 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray45);
        org.jfree.data.Range range47 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset46);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint48 = new org.jfree.chart.block.RectangleConstraint(0.0d, range47);
        boolean boolean50 = range47.contains((double) '4');
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(categoryDataset46);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list1 = projectInfo0.getContributors();
        projectInfo0.setCopyright("LGPL");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.awt.Font font1 = null;
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        java.awt.Font font5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double8 = categoryAxis7.getLabelAngle();
        categoryAxis7.setLowerMargin((double) 0);
        categoryAxis7.setUpperMargin(0.0d);
        java.lang.String str13 = categoryAxis7.getLabel();
        double double14 = categoryAxis7.getUpperMargin();
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke18 = valueMarker17.getOutlineStroke();
        java.awt.Paint paint19 = valueMarker17.getOutlinePaint();
        categoryAxis7.setTickLabelPaint((java.lang.Comparable) 10.0d, paint19);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer24 = new org.jfree.chart.text.G2TextMeasurer(graphics2D23);
        org.jfree.chart.text.TextBlock textBlock25 = org.jfree.chart.text.TextUtilities.createTextBlock("", font5, paint19, 0.0f, 4, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer24);
        try {
            org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("HorizontalAlignment.RIGHT", font1, paint2, (float) (byte) 10, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(textBlock25);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color2 = java.awt.Color.RED;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        categoryAxis1.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint6 = categoryAxis1.getTickLabelPaint();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder(paint6, stroke7, rectangleInsets8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = lineBorder9.getInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = lineBorder9.getInsets();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType13 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType14 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        try {
            java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets11.createAdjustedRectangle(rectangle2D12, lengthAdjustmentType13, lengthAdjustmentType14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(lengthAdjustmentType14);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis5.setMarkerBand(markerAxisBand6);
        java.awt.Stroke stroke8 = numberAxis5.getTickMarkStroke();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis5.setUpArrow(shape10);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape10, (double) (byte) 10, 1.0E-8d);
        org.jfree.chart.block.FlowArrangement flowArrangement15 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement15.clear();
        org.jfree.chart.LegendItemSource legendItemSource17 = null;
        org.jfree.chart.title.LegendTitle legendTitle18 = new org.jfree.chart.title.LegendTitle(legendItemSource17);
        org.jfree.chart.LegendItemSource legendItemSource19 = null;
        org.jfree.chart.title.LegendTitle legendTitle20 = new org.jfree.chart.title.LegendTitle(legendItemSource19);
        double double21 = legendTitle20.getHeight();
        flowArrangement15.add((org.jfree.chart.block.Block) legendTitle18, (java.lang.Object) double21);
        legendTitle18.setWidth((double) (byte) -1);
        java.awt.Paint paint25 = legendTitle18.getItemPaint();
        try {
            org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem(attributedString0, "", "CONTRACT", "hi!", shape14, paint25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 0);
        java.lang.Object obj2 = objectList1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.awt.Color color1 = java.awt.Color.getColor("RectangleConstraintType.RANGE");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color2 = java.awt.Color.RED;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        categoryAxis1.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint6 = categoryAxis1.getTickLabelPaint();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder(paint6, stroke7, rectangleInsets8);
        java.awt.Stroke stroke10 = lineBorder9.getStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double13 = categoryAxis12.getLabelAngle();
        java.awt.Font font15 = categoryAxis12.getTickLabelFont((java.lang.Comparable) 10.0d);
        double double16 = categoryAxis12.getLabelAngle();
        java.awt.Shape shape17 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape17, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color24 = java.awt.Color.RED;
        categoryAxis23.setLabelPaint((java.awt.Paint) color24);
        float[] floatArray30 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray31 = color24.getRGBColorComponents(floatArray30);
        org.jfree.chart.title.LegendGraphic legendGraphic32 = new org.jfree.chart.title.LegendGraphic(shape21, (java.awt.Paint) color24);
        java.awt.Shape shape33 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape37 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape33, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color40 = java.awt.Color.RED;
        categoryAxis39.setLabelPaint((java.awt.Paint) color40);
        float[] floatArray46 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray47 = color40.getRGBColorComponents(floatArray46);
        org.jfree.chart.title.LegendGraphic legendGraphic48 = new org.jfree.chart.title.LegendGraphic(shape37, (java.awt.Paint) color40);
        legendGraphic32.setLinePaint((java.awt.Paint) color40);
        boolean boolean50 = categoryAxis12.equals((java.lang.Object) legendGraphic32);
        java.awt.Stroke stroke51 = null;
        legendGraphic32.setOutlineStroke(stroke51);
        boolean boolean53 = lineBorder9.equals((java.lang.Object) legendGraphic32);
        java.awt.Stroke stroke54 = lineBorder9.getStroke();
        java.awt.Graphics2D graphics2D55 = null;
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        try {
            lineBorder9.draw(graphics2D55, rectangle2D56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(stroke54);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.MAGENTA;
        int int3 = color2.getRed();
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("hi!", font1, (java.awt.Paint) color2, (float) 'a');
        java.awt.image.ColorModel colorModel6 = null;
        java.awt.Rectangle rectangle7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.AffineTransform affineTransform9 = null;
        java.awt.RenderingHints renderingHints10 = null;
        java.awt.PaintContext paintContext11 = color2.createContext(colorModel6, rectangle7, rectangle2D8, affineTransform9, renderingHints10);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(paintContext11);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("DatasetRenderingOrder.FORWARD", graphics2D1, (double) '#', (float) (byte) 1, 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("TextAnchor.BASELINE_RIGHT");
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) '4', 10.0f);
        numberAxis1.setUpArrow(shape4);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.axis.AxisSpace axisSpace8 = new org.jfree.chart.axis.AxisSpace();
        axisSpace8.setBottom((double) '#');
        double double11 = axisSpace8.getLeft();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.lang.Object obj14 = null;
        boolean boolean15 = rectangleEdge13.equals(obj14);
        axisSpace8.add((double) (-1.0f), rectangleEdge13);
        try {
            double double17 = numberAxis1.java2DToValue(1.0E-8d, rectangle2D7, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.block.BlockFrame blockFrame1 = textTitle0.getFrame();
        org.junit.Assert.assertNotNull(blockFrame1);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) 1L);
        double double4 = rectangleInsets0.trimWidth((double) 1L);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder(rectangleInsets0, (java.awt.Paint) color5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = blockBorder6.getInsets();
        java.lang.String str8 = rectangleInsets7.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.0d) + "'", double2 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-7.0d) + "'", double4 == (-7.0d));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str8.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 0.0d, (double) (-1L), 100, (java.lang.Comparable) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        double double5 = legendTitle4.getHeight();
        org.jfree.chart.block.BlockContainer blockContainer6 = null;
        legendTitle4.setWrapper(blockContainer6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double10 = rectangleInsets8.trimWidth((double) 1L);
        double double11 = rectangleInsets8.getBottom();
        double double13 = rectangleInsets8.calculateRightOutset((double) 0L);
        double double15 = rectangleInsets8.extendHeight((double) 10.0f);
        legendTitle4.setItemLabelPadding(rectangleInsets8);
        double double18 = rectangleInsets8.trimWidth(0.2d);
        legendTitle1.setLegendItemGraphicPadding(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-7.0d) + "'", double10 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 14.0d + "'", double15 == 14.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-7.8d) + "'", double18 == (-7.8d));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        java.lang.String str1 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.DESCENDING" + "'", str1.equals("SortOrder.DESCENDING"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        double double6 = legendTitle5.getHeight();
        flowArrangement0.add((org.jfree.chart.block.Block) legendTitle3, (java.lang.Object) double6);
        java.lang.String str8 = legendTitle3.getID();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = null;
        numberAxis15.setMarkerBand(markerAxisBand16);
        java.awt.Stroke stroke18 = numberAxis15.getTickMarkStroke();
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis15.setUpArrow(shape20);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color27 = java.awt.Color.RED;
        categoryAxis26.setLabelPaint((java.awt.Paint) color27);
        float[] floatArray33 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray34 = color27.getRGBColorComponents(floatArray33);
        java.awt.Stroke stroke35 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape37 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity38 = new org.jfree.chart.entity.LegendItemEntity(shape37);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity41 = new org.jfree.chart.entity.TickLabelEntity(shape37, "", "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity44 = new org.jfree.chart.entity.TickLabelEntity(shape37, "hi!", "RectangleConstraintType.RANGE");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier45 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke46 = defaultDrawingSupplier45.getNextOutlineStroke();
        java.awt.Color color47 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("", "ThreadContext", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "DatasetRenderingOrder.FORWARD", true, shape20, true, (java.awt.Paint) color23, true, (java.awt.Paint) color27, stroke35, false, shape37, stroke46, (java.awt.Paint) color47);
        java.awt.Paint paint49 = legendItem48.getOutlinePaint();
        java.awt.Paint paint50 = legendItem48.getFillPaint();
        legendTitle3.setBackgroundPaint(paint50);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(paint50);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        int int3 = java.awt.Color.HSBtoRGB((float) 1L, (float) (byte) -1, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-2) + "'", int3 == (-2));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.clear();
        java.awt.Shape shape2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color9 = java.awt.Color.RED;
        categoryAxis8.setLabelPaint((java.awt.Paint) color9);
        float[] floatArray15 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray16 = color9.getRGBColorComponents(floatArray15);
        org.jfree.chart.title.LegendGraphic legendGraphic17 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color9);
        blockContainer0.add((org.jfree.chart.block.Block) legendGraphic17);
        java.awt.Shape shape19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape19, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color26 = java.awt.Color.RED;
        categoryAxis25.setLabelPaint((java.awt.Paint) color26);
        float[] floatArray32 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray33 = color26.getRGBColorComponents(floatArray32);
        org.jfree.chart.title.LegendGraphic legendGraphic34 = new org.jfree.chart.title.LegendGraphic(shape23, (java.awt.Paint) color26);
        legendGraphic17.setOutlinePaint((java.awt.Paint) color26);
        java.awt.Shape shape36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity37 = new org.jfree.chart.entity.LegendItemEntity(shape36);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity40 = new org.jfree.chart.entity.TickLabelEntity(shape36, "", "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity43 = new org.jfree.chart.entity.TickLabelEntity(shape36, "hi!", "RectangleConstraintType.RANGE");
        legendGraphic17.setLine(shape36);
        java.awt.Paint paint45 = legendGraphic17.getLinePaint();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNull(paint45);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color2 = java.awt.Color.RED;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        float[] floatArray8 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray9 = color2.getRGBColorComponents(floatArray8);
        org.jfree.chart.JFreeChart jFreeChart10 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) color2, jFreeChart10, (int) (byte) 100, (int) (byte) 100);
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        chartProgressEvent13.setChart(jFreeChart14);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color2 = java.awt.Color.RED;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        categoryAxis1.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint6 = categoryAxis1.getTickLabelPaint();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder(paint6, stroke7, rectangleInsets8);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets8.createOutsetRectangle(rectangle2D10, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = null;
        numberAxis5.setMarkerBand(markerAxisBand6);
        java.awt.Stroke stroke8 = numberAxis5.getTickMarkStroke();
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis5.setUpArrow(shape10);
        java.awt.Shape shape14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape10, (double) (byte) 10, 1.0E-8d);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand17 = null;
        numberAxis16.setMarkerBand(markerAxisBand17);
        java.awt.Stroke stroke19 = numberAxis16.getTickMarkStroke();
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color22 = java.awt.Color.getColor("", color21);
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "hi!", shape14, stroke19, (java.awt.Paint) color21);
        java.awt.Shape shape24 = legendItem23.getShape();
        java.awt.Paint paint25 = legendItem23.getOutlinePaint();
        java.lang.Object obj26 = null;
        boolean boolean27 = legendItem23.equals(obj26);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(4.0d, 0.0d, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        java.text.NumberFormat numberFormat5 = numberAxis1.getNumberFormatOverride();
        java.awt.Paint paint6 = numberAxis1.getLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(numberFormat5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 0.5f, (java.lang.Number) 14.0d);
        java.lang.Number number3 = meanAndStandardDeviation2.getMean();
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke6 = valueMarker5.getOutlineStroke();
        java.awt.Paint paint7 = valueMarker5.getOutlinePaint();
        boolean boolean8 = meanAndStandardDeviation2.equals((java.lang.Object) valueMarker5);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.5f + "'", number3.equals(0.5f));
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range3 = defaultStatisticalCategoryDataset1.getRangeBounds(false);
        int int4 = defaultStatisticalCategoryDataset1.getColumnCount();
        org.jfree.data.general.DatasetChangeListener datasetChangeListener5 = null;
        defaultStatisticalCategoryDataset1.removeChangeListener(datasetChangeListener5);
        try {
            java.lang.String str8 = standardCategorySeriesLabelGenerator0.generateLabel((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double3 = categoryAxis2.getLabelAngle();
        java.awt.Font font5 = categoryAxis2.getTickLabelFont((java.lang.Comparable) 10.0d);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("-3,-3,3,3", font5);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = textTitle6.getPosition();
        boolean boolean8 = textTitle6.getNotify();
        textTitle6.setMargin((double) (short) 0, (double) 10L, (double) (byte) 100, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape0, "", "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity7 = new org.jfree.chart.entity.TickLabelEntity(shape0, "hi!", "RectangleConstraintType.RANGE");
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, (double) (short) -1, 0.0d);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.block.BlockContainer blockContainer3 = null;
        legendTitle1.setWrapper(blockContainer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double7 = rectangleInsets5.trimWidth((double) 1L);
        double double8 = rectangleInsets5.getBottom();
        double double10 = rectangleInsets5.calculateRightOutset((double) 0L);
        double double12 = rectangleInsets5.extendHeight((double) 10.0f);
        legendTitle1.setItemLabelPadding(rectangleInsets5);
        org.jfree.chart.block.BlockContainer blockContainer14 = new org.jfree.chart.block.BlockContainer();
        blockContainer14.clear();
        java.awt.Shape shape16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape16, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color23 = java.awt.Color.RED;
        categoryAxis22.setLabelPaint((java.awt.Paint) color23);
        float[] floatArray29 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray30 = color23.getRGBColorComponents(floatArray29);
        org.jfree.chart.title.LegendGraphic legendGraphic31 = new org.jfree.chart.title.LegendGraphic(shape20, (java.awt.Paint) color23);
        blockContainer14.add((org.jfree.chart.block.Block) legendGraphic31);
        legendTitle1.setWrapper(blockContainer14);
        legendTitle1.setID("[size=1]");
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-7.0d) + "'", double7 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.0d + "'", double12 == 14.0d);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number3 = defaultStatisticalCategoryDataset0.getStdDevValue((java.lang.Comparable) "VerticalAlignment.CENTER", (java.lang.Comparable) (short) 10);
        int int5 = defaultStatisticalCategoryDataset0.getRowIndex((java.lang.Comparable) 100);
        defaultStatisticalCategoryDataset0.add((double) 100.0f, (double) 4, (java.lang.Comparable) (-1), (java.lang.Comparable) 2);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, false);
        java.lang.Comparable comparable14 = defaultStatisticalCategoryDataset0.getColumnKey(0);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 2 + "'", comparable14.equals(2));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = null;
        numberAxis6.setMarkerBand(markerAxisBand7);
        java.awt.Stroke stroke9 = numberAxis6.getTickMarkStroke();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis6.setUpArrow(shape11);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color18 = java.awt.Color.RED;
        categoryAxis17.setLabelPaint((java.awt.Paint) color18);
        float[] floatArray24 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray25 = color18.getRGBColorComponents(floatArray24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape28);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity32 = new org.jfree.chart.entity.TickLabelEntity(shape28, "", "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity35 = new org.jfree.chart.entity.TickLabelEntity(shape28, "hi!", "RectangleConstraintType.RANGE");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke37 = defaultDrawingSupplier36.getNextOutlineStroke();
        java.awt.Color color38 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("", "ThreadContext", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "DatasetRenderingOrder.FORWARD", true, shape11, true, (java.awt.Paint) color14, true, (java.awt.Paint) color18, stroke26, false, shape28, stroke37, (java.awt.Paint) color38);
        boolean boolean40 = legendItem39.isShapeFilled();
        java.lang.String str41 = legendItem39.getLabel();
        legendItem39.setDatasetIndex((int) (short) 100);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        try {
            java.lang.Comparable comparable2 = defaultStatisticalCategoryDataset0.getRowKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.renderer.RendererState rendererState2 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = rendererState2.getInfo();
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = plotRenderingInfo3.getSubplotInfo((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(plotRenderingInfo3);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color4 = java.awt.Color.RED;
        categoryAxis3.setLabelPaint((java.awt.Paint) color4);
        int int6 = color4.getRed();
        int int7 = color4.getRed();
        paintList0.setPaint((int) (byte) 0, (java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 255 + "'", int6 == 255);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 255 + "'", int7 == 255);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 0, range1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = rectangleConstraint4.getHeightConstraintType();
        java.lang.String str6 = lengthConstraintType5.toString();
        java.lang.String str7 = lengthConstraintType5.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleConstraintType.RANGE" + "'", str6.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleConstraintType.RANGE" + "'", str7.equals("RectangleConstraintType.RANGE"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        org.jfree.data.Range range5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) 0, range5);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint8.toUnconstrainedWidth();
        boolean boolean10 = numberAxis1.equals((java.lang.Object) rectangleConstraint9);
        org.jfree.data.RangeType rangeType11 = numberAxis1.getRangeType();
        java.lang.String str12 = rangeType11.toString();
        java.lang.String str13 = rangeType11.toString();
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rangeType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "RangeType.FULL" + "'", str12.equals("RangeType.FULL"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RangeType.FULL" + "'", str13.equals("RangeType.FULL"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        org.jfree.chart.block.FlowArrangement flowArrangement1 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement1.clear();
        org.jfree.chart.LegendItemSource legendItemSource3 = null;
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle(legendItemSource3);
        org.jfree.chart.LegendItemSource legendItemSource5 = null;
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle(legendItemSource5);
        double double7 = legendTitle6.getHeight();
        flowArrangement1.add((org.jfree.chart.block.Block) legendTitle4, (java.lang.Object) double7);
        legendTitle4.setWidth((double) (byte) -1);
        legendTitle4.setNotify(true);
        java.awt.Shape shape13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity14 = new org.jfree.chart.entity.LegendItemEntity(shape13);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity17 = new org.jfree.chart.entity.TickLabelEntity(shape13, "", "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity20 = new org.jfree.chart.entity.TickLabelEntity(shape13, "hi!", "RectangleConstraintType.RANGE");
        flowArrangement0.add((org.jfree.chart.block.Block) legendTitle4, (java.lang.Object) "RectangleConstraintType.RANGE");
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color6 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("ThreadContext", font5, (java.awt.Paint) color6);
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font5);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!", font5);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.lang.Object obj13 = textTitle9.draw(graphics2D10, rectangle2D11, (java.lang.Object) (byte) 100);
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color16 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("ThreadContext", font15, (java.awt.Paint) color16);
        textTitle9.setFont(font15);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("RangeType.FULL", font15);
        java.lang.String str20 = textTitle19.getURLText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine();
        java.awt.Font font24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color25 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment26 = new org.jfree.chart.text.TextFragment("ThreadContext", font24, (java.awt.Paint) color25);
        textLine22.addFragment(textFragment26);
        boolean boolean28 = horizontalAlignment21.equals((java.lang.Object) textFragment26);
        textTitle19.setTextAlignment(horizontalAlignment21);
        java.awt.Font font34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color35 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment36 = new org.jfree.chart.text.TextFragment("ThreadContext", font34, (java.awt.Paint) color35);
        org.jfree.chart.text.TextLine textLine37 = new org.jfree.chart.text.TextLine("", font34);
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("hi!", font34);
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        java.lang.Object obj42 = textTitle38.draw(graphics2D39, rectangle2D40, (java.lang.Object) (byte) 100);
        java.awt.Font font44 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color45 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment46 = new org.jfree.chart.text.TextFragment("ThreadContext", font44, (java.awt.Paint) color45);
        textTitle38.setFont(font44);
        org.jfree.chart.block.LabelBlock labelBlock48 = new org.jfree.chart.block.LabelBlock("ThreadContext", font44);
        textTitle19.setFont(font44);
        java.awt.Paint paint50 = null;
        java.awt.Font font53 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double56 = categoryAxis55.getLabelAngle();
        categoryAxis55.setLowerMargin((double) 0);
        categoryAxis55.setUpperMargin(0.0d);
        java.lang.String str61 = categoryAxis55.getLabel();
        double double62 = categoryAxis55.getUpperMargin();
        org.jfree.chart.plot.ValueMarker valueMarker65 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke66 = valueMarker65.getOutlineStroke();
        java.awt.Paint paint67 = valueMarker65.getOutlinePaint();
        categoryAxis55.setTickLabelPaint((java.lang.Comparable) 10.0d, paint67);
        java.awt.Graphics2D graphics2D71 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer72 = new org.jfree.chart.text.G2TextMeasurer(graphics2D71);
        org.jfree.chart.text.TextBlock textBlock73 = org.jfree.chart.text.TextUtilities.createTextBlock("", font53, paint67, 0.0f, 4, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer72);
        org.jfree.chart.text.TextBlock textBlock74 = org.jfree.chart.text.TextUtilities.createTextBlock("", font44, paint50, (float) (short) 1, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer72);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNull(obj42);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "hi!" + "'", str61.equals("hi!"));
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNotNull(textBlock73);
        org.junit.Assert.assertNotNull(textBlock74);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Stroke stroke3 = defaultDrawingSupplier0.getNextStroke();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateX((double) 1L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        java.awt.Font font2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color3 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("ThreadContext", font2, (java.awt.Paint) color3);
        textLine0.addFragment(textFragment4);
        java.lang.String str6 = textFragment4.getText();
        java.lang.String str7 = textFragment4.getText();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ThreadContext" + "'", str6.equals("ThreadContext"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ThreadContext" + "'", str7.equals("ThreadContext"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = null;
        axisState0.moveCursor((double) 0, rectangleEdge2);
        axisState0.setCursor(0.05d);
        java.util.List list6 = axisState0.getTicks();
        axisState0.setCursor((double) 10.0f);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.add((java.lang.Number) 35.0d, (java.lang.Number) 100.0d, (java.lang.Comparable) (short) 100, (java.lang.Comparable) (short) 1);
        int int6 = defaultStatisticalCategoryDataset0.getColumnCount();
        java.lang.Number number9 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) 1L, (java.lang.Comparable) '#');
        defaultStatisticalCategoryDataset0.add(44.0d, (-1.0d), (java.lang.Comparable) (-1.0d), (java.lang.Comparable) 0.2d);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener15 = null;
        defaultStatisticalCategoryDataset0.addChangeListener(datasetChangeListener15);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNull(number9);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            legendTitle1.draw(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        java.awt.Stroke stroke4 = numberAxis1.getTickMarkStroke();
        numberAxis1.setUpperMargin((double) (-1));
        numberAxis1.resizeRange((double) 1);
        numberAxis1.centerRange((double) (byte) 100);
        numberAxis1.setNegativeArrowVisible(true);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("DatasetRenderingOrder.FORWARD");
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList((int) (byte) 0);
        boolean boolean3 = categoryLabelWidthType0.equals((java.lang.Object) (byte) 0);
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        java.awt.Shape shape2 = legendItemEntity1.getArea();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.clear();
        java.awt.Shape shape2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape2, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color9 = java.awt.Color.RED;
        categoryAxis8.setLabelPaint((java.awt.Paint) color9);
        float[] floatArray15 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray16 = color9.getRGBColorComponents(floatArray15);
        org.jfree.chart.title.LegendGraphic legendGraphic17 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color9);
        blockContainer0.add((org.jfree.chart.block.Block) legendGraphic17);
        java.awt.Shape shape19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape19, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color26 = java.awt.Color.RED;
        categoryAxis25.setLabelPaint((java.awt.Paint) color26);
        float[] floatArray32 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray33 = color26.getRGBColorComponents(floatArray32);
        org.jfree.chart.title.LegendGraphic legendGraphic34 = new org.jfree.chart.title.LegendGraphic(shape23, (java.awt.Paint) color26);
        legendGraphic17.setOutlinePaint((java.awt.Paint) color26);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double38 = categoryAxis37.getLabelAngle();
        categoryAxis37.setLowerMargin((double) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color43 = java.awt.Color.RED;
        categoryAxis42.setLabelPaint((java.awt.Paint) color43);
        categoryAxis42.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint47 = categoryAxis42.getTickLabelPaint();
        java.awt.Stroke stroke48 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder50 = new org.jfree.chart.block.LineBorder(paint47, stroke48, rectangleInsets49);
        categoryAxis37.setAxisLineStroke(stroke48);
        java.awt.Color color52 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryAxis37.setTickMarkPaint((java.awt.Paint) color52);
        legendGraphic17.setLinePaint((java.awt.Paint) color52);
        java.awt.Stroke stroke55 = legendGraphic17.getOutlineStroke();
        java.awt.Stroke stroke56 = legendGraphic17.getOutlineStroke();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNull(stroke55);
        org.junit.Assert.assertNull(stroke56);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        org.jfree.data.Range range5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) 0, range5);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint8.toUnconstrainedWidth();
        boolean boolean10 = numberAxis1.equals((java.lang.Object) rectangleConstraint9);
        org.jfree.data.RangeType rangeType11 = numberAxis1.getRangeType();
        java.lang.String str12 = numberAxis1.getLabelToolTip();
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rangeType11);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey((int) 'a');
        int int4 = keyedObjects0.getIndex((java.lang.Comparable) (byte) 0);
        java.lang.Comparable comparable6 = keyedObjects0.getKey((int) (byte) -1);
        java.lang.Object obj8 = null;
        keyedObjects0.setObject((java.lang.Comparable) "{0}", obj8);
        org.junit.Assert.assertNull(comparable2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(comparable6);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((-7.0d));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtBottom();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean4 = categoryLabelPosition2.equals((java.lang.Object) categoryLabelPosition3);
        java.lang.Class<?> wildcardClass5 = categoryLabelPosition2.getClass();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean8 = categoryLabelPosition6.equals((java.lang.Object) categoryLabelPosition7);
        java.lang.Class<?> wildcardClass9 = categoryLabelPosition6.getClass();
        java.lang.Object obj10 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", (java.lang.Class) wildcardClass5, (java.lang.Class) wildcardClass9);
        java.net.URL uRL11 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("[size=1]", (java.lang.Class) wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertNull(uRL11);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean3 = categoryLabelPosition1.equals((java.lang.Object) categoryLabelPosition2);
        java.lang.Class<?> wildcardClass4 = categoryLabelPosition1.getClass();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition5 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean7 = categoryLabelPosition5.equals((java.lang.Object) categoryLabelPosition6);
        java.lang.Class<?> wildcardClass8 = categoryLabelPosition5.getClass();
        java.lang.Object obj9 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", (java.lang.Class) wildcardClass4, (java.lang.Class) wildcardClass8);
        java.lang.ClassLoader classLoader10 = org.jfree.chart.util.ObjectUtilities.getClassLoader((java.lang.Class) wildcardClass8);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNotNull(classLoader10);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        categoryAxis1.setLowerMargin((double) 0);
        categoryAxis1.setUpperMargin(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double9 = rectangleInsets7.trimWidth((double) 1L);
        double double11 = rectangleInsets7.trimWidth((double) 1L);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder(rectangleInsets7, (java.awt.Paint) color12);
        boolean boolean14 = categoryAxis1.equals((java.lang.Object) rectangleInsets7);
        double double16 = rectangleInsets7.calculateRightInset(14.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-7.0d) + "'", double9 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-7.0d) + "'", double11 == (-7.0d));
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color4 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("ThreadContext", font3, (java.awt.Paint) color4);
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("", font3);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("hi!", font3);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.lang.Object obj11 = textTitle7.draw(graphics2D8, rectangle2D9, (java.lang.Object) (byte) 100);
        java.awt.Font font13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color14 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("ThreadContext", font13, (java.awt.Paint) color14);
        textTitle7.setFont(font13);
        org.jfree.chart.block.BlockFrame blockFrame17 = textTitle7.getFrame();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(blockFrame17);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        double[] doubleArray10 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray17 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray24 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray31 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray38 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray45 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray46 = new double[][] { doubleArray10, doubleArray17, doubleArray24, doubleArray31, doubleArray38, doubleArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset47, (int) (short) 0);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer51 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement0, (org.jfree.data.general.Dataset) pieDataset49, (java.lang.Comparable) "ThreadContext");
        java.lang.Object obj52 = legendItemBlockContainer51.clone();
        java.awt.Graphics2D graphics2D53 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint56 = new org.jfree.chart.block.RectangleConstraint((double) 8, (double) 2.0f);
        org.jfree.chart.util.Size2D size2D57 = legendItemBlockContainer51.arrange(graphics2D53, rectangleConstraint56);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertNotNull(size2D57);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color6 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("ThreadContext", font5, (java.awt.Paint) color6);
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font5);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!", font5);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.lang.Object obj13 = textTitle9.draw(graphics2D10, rectangle2D11, (java.lang.Object) (byte) 100);
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color16 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("ThreadContext", font15, (java.awt.Paint) color16);
        textTitle9.setFont(font15);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("RangeType.FULL", font15);
        java.lang.String str20 = textTitle19.getURLText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine();
        java.awt.Font font24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color25 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment26 = new org.jfree.chart.text.TextFragment("ThreadContext", font24, (java.awt.Paint) color25);
        textLine22.addFragment(textFragment26);
        boolean boolean28 = horizontalAlignment21.equals((java.lang.Object) textFragment26);
        textTitle19.setTextAlignment(horizontalAlignment21);
        java.awt.Font font34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color35 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment36 = new org.jfree.chart.text.TextFragment("ThreadContext", font34, (java.awt.Paint) color35);
        org.jfree.chart.text.TextLine textLine37 = new org.jfree.chart.text.TextLine("", font34);
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("hi!", font34);
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        java.lang.Object obj42 = textTitle38.draw(graphics2D39, rectangle2D40, (java.lang.Object) (byte) 100);
        java.awt.Font font44 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color45 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment46 = new org.jfree.chart.text.TextFragment("ThreadContext", font44, (java.awt.Paint) color45);
        textTitle38.setFont(font44);
        org.jfree.chart.block.LabelBlock labelBlock48 = new org.jfree.chart.block.LabelBlock("ThreadContext", font44);
        textTitle19.setFont(font44);
        org.jfree.chart.block.FlowArrangement flowArrangement50 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement50.clear();
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double54 = categoryAxis53.getLabelAngle();
        java.awt.Font font56 = categoryAxis53.getTickLabelFont((java.lang.Comparable) 10.0d);
        double double57 = categoryAxis53.getLabelAngle();
        java.awt.Shape shape58 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape62 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape58, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color65 = java.awt.Color.RED;
        categoryAxis64.setLabelPaint((java.awt.Paint) color65);
        float[] floatArray71 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray72 = color65.getRGBColorComponents(floatArray71);
        org.jfree.chart.title.LegendGraphic legendGraphic73 = new org.jfree.chart.title.LegendGraphic(shape62, (java.awt.Paint) color65);
        java.awt.Shape shape74 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape78 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape74, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis80 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color81 = java.awt.Color.RED;
        categoryAxis80.setLabelPaint((java.awt.Paint) color81);
        float[] floatArray87 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray88 = color81.getRGBColorComponents(floatArray87);
        org.jfree.chart.title.LegendGraphic legendGraphic89 = new org.jfree.chart.title.LegendGraphic(shape78, (java.awt.Paint) color81);
        legendGraphic73.setLinePaint((java.awt.Paint) color81);
        boolean boolean91 = categoryAxis53.equals((java.lang.Object) legendGraphic73);
        java.awt.Stroke stroke92 = null;
        legendGraphic73.setOutlineStroke(stroke92);
        java.awt.Color color94 = java.awt.Color.black;
        flowArrangement50.add((org.jfree.chart.block.Block) legendGraphic73, (java.lang.Object) color94);
        org.jfree.chart.text.TextLine textLine96 = new org.jfree.chart.text.TextLine("RangeType.FULL", font44, (java.awt.Paint) color94);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNull(obj42);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertNotNull(shape62);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(floatArray71);
        org.junit.Assert.assertNotNull(floatArray72);
        org.junit.Assert.assertNotNull(shape74);
        org.junit.Assert.assertNotNull(shape78);
        org.junit.Assert.assertNotNull(color81);
        org.junit.Assert.assertNotNull(floatArray87);
        org.junit.Assert.assertNotNull(floatArray88);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(color94);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 100, (float) ' ');
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list1 = projectInfo0.getContributors();
        java.lang.String str2 = projectInfo0.getLicenceText();
        java.lang.String str3 = projectInfo0.getCopyright();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleConstraintType.RANGE" + "'", str2.equals("RectangleConstraintType.RANGE"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "LGPL" + "'", str3.equals("LGPL"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color4 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("ThreadContext", font3, (java.awt.Paint) color4);
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("", font3);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("hi!", font3);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.lang.Object obj11 = textTitle7.draw(graphics2D8, rectangle2D9, (java.lang.Object) (byte) 100);
        java.awt.Font font13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color14 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("ThreadContext", font13, (java.awt.Paint) color14);
        textTitle7.setFont(font13);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.data.Range range18 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint(range18, (double) 255);
        try {
            org.jfree.chart.util.Size2D size2D21 = textTitle7.arrange(graphics2D17, rectangleConstraint20);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        numberAxis1.setTickMarkInsideLength((float) 100L);
        boolean boolean6 = numberAxis1.isPositiveArrowVisible();
        java.awt.Paint paint7 = numberAxis1.getTickLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.jfree.chart.LegendItemSource legendItemSource1 = null;
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle(legendItemSource1);
        boolean boolean3 = itemLabelAnchor0.equals((java.lang.Object) legendTitle2);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement8 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment4, verticalAlignment5, (double) 255, (double) 1.0f);
        org.jfree.chart.block.BlockContainer blockContainer9 = new org.jfree.chart.block.BlockContainer();
        blockContainer9.clear();
        java.awt.Shape shape11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape11, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color18 = java.awt.Color.RED;
        categoryAxis17.setLabelPaint((java.awt.Paint) color18);
        float[] floatArray24 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray25 = color18.getRGBColorComponents(floatArray24);
        org.jfree.chart.title.LegendGraphic legendGraphic26 = new org.jfree.chart.title.LegendGraphic(shape15, (java.awt.Paint) color18);
        blockContainer9.add((org.jfree.chart.block.Block) legendGraphic26);
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke30 = valueMarker29.getOutlineStroke();
        java.awt.Paint paint31 = valueMarker29.getOutlinePaint();
        legendGraphic26.setLinePaint(paint31);
        org.jfree.chart.axis.AxisSpace axisSpace33 = new org.jfree.chart.axis.AxisSpace();
        axisSpace33.setBottom((double) '#');
        java.lang.String str36 = axisSpace33.toString();
        double double37 = axisSpace33.getBottom();
        double double38 = axisSpace33.getBottom();
        columnArrangement8.add((org.jfree.chart.block.Block) legendGraphic26, (java.lang.Object) double38);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = legendGraphic26.getShapeAnchor();
        legendTitle2.setLegendItemGraphicLocation(rectangleAnchor40);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 35.0d + "'", double37 == 35.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 35.0d + "'", double38 == 35.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean3 = categoryLabelPosition1.equals((java.lang.Object) categoryLabelPosition2);
        java.lang.Class<?> wildcardClass4 = categoryLabelPosition1.getClass();
        java.net.URL uRL5 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", (java.lang.Class) wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNull(uRL5);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double4 = categoryAxis3.getLabelAngle();
        java.awt.Font font6 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 10.0d);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("-3,-3,3,3", font6);
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("ThreadContext", font6);
        boolean boolean10 = labelBlock8.equals((java.lang.Object) 1.0E-8d);
        java.lang.String str11 = labelBlock8.getURLText();
        java.lang.Object obj12 = labelBlock8.clone();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = null;
        numberAxis6.setMarkerBand(markerAxisBand7);
        java.awt.Stroke stroke9 = numberAxis6.getTickMarkStroke();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis6.setUpArrow(shape11);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color18 = java.awt.Color.RED;
        categoryAxis17.setLabelPaint((java.awt.Paint) color18);
        float[] floatArray24 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray25 = color18.getRGBColorComponents(floatArray24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape28);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity32 = new org.jfree.chart.entity.TickLabelEntity(shape28, "", "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity35 = new org.jfree.chart.entity.TickLabelEntity(shape28, "hi!", "RectangleConstraintType.RANGE");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke37 = defaultDrawingSupplier36.getNextOutlineStroke();
        java.awt.Color color38 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("", "ThreadContext", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "DatasetRenderingOrder.FORWARD", true, shape11, true, (java.awt.Paint) color14, true, (java.awt.Paint) color18, stroke26, false, shape28, stroke37, (java.awt.Paint) color38);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer40 = legendItem39.getFillPaintTransformer();
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(gradientPaintTransformer40);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double4 = categoryAxis3.getLabelAngle();
        java.awt.Font font6 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 10.0d);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("-3,-3,3,3", font6);
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("ThreadContext", font6);
        java.awt.Paint paint9 = labelBlock8.getPaint();
        java.lang.Object obj10 = labelBlock8.clone();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Enumeration<java.lang.String> strEnumeration1 = jFreeChartResources0.getKeys();
        boolean boolean3 = jFreeChartResources0.containsKey("[size=10]");
        org.junit.Assert.assertNotNull(strEnumeration1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtTop();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.awt.Paint paint1 = null;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke4 = valueMarker3.getOutlineStroke();
        java.awt.Paint paint5 = valueMarker3.getOutlinePaint();
        java.awt.Paint paint6 = valueMarker3.getLabelPaint();
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = valueMarker8.getLabelOffsetType();
        java.lang.String str10 = lengthAdjustmentType9.toString();
        valueMarker3.setLabelOffsetType(lengthAdjustmentType9);
        java.awt.Stroke stroke12 = valueMarker3.getStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker(97.0d, paint1, stroke12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(lengthAdjustmentType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "CONTRACT" + "'", str10.equals("CONTRACT"));
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1);
        boolean boolean4 = textBlockAnchor1.equals((java.lang.Object) 4);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = null;
        numberAxis7.setMarkerBand(markerAxisBand8);
        java.awt.Stroke stroke10 = numberAxis7.getTickMarkStroke();
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis7.setUpArrow(shape12);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color19 = java.awt.Color.RED;
        categoryAxis18.setLabelPaint((java.awt.Paint) color19);
        float[] floatArray25 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray26 = color19.getRGBColorComponents(floatArray25);
        java.awt.Stroke stroke27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity30 = new org.jfree.chart.entity.LegendItemEntity(shape29);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity33 = new org.jfree.chart.entity.TickLabelEntity(shape29, "", "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity36 = new org.jfree.chart.entity.TickLabelEntity(shape29, "hi!", "RectangleConstraintType.RANGE");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier37 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke38 = defaultDrawingSupplier37.getNextOutlineStroke();
        java.awt.Color color39 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("", "ThreadContext", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "DatasetRenderingOrder.FORWARD", true, shape12, true, (java.awt.Paint) color15, true, (java.awt.Paint) color19, stroke27, false, shape29, stroke38, (java.awt.Paint) color39);
        boolean boolean41 = legendItem40.isShapeFilled();
        java.lang.String str42 = legendItem40.getLabel();
        boolean boolean43 = color0.equals((java.lang.Object) legendItem40);
        java.lang.String str44 = legendItem40.getDescription();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "ThreadContext" + "'", str44.equals("ThreadContext"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        java.awt.Stroke stroke4 = numberAxis1.getTickMarkStroke();
        numberAxis1.setUpperMargin((double) (-1));
        boolean boolean7 = numberAxis1.isPositiveArrowVisible();
        java.text.NumberFormat numberFormat8 = null;
        numberAxis1.setNumberFormatOverride(numberFormat8);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition4, true);
        double double7 = statisticalBarRenderer0.getBase();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        try {
            statisticalBarRenderer0.setPlot(categoryPlot8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color7 = java.awt.Color.RED;
        categoryAxis6.setLabelPaint((java.awt.Paint) color7);
        float[] floatArray13 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray14 = color7.getRGBColorComponents(floatArray13);
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape4, (java.awt.Paint) color7);
        legendGraphic15.setShapeOutlineVisible(false);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double3 = categoryAxis2.getLabelAngle();
        java.awt.Font font5 = categoryAxis2.getTickLabelFont((java.lang.Comparable) 10.0d);
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("-3,-3,3,3", font5);
        textTitle6.setNotify(false);
        java.awt.Font font13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color14 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("ThreadContext", font13, (java.awt.Paint) color14);
        org.jfree.chart.text.TextLine textLine16 = new org.jfree.chart.text.TextLine("", font13);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("hi!", font13);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.lang.Object obj21 = textTitle17.draw(graphics2D18, rectangle2D19, (java.lang.Object) (byte) 100);
        java.awt.Font font23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color24 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment25 = new org.jfree.chart.text.TextFragment("ThreadContext", font23, (java.awt.Paint) color24);
        textTitle17.setFont(font23);
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle("RangeType.FULL", font23);
        java.lang.String str28 = textTitle27.getURLText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.text.TextLine textLine30 = new org.jfree.chart.text.TextLine();
        java.awt.Font font32 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color33 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment34 = new org.jfree.chart.text.TextFragment("ThreadContext", font32, (java.awt.Paint) color33);
        textLine30.addFragment(textFragment34);
        boolean boolean36 = horizontalAlignment29.equals((java.lang.Object) textFragment34);
        textTitle27.setTextAlignment(horizontalAlignment29);
        textTitle6.setTextAlignment(horizontalAlignment29);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(obj21);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) ' ', 1, 100);
        float[] floatArray10 = new float[] { 100, 'a', 4, 100L, 2.0f, '#' };
        float[] floatArray11 = chartColor3.getColorComponents(floatArray10);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.add((java.lang.Number) 35.0d, (java.lang.Number) 100.0d, (java.lang.Comparable) (short) 100, (java.lang.Comparable) (short) 1);
        try {
            java.lang.Comparable comparable7 = defaultStatisticalCategoryDataset0.getRowKey(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.NEGATIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.FORWARD");
        java.lang.Object obj2 = categoryAxis1.clone();
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        categoryAxis1.addChangeListener(axisChangeListener3);
        org.jfree.chart.plot.Plot plot5 = null;
        categoryAxis1.setPlot(plot5);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Paint paint3 = defaultDrawingSupplier0.getNextPaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        double[] doubleArray10 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray17 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray24 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray31 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray38 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray45 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray46 = new double[][] { doubleArray10, doubleArray17, doubleArray24, doubleArray31, doubleArray38, doubleArray45 };
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset47, (int) (short) 0);
        legendItemEntity1.setDataset((org.jfree.data.general.Dataset) pieDataset49);
        legendItemEntity1.setSeriesKey((java.lang.Comparable) 100L);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNotNull(pieDataset49);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("[size=10]");
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = null;
        numberAxis6.setMarkerBand(markerAxisBand7);
        java.awt.Stroke stroke9 = numberAxis6.getTickMarkStroke();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis6.setUpArrow(shape11);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color18 = java.awt.Color.RED;
        categoryAxis17.setLabelPaint((java.awt.Paint) color18);
        float[] floatArray24 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray25 = color18.getRGBColorComponents(floatArray24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape28);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity32 = new org.jfree.chart.entity.TickLabelEntity(shape28, "", "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity35 = new org.jfree.chart.entity.TickLabelEntity(shape28, "hi!", "RectangleConstraintType.RANGE");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke37 = defaultDrawingSupplier36.getNextOutlineStroke();
        java.awt.Color color38 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("", "ThreadContext", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "DatasetRenderingOrder.FORWARD", true, shape11, true, (java.awt.Paint) color14, true, (java.awt.Paint) color18, stroke26, false, shape28, stroke37, (java.awt.Paint) color38);
        java.awt.Paint paint40 = legendItem39.getOutlinePaint();
        java.awt.Paint paint41 = legendItem39.getFillPaint();
        java.lang.String str42 = legendItem39.getLabel();
        java.lang.String str43 = legendItem39.getToolTipText();
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str43.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number3 = defaultStatisticalCategoryDataset0.getStdDevValue((java.lang.Comparable) "VerticalAlignment.CENTER", (java.lang.Comparable) (short) 10);
        int int5 = defaultStatisticalCategoryDataset0.getRowIndex((java.lang.Comparable) 100);
        defaultStatisticalCategoryDataset0.add((double) 100.0f, (double) 4, (java.lang.Comparable) (-1), (java.lang.Comparable) 2);
        java.util.EventListener eventListener11 = null;
        boolean boolean12 = defaultStatisticalCategoryDataset0.hasListener(eventListener11);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        legendItemEntity1.setToolTipText("[size=1]");
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = plotRenderingInfo1.getOwner();
        org.junit.Assert.assertNull(chartRenderingInfo2);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        java.awt.Font font4 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 10.0d);
        double double5 = categoryAxis1.getLabelAngle();
        java.awt.Shape shape6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color13 = java.awt.Color.RED;
        categoryAxis12.setLabelPaint((java.awt.Paint) color13);
        float[] floatArray19 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray20 = color13.getRGBColorComponents(floatArray19);
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape10, (java.awt.Paint) color13);
        java.awt.Shape shape22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape22, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color29 = java.awt.Color.RED;
        categoryAxis28.setLabelPaint((java.awt.Paint) color29);
        float[] floatArray35 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray36 = color29.getRGBColorComponents(floatArray35);
        org.jfree.chart.title.LegendGraphic legendGraphic37 = new org.jfree.chart.title.LegendGraphic(shape26, (java.awt.Paint) color29);
        legendGraphic21.setLinePaint((java.awt.Paint) color29);
        boolean boolean39 = categoryAxis1.equals((java.lang.Object) legendGraphic21);
        java.awt.Stroke stroke40 = null;
        legendGraphic21.setOutlineStroke(stroke40);
        double double42 = legendGraphic21.getContentXOffset();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 2.0d + "'", double42 == 2.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition4, true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke8 = defaultDrawingSupplier7.getNextOutlineStroke();
        java.awt.Stroke stroke9 = defaultDrawingSupplier7.getNextStroke();
        statisticalBarRenderer0.setErrorIndicatorStroke(stroke9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = statisticalBarRenderer0.getNegativeItemLabelPositionFallback();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = statisticalBarRenderer12.getNegativeItemLabelPosition((int) (byte) 0, (int) (byte) -1);
        statisticalBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo21);
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState23 = statisticalBarRenderer0.initialise(graphics2D17, rectangle2D18, categoryPlot19, (int) (short) 10, plotRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color5 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("ThreadContext", font4, (java.awt.Paint) color5);
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font4);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!", font4);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.lang.Object obj12 = textTitle8.draw(graphics2D9, rectangle2D10, (java.lang.Object) (byte) 100);
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color15 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("ThreadContext", font14, (java.awt.Paint) color15);
        textTitle8.setFont(font14);
        org.jfree.chart.block.LabelBlock labelBlock18 = new org.jfree.chart.block.LabelBlock("ThreadContext", font14);
        boolean boolean20 = labelBlock18.equals((java.lang.Object) 9.0d);
        labelBlock18.setURLText("LGPL");
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand30 = null;
        numberAxis29.setMarkerBand(markerAxisBand30);
        java.awt.Stroke stroke32 = numberAxis29.getTickMarkStroke();
        java.awt.Shape shape34 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis29.setUpArrow(shape34);
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color41 = java.awt.Color.RED;
        categoryAxis40.setLabelPaint((java.awt.Paint) color41);
        float[] floatArray47 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray48 = color41.getRGBColorComponents(floatArray47);
        java.awt.Stroke stroke49 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape51 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity52 = new org.jfree.chart.entity.LegendItemEntity(shape51);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity55 = new org.jfree.chart.entity.TickLabelEntity(shape51, "", "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity58 = new org.jfree.chart.entity.TickLabelEntity(shape51, "hi!", "RectangleConstraintType.RANGE");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier59 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke60 = defaultDrawingSupplier59.getNextOutlineStroke();
        java.awt.Color color61 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem62 = new org.jfree.chart.LegendItem("", "ThreadContext", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "DatasetRenderingOrder.FORWARD", true, shape34, true, (java.awt.Paint) color37, true, (java.awt.Paint) color41, stroke49, false, shape51, stroke60, (java.awt.Paint) color61);
        java.awt.Paint paint63 = legendItem62.getOutlinePaint();
        java.awt.Paint paint64 = legendItem62.getFillPaint();
        labelBlock18.setPaint(paint64);
        java.awt.Paint paint66 = labelBlock18.getPaint();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(paint66);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = defaultStatisticalCategoryDataset0.getRangeBounds(false);
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.data.general.DatasetChangeListener datasetChangeListener4 = null;
        defaultStatisticalCategoryDataset0.removeChangeListener(datasetChangeListener4);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener6 = null;
        defaultStatisticalCategoryDataset0.removeChangeListener(datasetChangeListener6);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener8 = null;
        defaultStatisticalCategoryDataset0.removeChangeListener(datasetChangeListener8);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("{0}");
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle(legendItemSource0);
        double double2 = legendTitle1.getHeight();
        org.jfree.chart.block.BlockContainer blockContainer3 = null;
        legendTitle1.setWrapper(blockContainer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double7 = rectangleInsets5.trimWidth((double) 1L);
        double double8 = rectangleInsets5.getBottom();
        double double10 = rectangleInsets5.calculateRightOutset((double) 0L);
        double double12 = rectangleInsets5.extendHeight((double) 10.0f);
        legendTitle1.setItemLabelPadding(rectangleInsets5);
        double double15 = rectangleInsets5.calculateTopOutset((double) 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-7.0d) + "'", double7 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.0d + "'", double12 == 14.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity4 = new org.jfree.chart.entity.TickLabelEntity(shape0, "", "");
        java.lang.String str5 = tickLabelEntity4.getToolTipText();
        java.lang.String str6 = tickLabelEntity4.getToolTipText();
        java.lang.String str7 = tickLabelEntity4.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ChartEntity: tooltip = " + "'", str7.equals("ChartEntity: tooltip = "));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        org.jfree.data.Range range5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) 0, range5);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint8.toUnconstrainedWidth();
        boolean boolean10 = numberAxis1.equals((java.lang.Object) rectangleConstraint9);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = numberAxis1.getMarkerBand();
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(markerAxisBand11);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        boolean boolean4 = numberAxis1.getAutoRangeIncludesZero();
        java.awt.Shape shape5 = numberAxis1.getRightArrow();
        numberAxis1.setLowerMargin(100.0d);
        double double8 = numberAxis1.getUpperMargin();
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = numberAxis1.getStandardTickUnits();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(tickUnitSource9);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke2 = valueMarker1.getOutlineStroke();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        valueMarker1.setLabelOffsetType(lengthAdjustmentType3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double7 = rectangleInsets5.trimWidth((double) 1L);
        valueMarker1.setLabelOffset(rectangleInsets5);
        java.lang.String str9 = valueMarker1.getLabel();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-7.0d) + "'", double7 == (-7.0d));
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String str2 = jFreeChartResources0.getString("RectangleConstraintType.RANGE");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key RectangleConstraintType.RANGE");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        double[] doubleArray12 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray19 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray26 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray33 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray40 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray47 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray48 = new double[][] { doubleArray12, doubleArray19, doubleArray26, doubleArray33, doubleArray40, doubleArray47 };
        org.jfree.data.category.CategoryDataset categoryDataset49 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray48);
        org.jfree.data.general.PieDataset pieDataset51 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset49, (int) (short) 0);
        org.jfree.data.Range range52 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset49);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset53 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number56 = defaultStatisticalCategoryDataset53.getStdDevValue((java.lang.Comparable) "VerticalAlignment.CENTER", (java.lang.Comparable) (short) 10);
        int int58 = defaultStatisticalCategoryDataset53.getRowIndex((java.lang.Comparable) 100);
        defaultStatisticalCategoryDataset53.add((double) 100.0f, (double) 4, (java.lang.Comparable) (-1), (java.lang.Comparable) 2);
        org.jfree.data.Range range65 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset53, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint66 = new org.jfree.chart.block.RectangleConstraint(range52, range65);
        numberAxis1.setRangeWithMargins(range65);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(categoryDataset49);
        org.junit.Assert.assertNotNull(pieDataset51);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertNull(number56);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertNotNull(range65);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        categoryAxis1.setLowerMargin((double) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color7 = java.awt.Color.RED;
        categoryAxis6.setLabelPaint((java.awt.Paint) color7);
        categoryAxis6.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint11 = categoryAxis6.getTickLabelPaint();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder(paint11, stroke12, rectangleInsets13);
        categoryAxis1.setAxisLineStroke(stroke12);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color16);
        categoryAxis1.setTickMarksVisible(false);
        java.awt.Font font20 = categoryAxis1.getTickLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double23 = rectangleInsets21.trimWidth((double) 1L);
        double double25 = rectangleInsets21.trimWidth((double) 1L);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.block.BlockBorder blockBorder27 = new org.jfree.chart.block.BlockBorder(rectangleInsets21, (java.awt.Paint) color26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = blockBorder27.getInsets();
        double double30 = rectangleInsets28.calculateTopInset((double) (short) -1);
        categoryAxis1.setLabelInsets(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-7.0d) + "'", double23 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + (-7.0d) + "'", double25 == (-7.0d));
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.0d + "'", double30 == 2.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Paint paint2 = statisticalBarRenderer0.getSeriesFillPaint(8);
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color2 = java.awt.Color.MAGENTA;
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color2);
        java.lang.String str4 = categoryAxis1.getLabelURL();
        double double5 = categoryAxis1.getFixedDimension();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color2 = java.awt.Color.RED;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        categoryAxis1.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint6 = categoryAxis1.getTickLabelPaint();
        java.awt.Stroke stroke7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder9 = new org.jfree.chart.block.LineBorder(paint6, stroke7, rectangleInsets8);
        java.awt.Paint paint10 = lineBorder9.getPaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.lang.String str1 = verticalAlignment0.toString();
        org.jfree.chart.block.FlowArrangement flowArrangement2 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement2.clear();
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        org.jfree.chart.LegendItemSource legendItemSource6 = null;
        org.jfree.chart.title.LegendTitle legendTitle7 = new org.jfree.chart.title.LegendTitle(legendItemSource6);
        double double8 = legendTitle7.getHeight();
        flowArrangement2.add((org.jfree.chart.block.Block) legendTitle5, (java.lang.Object) double8);
        legendTitle5.setWidth((double) (byte) -1);
        java.awt.Paint paint12 = legendTitle5.getItemPaint();
        boolean boolean13 = verticalAlignment0.equals((java.lang.Object) paint12);
        java.lang.String str14 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.CENTER" + "'", str1.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "VerticalAlignment.CENTER" + "'", str14.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 255, (double) 1.0f);
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement5.clear();
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray50 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray51 = new double[][] { doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43, doubleArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray51);
        org.jfree.data.general.PieDataset pieDataset54 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset52, (int) (short) 0);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer56 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement5, (org.jfree.data.general.Dataset) pieDataset54, (java.lang.Comparable) "ThreadContext");
        org.jfree.chart.block.BlockFrame blockFrame57 = legendItemBlockContainer56.getFrame();
        java.awt.Color color58 = java.awt.Color.BLACK;
        columnArrangement4.add((org.jfree.chart.block.Block) legendItemBlockContainer56, (java.lang.Object) color58);
        legendItemBlockContainer56.clear();
        legendItemBlockContainer56.clear();
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(pieDataset54);
        org.junit.Assert.assertNotNull(blockFrame57);
        org.junit.Assert.assertNotNull(color58);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, 2.0d, (double) 0, 100, (java.lang.Comparable) "RectangleConstraintType.RANGE");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) 1L);
        double double3 = rectangleInsets0.getBottom();
        double double5 = rectangleInsets0.calculateLeftOutset(0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.0d) + "'", double2 == (-7.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 255, (double) 1.0f);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer();
        blockContainer5.clear();
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape7, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color14 = java.awt.Color.RED;
        categoryAxis13.setLabelPaint((java.awt.Paint) color14);
        float[] floatArray20 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray21 = color14.getRGBColorComponents(floatArray20);
        org.jfree.chart.title.LegendGraphic legendGraphic22 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color14);
        blockContainer5.add((org.jfree.chart.block.Block) legendGraphic22);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke26 = valueMarker25.getOutlineStroke();
        java.awt.Paint paint27 = valueMarker25.getOutlinePaint();
        legendGraphic22.setLinePaint(paint27);
        org.jfree.chart.axis.AxisSpace axisSpace29 = new org.jfree.chart.axis.AxisSpace();
        axisSpace29.setBottom((double) '#');
        java.lang.String str32 = axisSpace29.toString();
        double double33 = axisSpace29.getBottom();
        double double34 = axisSpace29.getBottom();
        columnArrangement4.add((org.jfree.chart.block.Block) legendGraphic22, (java.lang.Object) double34);
        double[] doubleArray44 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray51 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray58 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray65 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray72 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray79 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray80 = new double[][] { doubleArray44, doubleArray51, doubleArray58, doubleArray65, doubleArray72, doubleArray79 };
        org.jfree.data.category.CategoryDataset categoryDataset81 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray80);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer83 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4, (org.jfree.data.general.Dataset) categoryDataset81, (java.lang.Comparable) 32.0d);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 35.0d + "'", double33 == 35.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 35.0d + "'", double34 == 35.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(categoryDataset81);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        double double6 = legendTitle5.getHeight();
        flowArrangement0.add((org.jfree.chart.block.Block) legendTitle3, (java.lang.Object) double6);
        java.lang.String str8 = legendTitle3.getID();
        org.jfree.chart.axis.AxisSpace axisSpace9 = new org.jfree.chart.axis.AxisSpace();
        axisSpace9.setBottom((double) '#');
        double double12 = axisSpace9.getLeft();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.lang.Object obj15 = null;
        boolean boolean16 = rectangleEdge14.equals(obj15);
        axisSpace9.add((double) (-1.0f), rectangleEdge14);
        legendTitle3.setLegendItemGraphicEdge(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color2 = java.awt.Color.RED;
        categoryAxis1.setLabelPaint((java.awt.Paint) color2);
        float[] floatArray8 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray9 = color2.getRGBColorComponents(floatArray8);
        org.jfree.chart.JFreeChart jFreeChart10 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent13 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) color2, jFreeChart10, (int) (byte) 100, (int) (byte) 100);
        java.lang.Object obj14 = chartProgressEvent13.getSource();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition4, true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke8 = defaultDrawingSupplier7.getNextOutlineStroke();
        java.awt.Stroke stroke9 = defaultDrawingSupplier7.getNextStroke();
        statisticalBarRenderer0.setErrorIndicatorStroke(stroke9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.setForegroundAlpha((float) (-1));
        int int15 = categoryPlot12.getWeight();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        java.util.List list17 = categoryPlot12.getCategoriesForAxis(categoryAxis16);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        try {
            statisticalBarRenderer0.drawDomainGridline(graphics2D11, categoryPlot12, rectangle2D18, 0.05d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.chart.util.PaintList paintList1 = new org.jfree.chart.util.PaintList();
        int int2 = paintList1.size();
        java.lang.Object obj3 = paintList1.clone();
        boolean boolean4 = paintList0.equals(obj3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset45);
        java.lang.Number number49 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset45);
        boolean boolean50 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset45);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + (-1.0d) + "'", number49.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) 2.0f, numberFormat1, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = null;
        numberAxis6.setMarkerBand(markerAxisBand7);
        java.awt.Stroke stroke9 = numberAxis6.getTickMarkStroke();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis6.setUpArrow(shape11);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color18 = java.awt.Color.RED;
        categoryAxis17.setLabelPaint((java.awt.Paint) color18);
        float[] floatArray24 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray25 = color18.getRGBColorComponents(floatArray24);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Shape shape28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape28);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity32 = new org.jfree.chart.entity.TickLabelEntity(shape28, "", "");
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity35 = new org.jfree.chart.entity.TickLabelEntity(shape28, "hi!", "RectangleConstraintType.RANGE");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke37 = defaultDrawingSupplier36.getNextOutlineStroke();
        java.awt.Color color38 = java.awt.Color.GREEN;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("", "ThreadContext", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", "DatasetRenderingOrder.FORWARD", true, shape11, true, (java.awt.Paint) color14, true, (java.awt.Paint) color18, stroke26, false, shape28, stroke37, (java.awt.Paint) color38);
        java.awt.Paint paint40 = legendItem39.getOutlinePaint();
        java.awt.Paint paint41 = legendItem39.getFillPaint();
        java.lang.String str42 = legendItem39.getLabel();
        java.lang.String str43 = legendItem39.getURLText();
        java.lang.String str44 = legendItem39.getLabel();
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str43.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.lang.Number number0 = null;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean5 = categoryLabelPosition3.equals((java.lang.Object) categoryLabelPosition4);
        org.jfree.chart.text.TextAnchor textAnchor6 = categoryLabelPosition4.getRotationAnchor();
        try {
            org.jfree.chart.axis.NumberTick numberTick8 = new org.jfree.chart.axis.NumberTick(number0, "HorizontalAlignment.RIGHT", textAnchor2, textAnchor6, 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(textAnchor6);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setLabelToolTip("DatasetRenderingOrder.FORWARD");
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color5 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("ThreadContext", font4, (java.awt.Paint) color5);
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font4);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!", font4);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.lang.Object obj12 = textTitle8.draw(graphics2D9, rectangle2D10, (java.lang.Object) (byte) 100);
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color15 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("ThreadContext", font14, (java.awt.Paint) color15);
        textTitle8.setFont(font14);
        org.jfree.chart.block.LabelBlock labelBlock18 = new org.jfree.chart.block.LabelBlock("ThreadContext", font14);
        java.awt.Font font19 = labelBlock18.getFont();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        defaultStatisticalCategoryDataset0.add((java.lang.Number) 35.0d, (java.lang.Number) 100.0d, (java.lang.Comparable) (short) 100, (java.lang.Comparable) (short) 1);
        int int6 = defaultStatisticalCategoryDataset0.getColumnCount();
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.chart.LegendItemSource legendItemSource9 = null;
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle(legendItemSource9);
        double double11 = legendTitle10.getWidth();
        legendTitle10.setHeight((double) (byte) 10);
        java.awt.Font font14 = legendTitle10.getItemFont();
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("", font14);
        boolean boolean16 = defaultStatisticalCategoryDataset0.equals((java.lang.Object) "");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 35.0d + "'", number7.equals(35.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        org.jfree.data.Range range5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) 0, range5);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toFixedWidth((double) (byte) 1);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint8.toUnconstrainedWidth();
        boolean boolean10 = numberAxis1.equals((java.lang.Object) rectangleConstraint9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand13 = null;
        numberAxis12.setMarkerBand(markerAxisBand13);
        java.awt.Stroke stroke15 = numberAxis12.getTickMarkStroke();
        java.awt.Shape shape17 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis12.setUpArrow(shape17);
        numberAxis1.setUpArrow(shape17);
        boolean boolean20 = numberAxis1.isNegativeArrowVisible();
        java.awt.Shape shape21 = numberAxis1.getRightArrow();
        numberAxis1.setAutoTickUnitSelection(false, true);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean3 = categoryLabelPosition1.equals((java.lang.Object) categoryLabelPosition2);
        boolean boolean4 = datasetGroup0.equals((java.lang.Object) categoryLabelPosition1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        numberAxis1.setTickMarkInsideLength((float) 100L);
        boolean boolean6 = numberAxis1.isPositiveArrowVisible();
        try {
            numberAxis1.setRangeAboutValue((double) (short) 10, (double) (-2));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (11.0) <= upper (9.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color3 = java.awt.Color.MAGENTA;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color3);
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 35.0d, (java.awt.Paint) color3);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double3 = categoryAxis2.getLabelAngle();
        java.awt.Font font5 = categoryAxis2.getTickLabelFont((java.lang.Comparable) 10.0d);
        double double6 = categoryAxis2.getLabelAngle();
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape7, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color14 = java.awt.Color.RED;
        categoryAxis13.setLabelPaint((java.awt.Paint) color14);
        float[] floatArray20 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray21 = color14.getRGBColorComponents(floatArray20);
        org.jfree.chart.title.LegendGraphic legendGraphic22 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color14);
        java.awt.Shape shape23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape23, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color30 = java.awt.Color.RED;
        categoryAxis29.setLabelPaint((java.awt.Paint) color30);
        float[] floatArray36 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray37 = color30.getRGBColorComponents(floatArray36);
        org.jfree.chart.title.LegendGraphic legendGraphic38 = new org.jfree.chart.title.LegendGraphic(shape27, (java.awt.Paint) color30);
        legendGraphic22.setLinePaint((java.awt.Paint) color30);
        boolean boolean40 = categoryAxis2.equals((java.lang.Object) legendGraphic22);
        java.awt.Stroke stroke41 = null;
        legendGraphic22.setOutlineStroke(stroke41);
        org.jfree.data.KeyedObject keyedObject43 = new org.jfree.data.KeyedObject((java.lang.Comparable) 1, (java.lang.Object) legendGraphic22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = legendGraphic22.getShapeAnchor();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (short) 10, (double) 'a', (double) (short) -1, (double) 0);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            blockBorder4.draw(graphics2D5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number3 = defaultStatisticalCategoryDataset0.getStdDevValue((java.lang.Comparable) "VerticalAlignment.CENTER", (java.lang.Comparable) (short) 10);
        int int5 = defaultStatisticalCategoryDataset0.getRowIndex((java.lang.Comparable) 100);
        defaultStatisticalCategoryDataset0.add((double) 100.0f, (double) 4, (java.lang.Comparable) (-1), (java.lang.Comparable) 2);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(range11);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color7 = java.awt.Color.RED;
        categoryAxis6.setLabelPaint((java.awt.Paint) color7);
        float[] floatArray13 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray14 = color7.getRGBColorComponents(floatArray13);
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape4, (java.awt.Paint) color7);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        legendGraphic15.setFillPaint((java.awt.Paint) color16);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand20 = null;
        numberAxis19.setMarkerBand(markerAxisBand20);
        java.awt.Stroke stroke22 = numberAxis19.getTickMarkStroke();
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (short) -1);
        numberAxis19.setUpArrow(shape24);
        java.awt.Shape shape28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape24, (double) (byte) 10, 1.0E-8d);
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape28, 2.0d, (float) 2, (float) 100L);
        legendGraphic15.setLine(shape28);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(shape32);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color7 = java.awt.Color.RED;
        categoryAxis6.setLabelPaint((java.awt.Paint) color7);
        float[] floatArray13 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray14 = color7.getRGBColorComponents(floatArray13);
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape4, (java.awt.Paint) color7);
        java.awt.Shape shape16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape20 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape16, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color23 = java.awt.Color.RED;
        categoryAxis22.setLabelPaint((java.awt.Paint) color23);
        float[] floatArray29 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray30 = color23.getRGBColorComponents(floatArray29);
        org.jfree.chart.title.LegendGraphic legendGraphic31 = new org.jfree.chart.title.LegendGraphic(shape20, (java.awt.Paint) color23);
        legendGraphic15.setLinePaint((java.awt.Paint) color23);
        legendGraphic15.setID("TextAnchor.BASELINE_RIGHT");
        java.awt.Paint paint35 = legendGraphic15.getLinePaint();
        java.awt.Paint paint36 = null;
        legendGraphic15.setLinePaint(paint36);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.block.FlowArrangement flowArrangement1 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement1.clear();
        double[] doubleArray11 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray18 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray25 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray32 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray39 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray46 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray47 = new double[][] { doubleArray11, doubleArray18, doubleArray25, doubleArray32, doubleArray39, doubleArray46 };
        org.jfree.data.category.CategoryDataset categoryDataset48 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray47);
        org.jfree.data.general.PieDataset pieDataset50 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset48, (int) (short) 0);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer52 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) flowArrangement1, (org.jfree.data.general.Dataset) pieDataset50, (java.lang.Comparable) "ThreadContext");
        java.lang.Comparable comparable53 = legendItemBlockContainer52.getSeriesKey();
        legendItemBlockContainer52.setToolTipText("CONTRACT");
        java.awt.Graphics2D graphics2D56 = null;
        org.jfree.data.Range range58 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint59 = new org.jfree.chart.block.RectangleConstraint((double) 0, range58);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint61 = rectangleConstraint59.toFixedWidth((double) (byte) 1);
        try {
            org.jfree.chart.util.Size2D size2D62 = borderArrangement0.arrange((org.jfree.chart.block.BlockContainer) legendItemBlockContainer52, graphics2D56, rectangleConstraint61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(categoryDataset48);
        org.junit.Assert.assertNotNull(pieDataset50);
        org.junit.Assert.assertTrue("'" + comparable53 + "' != '" + "ThreadContext" + "'", comparable53.equals("ThreadContext"));
        org.junit.Assert.assertNotNull(rectangleConstraint61);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        statisticalBarRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition4, true);
        boolean boolean7 = statisticalBarRenderer0.isDrawBarOutline();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        statisticalBarRenderer0.notifyListeners(rendererChangeEvent8);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
        java.awt.Stroke stroke4 = numberAxis1.getTickMarkStroke();
        numberAxis1.setUpperMargin((double) (-1));
        boolean boolean7 = numberAxis1.isPositiveArrowVisible();
        double double8 = numberAxis1.getUpperMargin();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement0.clear();
        org.jfree.chart.LegendItemSource legendItemSource2 = null;
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource2);
        org.jfree.chart.LegendItemSource legendItemSource4 = null;
        org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle(legendItemSource4);
        double double6 = legendTitle5.getHeight();
        flowArrangement0.add((org.jfree.chart.block.Block) legendTitle3, (java.lang.Object) double6);
        double double8 = legendTitle3.getWidth();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        legendTitle3.setLegendItemGraphicEdge(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color5 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("ThreadContext", font4, (java.awt.Paint) color5);
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font4);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (-1.0f));
        java.awt.Stroke stroke10 = valueMarker9.getOutlineStroke();
        java.awt.Paint paint11 = valueMarker9.getOutlinePaint();
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("-3,-3,3,3", font4, paint11);
        java.awt.Font font18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color19 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment20 = new org.jfree.chart.text.TextFragment("ThreadContext", font18, (java.awt.Paint) color19);
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("", font18);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("hi!", font18);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.lang.Object obj26 = textTitle22.draw(graphics2D23, rectangle2D24, (java.lang.Object) (byte) 100);
        java.awt.Font font28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color29 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment30 = new org.jfree.chart.text.TextFragment("ThreadContext", font28, (java.awt.Paint) color29);
        textTitle22.setFont(font28);
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("RangeType.FULL", font28);
        java.awt.Color color35 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color36 = java.awt.Color.getColor("", color35);
        java.awt.Color color37 = java.awt.Color.getColor("ThreadContext", color36);
        org.jfree.chart.axis.AxisSpace axisSpace38 = new org.jfree.chart.axis.AxisSpace();
        axisSpace38.setBottom((double) '#');
        double double41 = axisSpace38.getLeft();
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.lang.Object obj44 = null;
        boolean boolean45 = rectangleEdge43.equals(obj44);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge43);
        axisSpace38.ensureAtLeast((double) 100, rectangleEdge43);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment48 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor49 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean50 = horizontalAlignment48.equals((java.lang.Object) textAnchor49);
        org.jfree.chart.util.VerticalAlignment verticalAlignment51 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.lang.String str52 = verticalAlignment51.toString();
        org.jfree.chart.block.FlowArrangement flowArrangement53 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement53.clear();
        org.jfree.chart.LegendItemSource legendItemSource55 = null;
        org.jfree.chart.title.LegendTitle legendTitle56 = new org.jfree.chart.title.LegendTitle(legendItemSource55);
        org.jfree.chart.LegendItemSource legendItemSource57 = null;
        org.jfree.chart.title.LegendTitle legendTitle58 = new org.jfree.chart.title.LegendTitle(legendItemSource57);
        double double59 = legendTitle58.getHeight();
        flowArrangement53.add((org.jfree.chart.block.Block) legendTitle56, (java.lang.Object) double59);
        legendTitle56.setWidth((double) (byte) -1);
        java.awt.Paint paint63 = legendTitle56.getItemPaint();
        boolean boolean64 = verticalAlignment51.equals((java.lang.Object) paint63);
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double67 = rectangleInsets65.trimWidth((double) 1L);
        java.lang.String str68 = rectangleInsets65.toString();
        org.jfree.chart.title.TextTitle textTitle69 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font28, (java.awt.Paint) color37, rectangleEdge43, horizontalAlignment48, verticalAlignment51, rectangleInsets65);
        org.jfree.chart.text.TextLine textLine70 = new org.jfree.chart.text.TextLine("DatasetRenderingOrder.FORWARD", font4, (java.awt.Paint) color37);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertNotNull(horizontalAlignment48);
        org.junit.Assert.assertNotNull(textAnchor49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(verticalAlignment51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "VerticalAlignment.CENTER" + "'", str52.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + (-7.0d) + "'", double67 == (-7.0d));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str68.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("LGPL");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.PaintList paintList3 = new org.jfree.chart.util.PaintList();
        int int4 = paintList3.size();
        org.jfree.chart.axis.TickType tickType5 = org.jfree.chart.axis.TickType.MINOR;
        boolean boolean6 = paintList3.equals((java.lang.Object) tickType5);
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.axis.NumberTick numberTick12 = new org.jfree.chart.axis.NumberTick(tickType5, (double) 2.0f, "", textAnchor9, textAnchor10, 1.0E-8d);
        try {
            float float13 = textFragment1.calculateBaselineOffset(graphics2D2, textAnchor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(tickType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand3 = null;
        numberAxis2.setMarkerBand(markerAxisBand3);
        java.awt.Stroke stroke5 = numberAxis2.getTickMarkStroke();
        numberAxis2.setUpperMargin((double) 0.5f);
        java.awt.Paint paint8 = numberAxis2.getLabelPaint();
        org.jfree.data.KeyedObject keyedObject9 = new org.jfree.data.KeyedObject((java.lang.Comparable) 10L, (java.lang.Object) paint8);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        categoryAxis1.setLowerMargin((double) 0);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color7 = java.awt.Color.RED;
        categoryAxis6.setLabelPaint((java.awt.Paint) color7);
        categoryAxis6.setMaximumCategoryLabelLines((int) (short) -1);
        java.awt.Paint paint11 = categoryAxis6.getTickLabelPaint();
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.block.LineBorder lineBorder14 = new org.jfree.chart.block.LineBorder(paint11, stroke12, rectangleInsets13);
        categoryAxis1.setAxisLineStroke(stroke12);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryAxis1.getTickLabelInsets();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color6 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("ThreadContext", font5, (java.awt.Paint) color6);
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font5);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!", font5);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.lang.Object obj13 = textTitle9.draw(graphics2D10, rectangle2D11, (java.lang.Object) (byte) 100);
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color16 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("ThreadContext", font15, (java.awt.Paint) color16);
        textTitle9.setFont(font15);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("RangeType.FULL", font15);
        java.lang.String str20 = textTitle19.getURLText();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.jfree.chart.text.TextLine textLine22 = new org.jfree.chart.text.TextLine();
        java.awt.Font font24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color25 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment26 = new org.jfree.chart.text.TextFragment("ThreadContext", font24, (java.awt.Paint) color25);
        textLine22.addFragment(textFragment26);
        boolean boolean28 = horizontalAlignment21.equals((java.lang.Object) textFragment26);
        textTitle19.setTextAlignment(horizontalAlignment21);
        java.awt.Font font34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color35 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment36 = new org.jfree.chart.text.TextFragment("ThreadContext", font34, (java.awt.Paint) color35);
        org.jfree.chart.text.TextLine textLine37 = new org.jfree.chart.text.TextLine("", font34);
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle("hi!", font34);
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        java.lang.Object obj42 = textTitle38.draw(graphics2D39, rectangle2D40, (java.lang.Object) (byte) 100);
        java.awt.Font font44 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color45 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment46 = new org.jfree.chart.text.TextFragment("ThreadContext", font44, (java.awt.Paint) color45);
        textTitle38.setFont(font44);
        org.jfree.chart.block.LabelBlock labelBlock48 = new org.jfree.chart.block.LabelBlock("ThreadContext", font44);
        textTitle19.setFont(font44);
        java.awt.Paint paint50 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.text.TextBlock textBlock51 = org.jfree.chart.text.TextUtilities.createTextBlock("HorizontalAlignment.RIGHT", font44, paint50);
        java.util.List list52 = textBlock51.getLines();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNull(obj42);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(textBlock51);
        org.junit.Assert.assertNotNull(list52);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis1.setUpperBound((double) 1L);
        numberAxis1.setTickMarkInsideLength((float) 100L);
        boolean boolean6 = numberAxis1.isPositiveArrowVisible();
        numberAxis1.setFixedAutoRange(0.5d);
        numberAxis1.setLabel("RectangleConstraintType.RANGE");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int1 = numberTickUnit0.getMinorTickCount();
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) 0L, (-7.8d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-7.8).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Comparable comparable2 = keyedObjects0.getKey((int) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double6 = categoryAxis5.getLabelAngle();
        java.awt.Font font8 = categoryAxis5.getTickLabelFont((java.lang.Comparable) 10.0d);
        double double9 = categoryAxis5.getLabelAngle();
        java.awt.Paint paint10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        categoryAxis5.setAxisLinePaint(paint10);
        keyedObjects0.setObject((java.lang.Comparable) 10.0f, (java.lang.Object) categoryAxis5);
        java.awt.Font font18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color19 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment20 = new org.jfree.chart.text.TextFragment("ThreadContext", font18, (java.awt.Paint) color19);
        org.jfree.chart.text.TextLine textLine21 = new org.jfree.chart.text.TextLine("", font18);
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle("hi!", font18);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.lang.Object obj26 = textTitle22.draw(graphics2D23, rectangle2D24, (java.lang.Object) (byte) 100);
        java.awt.Font font28 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color29 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment30 = new org.jfree.chart.text.TextFragment("ThreadContext", font28, (java.awt.Paint) color29);
        textTitle22.setFont(font28);
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle("RangeType.FULL", font28);
        java.lang.String str33 = textTitle32.getURLText();
        keyedObjects0.addObject((java.lang.Comparable) (-1L), (java.lang.Object) str33);
        org.junit.Assert.assertNull(comparable2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(obj26);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNull(str33);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.Range range2 = defaultStatisticalCategoryDataset0.getRangeBounds(false);
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.jfree.data.general.DatasetChangeListener datasetChangeListener4 = null;
        defaultStatisticalCategoryDataset0.removeChangeListener(datasetChangeListener4);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener6 = null;
        defaultStatisticalCategoryDataset0.removeChangeListener(datasetChangeListener6);
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double4 = categoryAxis3.getLabelAngle();
        java.awt.Font font6 = categoryAxis3.getTickLabelFont((java.lang.Comparable) 10.0d);
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("-3,-3,3,3", font6);
        org.jfree.chart.block.LabelBlock labelBlock8 = new org.jfree.chart.block.LabelBlock("ThreadContext", font6);
        java.awt.Paint paint9 = labelBlock8.getPaint();
        java.awt.Paint paint10 = labelBlock8.getPaint();
        java.lang.Object obj11 = labelBlock8.clone();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        double[] doubleArray8 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray29 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray36 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[] doubleArray43 = new double[] { (byte) 10, 0.0d, (-1), 35.0d, (short) -1, 100L };
        double[][] doubleArray44 = new double[][] { doubleArray8, doubleArray15, doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.jfree.data.category.CategoryDataset categoryDataset45 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "ThreadContext", doubleArray44);
        org.jfree.data.general.PieDataset pieDataset47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset45, (int) (short) 0);
        org.jfree.data.Range range48 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset45);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double51 = categoryAxis50.getLabelAngle();
        categoryAxis50.setLowerMargin((double) 0);
        categoryAxis50.setLabel("hi!");
        int int56 = categoryAxis50.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("-3,-3,3,3");
        numberAxis58.setAutoRange(false);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer61 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator62 = null;
        statisticalBarRenderer61.setBaseItemLabelGenerator(categoryItemLabelGenerator62);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition65 = null;
        statisticalBarRenderer61.setSeriesPositiveItemLabelPosition((int) (short) 10, itemLabelPosition65, true);
        boolean boolean68 = statisticalBarRenderer61.isDrawBarOutline();
        boolean boolean69 = statisticalBarRenderer61.getAutoPopulateSeriesPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis50, (org.jfree.chart.axis.ValueAxis) numberAxis58, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer61);
        java.lang.Object obj71 = categoryPlot70.clone();
        categoryPlot70.setRangeCrosshairValue((double) (byte) 0);
        org.jfree.chart.axis.ValueAxis valueAxis75 = categoryPlot70.getRangeAxis((int) (short) -1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(categoryDataset45);
        org.junit.Assert.assertNotNull(pieDataset47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(obj71);
        org.junit.Assert.assertNull(valueAxis75);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        double double2 = categoryAxis1.getLabelAngle();
        java.awt.Font font4 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 10.0d);
        double double5 = categoryAxis1.getLabelAngle();
        java.awt.Shape shape6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape6, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color13 = java.awt.Color.RED;
        categoryAxis12.setLabelPaint((java.awt.Paint) color13);
        float[] floatArray19 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray20 = color13.getRGBColorComponents(floatArray19);
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape10, (java.awt.Paint) color13);
        java.awt.Shape shape22 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape22, (double) 0L, (float) (-1L), (float) (short) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color29 = java.awt.Color.RED;
        categoryAxis28.setLabelPaint((java.awt.Paint) color29);
        float[] floatArray35 = new float[] { 1L, 'a', 1, (byte) 100 };
        float[] floatArray36 = color29.getRGBColorComponents(floatArray35);
        org.jfree.chart.title.LegendGraphic legendGraphic37 = new org.jfree.chart.title.LegendGraphic(shape26, (java.awt.Paint) color29);
        legendGraphic21.setLinePaint((java.awt.Paint) color29);
        boolean boolean39 = categoryAxis1.equals((java.lang.Object) legendGraphic21);
        legendGraphic21.setMargin((double) '4', 100.0d, (double) (byte) 1, (double) 0L);
        legendGraphic21.setShapeFilled(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.lang.String str1 = axisLocation0.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str1.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        java.awt.Font font5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color6 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("ThreadContext", font5, (java.awt.Paint) color6);
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("", font5);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("hi!", font5);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        java.lang.Object obj13 = textTitle9.draw(graphics2D10, rectangle2D11, (java.lang.Object) (byte) 100);
        java.awt.Font font15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color16 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("ThreadContext", font15, (java.awt.Paint) color16);
        textTitle9.setFont(font15);
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle("RangeType.FULL", font15);
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color23 = java.awt.Color.getColor("", color22);
        java.awt.Color color24 = java.awt.Color.getColor("ThreadContext", color23);
        org.jfree.chart.axis.AxisSpace axisSpace25 = new org.jfree.chart.axis.AxisSpace();
        axisSpace25.setBottom((double) '#');
        double double28 = axisSpace25.getLeft();
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        java.lang.Object obj31 = null;
        boolean boolean32 = rectangleEdge30.equals(obj31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge30);
        axisSpace25.ensureAtLeast((double) 100, rectangleEdge30);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment35 = org.jfree.chart.util.HorizontalAlignment.RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor36 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        boolean boolean37 = horizontalAlignment35.equals((java.lang.Object) textAnchor36);
        org.jfree.chart.util.VerticalAlignment verticalAlignment38 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.lang.String str39 = verticalAlignment38.toString();
        org.jfree.chart.block.FlowArrangement flowArrangement40 = new org.jfree.chart.block.FlowArrangement();
        flowArrangement40.clear();
        org.jfree.chart.LegendItemSource legendItemSource42 = null;
        org.jfree.chart.title.LegendTitle legendTitle43 = new org.jfree.chart.title.LegendTitle(legendItemSource42);
        org.jfree.chart.LegendItemSource legendItemSource44 = null;
        org.jfree.chart.title.LegendTitle legendTitle45 = new org.jfree.chart.title.LegendTitle(legendItemSource44);
        double double46 = legendTitle45.getHeight();
        flowArrangement40.add((org.jfree.chart.block.Block) legendTitle43, (java.lang.Object) double46);
        legendTitle43.setWidth((double) (byte) -1);
        java.awt.Paint paint50 = legendTitle43.getItemPaint();
        boolean boolean51 = verticalAlignment38.equals((java.lang.Object) paint50);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double54 = rectangleInsets52.trimWidth((double) 1L);
        java.lang.String str55 = rectangleInsets52.toString();
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font15, (java.awt.Paint) color24, rectangleEdge30, horizontalAlignment35, verticalAlignment38, rectangleInsets52);
        java.lang.String str57 = textTitle56.getURLText();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(horizontalAlignment35);
        org.junit.Assert.assertNotNull(textAnchor36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(verticalAlignment38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "VerticalAlignment.CENTER" + "'", str39.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + (-7.0d) + "'", double54 == (-7.0d));
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str55.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertNull(str57);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.awt.Font font4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color5 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("ThreadContext", font4, (java.awt.Paint) color5);
        org.jfree.chart.text.TextLine textLine7 = new org.jfree.chart.text.TextLine("", font4);
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("hi!", font4);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.lang.Object obj12 = textTitle8.draw(graphics2D9, rectangle2D10, (java.lang.Object) (byte) 100);
        java.awt.Font font14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color15 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("ThreadContext", font14, (java.awt.Paint) color15);
        textTitle8.setFont(font14);
        org.jfree.chart.block.LabelBlock labelBlock18 = new org.jfree.chart.block.LabelBlock("ThreadContext", font14);
        java.lang.String str19 = labelBlock18.getToolTipText();
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        java.awt.Font font3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color4 = java.awt.Color.RED;
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("ThreadContext", font3, (java.awt.Paint) color4);
        org.jfree.chart.text.TextLine textLine6 = new org.jfree.chart.text.TextLine("", font3);
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color9 = java.awt.Color.MAGENTA;
        int int10 = color9.getRed();
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("hi!", font8, (java.awt.Paint) color9, (float) 'a');
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("HorizontalAlignment.RIGHT", font3, (java.awt.Paint) color9);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        try {
            textBlock13.draw(graphics2D14, (float) (short) -1, (float) (short) 100, textBlockAnchor17, 2.0f, 2.0f, 97.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertNotNull(textBlockAnchor17);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.awt.Font font0 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }
}

