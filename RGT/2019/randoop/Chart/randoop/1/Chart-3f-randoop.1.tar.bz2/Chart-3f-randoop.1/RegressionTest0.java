import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) '#', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries6 = timeSeries3.createCopy(regularTimePeriod4, regularTimePeriod5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = null;
        try {
            timeSeries3.add(regularTimePeriod4, (java.lang.Number) (byte) 100, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.Year.MINIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-9999) + "'", int0 == (-9999));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.addOrUpdate(regularTimePeriod5, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = null;
        try {
            timeSeries3.update(regularTimePeriod5, (java.lang.Number) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries3.addOrUpdate(timeSeriesDataItem5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        try {
            timeSeries3.delete((int) (short) 1, (int) (byte) 10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.removeAgedItems((long) (byte) 100, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.createCopy(regularTimePeriod9, regularTimePeriod10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 100, seriesChangeInfo1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo3);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo5);
        java.lang.String str7 = seriesChangeEvent2.toString();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str7.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = null;
        try {
            int int6 = timeSeries3.getIndex(regularTimePeriod5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries6 = null;
        try {
            java.util.Collection collection7 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        try {
            timeSeries3.delete(0, (int) (byte) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 6);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month6.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries7 = null;
        try {
            java.util.Collection collection8 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 6);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month6.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        timeSeries3.setRangeDescription("");
        try {
            java.lang.Number number9 = timeSeries3.getValue((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.setNotify(false);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries3.getDataItem((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false);
        int int2 = timeSeries1.getItemCount();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = null;
        try {
            int int4 = timeSeries1.getIndex(regularTimePeriod3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = day4.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        long long3 = regularTimePeriod2.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62119972800001L) + "'", long3 == (-62119972800001L));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries1.addOrUpdate(regularTimePeriod11, (java.lang.Number) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.getDataItem((-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test047");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        long long20 = day18.getFirstMillisecond();
//        int int21 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day18);
//        java.lang.Number number23 = null;
//        try {
//            timeSeries3.update(1, number23);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560150000000L + "'", long20 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.event.SeriesChangeEvent[source=100]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = day10.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj4 = null;
        int int5 = month3.compareTo(obj4);
        org.jfree.data.time.Year year6 = month3.getYear();
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) ' ', year6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(year6);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        org.jfree.data.time.Year year5 = month2.getYear();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year5.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries3.addChangeListener(seriesChangeListener16);
        java.util.List list18 = timeSeries3.getItems();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day19, 0.0d, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        java.util.Date date5 = month2.getEnd();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test058");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        java.util.TimeZone timeZone7 = null;
//        try {
//            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date6, timeZone7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182344717L + "'", long2 == 1560182344717L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries3.getTimePeriod(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560182343140L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.Number number7 = null;
        try {
            timeSeries3.update(0, number7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.removeAgedItems((long) (byte) 100, false);
        java.util.List list9 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("100");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str9 = timeSeries8.getDescription();
        java.lang.String str10 = timeSeries8.getDomainDescription();
        java.util.Collection collection11 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = null;
        try {
            int int13 = timeSeries8.getIndex(regularTimePeriod12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(collection11);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("October 100");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        long long2 = year1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 6);
        java.util.Calendar calendar8 = null;
        try {
            day4.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = day4.getMiddleMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate9);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test072");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        java.util.TimeZone timeZone5 = null;
//        java.util.Locale locale6 = null;
//        try {
//            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date3, timeZone5, locale6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182345651L + "'", long2 == 1560182345651L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries13.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month18);
        try {
            timeSeries3.delete((-1), (-1), true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.String str6 = seriesChangeEvent5.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        seriesChangeEvent5.setSummary(seriesChangeInfo7);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9999, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        timeSeries3.setMaximumItemAge((long) 12);
        boolean boolean9 = timeSeries3.isEmpty();
        timeSeries3.setMaximumItemAge(10L);
        try {
            org.jfree.data.time.TimeSeries timeSeries14 = timeSeries3.createCopy(10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        int int14 = day8.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        org.jfree.data.time.Year year5 = month2.getYear();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries7.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        int int10 = year5.compareTo((java.lang.Object) timeSeries7);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year5.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.util.Date date3 = regularTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        try {
            timeSeries3.delete((int) (byte) 0, (int) (byte) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        timeSeries3.setKey((java.lang.Comparable) 1560182345060L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries3.addChangeListener(seriesChangeListener16);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries3.removeChangeListener(seriesChangeListener18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries3.getDataItem(regularTimePeriod20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries3.addChangeListener(seriesChangeListener16);
        java.util.List list18 = timeSeries3.getItems();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.getDataItem(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(list18);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (byte) 100);
        boolean boolean4 = timeSeriesDataItem2.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem2.setSelected(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem2.getPeriod();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day8);
        try {
            timeSeries1.delete(0, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test088");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getFirstMillisecond();
//        java.util.Calendar calendar4 = null;
//        try {
//            day0.peg(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.String str6 = seriesChangeEvent5.toString();
        java.lang.String str7 = seriesChangeEvent5.toString();
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
        java.lang.String str9 = timeSeries3.getDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries3.getTimePeriod(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        try {
            java.lang.Number number5 = timeSeries1.getValue((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(8);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        timeSeries3.setMaximumItemAge((long) 12);
        boolean boolean9 = timeSeries3.isEmpty();
        boolean boolean10 = timeSeries3.getNotify();
        try {
            timeSeries3.delete(2147483647, (int) (short) -1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        long long9 = month8.getFirstMillisecond();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month8);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries3.getTimePeriod((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-58987929600000L) + "'", long9 == (-58987929600000L));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        try {
            timeSeries1.update((int) '4', (java.lang.Number) 1560182344569L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2147483647) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = null;
        try {
            timeSeries3.add(timeSeriesDataItem6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries3.getTimePeriod(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) (short) 0, year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean6 = timeSeries1.equals((java.lang.Object) timePeriodFormatException5);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeries1.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test104");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getFirstMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getFirstMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 100, seriesChangeInfo1);
        java.lang.Object obj3 = seriesChangeEvent2.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo4);
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (short) 100 + "'", obj3.equals((short) 100));
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        long long9 = fixedMillisecond6.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double14 = timeSeries13.getMaxY();
//        java.util.List list15 = timeSeries13.getItems();
//        timeSeries13.removeAgedItems((long) (byte) 100, false);
//        boolean boolean19 = fixedMillisecond6.equals((java.lang.Object) (byte) 100);
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond6.getMiddleMillisecond(calendar20);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182349137L + "'", long9 == 1560182349137L);
//        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list15);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560182349137L + "'", long21 == 1560182349137L);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        long long3 = month2.getFirstMillisecond();
        long long4 = month2.getFirstMillisecond();
        int int5 = month2.getYearValue();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-58987929600000L) + "'", long3 == (-58987929600000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-58987929600000L) + "'", long4 == (-58987929600000L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.String str2 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str2.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getMaximumItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        java.util.Date date9 = regularTimePeriod8.getStart();
        timeSeries3.delete(regularTimePeriod8);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries3.getDataItem(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double7 = timeSeries6.getMaxY();
        java.util.Collection collection8 = timeSeries6.getTimePeriods();
        java.lang.String str9 = timeSeries6.getRangeDescription();
        timeSeries6.setMaximumItemAge((long) 12);
        int int12 = month2.compareTo((java.lang.Object) 12);
        int int13 = month2.getYearValue();
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test112");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = month6.getLastMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182349437L + "'", long2 == 1560182349437L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.next();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month6, seriesChangeInfo10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = null;
        seriesChangeEvent11.setSummary(seriesChangeInfo12);
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getItemCount();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries3.getDataItem((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        timeSeries3.fireSeriesChanged();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeries3.getTimePeriod(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries15.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day18, (double) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day18.next();
        timeSeries1.add(regularTimePeriod22, (double) 1560182340527L);
        try {
            java.lang.Number number26 = timeSeries1.getValue(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test117");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        long long15 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double21 = timeSeries20.getMaxY();
//        int int22 = timeSeries20.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 6);
//        long long26 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond23.previous();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = null;
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries1.addOrUpdate(timeSeriesDataItem29);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182349894L + "'", long11 == 1560182349894L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182349894L + "'", long15 == 1560182349894L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182349896L + "'", long26 == 1560182349896L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("10-June-2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean6 = timeSeries1.equals((java.lang.Object) timePeriodFormatException5);
        java.lang.String str7 = timePeriodFormatException5.toString();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str7.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        int int3 = month2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        int int5 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        timeSeries3.removeAgedItems((long) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 100);
        boolean boolean14 = timeSeriesDataItem12.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem12.setSelected(false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.addOrUpdate(timeSeriesDataItem12);
        try {
            boolean boolean18 = timeSeriesDataItem17.isSelected();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        long long9 = fixedMillisecond6.getFirstMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond6.getMiddleMillisecond(calendar10);
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond6.getLastMillisecond(calendar12);
//        long long14 = fixedMillisecond6.getFirstMillisecond();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182350273L + "'", long9 == 1560182350273L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182350273L + "'", long11 == 1560182350273L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560182350273L + "'", long13 == 1560182350273L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560182350273L + "'", long14 == 1560182350273L);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 6);
        java.lang.String str3 = month2.toString();
        java.util.Calendar calendar4 = null;
        try {
            month2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "September 6" + "'", str3.equals("September 6"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getItemCount();
        timeSeries3.setMaximumItemCount(1);
        try {
            timeSeries3.update((int) (short) -1, (java.lang.Number) 1560182341480L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1560193199999L);
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560182350372L + "'", long4 == 1560182350372L);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        timeSeries3.setMaximumItemAge((long) 12);
        boolean boolean9 = timeSeries3.isEmpty();
        boolean boolean10 = timeSeries3.getNotify();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
//        long long2 = year1.getSerialIndex();
//        long long3 = year1.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        long long5 = fixedMillisecond4.getMiddleMillisecond();
//        int int6 = year1.compareTo((java.lang.Object) fixedMillisecond4);
//        java.util.Calendar calendar7 = null;
//        try {
//            long long8 = year1.getFirstMillisecond(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560182350859L + "'", long5 == 1560182350859L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.util.Date date3 = regularTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Mon Jun 10 08:59:09 PDT 2019");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test131");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        long long20 = day18.getFirstMillisecond();
//        int int21 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day18);
//        long long22 = day18.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day18.previous();
//        java.util.Calendar calendar24 = null;
//        try {
//            day18.peg(calendar24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560150000000L + "'", long20 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560150000000L + "'", long22 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.next();
        int int10 = month6.getMonth();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = month6.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test133");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        long long9 = fixedMillisecond6.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double14 = timeSeries13.getMaxY();
//        java.util.List list15 = timeSeries13.getItems();
//        timeSeries13.removeAgedItems((long) (byte) 100, false);
//        boolean boolean19 = fixedMillisecond6.equals((java.lang.Object) (byte) 100);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        long long24 = timeSeries23.getMaximumItemAge();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day25, (java.lang.Number) (byte) 100);
//        boolean boolean29 = timeSeriesDataItem27.equals((java.lang.Object) (short) 10);
//        boolean boolean30 = timeSeriesDataItem27.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries23.addOrUpdate(timeSeriesDataItem27);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries33.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month38, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month38.next();
//        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) month38);
//        boolean boolean43 = fixedMillisecond6.equals((java.lang.Object) month38);
//        java.util.Date date44 = fixedMillisecond6.getTime();
//        java.util.TimeZone timeZone45 = null;
//        try {
//            org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(date44, timeZone45);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182351129L + "'", long9 == 1560182351129L);
//        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list15);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(date44);
//    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test134");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
//        java.lang.String str10 = day4.toString();
//        long long11 = day4.getSerialIndex();
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = day4.getLastMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.util.TimeZone timeZone4 = null;
//        java.util.Locale locale5 = null;
//        try {
//            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3, timeZone4, locale5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182351169L + "'", long2 == 1560182351169L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(8, 1, (-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj5 = null;
        int int6 = month4.compareTo(obj5);
        org.jfree.data.time.Year year7 = month4.getYear();
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 1560182341480L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(year7);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test138");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        java.util.TimeZone timeZone4 = null;
//        try {
//            org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3, timeZone4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182351640L + "'", long2 == 1560182351640L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getItemCount();
        double double6 = timeSeries3.getMinY();
        try {
            java.lang.Number number8 = timeSeries3.getValue(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) (short) 1, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        java.util.Date date5 = month2.getEnd();
        java.util.Date date6 = month2.getStart();
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560182347681L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, (java.lang.Number) (byte) 100);
        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) (short) 10);
        timeSeries3.add(timeSeriesDataItem8);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries13.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) day16, (double) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day16.next();
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 1560182347498L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 10-June-2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        long long6 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double12 = timeSeries11.getMaxY();
//        java.util.Collection collection13 = timeSeries11.getTimePeriods();
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        long long17 = month16.getFirstMillisecond();
//        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) month16);
//        int int19 = fixedMillisecond0.compareTo((java.lang.Object) month16);
//        int int20 = month16.getYearValue();
//        java.util.Calendar calendar21 = null;
//        try {
//            month16.peg(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182352677L + "'", long2 == 1560182352677L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182352677L + "'", long6 == 1560182352677L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-58987929600000L) + "'", long17 == (-58987929600000L));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries15.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day18, (double) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day18.next();
        timeSeries1.add(regularTimePeriod22, (double) 1560182340527L);
        timeSeries1.setKey((java.lang.Comparable) '4');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = null;
        java.lang.Number number28 = null;
        try {
            timeSeries1.add(regularTimePeriod27, number28, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str13 = timeSeries12.getDescription();
        java.util.Collection collection14 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        double double15 = timeSeries1.getMinY();
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 9.223372036854776E18d + "'", double15 == 9.223372036854776E18d);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1);
//        java.util.List list3 = timeSeries2.getItems();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182352795L + "'", long1 == 1560182352795L);
//        org.junit.Assert.assertNotNull(list3);
//    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day4.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182352853L + "'", long2 == 1560182352853L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.util.Date date3 = regularTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test151");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
//        long long2 = year1.getSerialIndex();
//        long long3 = year1.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries9.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month14.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries7.addOrUpdate(regularTimePeriod17, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries7.addChangeListener(seriesChangeListener20);
//        java.util.Collection collection22 = timeSeries7.getTimePeriods();
//        timeSeries7.setRangeDescription("");
//        int int25 = year1.compareTo((java.lang.Object) timeSeries7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond26.getMiddleMillisecond(calendar27);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int31 = fixedMillisecond26.compareTo((java.lang.Object) "hi!");
//        java.util.Date date32 = fixedMillisecond26.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(date32);
//        java.lang.Number number34 = null;
//        try {
//            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, number34, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560182352945L + "'", long28 == 1560182352945L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertNotNull(date32);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (byte) 100);
        boolean boolean4 = timeSeriesDataItem2.equals((java.lang.Object) (short) 10);
        boolean boolean5 = timeSeriesDataItem2.isSelected();
        java.lang.Object obj6 = timeSeriesDataItem2.clone();
        java.lang.Number number7 = null;
        timeSeriesDataItem2.setValue(number7);
        timeSeriesDataItem2.setSelected(true);
        java.lang.Object obj11 = timeSeriesDataItem2.clone();
        timeSeriesDataItem2.setSelected(false);
        java.lang.Object obj14 = timeSeriesDataItem2.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        try {
            timeSeries3.update(2019, (java.lang.Number) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        long long15 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double21 = timeSeries20.getMaxY();
//        int int22 = timeSeries20.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 6);
//        long long26 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond23.previous();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) (byte) 100);
//        boolean boolean33 = timeSeriesDataItem31.equals((java.lang.Object) (short) 10);
//        boolean boolean34 = timeSeriesDataItem31.isSelected();
//        try {
//            timeSeries1.add(timeSeriesDataItem31);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 10-June-2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182353016L + "'", long11 == 1560182353016L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182353016L + "'", long15 == 1560182353016L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182353017L + "'", long26 == 1560182353017L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
//        long long14 = day8.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, (java.lang.Number) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day8.next();
//        org.jfree.data.time.SerialDate serialDate18 = day8.getSerialDate();
//        java.util.Calendar calendar19 = null;
//        try {
//            long long20 = day8.getLastMillisecond(calendar19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(serialDate18);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getItemCount();
        timeSeries3.setRangeDescription("October 100");
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(0);
        int int11 = year10.getYear();
        try {
            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) year10, (java.lang.Number) 1560182344886L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        timeSeries3.setMaximumItemAge((long) 12);
        boolean boolean9 = timeSeries3.isEmpty();
        timeSeries3.setMaximumItemAge(10L);
        try {
            timeSeries3.delete((int) (short) -1, (-9999), true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day8);
//        java.util.Collection collection11 = timeSeries1.getTimePeriods();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond12.getMiddleMillisecond(calendar13);
//        java.util.Date date15 = fixedMillisecond12.getTime();
//        java.util.Calendar calendar16 = null;
//        fixedMillisecond12.peg(calendar16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond12.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = null;
//        try {
//            org.jfree.data.time.TimeSeries timeSeries20 = timeSeries1.createCopy(regularTimePeriod18, regularTimePeriod19);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560182353388L + "'", long14 == 1560182353388L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test159");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
//        java.lang.String str10 = day4.toString();
//        java.lang.String str11 = day4.toString();
//        java.lang.String str12 = day4.toString();
//        int int13 = day4.getDayOfMonth();
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("September 6");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str13 = timeSeries12.getDescription();
        java.util.Collection collection14 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries12.getDataItem((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(collection14);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getItemCount();
        boolean boolean6 = timeSeries3.isEmpty();
        timeSeries3.removeAgedItems(true);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
        timeSeries3.setRangeDescription("10-June-2019");
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.removeAgedItems((long) (byte) 100, false);
        java.lang.Comparable comparable9 = timeSeries3.getKey();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj13 = null;
        int int14 = month12.compareTo(obj13);
        java.util.Date date15 = month12.getEnd();
        java.util.Date date16 = month12.getStart();
        boolean boolean17 = timeSeries3.equals((java.lang.Object) date16);
        java.util.TimeZone timeZone18 = null;
        try {
            org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16, timeZone18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 10.0d + "'", comparable9.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        long long2 = year1.getSerialIndex();
        long long3 = year1.getSerialIndex();
        int int4 = year1.getYear();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.previous();
        long long10 = month6.getFirstMillisecond();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = month6.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-58987929600000L) + "'", long10 == (-58987929600000L));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Mon Jun 10 08:59:05 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(0);
        int int3 = year2.getYear();
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month((int) '4', year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day4.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.removeAgedItems((long) (byte) 100, false);
        java.util.List list9 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double14 = timeSeries13.getMaxY();
        int int15 = timeSeries13.getItemCount();
        timeSeries13.setMaximumItemCount(1);
        boolean boolean18 = timeSeries3.equals((java.lang.Object) timeSeries13);
        timeSeries3.clear();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries3.addChangeListener(seriesChangeListener16);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries3.removeChangeListener(seriesChangeListener18);
        int int20 = timeSeries3.getMaximumItemCount();
        int int21 = timeSeries3.getItemCount();
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getFirstMillisecond();
//        long long4 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43626L + "'", long4 == 43626L);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        timeSeries3.setNotify(false);
        try {
            timeSeries3.delete(4, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        long long5 = year4.getFirstMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = year4.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182354316L + "'", long2 == 1560182354316L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.event.SeriesChangeEvent[source=100]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        java.util.Date date5 = month2.getEnd();
        int int7 = month2.compareTo((java.lang.Object) 1560182345060L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.next();
        org.jfree.data.time.Year year9 = month2.getYear();
        long long10 = year9.getFirstMillisecond();
        long long11 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year9.next();
        long long13 = year9.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-59011603200000L) + "'", long10 == (-59011603200000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-59011603200000L) + "'", long11 == (-59011603200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(9, (-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        timeSeries1.removeAgedItems(false);
        try {
            timeSeries1.delete((int) '#', 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        boolean boolean8 = timeSeriesDataItem6.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem6.setSelected(false);
        java.lang.Number number11 = timeSeriesDataItem6.getValue();
        timeSeries3.add(timeSeriesDataItem6, false);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(0);
        long long16 = year15.getSerialIndex();
        long long17 = year15.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries23.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month28.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries21.addOrUpdate(regularTimePeriod31, (double) (short) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener34 = null;
        timeSeries21.addChangeListener(seriesChangeListener34);
        java.util.Collection collection36 = timeSeries21.getTimePeriods();
        timeSeries21.setRangeDescription("");
        int int39 = year15.compareTo((java.lang.Object) timeSeries21);
        try {
            org.jfree.data.time.TimeSeries timeSeries40 = timeSeries3.addAndOrUpdate(timeSeries21);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 100 + "'", number11.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNotNull(collection36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test180");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
//        java.lang.String str14 = day8.toString();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
//        long long18 = year16.getLastMillisecond();
//        int int19 = year16.getYear();
//        boolean boolean20 = day8.equals((java.lang.Object) year16);
//        java.util.Calendar calendar21 = null;
//        try {
//            day8.peg(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62104204800001L) + "'", long18 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        timeSeries3.removeAgedItems((long) 10, false);
        java.util.List list8 = timeSeries3.getItems();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        org.jfree.data.time.Year year5 = month2.getYear();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries7.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        int int10 = year5.compareTo((java.lang.Object) timeSeries7);
        int int11 = year5.getYear();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        long long3 = year1.getLastMillisecond();
        int int4 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.next();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62104204800001L) + "'", long3 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries15.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day18, (double) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day18.next();
        timeSeries1.add(regularTimePeriod22, (double) 1560182340527L);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
//        java.lang.String str10 = day4.toString();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = day4.getLastMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test186");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 100, seriesChangeInfo8);
//        java.lang.Object obj10 = seriesChangeEvent9.getSource();
//        boolean boolean11 = month6.equals((java.lang.Object) seriesChangeEvent9);
//        java.lang.String str12 = seriesChangeEvent9.toString();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo13 = null;
//        seriesChangeEvent9.setSummary(seriesChangeInfo13);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182355128L + "'", long2 == 1560182355128L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + obj10 + "' != '" + (short) 100 + "'", obj10.equals((short) 100));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str12.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (byte) 100);
        boolean boolean4 = timeSeriesDataItem2.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem2.setSelected(false);
        int int8 = timeSeriesDataItem2.compareTo((java.lang.Object) 1560182341157L);
        timeSeriesDataItem2.setValue((java.lang.Number) 1560182349021L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (byte) 100);
//        boolean boolean4 = timeSeriesDataItem2.equals((java.lang.Object) (short) 10);
//        boolean boolean5 = timeSeriesDataItem2.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double10 = timeSeries9.getMaxY();
//        int int11 = timeSeries9.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 6);
//        long long15 = fixedMillisecond12.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double20 = timeSeries19.getMaxY();
//        java.util.List list21 = timeSeries19.getItems();
//        timeSeries19.removeAgedItems((long) (byte) 100, false);
//        boolean boolean25 = fixedMillisecond12.equals((java.lang.Object) (byte) 100);
//        int int26 = timeSeriesDataItem2.compareTo((java.lang.Object) fixedMillisecond12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond12.previous();
//        long long28 = fixedMillisecond12.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182355256L + "'", long15 == 1560182355256L);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list21);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560182355256L + "'", long28 == 1560182355256L);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries15.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day18, (double) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day18.next();
        timeSeries1.add(regularTimePeriod22, (double) 1560182340527L);
        try {
            org.jfree.data.time.TimeSeries timeSeries27 = timeSeries1.createCopy(10, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        long long20 = day18.getFirstMillisecond();
//        int int21 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day18);
//        long long22 = day18.getFirstMillisecond();
//        int int23 = day18.getMonth();
//        boolean boolean25 = day18.equals((java.lang.Object) 100.0f);
//        java.util.Calendar calendar26 = null;
//        try {
//            day18.peg(calendar26);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560150000000L + "'", long20 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560150000000L + "'", long22 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, "Mon Jun 10 08:59:05 PDT 2019", "10-June-2019");
        long long17 = timeSeries16.getMaximumItemAge();
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries13.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.Year year23 = month18.getYear();
        java.lang.String str24 = year23.toString();
        java.lang.String str25 = year23.toString();
        java.util.Calendar calendar26 = null;
        try {
            year23.peg(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "100" + "'", str24.equals("100"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "100" + "'", str25.equals("100"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        boolean boolean8 = timeSeriesDataItem6.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem6.setSelected(false);
        java.lang.Number number11 = timeSeriesDataItem6.getValue();
        timeSeries3.add(timeSeriesDataItem6, false);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener16);
        try {
            timeSeries3.delete(3, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 100 + "'", number11.equals((byte) 100));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        long long2 = year1.getSerialIndex();
        long long3 = year1.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year1.next();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        double double4 = timeSeries1.getMinY();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.removeAgedItems((long) (byte) 100, false);
        java.lang.Comparable comparable9 = timeSeries3.getKey();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 100);
        boolean boolean14 = timeSeriesDataItem12.equals((java.lang.Object) (short) 10);
        boolean boolean15 = timeSeriesDataItem12.isSelected();
        timeSeriesDataItem12.setValue((java.lang.Number) (byte) 100);
        timeSeries3.add(timeSeriesDataItem12, false);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str24 = timeSeries23.getDescription();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str29 = timeSeries28.getDescription();
        java.lang.String str30 = timeSeries28.getDomainDescription();
        java.util.Collection collection31 = timeSeries23.getTimePeriodsUniqueToOtherSeries(timeSeries28);
        timeSeries23.removeAgedItems((long) (-9999), true);
        int int35 = timeSeriesDataItem12.compareTo((java.lang.Object) (-9999));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 10.0d + "'", comparable9.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 100, seriesChangeInfo1);
        java.lang.Object obj3 = seriesChangeEvent2.getSource();
        java.lang.String str4 = seriesChangeEvent2.toString();
        java.lang.Object obj5 = seriesChangeEvent2.getSource();
        java.lang.String str6 = seriesChangeEvent2.toString();
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (short) 100 + "'", obj3.equals((short) 100));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + (short) 100 + "'", obj5.equals((short) 100));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str6.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        java.util.Date date5 = month2.getEnd();
        int int7 = month2.compareTo((java.lang.Object) 1560182345060L);
        java.lang.String str8 = month2.toString();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month2.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 100" + "'", str8.equals("October 100"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        java.util.Calendar calendar11 = null;
        try {
            day10.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries(comparable0, "", "org.jfree.data.general.SeriesException: ");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        int int3 = fixedMillisecond0.compareTo((java.lang.Object) 1560182342365L);
//        java.util.Date date4 = fixedMillisecond0.getTime();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182357336L + "'", long1 == 1560182357336L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertNotNull(date4);
//    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test202");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
//        java.util.Date date4 = fixedMillisecond1.getTime();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date4);
//        java.util.TimeZone timeZone7 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone7);
//        java.util.TimeZone timeZone9 = null;
//        try {
//            org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date4, timeZone9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560182357372L + "'", long3 == 1560182357372L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("October 100");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj4 = null;
        int int5 = month3.compareTo(obj4);
        java.util.Date date6 = month3.getEnd();
        int int8 = month3.compareTo((java.lang.Object) 1560182345060L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month3.next();
        org.jfree.data.time.Year year10 = month3.getYear();
        try {
            org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(0, year10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year10);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        long long7 = timeSeries3.getMaximumItemAge();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.addChangeListener(seriesChangeListener8);
        timeSeries3.setKey((java.lang.Comparable) 1560182347707L);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (byte) 100);
        boolean boolean4 = timeSeriesDataItem2.equals((java.lang.Object) (short) 10);
        boolean boolean5 = timeSeriesDataItem2.isSelected();
        java.lang.Object obj6 = timeSeriesDataItem2.clone();
        java.lang.Number number7 = null;
        timeSeriesDataItem2.setValue(number7);
        timeSeriesDataItem2.setSelected(true);
        timeSeriesDataItem2.setSelected(true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        java.util.Date date5 = month2.getEnd();
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        timeSeries3.removeAgedItems((long) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 100);
        boolean boolean14 = timeSeriesDataItem12.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem12.setSelected(false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.addOrUpdate(timeSeriesDataItem12);
        java.lang.String str18 = timeSeries3.getRangeDescription();
        java.lang.String str19 = timeSeries3.getDomainDescription();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        long long9 = fixedMillisecond6.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double14 = timeSeries13.getMaxY();
//        java.util.List list15 = timeSeries13.getItems();
//        timeSeries13.removeAgedItems((long) (byte) 100, false);
//        boolean boolean19 = fixedMillisecond6.equals((java.lang.Object) (byte) 100);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        long long24 = timeSeries23.getMaximumItemAge();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day25, (java.lang.Number) (byte) 100);
//        boolean boolean29 = timeSeriesDataItem27.equals((java.lang.Object) (short) 10);
//        boolean boolean30 = timeSeriesDataItem27.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries23.addOrUpdate(timeSeriesDataItem27);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries33.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month38, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month38.next();
//        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) month38);
//        boolean boolean43 = fixedMillisecond6.equals((java.lang.Object) month38);
//        java.util.Calendar calendar44 = null;
//        long long45 = fixedMillisecond6.getFirstMillisecond(calendar44);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182358086L + "'", long9 == 1560182358086L);
//        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list15);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560182358086L + "'", long45 == 1560182358086L);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        org.jfree.data.time.Year year5 = month2.getYear();
        java.lang.String str6 = year5.toString();
        long long7 = year5.getFirstMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            year5.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-59011603200000L) + "'", long7 == (-59011603200000L));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        int int6 = timeSeries3.getItemCount();
        timeSeries3.setDescription("Mon Jun 10 08:59:09 PDT 2019");
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        long long2 = year1.getSerialIndex();
        int int3 = year1.getYear();
        int int4 = year1.getYear();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("100");
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        long long9 = month8.getFirstMillisecond();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month8);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = month8.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-58987929600000L) + "'", long9 == (-58987929600000L));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        timeSeries3.setMaximumItemAge((long) 12);
        boolean boolean9 = timeSeries3.isEmpty();
        timeSeries3.setMaximumItemAge(10L);
        timeSeries3.setMaximumItemAge((long) (short) 100);
        timeSeries3.removeAgedItems((long) '4', false);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        java.util.Date date5 = month2.getEnd();
        java.util.Date date6 = month2.getStart();
        java.util.Calendar calendar7 = null;
        try {
            month2.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test217");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener18);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) (byte) 100);
//        boolean boolean26 = timeSeriesDataItem24.equals((java.lang.Object) (short) 10);
//        boolean boolean27 = timeSeriesDataItem24.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double32 = timeSeries31.getMaxY();
//        int int33 = timeSeries31.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (double) 6);
//        long long37 = fixedMillisecond34.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double42 = timeSeries41.getMaxY();
//        java.util.List list43 = timeSeries41.getItems();
//        timeSeries41.removeAgedItems((long) (byte) 100, false);
//        boolean boolean47 = fixedMillisecond34.equals((java.lang.Object) (byte) 100);
//        int int48 = timeSeriesDataItem24.compareTo((java.lang.Object) fixedMillisecond34);
//        try {
//            timeSeries3.add(timeSeriesDataItem24);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560182359083L + "'", long37 == 1560182359083L);
//        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list43);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        boolean boolean9 = timeSeries1.getNotify();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        int int13 = month12.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.next();
        long long15 = month12.getFirstMillisecond();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month12, 0.0d, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-58987929600000L) + "'", long15 == (-58987929600000L));
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        long long20 = day18.getFirstMillisecond();
//        int int21 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day18);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries3.getDataItem((int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560150000000L + "'", long20 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        long long2 = year1.getSerialIndex();
        long long3 = year1.getSerialIndex();
        java.lang.String str4 = year1.toString();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        long long2 = year1.getSerialIndex();
        long long3 = year1.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries9.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month14.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries7.addOrUpdate(regularTimePeriod17, (double) (short) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries7.addChangeListener(seriesChangeListener20);
        java.util.Collection collection22 = timeSeries7.getTimePeriods();
        timeSeries7.setRangeDescription("");
        int int25 = year1.compareTo((java.lang.Object) timeSeries7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries7.addOrUpdate(regularTimePeriod26, 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("0");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test223");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date6);
//        java.util.TimeZone timeZone10 = null;
//        java.util.Locale locale11 = null;
//        try {
//            org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date6, timeZone10, locale11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182359355L + "'", long2 == 1560182359355L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries13.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month18);
        java.lang.String str23 = timeSeries3.getRangeDescription();
        try {
            timeSeries3.delete(0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 100, seriesChangeInfo1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo3);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo5);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo7);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo9);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo11 = seriesChangeEvent2.getSummary();
        org.junit.Assert.assertNull(seriesChangeInfo11);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.lang.Object obj0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent(obj0, seriesChangeInfo1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
//        int int7 = month6.getYearValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 10.0f);
//        timeSeriesDataItem9.setSelected(false);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182359456L + "'", long2 == 1560182359456L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 6);
        long long8 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.Object obj6 = timeSeries3.clone();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) (byte) 100);
        boolean boolean11 = timeSeriesDataItem9.equals((java.lang.Object) (short) 10);
        boolean boolean12 = timeSeriesDataItem9.isSelected();
        java.lang.Object obj13 = timeSeriesDataItem9.clone();
        java.lang.Number number14 = null;
        timeSeriesDataItem9.setValue(number14);
        timeSeriesDataItem9.setSelected(true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate(timeSeriesDataItem9);
        try {
            boolean boolean19 = timeSeriesDataItem18.isSelected();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 9, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        java.util.Date date5 = month2.getEnd();
        int int7 = month2.compareTo((java.lang.Object) 1560182345060L);
        java.lang.String str8 = month2.toString();
        int int9 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 100" + "'", str8.equals("October 100"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        timeSeries3.removeAgedItems((long) 10, false);
        try {
            org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy(8, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        java.util.Date date5 = month2.getEnd();
        int int7 = month2.compareTo((java.lang.Object) 1560182345060L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.next();
        org.jfree.data.time.Year year9 = month2.getYear();
        java.util.Calendar calendar10 = null;
        try {
            month2.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(year9);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 6);
        int int9 = timeSeries1.getItemCount();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day4.next();
        java.util.Calendar calendar9 = null;
        try {
            day4.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
//        long long3 = year1.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, (java.lang.Number) (byte) 100);
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int18 = fixedMillisecond13.compareTo((java.lang.Object) "hi!");
//        long long19 = fixedMillisecond13.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond13.next();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double25 = timeSeries24.getMaxY();
//        int int26 = timeSeries24.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) 6);
//        long long30 = fixedMillisecond27.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond27.previous();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
//        timeSeries32.addChangeListener(seriesChangeListener33);
//        int int35 = timeSeries32.getMaximumItemCount();
//        int int36 = year1.compareTo((java.lang.Object) timeSeries32);
//        java.lang.Object obj37 = timeSeries32.clone();
//        timeSeries32.clear();
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62104204800001L) + "'", long3 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182361125L + "'", long15 == 1560182361125L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560182361125L + "'", long19 == 1560182361125L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560182361147L + "'", long30 == 1560182361147L);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2147483647 + "'", int35 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(obj37);
//    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test237");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        long long4 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
//        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
//        boolean boolean10 = timeSeriesDataItem7.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int18 = fixedMillisecond13.compareTo((java.lang.Object) "hi!");
//        java.util.Date date19 = fixedMillisecond13.getTime();
//        boolean boolean21 = fixedMillisecond13.equals((java.lang.Object) 1560182343140L);
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond13.getFirstMillisecond(calendar22);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) 1560182350372L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182361251L + "'", long15 == 1560182361251L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560182361251L + "'", long23 == 1560182361251L);
//    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        boolean boolean8 = fixedMillisecond0.equals((java.lang.Object) 1560182343140L);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond0.getLastMillisecond(calendar9);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182361306L + "'", long2 == 1560182361306L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560182361306L + "'", long10 == 1560182361306L);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Mon Jun 10 08:59:16 PDT 2019");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test240");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        boolean boolean11 = fixedMillisecond8.equals((java.lang.Object) 1560182341608L);
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond8.getFirstMillisecond(calendar12);
//        try {
//            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182361329L + "'", long2 == 1560182361329L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182361329L + "'", long9 == 1560182361329L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560182361329L + "'", long13 == 1560182361329L);
//    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
//        long long2 = year1.getSerialIndex();
//        long long3 = year1.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        long long5 = fixedMillisecond4.getMiddleMillisecond();
//        int int6 = year1.compareTo((java.lang.Object) fixedMillisecond4);
//        java.util.Calendar calendar7 = null;
//        fixedMillisecond4.peg(calendar7);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560182361360L + "'", long5 == 1560182361360L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean6 = timeSeries1.equals((java.lang.Object) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) seriesException11);
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException8.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(throwableArray13);
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.next();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182361438L + "'", long2 == 1560182361438L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
//        long long2 = year1.getSerialIndex();
//        long long3 = year1.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        long long5 = fixedMillisecond4.getMiddleMillisecond();
//        int int6 = year1.compareTo((java.lang.Object) fixedMillisecond4);
//        int int7 = year1.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year1.previous();
//        java.lang.String str9 = regularTimePeriod8.toString();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560182361464L + "'", long5 == 1560182361464L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1" + "'", str9.equals("-1"));
//    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test245");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        long long6 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        java.lang.String str8 = fixedMillisecond0.toString();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj12 = null;
//        int int13 = month11.compareTo(obj12);
//        org.jfree.data.time.Year year14 = month11.getYear();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        int int19 = year14.compareTo((java.lang.Object) timeSeries16);
//        boolean boolean20 = fixedMillisecond0.equals((java.lang.Object) timeSeries16);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj24 = null;
//        int int25 = month23.compareTo(obj24);
//        org.jfree.data.time.Year year26 = month23.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) year26);
//        java.util.Calendar calendar28 = null;
//        try {
//            year26.peg(calendar28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182361496L + "'", long2 == 1560182361496L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182361496L + "'", long6 == 1560182361496L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Mon Jun 10 08:59:21 PDT 2019" + "'", str8.equals("Mon Jun 10 08:59:21 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test246");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
//        java.util.TimeZone timeZone7 = null;
//        try {
//            org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date3, timeZone7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182361627L + "'", long2 == 1560182361627L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries3.addChangeListener(seriesChangeListener16);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries3.removeChangeListener(seriesChangeListener18);
        timeSeries3.setDomainDescription("");
        timeSeries3.setDomainDescription("0");
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj27 = null;
        int int28 = month26.compareTo(obj27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month26.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month26.next();
        try {
            timeSeries3.add(regularTimePeriod30, (java.lang.Number) 1560182344569L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period November 100 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.Object obj6 = timeSeries3.clone();
        timeSeries3.setDescription("100");
        timeSeries3.setRangeDescription("100");
        try {
            timeSeries3.delete((int) (byte) 0, (int) (byte) 1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        org.jfree.data.time.Year year5 = month2.getYear();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries7.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        int int10 = year5.compareTo((java.lang.Object) timeSeries7);
        java.util.Date date11 = year5.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year5.next();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        int int6 = timeSeries3.getItemCount();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3, seriesChangeInfo7);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long1);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries2.getDataItem(8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182361870L + "'", long1 == 1560182361870L);
//    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
//        java.lang.String str10 = day4.toString();
//        java.lang.String str11 = day4.toString();
//        java.lang.String str12 = day4.toString();
//        java.lang.String str13 = day4.toString();
//        long long14 = day4.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10-June-2019" + "'", str13.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560150000000L + "'", long14 == 1560150000000L);
//    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
//        timeSeries1.addChangeListener(seriesChangeListener2);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        boolean boolean6 = timeSeries1.equals((java.lang.Object) timePeriodFormatException5);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries12.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month17, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month17.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries10.addOrUpdate(regularTimePeriod20, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
//        timeSeries10.addChangeListener(seriesChangeListener23);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day25.previous();
//        long long27 = day25.getFirstMillisecond();
//        int int28 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) day25);
//        long long29 = day25.getFirstMillisecond();
//        long long30 = day25.getSerialIndex();
//        boolean boolean31 = timeSeries1.equals((java.lang.Object) long30);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560150000000L + "'", long27 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560150000000L + "'", long29 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43626L + "'", long30 == 43626L);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        timeSeries3.setNotify(false);
        long long7 = timeSeries3.getMaximumItemAge();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener8);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        java.util.Date date5 = month2.getEnd();
        int int7 = month2.compareTo((java.lang.Object) 1560182345060L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.next();
        org.jfree.data.time.Year year9 = month2.getYear();
        java.util.Calendar calendar10 = null;
        try {
            year9.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(year9);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test256");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 1560193199999L);
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
//        long long22 = fixedMillisecond18.getLastMillisecond();
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560182362288L + "'", long22 == 1560182362288L);
//    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
//        java.lang.String str10 = day4.toString();
//        int int11 = day4.getMonth();
//        java.lang.String str12 = day4.toString();
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Calendar calendar2 = null;
        try {
            day0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
//        java.util.TimeZone timeZone8 = null;
//        try {
//            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date6, timeZone8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182362655L + "'", long2 == 1560182362655L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        long long2 = year1.getSerialIndex();
        long long3 = year1.getSerialIndex();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year1.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean6 = timeSeries1.equals((java.lang.Object) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries11.addChangeListener(seriesChangeListener12);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean16 = timeSeries11.equals((java.lang.Object) timePeriodFormatException15);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.Throwable[] throwableArray21 = timePeriodFormatException8.getSuppressed();
        java.lang.Throwable[] throwableArray22 = timePeriodFormatException8.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(throwableArray22);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1560182345230L);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.String str3 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 1560182345230L + "'", obj2.equals(1560182345230L));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1560182345230]" + "'", str3.equals("org.jfree.data.event.SeriesChangeEvent[source=1560182345230]"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        java.util.Date date5 = month2.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) 1560182343140L);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month2.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        long long6 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        java.lang.String str8 = fixedMillisecond0.toString();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj12 = null;
//        int int13 = month11.compareTo(obj12);
//        org.jfree.data.time.Year year14 = month11.getYear();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        int int19 = year14.compareTo((java.lang.Object) timeSeries16);
//        boolean boolean20 = fixedMillisecond0.equals((java.lang.Object) timeSeries16);
//        long long21 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182362849L + "'", long2 == 1560182362849L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182362849L + "'", long6 == 1560182362849L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Mon Jun 10 08:59:22 PDT 2019" + "'", str8.equals("Mon Jun 10 08:59:22 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560182362849L + "'", long21 == 1560182362849L);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) "Mon Jun 10 08:59:13 PDT 2019", seriesChangeInfo1);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        long long3 = year1.getLastMillisecond();
        int int4 = year1.getYear();
        java.lang.String str5 = year1.toString();
        java.util.Calendar calendar6 = null;
        try {
            year1.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62104204800001L) + "'", long3 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0" + "'", str5.equals("0"));
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test267");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.previous();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double12 = timeSeries11.getMaxY();
//        java.util.List list13 = timeSeries11.getItems();
//        int int14 = timeSeries11.getItemCount();
//        boolean boolean15 = fixedMillisecond0.equals((java.lang.Object) timeSeries11);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) (byte) 100);
//        boolean boolean20 = timeSeriesDataItem18.equals((java.lang.Object) (short) 10);
//        boolean boolean21 = timeSeriesDataItem18.isSelected();
//        java.lang.Object obj22 = timeSeriesDataItem18.clone();
//        java.lang.Number number23 = null;
//        timeSeriesDataItem18.setValue(number23);
//        boolean boolean25 = timeSeriesDataItem18.isSelected();
//        boolean boolean26 = timeSeriesDataItem18.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries11.addOrUpdate(timeSeriesDataItem18);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = timeSeriesDataItem27.getPeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182363439L + "'", long2 == 1560182363439L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(obj22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) 'a', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries13.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month18.next();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar2 = null;
//        fixedMillisecond0.peg(calendar2);
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond0.getLastMillisecond(calendar4);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182363665L + "'", long1 == 1560182363665L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560182363665L + "'", long5 == 1560182363665L);
//    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
//        java.lang.String str14 = day8.toString();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
//        long long18 = year16.getLastMillisecond();
//        int int19 = year16.getYear();
//        boolean boolean20 = day8.equals((java.lang.Object) year16);
//        java.util.Calendar calendar21 = null;
//        try {
//            long long22 = year16.getLastMillisecond(calendar21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62104204800001L) + "'", long18 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.String str3 = month2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "October 100" + "'", str3.equals("October 100"));
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar2 = null;
//        fixedMillisecond0.peg(calendar2);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries9.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month14.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries7.addOrUpdate(regularTimePeriod17, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries7.addChangeListener(seriesChangeListener20);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
//        timeSeries7.removeChangeListener(seriesChangeListener22);
//        timeSeries7.setDomainDescription("");
//        int int26 = fixedMillisecond0.compareTo((java.lang.Object) "");
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182363699L + "'", long1 == 1560182363699L);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        org.jfree.data.time.Year year5 = month2.getYear();
        java.lang.String str6 = year5.toString();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double11 = timeSeries10.getMaxY();
        java.util.List list12 = timeSeries10.getItems();
        timeSeries10.setNotify(false);
        boolean boolean15 = timeSeries10.getNotify();
        long long16 = timeSeries10.getMaximumItemAge();
        long long17 = timeSeries10.getMaximumItemAge();
        boolean boolean18 = year5.equals((java.lang.Object) timeSeries10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = null;
        try {
            timeSeries10.delete(regularTimePeriod19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
//        long long2 = year1.getSerialIndex();
//        long long3 = year1.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries9.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month14.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries7.addOrUpdate(regularTimePeriod17, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries7.addChangeListener(seriesChangeListener20);
//        java.util.Collection collection22 = timeSeries7.getTimePeriods();
//        timeSeries7.setRangeDescription("");
//        int int25 = year1.compareTo((java.lang.Object) timeSeries7);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double30 = timeSeries29.getMaxY();
//        java.util.List list31 = timeSeries29.getItems();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day32, (java.lang.Number) (byte) 100);
//        boolean boolean36 = timeSeriesDataItem34.equals((java.lang.Object) (short) 10);
//        timeSeries29.add(timeSeriesDataItem34);
//        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year39.next();
//        long long41 = year39.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries43.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day46, (java.lang.Number) (byte) 100);
//        timeSeries43.add((org.jfree.data.time.RegularTimePeriod) day46, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar52 = null;
//        long long53 = fixedMillisecond51.getMiddleMillisecond(calendar52);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException55 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int56 = fixedMillisecond51.compareTo((java.lang.Object) "hi!");
//        long long57 = fixedMillisecond51.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = fixedMillisecond51.next();
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double63 = timeSeries62.getMaxY();
//        int int64 = timeSeries62.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries62.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65, (double) 6);
//        long long68 = fixedMillisecond65.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = fixedMillisecond65.previous();
//        org.jfree.data.time.TimeSeries timeSeries70 = timeSeries43.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond65);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener71 = null;
//        timeSeries70.addChangeListener(seriesChangeListener71);
//        int int73 = timeSeries70.getMaximumItemCount();
//        int int74 = year39.compareTo((java.lang.Object) timeSeries70);
//        java.lang.Object obj75 = timeSeries70.clone();
//        boolean boolean76 = timeSeriesDataItem34.equals((java.lang.Object) timeSeries70);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries7.addOrUpdate(timeSeriesDataItem34);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list31);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-62104204800001L) + "'", long41 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560182363765L + "'", long53 == 1560182363765L);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560182363765L + "'", long57 == 1560182363765L);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertEquals((double) double63, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 1560182363766L + "'", long68 == 1560182363766L);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertNotNull(timeSeries70);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2147483647 + "'", int73 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
//        org.junit.Assert.assertNotNull(obj75);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
//    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
//        java.lang.String str10 = day4.toString();
//        long long11 = day4.getSerialIndex();
//        long long12 = day4.getLastMillisecond();
//        int int13 = day4.getMonth();
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560236399999L + "'", long12 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date6);
//        java.util.TimeZone timeZone10 = null;
//        try {
//            org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date6, timeZone10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182364762L + "'", long2 == 1560182364762L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false);
        int int2 = timeSeries1.getItemCount();
        int int3 = timeSeries1.getItemCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: hi!");
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        long long15 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double21 = timeSeries20.getMaxY();
//        int int22 = timeSeries20.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 6);
//        long long26 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond23.previous();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
//        timeSeries28.addChangeListener(seriesChangeListener29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day31, (java.lang.Number) (byte) 100);
//        boolean boolean35 = timeSeriesDataItem33.equals((java.lang.Object) (short) 10);
//        timeSeriesDataItem33.setSelected(false);
//        int int39 = timeSeriesDataItem33.compareTo((java.lang.Object) 1560182341157L);
//        java.lang.Number number40 = timeSeriesDataItem33.getValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries28.addOrUpdate(timeSeriesDataItem33);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = null;
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries28.getDataItem(regularTimePeriod42);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182364848L + "'", long11 == 1560182364848L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182364848L + "'", long15 == 1560182364848L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182364849L + "'", long26 == 1560182364849L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + number40 + "' != '" + (byte) 100 + "'", number40.equals((byte) 100));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(4);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) -1, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        int int2 = year1.getYear();
        java.util.Calendar calendar3 = null;
        try {
            year1.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
//        java.lang.String str10 = day4.toString();
//        int int11 = day4.getMonth();
//        long long12 = day4.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560150000000L + "'", long12 == 1560150000000L);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        try {
            timeSeries1.delete((int) (byte) 10, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        java.util.List list8 = timeSeries3.getItems();
//        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond12.getMiddleMillisecond(calendar13);
//        java.util.Date date15 = fixedMillisecond12.getTime();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date15);
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date15, timeZone18);
//        java.util.TimeZone timeZone20 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone20);
//        java.util.TimeZone timeZone22 = null;
//        try {
//            org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date15, timeZone22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560182365182L + "'", long14 == 1560182365182L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test287");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day4.previous();
//        long long11 = day4.getFirstMillisecond();
//        long long12 = day4.getLastMillisecond();
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560150000000L + "'", long11 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560236399999L + "'", long12 == 1560236399999L);
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        long long7 = timeSeries3.getMaximumItemAge();
        java.util.List list8 = timeSeries3.getItems();
        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
        timeSeries3.setMaximumItemCount(11);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj4 = null;
        int int5 = month3.compareTo(obj4);
        org.jfree.data.time.Year year6 = month3.getYear();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(1, year6);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double12 = timeSeries11.getMaxY();
        java.util.List list13 = timeSeries11.getItems();
        timeSeries11.setNotify(false);
        boolean boolean16 = timeSeries11.getNotify();
        long long17 = timeSeries11.getMaximumItemAge();
        boolean boolean18 = month7.equals((java.lang.Object) timeSeries11);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 9223372036854775807L + "'", long17 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.previous();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double7 = timeSeries6.getMaxY();
//        java.util.Collection collection8 = timeSeries6.getTimePeriods();
//        java.lang.String str9 = timeSeries6.getRangeDescription();
//        timeSeries6.setMaximumItemAge((long) 12);
//        boolean boolean12 = timeSeries6.isEmpty();
//        timeSeries6.setMaximumItemAge(10L);
//        timeSeries6.setMaximumItemAge((long) (short) 100);
//        int int17 = fixedMillisecond0.compareTo((java.lang.Object) timeSeries6);
//        boolean boolean18 = timeSeries6.getNotify();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182365513L + "'", long1 == 1560182365513L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
//        timeSeries1.addChangeListener(seriesChangeListener2);
//        timeSeries1.removeAgedItems(1560182348434L, true);
//        java.beans.PropertyChangeListener propertyChangeListener7 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int15 = fixedMillisecond10.compareTo((java.lang.Object) "hi!");
//        java.util.Date date16 = fixedMillisecond10.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond10.previous();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double22 = timeSeries21.getMaxY();
//        java.util.List list23 = timeSeries21.getItems();
//        int int24 = timeSeries21.getItemCount();
//        boolean boolean25 = fixedMillisecond10.equals((java.lang.Object) timeSeries21);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries26 = timeSeries1.createCopy(regularTimePeriod9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560182365589L + "'", long12 == 1560182365589L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getItemCount();
        timeSeries3.setRangeDescription("October 100");
        timeSeries3.setNotify(true);
        java.util.List list10 = timeSeries3.getItems();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(list10);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
//        java.lang.Comparable comparable14 = timeSeries1.getKey();
//        java.util.Collection collection15 = timeSeries1.getTimePeriods();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries1.addChangeListener(seriesChangeListener16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond18.getMiddleMillisecond(calendar19);
//        java.util.Date date21 = fixedMillisecond18.getTime();
//        java.util.Calendar calendar22 = null;
//        fixedMillisecond18.peg(calendar22);
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond18.getFirstMillisecond(calendar24);
//        long long26 = fixedMillisecond18.getSerialIndex();
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 1560182343000L, true);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 9 + "'", comparable14.equals(9));
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560182365616L + "'", long20 == 1560182365616L);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560182365616L + "'", long25 == 1560182365616L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182365616L + "'", long26 == 1560182365616L);
//    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        long long15 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double21 = timeSeries20.getMaxY();
//        int int22 = timeSeries20.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 6);
//        long long26 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond23.previous();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        java.lang.Comparable comparable29 = timeSeries28.getKey();
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182365786L + "'", long11 == 1560182365786L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182365786L + "'", long15 == 1560182365786L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182365787L + "'", long26 == 1560182365787L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + comparable29 + "' != '" + 9 + "'", comparable29.equals(9));
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 6);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(0);
        long long11 = year10.getSerialIndex();
        long long12 = year10.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries18.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month23, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month23.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries16.addOrUpdate(regularTimePeriod26, (double) (short) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries16.addChangeListener(seriesChangeListener29);
        java.util.Collection collection31 = timeSeries16.getTimePeriods();
        timeSeries16.setRangeDescription("");
        int int34 = year10.compareTo((java.lang.Object) timeSeries16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year10.previous();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year10, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        long long6 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        java.lang.String str8 = fixedMillisecond0.toString();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj12 = null;
//        int int13 = month11.compareTo(obj12);
//        org.jfree.data.time.Year year14 = month11.getYear();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        int int19 = year14.compareTo((java.lang.Object) timeSeries16);
//        boolean boolean20 = fixedMillisecond0.equals((java.lang.Object) timeSeries16);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj24 = null;
//        int int25 = month23.compareTo(obj24);
//        org.jfree.data.time.Year year26 = month23.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) year26);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener30 = null;
//        timeSeries29.addChangeListener(seriesChangeListener30);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        boolean boolean34 = timeSeries29.equals((java.lang.Object) timePeriodFormatException33);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        timePeriodFormatException33.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
//        int int38 = year26.compareTo((java.lang.Object) timePeriodFormatException33);
//        java.util.Calendar calendar39 = null;
//        try {
//            long long40 = year26.getFirstMillisecond(calendar39);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182365987L + "'", long2 == 1560182365987L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182365987L + "'", long6 == 1560182365987L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Mon Jun 10 08:59:25 PDT 2019" + "'", str8.equals("Mon Jun 10 08:59:25 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        try {
            timeSeries1.delete(7, 1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        long long2 = year1.getSerialIndex();
        long long3 = year1.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries9.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month14.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries7.addOrUpdate(regularTimePeriod17, (double) (short) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries7.addChangeListener(seriesChangeListener20);
        java.util.Collection collection22 = timeSeries7.getTimePeriods();
        timeSeries7.setRangeDescription("");
        int int25 = year1.compareTo((java.lang.Object) timeSeries7);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries7);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo27 = seriesChangeEvent26.getSummary();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNull(seriesChangeInfo27);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getItemCount();
        double double6 = timeSeries3.getMinY();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3, seriesChangeInfo7);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        long long15 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double21 = timeSeries20.getMaxY();
//        int int22 = timeSeries20.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 6);
//        long long26 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond23.previous();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        int int29 = timeSeries28.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
//        java.util.Collection collection34 = timeSeries28.getTimePeriodsUniqueToOtherSeries(timeSeries33);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182366347L + "'", long11 == 1560182366347L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182366347L + "'", long15 == 1560182366347L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182366349L + "'", long26 == 1560182366349L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(collection34);
//    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test301");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
//        int int7 = month6.getYearValue();
//        long long8 = month6.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182366492L + "'", long2 == 1560182366492L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 24234L + "'", long8 == 24234L);
//    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        java.util.List list8 = timeSeries3.getItems();
//        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond12.getMiddleMillisecond(calendar13);
//        java.util.Date date15 = fixedMillisecond12.getTime();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date15);
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date15, timeZone18);
//        java.util.TimeZone timeZone20 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone20);
//        java.util.TimeZone timeZone22 = null;
//        try {
//            org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date15, timeZone22);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560182366517L + "'", long14 == 1560182366517L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.event.SeriesChangeEvent[source=1560182345230]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        long long6 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        java.lang.String str8 = fixedMillisecond0.toString();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj12 = null;
//        int int13 = month11.compareTo(obj12);
//        org.jfree.data.time.Year year14 = month11.getYear();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        int int19 = year14.compareTo((java.lang.Object) timeSeries16);
//        boolean boolean20 = fixedMillisecond0.equals((java.lang.Object) timeSeries16);
//        int int21 = timeSeries16.getMaximumItemCount();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182366538L + "'", long2 == 1560182366538L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182366538L + "'", long6 == 1560182366538L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Mon Jun 10 08:59:26 PDT 2019" + "'", str8.equals("Mon Jun 10 08:59:26 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
//    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day8);
//        java.util.Collection collection11 = timeSeries1.getTimePeriods();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond12.previous();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) 1560182357836L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560182366585L + "'", long13 == 1560182366585L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.next();
        long long7 = month2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58987929600000L) + "'", long7 == (-58987929600000L));
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        long long9 = fixedMillisecond6.getFirstMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond6.getMiddleMillisecond(calendar10);
//        long long12 = fixedMillisecond6.getSerialIndex();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182366717L + "'", long9 == 1560182366717L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182366717L + "'", long11 == 1560182366717L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560182366717L + "'", long12 == 1560182366717L);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        boolean boolean8 = timeSeriesDataItem6.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem6.setSelected(false);
        java.lang.Number number11 = timeSeriesDataItem6.getValue();
        timeSeries3.add(timeSeriesDataItem6, false);
        try {
            java.lang.Number number15 = timeSeries3.getValue((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 100 + "'", number11.equals((byte) 100));
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.Year year7 = month6.getYear();
//        long long8 = year7.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182366774L + "'", long2 == 1560182366774L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.setNotify(false);
        java.lang.String str8 = timeSeries3.getDomainDescription();
        timeSeries3.removeAgedItems((-62119972800001L), false);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
        java.lang.String str9 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        try {
            timeSeries3.update((-1), (java.lang.Number) 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries3.getTimePeriod(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
        java.lang.String str9 = timeSeries3.getDescription();
        double double10 = timeSeries3.getMinY();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = null;
        try {
            timeSeries3.delete(regularTimePeriod11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 6.0d + "'", double10 == 6.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.Object obj6 = timeSeries3.clone();
        timeSeries3.setDescription("100");
        try {
            timeSeries3.update((int) (short) 1, (java.lang.Number) 24234L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean6 = timeSeries1.equals((java.lang.Object) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) seriesException11);
        java.lang.String str13 = timePeriodFormatException8.toString();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.event.SeriesChangeEvent[source=100]"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean6 = timeSeries1.equals((java.lang.Object) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries11.addChangeListener(seriesChangeListener12);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean16 = timeSeries11.equals((java.lang.Object) timePeriodFormatException15);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries22.addChangeListener(seriesChangeListener23);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean27 = timeSeries22.equals((java.lang.Object) timePeriodFormatException26);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        org.jfree.data.general.SeriesException seriesException33 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray34 = seriesException33.getSuppressed();
        timePeriodFormatException29.addSuppressed((java.lang.Throwable) seriesException33);
        org.jfree.data.general.SeriesException seriesException37 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException29.addSuppressed((java.lang.Throwable) seriesException37);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(throwableArray34);
    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test317");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener18);
//        timeSeries3.setDescription("Mon Jun 10 08:59:05 PDT 2019");
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries23.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day26, (java.lang.Number) (byte) 100);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) day26, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate31 = day26.getSerialDate();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(serialDate31);
//        java.lang.String str33 = day32.toString();
//        java.lang.Number number34 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day32);
//        timeSeries3.setMaximumItemCount((int) (short) 100);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "10-June-2019" + "'", str33.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 10.0d + "'", number34.equals(10.0d));
//    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 1560182343089L);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.removeAgedItems(1560182348434L, true);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        java.lang.Object obj9 = timeSeries1.clone();
        org.junit.Assert.assertNotNull(obj9);
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        long long6 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond0.previous();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182367767L + "'", long2 == 1560182367767L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182367767L + "'", long6 == 1560182367767L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
//        java.lang.String str11 = day10.toString();
//        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate12);
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 0, 3, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        timeSeries3.setNotify(false);
        java.lang.Comparable comparable11 = timeSeries3.getKey();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 10.0d + "'", comparable11.equals(10.0d));
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        long long6 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        java.lang.String str8 = fixedMillisecond0.toString();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj12 = null;
//        int int13 = month11.compareTo(obj12);
//        org.jfree.data.time.Year year14 = month11.getYear();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        int int19 = year14.compareTo((java.lang.Object) timeSeries16);
//        boolean boolean20 = fixedMillisecond0.equals((java.lang.Object) timeSeries16);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj24 = null;
//        int int25 = month23.compareTo(obj24);
//        org.jfree.data.time.Year year26 = month23.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) year26);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener30 = null;
//        timeSeries29.addChangeListener(seriesChangeListener30);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        boolean boolean34 = timeSeries29.equals((java.lang.Object) timePeriodFormatException33);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        timePeriodFormatException33.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
//        int int38 = year26.compareTo((java.lang.Object) timePeriodFormatException33);
//        java.lang.Throwable[] throwableArray39 = timePeriodFormatException33.getSuppressed();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182367892L + "'", long2 == 1560182367892L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182367892L + "'", long6 == 1560182367892L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Mon Jun 10 08:59:27 PDT 2019" + "'", str8.equals("Mon Jun 10 08:59:27 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(throwableArray39);
//    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getMiddleMillisecond(calendar17);
//        try {
//            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (java.lang.Number) 1560182367767L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560182368023L + "'", long18 == 1560182368023L);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        timeSeries1.fireSeriesChanged();
        timeSeries1.setDescription("Mon Jun 10 08:59:09 PDT 2019");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener12);
        double double14 = timeSeries1.getMinY();
        timeSeries1.setMaximumItemCount((int) (short) 10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 9.223372036854776E18d + "'", double14 == 9.223372036854776E18d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (byte) 100);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
//        long long14 = day8.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, (java.lang.Number) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeriesDataItem16.getPeriod();
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
//        java.util.TimeZone timeZone6 = null;
//        java.util.Locale locale7 = null;
//        try {
//            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date3, timeZone6, locale7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182368319L + "'", long2 == 1560182368319L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double9 = timeSeries8.getMaxY();
        int int10 = timeSeries8.getItemCount();
        timeSeries8.setRangeDescription("October 100");
        java.util.Collection collection13 = timeSeries8.getTimePeriods();
        long long14 = timeSeries8.getMaximumItemAge();
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        try {
            timeSeries3.delete((int) (byte) 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection15);
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test332");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
//        java.lang.String str14 = day8.toString();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
//        long long18 = year16.getLastMillisecond();
//        int int19 = year16.getYear();
//        boolean boolean20 = day8.equals((java.lang.Object) year16);
//        long long21 = day8.getLastMillisecond();
//        java.util.Calendar calendar22 = null;
//        try {
//            long long23 = day8.getLastMillisecond(calendar22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62104204800001L) + "'", long18 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560236399999L + "'", long21 == 1560236399999L);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getStart();
        java.util.TimeZone timeZone2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Mon Jun 10 08:59:25 PDT 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        java.util.Date date3 = regularTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date3, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.setNotify(false);
        boolean boolean8 = timeSeries3.getNotify();
        boolean boolean9 = timeSeries3.isEmpty();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (byte) 100);
//        boolean boolean4 = timeSeriesDataItem2.equals((java.lang.Object) (short) 10);
//        boolean boolean5 = timeSeriesDataItem2.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double10 = timeSeries9.getMaxY();
//        int int11 = timeSeries9.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 6);
//        long long15 = fixedMillisecond12.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double20 = timeSeries19.getMaxY();
//        java.util.List list21 = timeSeries19.getItems();
//        timeSeries19.removeAgedItems((long) (byte) 100, false);
//        boolean boolean25 = fixedMillisecond12.equals((java.lang.Object) (byte) 100);
//        int int26 = timeSeriesDataItem2.compareTo((java.lang.Object) fixedMillisecond12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond12.previous();
//        java.util.Calendar calendar28 = null;
//        fixedMillisecond12.peg(calendar28);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) '#');
//        long long32 = fixedMillisecond12.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182369646L + "'", long15 == 1560182369646L);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list21);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182369646L + "'", long32 == 1560182369646L);
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        org.jfree.data.time.Year year5 = month2.getYear();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries7.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        int int10 = year5.compareTo((java.lang.Object) timeSeries7);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries7.getDataItem(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        java.lang.Object obj5 = timeSeries3.clone();
        try {
            timeSeries3.update(0, (java.lang.Number) 1560182363809L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((int) (byte) 1, 9999);
        try {
            java.lang.Number number12 = timeSeries10.getValue((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        boolean boolean8 = timeSeries3.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries10.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries14.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day17.previous();
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) day17, (double) 6);
//        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) day17, 0.0d);
//        long long23 = day17.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = day17.next();
//        timeSeries3.add(regularTimePeriod26, (double) 1560182347444L);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560236399999L + "'", long23 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 100, (int) (short) 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.setNotify(false);
        boolean boolean8 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.createCopy((int) (byte) 0, 4);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries11.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(timeSeries11);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        timeSeries3.removeAgedItems((long) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 100);
        boolean boolean14 = timeSeriesDataItem12.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem12.setSelected(false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.addOrUpdate(timeSeriesDataItem12);
        int int18 = timeSeries3.getMaximumItemCount();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2147483647 + "'", int18 == 2147483647);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getMaximumItemCount();
        try {
            timeSeries3.setMaximumItemCount((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((int) (byte) 1, 9999);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long15 = timeSeries14.getMaximumItemAge();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) (byte) 100);
        boolean boolean20 = timeSeriesDataItem18.equals((java.lang.Object) (short) 10);
        boolean boolean21 = timeSeriesDataItem18.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries14.addOrUpdate(timeSeriesDataItem18);
        java.util.Collection collection23 = timeSeries14.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries10.addAndOrUpdate(timeSeries14);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day25, (java.lang.Number) (byte) 100);
        boolean boolean29 = timeSeriesDataItem27.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem27.setSelected(false);
        int int33 = timeSeriesDataItem27.compareTo((java.lang.Object) 1560182341157L);
        timeSeriesDataItem27.setSelected(true);
        try {
            timeSeries10.add(timeSeriesDataItem27);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 10-June-2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        long long15 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double21 = timeSeries20.getMaxY();
//        int int22 = timeSeries20.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 6);
//        long long26 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond23.previous();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
//        timeSeries28.addChangeListener(seriesChangeListener29);
//        boolean boolean31 = timeSeries28.isEmpty();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = null;
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries28.getDataItem(regularTimePeriod32);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182370301L + "'", long11 == 1560182370301L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182370301L + "'", long15 == 1560182370301L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182370317L + "'", long26 == 1560182370317L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.SerialDate serialDate13 = day12.getSerialDate();
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.removeAgedItems((long) (byte) 100, false);
        java.util.List list9 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double14 = timeSeries13.getMaxY();
        int int15 = timeSeries13.getItemCount();
        timeSeries13.setMaximumItemCount(1);
        boolean boolean18 = timeSeries3.equals((java.lang.Object) timeSeries13);
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        timeSeries3.setDescription("Mon Jun 10 08:59:09 PDT 2019");
        try {
            java.lang.Number number23 = timeSeries3.getValue((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(collection19);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        java.util.TimeZone timeZone2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries3.addChangeListener(seriesChangeListener16);
        java.util.Collection collection18 = timeSeries3.getTimePeriods();
        timeSeries3.setRangeDescription("");
        try {
            org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.createCopy(0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(collection18);
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
//        long long2 = year1.getSerialIndex();
//        long long3 = year1.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        long long5 = fixedMillisecond4.getMiddleMillisecond();
//        int int6 = year1.compareTo((java.lang.Object) fixedMillisecond4);
//        int int7 = year1.getYear();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = year1.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560182370707L + "'", long5 == 1560182370707L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 10, 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        long long10 = fixedMillisecond8.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182370723L + "'", long2 == 1560182370723L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182370723L + "'", long9 == 1560182370723L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560182370723L + "'", long10 == 1560182370723L);
//    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        long long9 = fixedMillisecond6.getFirstMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond6.getFirstMillisecond(calendar10);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182370802L + "'", long9 == 1560182370802L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182370802L + "'", long11 == 1560182370802L);
//    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        long long15 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double21 = timeSeries20.getMaxY();
//        int int22 = timeSeries20.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 6);
//        long long26 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond23.previous();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
//        timeSeries28.addChangeListener(seriesChangeListener29);
//        timeSeries28.setMaximumItemAge(1560182353546L);
//        java.lang.String str33 = timeSeries28.getDomainDescription();
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182370814L + "'", long11 == 1560182370814L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182370814L + "'", long15 == 1560182370814L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182370815L + "'", long26 == 1560182370815L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Time" + "'", str33.equals("Time"));
//    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double7 = timeSeries6.getMaxY();
        java.util.Collection collection8 = timeSeries6.getTimePeriods();
        java.lang.String str9 = timeSeries6.getRangeDescription();
        timeSeries6.setMaximumItemAge((long) 12);
        int int12 = month2.compareTo((java.lang.Object) 12);
        java.lang.String str13 = month2.toString();
        long long14 = month2.getFirstMillisecond();
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "October 100" + "'", str13.equals("October 100"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-58987929600000L) + "'", long14 == (-58987929600000L));
    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.previous();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double12 = timeSeries11.getMaxY();
//        java.util.List list13 = timeSeries11.getItems();
//        int int14 = timeSeries11.getItemCount();
//        boolean boolean15 = fixedMillisecond0.equals((java.lang.Object) timeSeries11);
//        java.util.Calendar calendar16 = null;
//        fixedMillisecond0.peg(calendar16);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182371478L + "'", long2 == 1560182371478L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test359");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        java.util.List list8 = timeSeries3.getItems();
//        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int18 = fixedMillisecond13.compareTo((java.lang.Object) "hi!");
//        java.util.Date date19 = fixedMillisecond13.getTime();
//        java.util.TimeZone timeZone20 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date19, timeZone20);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182371509L + "'", long15 == 1560182371509L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        long long2 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1577865599999L + "'", long2 == 1577865599999L);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getItemCount();
        timeSeries3.setRangeDescription("October 100");
        timeSeries3.setNotify(false);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries3.getTimePeriod(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean6 = timeSeries1.equals((java.lang.Object) timePeriodFormatException5);
        java.util.List list7 = timeSeries1.getItems();
        timeSeries1.setNotify(false);
        try {
            java.lang.Number number11 = timeSeries1.getValue((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false);
        timeSeries1.setKey((java.lang.Comparable) 100.0f);
        java.lang.Object obj4 = timeSeries1.clone();
        boolean boolean5 = timeSeries1.isEmpty();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(1);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year7, (double) 1560182355828L, true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year7.next();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("0");
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.setNotify(false);
        java.lang.String str8 = timeSeries3.getDomainDescription();
        double double9 = timeSeries3.getMaxY();
        boolean boolean10 = timeSeries3.isEmpty();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (byte) 100);
//        boolean boolean4 = timeSeriesDataItem2.equals((java.lang.Object) (short) 10);
//        boolean boolean5 = timeSeriesDataItem2.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double10 = timeSeries9.getMaxY();
//        int int11 = timeSeries9.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 6);
//        long long15 = fixedMillisecond12.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double20 = timeSeries19.getMaxY();
//        java.util.List list21 = timeSeries19.getItems();
//        timeSeries19.removeAgedItems((long) (byte) 100, false);
//        boolean boolean25 = fixedMillisecond12.equals((java.lang.Object) (byte) 100);
//        int int26 = timeSeriesDataItem2.compareTo((java.lang.Object) fixedMillisecond12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond12.previous();
//        java.util.Calendar calendar28 = null;
//        fixedMillisecond12.peg(calendar28);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) '#');
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond12.previous();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182371843L + "'", long15 == 1560182371843L);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list21);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
//        java.util.Calendar calendar10 = null;
//        try {
//            long long11 = year7.getLastMillisecond(calendar10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182371897L + "'", long2 == 1560182371897L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        org.jfree.data.time.Year year5 = month2.getYear();
        int int6 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        long long6 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        java.lang.String str8 = fixedMillisecond0.toString();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj12 = null;
//        int int13 = month11.compareTo(obj12);
//        org.jfree.data.time.Year year14 = month11.getYear();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        int int19 = year14.compareTo((java.lang.Object) timeSeries16);
//        boolean boolean20 = fixedMillisecond0.equals((java.lang.Object) timeSeries16);
//        java.util.List list21 = timeSeries16.getItems();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182372039L + "'", long2 == 1560182372039L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182372039L + "'", long6 == 1560182372039L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Mon Jun 10 08:59:32 PDT 2019" + "'", str8.equals("Mon Jun 10 08:59:32 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(list21);
//    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        timeSeries3.setRangeDescription("October 100");
//        timeSeries3.setNotify(true);
//        java.lang.String str10 = timeSeries3.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
//        java.util.Date date14 = fixedMillisecond11.getEnd();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 1560182363084L, true);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNull(str10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560182372092L + "'", long13 == 1560182372092L);
//        org.junit.Assert.assertNotNull(date14);
//    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        timeSeries1.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries12.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) day19, (double) 6);
//        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) day19, 0.0d);
//        long long25 = day19.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day19.next();
//        org.jfree.data.time.SerialDate serialDate29 = day19.getSerialDate();
//        boolean boolean30 = timeSeries1.equals((java.lang.Object) day19);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar32 = null;
//        long long33 = fixedMillisecond31.getMiddleMillisecond(calendar32);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int36 = fixedMillisecond31.compareTo((java.lang.Object) "hi!");
//        java.util.Date date37 = fixedMillisecond31.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond31.previous();
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double43 = timeSeries42.getMaxY();
//        java.util.List list44 = timeSeries42.getItems();
//        int int45 = timeSeries42.getItemCount();
//        boolean boolean46 = fixedMillisecond31.equals((java.lang.Object) timeSeries42);
//        java.util.Calendar calendar47 = null;
//        long long48 = fixedMillisecond31.getLastMillisecond(calendar47);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (double) 1560182363318L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560236399999L + "'", long25 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560182372110L + "'", long33 == 1560182372110L);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560182372110L + "'", long48 == 1560182372110L);
//    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(0);
        long long3 = year2.getSerialIndex();
        int int4 = year2.getYear();
        boolean boolean6 = year2.equals((java.lang.Object) 1560182347531L);
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month((int) 'a', year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.removeAgedItems((long) (byte) 100, false);
        java.util.List list9 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double14 = timeSeries13.getMaxY();
        int int15 = timeSeries13.getItemCount();
        timeSeries13.setMaximumItemCount(1);
        boolean boolean18 = timeSeries3.equals((java.lang.Object) timeSeries13);
        java.lang.String str19 = timeSeries13.getDescription();
        double double20 = timeSeries13.getMinY();
        try {
            timeSeries13.delete(9, 12, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
//        java.lang.String str4 = timeSeries3.getDescription();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
//        java.lang.Object obj6 = timeSeries3.clone();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) (byte) 100);
//        boolean boolean11 = timeSeriesDataItem9.equals((java.lang.Object) (short) 10);
//        boolean boolean12 = timeSeriesDataItem9.isSelected();
//        java.lang.Object obj13 = timeSeriesDataItem9.clone();
//        java.lang.Number number14 = null;
//        timeSeriesDataItem9.setValue(number14);
//        timeSeriesDataItem9.setSelected(true);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate(timeSeriesDataItem9);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries20.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) day23, (double) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day23.next();
//        long long28 = day23.getMiddleMillisecond();
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj33 = null;
//        int int34 = month32.compareTo(obj33);
//        org.jfree.data.time.Year year35 = month32.getYear();
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(1, year35);
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day23, (org.jfree.data.time.RegularTimePeriod) year35);
//        java.util.Calendar calendar38 = null;
//        try {
//            long long39 = day23.getMiddleMillisecond(calendar38);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560193199999L + "'", long28 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(year35);
//        org.junit.Assert.assertNotNull(timeSeries37);
//    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test375");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getLastMillisecond(calendar2);
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond0.peg(calendar4);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1560182362288L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        long long9 = fixedMillisecond8.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.previous();
//        long long11 = fixedMillisecond8.getFirstMillisecond();
//        java.lang.String str12 = fixedMillisecond8.toString();
//        int int13 = timeSeriesDataItem7.compareTo((java.lang.Object) fixedMillisecond8);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182372425L + "'", long1 == 1560182372425L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560182372425L + "'", long3 == 1560182372425L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182372426L + "'", long9 == 1560182372426L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182372426L + "'", long11 == 1560182372426L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Mon Jun 10 08:59:32 PDT 2019" + "'", str12.equals("Mon Jun 10 08:59:32 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test376");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
//        long long14 = day8.getLastMillisecond();
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = day8.getLastMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (byte) 100);
        boolean boolean4 = timeSeriesDataItem2.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem2.setSelected(false);
        int int8 = timeSeriesDataItem2.compareTo((java.lang.Object) 1560182341157L);
        timeSeriesDataItem2.setSelected(true);
        timeSeriesDataItem2.setSelected(true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries7);
        java.lang.String str10 = seriesChangeEvent9.toString();
        boolean boolean11 = month2.equals((java.lang.Object) seriesChangeEvent9);
        int int12 = month2.getMonth();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = month2.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-58987929600000L) + "'", long3 == (-58987929600000L));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test379");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        long long6 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        java.lang.String str8 = fixedMillisecond0.toString();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj12 = null;
//        int int13 = month11.compareTo(obj12);
//        org.jfree.data.time.Year year14 = month11.getYear();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        int int19 = year14.compareTo((java.lang.Object) timeSeries16);
//        boolean boolean20 = fixedMillisecond0.equals((java.lang.Object) timeSeries16);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond0.getMiddleMillisecond(calendar21);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182372796L + "'", long2 == 1560182372796L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182372796L + "'", long6 == 1560182372796L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Mon Jun 10 08:59:32 PDT 2019" + "'", str8.equals("Mon Jun 10 08:59:32 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560182372796L + "'", long22 == 1560182372796L);
//    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Mon Jun 10 08:59:25 PDT 2019");
    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test381");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        java.util.List list8 = timeSeries3.getItems();
//        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
//        java.util.Date date16 = fixedMillisecond13.getTime();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date16);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date16);
//        java.util.TimeZone timeZone20 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date16, timeZone20);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182373093L + "'", long15 == 1560182373093L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        long long9 = day4.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day4.next();
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getStart();
//        long long2 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182373223L + "'", long2 == 1560182373223L);
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj8 = null;
        int int9 = month7.compareTo(obj8);
        java.util.Date date10 = month7.getEnd();
        int int12 = month7.compareTo((java.lang.Object) 1560182345060L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month7.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month7, (double) 1560182354231L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = null;
        try {
            timeSeries1.add(regularTimePeriod16, (java.lang.Number) 1560182344001L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.addChangeListener(seriesChangeListener8);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener10);
//        int int12 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
//        java.util.Date date16 = fixedMillisecond13.getTime();
//        java.util.Calendar calendar17 = null;
//        fixedMillisecond13.peg(calendar17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond13.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) 1.0f);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int27 = fixedMillisecond22.compareTo((java.lang.Object) "hi!");
//        long long28 = fixedMillisecond22.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond22.next();
//        java.lang.String str30 = fixedMillisecond22.toString();
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj34 = null;
//        int int35 = month33.compareTo(obj34);
//        org.jfree.data.time.Year year36 = month33.getYear();
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries38.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        int int41 = year36.compareTo((java.lang.Object) timeSeries38);
//        boolean boolean42 = fixedMillisecond22.equals((java.lang.Object) timeSeries38);
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj46 = null;
//        int int47 = month45.compareTo(obj46);
//        org.jfree.data.time.Year year48 = month45.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries38.getDataItem((org.jfree.data.time.RegularTimePeriod) year48);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year48, (java.lang.Number) 1560182356277L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182373265L + "'", long15 == 1560182373265L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560182373267L + "'", long24 == 1560182373267L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560182373267L + "'", long28 == 1560182373267L);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Mon Jun 10 08:59:33 PDT 2019" + "'", str30.equals("Mon Jun 10 08:59:33 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(year36);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertNotNull(year48);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        timeSeries3.setRangeDescription("");
        boolean boolean8 = timeSeries3.getNotify();
        try {
            timeSeries3.delete(0, 2, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        long long15 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double21 = timeSeries20.getMaxY();
//        int int22 = timeSeries20.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 6);
//        long long26 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond23.previous();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
//        timeSeries28.addChangeListener(seriesChangeListener29);
//        boolean boolean31 = timeSeries28.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond32.getMiddleMillisecond(calendar33);
//        java.util.Date date35 = fixedMillisecond32.getTime();
//        java.util.Calendar calendar36 = null;
//        fixedMillisecond32.peg(calendar36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond32.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = fixedMillisecond32.next();
//        timeSeries28.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 1560182352357L);
//        timeSeries28.removeAgedItems(1560182344569L, false);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries47 = timeSeries28.createCopy((-9999), (int) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182373302L + "'", long11 == 1560182373302L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182373302L + "'", long15 == 1560182373302L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182373304L + "'", long26 == 1560182373304L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560182373309L + "'", long34 == 1560182373309L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test388");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        long long20 = day18.getFirstMillisecond();
//        int int21 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day18);
//        long long22 = day18.getFirstMillisecond();
//        int int23 = day18.getMonth();
//        int int24 = day18.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day18.previous();
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560150000000L + "'", long20 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560150000000L + "'", long22 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (byte) 100);
        boolean boolean4 = timeSeriesDataItem2.equals((java.lang.Object) (short) 10);
        boolean boolean5 = timeSeriesDataItem2.isSelected();
        java.lang.Object obj6 = timeSeriesDataItem2.clone();
        java.lang.Number number7 = null;
        timeSeriesDataItem2.setValue(number7);
        java.lang.Object obj9 = timeSeriesDataItem2.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(obj9);
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        timeSeries3.removeAgedItems((long) 10, false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener8);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        int int13 = month12.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.next();
//        timeSeries3.add(regularTimePeriod14, (double) 1560182345775L, false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        long long19 = fixedMillisecond18.getLastMillisecond();
//        java.util.Calendar calendar20 = null;
//        fixedMillisecond18.peg(calendar20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int27 = fixedMillisecond22.compareTo((java.lang.Object) "hi!");
//        java.util.Date date28 = fixedMillisecond22.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        java.lang.Object obj31 = timeSeries30.clone();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day32, (java.lang.Number) (byte) 100);
//        boolean boolean36 = timeSeriesDataItem34.equals((java.lang.Object) (short) 10);
//        boolean boolean37 = timeSeriesDataItem34.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double42 = timeSeries41.getMaxY();
//        int int43 = timeSeries41.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries41.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) 6);
//        long long47 = fixedMillisecond44.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double52 = timeSeries51.getMaxY();
//        java.util.List list53 = timeSeries51.getItems();
//        timeSeries51.removeAgedItems((long) (byte) 100, false);
//        boolean boolean57 = fixedMillisecond44.equals((java.lang.Object) (byte) 100);
//        int int58 = timeSeriesDataItem34.compareTo((java.lang.Object) fixedMillisecond44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = fixedMillisecond44.previous();
//        java.util.Calendar calendar60 = null;
//        fixedMillisecond44.peg(calendar60);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (double) '#');
//        try {
//            timeSeries30.add(timeSeriesDataItem63);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560182373493L + "'", long19 == 1560182373493L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560182373493L + "'", long24 == 1560182373493L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertNotNull(obj31);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560182373496L + "'", long47 == 1560182373496L);
//        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list53);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod59);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.removeAgedItems((long) (byte) 100, false);
        java.lang.Comparable comparable9 = timeSeries3.getKey();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj13 = null;
        int int14 = month12.compareTo(obj13);
        java.util.Date date15 = month12.getEnd();
        java.util.Date date16 = month12.getStart();
        boolean boolean17 = timeSeries3.equals((java.lang.Object) date16);
        boolean boolean18 = timeSeries3.getNotify();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 10.0d + "'", comparable9.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((int) (byte) 1, 9999);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long15 = timeSeries14.getMaximumItemAge();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) (byte) 100);
        boolean boolean20 = timeSeriesDataItem18.equals((java.lang.Object) (short) 10);
        boolean boolean21 = timeSeriesDataItem18.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries14.addOrUpdate(timeSeriesDataItem18);
        java.util.Collection collection23 = timeSeries14.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries10.addAndOrUpdate(timeSeries14);
        try {
            timeSeries14.update((int) ' ', (java.lang.Number) 1560182350172L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertNotNull(timeSeries24);
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date6);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date6);
//        java.util.TimeZone timeZone11 = null;
//        try {
//            org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date6, timeZone11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182373560L + "'", long2 == 1560182373560L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        long long6 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        java.lang.String str8 = fixedMillisecond0.toString();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj12 = null;
//        int int13 = month11.compareTo(obj12);
//        org.jfree.data.time.Year year14 = month11.getYear();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        int int19 = year14.compareTo((java.lang.Object) timeSeries16);
//        boolean boolean20 = fixedMillisecond0.equals((java.lang.Object) timeSeries16);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj24 = null;
//        int int25 = month23.compareTo(obj24);
//        org.jfree.data.time.Year year26 = month23.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) year26);
//        long long28 = year26.getSerialIndex();
//        java.util.Calendar calendar29 = null;
//        try {
//            year26.peg(calendar29);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182373571L + "'", long2 == 1560182373571L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182373571L + "'", long6 == 1560182373571L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Mon Jun 10 08:59:33 PDT 2019" + "'", str8.equals("Mon Jun 10 08:59:33 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 100L + "'", long28 == 100L);
//    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test395");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false);
//        int int2 = timeSeries1.getItemCount();
//        timeSeries1.fireSeriesChanged();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        long long5 = fixedMillisecond4.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond4.previous();
//        long long7 = fixedMillisecond4.getFirstMillisecond();
//        java.lang.String str8 = fixedMillisecond4.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, 0.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond4.next();
//        timeSeries1.setKey((java.lang.Comparable) fixedMillisecond4);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560182373661L + "'", long5 == 1560182373661L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560182373661L + "'", long7 == 1560182373661L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Mon Jun 10 08:59:33 PDT 2019" + "'", str8.equals("Mon Jun 10 08:59:33 PDT 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test397");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double7 = timeSeries6.getMaxY();
//        java.util.List list8 = timeSeries6.getItems();
//        timeSeries6.setNotify(false);
//        java.lang.String str11 = timeSeries6.getDomainDescription();
//        int int12 = day0.compareTo((java.lang.Object) timeSeries6);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries6.getTimePeriod(1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries3.addChangeListener(seriesChangeListener16);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries3.removeChangeListener(seriesChangeListener18);
        try {
            timeSeries3.delete(0, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.previous();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double12 = timeSeries11.getMaxY();
//        java.util.List list13 = timeSeries11.getItems();
//        int int14 = timeSeries11.getItemCount();
//        boolean boolean15 = fixedMillisecond0.equals((java.lang.Object) timeSeries11);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) (byte) 100);
//        boolean boolean20 = timeSeriesDataItem18.equals((java.lang.Object) (short) 10);
//        boolean boolean21 = timeSeriesDataItem18.isSelected();
//        java.lang.Object obj22 = timeSeriesDataItem18.clone();
//        java.lang.Number number23 = null;
//        timeSeriesDataItem18.setValue(number23);
//        boolean boolean25 = timeSeriesDataItem18.isSelected();
//        boolean boolean26 = timeSeriesDataItem18.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries11.addOrUpdate(timeSeriesDataItem18);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year((int) '#');
//        java.lang.Object obj30 = null;
//        int int31 = year29.compareTo(obj30);
//        boolean boolean32 = timeSeriesDataItem18.equals(obj30);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182373865L + "'", long2 == 1560182373865L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(obj22);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Mon Jun 10 08:59:26 PDT 2019");
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date6);
//        java.util.TimeZone timeZone10 = null;
//        try {
//            org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date6, timeZone10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182374343L + "'", long2 == 1560182374343L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries15.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day18, (double) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day18.next();
//        timeSeries1.add(regularTimePeriod22, (double) 1560182340527L);
//        long long25 = timeSeries1.getMaximumItemAge();
//        long long26 = timeSeries1.getMaximumItemAge();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double31 = timeSeries30.getMaxY();
//        int int32 = timeSeries30.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries30.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (double) 6);
//        long long36 = fixedMillisecond33.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double41 = timeSeries40.getMaxY();
//        java.util.List list42 = timeSeries40.getItems();
//        timeSeries40.removeAgedItems((long) (byte) 100, false);
//        boolean boolean46 = fixedMillisecond33.equals((java.lang.Object) (byte) 100);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        long long51 = timeSeries50.getMaximumItemAge();
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day52, (java.lang.Number) (byte) 100);
//        boolean boolean56 = timeSeriesDataItem54.equals((java.lang.Object) (short) 10);
//        boolean boolean57 = timeSeriesDataItem54.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = timeSeries50.addOrUpdate(timeSeriesDataItem54);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries60.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries60.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month65, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = month65.next();
//        timeSeries50.delete((org.jfree.data.time.RegularTimePeriod) month65);
//        boolean boolean70 = fixedMillisecond33.equals((java.lang.Object) month65);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = month65.next();
//        int int72 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month65);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9223372036854775807L + "'", long26 == 9223372036854775807L);
//        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560182374426L + "'", long36 == 1560182374426L);
//        org.junit.Assert.assertEquals((double) double41, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list42);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 9223372036854775807L + "'", long51 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem58);
//        org.junit.Assert.assertNull(timeSeriesDataItem67);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
//    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.addChangeListener(seriesChangeListener8);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond12.previous();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 1560182355429L, false);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond12.getMiddleMillisecond(calendar18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond20.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        boolean boolean25 = fixedMillisecond12.equals((java.lang.Object) fixedMillisecond24);
//        java.util.Calendar calendar26 = null;
//        fixedMillisecond24.peg(calendar26);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560182374643L + "'", long13 == 1560182374643L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560182374643L + "'", long19 == 1560182374643L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560182374648L + "'", long22 == 1560182374648L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 100, seriesChangeInfo1);
        java.lang.Object obj3 = seriesChangeEvent2.getSource();
        java.lang.String str4 = seriesChangeEvent2.toString();
        java.lang.Object obj5 = seriesChangeEvent2.getSource();
        java.lang.Object obj6 = seriesChangeEvent2.getSource();
        java.lang.Object obj7 = seriesChangeEvent2.getSource();
        java.lang.Object obj8 = seriesChangeEvent2.getSource();
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (short) 100 + "'", obj3.equals((short) 100));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + (short) 100 + "'", obj5.equals((short) 100));
        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + (short) 100 + "'", obj6.equals((short) 100));
        org.junit.Assert.assertTrue("'" + obj7 + "' != '" + (short) 100 + "'", obj7.equals((short) 100));
        org.junit.Assert.assertTrue("'" + obj8 + "' != '" + (short) 100 + "'", obj8.equals((short) 100));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
        java.util.Calendar calendar2 = null;
        try {
            year1.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Mon Jun 10 08:59:16 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        java.lang.String str9 = timeSeries3.getDescription();
//        double double10 = timeSeries3.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries12.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) day19, (double) 6);
//        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) day19, 0.0d);
//        long long25 = day19.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day19.previous();
//        long long29 = day19.getLastMillisecond();
//        boolean boolean30 = timeSeries3.equals((java.lang.Object) day19);
//        java.lang.Comparable comparable31 = timeSeries3.getKey();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = null;
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries3.addOrUpdate(regularTimePeriod32, (java.lang.Number) 1560182374426L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 6.0d + "'", double10 == 6.0d);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560236399999L + "'", long25 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560236399999L + "'", long29 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + 10.0d + "'", comparable31.equals(10.0d));
//    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str9 = timeSeries8.getDescription();
        java.lang.String str10 = timeSeries8.getDomainDescription();
        java.util.Collection collection11 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        timeSeries8.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        double double14 = timeSeries8.getMinY();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test409");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        timeSeries3.removeAgedItems((long) 10, false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener8);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        int int13 = month12.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.next();
//        timeSeries3.add(regularTimePeriod14, (double) 1560182345775L, false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        long long19 = fixedMillisecond18.getLastMillisecond();
//        java.util.Calendar calendar20 = null;
//        fixedMillisecond18.peg(calendar20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int27 = fixedMillisecond22.compareTo((java.lang.Object) "hi!");
//        java.util.Date date28 = fixedMillisecond22.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        timeSeries3.setMaximumItemAge(1560182345395L);
//        try {
//            timeSeries3.delete(2, (int) (short) 1, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560182374960L + "'", long19 == 1560182374960L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560182374960L + "'", long24 == 1560182374960L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeSeries30);
//    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.previous();
//        long long3 = fixedMillisecond0.getFirstMillisecond();
//        long long4 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182374986L + "'", long1 == 1560182374986L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560182374986L + "'", long3 == 1560182374986L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560182374986L + "'", long4 == 1560182374986L);
//    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        long long4 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
//        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
//        boolean boolean10 = timeSeriesDataItem7.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries13.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month18);
//        java.lang.String str23 = timeSeries3.getRangeDescription();
//        timeSeries3.setRangeDescription("");
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double30 = timeSeries29.getMaxY();
//        int int31 = timeSeries29.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries29.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (double) 6);
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond32.getMiddleMillisecond(calendar35);
//        java.util.Calendar calendar37 = null;
//        fixedMillisecond32.peg(calendar37);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 1560182353546L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries3.addOrUpdate(timeSeriesDataItem40);
//        try {
//            timeSeriesDataItem41.setValue((java.lang.Number) 1560182353105L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
//        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560182375005L + "'", long36 == 1560182375005L);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//    }

//    @Test
//    public void test412() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test412");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond0.peg(calendar4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond0.next();
//        long long7 = fixedMillisecond0.getSerialIndex();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond0.getLastMillisecond(calendar8);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182375111L + "'", long2 == 1560182375111L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560182375111L + "'", long7 == 1560182375111L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182375111L + "'", long9 == 1560182375111L);
//    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day8);
        java.util.Calendar calendar11 = null;
        try {
            day8.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries13.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.Year year23 = month18.getYear();
        long long24 = month18.getSerialIndex();
        long long25 = month18.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1210L + "'", long24 == 1210L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1210L + "'", long25 == 1210L);
    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond6.getMiddleMillisecond(calendar9);
//        java.util.Calendar calendar11 = null;
//        fixedMillisecond6.peg(calendar11);
//        java.util.Date date13 = fixedMillisecond6.getTime();
//        long long14 = fixedMillisecond6.getLastMillisecond();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560182375196L + "'", long10 == 1560182375196L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560182375196L + "'", long14 == 1560182375196L);
//    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate9);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate9);
//        long long13 = day12.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries15.addChangeListener(seriesChangeListener16);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        boolean boolean20 = timeSeries15.equals((java.lang.Object) timePeriodFormatException19);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException22 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        timePeriodFormatException19.addSuppressed((java.lang.Throwable) timePeriodFormatException22);
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
//        timeSeries25.addChangeListener(seriesChangeListener26);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        boolean boolean30 = timeSeries25.equals((java.lang.Object) timePeriodFormatException29);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        timePeriodFormatException29.addSuppressed((java.lang.Throwable) timePeriodFormatException32);
//        timePeriodFormatException22.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
//        boolean boolean35 = day12.equals((java.lang.Object) timePeriodFormatException29);
//        java.util.Calendar calendar36 = null;
//        try {
//            day12.peg(calendar36);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560236399999L + "'", long13 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
//        java.lang.String str4 = timeSeries3.getDescription();
//        java.lang.String str5 = timeSeries3.getDomainDescription();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
//        timeSeries3.addChangeListener(seriesChangeListener6);
//        timeSeries3.setRangeDescription("Mon Jun 10 08:59:05 PDT 2019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond10.getMiddleMillisecond(calendar11);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int15 = fixedMillisecond10.compareTo((java.lang.Object) "hi!");
//        java.util.Date date16 = fixedMillisecond10.getTime();
//        boolean boolean18 = fixedMillisecond10.equals((java.lang.Object) 1560182343140L);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, 0.0d);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560182375399L + "'", long12 == 1560182375399L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(8, 12);
    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test419");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        long long6 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        java.lang.String str8 = fixedMillisecond0.toString();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj12 = null;
//        int int13 = month11.compareTo(obj12);
//        org.jfree.data.time.Year year14 = month11.getYear();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        int int19 = year14.compareTo((java.lang.Object) timeSeries16);
//        boolean boolean20 = fixedMillisecond0.equals((java.lang.Object) timeSeries16);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj24 = null;
//        int int25 = month23.compareTo(obj24);
//        org.jfree.data.time.Year year26 = month23.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) year26);
//        double double28 = timeSeries16.getMaxY();
//        timeSeries16.removeAgedItems((long) 3, false);
//        java.lang.Class class32 = timeSeries16.getTimePeriodClass();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182375938L + "'", long2 == 1560182375938L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182375938L + "'", long6 == 1560182375938L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Mon Jun 10 08:59:35 PDT 2019" + "'", str8.equals("Mon Jun 10 08:59:35 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
//        org.junit.Assert.assertNull(class32);
//    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Mon Jun 10 08:59:30 PDT 2019");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        long long2 = year1.getSerialIndex();
        int int3 = year1.getYear();
        boolean boolean5 = year1.equals((java.lang.Object) 1560182347531L);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year1.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
//        long long14 = day8.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day8.previous();
//        java.util.Calendar calendar16 = null;
//        try {
//            long long17 = day8.getLastMillisecond(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.setNotify(false);
        boolean boolean8 = timeSeries3.getNotify();
        long long9 = timeSeries3.getMaximumItemAge();
        timeSeries3.setDescription("Mon Jun 10 08:59:25 PDT 2019");
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        timeSeries3.removeAgedItems((long) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 100);
        boolean boolean14 = timeSeriesDataItem12.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem12.setSelected(false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.addOrUpdate(timeSeriesDataItem12);
        java.lang.String str18 = timeSeries3.getRangeDescription();
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
        org.junit.Assert.assertNotNull(collection19);
    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        long long3 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182376157L + "'", long2 == 1560182376157L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560182376157L + "'", long3 == 1560182376157L);
//    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Mon Jun 10 08:59:27 PDT 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        java.util.Date date5 = month2.getEnd();
        int int7 = month2.compareTo((java.lang.Object) 1560182345060L);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month2.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
//        timeSeries1.addChangeListener(seriesChangeListener2);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        boolean boolean6 = timeSeries1.equals((java.lang.Object) timePeriodFormatException5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) (byte) 100);
//        boolean boolean11 = timeSeriesDataItem9.equals((java.lang.Object) (short) 10);
//        boolean boolean12 = timeSeriesDataItem9.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double17 = timeSeries16.getMaxY();
//        int int18 = timeSeries16.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 6);
//        long long22 = fixedMillisecond19.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double27 = timeSeries26.getMaxY();
//        java.util.List list28 = timeSeries26.getItems();
//        timeSeries26.removeAgedItems((long) (byte) 100, false);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) (byte) 100);
//        int int33 = timeSeriesDataItem9.compareTo((java.lang.Object) fixedMillisecond19);
//        int int34 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        timeSeries1.clear();
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.next();
//        long long40 = year38.getLastMillisecond();
//        int int41 = year38.getYear();
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(4, year38);
//        timeSeries1.setKey((java.lang.Comparable) month42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day44, (java.lang.Number) (byte) 100);
//        boolean boolean48 = timeSeriesDataItem46.equals((java.lang.Object) (short) 10);
//        boolean boolean49 = timeSeriesDataItem46.isSelected();
//        java.lang.Object obj50 = timeSeriesDataItem46.clone();
//        timeSeries1.add(timeSeriesDataItem46, false);
//        java.beans.PropertyChangeListener propertyChangeListener53 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener53);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries1.getDataItem((int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560182376472L + "'", long22 == 1560182376472L);
//        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list28);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-62104204800001L) + "'", long40 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(obj50);
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
        java.lang.String str9 = timeSeries3.getDescription();
        timeSeries3.setDescription("");
        java.lang.Comparable comparable12 = timeSeries3.getKey();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 10.0d + "'", comparable12.equals(10.0d));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        org.jfree.data.time.Year year5 = month2.getYear();
        java.util.Calendar calendar6 = null;
        try {
            year5.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.removeAgedItems((long) (byte) 100, false);
        java.lang.Comparable comparable9 = timeSeries3.getKey();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 100);
        boolean boolean14 = timeSeriesDataItem12.equals((java.lang.Object) (short) 10);
        boolean boolean15 = timeSeriesDataItem12.isSelected();
        timeSeriesDataItem12.setValue((java.lang.Number) (byte) 100);
        timeSeries3.add(timeSeriesDataItem12, false);
        java.lang.Number number20 = timeSeriesDataItem12.getValue();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 10.0d + "'", comparable9.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (byte) 100 + "'", number20.equals((byte) 100));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries3.addChangeListener(seriesChangeListener16);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries3.removeChangeListener(seriesChangeListener18);
        timeSeries3.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries23.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries27.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.previous();
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) day30, (double) 6);
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) day30, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries37.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day40.previous();
        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) day40, (double) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day40.next();
        timeSeries23.add(regularTimePeriod44, (double) 1560182340527L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener47 = null;
        timeSeries23.addChangeListener(seriesChangeListener47);
        boolean boolean49 = timeSeries3.equals((java.lang.Object) timeSeries23);
        java.beans.PropertyChangeListener propertyChangeListener50 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener50);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemCount((int) '#');
        long long8 = timeSeries3.getMaximumItemAge();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
//        long long3 = year1.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, (java.lang.Number) (byte) 100);
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int18 = fixedMillisecond13.compareTo((java.lang.Object) "hi!");
//        long long19 = fixedMillisecond13.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond13.next();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double25 = timeSeries24.getMaxY();
//        int int26 = timeSeries24.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) 6);
//        long long30 = fixedMillisecond27.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond27.previous();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
//        timeSeries32.addChangeListener(seriesChangeListener33);
//        int int35 = timeSeries32.getMaximumItemCount();
//        int int36 = year1.compareTo((java.lang.Object) timeSeries32);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day37, (java.lang.Number) (byte) 100);
//        boolean boolean41 = timeSeriesDataItem39.equals((java.lang.Object) (short) 10);
//        boolean boolean42 = timeSeriesDataItem39.isSelected();
//        java.lang.Object obj43 = timeSeriesDataItem39.clone();
//        java.lang.Number number44 = null;
//        timeSeriesDataItem39.setValue(number44);
//        timeSeriesDataItem39.setSelected(true);
//        java.lang.Object obj48 = timeSeriesDataItem39.clone();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries32.addOrUpdate(timeSeriesDataItem39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = timeSeriesDataItem49.getPeriod();
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62104204800001L) + "'", long3 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182376810L + "'", long15 == 1560182376810L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560182376810L + "'", long19 == 1560182376810L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560182376811L + "'", long30 == 1560182376811L);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2147483647 + "'", int35 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(obj43);
//        org.junit.Assert.assertNotNull(obj48);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(regularTimePeriod50);
//    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 1546329600000L);
        boolean boolean7 = timeSeriesDataItem5.equals((java.lang.Object) 1560182353170L);
        timeSeriesDataItem5.setValue((java.lang.Number) 1560182348652L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-58987929600000L) + "'", long3 == (-58987929600000L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str9 = timeSeries8.getDescription();
        java.lang.String str10 = timeSeries8.getDomainDescription();
        java.util.Collection collection11 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        timeSeries8.removeAgedItems(true);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, (java.lang.Number) (byte) 100);
        boolean boolean18 = timeSeriesDataItem16.equals((java.lang.Object) (short) 10);
        boolean boolean19 = timeSeriesDataItem16.isSelected();
        java.lang.Object obj20 = timeSeriesDataItem16.clone();
        java.lang.Number number21 = null;
        timeSeriesDataItem16.setValue(number21);
        timeSeriesDataItem16.setSelected(true);
        timeSeriesDataItem16.setValue((java.lang.Number) 1560182356794L);
        timeSeries8.add(timeSeriesDataItem16, true);
        boolean boolean29 = timeSeries8.getNotify();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        org.jfree.data.time.Year year5 = month2.getYear();
        java.lang.String str6 = year5.toString();
        long long7 = year5.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.removeAgedItems(1560182348434L, true);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        java.util.Collection collection9 = timeSeries1.getTimePeriods();
        org.junit.Assert.assertNotNull(collection9);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 100);
        boolean boolean14 = timeSeriesDataItem12.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem12.setValue((java.lang.Number) 9);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long21 = timeSeries20.getMaximumItemAge();
        boolean boolean22 = timeSeriesDataItem12.equals((java.lang.Object) timeSeries20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries1.addOrUpdate(timeSeriesDataItem12);
        try {
            org.jfree.data.time.TimeSeries timeSeries26 = timeSeries1.createCopy(0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        long long9 = fixedMillisecond6.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double14 = timeSeries13.getMaxY();
//        java.util.List list15 = timeSeries13.getItems();
//        timeSeries13.removeAgedItems((long) (byte) 100, false);
//        boolean boolean19 = fixedMillisecond6.equals((java.lang.Object) (byte) 100);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        long long24 = timeSeries23.getMaximumItemAge();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day25, (java.lang.Number) (byte) 100);
//        boolean boolean29 = timeSeriesDataItem27.equals((java.lang.Object) (short) 10);
//        boolean boolean30 = timeSeriesDataItem27.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries23.addOrUpdate(timeSeriesDataItem27);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries33.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month38, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month38.next();
//        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) month38);
//        boolean boolean43 = fixedMillisecond6.equals((java.lang.Object) month38);
//        java.util.Date date44 = fixedMillisecond6.getTime();
//        java.util.TimeZone timeZone45 = null;
//        java.util.Locale locale46 = null;
//        try {
//            org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date44, timeZone45, locale46);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182377177L + "'", long9 == 1560182377177L);
//        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list15);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(date44);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries15.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day18, (double) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day18.next();
        timeSeries1.add(regularTimePeriod22, (double) 1560182340527L);
        try {
            timeSeries1.delete(2019, 2019, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean8 = timeSeries3.equals((java.lang.Object) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.String str13 = timePeriodFormatException1.toString();
        java.lang.String str14 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str14.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("0");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("October 100");
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        org.jfree.data.time.Year year5 = month2.getYear();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries7.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        int int10 = year5.compareTo((java.lang.Object) timeSeries7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year5.next();
        java.util.Calendar calendar12 = null;
        try {
            year5.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        timeSeries3.removeAgedItems((long) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 100);
        boolean boolean14 = timeSeriesDataItem12.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem12.setSelected(false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.addOrUpdate(timeSeriesDataItem12);
        try {
            timeSeriesDataItem17.setSelected(true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries7);
        java.lang.String str10 = seriesChangeEvent9.toString();
        boolean boolean11 = month2.equals((java.lang.Object) seriesChangeEvent9);
        long long12 = month2.getLastMillisecond();
        int int13 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-58987929600000L) + "'", long3 == (-58987929600000L));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-58985251200001L) + "'", long12 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        java.util.Date date5 = month2.getEnd();
        int int7 = month2.compareTo((java.lang.Object) 1560182345060L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.next();
        org.jfree.data.time.Year year9 = month2.getYear();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.next();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-59011603200000L) + "'", long10 == (-59011603200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.List list5 = timeSeries3.getItems();
//        timeSeries3.setNotify(false);
//        java.lang.String str8 = timeSeries3.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        java.util.Date date12 = fixedMillisecond9.getTime();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date12);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date12);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date12);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 1560182358499L);
//        try {
//            timeSeries3.delete((int) (byte) 0, 9, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182377355L + "'", long11 == 1560182377355L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        long long3 = year1.getLastMillisecond();
        int int4 = year1.getYear();
        java.lang.String str5 = year1.toString();
        long long6 = year1.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62104204800001L) + "'", long3 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0" + "'", str5.equals("0"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        long long6 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        java.lang.String str8 = fixedMillisecond0.toString();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj12 = null;
//        int int13 = month11.compareTo(obj12);
//        org.jfree.data.time.Year year14 = month11.getYear();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        int int19 = year14.compareTo((java.lang.Object) timeSeries16);
//        boolean boolean20 = fixedMillisecond0.equals((java.lang.Object) timeSeries16);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj24 = null;
//        int int25 = month23.compareTo(obj24);
//        org.jfree.data.time.Year year26 = month23.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) year26);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener30 = null;
//        timeSeries29.addChangeListener(seriesChangeListener30);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        boolean boolean34 = timeSeries29.equals((java.lang.Object) timePeriodFormatException33);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        timePeriodFormatException33.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
//        int int38 = year26.compareTo((java.lang.Object) timePeriodFormatException33);
//        java.util.Calendar calendar39 = null;
//        try {
//            year26.peg(calendar39);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182377470L + "'", long2 == 1560182377470L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182377470L + "'", long6 == 1560182377470L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Mon Jun 10 08:59:37 PDT 2019" + "'", str8.equals("Mon Jun 10 08:59:37 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        int int6 = timeSeries3.getItemCount();
        boolean boolean7 = timeSeries3.getNotify();
        try {
            timeSeries3.delete(1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        timeSeries1.fireSeriesChanged();
        timeSeries1.setDescription("Mon Jun 10 08:59:09 PDT 2019");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener12);
        double double14 = timeSeries1.getMinY();
        try {
            timeSeries1.update(3, (java.lang.Number) 1560182372411L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 9.223372036854776E18d + "'", double14 == 9.223372036854776E18d);
    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test454");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond0.next();
//        java.util.Date date9 = fixedMillisecond0.getTime();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182377588L + "'", long2 == 1560182377588L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(date9);
//    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 6);
        java.lang.String str9 = month6.toString();
        int int10 = month6.getYearValue();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = month6.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "October 100" + "'", str9.equals("October 100"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
//        long long3 = year1.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, (java.lang.Number) (byte) 100);
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int18 = fixedMillisecond13.compareTo((java.lang.Object) "hi!");
//        long long19 = fixedMillisecond13.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond13.next();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double25 = timeSeries24.getMaxY();
//        int int26 = timeSeries24.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) 6);
//        long long30 = fixedMillisecond27.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond27.previous();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
//        timeSeries32.addChangeListener(seriesChangeListener33);
//        int int35 = timeSeries32.getMaximumItemCount();
//        int int36 = year1.compareTo((java.lang.Object) timeSeries32);
//        java.beans.PropertyChangeListener propertyChangeListener37 = null;
//        timeSeries32.removePropertyChangeListener(propertyChangeListener37);
//        java.beans.PropertyChangeListener propertyChangeListener39 = null;
//        timeSeries32.addPropertyChangeListener(propertyChangeListener39);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries32.getDataItem((int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62104204800001L) + "'", long3 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182377849L + "'", long15 == 1560182377849L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560182377849L + "'", long19 == 1560182377849L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560182377851L + "'", long30 == 1560182377851L);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2147483647 + "'", int35 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.Object obj6 = timeSeries3.clone();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) (byte) 100);
        boolean boolean11 = timeSeriesDataItem9.equals((java.lang.Object) (short) 10);
        boolean boolean12 = timeSeriesDataItem9.isSelected();
        java.lang.Object obj13 = timeSeriesDataItem9.clone();
        java.lang.Number number14 = null;
        timeSeriesDataItem9.setValue(number14);
        timeSeriesDataItem9.setSelected(true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate(timeSeriesDataItem9);
        try {
            timeSeriesDataItem18.setValue((java.lang.Number) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.Year year7 = month6.getYear();
//        java.util.Calendar calendar8 = null;
//        try {
//            month6.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182377920L + "'", long2 == 1560182377920L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year7);
//    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries13.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month18);
        java.lang.String str23 = timeSeries3.getRangeDescription();
        timeSeries3.removeAgedItems(1560182350391L, false);
        double double27 = timeSeries3.getMaxY();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        long long15 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double21 = timeSeries20.getMaxY();
//        int int22 = timeSeries20.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 6);
//        long long26 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond23.previous();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        timeSeries28.setMaximumItemCount(3);
//        java.beans.PropertyChangeListener propertyChangeListener31 = null;
//        timeSeries28.removePropertyChangeListener(propertyChangeListener31);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries34.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries38.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day41.previous();
//        timeSeries38.add((org.jfree.data.time.RegularTimePeriod) day41, (double) 6);
//        timeSeries34.add((org.jfree.data.time.RegularTimePeriod) day41, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day41, "Mon Jun 10 08:59:05 PDT 2019", "10-June-2019");
//        java.util.Collection collection50 = timeSeries28.getTimePeriodsUniqueToOtherSeries(timeSeries49);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries28.getDataItem((int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182378021L + "'", long11 == 1560182378021L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182378021L + "'", long15 == 1560182378021L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182378028L + "'", long26 == 1560182378028L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(collection50);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double15 = timeSeries14.getMaxY();
        timeSeries14.removeAgedItems((long) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries14.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) (byte) 100);
        boolean boolean25 = timeSeriesDataItem23.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem23.setSelected(false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries14.addOrUpdate(timeSeriesDataItem23);
        java.lang.String str29 = timeSeries14.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries1.addAndOrUpdate(timeSeries14);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = timeSeries1.getTimePeriod(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeries30);
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        long long20 = day18.getFirstMillisecond();
//        int int21 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day18);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(0);
//        long long24 = year23.getSerialIndex();
//        long long25 = year23.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
//        java.lang.String str30 = timeSeries29.getDescription();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries29);
//        int int32 = year23.compareTo((java.lang.Object) seriesChangeEvent31);
//        int int33 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year23);
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        int int37 = month36.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month36.next();
//        boolean boolean39 = timeSeries3.equals((java.lang.Object) regularTimePeriod38);
//        java.beans.PropertyChangeListener propertyChangeListener40 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener40);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560150000000L + "'", long20 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNull(str30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date6);
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date6);
//        java.util.TimeZone timeZone11 = null;
//        java.util.Locale locale12 = null;
//        try {
//            org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date6, timeZone11, locale12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182378200L + "'", long2 == 1560182378200L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.Object obj6 = timeSeries3.clone();
        try {
            timeSeries3.delete(100, 3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.Object obj6 = timeSeries3.clone();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) (byte) 100);
        boolean boolean11 = timeSeriesDataItem9.equals((java.lang.Object) (short) 10);
        boolean boolean12 = timeSeriesDataItem9.isSelected();
        java.lang.Object obj13 = timeSeriesDataItem9.clone();
        java.lang.Number number14 = null;
        timeSeriesDataItem9.setValue(number14);
        timeSeriesDataItem9.setSelected(true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate(timeSeriesDataItem9);
        boolean boolean19 = timeSeriesDataItem9.isSelected();
        java.lang.Number number20 = timeSeriesDataItem9.getValue();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(number20);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Mon Jun 10 08:59:22 PDT 2019");
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        long long9 = fixedMillisecond6.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double14 = timeSeries13.getMaxY();
//        java.util.List list15 = timeSeries13.getItems();
//        timeSeries13.removeAgedItems((long) (byte) 100, false);
//        boolean boolean19 = fixedMillisecond6.equals((java.lang.Object) (byte) 100);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        long long24 = timeSeries23.getMaximumItemAge();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day25, (java.lang.Number) (byte) 100);
//        boolean boolean29 = timeSeriesDataItem27.equals((java.lang.Object) (short) 10);
//        boolean boolean30 = timeSeriesDataItem27.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries23.addOrUpdate(timeSeriesDataItem27);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries33.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month38, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month38.next();
//        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) month38);
//        boolean boolean43 = fixedMillisecond6.equals((java.lang.Object) month38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month38.next();
//        long long45 = month38.getFirstMillisecond();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182378306L + "'", long9 == 1560182378306L);
//        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list15);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-58987929600000L) + "'", long45 == (-58987929600000L));
//    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        java.lang.Number number12 = timeSeriesDataItem7.getValue();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (byte) 100 + "'", number12.equals((byte) 100));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) -1, (-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        timeSeries3.removeAgedItems((long) 10, false);
        try {
            timeSeries3.update((int) (short) 0, (java.lang.Number) (-58985251200001L));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        long long3 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test474");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182378522L + "'", long2 == 1560182378522L);
//        org.junit.Assert.assertNotNull(date3);
//    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate5);
//        try {
//            timeSeries6.delete(7, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182378532L + "'", long2 == 1560182378532L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560182343089L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 1560182366600L);
        long long4 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560182343089L + "'", long4 == 1560182343089L);
    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test477");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        long long9 = day4.getFirstMillisecond();
//        int int10 = day4.getMonth();
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Time");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.Class<?> wildcardClass6 = seriesChangeEvent5.getClass();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        timeSeries3.setRangeDescription("");
        boolean boolean8 = timeSeries3.getNotify();
        java.util.List list9 = timeSeries3.getItems();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Mon Jun 10 08:59:23 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        try {
            timeSeries3.update(0, (java.lang.Number) 1560182351867L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj9 = null;
        int int10 = month8.compareTo(obj9);
        org.jfree.data.time.Year year11 = month8.getYear();
        java.lang.String str12 = year11.toString();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double17 = timeSeries16.getMaxY();
        java.util.List list18 = timeSeries16.getItems();
        timeSeries16.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries16.createCopy((int) (byte) 1, 9999);
        boolean boolean24 = year11.equals((java.lang.Object) timeSeries23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year11.next();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year11, (double) 1560182376166L);
        int int28 = timeSeries3.getMaximumItemCount();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100" + "'", str12.equals("100"));
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2147483647 + "'", int28 == 2147483647);
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        long long20 = day18.getFirstMillisecond();
//        int int21 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day18);
//        long long22 = day18.getFirstMillisecond();
//        int int23 = day18.getMonth();
//        org.jfree.data.time.SerialDate serialDate24 = day18.getSerialDate();
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560150000000L + "'", long20 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560150000000L + "'", long22 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertNotNull(serialDate24);
//    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
//        int int10 = day4.getYear();
//        long long11 = day4.getLastMillisecond();
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560236399999L + "'", long11 == 1560236399999L);
//    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        long long2 = year1.getSerialIndex();
        long long3 = year1.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries9.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month14.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries7.addOrUpdate(regularTimePeriod17, (double) (short) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries7.addChangeListener(seriesChangeListener20);
        java.util.Collection collection22 = timeSeries7.getTimePeriods();
        timeSeries7.setRangeDescription("");
        int int25 = year1.compareTo((java.lang.Object) timeSeries7);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = null;
        try {
            timeSeries7.add(regularTimePeriod27, (double) 1560182352596L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.removeAgedItems((long) (byte) 100, false);
        java.util.List list9 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double14 = timeSeries13.getMaxY();
        int int15 = timeSeries13.getItemCount();
        timeSeries13.setMaximumItemCount(1);
        boolean boolean18 = timeSeries3.equals((java.lang.Object) timeSeries13);
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        int int20 = timeSeries3.getItemCount();
        try {
            timeSeries3.update(4, (java.lang.Number) 1560182367680L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test488");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        long long9 = month8.getFirstMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month8);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month21.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries14.addOrUpdate(regularTimePeriod24, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries14.addChangeListener(seriesChangeListener27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.previous();
//        long long31 = day29.getFirstMillisecond();
//        int int32 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) day29);
//        long long33 = day29.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day29.previous();
//        timeSeries3.add(regularTimePeriod34, (double) 1560182341608L, false);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod34, "Mon Jun 10 08:59:09 PDT 2019", "org.jfree.data.time.TimePeriodFormatException: hi!");
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod34, (double) 1560182366347L);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-58987929600000L) + "'", long9 == (-58987929600000L));
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560150000000L + "'", long31 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560150000000L + "'", long33 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries3.addChangeListener(seriesChangeListener16);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries3.removeChangeListener(seriesChangeListener18);
        timeSeries3.setDomainDescription("");
        try {
            org.jfree.data.time.TimeSeries timeSeries24 = timeSeries3.createCopy((int) ' ', 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.addChangeListener(seriesChangeListener8);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond12.previous();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 1560182355429L, false);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond12.getMiddleMillisecond(calendar18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond20.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        boolean boolean25 = fixedMillisecond12.equals((java.lang.Object) fixedMillisecond24);
//        long long26 = fixedMillisecond24.getLastMillisecond();
//        long long27 = fixedMillisecond24.getMiddleMillisecond();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560182379437L + "'", long13 == 1560182379437L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560182379437L + "'", long19 == 1560182379437L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560182379439L + "'", long22 == 1560182379439L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182379439L + "'", long26 == 1560182379439L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560182379439L + "'", long27 == 1560182379439L);
//    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        long long9 = fixedMillisecond6.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double14 = timeSeries13.getMaxY();
//        java.util.List list15 = timeSeries13.getItems();
//        timeSeries13.removeAgedItems((long) (byte) 100, false);
//        boolean boolean19 = fixedMillisecond6.equals((java.lang.Object) (byte) 100);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        long long24 = timeSeries23.getMaximumItemAge();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day25, (java.lang.Number) (byte) 100);
//        boolean boolean29 = timeSeriesDataItem27.equals((java.lang.Object) (short) 10);
//        boolean boolean30 = timeSeriesDataItem27.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries23.addOrUpdate(timeSeriesDataItem27);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries33.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month38, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month38.next();
//        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) month38);
//        boolean boolean43 = fixedMillisecond6.equals((java.lang.Object) month38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month38.next();
//        java.util.Date date45 = regularTimePeriod44.getStart();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182379475L + "'", long9 == 1560182379475L);
//        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list15);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(date45);
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        boolean boolean9 = timeSeries1.getNotify();
        java.util.List list10 = timeSeries1.getItems();
        java.lang.String str11 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str11.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) date3, seriesChangeInfo5);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182379828L + "'", long2 == 1560182379828L);
//        org.junit.Assert.assertNotNull(date3);
//    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond0.peg(calendar4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond0.next();
//        long long7 = fixedMillisecond0.getMiddleMillisecond();
//        long long8 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182379904L + "'", long2 == 1560182379904L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560182379904L + "'", long7 == 1560182379904L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560182379904L + "'", long8 == 1560182379904L);
//    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
//        timeSeries1.addChangeListener(seriesChangeListener2);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        boolean boolean6 = timeSeries1.equals((java.lang.Object) timePeriodFormatException5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) (byte) 100);
//        boolean boolean11 = timeSeriesDataItem9.equals((java.lang.Object) (short) 10);
//        boolean boolean12 = timeSeriesDataItem9.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double17 = timeSeries16.getMaxY();
//        int int18 = timeSeries16.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 6);
//        long long22 = fixedMillisecond19.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double27 = timeSeries26.getMaxY();
//        java.util.List list28 = timeSeries26.getItems();
//        timeSeries26.removeAgedItems((long) (byte) 100, false);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) (byte) 100);
//        int int33 = timeSeriesDataItem9.compareTo((java.lang.Object) fixedMillisecond19);
//        int int34 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        timeSeries1.removeAgedItems(true);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560182380104L + "'", long22 == 1560182380104L);
//        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list28);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries13.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month18);
        java.lang.String str23 = month18.toString();
        org.jfree.data.time.Year year24 = month18.getYear();
        long long25 = year24.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "October 100" + "'", str23.equals("October 100"));
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 100L + "'", long25 == 100L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        org.jfree.data.time.Year year5 = month2.getYear();
        java.lang.String str6 = year5.toString();
        long long7 = year5.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year5, (java.lang.Number) 8);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-59011603200000L) + "'", long7 == (-59011603200000L));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries3.addChangeListener(seriesChangeListener16);
        double double18 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries20.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) day23, (double) 6);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day27.previous();
        int int29 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) day27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = timeSeries20.getNextTimePeriod();
        timeSeries3.update(regularTimePeriod30, (java.lang.Number) 1560182374632L);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 10.0d + "'", double18 == 10.0d);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries1.getNextTimePeriod();
        timeSeries1.fireSeriesChanged();
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        timeSeries3.setDescription("");
        java.lang.String str7 = timeSeries3.getRangeDescription();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }
}

