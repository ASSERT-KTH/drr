import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        timeSeries3.setMaximumItemAge((long) 12);
        boolean boolean9 = timeSeries3.isEmpty();
        timeSeries3.setMaximumItemAge(10L);
        try {
            timeSeries3.delete(9999, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.addChangeListener(seriesChangeListener5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean9 = timeSeries4.equals((java.lang.Object) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean19 = timeSeries14.equals((java.lang.Object) timePeriodFormatException18);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException11.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.Throwable[] throwableArray26 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray27 = seriesException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("Mon Jun 10 08:59:05 PDT 2019");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(throwableArray27);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        java.lang.String str5 = timeSeries3.getDomainDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        long long8 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day9, (java.lang.Number) (byte) 100);
        boolean boolean13 = timeSeriesDataItem11.equals((java.lang.Object) (short) 10);
        boolean boolean14 = timeSeriesDataItem11.isSelected();
        java.lang.Object obj15 = timeSeriesDataItem11.clone();
        java.lang.Number number16 = null;
        timeSeriesDataItem11.setValue(number16);
        timeSeriesDataItem11.setSelected(true);
        timeSeriesDataItem11.setValue((java.lang.Number) 1560182356794L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.addOrUpdate(timeSeriesDataItem11);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries24.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day27, (java.lang.Number) (byte) 100);
        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) day27, (java.lang.Number) 9223372036854775807L);
        org.jfree.data.time.SerialDate serialDate32 = day27.getSerialDate();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(serialDate32);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(serialDate32);
        int int35 = day34.getMonth();
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day34, (double) 1560182365283L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 10-June-2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test004");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
//        int int8 = month7.getYearValue();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj12 = null;
//        int int13 = month11.compareTo(obj12);
//        int int14 = month7.compareTo((java.lang.Object) int13);
//        java.lang.String str15 = month7.toString();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182423946L + "'", long2 == 1560182423946L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "June 2019" + "'", str15.equals("June 2019"));
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj8 = null;
        int int9 = month7.compareTo(obj8);
        java.util.Date date10 = month7.getEnd();
        int int12 = month7.compareTo((java.lang.Object) 1560182345060L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month7.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month7, (double) 1560182354231L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeries1.getNextTimePeriod();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test006");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
//        java.lang.String str4 = timeSeries3.getDescription();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj9 = null;
//        int int10 = month8.compareTo(obj9);
//        org.jfree.data.time.Year year11 = month8.getYear();
//        java.lang.String str12 = year11.toString();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double17 = timeSeries16.getMaxY();
//        java.util.List list18 = timeSeries16.getItems();
//        timeSeries16.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries16.createCopy((int) (byte) 1, 9999);
//        boolean boolean24 = year11.equals((java.lang.Object) timeSeries23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year11.next();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year11, (double) 1560182376166L);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries33.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month38, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month38.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries31.addOrUpdate(regularTimePeriod41, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener44 = null;
//        timeSeries31.addChangeListener(seriesChangeListener44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = day46.previous();
//        long long48 = day46.getFirstMillisecond();
//        int int49 = timeSeries31.getIndex((org.jfree.data.time.RegularTimePeriod) day46);
//        long long50 = day46.getFirstMillisecond();
//        long long51 = day46.getSerialIndex();
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day46, (java.lang.Number) 1560182398994L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(year11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100" + "'", str12.equals("100"));
//        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list18);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(timeSeriesDataItem43);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560150000000L + "'", long48 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560150000000L + "'", long50 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 43626L + "'", long51 == 43626L);
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        timeSeries3.setRangeDescription("");
        try {
            timeSeries3.delete((int) (byte) -1, (int) (short) 1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test008");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar2 = null;
//        fixedMillisecond0.peg(calendar2);
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond0.peg(calendar4);
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        long long7 = fixedMillisecond0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182424050L + "'", long1 == 1560182424050L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560182424050L + "'", long7 == 1560182424050L);
//    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test009");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        java.lang.String str9 = timeSeries3.getDescription();
//        double double10 = timeSeries3.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double15 = timeSeries14.getMaxY();
//        java.util.List list16 = timeSeries14.getItems();
//        timeSeries14.setNotify(false);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj22 = null;
//        int int23 = month21.compareTo(obj22);
//        java.util.Date date24 = month21.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (double) 1560182343140L);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem26);
//        timeSeries14.add(timeSeriesDataItem26);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
//        timeSeries30.addChangeListener(seriesChangeListener31);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        boolean boolean35 = timeSeries30.equals((java.lang.Object) timePeriodFormatException34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day36, (java.lang.Number) (byte) 100);
//        boolean boolean40 = timeSeriesDataItem38.equals((java.lang.Object) (short) 10);
//        boolean boolean41 = timeSeriesDataItem38.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double46 = timeSeries45.getMaxY();
//        int int47 = timeSeries45.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries45.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (double) 6);
//        long long51 = fixedMillisecond48.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double56 = timeSeries55.getMaxY();
//        java.util.List list57 = timeSeries55.getItems();
//        timeSeries55.removeAgedItems((long) (byte) 100, false);
//        boolean boolean61 = fixedMillisecond48.equals((java.lang.Object) (byte) 100);
//        int int62 = timeSeriesDataItem38.compareTo((java.lang.Object) fixedMillisecond48);
//        int int63 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
//        timeSeries30.clear();
//        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = year67.next();
//        long long69 = year67.getLastMillisecond();
//        int int70 = year67.getYear();
//        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month(4, year67);
//        timeSeries30.setKey((java.lang.Comparable) month71);
//        boolean boolean73 = timeSeriesDataItem26.equals((java.lang.Object) timeSeries30);
//        boolean boolean74 = timeSeries3.equals((java.lang.Object) timeSeriesDataItem26);
//        java.lang.String str75 = timeSeries3.getDomainDescription();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 6.0d + "'", double10 == 6.0d);
//        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list16);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertEquals((double) double46, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560182424219L + "'", long51 == 1560182424219L);
//        org.junit.Assert.assertEquals((double) double56, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list57);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-62104204800001L) + "'", long69 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "hi!" + "'", str75.equals("hi!"));
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560182349137L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test011");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        boolean boolean8 = fixedMillisecond0.equals((java.lang.Object) 1560182343140L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1560182341157L);
//        timeSeriesDataItem10.setSelected(false);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182424482L + "'", long2 == 1560182424482L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        timeSeries1.fireSeriesChanged();
        timeSeries1.setDescription("Mon Jun 10 08:59:09 PDT 2019");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener12);
        int int14 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test013");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        int int2 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test014");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182424932L + "'", long2 == 1560182424932L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test015");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 100, seriesChangeInfo8);
//        java.lang.Object obj10 = seriesChangeEvent9.getSource();
//        boolean boolean11 = month6.equals((java.lang.Object) seriesChangeEvent9);
//        java.lang.String str12 = seriesChangeEvent9.toString();
//        java.lang.Object obj13 = seriesChangeEvent9.getSource();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182424966L + "'", long2 == 1560182424966L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + obj10 + "' != '" + (short) 100 + "'", obj10.equals((short) 100));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str12.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
//        org.junit.Assert.assertTrue("'" + obj13 + "' != '" + (short) 100 + "'", obj13.equals((short) 100));
//    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test016");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.previous();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double12 = timeSeries11.getMaxY();
//        java.util.List list13 = timeSeries11.getItems();
//        int int14 = timeSeries11.getItemCount();
//        boolean boolean15 = fixedMillisecond0.equals((java.lang.Object) timeSeries11);
//        java.lang.Class class16 = timeSeries11.getTimePeriodClass();
//        timeSeries11.setNotify(false);
//        int int19 = timeSeries11.getMaximumItemCount();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries21.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries25.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day28.previous();
//        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) day28, (double) 6);
//        timeSeries21.add((org.jfree.data.time.RegularTimePeriod) day28, 0.0d);
//        long long34 = day28.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day28.previous();
//        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) day28);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182425026L + "'", long2 == 1560182425026L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNull(class16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2147483647 + "'", int19 == 2147483647);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560236399999L + "'", long34 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
        try {
            java.lang.Number number17 = timeSeries3.getValue((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test018");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        int int9 = day4.getYear();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double14 = timeSeries13.getMaxY();
//        int int15 = timeSeries13.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) 6);
//        long long19 = fixedMillisecond16.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond16.previous();
//        java.lang.Object obj21 = null;
//        boolean boolean22 = fixedMillisecond16.equals(obj21);
//        boolean boolean23 = day4.equals((java.lang.Object) boolean22);
//        int int24 = day4.getMonth();
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560182425191L + "'", long19 == 1560182425191L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false);
        int int2 = timeSeries1.getItemCount();
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        long long9 = month6.getFirstMillisecond();
        java.util.Date date10 = month6.getEnd();
        org.jfree.data.time.Year year11 = month6.getYear();
        java.lang.Number number12 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year11);
        java.util.Date date13 = year11.getEnd();
        java.util.TimeZone timeZone14 = null;
        try {
            org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date13, timeZone14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-58987929600000L) + "'", long9 == (-58987929600000L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNotNull(date13);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test020");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        long long20 = day18.getFirstMillisecond();
//        int int21 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day18);
//        long long22 = day18.getFirstMillisecond();
//        int int23 = day18.getMonth();
//        int int24 = day18.getDayOfMonth();
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560150000000L + "'", long20 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560150000000L + "'", long22 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        org.jfree.data.time.Year year5 = month2.getYear();
        java.lang.String str6 = year5.toString();
        int int7 = year5.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year5.next();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test022");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        long long15 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double21 = timeSeries20.getMaxY();
//        int int22 = timeSeries20.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 6);
//        long long26 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond23.previous();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        timeSeries28.setMaximumItemCount(3);
//        java.beans.PropertyChangeListener propertyChangeListener31 = null;
//        timeSeries28.removePropertyChangeListener(propertyChangeListener31);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries34.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries38.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day41.previous();
//        timeSeries38.add((org.jfree.data.time.RegularTimePeriod) day41, (double) 6);
//        timeSeries34.add((org.jfree.data.time.RegularTimePeriod) day41, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day41, "Mon Jun 10 08:59:05 PDT 2019", "10-June-2019");
//        java.util.Collection collection50 = timeSeries28.getTimePeriodsUniqueToOtherSeries(timeSeries49);
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries52.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day55, (java.lang.Number) (byte) 100);
//        timeSeries52.add((org.jfree.data.time.RegularTimePeriod) day55, (java.lang.Number) 9223372036854775807L);
//        int int60 = day55.getYear();
//        int int61 = day55.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar63 = null;
//        long long64 = fixedMillisecond62.getMiddleMillisecond(calendar63);
//        java.util.Date date65 = fixedMillisecond62.getTime();
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date65);
//        boolean boolean67 = day55.equals((java.lang.Object) year66);
//        boolean boolean68 = timeSeries28.equals((java.lang.Object) day55);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182425328L + "'", long11 == 1560182425328L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182425328L + "'", long15 == 1560182425328L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182425330L + "'", long26 == 1560182425330L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(collection50);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560182425335L + "'", long64 == 1560182425335L);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        org.jfree.data.time.Year year5 = month2.getYear();
        java.lang.String str6 = year5.toString();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double11 = timeSeries10.getMaxY();
        java.util.List list12 = timeSeries10.getItems();
        timeSeries10.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries10.createCopy((int) (byte) 1, 9999);
        boolean boolean18 = year5.equals((java.lang.Object) timeSeries17);
        double double19 = timeSeries17.getMinY();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(0);
        long long22 = year21.getSerialIndex();
        int int23 = year21.getYear();
        long long24 = year21.getFirstMillisecond();
        long long25 = year21.getLastMillisecond();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        long long27 = year26.getFirstMillisecond();
        java.lang.String str28 = year26.toString();
        int int29 = year21.compareTo((java.lang.Object) year26);
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) year21, (double) 24234L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-62167363200000L) + "'", long24 == (-62167363200000L));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-62104204800001L) + "'", long25 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2019" + "'", str28.equals("2019"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-2019) + "'", int29 == (-2019));
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test024");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.addChangeListener(seriesChangeListener8);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond12.previous();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 1560182355429L, false);
//        long long18 = fixedMillisecond12.getMiddleMillisecond();
//        java.util.Calendar calendar19 = null;
//        long long20 = fixedMillisecond12.getLastMillisecond(calendar19);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560182425884L + "'", long13 == 1560182425884L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560182425884L + "'", long18 == 1560182425884L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560182425884L + "'", long20 == 1560182425884L);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        timeSeries1.setRangeDescription("hi!");
        timeSeries1.setNotify(false);
        boolean boolean13 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str18 = timeSeries17.getDescription();
        timeSeries17.removeAgedItems(1560182378522L, false);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries23.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month28.previous();
        long long32 = month28.getFirstMillisecond();
        timeSeries17.delete((org.jfree.data.time.RegularTimePeriod) month28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month28, (double) 1560182386556L);
        try {
            timeSeries1.add(timeSeriesDataItem35);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-58987929600000L) + "'", long32 == (-58987929600000L));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        org.jfree.data.time.Year year5 = month2.getYear();
        java.lang.Object obj6 = null;
        boolean boolean7 = year5.equals(obj6);
        long long8 = year5.getLastMillisecond();
        long long9 = year5.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-58979980800001L) + "'", long8 == (-58979980800001L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-59011603200000L) + "'", long9 == (-59011603200000L));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean6 = timeSeries1.equals((java.lang.Object) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) seriesException11);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test028");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond6.getMiddleMillisecond(calendar9);
//        java.util.Calendar calendar11 = null;
//        fixedMillisecond6.peg(calendar11);
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond6.getLastMillisecond(calendar13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond6.previous();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560182425971L + "'", long10 == 1560182425971L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560182425971L + "'", long14 == 1560182425971L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getItemCount();
        timeSeries3.setRangeDescription("October 100");
        java.util.Collection collection8 = timeSeries3.getTimePeriods();
        long long9 = timeSeries3.getMaximumItemAge();
        java.util.List list10 = timeSeries3.getItems();
        java.lang.Class class11 = timeSeries3.getTimePeriodClass();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNull(class11);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        boolean boolean8 = timeSeriesDataItem6.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem6.setSelected(false);
        java.lang.Number number11 = timeSeriesDataItem6.getValue();
        timeSeries3.add(timeSeriesDataItem6, false);
        timeSeries3.setNotify(false);
        boolean boolean16 = timeSeries3.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 100 + "'", number11.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test031");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        boolean boolean8 = fixedMillisecond0.equals((java.lang.Object) 1560182343140L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1560182341157L);
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond0.getLastMillisecond(calendar11);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182426095L + "'", long2 == 1560182426095L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560182426095L + "'", long12 == 1560182426095L);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        timeSeries3.setMaximumItemAge((long) 12);
        boolean boolean9 = timeSeries3.isEmpty();
        boolean boolean10 = timeSeries3.getNotify();
        java.lang.Comparable comparable11 = timeSeries3.getKey();
        timeSeries3.setDomainDescription("Mon Jun 10 08:59:15 PDT 2019");
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 10.0d + "'", comparable11.equals(10.0d));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double15 = timeSeries14.getMaxY();
        timeSeries14.removeAgedItems((long) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries14.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) (byte) 100);
        boolean boolean25 = timeSeriesDataItem23.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem23.setSelected(false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries14.addOrUpdate(timeSeriesDataItem23);
        java.lang.String str29 = timeSeries14.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries1.addAndOrUpdate(timeSeries14);
        boolean boolean31 = timeSeries1.isEmpty();
        double double32 = timeSeries1.getMaxY();
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 100.0d + "'", double32 == 100.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries13.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.Year year23 = month18.getYear();
        long long24 = month18.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double29 = timeSeries28.getMaxY();
        java.util.Collection collection30 = timeSeries28.getTimePeriods();
        timeSeries28.setRangeDescription("");
        boolean boolean33 = timeSeries28.getNotify();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(9, 6);
        java.lang.String str37 = month36.toString();
        int int38 = month36.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month36, 0.0d);
        int int41 = month18.compareTo((java.lang.Object) 0.0d);
        long long42 = month18.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1210L + "'", long24 == 1210L);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "September 6" + "'", str37.equals("September 6"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1210L + "'", long42 == 1210L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        int int2 = day0.getMonth();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test036");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.List list5 = timeSeries3.getItems();
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((int) (byte) 1, 9999);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        long long15 = timeSeries14.getMaximumItemAge();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) (byte) 100);
//        boolean boolean20 = timeSeriesDataItem18.equals((java.lang.Object) (short) 10);
//        boolean boolean21 = timeSeriesDataItem18.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries14.addOrUpdate(timeSeriesDataItem18);
//        java.util.Collection collection23 = timeSeries14.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries10.addAndOrUpdate(timeSeries14);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double29 = timeSeries28.getMaxY();
//        int int30 = timeSeries28.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (double) 6);
//        long long34 = fixedMillisecond31.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double39 = timeSeries38.getMaxY();
//        java.util.List list40 = timeSeries38.getItems();
//        timeSeries38.removeAgedItems((long) (byte) 100, false);
//        boolean boolean44 = fixedMillisecond31.equals((java.lang.Object) (byte) 100);
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        long long49 = timeSeries48.getMaximumItemAge();
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day50, (java.lang.Number) (byte) 100);
//        boolean boolean54 = timeSeriesDataItem52.equals((java.lang.Object) (short) 10);
//        boolean boolean55 = timeSeriesDataItem52.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries48.addOrUpdate(timeSeriesDataItem52);
//        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries58.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries58.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month63, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = month63.next();
//        timeSeries48.delete((org.jfree.data.time.RegularTimePeriod) month63);
//        boolean boolean68 = fixedMillisecond31.equals((java.lang.Object) month63);
//        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (java.lang.Number) 1560182387633L);
//        java.lang.Class<?> wildcardClass71 = timeSeries24.getClass();
//        java.beans.PropertyChangeListener propertyChangeListener72 = null;
//        timeSeries24.removePropertyChangeListener(propertyChangeListener72);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list5);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertNotNull(collection23);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560182426509L + "'", long34 == 1560182426509L);
//        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list40);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 9223372036854775807L + "'", long49 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem56);
//        org.junit.Assert.assertNull(timeSeriesDataItem65);
//        org.junit.Assert.assertNotNull(regularTimePeriod66);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertNotNull(wildcardClass71);
//    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test037");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener18);
//        timeSeries3.setDescription("Mon Jun 10 08:59:05 PDT 2019");
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries23.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day26, (java.lang.Number) (byte) 100);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) day26, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate31 = day26.getSerialDate();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(serialDate31);
//        java.lang.String str33 = day32.toString();
//        java.lang.Number number34 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day32);
//        boolean boolean35 = timeSeries3.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double40 = timeSeries39.getMaxY();
//        int int41 = timeSeries39.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries39.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (double) 6);
//        java.lang.String str45 = timeSeries39.getDescription();
//        double double46 = timeSeries39.getMinY();
//        java.util.Collection collection47 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries39);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "10-June-2019" + "'", str33.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 10.0d + "'", number34.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertNull(str45);
//        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 6.0d + "'", double46 == 6.0d);
//        org.junit.Assert.assertNotNull(collection47);
//    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test038");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.previous();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double12 = timeSeries11.getMaxY();
//        java.util.List list13 = timeSeries11.getItems();
//        int int14 = timeSeries11.getItemCount();
//        boolean boolean15 = fixedMillisecond0.equals((java.lang.Object) timeSeries11);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double20 = timeSeries19.getMaxY();
//        java.util.Collection collection21 = timeSeries19.getTimePeriods();
//        java.lang.String str22 = timeSeries19.getRangeDescription();
//        long long23 = timeSeries19.getMaximumItemAge();
//        boolean boolean24 = fixedMillisecond0.equals((java.lang.Object) long23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond0.previous();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182426970L + "'", long2 == 1560182426970L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        java.util.Date date5 = month2.getEnd();
        java.util.Date date6 = month2.getStart();
        int int7 = month2.getYearValue();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) '#');
        int int8 = year7.getYear();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) year7);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 100);
        boolean boolean14 = timeSeriesDataItem12.equals((java.lang.Object) (short) 10);
        boolean boolean15 = timeSeriesDataItem12.isSelected();
        java.lang.Object obj16 = timeSeriesDataItem12.clone();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries1.addOrUpdate(timeSeriesDataItem12);
        java.lang.String str18 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Value" + "'", str18.equals("Value"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        timeSeries3.setRangeDescription("");
        boolean boolean8 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double13 = timeSeries12.getMaxY();
        java.util.List list14 = timeSeries12.getItems();
        timeSeries12.removeAgedItems((long) (byte) 100, false);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.addAndOrUpdate(timeSeries12);
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener19);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560182343089L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 1560182366600L);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getLastMillisecond(calendar6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560182343089L + "'", long7 == 1560182343089L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        java.lang.String str5 = timeSeries3.getDomainDescription();
        timeSeries3.removeAgedItems(true);
        int int8 = timeSeries3.getItemCount();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 1);
        long long2 = year1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62135740800000L) + "'", long2 == (-62135740800000L));
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test046");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        long long15 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double21 = timeSeries20.getMaxY();
//        int int22 = timeSeries20.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 6);
//        long long26 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond23.previous();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
//        timeSeries28.addChangeListener(seriesChangeListener29);
//        boolean boolean31 = timeSeries28.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond32.getMiddleMillisecond(calendar33);
//        java.util.Date date35 = fixedMillisecond32.getTime();
//        java.util.Calendar calendar36 = null;
//        fixedMillisecond32.peg(calendar36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond32.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = fixedMillisecond32.next();
//        timeSeries28.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 1560182352357L);
//        long long42 = fixedMillisecond32.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182427298L + "'", long11 == 1560182427298L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182427298L + "'", long15 == 1560182427298L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182427300L + "'", long26 == 1560182427300L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560182427302L + "'", long34 == 1560182427302L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560182427302L + "'", long42 == 1560182427302L);
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.setNotify(false);
        boolean boolean8 = timeSeries3.getNotify();
        boolean boolean9 = timeSeries3.getNotify();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test048");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.List list5 = timeSeries3.getItems();
//        timeSeries3.setNotify(false);
//        java.lang.String str8 = timeSeries3.getDomainDescription();
//        timeSeries3.setKey((java.lang.Comparable) 4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
//        java.util.Date date14 = fixedMillisecond11.getTime();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date14);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date14);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.previous();
//        int int21 = timeSeries3.getIndex(regularTimePeriod20);
//        timeSeries3.setDescription("Value");
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560182427652L + "'", long13 == 1560182427652L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day9.previous();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) 1560193199999L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries11.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        java.util.Calendar calendar16 = null;
        fixedMillisecond12.peg(calendar16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(1560182343089L);
        int int21 = fixedMillisecond19.compareTo((java.lang.Object) 1560182366600L);
        java.util.Calendar calendar22 = null;
        fixedMillisecond19.peg(calendar22);
        try {
            org.jfree.data.time.TimeSeries timeSeries24 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start on or before end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str13 = timeSeries12.getDescription();
        java.util.Collection collection14 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        timeSeries12.setMaximumItemAge(1560182348409L);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str21 = timeSeries20.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries20);
        java.lang.Object obj23 = timeSeries20.clone();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (java.lang.Number) (byte) 100);
        boolean boolean28 = timeSeriesDataItem26.equals((java.lang.Object) (short) 10);
        boolean boolean29 = timeSeriesDataItem26.isSelected();
        java.lang.Object obj30 = timeSeriesDataItem26.clone();
        java.lang.Number number31 = null;
        timeSeriesDataItem26.setValue(number31);
        timeSeriesDataItem26.setSelected(true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries20.addOrUpdate(timeSeriesDataItem26);
        boolean boolean36 = timeSeriesDataItem26.isSelected();
        java.lang.Object obj37 = timeSeriesDataItem26.clone();
        timeSeries12.add(timeSeriesDataItem26, false);
        timeSeries12.update(0, (java.lang.Number) 1560182350065L);
        try {
            org.jfree.data.time.TimeSeries timeSeries45 = timeSeries12.createCopy(8, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(obj37);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test051");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
//        timeSeries1.addChangeListener(seriesChangeListener2);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        boolean boolean6 = timeSeries1.equals((java.lang.Object) timePeriodFormatException5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) (byte) 100);
//        boolean boolean11 = timeSeriesDataItem9.equals((java.lang.Object) (short) 10);
//        boolean boolean12 = timeSeriesDataItem9.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double17 = timeSeries16.getMaxY();
//        int int18 = timeSeries16.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 6);
//        long long22 = fixedMillisecond19.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double27 = timeSeries26.getMaxY();
//        java.util.List list28 = timeSeries26.getItems();
//        timeSeries26.removeAgedItems((long) (byte) 100, false);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) (byte) 100);
//        int int33 = timeSeriesDataItem9.compareTo((java.lang.Object) fixedMillisecond19);
//        int int34 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        timeSeries1.setRangeDescription("");
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560182427894L + "'", long22 == 1560182427894L);
//        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list28);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 100, seriesChangeInfo1);
        java.lang.String str3 = seriesChangeEvent2.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo4);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo6);
        java.lang.Object obj8 = seriesChangeEvent2.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = seriesChangeEvent2.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str3.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + obj8 + "' != '" + (short) 100 + "'", obj8.equals((short) 100));
        org.junit.Assert.assertNull(seriesChangeInfo9);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 1, "October 100", "100");
        timeSeries3.setKey((java.lang.Comparable) 1560182398486L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries7);
        java.lang.String str10 = seriesChangeEvent9.toString();
        boolean boolean11 = month2.equals((java.lang.Object) seriesChangeEvent9);
        int int12 = month2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month2.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-58987929600000L) + "'", long3 == (-58987929600000L));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.previous();
        java.lang.String str10 = month6.toString();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "October 100" + "'", str10.equals("October 100"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560182356406L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test057");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries7.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month12.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries5.addOrUpdate(regularTimePeriod15, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries5.addChangeListener(seriesChangeListener18);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries5.removeChangeListener(seriesChangeListener20);
//        timeSeries5.setDomainDescription("");
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries29.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month34, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = month34.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries27.addOrUpdate(regularTimePeriod37, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener40 = null;
//        timeSeries27.addChangeListener(seriesChangeListener40);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day42.previous();
//        long long44 = day42.getFirstMillisecond();
//        int int45 = timeSeries27.getIndex((org.jfree.data.time.RegularTimePeriod) day42);
//        long long46 = day42.getFirstMillisecond();
//        int int47 = day42.getMonth();
//        int int48 = day42.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) day42);
//        long long50 = day42.getFirstMillisecond();
//        boolean boolean51 = day0.equals((java.lang.Object) day42);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560150000000L + "'", long44 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560150000000L + "'", long46 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560150000000L + "'", long50 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        timeSeries3.setMaximumItemAge((long) 12);
        boolean boolean9 = timeSeries3.isEmpty();
        boolean boolean10 = timeSeries3.getNotify();
        java.lang.Comparable comparable11 = timeSeries3.getKey();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 10.0d + "'", comparable11.equals(10.0d));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day4.next();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = regularTimePeriod8.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries1.addChangeListener(seriesChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener6);
        try {
            timeSeries1.delete((int) (short) 10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries3.addChangeListener(seriesChangeListener16);
        double double18 = timeSeries3.getMinY();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj22 = null;
        int int23 = month21.compareTo(obj22);
        java.util.Date date24 = month21.getEnd();
        int int26 = month21.compareTo((java.lang.Object) 1560182345060L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month21.next();
        int int28 = timeSeries3.getIndex(regularTimePeriod27);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 10.0d + "'", double18 == 10.0d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        java.lang.String str5 = timeSeries3.getDomainDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        long long8 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day9, (java.lang.Number) (byte) 100);
        boolean boolean13 = timeSeriesDataItem11.equals((java.lang.Object) (short) 10);
        boolean boolean14 = timeSeriesDataItem11.isSelected();
        java.lang.Object obj15 = timeSeriesDataItem11.clone();
        java.lang.Number number16 = null;
        timeSeriesDataItem11.setValue(number16);
        timeSeriesDataItem11.setSelected(true);
        timeSeriesDataItem11.setValue((java.lang.Number) 1560182356794L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.addOrUpdate(timeSeriesDataItem11);
        timeSeriesDataItem11.setValue((java.lang.Number) 1560182421604L);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        org.jfree.data.time.Year year5 = month2.getYear();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries7.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        int int10 = year5.compareTo((java.lang.Object) timeSeries7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year5.next();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year5.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test064");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        timeSeries3.setMaximumItemAge((long) 12);
//        boolean boolean9 = timeSeries3.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        long long14 = timeSeries13.getMaximumItemAge();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) (byte) 100);
//        boolean boolean19 = timeSeriesDataItem17.equals((java.lang.Object) (short) 10);
//        boolean boolean20 = timeSeriesDataItem17.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries13.addOrUpdate(timeSeriesDataItem17);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries23.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = month28.next();
//        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) month28);
//        org.jfree.data.time.Year year33 = month28.getYear();
//        java.lang.String str34 = year33.toString();
//        java.lang.String str35 = year33.toString();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        java.lang.String str37 = day36.toString();
//        boolean boolean38 = year33.equals((java.lang.Object) str37);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double43 = timeSeries42.getMaxY();
//        java.util.List list44 = timeSeries42.getItems();
//        timeSeries42.setNotify(false);
//        java.lang.String str47 = timeSeries42.getDomainDescription();
//        boolean boolean48 = year33.equals((java.lang.Object) timeSeries42);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year33, (java.lang.Number) 1560182350273L, false);
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        long long56 = timeSeries55.getMaximumItemAge();
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day57, (java.lang.Number) (byte) 100);
//        boolean boolean61 = timeSeriesDataItem59.equals((java.lang.Object) (short) 10);
//        boolean boolean62 = timeSeriesDataItem59.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries55.addOrUpdate(timeSeriesDataItem59);
//        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries65.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month70 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries65.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month70, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = month70.next();
//        timeSeries55.delete((org.jfree.data.time.RegularTimePeriod) month70);
//        timeSeries55.clear();
//        org.jfree.data.time.TimeSeries timeSeries76 = timeSeries3.addAndOrUpdate(timeSeries55);
//        java.beans.PropertyChangeListener propertyChangeListener77 = null;
//        timeSeries55.addPropertyChangeListener(propertyChangeListener77);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(year33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "100" + "'", str34.equals("100"));
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "100" + "'", str35.equals("100"));
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "10-June-2019" + "'", str37.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list44);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "hi!" + "'", str47.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 9223372036854775807L + "'", long56 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem63);
//        org.junit.Assert.assertNull(timeSeriesDataItem72);
//        org.junit.Assert.assertNotNull(regularTimePeriod73);
//        org.junit.Assert.assertNotNull(timeSeries76);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries13.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month18);
        java.lang.String str23 = month18.toString();
        org.jfree.data.time.Year year24 = month18.getYear();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries26.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month31.previous();
        long long35 = month31.getFirstMillisecond();
        boolean boolean36 = month18.equals((java.lang.Object) long35);
        long long37 = month18.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "October 100" + "'", str23.equals("October 100"));
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertNull(timeSeriesDataItem33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-58987929600000L) + "'", long35 == (-58987929600000L));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1210L + "'", long37 == 1210L);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test066");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.List list5 = timeSeries3.getItems();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, (java.lang.Number) (byte) 100);
//        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) (short) 10);
//        timeSeries3.add(timeSeriesDataItem8);
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener12);
//        timeSeries3.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getMiddleMillisecond(calendar17);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int21 = fixedMillisecond16.compareTo((java.lang.Object) "hi!");
//        java.util.Date date22 = fixedMillisecond16.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond16.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond16.next();
//        java.lang.String str25 = fixedMillisecond16.toString();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) 1560182375196L);
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond16.getFirstMillisecond(calendar28);
//        java.util.Date date30 = fixedMillisecond16.getTime();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list5);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560182429760L + "'", long18 == 1560182429760L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Mon Jun 10 09:00:29 PDT 2019" + "'", str25.equals("Mon Jun 10 09:00:29 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182429760L + "'", long29 == 1560182429760L);
//        org.junit.Assert.assertNotNull(date30);
//    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test067");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
//        java.util.Calendar calendar7 = null;
//        try {
//            month6.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182430002L + "'", long2 == 1560182430002L);
//        org.junit.Assert.assertNotNull(date3);
//    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test068");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        long long6 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        java.lang.String str8 = fixedMillisecond0.toString();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj12 = null;
//        int int13 = month11.compareTo(obj12);
//        org.jfree.data.time.Year year14 = month11.getYear();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        int int19 = year14.compareTo((java.lang.Object) timeSeries16);
//        boolean boolean20 = fixedMillisecond0.equals((java.lang.Object) timeSeries16);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj24 = null;
//        int int25 = month23.compareTo(obj24);
//        org.jfree.data.time.Year year26 = month23.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) year26);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener30 = null;
//        timeSeries29.addChangeListener(seriesChangeListener30);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        boolean boolean34 = timeSeries29.equals((java.lang.Object) timePeriodFormatException33);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        timePeriodFormatException33.addSuppressed((java.lang.Throwable) timePeriodFormatException36);
//        int int38 = year26.compareTo((java.lang.Object) timePeriodFormatException33);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year26, (double) 1560182361147L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond41.getMiddleMillisecond(calendar42);
//        java.util.Date date44 = fixedMillisecond41.getTime();
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date44);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond(date44);
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month(date44);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo49 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent50 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 100, seriesChangeInfo49);
//        java.lang.Object obj51 = seriesChangeEvent50.getSource();
//        boolean boolean52 = month47.equals((java.lang.Object) seriesChangeEvent50);
//        boolean boolean53 = timeSeriesDataItem40.equals((java.lang.Object) month47);
//        java.util.Calendar calendar54 = null;
//        try {
//            month47.peg(calendar54);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182430028L + "'", long2 == 1560182430028L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182430028L + "'", long6 == 1560182430028L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Mon Jun 10 09:00:30 PDT 2019" + "'", str8.equals("Mon Jun 10 09:00:30 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560182430084L + "'", long43 == 1560182430084L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + obj51 + "' != '" + (short) 100 + "'", obj51.equals((short) 100));
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test069");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
//        java.lang.String str4 = timeSeries3.getDescription();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
//        java.lang.Object obj6 = timeSeries3.clone();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) (byte) 100);
//        boolean boolean11 = timeSeriesDataItem9.equals((java.lang.Object) (short) 10);
//        boolean boolean12 = timeSeriesDataItem9.isSelected();
//        java.lang.Object obj13 = timeSeriesDataItem9.clone();
//        java.lang.Number number14 = null;
//        timeSeriesDataItem9.setValue(number14);
//        timeSeriesDataItem9.setSelected(true);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate(timeSeriesDataItem9);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries20.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) day23, (double) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day23.next();
//        long long28 = day23.getMiddleMillisecond();
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj33 = null;
//        int int34 = month32.compareTo(obj33);
//        org.jfree.data.time.Year year35 = month32.getYear();
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(1, year35);
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day23, (org.jfree.data.time.RegularTimePeriod) year35);
//        java.lang.Class class38 = timeSeries3.getTimePeriodClass();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560193199999L + "'", long28 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(year35);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertNotNull(class38);
//    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test070");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.Year year7 = month6.getYear();
//        java.lang.Object obj8 = null;
//        int int9 = year7.compareTo(obj8);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182430662L + "'", long2 == 1560182430662L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(35);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        long long2 = year1.getSerialIndex();
        long long3 = year1.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries9.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month14.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries7.addOrUpdate(regularTimePeriod17, (double) (short) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries7.addChangeListener(seriesChangeListener20);
        java.util.Collection collection22 = timeSeries7.getTimePeriods();
        timeSeries7.setRangeDescription("");
        int int25 = year1.compareTo((java.lang.Object) timeSeries7);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries7);
        timeSeries7.setDomainDescription("");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries7.removeChangeListener(seriesChangeListener29);
        try {
            timeSeries7.update((int) (short) 10, (java.lang.Number) 1560182374426L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test073");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        long long15 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double21 = timeSeries20.getMaxY();
//        int int22 = timeSeries20.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 6);
//        long long26 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond23.previous();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        int int29 = timeSeries28.getItemCount();
//        long long30 = timeSeries28.getMaximumItemAge();
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182430768L + "'", long11 == 1560182430768L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182430768L + "'", long15 == 1560182430768L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182430770L + "'", long26 == 1560182430770L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 6);
        int int10 = month6.compareTo((java.lang.Object) 0L);
        int int11 = month6.getYearValue();
        java.lang.String str12 = month6.toString();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "October 100" + "'", str12.equals("October 100"));
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test075");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond6.getMiddleMillisecond(calendar9);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double15 = timeSeries14.getMaxY();
//        int int16 = timeSeries14.getItemCount();
//        timeSeries14.setRangeDescription("October 100");
//        boolean boolean19 = fixedMillisecond6.equals((java.lang.Object) timeSeries14);
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond6.getFirstMillisecond(calendar20);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560182431020L + "'", long10 == 1560182431020L);
//        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560182431020L + "'", long21 == 1560182431020L);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.removeAgedItems(1560182348434L, true);
        int int7 = timeSeries1.getItemCount();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 100);
        boolean boolean14 = timeSeriesDataItem12.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem12.setValue((java.lang.Number) 9);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long21 = timeSeries20.getMaximumItemAge();
        boolean boolean22 = timeSeriesDataItem12.equals((java.lang.Object) timeSeries20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries1.addOrUpdate(timeSeriesDataItem12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem23.getPeriod();
        java.lang.Number number25 = timeSeriesDataItem23.getValue();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 9223372036854775807L + "'", number25.equals(9223372036854775807L));
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test078");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.previous();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double12 = timeSeries11.getMaxY();
//        java.util.List list13 = timeSeries11.getItems();
//        int int14 = timeSeries11.getItemCount();
//        boolean boolean15 = fixedMillisecond0.equals((java.lang.Object) timeSeries11);
//        java.lang.Class class16 = timeSeries11.getTimePeriodClass();
//        timeSeries11.setNotify(false);
//        java.lang.String str19 = timeSeries11.getRangeDescription();
//        long long20 = timeSeries11.getMaximumItemAge();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182431229L + "'", long2 == 1560182431229L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNull(class16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1, seriesChangeInfo1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = seriesChangeEvent2.getSummary();
        org.junit.Assert.assertNull(seriesChangeInfo3);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test080");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
//        long long14 = day8.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, (java.lang.Number) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day8.next();
//        org.jfree.data.time.SerialDate serialDate18 = day8.getSerialDate();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate18);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(serialDate18);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str9 = timeSeries8.getDescription();
        java.lang.String str10 = timeSeries8.getDomainDescription();
        java.util.Collection collection11 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries8.addChangeListener(seriesChangeListener12);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(collection11);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Mon Jun 10 08:59:30 PDT 2019");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test084");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double7 = timeSeries6.getMaxY();
//        java.util.List list8 = timeSeries6.getItems();
//        timeSeries6.setNotify(false);
//        java.lang.String str11 = timeSeries6.getDomainDescription();
//        int int12 = day0.compareTo((java.lang.Object) timeSeries6);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double17 = timeSeries16.getMaxY();
//        timeSeries16.removeAgedItems((long) 10, false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries16.removeChangeListener(seriesChangeListener21);
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        int int26 = month25.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month25.next();
//        timeSeries16.add(regularTimePeriod27, (double) 1560182345775L, false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
//        long long32 = fixedMillisecond31.getLastMillisecond();
//        java.util.Calendar calendar33 = null;
//        fixedMillisecond31.peg(calendar33);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException39 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int40 = fixedMillisecond35.compareTo((java.lang.Object) "hi!");
//        java.util.Date date41 = fixedMillisecond35.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(date41);
//        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (java.lang.Number) 1560182352795L, true);
//        boolean boolean48 = fixedMillisecond42.equals((java.lang.Object) 1560182425884L);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560182431596L + "'", long32 == 1560182431596L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560182431597L + "'", long37 == 1560182431597L);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeSeries43);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test085");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        timeSeries3.setRangeDescription("October 100");
//        java.util.Collection collection8 = timeSeries3.getTimePeriods();
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond12.getMiddleMillisecond(calendar13);
//        java.util.Date date15 = fixedMillisecond12.getEnd();
//        boolean boolean16 = day11.equals((java.lang.Object) fixedMillisecond12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond12.previous();
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond12);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) (byte) 100);
//        boolean boolean23 = timeSeriesDataItem21.equals((java.lang.Object) (short) 10);
//        timeSeriesDataItem21.setValue((java.lang.Number) 9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeriesDataItem21.getPeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeriesDataItem21.getPeriod();
//        java.lang.Number number28 = timeSeries3.getValue(regularTimePeriod27);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560182431759L + "'", long14 == 1560182431759L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNull(number28);
//    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test086");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        boolean boolean8 = fixedMillisecond0.equals((java.lang.Object) 1560182343140L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1560182341157L);
//        timeSeriesDataItem10.setValue((java.lang.Number) 1560182415500L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182431956L + "'", long2 == 1560182431956L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.removeAgedItems((long) (byte) 100, false);
        java.lang.Comparable comparable9 = timeSeries3.getKey();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 100);
        boolean boolean14 = timeSeriesDataItem12.equals((java.lang.Object) (short) 10);
        boolean boolean15 = timeSeriesDataItem12.isSelected();
        java.lang.Object obj16 = timeSeriesDataItem12.clone();
        java.lang.Number number17 = null;
        timeSeriesDataItem12.setValue(number17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeriesDataItem12.getPeriod();
        timeSeries3.add(timeSeriesDataItem12, false);
        try {
            timeSeries3.update(2, (java.lang.Number) 1560182384325L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 10.0d + "'", comparable9.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test088");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
//        long long3 = year1.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, (java.lang.Number) (byte) 100);
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int18 = fixedMillisecond13.compareTo((java.lang.Object) "hi!");
//        long long19 = fixedMillisecond13.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond13.next();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double25 = timeSeries24.getMaxY();
//        int int26 = timeSeries24.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) 6);
//        long long30 = fixedMillisecond27.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond27.previous();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
//        timeSeries32.addChangeListener(seriesChangeListener33);
//        int int35 = timeSeries32.getMaximumItemCount();
//        int int36 = year1.compareTo((java.lang.Object) timeSeries32);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day37, (java.lang.Number) (byte) 100);
//        boolean boolean41 = timeSeriesDataItem39.equals((java.lang.Object) (short) 10);
//        boolean boolean42 = timeSeriesDataItem39.isSelected();
//        java.lang.Object obj43 = timeSeriesDataItem39.clone();
//        java.lang.Number number44 = null;
//        timeSeriesDataItem39.setValue(number44);
//        timeSeriesDataItem39.setSelected(true);
//        java.lang.Object obj48 = timeSeriesDataItem39.clone();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries32.addOrUpdate(timeSeriesDataItem39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = null;
//        try {
//            org.jfree.data.time.TimeSeries timeSeries52 = timeSeries32.createCopy(regularTimePeriod50, regularTimePeriod51);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'start' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62104204800001L) + "'", long3 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182431992L + "'", long15 == 1560182431992L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560182431992L + "'", long19 == 1560182431992L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560182431997L + "'", long30 == 1560182431997L);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2147483647 + "'", int35 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(obj43);
//        org.junit.Assert.assertNotNull(obj48);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem49);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        java.util.Date date5 = month2.getEnd();
        int int7 = month2.compareTo((java.lang.Object) 1560182345060L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.next();
        org.jfree.data.time.Year year9 = month2.getYear();
        long long10 = year9.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-58979980800001L) + "'", long10 == (-58979980800001L));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        timeSeries1.fireSeriesChanged();
        timeSeries1.setDescription("Mon Jun 10 08:59:09 PDT 2019");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener12);
        java.lang.Class class14 = timeSeries1.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double19 = timeSeries18.getMaxY();
        java.util.List list20 = timeSeries18.getItems();
        timeSeries18.removeAgedItems((long) (byte) 100, false);
        java.lang.Comparable comparable24 = timeSeries18.getKey();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj28 = null;
        int int29 = month27.compareTo(obj28);
        java.util.Date date30 = month27.getEnd();
        java.util.Date date31 = month27.getStart();
        boolean boolean32 = timeSeries18.equals((java.lang.Object) date31);
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date31, timeZone33);
        org.junit.Assert.assertNotNull(class14);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + 10.0d + "'", comparable24.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(regularTimePeriod34);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double9 = timeSeries8.getMaxY();
        int int10 = timeSeries8.getItemCount();
        timeSeries8.setRangeDescription("October 100");
        java.util.Collection collection13 = timeSeries8.getTimePeriods();
        long long14 = timeSeries8.getMaximumItemAge();
        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        timeSeries3.setDomainDescription("org.jfree.data.general.SeriesException: ");
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223372036854775807L + "'", long14 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(collection15);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test092");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
//        java.lang.String str14 = day8.toString();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
//        long long18 = year16.getLastMillisecond();
//        int int19 = year16.getYear();
//        boolean boolean20 = day8.equals((java.lang.Object) year16);
//        long long21 = year16.getLastMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10-June-2019" + "'", str14.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-62104204800001L) + "'", long18 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-62104204800001L) + "'", long21 == (-62104204800001L));
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getItemCount();
        timeSeries3.setRangeDescription("October 100");
        timeSeries3.setNotify(true);
        java.lang.String str10 = timeSeries3.getDescription();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj14 = null;
        int int15 = month13.compareTo(obj14);
        java.util.Date date16 = month13.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (double) 1560182343140L);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month13);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.removeAgedItems((long) (byte) 100, false);
        java.lang.Comparable comparable9 = timeSeries3.getKey();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 100);
        boolean boolean14 = timeSeriesDataItem12.equals((java.lang.Object) (short) 10);
        boolean boolean15 = timeSeriesDataItem12.isSelected();
        timeSeriesDataItem12.setValue((java.lang.Number) (byte) 100);
        timeSeries3.add(timeSeriesDataItem12, false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeriesDataItem12.getPeriod();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 10.0d + "'", comparable9.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-2019), (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test096");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond0.peg(calendar4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond0.getMiddleMillisecond(calendar8);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182432307L + "'", long2 == 1560182432307L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182432307L + "'", long9 == 1560182432307L);
//    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test097");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43626L + "'", long1 == 43626L);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.Object obj6 = timeSeries3.clone();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) (byte) 100);
        boolean boolean11 = timeSeriesDataItem9.equals((java.lang.Object) (short) 10);
        boolean boolean12 = timeSeriesDataItem9.isSelected();
        java.lang.Object obj13 = timeSeriesDataItem9.clone();
        java.lang.Number number14 = null;
        timeSeriesDataItem9.setValue(number14);
        timeSeriesDataItem9.setSelected(true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate(timeSeriesDataItem9);
        long long19 = timeSeries3.getMaximumItemAge();
        int int20 = timeSeries3.getMaximumItemCount();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2147483647 + "'", int20 == 2147483647);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560182417164L);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test100");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
//        java.lang.String str4 = timeSeries3.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
//        java.lang.String str9 = timeSeries8.getDescription();
//        java.lang.String str10 = timeSeries8.getDomainDescription();
//        java.util.Collection collection11 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
//        timeSeries8.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int19 = fixedMillisecond14.compareTo((java.lang.Object) "hi!");
//        java.util.Date date20 = fixedMillisecond14.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond22.previous();
//        timeSeries8.delete(regularTimePeriod23);
//        try {
//            timeSeries8.delete((-1), (-1), true);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560182432395L + "'", long16 == 1560182432395L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        int int3 = month2.getMonth();
        int int4 = month2.getMonth();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double9 = timeSeries8.getMaxY();
        java.util.List list10 = timeSeries8.getItems();
        timeSeries8.removeAgedItems((long) (byte) 100, false);
        java.util.List list14 = timeSeries8.getItems();
        boolean boolean15 = month2.equals((java.lang.Object) list14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test102");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (byte) 100);
//        boolean boolean4 = timeSeriesDataItem2.equals((java.lang.Object) (short) 10);
//        boolean boolean5 = timeSeriesDataItem2.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double10 = timeSeries9.getMaxY();
//        int int11 = timeSeries9.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 6);
//        long long15 = fixedMillisecond12.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double20 = timeSeries19.getMaxY();
//        java.util.List list21 = timeSeries19.getItems();
//        timeSeries19.removeAgedItems((long) (byte) 100, false);
//        boolean boolean25 = fixedMillisecond12.equals((java.lang.Object) (byte) 100);
//        int int26 = timeSeriesDataItem2.compareTo((java.lang.Object) fixedMillisecond12);
//        long long27 = fixedMillisecond12.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182432426L + "'", long15 == 1560182432426L);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list21);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560182432426L + "'", long27 == 1560182432426L);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, 3);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day4.next();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj12 = null;
        int int13 = month11.compareTo(obj12);
        java.util.Date date14 = month11.getEnd();
        int int16 = month11.compareTo((java.lang.Object) 1560182345060L);
        long long17 = month11.getSerialIndex();
        int int18 = month11.getYearValue();
        int int19 = month11.getMonth();
        int int20 = day4.compareTo((java.lang.Object) int19);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1210L + "'", long17 == 1210L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str13 = timeSeries12.getDescription();
        java.util.Collection collection14 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        timeSeries12.setMaximumItemAge(1560182348409L);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str21 = timeSeries20.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries20);
        java.lang.Object obj23 = timeSeries20.clone();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (java.lang.Number) (byte) 100);
        boolean boolean28 = timeSeriesDataItem26.equals((java.lang.Object) (short) 10);
        boolean boolean29 = timeSeriesDataItem26.isSelected();
        java.lang.Object obj30 = timeSeriesDataItem26.clone();
        java.lang.Number number31 = null;
        timeSeriesDataItem26.setValue(number31);
        timeSeriesDataItem26.setSelected(true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries20.addOrUpdate(timeSeriesDataItem26);
        boolean boolean36 = timeSeriesDataItem26.isSelected();
        java.lang.Object obj37 = timeSeriesDataItem26.clone();
        timeSeries12.add(timeSeriesDataItem26, false);
        java.lang.Object obj40 = timeSeriesDataItem26.clone();
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(obj40);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 100, seriesChangeInfo1);
        java.lang.String str3 = seriesChangeEvent2.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = seriesChangeEvent2.getSummary();
        java.lang.String str5 = seriesChangeEvent2.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo6);
        java.lang.String str8 = seriesChangeEvent2.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str3.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertNull(seriesChangeInfo4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str5.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str8.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries3.addChangeListener(seriesChangeListener16);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries3.removeChangeListener(seriesChangeListener18);
        timeSeries3.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries23.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries27.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day30.previous();
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) day30, (double) 6);
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) day30, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries37.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day40.previous();
        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) day40, (double) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day40.next();
        timeSeries23.add(regularTimePeriod44, (double) 1560182340527L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener47 = null;
        timeSeries23.addChangeListener(seriesChangeListener47);
        boolean boolean49 = timeSeries3.equals((java.lang.Object) timeSeries23);
        timeSeries23.setRangeDescription("Mon Jun 10 08:59:32 PDT 2019");
        timeSeries23.removeAgedItems(false);
        timeSeries23.removeAgedItems(false);
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 100, seriesChangeInfo1);
        java.lang.Object obj3 = seriesChangeEvent2.getSource();
        java.lang.String str4 = seriesChangeEvent2.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = seriesChangeEvent2.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo6);
        java.lang.Object obj8 = seriesChangeEvent2.getSource();
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (short) 100 + "'", obj3.equals((short) 100));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertNull(seriesChangeInfo5);
        org.junit.Assert.assertTrue("'" + obj8 + "' != '" + (short) 100 + "'", obj8.equals((short) 100));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean8 = timeSeries3.equals((java.lang.Object) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2, 11);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        java.util.Date date5 = month2.getEnd();
        int int7 = month2.compareTo((java.lang.Object) 1560182345060L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.next();
        org.jfree.data.time.Year year9 = month2.getYear();
        long long10 = year9.getFirstMillisecond();
        int int11 = year9.getYear();
        long long12 = year9.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-59011603200000L) + "'", long10 == (-59011603200000L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-58979980800001L) + "'", long12 == (-58979980800001L));
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test112");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        long long15 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double21 = timeSeries20.getMaxY();
//        int int22 = timeSeries20.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 6);
//        long long26 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond23.previous();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
//        timeSeries28.addChangeListener(seriesChangeListener29);
//        boolean boolean31 = timeSeries28.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond32.getMiddleMillisecond(calendar33);
//        java.util.Date date35 = fixedMillisecond32.getTime();
//        java.util.Calendar calendar36 = null;
//        fixedMillisecond32.peg(calendar36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond32.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = fixedMillisecond32.next();
//        timeSeries28.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 1560182352357L);
//        int int42 = timeSeries28.getMaximumItemCount();
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182432884L + "'", long11 == 1560182432884L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182432884L + "'", long15 == 1560182432884L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182432886L + "'", long26 == 1560182432886L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560182432887L + "'", long34 == 1560182432887L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2147483647 + "'", int42 == 2147483647);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-9999), 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test114");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false);
//        int int11 = timeSeries10.getItemCount();
//        timeSeries10.fireSeriesChanged();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        int int16 = month15.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month15.next();
//        long long18 = month15.getFirstMillisecond();
//        java.util.Date date19 = month15.getEnd();
//        org.jfree.data.time.Year year20 = month15.getYear();
//        java.lang.Number number21 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) year20);
//        int int22 = fixedMillisecond8.compareTo((java.lang.Object) timeSeries10);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo23 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent24 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond8, seriesChangeInfo23);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries26.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) (byte) 100);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate34 = day29.getSerialDate();
//        java.lang.String str35 = day29.toString();
//        int int36 = fixedMillisecond8.compareTo((java.lang.Object) day29);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day37.previous();
//        java.lang.String str39 = day37.toString();
//        long long40 = day37.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day37, (double) 1560182359592L);
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day37, "", "");
//        boolean boolean46 = fixedMillisecond8.equals((java.lang.Object) "");
//        java.util.Calendar calendar47 = null;
//        fixedMillisecond8.peg(calendar47);
//        long long49 = fixedMillisecond8.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182433042L + "'", long2 == 1560182433042L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-58987929600000L) + "'", long18 == (-58987929600000L));
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(year20);
//        org.junit.Assert.assertNull(number21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "10-June-2019" + "'", str35.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "10-June-2019" + "'", str39.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560150000000L + "'", long40 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1560182433042L + "'", long49 == 1560182433042L);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Mon Jun 10 08:59:28 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        timeSeries3.removeAgedItems(true);
        timeSeries3.setKey((java.lang.Comparable) '#');
        try {
            java.lang.Number number11 = timeSeries3.getValue(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test117");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        long long9 = fixedMillisecond6.getFirstMillisecond();
//        boolean boolean11 = fixedMillisecond6.equals((java.lang.Object) 1560182358349L);
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond6.getLastMillisecond(calendar12);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182433216L + "'", long9 == 1560182433216L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560182433216L + "'", long13 == 1560182433216L);
//    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test118");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
//        long long14 = day8.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day8.previous();
//        int int16 = day8.getYear();
//        java.util.Date date17 = day8.getStart();
//        int int18 = day8.getMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560182365786L);
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182365786L, "0", "October 100");
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test120");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.addChangeListener(seriesChangeListener8);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener10);
//        int int12 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
//        java.util.Date date16 = fixedMillisecond13.getTime();
//        java.util.Calendar calendar17 = null;
//        fixedMillisecond13.peg(calendar17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond13.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) 1.0f);
//        boolean boolean22 = timeSeries3.isEmpty();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182433298L + "'", long15 == 1560182433298L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test121");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) 1560182359592L);
//        timeSeriesDataItem9.setSelected(false);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182433316L + "'", long2 == 1560182433316L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries15.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day18, (double) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day18.next();
        timeSeries1.add(regularTimePeriod22, (double) 1560182340527L);
        long long25 = timeSeries1.getMaximumItemAge();
        long long26 = timeSeries1.getMaximumItemAge();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries1.removeChangeListener(seriesChangeListener27);
        org.jfree.data.time.TimeSeries timeSeries29 = null;
        try {
            java.util.Collection collection30 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 9223372036854775807L + "'", long26 == 9223372036854775807L);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test123");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
//        java.util.TimeZone timeZone8 = null;
//        java.util.Locale locale9 = null;
//        try {
//            org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date6, timeZone8, locale9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182433357L + "'", long2 == 1560182433357L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
        java.lang.String str2 = year1.toString();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year1.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test125");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        timeSeries1.fireSeriesChanged();
//        timeSeries1.setDescription("Mon Jun 10 08:59:09 PDT 2019");
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener12);
//        double double14 = timeSeries1.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double19 = timeSeries18.getMaxY();
//        java.util.List list20 = timeSeries18.getItems();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) (byte) 100);
//        boolean boolean25 = timeSeriesDataItem23.equals((java.lang.Object) (short) 10);
//        timeSeries18.add(timeSeriesDataItem23);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.next();
//        long long30 = year28.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries32.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) (byte) 100);
//        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar41 = null;
//        long long42 = fixedMillisecond40.getMiddleMillisecond(calendar41);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException44 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int45 = fixedMillisecond40.compareTo((java.lang.Object) "hi!");
//        long long46 = fixedMillisecond40.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = fixedMillisecond40.next();
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double52 = timeSeries51.getMaxY();
//        int int53 = timeSeries51.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries51.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (double) 6);
//        long long57 = fixedMillisecond54.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = fixedMillisecond54.previous();
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond54);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener60 = null;
//        timeSeries59.addChangeListener(seriesChangeListener60);
//        int int62 = timeSeries59.getMaximumItemCount();
//        int int63 = year28.compareTo((java.lang.Object) timeSeries59);
//        java.lang.Object obj64 = timeSeries59.clone();
//        boolean boolean65 = timeSeriesDataItem23.equals((java.lang.Object) timeSeries59);
//        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries1.addAndOrUpdate(timeSeries59);
//        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double71 = timeSeries70.getMaxY();
//        int int72 = timeSeries70.getItemCount();
//        double double73 = timeSeries70.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries74 = timeSeries66.addAndOrUpdate(timeSeries70);
//        double double75 = timeSeries66.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries77 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries77.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = day80.previous();
//        timeSeries77.add((org.jfree.data.time.RegularTimePeriod) day80, (double) 6);
//        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = day84.previous();
//        int int86 = timeSeries77.getIndex((org.jfree.data.time.RegularTimePeriod) day84);
//        org.jfree.data.time.SerialDate serialDate87 = day84.getSerialDate();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem89 = timeSeries66.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day84, (double) 1560182398191L);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 9.223372036854776E18d + "'", double14 == 9.223372036854776E18d);
//        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list20);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-62104204800001L) + "'", long30 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560182433413L + "'", long42 == 1560182433413L);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560182433413L + "'", long46 == 1560182433413L);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560182433415L + "'", long57 == 1560182433415L);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2147483647 + "'", int62 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(obj64);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(timeSeries66);
//        org.junit.Assert.assertEquals((double) double71, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
//        org.junit.Assert.assertEquals((double) double73, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(timeSeries74);
//        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 9.223372036854776E18d + "'", double75 == 9.223372036854776E18d);
//        org.junit.Assert.assertNotNull(regularTimePeriod81);
//        org.junit.Assert.assertNotNull(regularTimePeriod85);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
//        org.junit.Assert.assertNotNull(serialDate87);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem89);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        timeSeries3.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = null;
        try {
            int int10 = timeSeries3.getIndex(regularTimePeriod9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries13.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.Year year23 = month18.getYear();
        java.lang.String str24 = year23.toString();
        java.lang.String str25 = year23.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year23.next();
        java.util.Calendar calendar27 = null;
        try {
            long long28 = year23.getLastMillisecond(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "100" + "'", str24.equals("100"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "100" + "'", str25.equals("100"));
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj9 = null;
        int int10 = month8.compareTo(obj9);
        org.jfree.data.time.Year year11 = month8.getYear();
        java.lang.String str12 = year11.toString();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double17 = timeSeries16.getMaxY();
        java.util.List list18 = timeSeries16.getItems();
        timeSeries16.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries16.createCopy((int) (byte) 1, 9999);
        boolean boolean24 = year11.equals((java.lang.Object) timeSeries23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year11.next();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year11, (double) 1560182376166L);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day28, (java.lang.Number) (byte) 100);
        boolean boolean32 = timeSeriesDataItem30.equals((java.lang.Object) (short) 10);
        boolean boolean33 = timeSeriesDataItem30.isSelected();
        java.lang.Object obj34 = timeSeriesDataItem30.clone();
        java.lang.Number number35 = null;
        timeSeriesDataItem30.setValue(number35);
        timeSeriesDataItem30.setSelected(true);
        timeSeriesDataItem30.setValue((java.lang.Number) 1560182356794L);
        try {
            timeSeries3.add(timeSeriesDataItem30);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100" + "'", str12.equals("100"));
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(obj34);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test129");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.previous();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double12 = timeSeries11.getMaxY();
//        java.util.List list13 = timeSeries11.getItems();
//        int int14 = timeSeries11.getItemCount();
//        boolean boolean15 = fixedMillisecond0.equals((java.lang.Object) timeSeries11);
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond0.getLastMillisecond(calendar16);
//        java.util.Date date18 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date18);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date18);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182434167L + "'", long2 == 1560182434167L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182434167L + "'", long17 == 1560182434167L);
//        org.junit.Assert.assertNotNull(date18);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getStart();
        java.util.TimeZone timeZone2 = null;
        try {
            org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test131");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        timeSeries1.fireSeriesChanged();
//        timeSeries1.setDescription("Mon Jun 10 08:59:09 PDT 2019");
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener12);
//        double double14 = timeSeries1.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double19 = timeSeries18.getMaxY();
//        java.util.List list20 = timeSeries18.getItems();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) (byte) 100);
//        boolean boolean25 = timeSeriesDataItem23.equals((java.lang.Object) (short) 10);
//        timeSeries18.add(timeSeriesDataItem23);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.next();
//        long long30 = year28.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries32.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) (byte) 100);
//        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar41 = null;
//        long long42 = fixedMillisecond40.getMiddleMillisecond(calendar41);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException44 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int45 = fixedMillisecond40.compareTo((java.lang.Object) "hi!");
//        long long46 = fixedMillisecond40.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = fixedMillisecond40.next();
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double52 = timeSeries51.getMaxY();
//        int int53 = timeSeries51.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries51.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (double) 6);
//        long long57 = fixedMillisecond54.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = fixedMillisecond54.previous();
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond54);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener60 = null;
//        timeSeries59.addChangeListener(seriesChangeListener60);
//        int int62 = timeSeries59.getMaximumItemCount();
//        int int63 = year28.compareTo((java.lang.Object) timeSeries59);
//        java.lang.Object obj64 = timeSeries59.clone();
//        boolean boolean65 = timeSeriesDataItem23.equals((java.lang.Object) timeSeries59);
//        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries1.addAndOrUpdate(timeSeries59);
//        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double71 = timeSeries70.getMaxY();
//        int int72 = timeSeries70.getItemCount();
//        double double73 = timeSeries70.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries74 = timeSeries66.addAndOrUpdate(timeSeries70);
//        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year(0);
//        long long79 = year78.getSerialIndex();
//        long long80 = year78.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries84 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
//        java.lang.String str85 = timeSeries84.getDescription();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent86 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries84);
//        int int87 = year78.compareTo((java.lang.Object) seriesChangeEvent86);
//        boolean boolean88 = year76.equals((java.lang.Object) int87);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod89 = year76.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem91 = timeSeries74.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year76, 1.0d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 9.223372036854776E18d + "'", double14 == 9.223372036854776E18d);
//        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list20);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-62104204800001L) + "'", long30 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560182434313L + "'", long42 == 1560182434313L);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560182434313L + "'", long46 == 1560182434313L);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560182434314L + "'", long57 == 1560182434314L);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2147483647 + "'", int62 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(obj64);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(timeSeries66);
//        org.junit.Assert.assertEquals((double) double71, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
//        org.junit.Assert.assertEquals((double) double73, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(timeSeries74);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 0L + "'", long79 == 0L);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 0L + "'", long80 == 0L);
//        org.junit.Assert.assertNull(str85);
//        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod89);
//        org.junit.Assert.assertNull(timeSeriesDataItem91);
//    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test132");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 6);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
//        java.lang.String str12 = timeSeries11.getDescription();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries11);
//        java.lang.Object obj14 = timeSeries11.clone();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day15, (java.lang.Number) (byte) 100);
//        boolean boolean19 = timeSeriesDataItem17.equals((java.lang.Object) (short) 10);
//        boolean boolean20 = timeSeriesDataItem17.isSelected();
//        java.lang.Object obj21 = timeSeriesDataItem17.clone();
//        java.lang.Number number22 = null;
//        timeSeriesDataItem17.setValue(number22);
//        timeSeriesDataItem17.setSelected(true);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries11.addOrUpdate(timeSeriesDataItem17);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries28.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day31.previous();
//        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) day31, (double) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = day31.next();
//        long long36 = day31.getMiddleMillisecond();
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj41 = null;
//        int int42 = month40.compareTo(obj41);
//        org.jfree.data.time.Year year43 = month40.getYear();
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(1, year43);
//        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) day31, (org.jfree.data.time.RegularTimePeriod) year43);
//        java.lang.String str46 = day31.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day31, (java.lang.Number) 1560182377967L);
//        try {
//            timeSeries1.delete((-2019), 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -2019");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNull(str12);
//        org.junit.Assert.assertNotNull(obj14);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(obj21);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560193199999L + "'", long36 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertNotNull(year43);
//        org.junit.Assert.assertNotNull(timeSeries45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "10-June-2019" + "'", str46.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem48);
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test133");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.Year year7 = month6.getYear();
//        long long8 = month6.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182434805L + "'", long2 == 1560182434805L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1559372400000L + "'", long8 == 1559372400000L);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test135");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        long long20 = day18.getFirstMillisecond();
//        int int21 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day18);
//        long long22 = day18.getSerialIndex();
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560150000000L + "'", long20 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 43626L + "'", long22 == 43626L);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Mon Jun 10 08:59:13 PDT 2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Mon Jun 10 08:59:13 PDT 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: Mon Jun 10 08:59:13 PDT 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Mon Jun 10 08:59:13 PDT 2019" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: Mon Jun 10 08:59:13 PDT 2019"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("6");
        org.junit.Assert.assertNotNull(year1);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test138");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
//        long long2 = year1.getSerialIndex();
//        long long3 = year1.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        long long5 = fixedMillisecond4.getMiddleMillisecond();
//        int int6 = year1.compareTo((java.lang.Object) fixedMillisecond4);
//        int int7 = year1.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year1.previous();
//        int int9 = year1.getYear();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560182434917L + "'", long5 == 1560182434917L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(12, (int) 'a', 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 0, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test141");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        java.util.List list8 = timeSeries3.getItems();
//        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
//        java.util.Date date16 = fixedMillisecond13.getTime();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date16);
//        java.util.TimeZone timeZone19 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date16, timeZone19);
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date16, timeZone21);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond23.getMiddleMillisecond(calendar24);
//        java.util.Date date26 = fixedMillisecond23.getTime();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date26);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date26);
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date26);
//        java.util.TimeZone timeZone31 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date26, timeZone31);
//        java.util.Date date33 = null;
//        java.util.TimeZone timeZone34 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date33, timeZone34);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182434945L + "'", long15 == 1560182434945L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560182434946L + "'", long25 == 1560182434946L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(0);
        long long4 = year3.getSerialIndex();
        long long5 = year3.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str10 = timeSeries9.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries9);
        int int12 = year3.compareTo((java.lang.Object) seriesChangeEvent11);
        boolean boolean13 = year1.equals((java.lang.Object) int12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year1.previous();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-9999));
        int int17 = year1.compareTo((java.lang.Object) (-9999));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test143");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond6.getMiddleMillisecond(calendar9);
//        java.util.Calendar calendar11 = null;
//        fixedMillisecond6.peg(calendar11);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 1560182353546L);
//        java.util.Date date15 = fixedMillisecond6.getTime();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560182435109L + "'", long10 == 1560182435109L);
//        org.junit.Assert.assertNotNull(date15);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries15.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day18, (double) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day18.next();
        timeSeries1.add(regularTimePeriod22, (double) 1560182340527L);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(0);
        long long27 = year26.getSerialIndex();
        long long28 = year26.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries34.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries34.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month39, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month39.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries32.addOrUpdate(regularTimePeriod42, (double) (short) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener45 = null;
        timeSeries32.addChangeListener(seriesChangeListener45);
        java.util.Collection collection47 = timeSeries32.getTimePeriods();
        timeSeries32.setRangeDescription("");
        int int50 = year26.compareTo((java.lang.Object) timeSeries32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year26.previous();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
        int int53 = day52.getMonth();
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries1.createCopy(regularTimePeriod51, (org.jfree.data.time.RegularTimePeriod) day52);
        int int56 = day52.compareTo((java.lang.Object) "Mon Jun 10 08:59:05 PDT 2019");
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertNotNull(collection47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 6 + "'", int53 == 6);
        org.junit.Assert.assertNotNull(timeSeries54);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test145");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        java.util.List list8 = timeSeries3.getItems();
//        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int18 = fixedMillisecond13.compareTo((java.lang.Object) "hi!");
//        java.util.Date date19 = fixedMillisecond13.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date19);
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date19, timeZone22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date19);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182435267L + "'", long15 == 1560182435267L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        org.jfree.data.time.Year year5 = month2.getYear();
        java.lang.String str6 = year5.toString();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double11 = timeSeries10.getMaxY();
        java.util.List list12 = timeSeries10.getItems();
        timeSeries10.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries10.createCopy((int) (byte) 1, 9999);
        boolean boolean18 = year5.equals((java.lang.Object) timeSeries17);
        long long19 = year5.getSerialIndex();
        long long20 = year5.getSerialIndex();
        java.util.Calendar calendar21 = null;
        try {
            year5.peg(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 100L + "'", long20 == 100L);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test147");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        long long9 = fixedMillisecond6.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond6.previous();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries12.addChangeListener(seriesChangeListener13);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        boolean boolean17 = timeSeries12.equals((java.lang.Object) timePeriodFormatException16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day18, (java.lang.Number) (byte) 100);
//        boolean boolean22 = timeSeriesDataItem20.equals((java.lang.Object) (short) 10);
//        boolean boolean23 = timeSeriesDataItem20.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double28 = timeSeries27.getMaxY();
//        int int29 = timeSeries27.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (double) 6);
//        long long33 = fixedMillisecond30.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double38 = timeSeries37.getMaxY();
//        java.util.List list39 = timeSeries37.getItems();
//        timeSeries37.removeAgedItems((long) (byte) 100, false);
//        boolean boolean43 = fixedMillisecond30.equals((java.lang.Object) (byte) 100);
//        int int44 = timeSeriesDataItem20.compareTo((java.lang.Object) fixedMillisecond30);
//        int int45 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
//        timeSeries12.clear();
//        java.lang.String str47 = timeSeries12.getDescription();
//        java.lang.Object obj48 = timeSeries12.clone();
//        boolean boolean49 = fixedMillisecond6.equals((java.lang.Object) timeSeries12);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182435351L + "'", long9 == 1560182435351L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560182435388L + "'", long33 == 1560182435388L);
//        org.junit.Assert.assertEquals((double) double38, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list39);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
//        org.junit.Assert.assertNull(str47);
//        org.junit.Assert.assertNotNull(obj48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test148");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
//        long long10 = day4.getLastMillisecond();
//        java.util.Date date11 = day4.getEnd();
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date11);
//    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test149");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
//        java.util.Date date14 = day8.getEnd();
//        long long15 = day8.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560193199999L + "'", long15 == 1560193199999L);
//    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test150");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.previous();
//        java.util.Calendar calendar3 = null;
//        fixedMillisecond0.peg(calendar3);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182435536L + "'", long1 == 1560182435536L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries1.getNextTimePeriod();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) (byte) 100);
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 9223372036854775807L);
        org.jfree.data.time.SerialDate serialDate24 = day19.getSerialDate();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(serialDate24);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(serialDate24);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate24);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate24);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double34 = timeSeries33.getMaxY();
        java.util.List list35 = timeSeries33.getItems();
        timeSeries33.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries33.createCopy((int) (byte) 1, 9999);
        boolean boolean41 = day29.equals((java.lang.Object) (byte) 1);
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day29, (double) 1560182347240L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 10-June-2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean8 = timeSeries3.equals((java.lang.Object) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException14 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException14);
        org.jfree.data.general.SeriesException seriesException17 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException14.addSuppressed((java.lang.Throwable) seriesException17);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        int int7 = timeSeries3.getMaximumItemCount();
        double double8 = timeSeries3.getMinY();
        java.lang.Comparable comparable9 = timeSeries3.getKey();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 10.0d + "'", comparable9.equals(10.0d));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(5, (int) (short) 100, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries13.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month18);
        java.lang.String str23 = timeSeries3.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries25.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day28, (java.lang.Number) (byte) 100);
        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) day28, (java.lang.Number) 9223372036854775807L);
        timeSeries25.fireSeriesChanged();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day34, (java.lang.Number) (byte) 100);
        boolean boolean38 = timeSeriesDataItem36.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem36.setValue((java.lang.Number) 9);
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long45 = timeSeries44.getMaximumItemAge();
        boolean boolean46 = timeSeriesDataItem36.equals((java.lang.Object) timeSeries44);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries25.addOrUpdate(timeSeriesDataItem36);
        boolean boolean48 = timeSeriesDataItem47.isSelected();
        timeSeries3.add(timeSeriesDataItem47);
        java.util.Collection collection50 = timeSeries3.getTimePeriods();
        timeSeries3.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 9223372036854775807L + "'", long45 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(collection50);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        java.util.Date date5 = month2.getEnd();
        int int7 = month2.compareTo((java.lang.Object) 1560182345060L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.next();
        long long9 = month2.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-58985251200001L) + "'", long9 == (-58985251200001L));
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test157");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.List list5 = timeSeries3.getItems();
//        timeSeries3.removeAgedItems((long) (byte) 100, false);
//        java.lang.Comparable comparable9 = timeSeries3.getKey();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 100);
//        boolean boolean14 = timeSeriesDataItem12.equals((java.lang.Object) (short) 10);
//        boolean boolean15 = timeSeriesDataItem12.isSelected();
//        timeSeriesDataItem12.setValue((java.lang.Number) (byte) 100);
//        timeSeries3.add(timeSeriesDataItem12, false);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries21.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (java.lang.Number) (byte) 100);
//        timeSeries21.add((org.jfree.data.time.RegularTimePeriod) day24, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond29.getMiddleMillisecond(calendar30);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int34 = fixedMillisecond29.compareTo((java.lang.Object) "hi!");
//        long long35 = fixedMillisecond29.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond29.next();
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double41 = timeSeries40.getMaxY();
//        int int42 = timeSeries40.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43, (double) 6);
//        long long46 = fixedMillisecond43.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = fixedMillisecond43.previous();
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
//        int int49 = timeSeries48.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries3.addAndOrUpdate(timeSeries48);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener51);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list5);
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 10.0d + "'", comparable9.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560182435808L + "'", long31 == 1560182435808L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560182435808L + "'", long35 == 1560182435808L);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertEquals((double) double41, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560182435809L + "'", long46 == 1560182435809L);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(timeSeries48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertNotNull(timeSeries50);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        org.jfree.data.time.Year year5 = month2.getYear();
        java.lang.String str6 = year5.toString();
        int int7 = year5.getYear();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double12 = timeSeries11.getMaxY();
        java.util.List list13 = timeSeries11.getItems();
        timeSeries11.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries17.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day20, (java.lang.Number) (byte) 100);
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) day20, (java.lang.Number) 9223372036854775807L);
        org.jfree.data.time.SerialDate serialDate25 = day20.getSerialDate();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(serialDate25);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(serialDate25);
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) day27, (java.lang.Number) 1560182352596L, false);
        java.util.Date date31 = day27.getStart();
        int int32 = year5.compareTo((java.lang.Object) date31);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((int) (byte) 1, 9999);
        timeSeries10.fireSeriesChanged();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test160");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        timeSeries3.setMaximumItemAge((long) 12);
//        boolean boolean9 = timeSeries3.isEmpty();
//        timeSeries3.setMaximumItemAge(10L);
//        timeSeries3.setMaximumItemAge((long) (short) 100);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries3.addChangeListener(seriesChangeListener14);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries17.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day20, (java.lang.Number) (byte) 100);
//        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) day20, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate25 = day20.getSerialDate();
//        java.lang.String str26 = day20.toString();
//        timeSeries3.setKey((java.lang.Comparable) str26);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "10-June-2019" + "'", str26.equals("10-June-2019"));
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        int int3 = month2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        long long5 = month2.getFirstMillisecond();
        java.util.Date date6 = month2.getEnd();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-58987929600000L) + "'", long5 == (-58987929600000L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test162");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        long long9 = month8.getFirstMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month8);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month21.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries14.addOrUpdate(regularTimePeriod24, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries14.addChangeListener(seriesChangeListener27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.previous();
//        long long31 = day29.getFirstMillisecond();
//        int int32 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) day29);
//        long long33 = day29.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day29.previous();
//        timeSeries3.add(regularTimePeriod34, (double) 1560182341608L, false);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod34, "Mon Jun 10 08:59:09 PDT 2019", "org.jfree.data.time.TimePeriodFormatException: hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond41.getMiddleMillisecond(calendar42);
//        java.util.Date date44 = fixedMillisecond41.getTime();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond(date44);
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date44);
//        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) year47, (java.lang.Number) 1560182374632L);
//        double double50 = timeSeries40.getMaxY();
//        java.lang.String str51 = timeSeries40.getDomainDescription();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-58987929600000L) + "'", long9 == (-58987929600000L));
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560150000000L + "'", long31 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560150000000L + "'", long33 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560182436131L + "'", long43 == 1560182436131L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.560182374632E12d + "'", double50 == 1.560182374632E12d);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Mon Jun 10 08:59:09 PDT 2019" + "'", str51.equals("Mon Jun 10 08:59:09 PDT 2019"));
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 6);
        java.lang.String str3 = month2.toString();
        int int4 = month2.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str9 = timeSeries8.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries8);
        java.lang.Object obj11 = timeSeries8.clone();
        boolean boolean12 = month2.equals(obj11);
        java.lang.String str13 = month2.toString();
        java.util.Calendar calendar14 = null;
        try {
            month2.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "September 6" + "'", str3.equals("September 6"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "September 6" + "'", str13.equals("September 6"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        timeSeries1.setRangeDescription("hi!");
        timeSeries1.setNotify(false);
        timeSeries1.setDomainDescription("Mon Jun 10 08:59:55 PDT 2019");
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries15.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day18, (double) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day18.next();
        timeSeries1.add(regularTimePeriod22, (double) 1560182340527L);
        timeSeries1.setKey((java.lang.Comparable) '4');
        timeSeries1.setDomainDescription("Mon Jun 10 08:59:09 PDT 2019");
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        timeSeries3.setMaximumItemAge((long) 12);
        timeSeries3.fireSeriesChanged();
        java.lang.String str10 = timeSeries3.getRangeDescription();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test167");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        long long15 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double21 = timeSeries20.getMaxY();
//        int int22 = timeSeries20.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 6);
//        long long26 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond23.previous();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
//        timeSeries28.addChangeListener(seriesChangeListener29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day31, (java.lang.Number) (byte) 100);
//        boolean boolean35 = timeSeriesDataItem33.equals((java.lang.Object) (short) 10);
//        timeSeriesDataItem33.setSelected(false);
//        int int39 = timeSeriesDataItem33.compareTo((java.lang.Object) 1560182341157L);
//        java.lang.Number number40 = timeSeriesDataItem33.getValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries28.addOrUpdate(timeSeriesDataItem33);
//        timeSeriesDataItem33.setSelected(true);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182436380L + "'", long11 == 1560182436380L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182436380L + "'", long15 == 1560182436380L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182436381L + "'", long26 == 1560182436381L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + number40 + "' != '" + (byte) 100 + "'", number40.equals((byte) 100));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(9999);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test169");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener18);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries23.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day26.previous();
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) day26, (double) 6);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
//        java.lang.String str34 = timeSeries33.getDescription();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries33);
//        java.lang.Object obj36 = timeSeries33.clone();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day37, (java.lang.Number) (byte) 100);
//        boolean boolean41 = timeSeriesDataItem39.equals((java.lang.Object) (short) 10);
//        boolean boolean42 = timeSeriesDataItem39.isSelected();
//        java.lang.Object obj43 = timeSeriesDataItem39.clone();
//        java.lang.Number number44 = null;
//        timeSeriesDataItem39.setValue(number44);
//        timeSeriesDataItem39.setSelected(true);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = timeSeries33.addOrUpdate(timeSeriesDataItem39);
//        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries50.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = day53.previous();
//        timeSeries50.add((org.jfree.data.time.RegularTimePeriod) day53, (double) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = day53.next();
//        long long58 = day53.getMiddleMillisecond();
//        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj63 = null;
//        int int64 = month62.compareTo(obj63);
//        org.jfree.data.time.Year year65 = month62.getYear();
//        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month(1, year65);
//        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries33.createCopy((org.jfree.data.time.RegularTimePeriod) day53, (org.jfree.data.time.RegularTimePeriod) year65);
//        java.lang.String str68 = day53.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day53, (java.lang.Number) 1560182377967L);
//        java.lang.Number number71 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day53);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener72 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener72);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = timeSeries3.getNextTimePeriod();
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNull(str34);
//        org.junit.Assert.assertNotNull(obj36);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(obj43);
//        org.junit.Assert.assertNull(timeSeriesDataItem48);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560193199999L + "'", long58 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//        org.junit.Assert.assertNotNull(year65);
//        org.junit.Assert.assertNotNull(timeSeries67);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "10-June-2019" + "'", str68.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem70);
//        org.junit.Assert.assertTrue("'" + number71 + "' != '" + 10.0d + "'", number71.equals(10.0d));
//        org.junit.Assert.assertNotNull(regularTimePeriod74);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        timeSeries3.setMaximumItemCount(2019);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        int int3 = month2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        long long5 = month2.getSerialIndex();
        int int6 = month2.getMonth();
        org.jfree.data.time.Year year7 = month2.getYear();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("September 6");
        int int10 = month2.compareTo((java.lang.Object) "September 6");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1210L + "'", long5 == 1210L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test172");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond6.getMiddleMillisecond(calendar9);
//        java.util.Calendar calendar11 = null;
//        fixedMillisecond6.peg(calendar11);
//        java.util.Date date13 = fixedMillisecond6.getTime();
//        java.util.TimeZone timeZone14 = null;
//        java.util.Locale locale15 = null;
//        try {
//            org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date13, timeZone14, locale15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560182436915L + "'", long10 == 1560182436915L);
//        org.junit.Assert.assertNotNull(date13);
//    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test173");
//        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
//        long long1 = year0.getFirstMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond2.getMiddleMillisecond(calendar3);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException6 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int7 = fixedMillisecond2.compareTo((java.lang.Object) "hi!");
//        long long8 = fixedMillisecond2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond2.previous();
//        boolean boolean10 = year0.equals((java.lang.Object) regularTimePeriod9);
//        long long11 = year0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560182436930L + "'", long4 == 1560182436930L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560182436930L + "'", long8 == 1560182436930L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.removeAgedItems(1560182348434L, true);
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener7);
        timeSeries1.clear();
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test175");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        long long6 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        java.lang.String str8 = fixedMillisecond0.toString();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj12 = null;
//        int int13 = month11.compareTo(obj12);
//        org.jfree.data.time.Year year14 = month11.getYear();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        int int19 = year14.compareTo((java.lang.Object) timeSeries16);
//        boolean boolean20 = fixedMillisecond0.equals((java.lang.Object) timeSeries16);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj24 = null;
//        int int25 = month23.compareTo(obj24);
//        org.jfree.data.time.Year year26 = month23.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) year26);
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double32 = timeSeries31.getMaxY();
//        java.util.List list33 = timeSeries31.getItems();
//        timeSeries31.setNotify(false);
//        boolean boolean36 = timeSeries31.getNotify();
//        java.util.Collection collection37 = timeSeries16.getTimePeriodsUniqueToOtherSeries(timeSeries31);
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj41 = null;
//        int int42 = month40.compareTo(obj41);
//        org.jfree.data.time.Year year43 = month40.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year43.previous();
//        java.lang.String str45 = year43.toString();
//        int int46 = timeSeries16.getIndex((org.jfree.data.time.RegularTimePeriod) year43);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182437022L + "'", long2 == 1560182437022L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182437022L + "'", long6 == 1560182437022L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Mon Jun 10 09:00:37 PDT 2019" + "'", str8.equals("Mon Jun 10 09:00:37 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list33);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(collection37);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertNotNull(year43);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "100" + "'", str45.equals("100"));
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
//    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test176");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        java.lang.String str9 = timeSeries3.getDescription();
//        double double10 = timeSeries3.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double15 = timeSeries14.getMaxY();
//        java.util.List list16 = timeSeries14.getItems();
//        timeSeries14.setNotify(false);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj22 = null;
//        int int23 = month21.compareTo(obj22);
//        java.util.Date date24 = month21.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month21, (double) 1560182343140L);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem26);
//        timeSeries14.add(timeSeriesDataItem26);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
//        timeSeries30.addChangeListener(seriesChangeListener31);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException34 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        boolean boolean35 = timeSeries30.equals((java.lang.Object) timePeriodFormatException34);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day36, (java.lang.Number) (byte) 100);
//        boolean boolean40 = timeSeriesDataItem38.equals((java.lang.Object) (short) 10);
//        boolean boolean41 = timeSeriesDataItem38.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double46 = timeSeries45.getMaxY();
//        int int47 = timeSeries45.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries45.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (double) 6);
//        long long51 = fixedMillisecond48.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double56 = timeSeries55.getMaxY();
//        java.util.List list57 = timeSeries55.getItems();
//        timeSeries55.removeAgedItems((long) (byte) 100, false);
//        boolean boolean61 = fixedMillisecond48.equals((java.lang.Object) (byte) 100);
//        int int62 = timeSeriesDataItem38.compareTo((java.lang.Object) fixedMillisecond48);
//        int int63 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
//        timeSeries30.clear();
//        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = year67.next();
//        long long69 = year67.getLastMillisecond();
//        int int70 = year67.getYear();
//        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month(4, year67);
//        timeSeries30.setKey((java.lang.Comparable) month71);
//        boolean boolean73 = timeSeriesDataItem26.equals((java.lang.Object) timeSeries30);
//        boolean boolean74 = timeSeries3.equals((java.lang.Object) timeSeriesDataItem26);
//        java.lang.Object obj75 = timeSeriesDataItem26.clone();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 6.0d + "'", double10 == 6.0d);
//        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list16);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertEquals((double) double46, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560182437188L + "'", long51 == 1560182437188L);
//        org.junit.Assert.assertEquals((double) double56, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list57);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-62104204800001L) + "'", long69 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
//        org.junit.Assert.assertNotNull(obj75);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        timeSeries3.setNotify(false);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) (byte) 100);
        boolean boolean11 = timeSeriesDataItem9.equals((java.lang.Object) (short) 10);
        boolean boolean12 = timeSeriesDataItem9.isSelected();
        java.lang.Object obj13 = timeSeriesDataItem9.clone();
        timeSeries3.add(timeSeriesDataItem9, false);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        int int3 = month2.getMonth();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.removeAgedItems((long) (byte) 100, false);
        java.util.List list9 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double14 = timeSeries13.getMaxY();
        int int15 = timeSeries13.getItemCount();
        timeSeries13.setMaximumItemCount(1);
        boolean boolean18 = timeSeries3.equals((java.lang.Object) timeSeries13);
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        timeSeries3.setDescription("Mon Jun 10 08:59:09 PDT 2019");
        timeSeries3.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener24);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(collection19);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test180");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        timeSeries1.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries12.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) day19, (double) 6);
//        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) day19, 0.0d);
//        long long25 = day19.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day19.next();
//        org.jfree.data.time.SerialDate serialDate29 = day19.getSerialDate();
//        boolean boolean30 = timeSeries1.equals((java.lang.Object) day19);
//        int int31 = day19.getMonth();
//        int int32 = day19.getDayOfMonth();
//        java.lang.Class<?> wildcardClass33 = day19.getClass();
//        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass33);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560236399999L + "'", long25 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 10 + "'", int32 == 10);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(class34);
//    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test181");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getLastMillisecond(calendar2);
//        boolean boolean5 = fixedMillisecond0.equals((java.lang.Object) 1560182359456L);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond0.getLastMillisecond(calendar6);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182437630L + "'", long1 == 1560182437630L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560182437630L + "'", long3 == 1560182437630L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560182437630L + "'", long7 == 1560182437630L);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        long long2 = year1.getSerialIndex();
        int int3 = year1.getYear();
        long long4 = year1.getFirstMillisecond();
        int int5 = year1.getYear();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62167363200000L) + "'", long4 == (-62167363200000L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test183");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.List list5 = timeSeries3.getItems();
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj11 = null;
//        int int12 = month10.compareTo(obj11);
//        java.util.Date date13 = month10.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (double) 1560182343140L);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem15);
//        timeSeries3.add(timeSeriesDataItem15);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries19.addChangeListener(seriesChangeListener20);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        boolean boolean24 = timeSeries19.equals((java.lang.Object) timePeriodFormatException23);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day25, (java.lang.Number) (byte) 100);
//        boolean boolean29 = timeSeriesDataItem27.equals((java.lang.Object) (short) 10);
//        boolean boolean30 = timeSeriesDataItem27.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double35 = timeSeries34.getMaxY();
//        int int36 = timeSeries34.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries34.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (double) 6);
//        long long40 = fixedMillisecond37.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double45 = timeSeries44.getMaxY();
//        java.util.List list46 = timeSeries44.getItems();
//        timeSeries44.removeAgedItems((long) (byte) 100, false);
//        boolean boolean50 = fixedMillisecond37.equals((java.lang.Object) (byte) 100);
//        int int51 = timeSeriesDataItem27.compareTo((java.lang.Object) fixedMillisecond37);
//        int int52 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
//        timeSeries19.clear();
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = year56.next();
//        long long58 = year56.getLastMillisecond();
//        int int59 = year56.getYear();
//        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month(4, year56);
//        timeSeries19.setKey((java.lang.Comparable) month60);
//        boolean boolean62 = timeSeriesDataItem15.equals((java.lang.Object) timeSeries19);
//        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj66 = null;
//        int int67 = month65.compareTo(obj66);
//        java.util.Date date68 = month65.getEnd();
//        int int70 = month65.compareTo((java.lang.Object) 1560182345060L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = month65.next();
//        org.jfree.data.time.Year year72 = month65.getYear();
//        long long73 = year72.getFirstMillisecond();
//        java.lang.String str74 = year72.toString();
//        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) year72, (java.lang.Number) 1560182363374L, false);
//        java.util.Calendar calendar78 = null;
//        try {
//            year72.peg(calendar78);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list5);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560182437652L + "'", long40 == 1560182437652L);
//        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list46);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-62104204800001L) + "'", long58 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertNotNull(year72);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-59011603200000L) + "'", long73 == (-59011603200000L));
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "100" + "'", str74.equals("100"));
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 6);
        java.lang.String str9 = month6.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month6.previous();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "October 100" + "'", str9.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (byte) 100);
        boolean boolean4 = timeSeriesDataItem2.equals((java.lang.Object) (short) 10);
        boolean boolean5 = timeSeriesDataItem2.isSelected();
        java.lang.Object obj6 = timeSeriesDataItem2.clone();
        java.lang.Number number7 = null;
        timeSeriesDataItem2.setValue(number7);
        timeSeriesDataItem2.setSelected(true);
        java.lang.Object obj11 = timeSeriesDataItem2.clone();
        timeSeriesDataItem2.setSelected(true);
        timeSeriesDataItem2.setSelected(true);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeriesDataItem2.getPeriod();
        java.lang.Number number17 = timeSeriesDataItem2.getValue();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNull(number17);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test186");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        long long20 = day18.getFirstMillisecond();
//        int int21 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day18);
//        java.beans.PropertyChangeListener propertyChangeListener22 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener22);
//        timeSeries3.removeAgedItems(1560182358201L, false);
//        java.lang.String str27 = timeSeries3.getDescription();
//        timeSeries3.fireSeriesChanged();
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560150000000L + "'", long20 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNull(str27);
//    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test187");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
//        long long10 = day4.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day4.previous();
//        int int12 = day4.getYear();
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43626L + "'", long10 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test188");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getMaximumItemCount();
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries7.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries11.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
//        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) day14, (double) 6);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day14, 0.0d);
//        long long20 = day14.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, (java.lang.Number) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day14.next();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day14, (java.lang.Number) 1560182379475L, true);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560236399999L + "'", long20 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getItemCount();
        timeSeries3.setRangeDescription("October 100");
        timeSeries3.setNotify(true);
        java.lang.String str10 = timeSeries3.getDescription();
        java.util.Collection collection11 = timeSeries3.getTimePeriods();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(collection11);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(6);
        java.lang.String str2 = year1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "6" + "'", str2.equals("6"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        timeSeries1.setRangeDescription("hi!");
        timeSeries1.setNotify(false);
        boolean boolean13 = timeSeries1.isEmpty();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries1.getNextTimePeriod();
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test192");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        long long15 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double21 = timeSeries20.getMaxY();
//        int int22 = timeSeries20.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 6);
//        long long26 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond23.previous();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
//        timeSeries28.addChangeListener(seriesChangeListener29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day31, (java.lang.Number) (byte) 100);
//        boolean boolean35 = timeSeriesDataItem33.equals((java.lang.Object) (short) 10);
//        timeSeriesDataItem33.setSelected(false);
//        int int39 = timeSeriesDataItem33.compareTo((java.lang.Object) 1560182341157L);
//        java.lang.Number number40 = timeSeriesDataItem33.getValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries28.addOrUpdate(timeSeriesDataItem33);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar43 = null;
//        long long44 = fixedMillisecond42.getMiddleMillisecond(calendar43);
//        java.util.Date date45 = fixedMillisecond42.getTime();
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date45);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date45);
//        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date45);
//        int int49 = month48.getYearValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month48, (java.lang.Number) 10.0f);
//        timeSeries28.setKey((java.lang.Comparable) timeSeriesDataItem51);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = timeSeriesDataItem51.getPeriod();
//        java.lang.Object obj54 = timeSeriesDataItem51.clone();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = timeSeriesDataItem51.getPeriod();
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182437902L + "'", long11 == 1560182437902L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182437902L + "'", long15 == 1560182437902L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182437967L + "'", long26 == 1560182437967L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + number40 + "' != '" + (byte) 100 + "'", number40.equals((byte) 100));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560182437970L + "'", long44 == 1560182437970L);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2019 + "'", int49 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod53);
//        org.junit.Assert.assertNotNull(obj54);
//        org.junit.Assert.assertNotNull(regularTimePeriod55);
//    }
//}

