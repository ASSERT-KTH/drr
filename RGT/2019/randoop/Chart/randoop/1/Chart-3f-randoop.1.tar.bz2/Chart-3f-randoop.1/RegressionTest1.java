import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        timeSeries3.removeAgedItems((long) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 100);
        boolean boolean14 = timeSeriesDataItem12.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem12.setSelected(false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.addOrUpdate(timeSeriesDataItem12);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem17.getPeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        java.util.Date date5 = month2.getEnd();
        java.util.TimeZone timeZone6 = null;
        java.util.Locale locale7 = null;
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date5, timeZone6, locale7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 1, 3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Mon Jun 10 08:59:35 PDT 2019");
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond0.peg(calendar4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond0.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        java.util.Date date8 = regularTimePeriod7.getEnd();
//        java.util.TimeZone timeZone9 = null;
//        try {
//            org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8, timeZone9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182380803L + "'", long2 == 1560182380803L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(3, (int) (byte) 10, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date6);
//        java.util.TimeZone timeZone10 = null;
//        try {
//            org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date6, timeZone10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182380990L + "'", long2 == 1560182380990L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (byte) 100);
//        java.lang.Number number3 = timeSeriesDataItem2.getValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeriesDataItem2.getPeriod();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double9 = timeSeries8.getMaxY();
//        int int10 = timeSeries8.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 6);
//        long long14 = fixedMillisecond11.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double19 = timeSeries18.getMaxY();
//        java.util.List list20 = timeSeries18.getItems();
//        timeSeries18.removeAgedItems((long) (byte) 100, false);
//        boolean boolean24 = fixedMillisecond11.equals((java.lang.Object) (byte) 100);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        long long29 = timeSeries28.getMaximumItemAge();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (java.lang.Number) (byte) 100);
//        boolean boolean34 = timeSeriesDataItem32.equals((java.lang.Object) (short) 10);
//        boolean boolean35 = timeSeriesDataItem32.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries28.addOrUpdate(timeSeriesDataItem32);
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries38.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month43, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = month43.next();
//        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) month43);
//        boolean boolean48 = fixedMillisecond11.equals((java.lang.Object) month43);
//        java.util.Date date49 = fixedMillisecond11.getTime();
//        boolean boolean50 = timeSeriesDataItem2.equals((java.lang.Object) fixedMillisecond11);
//        java.util.Calendar calendar51 = null;
//        fixedMillisecond11.peg(calendar51);
//        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (byte) 100 + "'", number3.equals((byte) 100));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560182381039L + "'", long14 == 1560182381039L);
//        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list20);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 9223372036854775807L + "'", long29 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNull(timeSeriesDataItem45);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries9.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) 9223372036854775807L);
        org.jfree.data.time.SerialDate serialDate17 = day12.getSerialDate();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate17);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 1560182352596L, false);
        java.lang.Comparable comparable23 = timeSeries3.getKey();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + 10.0d + "'", comparable23.equals(10.0d));
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate9);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate9);
//        java.lang.String str13 = day12.toString();
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10-June-2019" + "'", str13.equals("10-June-2019"));
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.removeAgedItems((long) (byte) 100, false);
        java.lang.Comparable comparable9 = timeSeries3.getKey();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj13 = null;
        int int14 = month12.compareTo(obj13);
        java.util.Date date15 = month12.getEnd();
        java.util.Date date16 = month12.getStart();
        boolean boolean17 = timeSeries3.equals((java.lang.Object) date16);
        timeSeries3.removeAgedItems(1560182358086L, false);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 10.0d + "'", comparable9.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        timeSeries3.setMaximumItemAge((long) 12);
        boolean boolean9 = timeSeries3.isEmpty();
        boolean boolean10 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries3.addChangeListener(seriesChangeListener11);
        java.util.Collection collection13 = timeSeries3.getTimePeriods();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(collection13);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("10-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.removeAgedItems((long) (byte) 100, false);
        java.util.List list9 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double14 = timeSeries13.getMaxY();
        int int15 = timeSeries13.getItemCount();
        timeSeries13.setMaximumItemCount(1);
        boolean boolean18 = timeSeries3.equals((java.lang.Object) timeSeries13);
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        int int20 = timeSeries3.getItemCount();
        timeSeries3.setMaximumItemCount((int) (short) 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        long long7 = timeSeries3.getMaximumItemAge();
        java.util.List list8 = timeSeries3.getItems();
        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize(class12);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(class13);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
//        java.util.Date date4 = fixedMillisecond1.getEnd();
//        boolean boolean5 = day0.equals((java.lang.Object) fixedMillisecond1);
//        java.lang.String str6 = day0.toString();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560182381342L + "'", long3 == 1560182381342L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str9 = timeSeries8.getDescription();
        java.lang.String str10 = timeSeries8.getDomainDescription();
        java.util.Collection collection11 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        timeSeries3.removeAgedItems((long) (-9999), true);
        java.lang.Class class15 = timeSeries3.getTimePeriodClass();
        try {
            timeSeries3.delete((int) (byte) -1, 1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNull(class15);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
//        java.lang.String str9 = year7.toString();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182381620L + "'", long2 == 1560182381620L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
//    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        long long6 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        java.lang.String str8 = fixedMillisecond0.toString();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj12 = null;
//        int int13 = month11.compareTo(obj12);
//        org.jfree.data.time.Year year14 = month11.getYear();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        int int19 = year14.compareTo((java.lang.Object) timeSeries16);
//        boolean boolean20 = fixedMillisecond0.equals((java.lang.Object) timeSeries16);
//        java.lang.String str21 = timeSeries16.getDomainDescription();
//        long long22 = timeSeries16.getMaximumItemAge();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182381658L + "'", long2 == 1560182381658L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182381658L + "'", long6 == 1560182381658L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Mon Jun 10 08:59:41 PDT 2019" + "'", str8.equals("Mon Jun 10 08:59:41 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Time" + "'", str21.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9223372036854775807L + "'", long22 == 9223372036854775807L);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        java.lang.Object obj5 = timeSeries3.clone();
        try {
            java.lang.Number number7 = timeSeries3.getValue((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj5);
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
//        java.lang.String str10 = day4.toString();
//        int int11 = day4.getDayOfMonth();
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getLastMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        int int3 = month2.getMonth();
        int int4 = month2.getMonth();
        org.jfree.data.time.Year year5 = month2.getYear();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(year5);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
//        java.lang.String str10 = day4.toString();
//        java.lang.String str11 = day4.toString();
//        java.lang.String str12 = day4.toString();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj16 = null;
//        int int17 = month15.compareTo(obj16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month15.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month15.next();
//        boolean boolean20 = day4.equals((java.lang.Object) regularTimePeriod19);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries13.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.Year year23 = month18.getYear();
        long long24 = month18.getSerialIndex();
        java.lang.String str25 = month18.toString();
        java.util.Calendar calendar26 = null;
        try {
            long long27 = month18.getLastMillisecond(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1210L + "'", long24 == 1210L);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "October 100" + "'", str25.equals("October 100"));
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        long long9 = month8.getFirstMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month8);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month21.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries14.addOrUpdate(regularTimePeriod24, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries14.addChangeListener(seriesChangeListener27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.previous();
//        long long31 = day29.getFirstMillisecond();
//        int int32 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) day29);
//        long long33 = day29.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day29.previous();
//        timeSeries3.add(regularTimePeriod34, (double) 1560182341608L, false);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod34, "Mon Jun 10 08:59:09 PDT 2019", "org.jfree.data.time.TimePeriodFormatException: hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond41.getMiddleMillisecond(calendar42);
//        java.util.Date date44 = fixedMillisecond41.getTime();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond(date44);
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date44);
//        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) year47, (java.lang.Number) 1560182374632L);
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double54 = timeSeries53.getMaxY();
//        java.util.List list55 = timeSeries53.getItems();
//        timeSeries53.setNotify(false);
//        java.lang.String str58 = timeSeries53.getDomainDescription();
//        boolean boolean59 = year47.equals((java.lang.Object) str58);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-58987929600000L) + "'", long9 == (-58987929600000L));
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560150000000L + "'", long31 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560150000000L + "'", long33 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560182381806L + "'", long43 == 1560182381806L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertEquals((double) double54, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list55);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 100, seriesChangeInfo1);
        java.lang.Object obj3 = seriesChangeEvent2.getSource();
        java.lang.String str4 = seriesChangeEvent2.toString();
        java.lang.Object obj5 = seriesChangeEvent2.getSource();
        java.lang.Object obj6 = seriesChangeEvent2.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo7);
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (short) 100 + "'", obj3.equals((short) 100));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str4.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + (short) 100 + "'", obj5.equals((short) 100));
        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + (short) 100 + "'", obj6.equals((short) 100));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        org.jfree.data.time.Year year5 = month2.getYear();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries7.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        int int10 = year5.compareTo((java.lang.Object) timeSeries7);
        java.util.Date date11 = year5.getEnd();
        int int12 = year5.getYear();
        long long13 = year5.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-58979980800001L) + "'", long13 == (-58979980800001L));
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
//        long long2 = year1.getSerialIndex();
//        long long3 = year1.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        long long5 = fixedMillisecond4.getMiddleMillisecond();
//        int int6 = year1.compareTo((java.lang.Object) fixedMillisecond4);
//        int int7 = year1.getYear();
//        java.lang.String str8 = year1.toString();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560182382002L + "'", long5 == 1560182382002L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
//    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
//        java.util.TimeZone timeZone9 = null;
//        try {
//            org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date6, timeZone9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182382125L + "'", long2 == 1560182382125L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj4 = null;
        int int5 = month3.compareTo(obj4);
        java.util.Date date6 = month3.getEnd();
        int int8 = month3.compareTo((java.lang.Object) 1560182345060L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month3.next();
        org.jfree.data.time.Year year10 = month3.getYear();
        long long11 = year10.getFirstMillisecond();
        java.lang.String str12 = year10.toString();
        try {
            org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(35, year10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-59011603200000L) + "'", long11 == (-59011603200000L));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100" + "'", str12.equals("100"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        java.util.TimeZone timeZone2 = null;
        java.util.Locale locale3 = null;
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date1, timeZone2, locale3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj4 = null;
        int int5 = month3.compareTo(obj4);
        org.jfree.data.time.Year year6 = month3.getYear();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(1, year6);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month7.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(year6);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
        java.lang.String str9 = timeSeries3.getDescription();
        timeSeries3.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.Object obj6 = timeSeries3.clone();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) (byte) 100);
        boolean boolean11 = timeSeriesDataItem9.equals((java.lang.Object) (short) 10);
        boolean boolean12 = timeSeriesDataItem9.isSelected();
        java.lang.Object obj13 = timeSeriesDataItem9.clone();
        java.lang.Number number14 = null;
        timeSeriesDataItem9.setValue(number14);
        timeSeriesDataItem9.setSelected(true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate(timeSeriesDataItem9);
        long long19 = timeSeries3.getMaximumItemAge();
        timeSeries3.setKey((java.lang.Comparable) 1560182380104L);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
//        long long14 = day8.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, (java.lang.Number) (short) 10);
//        int int17 = day8.getYear();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo19 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 100, seriesChangeInfo19);
//        java.lang.String str21 = seriesChangeEvent20.toString();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo22 = null;
//        seriesChangeEvent20.setSummary(seriesChangeInfo22);
//        java.lang.Object obj24 = seriesChangeEvent20.getSource();
//        boolean boolean25 = day8.equals((java.lang.Object) seriesChangeEvent20);
//        java.lang.Object obj26 = seriesChangeEvent20.getSource();
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str21.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
//        org.junit.Assert.assertTrue("'" + obj24 + "' != '" + (short) 100 + "'", obj24.equals((short) 100));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + obj26 + "' != '" + (short) 100 + "'", obj26.equals((short) 100));
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        timeSeries3.removeAgedItems((long) 10, false);
        boolean boolean8 = timeSeries3.isEmpty();
        int int9 = timeSeries3.getItemCount();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.previous();
        int int10 = month6.getYearValue();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        int int3 = month2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        long long5 = month2.getFirstMillisecond();
        java.util.Date date6 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date6, "Mon Jun 10 08:59:23 PDT 2019", "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.event.SeriesChangeEvent[source=100]");
        try {
            org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-58987929600000L) + "'", long5 == (-58987929600000L));
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        long long9 = fixedMillisecond6.getFirstMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond6.getMiddleMillisecond(calendar10);
//        java.util.Calendar calendar12 = null;
//        fixedMillisecond6.peg(calendar12);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182382942L + "'", long9 == 1560182382942L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182382942L + "'", long11 == 1560182382942L);
//    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        java.util.List list8 = timeSeries3.getItems();
//        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double17 = timeSeries16.getMaxY();
//        java.util.Collection collection18 = timeSeries16.getTimePeriods();
//        java.lang.String str19 = timeSeries16.getRangeDescription();
//        long long20 = timeSeries16.getMaximumItemAge();
//        java.util.List list21 = timeSeries16.getItems();
//        java.lang.Class<?> wildcardClass22 = timeSeries16.getClass();
//        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass22);
//        java.lang.Class class24 = org.jfree.data.time.RegularTimePeriod.downsize(class23);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond26.getMiddleMillisecond(calendar27);
//        java.util.Date date29 = fixedMillisecond26.getTime();
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date29);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(date29);
//        java.util.TimeZone timeZone32 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date29, timeZone32);
//        java.util.TimeZone timeZone34 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date29, timeZone34);
//        java.util.TimeZone timeZone36 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date29, timeZone36);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "hi!" + "'", str19.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(list21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(class23);
//        org.junit.Assert.assertNotNull(class24);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560182382961L + "'", long28 == 1560182382961L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNull(regularTimePeriod35);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        long long3 = year1.getLastMillisecond();
        int int4 = year1.getYear();
        java.lang.String str5 = year1.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 1560182348076L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62104204800001L) + "'", long3 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0" + "'", str5.equals("0"));
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        long long15 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double21 = timeSeries20.getMaxY();
//        int int22 = timeSeries20.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 6);
//        long long26 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond23.previous();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond29.getMiddleMillisecond(calendar30);
//        java.util.Date date32 = fixedMillisecond29.getTime();
//        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date32);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date32);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month(date32);
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date32);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year36.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year36.previous();
//        long long39 = year36.getSerialIndex();
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) year36, (java.lang.Number) 11, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182383127L + "'", long11 == 1560182383127L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182383127L + "'", long15 == 1560182383127L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182383129L + "'", long26 == 1560182383129L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560182383130L + "'", long31 == 1560182383130L);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 2019L + "'", long39 == 2019L);
//    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener18);
//        timeSeries3.setDescription("Mon Jun 10 08:59:05 PDT 2019");
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries23.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day26, (java.lang.Number) (byte) 100);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) day26, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate31 = day26.getSerialDate();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(serialDate31);
//        java.lang.String str33 = day32.toString();
//        java.lang.Number number34 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day32);
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double39 = timeSeries38.getMaxY();
//        java.util.Collection collection40 = timeSeries38.getTimePeriods();
//        java.lang.String str41 = timeSeries38.getRangeDescription();
//        long long42 = timeSeries38.getMaximumItemAge();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener43 = null;
//        timeSeries38.addChangeListener(seriesChangeListener43);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener45 = null;
//        timeSeries38.removeChangeListener(seriesChangeListener45);
//        int int47 = timeSeries38.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar49 = null;
//        long long50 = fixedMillisecond48.getMiddleMillisecond(calendar49);
//        java.util.Date date51 = fixedMillisecond48.getTime();
//        java.util.Calendar calendar52 = null;
//        fixedMillisecond48.peg(calendar52);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = fixedMillisecond48.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (double) 1.0f);
//        boolean boolean57 = day32.equals((java.lang.Object) timeSeriesDataItem56);
//        java.util.Calendar calendar58 = null;
//        try {
//            long long59 = day32.getFirstMillisecond(calendar58);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "10-June-2019" + "'", str33.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 10.0d + "'", number34.equals(10.0d));
//        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection40);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 9223372036854775807L + "'", long42 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560182383172L + "'", long50 == 1560182383172L);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//        org.junit.Assert.assertNull(timeSeriesDataItem56);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getStart();
        java.util.TimeZone timeZone2 = null;
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        java.lang.String str9 = timeSeries3.getDescription();
//        double double10 = timeSeries3.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries12.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) day19, (double) 6);
//        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) day19, 0.0d);
//        long long25 = day19.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day19.previous();
//        long long29 = day19.getLastMillisecond();
//        boolean boolean30 = timeSeries3.equals((java.lang.Object) day19);
//        java.util.List list31 = timeSeries3.getItems();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 6.0d + "'", double10 == 6.0d);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560236399999L + "'", long25 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560236399999L + "'", long29 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(list31);
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
//        java.lang.String str4 = timeSeries3.getDescription();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries9.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day12, (double) 6);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
//        int int18 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day16);
//        long long19 = day16.getSerialIndex();
//        int int20 = day16.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) day16);
//        java.lang.String str22 = day16.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day16.previous();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43626L + "'", long19 == 43626L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10-June-2019" + "'", str22.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.List list5 = timeSeries3.getItems();
//        timeSeries3.removeAgedItems((long) (byte) 100, false);
//        java.lang.Comparable comparable9 = timeSeries3.getKey();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 100);
//        boolean boolean14 = timeSeriesDataItem12.equals((java.lang.Object) (short) 10);
//        boolean boolean15 = timeSeriesDataItem12.isSelected();
//        timeSeriesDataItem12.setValue((java.lang.Number) (byte) 100);
//        timeSeries3.add(timeSeriesDataItem12, false);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries21.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (java.lang.Number) (byte) 100);
//        timeSeries21.add((org.jfree.data.time.RegularTimePeriod) day24, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar30 = null;
//        long long31 = fixedMillisecond29.getMiddleMillisecond(calendar30);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int34 = fixedMillisecond29.compareTo((java.lang.Object) "hi!");
//        long long35 = fixedMillisecond29.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond29.next();
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double41 = timeSeries40.getMaxY();
//        int int42 = timeSeries40.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43, (double) 6);
//        long long46 = fixedMillisecond43.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = fixedMillisecond43.previous();
//        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
//        int int49 = timeSeries48.getItemCount();
//        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries3.addAndOrUpdate(timeSeries48);
//        timeSeries50.removeAgedItems(false);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list5);
//        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 10.0d + "'", comparable9.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560182383448L + "'", long31 == 1560182383448L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560182383448L + "'", long35 == 1560182383448L);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertEquals((double) double41, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560182384028L + "'", long46 == 1560182384028L);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNotNull(timeSeries48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
//        org.junit.Assert.assertNotNull(timeSeries50);
//    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (byte) 100);
//        long long3 = day0.getSerialIndex();
//        int int4 = day0.getMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day0.getSerialDate();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) ' ', (int) ' ', 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Mon Jun 10 08:59:36 PDT 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        long long3 = month2.getFirstMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            month2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-58987929600000L) + "'", long3 == (-58987929600000L));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, (java.lang.Number) (byte) 100);
        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem8.setSelected(false);
        int int14 = timeSeriesDataItem8.compareTo((java.lang.Object) 1560182341157L);
        timeSeriesDataItem8.setSelected(true);
        timeSeries3.add(timeSeriesDataItem8);
        java.lang.String str18 = timeSeries3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        long long6 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        java.lang.String str8 = fixedMillisecond0.toString();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj12 = null;
//        int int13 = month11.compareTo(obj12);
//        org.jfree.data.time.Year year14 = month11.getYear();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        int int19 = year14.compareTo((java.lang.Object) timeSeries16);
//        boolean boolean20 = fixedMillisecond0.equals((java.lang.Object) timeSeries16);
//        timeSeries16.removeAgedItems(1560182371699L, false);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182384631L + "'", long2 == 1560182384631L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182384631L + "'", long6 == 1560182384631L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Mon Jun 10 08:59:44 PDT 2019" + "'", str8.equals("Mon Jun 10 08:59:44 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.setNotify(false);
        boolean boolean8 = timeSeries3.getNotify();
        long long9 = timeSeries3.getMaximumItemAge();
        long long10 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries3.createCopy((int) (byte) 10, 9999);
        timeSeries13.removeAgedItems(true);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(timeSeries13);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
//        int int6 = day4.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182384682L + "'", long2 == 1560182384682L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
//    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
//        long long14 = day8.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day8.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day8.next();
//        int int17 = day8.getDayOfMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        long long2 = year1.getSerialIndex();
        int int3 = year1.getYear();
        java.lang.String str4 = year1.toString();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
//        java.lang.String str10 = day4.toString();
//        java.lang.String str11 = day4.toString();
//        java.lang.String str12 = day4.toString();
//        boolean boolean14 = day4.equals((java.lang.Object) 9999);
//        java.util.Calendar calendar15 = null;
//        try {
//            day4.peg(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date6);
//        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182384803L + "'", long2 == 1560182384803L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        long long3 = year1.getLastMillisecond();
        int int4 = year1.getYear();
        java.lang.String str5 = year1.toString();
        int int6 = year1.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62104204800001L) + "'", long3 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0" + "'", str5.equals("0"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.setNotify(false);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj11 = null;
        int int12 = month10.compareTo(obj11);
        java.util.Date date13 = month10.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (double) 1560182343140L);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem15);
        timeSeries3.add(timeSeriesDataItem15);
        java.lang.Object obj18 = timeSeriesDataItem15.clone();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(obj18);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182385019L + "'", long1 == 1560182385019L);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        long long9 = month8.getFirstMillisecond();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month8);
        java.util.Calendar calendar11 = null;
        try {
            month8.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-58987929600000L) + "'", long9 == (-58987929600000L));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 100, seriesChangeInfo1);
        java.lang.Object obj3 = seriesChangeEvent2.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = seriesChangeEvent2.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = seriesChangeEvent2.getSummary();
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (short) 100 + "'", obj3.equals((short) 100));
        org.junit.Assert.assertNull(seriesChangeInfo4);
        org.junit.Assert.assertNull(seriesChangeInfo5);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        long long15 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double21 = timeSeries20.getMaxY();
//        int int22 = timeSeries20.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 6);
//        long long26 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond23.previous();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        timeSeries28.setMaximumItemCount(3);
//        java.beans.PropertyChangeListener propertyChangeListener31 = null;
//        timeSeries28.removePropertyChangeListener(propertyChangeListener31);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries34.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries38.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day41.previous();
//        timeSeries38.add((org.jfree.data.time.RegularTimePeriod) day41, (double) 6);
//        timeSeries34.add((org.jfree.data.time.RegularTimePeriod) day41, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day41, "Mon Jun 10 08:59:05 PDT 2019", "10-June-2019");
//        java.util.Collection collection50 = timeSeries28.getTimePeriodsUniqueToOtherSeries(timeSeries49);
//        timeSeries49.setMaximumItemCount(6);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182385066L + "'", long11 == 1560182385066L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182385066L + "'", long15 == 1560182385066L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182385067L + "'", long26 == 1560182385067L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(collection50);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.removeAgedItems((long) (byte) 100, false);
        java.lang.Comparable comparable9 = timeSeries3.getKey();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj13 = null;
        int int14 = month12.compareTo(obj13);
        java.util.Date date15 = month12.getEnd();
        java.util.Date date16 = month12.getStart();
        boolean boolean17 = timeSeries3.equals((java.lang.Object) date16);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 10.0d + "'", comparable9.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2, (int) (short) 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.addChangeListener(seriesChangeListener8);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener10);
//        int int12 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
//        java.util.Date date16 = fixedMillisecond13.getTime();
//        java.util.Calendar calendar17 = null;
//        fixedMillisecond13.peg(calendar17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond13.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) 1.0f);
//        long long22 = timeSeries3.getMaximumItemAge();
//        timeSeries3.setDomainDescription("Mon Jun 10 08:59:25 PDT 2019");
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182385250L + "'", long15 == 1560182385250L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9223372036854775807L + "'", long22 == 9223372036854775807L);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        long long7 = timeSeries3.getMaximumItemAge();
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(0);
        long long12 = year11.getSerialIndex();
        long long13 = year11.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries19.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month24, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month24.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries17.addOrUpdate(regularTimePeriod27, (double) (short) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener30 = null;
        timeSeries17.addChangeListener(seriesChangeListener30);
        java.util.Collection collection32 = timeSeries17.getTimePeriods();
        timeSeries17.setRangeDescription("");
        int int35 = year11.compareTo((java.lang.Object) timeSeries17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year11.previous();
        timeSeries3.add(regularTimePeriod36, (java.lang.Number) 1560182361360L);
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries40.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day43, (java.lang.Number) (byte) 100);
        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) day43, (java.lang.Number) 9223372036854775807L);
        int int48 = day43.getYear();
        int int49 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day43);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener50 = null;
        timeSeries3.removeChangeListener(seriesChangeListener50);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) -1);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day8);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double15 = timeSeries14.getMaxY();
//        java.util.List list16 = timeSeries14.getItems();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (byte) 100);
//        boolean boolean21 = timeSeriesDataItem19.equals((java.lang.Object) (short) 10);
//        timeSeries14.add(timeSeriesDataItem19);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timeSeries14.addPropertyChangeListener(propertyChangeListener23);
//        timeSeries14.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int32 = fixedMillisecond27.compareTo((java.lang.Object) "hi!");
//        java.util.Date date33 = fixedMillisecond27.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond27.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond27.next();
//        java.lang.String str36 = fixedMillisecond27.toString();
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) 1560182375196L);
//        boolean boolean39 = day8.equals((java.lang.Object) fixedMillisecond27);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list16);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182385644L + "'", long29 == 1560182385644L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Mon Jun 10 08:59:45 PDT 2019" + "'", str36.equals("Mon Jun 10 08:59:45 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        timeSeries1.fireSeriesChanged();
//        timeSeries1.setDescription("Mon Jun 10 08:59:09 PDT 2019");
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener12);
//        double double14 = timeSeries1.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double19 = timeSeries18.getMaxY();
//        java.util.List list20 = timeSeries18.getItems();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) (byte) 100);
//        boolean boolean25 = timeSeriesDataItem23.equals((java.lang.Object) (short) 10);
//        timeSeries18.add(timeSeriesDataItem23);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.next();
//        long long30 = year28.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries32.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) (byte) 100);
//        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar41 = null;
//        long long42 = fixedMillisecond40.getMiddleMillisecond(calendar41);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException44 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int45 = fixedMillisecond40.compareTo((java.lang.Object) "hi!");
//        long long46 = fixedMillisecond40.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = fixedMillisecond40.next();
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double52 = timeSeries51.getMaxY();
//        int int53 = timeSeries51.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries51.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (double) 6);
//        long long57 = fixedMillisecond54.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = fixedMillisecond54.previous();
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond54);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener60 = null;
//        timeSeries59.addChangeListener(seriesChangeListener60);
//        int int62 = timeSeries59.getMaximumItemCount();
//        int int63 = year28.compareTo((java.lang.Object) timeSeries59);
//        java.lang.Object obj64 = timeSeries59.clone();
//        boolean boolean65 = timeSeriesDataItem23.equals((java.lang.Object) timeSeries59);
//        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries1.addAndOrUpdate(timeSeries59);
//        java.lang.Comparable comparable67 = timeSeries1.getKey();
//        java.lang.String str68 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = timeSeries1.getNextTimePeriod();
//        int int70 = timeSeries1.getItemCount();
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 9.223372036854776E18d + "'", double14 == 9.223372036854776E18d);
//        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list20);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-62104204800001L) + "'", long30 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560182385765L + "'", long42 == 1560182385765L);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560182385765L + "'", long46 == 1560182385765L);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560182385773L + "'", long57 == 1560182385773L);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2147483647 + "'", int62 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(obj64);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(timeSeries66);
//        org.junit.Assert.assertTrue("'" + comparable67 + "' != '" + 9 + "'", comparable67.equals(9));
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Time" + "'", str68.equals("Time"));
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.Object obj6 = timeSeries3.clone();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) (byte) 100);
        boolean boolean11 = timeSeriesDataItem9.equals((java.lang.Object) (short) 10);
        boolean boolean12 = timeSeriesDataItem9.isSelected();
        java.lang.Object obj13 = timeSeriesDataItem9.clone();
        java.lang.Number number14 = null;
        timeSeriesDataItem9.setValue(number14);
        timeSeriesDataItem9.setSelected(true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate(timeSeriesDataItem9);
        boolean boolean19 = timeSeriesDataItem9.isSelected();
        timeSeriesDataItem9.setValue((java.lang.Number) 1560182368684L);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day8);
        java.util.Collection collection11 = timeSeries1.getTimePeriods();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries1.addChangeListener(seriesChangeListener12);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(collection11);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
//        long long14 = day8.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, (java.lang.Number) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day8.previous();
//        long long18 = day8.getLastMillisecond();
//        int int19 = day8.getYear();
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: Mon Jun 10 08:59:13 PDT 2019");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("September 6");
        long long2 = month1.getLastMillisecond();
        java.lang.String str3 = month1.toString();
        long long4 = month1.getFirstMillisecond();
        org.junit.Assert.assertNotNull(month1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61954387200001L) + "'", long2 == (-61954387200001L));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "September 6" + "'", str3.equals("September 6"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-61956979200000L) + "'", long4 == (-61956979200000L));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1560182345230L);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = seriesChangeEvent1.getSummary();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 1560182345230L + "'", obj2.equals(1560182345230L));
        org.junit.Assert.assertNull(seriesChangeInfo3);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        long long6 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        java.lang.String str8 = fixedMillisecond0.toString();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj12 = null;
//        int int13 = month11.compareTo(obj12);
//        org.jfree.data.time.Year year14 = month11.getYear();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        int int19 = year14.compareTo((java.lang.Object) timeSeries16);
//        boolean boolean20 = fixedMillisecond0.equals((java.lang.Object) timeSeries16);
//        java.lang.String str21 = timeSeries16.getDomainDescription();
//        timeSeries16.setMaximumItemAge(1560182348451L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182386556L + "'", long2 == 1560182386556L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182386556L + "'", long6 == 1560182386556L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Mon Jun 10 08:59:46 PDT 2019" + "'", str8.equals("Mon Jun 10 08:59:46 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Time" + "'", str21.equals("Time"));
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str9 = timeSeries8.getDescription();
        java.lang.String str10 = timeSeries8.getDomainDescription();
        java.util.Collection collection11 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        timeSeries8.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timeSeries8.setNotify(true);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(collection11);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        long long9 = fixedMillisecond6.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double14 = timeSeries13.getMaxY();
//        java.util.List list15 = timeSeries13.getItems();
//        timeSeries13.removeAgedItems((long) (byte) 100, false);
//        boolean boolean19 = fixedMillisecond6.equals((java.lang.Object) (byte) 100);
//        long long20 = fixedMillisecond6.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond6.previous();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182387126L + "'", long9 == 1560182387126L);
//        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list15);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560182387126L + "'", long20 == 1560182387126L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        long long15 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double21 = timeSeries20.getMaxY();
//        int int22 = timeSeries20.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 6);
//        long long26 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond23.previous();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
//        timeSeries28.addChangeListener(seriesChangeListener29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day31, (java.lang.Number) (byte) 100);
//        boolean boolean35 = timeSeriesDataItem33.equals((java.lang.Object) (short) 10);
//        timeSeriesDataItem33.setSelected(false);
//        int int39 = timeSeriesDataItem33.compareTo((java.lang.Object) 1560182341157L);
//        java.lang.Number number40 = timeSeriesDataItem33.getValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries28.addOrUpdate(timeSeriesDataItem33);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar43 = null;
//        long long44 = fixedMillisecond42.getMiddleMillisecond(calendar43);
//        java.util.Date date45 = fixedMillisecond42.getTime();
//        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date45);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date45);
//        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date45);
//        int int49 = month48.getYearValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month48, (java.lang.Number) 10.0f);
//        timeSeries28.setKey((java.lang.Comparable) timeSeriesDataItem51);
//        int int53 = timeSeries28.getMaximumItemCount();
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182387159L + "'", long11 == 1560182387159L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182387159L + "'", long15 == 1560182387159L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182387160L + "'", long26 == 1560182387160L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + number40 + "' != '" + (byte) 100 + "'", number40.equals((byte) 100));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560182387171L + "'", long44 == 1560182387171L);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2019 + "'", int49 == 2019);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 2147483647 + "'", int53 == 2147483647);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        java.lang.String str5 = timeSeries3.getDomainDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        timeSeries3.setRangeDescription("Mon Jun 10 08:59:05 PDT 2019");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries3.removeChangeListener(seriesChangeListener10);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Mon Jun 10 08:59:41 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        org.jfree.data.time.Year year5 = month2.getYear();
        java.lang.String str6 = year5.toString();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year5.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
//        long long14 = day8.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, (java.lang.Number) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day8.previous();
//        long long18 = day8.getLastMillisecond();
//        int int19 = day8.getMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.next();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182387603L + "'", long2 == 1560182387603L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date3);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182387633L + "'", long2 == 1560182387633L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
        long long2 = year1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62135740800000L) + "'", long2 == (-62135740800000L));
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        long long6 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double12 = timeSeries11.getMaxY();
//        java.util.Collection collection13 = timeSeries11.getTimePeriods();
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        long long17 = month16.getFirstMillisecond();
//        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) month16);
//        int int19 = fixedMillisecond0.compareTo((java.lang.Object) month16);
//        java.util.Calendar calendar20 = null;
//        try {
//            long long21 = month16.getLastMillisecond(calendar20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182387678L + "'", long2 == 1560182387678L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182387678L + "'", long6 == 1560182387678L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-58987929600000L) + "'", long17 == (-58987929600000L));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (byte) 100);
//        boolean boolean4 = timeSeriesDataItem2.equals((java.lang.Object) (short) 10);
//        boolean boolean5 = timeSeriesDataItem2.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double10 = timeSeries9.getMaxY();
//        int int11 = timeSeries9.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 6);
//        long long15 = fixedMillisecond12.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double20 = timeSeries19.getMaxY();
//        java.util.List list21 = timeSeries19.getItems();
//        timeSeries19.removeAgedItems((long) (byte) 100, false);
//        boolean boolean25 = fixedMillisecond12.equals((java.lang.Object) (byte) 100);
//        int int26 = timeSeriesDataItem2.compareTo((java.lang.Object) fixedMillisecond12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond12.previous();
//        java.util.Calendar calendar28 = null;
//        fixedMillisecond12.peg(calendar28);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) '#');
//        java.lang.Number number32 = timeSeriesDataItem31.getValue();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182387701L + "'", long15 == 1560182387701L);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list21);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 35.0d + "'", number32.equals(35.0d));
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, (int) (short) 100);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        java.util.Date date5 = month2.getEnd();
        int int6 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
//        long long14 = day8.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day8.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day8.next();
//        java.lang.String str17 = regularTimePeriod16.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "11-June-2019" + "'", str17.equals("11-June-2019"));
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560182345395L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560182345395L + "'", long3 == 1560182345395L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (byte) 100);
        java.lang.Number number3 = timeSeriesDataItem2.getValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeriesDataItem2.getPeriod();
        timeSeriesDataItem2.setSelected(false);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (byte) 100 + "'", number3.equals((byte) 100));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        long long9 = month8.getFirstMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month8);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month21.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries14.addOrUpdate(regularTimePeriod24, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries14.addChangeListener(seriesChangeListener27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.previous();
//        long long31 = day29.getFirstMillisecond();
//        int int32 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) day29);
//        long long33 = day29.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day29.previous();
//        timeSeries3.add(regularTimePeriod34, (double) 1560182341608L, false);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod34, "Mon Jun 10 08:59:09 PDT 2019", "org.jfree.data.time.TimePeriodFormatException: hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond41.getMiddleMillisecond(calendar42);
//        java.util.Date date44 = fixedMillisecond41.getTime();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond(date44);
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date44);
//        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) year47, (java.lang.Number) 1560182374632L);
//        double double50 = timeSeries40.getMaxY();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = null;
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries40.addOrUpdate(regularTimePeriod51, 10.0d);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-58987929600000L) + "'", long9 == (-58987929600000L));
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560150000000L + "'", long31 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560150000000L + "'", long33 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560182388174L + "'", long43 == 1560182388174L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.560182374632E12d + "'", double50 == 1.560182374632E12d);
//    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        timeSeries3.removeAgedItems((long) 10, false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener8);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        int int13 = month12.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.next();
//        timeSeries3.add(regularTimePeriod14, (double) 1560182345775L, false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        long long19 = fixedMillisecond18.getLastMillisecond();
//        java.util.Calendar calendar20 = null;
//        fixedMillisecond18.peg(calendar20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int27 = fixedMillisecond22.compareTo((java.lang.Object) "hi!");
//        java.util.Date date28 = fixedMillisecond22.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        timeSeries3.setMaximumItemAge(1560182345395L);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double37 = timeSeries36.getMaxY();
//        int int38 = timeSeries36.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries36.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (double) 6);
//        long long42 = fixedMillisecond39.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = fixedMillisecond39.previous();
//        java.lang.Object obj44 = null;
//        boolean boolean45 = fixedMillisecond39.equals(obj44);
//        try {
//            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 1560182350845L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560182388258L + "'", long19 == 1560182388258L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560182388259L + "'", long24 == 1560182388259L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560182388260L + "'", long42 == 1560182388260L);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        java.util.Date date5 = month2.getEnd();
        int int7 = month2.compareTo((java.lang.Object) 1560182345060L);
        long long8 = month2.getSerialIndex();
        int int9 = month2.getYearValue();
        java.util.Calendar calendar10 = null;
        try {
            month2.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1210L + "'", long8 == 1210L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        timeSeries3.setMaximumItemAge((long) 12);
        try {
            java.lang.Number number10 = timeSeries3.getValue(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
//        timeSeries1.addChangeListener(seriesChangeListener2);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        boolean boolean6 = timeSeries1.equals((java.lang.Object) timePeriodFormatException5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) (byte) 100);
//        boolean boolean11 = timeSeriesDataItem9.equals((java.lang.Object) (short) 10);
//        boolean boolean12 = timeSeriesDataItem9.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double17 = timeSeries16.getMaxY();
//        int int18 = timeSeries16.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 6);
//        long long22 = fixedMillisecond19.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double27 = timeSeries26.getMaxY();
//        java.util.List list28 = timeSeries26.getItems();
//        timeSeries26.removeAgedItems((long) (byte) 100, false);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) (byte) 100);
//        int int33 = timeSeriesDataItem9.compareTo((java.lang.Object) fixedMillisecond19);
//        int int34 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        timeSeries1.clear();
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.next();
//        long long40 = year38.getLastMillisecond();
//        int int41 = year38.getYear();
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(4, year38);
//        timeSeries1.setKey((java.lang.Comparable) month42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day44, (java.lang.Number) (byte) 100);
//        boolean boolean48 = timeSeriesDataItem46.equals((java.lang.Object) (short) 10);
//        boolean boolean49 = timeSeriesDataItem46.isSelected();
//        java.lang.Object obj50 = timeSeriesDataItem46.clone();
//        timeSeries1.add(timeSeriesDataItem46, false);
//        java.beans.PropertyChangeListener propertyChangeListener53 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener53);
//        long long55 = timeSeries1.getMaximumItemAge();
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560182388569L + "'", long22 == 1560182388569L);
//        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list28);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-62104204800001L) + "'", long40 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(obj50);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 9223372036854775807L + "'", long55 == 9223372036854775807L);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        timeSeries3.setMaximumItemAge((long) 12);
        boolean boolean9 = timeSeries3.isEmpty();
        timeSeries3.setMaximumItemAge(10L);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        timeSeries1.fireSeriesChanged();
//        timeSeries1.setDescription("Mon Jun 10 08:59:09 PDT 2019");
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener12);
//        double double14 = timeSeries1.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double19 = timeSeries18.getMaxY();
//        java.util.List list20 = timeSeries18.getItems();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) (byte) 100);
//        boolean boolean25 = timeSeriesDataItem23.equals((java.lang.Object) (short) 10);
//        timeSeries18.add(timeSeriesDataItem23);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.next();
//        long long30 = year28.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries32.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) (byte) 100);
//        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar41 = null;
//        long long42 = fixedMillisecond40.getMiddleMillisecond(calendar41);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException44 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int45 = fixedMillisecond40.compareTo((java.lang.Object) "hi!");
//        long long46 = fixedMillisecond40.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = fixedMillisecond40.next();
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double52 = timeSeries51.getMaxY();
//        int int53 = timeSeries51.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries51.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (double) 6);
//        long long57 = fixedMillisecond54.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = fixedMillisecond54.previous();
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond54);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener60 = null;
//        timeSeries59.addChangeListener(seriesChangeListener60);
//        int int62 = timeSeries59.getMaximumItemCount();
//        int int63 = year28.compareTo((java.lang.Object) timeSeries59);
//        java.lang.Object obj64 = timeSeries59.clone();
//        boolean boolean65 = timeSeriesDataItem23.equals((java.lang.Object) timeSeries59);
//        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries1.addAndOrUpdate(timeSeries59);
//        timeSeries66.removeAgedItems(false);
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
//        java.lang.String str70 = day69.toString();
//        try {
//            timeSeries66.add((org.jfree.data.time.RegularTimePeriod) day69, (java.lang.Number) 1560182346671L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 10-June-2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 9.223372036854776E18d + "'", double14 == 9.223372036854776E18d);
//        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list20);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-62104204800001L) + "'", long30 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560182388958L + "'", long42 == 1560182388958L);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560182388958L + "'", long46 == 1560182388958L);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560182388961L + "'", long57 == 1560182388961L);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2147483647 + "'", int62 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(obj64);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(timeSeries66);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "10-June-2019" + "'", str70.equals("10-June-2019"));
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182374643L, "Mon Jun 10 08:59:45 PDT 2019", "org.jfree.data.event.SeriesChangeEvent[source=100]");
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        java.lang.String str5 = timeSeries3.getDomainDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        long long8 = timeSeries3.getMaximumItemAge();
        try {
            java.lang.Number number10 = timeSeries3.getValue(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9223372036854775807L + "'", long8 == 9223372036854775807L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("September 6");
        long long2 = month1.getLastMillisecond();
        java.lang.String str3 = month1.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month1.previous();
        org.junit.Assert.assertNotNull(month1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-61954387200001L) + "'", long2 == (-61954387200001L));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "September 6" + "'", str3.equals("September 6"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, (java.lang.Number) (byte) 100);
        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) (short) 10);
        timeSeries3.add(timeSeriesDataItem8);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener12);
        timeSeries3.setMaximumItemCount(0);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double20 = timeSeries19.getMaxY();
        timeSeries19.removeAgedItems((long) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries19.removeChangeListener(seriesChangeListener24);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        int int29 = month28.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month28.next();
        timeSeries19.add(regularTimePeriod30, (double) 1560182345775L, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries3.addOrUpdate(regularTimePeriod30, (double) 1560182350412L);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
//        timeSeries1.addChangeListener(seriesChangeListener2);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        boolean boolean6 = timeSeries1.equals((java.lang.Object) timePeriodFormatException5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) (byte) 100);
//        boolean boolean11 = timeSeriesDataItem9.equals((java.lang.Object) (short) 10);
//        boolean boolean12 = timeSeriesDataItem9.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double17 = timeSeries16.getMaxY();
//        int int18 = timeSeries16.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 6);
//        long long22 = fixedMillisecond19.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double27 = timeSeries26.getMaxY();
//        java.util.List list28 = timeSeries26.getItems();
//        timeSeries26.removeAgedItems((long) (byte) 100, false);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) (byte) 100);
//        int int33 = timeSeriesDataItem9.compareTo((java.lang.Object) fixedMillisecond19);
//        int int34 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        timeSeries1.clear();
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.next();
//        long long40 = year38.getLastMillisecond();
//        int int41 = year38.getYear();
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(4, year38);
//        timeSeries1.setKey((java.lang.Comparable) month42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day44, (java.lang.Number) (byte) 100);
//        boolean boolean48 = timeSeriesDataItem46.equals((java.lang.Object) (short) 10);
//        boolean boolean49 = timeSeriesDataItem46.isSelected();
//        java.lang.Object obj50 = timeSeriesDataItem46.clone();
//        timeSeries1.add(timeSeriesDataItem46, false);
//        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj56 = null;
//        int int57 = month55.compareTo(obj56);
//        java.util.Date date58 = month55.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month55, (double) 1560182343140L);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent61 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem60);
//        try {
//            timeSeries1.add(timeSeriesDataItem60, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560182389653L + "'", long22 == 1560182389653L);
//        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list28);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-62104204800001L) + "'", long40 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(obj50);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertNotNull(date58);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day8);
        java.util.Collection collection11 = timeSeries1.getTimePeriods();
        long long12 = timeSeries1.getMaximumItemAge();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        timeSeries3.setDescription("Mon Jun 10 08:59:05 PDT 2019");
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries15.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day18, (double) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day18.next();
        timeSeries1.add(regularTimePeriod22, (double) 1560182340527L);
        long long25 = timeSeries1.getMaximumItemAge();
        java.lang.String str26 = timeSeries1.getDomainDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = null;
        try {
            timeSeries1.add(regularTimePeriod27, (double) 1560182365022L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        timeSeries3.removeAgedItems((long) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 100);
        boolean boolean14 = timeSeriesDataItem12.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem12.setSelected(false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.addOrUpdate(timeSeriesDataItem12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeriesDataItem12.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem12, "Mon Jun 10 08:59:05 PDT 2019", "Mon Jun 10 08:59:28 PDT 2019");
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        int int2 = day0.getMonth();
        int int3 = day0.getMonth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getLastMillisecond(calendar2);
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond0.peg(calendar4);
//        java.util.Date date6 = fixedMillisecond0.getEnd();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182390211L + "'", long1 == 1560182390211L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560182390211L + "'", long3 == 1560182390211L);
//        org.junit.Assert.assertNotNull(date6);
//    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        long long9 = fixedMillisecond6.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond6.previous();
//        java.lang.Object obj11 = null;
//        boolean boolean12 = fixedMillisecond6.equals(obj11);
//        long long13 = fixedMillisecond6.getMiddleMillisecond();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182390226L + "'", long9 == 1560182390226L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560182390226L + "'", long13 == 1560182390226L);
//    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener18);
//        timeSeries3.setDomainDescription("");
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries27.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries27.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month32, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month32.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries25.addOrUpdate(regularTimePeriod35, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener38 = null;
//        timeSeries25.addChangeListener(seriesChangeListener38);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day40.previous();
//        long long42 = day40.getFirstMillisecond();
//        int int43 = timeSeries25.getIndex((org.jfree.data.time.RegularTimePeriod) day40);
//        long long44 = day40.getFirstMillisecond();
//        int int45 = day40.getMonth();
//        int int46 = day40.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) day40);
//        java.lang.Number number48 = timeSeriesDataItem47.getValue();
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNull(timeSeriesDataItem34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNull(timeSeriesDataItem37);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560150000000L + "'", long42 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560150000000L + "'", long44 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 6 + "'", int45 == 6);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2019 + "'", int46 == 2019);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem47);
//        org.junit.Assert.assertTrue("'" + number48 + "' != '" + 10.0d + "'", number48.equals(10.0d));
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.String str6 = seriesChangeEvent5.toString();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = seriesChangeEvent5.getSummary();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(seriesChangeInfo7);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        long long9 = month8.getFirstMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month8);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month21.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries14.addOrUpdate(regularTimePeriod24, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries14.addChangeListener(seriesChangeListener27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.previous();
//        long long31 = day29.getFirstMillisecond();
//        int int32 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) day29);
//        long long33 = day29.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day29.previous();
//        timeSeries3.add(regularTimePeriod34, (double) 1560182341608L, false);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod34, "Mon Jun 10 08:59:09 PDT 2019", "org.jfree.data.time.TimePeriodFormatException: hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond41.getMiddleMillisecond(calendar42);
//        java.util.Date date44 = fixedMillisecond41.getTime();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond(date44);
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date44);
//        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) year47, (java.lang.Number) 1560182374632L);
//        java.util.Calendar calendar50 = null;
//        try {
//            long long51 = year47.getFirstMillisecond(calendar50);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-58987929600000L) + "'", long9 == (-58987929600000L));
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560150000000L + "'", long31 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560150000000L + "'", long33 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560182390736L + "'", long43 == 1560182390736L);
//        org.junit.Assert.assertNotNull(date44);
//    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        timeSeries1.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double15 = timeSeries14.getMaxY();
//        timeSeries14.removeAgedItems((long) 10, false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
//        timeSeries14.removeChangeListener(seriesChangeListener19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) (byte) 100);
//        boolean boolean25 = timeSeriesDataItem23.equals((java.lang.Object) (short) 10);
//        timeSeriesDataItem23.setSelected(false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries14.addOrUpdate(timeSeriesDataItem23);
//        java.lang.String str29 = timeSeries14.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries1.addAndOrUpdate(timeSeries14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar32 = null;
//        long long33 = fixedMillisecond31.getMiddleMillisecond(calendar32);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException35 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int36 = fixedMillisecond31.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = fixedMillisecond31.previous();
//        try {
//            timeSeries14.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (double) 1560182387126L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560182390803L + "'", long33 == 1560182390803L);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod37);
//    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day4.getFirstMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182391258L + "'", long2 == 1560182391258L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        timeSeries1.clear();
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries15.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day18, (double) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day18.next();
        timeSeries1.add(regularTimePeriod22, (double) 1560182340527L);
        long long25 = timeSeries1.getMaximumItemAge();
        int int26 = timeSeries1.getItemCount();
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
//        long long2 = year1.getSerialIndex();
//        long long3 = year1.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        long long5 = fixedMillisecond4.getMiddleMillisecond();
//        int int6 = year1.compareTo((java.lang.Object) fixedMillisecond4);
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond4.getMiddleMillisecond(calendar7);
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond4.peg(calendar9);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560182391409L + "'", long5 == 1560182391409L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560182391409L + "'", long8 == 1560182391409L);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        timeSeries3.setMaximumItemAge((long) 12);
        boolean boolean9 = timeSeries3.isEmpty();
        try {
            timeSeries3.setMaximumItemAge((-62135740800000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        seriesChangeEvent5.setSummary(seriesChangeInfo6);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean6 = timeSeries1.equals((java.lang.Object) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries11.addChangeListener(seriesChangeListener12);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean16 = timeSeries11.equals((java.lang.Object) timePeriodFormatException15);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries22.addChangeListener(seriesChangeListener23);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean27 = timeSeries22.equals((java.lang.Object) timePeriodFormatException26);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        java.lang.String str32 = timePeriodFormatException8.toString();
        org.jfree.data.general.SeriesException seriesException34 = new org.jfree.data.general.SeriesException("");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) seriesException34);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str32.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.event.SeriesChangeEvent[source=100]"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 6);
        java.lang.String str3 = month2.toString();
        int int4 = month2.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str9 = timeSeries8.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries8);
        java.lang.Object obj11 = timeSeries8.clone();
        boolean boolean12 = month2.equals(obj11);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = month2.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "September 6" + "'", str3.equals("September 6"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.time.TimePeriodFormatException: hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries7);
        java.lang.String str10 = seriesChangeEvent9.toString();
        boolean boolean11 = month2.equals((java.lang.Object) seriesChangeEvent9);
        org.jfree.data.time.Year year12 = month2.getYear();
        java.util.Calendar calendar13 = null;
        try {
            year12.peg(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-58987929600000L) + "'", long3 == (-58987929600000L));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(year12);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, (java.lang.Number) (byte) 100);
        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem8.setSelected(false);
        int int14 = timeSeriesDataItem8.compareTo((java.lang.Object) 1560182341157L);
        timeSeriesDataItem8.setSelected(true);
        timeSeries3.add(timeSeriesDataItem8);
        java.lang.Number number18 = timeSeriesDataItem8.getValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = timeSeriesDataItem8.getPeriod();
        boolean boolean20 = timeSeriesDataItem8.isSelected();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (byte) 100 + "'", number18.equals((byte) 100));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
        java.lang.String str2 = year1.toString();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(0);
        long long5 = year4.getSerialIndex();
        int int6 = year4.getYear();
        long long7 = year4.getFirstMillisecond();
        boolean boolean8 = year1.equals((java.lang.Object) year4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62167363200000L) + "'", long7 == (-62167363200000L));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar2 = null;
//        fixedMillisecond0.peg(calendar2);
//        java.lang.String str4 = fixedMillisecond0.toString();
//        java.util.Date date5 = fixedMillisecond0.getTime();
//        java.util.TimeZone timeZone6 = null;
//        try {
//            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5, timeZone6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182392269L + "'", long1 == 1560182392269L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Mon Jun 10 08:59:52 PDT 2019" + "'", str4.equals("Mon Jun 10 08:59:52 PDT 2019"));
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        long long15 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double21 = timeSeries20.getMaxY();
//        int int22 = timeSeries20.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 6);
//        long long26 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond23.previous();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        timeSeries28.setMaximumItemCount(3);
//        java.beans.PropertyChangeListener propertyChangeListener31 = null;
//        timeSeries28.removePropertyChangeListener(propertyChangeListener31);
//        timeSeries28.setDomainDescription("Mon Jun 10 08:59:38 PDT 2019");
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182392313L + "'", long11 == 1560182392313L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182392313L + "'", long15 == 1560182392313L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182392317L + "'", long26 == 1560182392317L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries4.addChangeListener(seriesChangeListener5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean9 = timeSeries4.equals((java.lang.Object) timePeriodFormatException8);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.addChangeListener(seriesChangeListener15);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean19 = timeSeries14.equals((java.lang.Object) timePeriodFormatException18);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timePeriodFormatException18.addSuppressed((java.lang.Throwable) timePeriodFormatException21);
        timePeriodFormatException11.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        java.lang.Throwable[] throwableArray24 = timePeriodFormatException11.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException11);
        java.lang.String str26 = timePeriodFormatException11.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str26.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.event.SeriesChangeEvent[source=100]"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(100, 3, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        java.lang.String str5 = timeSeries3.getDomainDescription();
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double12 = timeSeries11.getMaxY();
        java.util.List list13 = timeSeries11.getItems();
        timeSeries11.removeAgedItems((long) (byte) 100, false);
        java.lang.Comparable comparable17 = timeSeries11.getKey();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day18, (java.lang.Number) (byte) 100);
        boolean boolean22 = timeSeriesDataItem20.equals((java.lang.Object) (short) 10);
        boolean boolean23 = timeSeriesDataItem20.isSelected();
        java.lang.Object obj24 = timeSeriesDataItem20.clone();
        java.lang.Number number25 = null;
        timeSeriesDataItem20.setValue(number25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeriesDataItem20.getPeriod();
        timeSeries11.add(timeSeriesDataItem20, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries3.addOrUpdate(timeSeriesDataItem20);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + comparable17 + "' != '" + 10.0d + "'", comparable17.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj5 = null;
//        int int6 = month4.compareTo(obj5);
//        java.util.Date date7 = month4.getEnd();
//        int int8 = day0.compareTo((java.lang.Object) month4);
//        org.jfree.data.time.Year year9 = month4.getYear();
//        java.lang.String str10 = month4.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(year9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "October 100" + "'", str10.equals("October 100"));
//    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        timeSeries3.removeAgedItems((long) 10, false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener8);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        int int13 = month12.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.next();
//        timeSeries3.add(regularTimePeriod14, (double) 1560182345775L, false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        long long19 = fixedMillisecond18.getLastMillisecond();
//        java.util.Calendar calendar20 = null;
//        fixedMillisecond18.peg(calendar20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int27 = fixedMillisecond22.compareTo((java.lang.Object) "hi!");
//        java.util.Date date28 = fixedMillisecond22.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        java.lang.Object obj31 = timeSeries30.clone();
//        java.lang.String str32 = timeSeries30.getDomainDescription();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560182392842L + "'", long19 == 1560182392842L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560182392843L + "'", long24 == 1560182392843L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertNotNull(obj31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "hi!" + "'", str32.equals("hi!"));
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 1560182359592L);
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day0.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries13.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month18);
        java.lang.String str23 = timeSeries3.getRangeDescription();
        timeSeries3.removeAgedItems(1560182350391L, false);
        timeSeries3.clear();
        timeSeries3.setNotify(false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        int int6 = timeSeries3.getItemCount();
        try {
            timeSeries3.delete(2147483647, (int) (short) 1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.Year year7 = month6.getYear();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = month6.getFirstMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182393113L + "'", long2 == 1560182393113L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year7);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560182370814L);
        java.util.Date date2 = fixedMillisecond1.getEnd();
        org.junit.Assert.assertNotNull(date2);
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        java.lang.String str9 = timeSeries3.getDescription();
//        double double10 = timeSeries3.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries12.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) day19, (double) 6);
//        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) day19, 0.0d);
//        long long25 = day19.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day19.previous();
//        long long29 = day19.getLastMillisecond();
//        boolean boolean30 = timeSeries3.equals((java.lang.Object) day19);
//        boolean boolean31 = timeSeries3.getNotify();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 6.0d + "'", double10 == 6.0d);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560236399999L + "'", long25 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560236399999L + "'", long29 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        timeSeries3.removeAgedItems((long) 10, false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 100);
//        boolean boolean14 = timeSeriesDataItem12.equals((java.lang.Object) (short) 10);
//        timeSeriesDataItem12.setSelected(false);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.addOrUpdate(timeSeriesDataItem12);
//        java.lang.String str18 = timeSeries3.getRangeDescription();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.lang.String str20 = day19.toString();
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj24 = null;
//        int int25 = month23.compareTo(obj24);
//        java.util.Date date26 = month23.getEnd();
//        int int27 = day19.compareTo((java.lang.Object) month23);
//        org.jfree.data.time.Year year28 = month23.getYear();
//        try {
//            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month23, (double) 1560182355012L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hi!" + "'", str18.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10-June-2019" + "'", str20.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(year28);
//    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test148");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (byte) 100);
//        java.lang.Number number3 = timeSeriesDataItem2.getValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeriesDataItem2.getPeriod();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double9 = timeSeries8.getMaxY();
//        int int10 = timeSeries8.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 6);
//        long long14 = fixedMillisecond11.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double19 = timeSeries18.getMaxY();
//        java.util.List list20 = timeSeries18.getItems();
//        timeSeries18.removeAgedItems((long) (byte) 100, false);
//        boolean boolean24 = fixedMillisecond11.equals((java.lang.Object) (byte) 100);
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        long long29 = timeSeries28.getMaximumItemAge();
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (java.lang.Number) (byte) 100);
//        boolean boolean34 = timeSeriesDataItem32.equals((java.lang.Object) (short) 10);
//        boolean boolean35 = timeSeriesDataItem32.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries28.addOrUpdate(timeSeriesDataItem32);
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries38.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month43, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = month43.next();
//        timeSeries28.delete((org.jfree.data.time.RegularTimePeriod) month43);
//        boolean boolean48 = fixedMillisecond11.equals((java.lang.Object) month43);
//        java.util.Date date49 = fixedMillisecond11.getTime();
//        boolean boolean50 = timeSeriesDataItem2.equals((java.lang.Object) fixedMillisecond11);
//        java.lang.Object obj51 = timeSeriesDataItem2.clone();
//        java.lang.Number number52 = null;
//        timeSeriesDataItem2.setValue(number52);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = timeSeriesDataItem2.getPeriod();
//        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (byte) 100 + "'", number3.equals((byte) 100));
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560182393328L + "'", long14 == 1560182393328L);
//        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list20);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 9223372036854775807L + "'", long29 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertNull(timeSeriesDataItem45);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(obj51);
//        org.junit.Assert.assertNotNull(regularTimePeriod54);
//    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getItemCount();
        timeSeries3.setMaximumItemCount(1);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = timeSeries3.getTimePeriod(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        timeSeries1.fireSeriesChanged();
//        timeSeries1.setDescription("Mon Jun 10 08:59:09 PDT 2019");
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener12);
//        double double14 = timeSeries1.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double19 = timeSeries18.getMaxY();
//        java.util.List list20 = timeSeries18.getItems();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) (byte) 100);
//        boolean boolean25 = timeSeriesDataItem23.equals((java.lang.Object) (short) 10);
//        timeSeries18.add(timeSeriesDataItem23);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.next();
//        long long30 = year28.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries32.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) (byte) 100);
//        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar41 = null;
//        long long42 = fixedMillisecond40.getMiddleMillisecond(calendar41);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException44 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int45 = fixedMillisecond40.compareTo((java.lang.Object) "hi!");
//        long long46 = fixedMillisecond40.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = fixedMillisecond40.next();
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double52 = timeSeries51.getMaxY();
//        int int53 = timeSeries51.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries51.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (double) 6);
//        long long57 = fixedMillisecond54.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = fixedMillisecond54.previous();
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond54);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener60 = null;
//        timeSeries59.addChangeListener(seriesChangeListener60);
//        int int62 = timeSeries59.getMaximumItemCount();
//        int int63 = year28.compareTo((java.lang.Object) timeSeries59);
//        java.lang.Object obj64 = timeSeries59.clone();
//        boolean boolean65 = timeSeriesDataItem23.equals((java.lang.Object) timeSeries59);
//        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries1.addAndOrUpdate(timeSeries59);
//        java.lang.Comparable comparable67 = timeSeries1.getKey();
//        java.lang.String str68 = timeSeries1.getDomainDescription();
//        double double69 = timeSeries1.getMaxY();
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 9.223372036854776E18d + "'", double14 == 9.223372036854776E18d);
//        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list20);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-62104204800001L) + "'", long30 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560182394236L + "'", long42 == 1560182394236L);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560182394236L + "'", long46 == 1560182394236L);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560182394238L + "'", long57 == 1560182394238L);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2147483647 + "'", int62 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(obj64);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(timeSeries66);
//        org.junit.Assert.assertTrue("'" + comparable67 + "' != '" + 9 + "'", comparable67.equals(9));
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Time" + "'", str68.equals("Time"));
//        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 9.223372036854776E18d + "'", double69 == 9.223372036854776E18d);
//    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        timeSeries1.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries12.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) day19, (double) 6);
//        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) day19, 0.0d);
//        long long25 = day19.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day19.next();
//        org.jfree.data.time.SerialDate serialDate29 = day19.getSerialDate();
//        boolean boolean30 = timeSeries1.equals((java.lang.Object) day19);
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries32.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries36.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = day39.previous();
//        timeSeries36.add((org.jfree.data.time.RegularTimePeriod) day39, (double) 6);
//        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) day39, 0.0d);
//        long long45 = day39.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day39, (java.lang.Number) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = day39.next();
//        org.jfree.data.time.SerialDate serialDate49 = day39.getSerialDate();
//        try {
//            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day39, (double) 1560182385765L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 10-June-2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560236399999L + "'", long25 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560236399999L + "'", long45 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(serialDate49);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 0);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        long long20 = day18.getFirstMillisecond();
//        int int21 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day18);
//        long long22 = day18.getFirstMillisecond();
//        int int23 = day18.getMonth();
//        java.util.Calendar calendar24 = null;
//        try {
//            long long25 = day18.getFirstMillisecond(calendar24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560150000000L + "'", long20 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560150000000L + "'", long22 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        timeSeries3.removeAgedItems((long) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        int int10 = timeSeries3.getMaximumItemCount();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 6);
        java.lang.String str3 = month2.toString();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "September 6" + "'", str3.equals("September 6"));
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        long long15 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double21 = timeSeries20.getMaxY();
//        int int22 = timeSeries20.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 6);
//        long long26 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond23.previous();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
//        timeSeries28.addChangeListener(seriesChangeListener29);
//        boolean boolean31 = timeSeries28.isEmpty();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar33 = null;
//        long long34 = fixedMillisecond32.getMiddleMillisecond(calendar33);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException36 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int37 = fixedMillisecond32.compareTo((java.lang.Object) "hi!");
//        java.util.Date date38 = fixedMillisecond32.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(date38);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date38);
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date38);
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date38);
//        try {
//            timeSeries28.add((org.jfree.data.time.RegularTimePeriod) day42, (double) 1560182373233L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 10-June-2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182395123L + "'", long11 == 1560182395123L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182395123L + "'", long15 == 1560182395123L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182395124L + "'", long26 == 1560182395124L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560182395126L + "'", long34 == 1560182395126L);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertNotNull(date38);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        timeSeries3.setRangeDescription("");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        java.util.Date date11 = regularTimePeriod10.getStart();
        timeSeries3.add(regularTimePeriod10, (double) 1560182341123L);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        int int17 = month16.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month16.next();
        long long19 = month16.getFirstMillisecond();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month16, (java.lang.Number) (-62167363200000L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Year.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-58987929600000L) + "'", long19 == (-58987929600000L));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj4 = null;
        int int5 = month3.compareTo(obj4);
        org.jfree.data.time.Year year6 = month3.getYear();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(1, year6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month7.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
        java.lang.String str9 = timeSeries3.getDescription();
        try {
            timeSeries3.delete(100, 8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        long long7 = timeSeries3.getMaximumItemAge();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.addChangeListener(seriesChangeListener8);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries3.removeChangeListener(seriesChangeListener10);
        timeSeries3.setRangeDescription("org.jfree.data.general.SeriesException: ");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener14);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.addChangeListener(seriesChangeListener8);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond12.previous();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 1560182355429L, false);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond12.getMiddleMillisecond(calendar18);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond20.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
//        boolean boolean25 = fixedMillisecond12.equals((java.lang.Object) fixedMillisecond24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond24.previous();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560182395331L + "'", long13 == 1560182395331L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560182395331L + "'", long19 == 1560182395331L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560182395344L + "'", long22 == 1560182395344L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
//        java.lang.String str4 = timeSeries3.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
//        java.lang.String str9 = timeSeries8.getDescription();
//        java.lang.String str10 = timeSeries8.getDomainDescription();
//        java.util.Collection collection11 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries17.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month22.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries15.addOrUpdate(regularTimePeriod25, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries15.addChangeListener(seriesChangeListener28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 1560193199999L);
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond34.getMiddleMillisecond(calendar35);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException38 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int39 = fixedMillisecond34.compareTo((java.lang.Object) "hi!");
//        java.util.Date date40 = fixedMillisecond34.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond34.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries15.getDataItem(regularTimePeriod41);
//        timeSeries8.add(regularTimePeriod41, (java.lang.Number) 1560182385451L, true);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries48 = timeSeries8.createCopy((int) (byte) 0, 2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560182395522L + "'", long36 == 1560182395522L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(timeSeriesDataItem42);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        int int2 = day0.getMonth();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, "org.jfree.data.event.SeriesChangeEvent[source=1560182345230]", "");
        try {
            timeSeries5.delete(5, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        long long6 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        java.lang.String str8 = fixedMillisecond0.toString();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj12 = null;
//        int int13 = month11.compareTo(obj12);
//        org.jfree.data.time.Year year14 = month11.getYear();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        int int19 = year14.compareTo((java.lang.Object) timeSeries16);
//        boolean boolean20 = fixedMillisecond0.equals((java.lang.Object) timeSeries16);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj24 = null;
//        int int25 = month23.compareTo(obj24);
//        org.jfree.data.time.Year year26 = month23.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) year26);
//        double double28 = timeSeries16.getMaxY();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries30.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries34.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day37.previous();
//        timeSeries34.add((org.jfree.data.time.RegularTimePeriod) day37, (double) 6);
//        timeSeries30.add((org.jfree.data.time.RegularTimePeriod) day37, 0.0d);
//        long long43 = day37.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day37, (java.lang.Number) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day37.previous();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond(1560182370814L);
//        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries16.createCopy(regularTimePeriod46, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond48);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182395705L + "'", long2 == 1560182395705L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182395705L + "'", long6 == 1560182395705L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Mon Jun 10 08:59:55 PDT 2019" + "'", str8.equals("Mon Jun 10 08:59:55 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560236399999L + "'", long43 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertNotNull(timeSeries49);
//    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
//        java.lang.String str13 = timeSeries12.getDescription();
//        java.util.Collection collection14 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries12);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double19 = timeSeries18.getMaxY();
//        int int20 = timeSeries18.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (double) 6);
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond21.getMiddleMillisecond(calendar24);
//        java.util.Calendar calendar26 = null;
//        fixedMillisecond21.peg(calendar26);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 1560182353546L);
//        try {
//            timeSeries12.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 1560182378522L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNull(str13);
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560182395990L + "'", long25 == 1560182395990L);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        java.util.Date date5 = month2.getEnd();
        int int7 = month2.compareTo((java.lang.Object) 1560182345060L);
        long long8 = month2.getSerialIndex();
        int int9 = month2.getYearValue();
        int int10 = month2.getMonth();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = month2.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1210L + "'", long8 == 1210L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj4 = null;
        int int5 = month3.compareTo(obj4);
        java.util.Date date6 = month3.getEnd();
        int int8 = month3.compareTo((java.lang.Object) 1560182345060L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month3.next();
        org.jfree.data.time.Year year10 = month3.getYear();
        long long11 = year10.getFirstMillisecond();
        long long12 = year10.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year10.next();
        long long14 = year10.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year10.next();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(4, year10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(year10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-59011603200000L) + "'", long11 == (-59011603200000L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-59011603200000L) + "'", long12 == (-59011603200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-58979980800001L) + "'", long14 == (-58979980800001L));
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(0);
        long long3 = year2.getSerialIndex();
        long long4 = year2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year2.next();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(11, year2);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month6.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.List list5 = timeSeries3.getItems();
//        timeSeries3.setNotify(false);
//        java.lang.String str8 = timeSeries3.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        java.util.Date date12 = fixedMillisecond9.getTime();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date12);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date12);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date12);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 1560182358499L);
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj22 = null;
//        int int23 = month21.compareTo(obj22);
//        org.jfree.data.time.Year year24 = month21.getYear();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries26.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        int int29 = year24.compareTo((java.lang.Object) timeSeries26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year24.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year24);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182396462L + "'", long11 == 1560182396462L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 6);
        java.lang.String str3 = month2.toString();
        int int4 = month2.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str9 = timeSeries8.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries8);
        java.lang.Object obj11 = timeSeries8.clone();
        boolean boolean12 = month2.equals(obj11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month2.previous();
        long long14 = month2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "September 6" + "'", str3.equals("September 6"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61956979200000L) + "'", long14 == (-61956979200000L));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.event.SeriesChangeEvent[source=100]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test173");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 100, seriesChangeInfo8);
//        java.lang.Object obj10 = seriesChangeEvent9.getSource();
//        java.lang.String str11 = seriesChangeEvent9.toString();
//        java.lang.Object obj12 = seriesChangeEvent9.getSource();
//        boolean boolean13 = fixedMillisecond6.equals((java.lang.Object) seriesChangeEvent9);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182396624L + "'", long2 == 1560182396624L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + obj10 + "' != '" + (short) 100 + "'", obj10.equals((short) 100));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str11.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
//        org.junit.Assert.assertTrue("'" + obj12 + "' != '" + (short) 100 + "'", obj12.equals((short) 100));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, (java.lang.Number) (byte) 100);
        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) (short) 10);
        timeSeries3.add(timeSeriesDataItem8);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener12);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries3.removeChangeListener(seriesChangeListener14);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        long long6 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        java.lang.String str8 = fixedMillisecond0.toString();
//        java.lang.Class<?> wildcardClass9 = fixedMillisecond0.getClass();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182396695L + "'", long2 == 1560182396695L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182396695L + "'", long6 == 1560182396695L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Mon Jun 10 08:59:56 PDT 2019" + "'", str8.equals("Mon Jun 10 08:59:56 PDT 2019"));
//        org.junit.Assert.assertNotNull(wildcardClass9);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        int int3 = month2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        long long5 = month2.getSerialIndex();
        int int6 = month2.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries8.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) (byte) 100);
        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 9223372036854775807L);
        org.jfree.data.time.SerialDate serialDate16 = day11.getSerialDate();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(serialDate16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate16);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate16);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate16);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate16);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double26 = timeSeries25.getMaxY();
        java.util.List list27 = timeSeries25.getItems();
        timeSeries25.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries25.createCopy((int) (byte) 1, 9999);
        boolean boolean33 = day21.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day21);
        boolean boolean35 = month2.equals((java.lang.Object) day21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1210L + "'", long5 == 1210L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertEquals((double) double26, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (byte) 100);
        boolean boolean4 = timeSeriesDataItem2.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem2.setSelected(false);
        java.lang.Number number7 = timeSeriesDataItem2.getValue();
        boolean boolean8 = timeSeriesDataItem2.isSelected();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) 100 + "'", number7.equals((byte) 100));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries7);
        java.lang.String str10 = seriesChangeEvent9.toString();
        boolean boolean11 = month2.equals((java.lang.Object) seriesChangeEvent9);
        org.jfree.data.time.Year year12 = month2.getYear();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = year12.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-58987929600000L) + "'", long3 == (-58987929600000L));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(year12);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        long long9 = fixedMillisecond6.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond6.previous();
//        java.lang.Object obj11 = null;
//        boolean boolean12 = fixedMillisecond6.equals(obj11);
//        long long13 = fixedMillisecond6.getFirstMillisecond();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182396972L + "'", long9 == 1560182396972L);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560182396972L + "'", long13 == 1560182396972L);
//    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
//        long long3 = year1.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, (java.lang.Number) (byte) 100);
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int18 = fixedMillisecond13.compareTo((java.lang.Object) "hi!");
//        long long19 = fixedMillisecond13.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond13.next();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double25 = timeSeries24.getMaxY();
//        int int26 = timeSeries24.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) 6);
//        long long30 = fixedMillisecond27.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond27.previous();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
//        timeSeries32.addChangeListener(seriesChangeListener33);
//        int int35 = timeSeries32.getMaximumItemCount();
//        int int36 = year1.compareTo((java.lang.Object) timeSeries32);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day37, (java.lang.Number) (byte) 100);
//        boolean boolean41 = timeSeriesDataItem39.equals((java.lang.Object) (short) 10);
//        boolean boolean42 = timeSeriesDataItem39.isSelected();
//        java.lang.Object obj43 = timeSeriesDataItem39.clone();
//        java.lang.Number number44 = null;
//        timeSeriesDataItem39.setValue(number44);
//        timeSeriesDataItem39.setSelected(true);
//        java.lang.Object obj48 = timeSeriesDataItem39.clone();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries32.addOrUpdate(timeSeriesDataItem39);
//        java.lang.Number number50 = timeSeriesDataItem39.getValue();
//        timeSeriesDataItem39.setSelected(false);
//        timeSeriesDataItem39.setSelected(false);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62104204800001L) + "'", long3 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182396989L + "'", long15 == 1560182396989L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560182396989L + "'", long19 == 1560182396989L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560182396991L + "'", long30 == 1560182396991L);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2147483647 + "'", int35 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(obj43);
//        org.junit.Assert.assertNotNull(obj48);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNull(number50);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2147483647, 7, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
//        timeSeries1.addChangeListener(seriesChangeListener2);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        boolean boolean6 = timeSeries1.equals((java.lang.Object) timePeriodFormatException5);
//        java.util.List list7 = timeSeries1.getItems();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.lang.String str9 = day8.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = null;
//        try {
//            org.jfree.data.time.TimeSeries timeSeries11 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day8, regularTimePeriod10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(list7);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
        java.lang.String str9 = timeSeries3.getDescription();
        timeSeries3.setDescription("");
        java.lang.Class class12 = timeSeries3.getTimePeriodClass();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(class12);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        int int6 = timeSeries3.getItemCount();
        boolean boolean7 = timeSeries3.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(1560182346836L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) 1560182367767L);
        boolean boolean14 = timeSeries3.isEmpty();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.getDataItem((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182346836L + "'", long11 == 1560182346836L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        try {
            timeSeries3.delete((int) '#', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        org.jfree.data.time.Year year5 = month2.getYear();
        java.lang.String str6 = year5.toString();
        boolean boolean8 = year5.equals((java.lang.Object) 1560182381421L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        java.lang.String str12 = timeSeries3.getDomainDescription();
        try {
            java.lang.Number number14 = timeSeries3.getValue((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        long long3 = year1.getLastMillisecond();
        int int4 = year1.getYear();
        long long5 = year1.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62104204800001L) + "'", long3 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62104204800001L) + "'", long5 == (-62104204800001L));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        timeSeries3.setRangeDescription("");
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.next();
        java.util.Date date11 = regularTimePeriod10.getStart();
        timeSeries3.add(regularTimePeriod10, (double) 1560182341123L);
        timeSeries3.setDescription("hi!");
        boolean boolean16 = timeSeries3.getNotify();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = timeSeries3.getTimePeriod(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.setNotify(false);
        boolean boolean8 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.createCopy((int) (byte) 0, 4);
        int int12 = timeSeries11.getMaximumItemCount();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.Object obj6 = timeSeries3.clone();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) (byte) 100);
        boolean boolean11 = timeSeriesDataItem9.equals((java.lang.Object) (short) 10);
        boolean boolean12 = timeSeriesDataItem9.isSelected();
        java.lang.Object obj13 = timeSeriesDataItem9.clone();
        java.lang.Number number14 = null;
        timeSeriesDataItem9.setValue(number14);
        timeSeriesDataItem9.setSelected(true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate(timeSeriesDataItem9);
        long long19 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day20, (java.lang.Number) (byte) 100);
        boolean boolean24 = timeSeriesDataItem22.equals((java.lang.Object) (short) 10);
        boolean boolean25 = timeSeriesDataItem22.isSelected();
        java.lang.Object obj26 = timeSeriesDataItem22.clone();
        java.lang.Number number27 = null;
        timeSeriesDataItem22.setValue(number27);
        timeSeriesDataItem22.setSelected(true);
        java.lang.Object obj31 = timeSeriesDataItem22.clone();
        timeSeriesDataItem22.setSelected(true);
        java.lang.Number number34 = timeSeriesDataItem22.getValue();
        try {
            timeSeries3.add(timeSeriesDataItem22, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 10-June-2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNull(number34);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond3.getMiddleMillisecond(calendar4);
//        java.util.Date date6 = fixedMillisecond3.getTime();
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date6);
//        org.jfree.data.time.Year year10 = month9.getYear();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
//        try {
//            org.jfree.data.time.TimeSeries timeSeries14 = timeSeries2.createCopy((org.jfree.data.time.RegularTimePeriod) year10, regularTimePeriod13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start on or before end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560182398127L + "'", long5 == 1560182398127L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(year10);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        boolean boolean8 = fixedMillisecond0.equals((java.lang.Object) 1560182343140L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (java.lang.Number) 1560182345714L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182398191L + "'", long2 == 1560182398191L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.setNotify(false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.addChangeListener(seriesChangeListener8);
        timeSeries3.setDescription("hi!");
        try {
            org.jfree.data.time.TimeSeries timeSeries14 = timeSeries3.createCopy((-1), (-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (double) 6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        int int10 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) day8);
//        long long11 = day8.getSerialIndex();
//        java.lang.String str12 = day8.toString();
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test196");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        java.lang.String str9 = timeSeries3.getDescription();
//        double double10 = timeSeries3.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries12.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) day19, (double) 6);
//        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) day19, 0.0d);
//        long long25 = day19.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day19.previous();
//        long long29 = day19.getLastMillisecond();
//        boolean boolean30 = timeSeries3.equals((java.lang.Object) day19);
//        org.jfree.data.time.SerialDate serialDate31 = day19.getSerialDate();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 6.0d + "'", double10 == 6.0d);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560236399999L + "'", long25 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560236399999L + "'", long29 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(serialDate31);
//    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test197");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (byte) 100);
//        boolean boolean4 = timeSeriesDataItem2.equals((java.lang.Object) (short) 10);
//        boolean boolean5 = timeSeriesDataItem2.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double10 = timeSeries9.getMaxY();
//        int int11 = timeSeries9.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 6);
//        long long15 = fixedMillisecond12.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double20 = timeSeries19.getMaxY();
//        java.util.List list21 = timeSeries19.getItems();
//        timeSeries19.removeAgedItems((long) (byte) 100, false);
//        boolean boolean25 = fixedMillisecond12.equals((java.lang.Object) (byte) 100);
//        int int26 = timeSeriesDataItem2.compareTo((java.lang.Object) fixedMillisecond12);
//        boolean boolean28 = fixedMillisecond12.equals((java.lang.Object) 1560182355128L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182398456L + "'", long15 == 1560182398456L);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list21);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.List list5 = timeSeries3.getItems();
//        timeSeries3.setNotify(false);
//        java.lang.String str8 = timeSeries3.getDomainDescription();
//        timeSeries3.setKey((java.lang.Comparable) 4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
//        java.util.Date date14 = fixedMillisecond11.getTime();
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date14);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date14);
//        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year18.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.previous();
//        int int21 = timeSeries3.getIndex(regularTimePeriod20);
//        timeSeries3.removeAgedItems(1560182347331L, true);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560182398486L + "'", long13 == 1560182398486L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        long long9 = month8.getFirstMillisecond();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month8);
        int int11 = month8.getYearValue();
        long long12 = month8.getFirstMillisecond();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-58987929600000L) + "'", long9 == (-58987929600000L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-58987929600000L) + "'", long12 == (-58987929600000L));
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test200");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        long long9 = month8.getFirstMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month8);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month21.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries14.addOrUpdate(regularTimePeriod24, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries14.addChangeListener(seriesChangeListener27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.previous();
//        long long31 = day29.getFirstMillisecond();
//        int int32 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) day29);
//        long long33 = day29.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day29.previous();
//        timeSeries3.add(regularTimePeriod34, (double) 1560182341608L, false);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod34, "Mon Jun 10 08:59:09 PDT 2019", "org.jfree.data.time.TimePeriodFormatException: hi!");
//        java.util.List list41 = timeSeries40.getItems();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-58987929600000L) + "'", long9 == (-58987929600000L));
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560150000000L + "'", long31 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560150000000L + "'", long33 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(list41);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 6);
        java.lang.String str3 = month2.toString();
        int int4 = month2.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str9 = timeSeries8.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries8);
        java.lang.Object obj11 = timeSeries8.clone();
        boolean boolean12 = month2.equals(obj11);
        java.lang.String str13 = month2.toString();
        long long14 = month2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "September 6" + "'", str3.equals("September 6"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "September 6" + "'", str13.equals("September 6"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 81L + "'", long14 == 81L);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries1.getNextTimePeriod();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int20 = fixedMillisecond15.compareTo((java.lang.Object) "hi!");
//        java.util.Date date21 = fixedMillisecond15.getTime();
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date21);
//        boolean boolean23 = timeSeries1.equals((java.lang.Object) month22);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182399196L + "'", long17 == 1560182399196L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test203");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date3);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182399267L + "'", long2 == 1560182399267L);
//        org.junit.Assert.assertNotNull(date3);
//    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        timeSeries3.removeAgedItems((long) 10, false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener8);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        int int13 = month12.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.next();
//        timeSeries3.add(regularTimePeriod14, (double) 1560182345775L, false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        long long19 = fixedMillisecond18.getLastMillisecond();
//        java.util.Calendar calendar20 = null;
//        fixedMillisecond18.peg(calendar20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int27 = fixedMillisecond22.compareTo((java.lang.Object) "hi!");
//        java.util.Date date28 = fixedMillisecond22.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        java.util.Date date31 = fixedMillisecond29.getTime();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560182399309L + "'", long19 == 1560182399309L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560182399310L + "'", long24 == 1560182399310L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertNotNull(date31);
//    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        timeSeries3.removeAgedItems((long) 10, false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener8);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        int int13 = month12.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.next();
//        timeSeries3.add(regularTimePeriod14, (double) 1560182345775L, false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        long long19 = fixedMillisecond18.getLastMillisecond();
//        java.util.Calendar calendar20 = null;
//        fixedMillisecond18.peg(calendar20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int27 = fixedMillisecond22.compareTo((java.lang.Object) "hi!");
//        java.util.Date date28 = fixedMillisecond22.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(1560182346836L);
//        timeSeries30.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 10);
//        java.util.List list35 = timeSeries30.getItems();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560182399447L + "'", long19 == 1560182399447L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560182399448L + "'", long24 == 1560182399448L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertNotNull(list35);
//    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test206");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
//        long long3 = year1.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, (java.lang.Number) (byte) 100);
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int18 = fixedMillisecond13.compareTo((java.lang.Object) "hi!");
//        long long19 = fixedMillisecond13.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond13.next();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double25 = timeSeries24.getMaxY();
//        int int26 = timeSeries24.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) 6);
//        long long30 = fixedMillisecond27.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond27.previous();
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
//        timeSeries32.addChangeListener(seriesChangeListener33);
//        int int35 = timeSeries32.getMaximumItemCount();
//        int int36 = year1.compareTo((java.lang.Object) timeSeries32);
//        java.beans.PropertyChangeListener propertyChangeListener37 = null;
//        timeSeries32.removePropertyChangeListener(propertyChangeListener37);
//        java.beans.PropertyChangeListener propertyChangeListener39 = null;
//        timeSeries32.addPropertyChangeListener(propertyChangeListener39);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries43 = timeSeries32.createCopy((int) ' ', 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62104204800001L) + "'", long3 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182399553L + "'", long15 == 1560182399553L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560182399553L + "'", long19 == 1560182399553L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560182399554L + "'", long30 == 1560182399554L);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2147483647 + "'", int35 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 100);
        boolean boolean14 = timeSeriesDataItem12.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem12.setValue((java.lang.Number) 9);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long21 = timeSeries20.getMaximumItemAge();
        boolean boolean22 = timeSeriesDataItem12.equals((java.lang.Object) timeSeries20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries1.addOrUpdate(timeSeriesDataItem12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeriesDataItem23.getPeriod();
        timeSeriesDataItem23.setSelected(false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 6);
        java.lang.String str3 = month2.toString();
        int int4 = month2.getYearValue();
        java.lang.String str5 = month2.toString();
        long long6 = month2.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "September 6" + "'", str3.equals("September 6"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "September 6" + "'", str5.equals("September 6"));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 81L + "'", long6 == 81L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("-1");
        long long2 = year1.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-62135784000001L) + "'", long2 == (-62135784000001L));
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test210");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        long long9 = month8.getFirstMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month8);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month21.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries14.addOrUpdate(regularTimePeriod24, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries14.addChangeListener(seriesChangeListener27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.previous();
//        long long31 = day29.getFirstMillisecond();
//        int int32 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) day29);
//        long long33 = day29.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day29.previous();
//        timeSeries3.add(regularTimePeriod34, (double) 1560182341608L, false);
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double42 = timeSeries41.getMaxY();
//        java.util.Collection collection43 = timeSeries41.getTimePeriods();
//        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        long long47 = month46.getFirstMillisecond();
//        timeSeries41.delete((org.jfree.data.time.RegularTimePeriod) month46);
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries54.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem61 = timeSeries54.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month59, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = month59.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = timeSeries52.addOrUpdate(regularTimePeriod62, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener65 = null;
//        timeSeries52.addChangeListener(seriesChangeListener65);
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = day67.previous();
//        long long69 = day67.getFirstMillisecond();
//        int int70 = timeSeries52.getIndex((org.jfree.data.time.RegularTimePeriod) day67);
//        long long71 = day67.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = day67.previous();
//        timeSeries41.add(regularTimePeriod72, (double) 1560182341608L, false);
//        org.jfree.data.time.TimeSeries timeSeries78 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod72, "Mon Jun 10 08:59:09 PDT 2019", "org.jfree.data.time.TimePeriodFormatException: hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond79 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar80 = null;
//        long long81 = fixedMillisecond79.getMiddleMillisecond(calendar80);
//        java.util.Date date82 = fixedMillisecond79.getTime();
//        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day(date82);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond84 = new org.jfree.data.time.FixedMillisecond(date82);
//        org.jfree.data.time.Year year85 = new org.jfree.data.time.Year(date82);
//        timeSeries78.add((org.jfree.data.time.RegularTimePeriod) year85, (java.lang.Number) 1560182374632L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = null;
//        try {
//            org.jfree.data.time.TimeSeries timeSeries89 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year85, regularTimePeriod88);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-58987929600000L) + "'", long9 == (-58987929600000L));
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560150000000L + "'", long31 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560150000000L + "'", long33 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection43);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-58987929600000L) + "'", long47 == (-58987929600000L));
//        org.junit.Assert.assertNull(timeSeriesDataItem61);
//        org.junit.Assert.assertNotNull(regularTimePeriod62);
//        org.junit.Assert.assertNull(timeSeriesDataItem64);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1560150000000L + "'", long69 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560150000000L + "'", long71 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod72);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 1560182400315L + "'", long81 == 1560182400315L);
//        org.junit.Assert.assertNotNull(date82);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries7.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries11.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.previous();
        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) day14, (double) 6);
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day14, 0.0d);
        java.util.Date date20 = day14.getEnd();
        java.lang.Number number21 = null;
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day14, number21);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date20);
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test212");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
//        timeSeries1.addChangeListener(seriesChangeListener2);
//        java.lang.String str4 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond6.getMiddleMillisecond(calendar7);
//        java.util.Date date9 = fixedMillisecond6.getEnd();
//        boolean boolean10 = day5.equals((java.lang.Object) fixedMillisecond6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond6.previous();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (java.lang.Number) 1560182368684L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560182400371L + "'", long8 == 1560182400371L);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.List list5 = timeSeries3.getItems();
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((int) (byte) 1, 9999);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        long long15 = timeSeries14.getMaximumItemAge();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) (byte) 100);
//        boolean boolean20 = timeSeriesDataItem18.equals((java.lang.Object) (short) 10);
//        boolean boolean21 = timeSeriesDataItem18.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries14.addOrUpdate(timeSeriesDataItem18);
//        java.util.Collection collection23 = timeSeries14.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries10.addAndOrUpdate(timeSeries14);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries26.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) (byte) 100);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate34 = day29.getSerialDate();
//        java.lang.String str35 = day29.toString();
//        java.lang.String str36 = day29.toString();
//        java.lang.String str37 = day29.toString();
//        int int38 = timeSeries24.getIndex((org.jfree.data.time.RegularTimePeriod) day29);
//        int int39 = day29.getMonth();
//        long long40 = day29.getLastMillisecond();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list5);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertNotNull(collection23);
//        org.junit.Assert.assertNotNull(timeSeries24);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "10-June-2019" + "'", str35.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "10-June-2019" + "'", str36.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "10-June-2019" + "'", str37.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560236399999L + "'", long40 == 1560236399999L);
//    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        java.lang.String str9 = timeSeries3.getDescription();
//        double double10 = timeSeries3.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries12.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) day19, (double) 6);
//        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) day19, 0.0d);
//        long long25 = day19.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day19.previous();
//        long long29 = day19.getLastMillisecond();
//        boolean boolean30 = timeSeries3.equals((java.lang.Object) day19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day19.previous();
//        java.util.Calendar calendar32 = null;
//        try {
//            day19.peg(calendar32);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 6.0d + "'", double10 == 6.0d);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560236399999L + "'", long25 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560236399999L + "'", long29 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getFirstMillisecond();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getFirstMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month2.next();
        int int8 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false);
        timeSeries1.setKey((java.lang.Comparable) 100.0f);
        java.lang.Object obj4 = timeSeries1.clone();
        java.lang.String str5 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        long long15 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double21 = timeSeries20.getMaxY();
//        int int22 = timeSeries20.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 6);
//        long long26 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond23.previous();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        timeSeries28.setMaximumItemCount(3);
//        boolean boolean31 = timeSeries28.isEmpty();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
//        timeSeries28.addChangeListener(seriesChangeListener32);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182400660L + "'", long11 == 1560182400660L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182400660L + "'", long15 == 1560182400660L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182400662L + "'", long26 == 1560182400662L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test220");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
//        timeSeries1.addChangeListener(seriesChangeListener2);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        boolean boolean6 = timeSeries1.equals((java.lang.Object) timePeriodFormatException5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) (byte) 100);
//        boolean boolean11 = timeSeriesDataItem9.equals((java.lang.Object) (short) 10);
//        boolean boolean12 = timeSeriesDataItem9.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double17 = timeSeries16.getMaxY();
//        int int18 = timeSeries16.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 6);
//        long long22 = fixedMillisecond19.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double27 = timeSeries26.getMaxY();
//        java.util.List list28 = timeSeries26.getItems();
//        timeSeries26.removeAgedItems((long) (byte) 100, false);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) (byte) 100);
//        int int33 = timeSeriesDataItem9.compareTo((java.lang.Object) fixedMillisecond19);
//        int int34 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        timeSeries1.clear();
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.next();
//        long long40 = year38.getLastMillisecond();
//        int int41 = year38.getYear();
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(4, year38);
//        timeSeries1.setKey((java.lang.Comparable) month42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day44, (java.lang.Number) (byte) 100);
//        boolean boolean48 = timeSeriesDataItem46.equals((java.lang.Object) (short) 10);
//        boolean boolean49 = timeSeriesDataItem46.isSelected();
//        java.lang.Object obj50 = timeSeriesDataItem46.clone();
//        timeSeries1.add(timeSeriesDataItem46, false);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent53 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries1);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries56 = timeSeries1.createCopy(4, (int) '#');
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560182400743L + "'", long22 == 1560182400743L);
//        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list28);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-62104204800001L) + "'", long40 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(obj50);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((int) (byte) 1, 9999);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long15 = timeSeries14.getMaximumItemAge();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) (byte) 100);
        boolean boolean20 = timeSeriesDataItem18.equals((java.lang.Object) (short) 10);
        boolean boolean21 = timeSeriesDataItem18.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries14.addOrUpdate(timeSeriesDataItem18);
        java.util.Collection collection23 = timeSeries14.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries10.addAndOrUpdate(timeSeries14);
        int int25 = timeSeries24.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double30 = timeSeries29.getMaxY();
        java.util.List list31 = timeSeries29.getItems();
        timeSeries29.removeAgedItems((long) (byte) 100, false);
        java.util.List list35 = timeSeries29.getItems();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double40 = timeSeries39.getMaxY();
        int int41 = timeSeries39.getItemCount();
        timeSeries39.setMaximumItemCount(1);
        boolean boolean44 = timeSeries29.equals((java.lang.Object) timeSeries39);
        java.util.Collection collection45 = timeSeries29.getTimePeriods();
        int int46 = timeSeries29.getItemCount();
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries48.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day51, (java.lang.Number) (byte) 100);
        timeSeries48.add((org.jfree.data.time.RegularTimePeriod) day51, (java.lang.Number) 9223372036854775807L);
        org.jfree.data.time.SerialDate serialDate56 = day51.getSerialDate();
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(serialDate56);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate56);
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(serialDate56);
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(serialDate56);
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(serialDate56);
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double66 = timeSeries65.getMaxY();
        java.util.List list67 = timeSeries65.getItems();
        timeSeries65.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries72 = timeSeries65.createCopy((int) (byte) 1, 9999);
        boolean boolean73 = day61.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day61);
        java.lang.Object obj75 = null;
        boolean boolean76 = day61.equals(obj75);
        timeSeries29.add((org.jfree.data.time.RegularTimePeriod) day61, (java.lang.Number) 1560182366349L);
        java.lang.Number number79 = null;
        try {
            timeSeries24.update((org.jfree.data.time.RegularTimePeriod) day61, number79);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2147483647 + "'", int25 == 2147483647);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(collection45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertEquals((double) double66, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list67);
        org.junit.Assert.assertNotNull(timeSeries72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test222");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
//        java.lang.String str4 = timeSeries3.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
//        java.lang.String str9 = timeSeries8.getDescription();
//        java.lang.String str10 = timeSeries8.getDomainDescription();
//        java.util.Collection collection11 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
//        timeSeries8.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getMiddleMillisecond(calendar15);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int19 = fixedMillisecond14.compareTo((java.lang.Object) "hi!");
//        java.util.Date date20 = fixedMillisecond14.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond22.previous();
//        timeSeries8.delete(regularTimePeriod23);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = null;
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries8.addOrUpdate(regularTimePeriod25, 0.0d);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560182400873L + "'", long16 == 1560182400873L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test223");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        java.util.List list8 = timeSeries3.getItems();
//        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
//        java.util.Date date16 = fixedMillisecond13.getTime();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date16);
//        java.util.TimeZone timeZone19 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date16, timeZone19);
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date16, timeZone21);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond23.getMiddleMillisecond(calendar24);
//        java.util.Date date26 = fixedMillisecond23.getTime();
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date26);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date26);
//        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date26);
//        java.util.TimeZone timeZone31 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date26, timeZone31);
//        java.lang.Class class33 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182401023L + "'", long15 == 1560182401023L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560182401026L + "'", long25 == 1560182401026L);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNotNull(class33);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        long long7 = timeSeries3.getMaximumItemAge();
        java.util.List list8 = timeSeries3.getItems();
        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
        try {
            timeSeries3.update(35, (java.lang.Number) 1560182380741L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries15.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day18, (double) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day18.next();
        timeSeries1.add(regularTimePeriod22, (double) 1560182340527L);
        timeSeries1.setKey((java.lang.Comparable) '4');
        java.lang.String str27 = timeSeries1.getRangeDescription();
        timeSeries1.clear();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo29 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries1, seriesChangeInfo29);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str27.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100, seriesChangeInfo1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo3);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        long long3 = month2.getFirstMillisecond();
        long long4 = month2.getFirstMillisecond();
        java.lang.String str5 = month2.toString();
        org.jfree.data.time.Year year6 = month2.getYear();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-58987929600000L) + "'", long3 == (-58987929600000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-58987929600000L) + "'", long4 == (-58987929600000L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "October 100" + "'", str5.equals("October 100"));
        org.junit.Assert.assertNotNull(year6);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.setNotify(false);
        boolean boolean8 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.createCopy((int) (byte) 0, 4);
        int int12 = timeSeries3.getItemCount();
        timeSeries3.setDescription("Mon Jun 10 08:59:32 PDT 2019");
        timeSeries3.setMaximumItemAge(1560182357336L);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(timeSeries11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate9);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate9);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate9);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate9);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double19 = timeSeries18.getMaxY();
//        java.util.List list20 = timeSeries18.getItems();
//        timeSeries18.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries18.createCopy((int) (byte) 1, 9999);
//        boolean boolean26 = day14.equals((java.lang.Object) (byte) 1);
//        int int27 = day14.getDayOfMonth();
//        boolean boolean29 = day14.equals((java.lang.Object) Double.NaN);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list20);
//        org.junit.Assert.assertNotNull(timeSeries25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries3.addChangeListener(seriesChangeListener16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day18, (java.lang.Number) (byte) 100);
        boolean boolean22 = timeSeriesDataItem20.equals((java.lang.Object) (short) 10);
        boolean boolean23 = timeSeriesDataItem20.isSelected();
        java.lang.Object obj24 = timeSeriesDataItem20.clone();
        boolean boolean25 = timeSeries3.equals(obj24);
        double double26 = timeSeries3.getMaxY();
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 10.0d + "'", double26 == 10.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        org.jfree.data.time.Year year5 = month2.getYear();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries7.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        int int10 = year5.compareTo((java.lang.Object) timeSeries7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year5.next();
        long long12 = year5.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.setNotify(false);
        java.lang.String str8 = timeSeries3.getDomainDescription();
        double double9 = timeSeries3.getMaxY();
        try {
            java.lang.Number number11 = timeSeries3.getValue((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        org.jfree.data.time.Year year5 = month2.getYear();
        java.lang.String str6 = year5.toString();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double11 = timeSeries10.getMaxY();
        java.util.List list12 = timeSeries10.getItems();
        timeSeries10.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries10.createCopy((int) (byte) 1, 9999);
        boolean boolean18 = year5.equals((java.lang.Object) timeSeries17);
        java.lang.String str19 = year5.toString();
        java.util.Calendar calendar20 = null;
        try {
            year5.peg(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test234");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        boolean boolean8 = fixedMillisecond0.equals((java.lang.Object) 1560182343140L);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond0.getFirstMillisecond(calendar9);
//        java.util.Calendar calendar11 = null;
//        long long12 = fixedMillisecond0.getFirstMillisecond(calendar11);
//        java.util.Date date13 = fixedMillisecond0.getStart();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182401665L + "'", long2 == 1560182401665L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560182401665L + "'", long10 == 1560182401665L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560182401665L + "'", long12 == 1560182401665L);
//        org.junit.Assert.assertNotNull(date13);
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3, seriesChangeInfo7);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = seriesChangeEvent8.getSummary();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(seriesChangeInfo9);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        timeSeries3.setRangeDescription("");
        boolean boolean8 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double13 = timeSeries12.getMaxY();
        java.util.List list14 = timeSeries12.getItems();
        timeSeries12.removeAgedItems((long) (byte) 100, false);
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.addAndOrUpdate(timeSeries12);
        try {
            org.jfree.data.time.TimeSeries timeSeries21 = timeSeries3.createCopy((int) (short) 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(timeSeries18);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        long long7 = timeSeries3.getMaximumItemAge();
        java.lang.String str8 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj12 = null;
        int int13 = month11.compareTo(obj12);
        java.util.Date date14 = month11.getEnd();
        int int16 = month11.compareTo((java.lang.Object) 1560182345060L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month11.next();
        org.jfree.data.time.Year year18 = month11.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 1560182352795L);
        long long21 = year18.getFirstMillisecond();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-59011603200000L) + "'", long21 == (-59011603200000L));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
        java.lang.String str9 = timeSeries3.getDescription();
        double double10 = timeSeries3.getMinY();
        timeSeries3.setDomainDescription("Mon Jun 10 08:59:13 PDT 2019");
        java.lang.String str13 = timeSeries3.getRangeDescription();
        java.lang.String str14 = timeSeries3.getDomainDescription();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 6.0d + "'", double10 == 6.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Mon Jun 10 08:59:13 PDT 2019" + "'", str14.equals("Mon Jun 10 08:59:13 PDT 2019"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("0");
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test240");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        timeSeries1.fireSeriesChanged();
//        timeSeries1.setDescription("Mon Jun 10 08:59:09 PDT 2019");
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener12);
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
//        long long17 = year15.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries19.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) (byte) 100);
//        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) day22, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getMiddleMillisecond(calendar28);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException31 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int32 = fixedMillisecond27.compareTo((java.lang.Object) "hi!");
//        long long33 = fixedMillisecond27.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = fixedMillisecond27.next();
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double39 = timeSeries38.getMaxY();
//        int int40 = timeSeries38.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries38.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (double) 6);
//        long long44 = fixedMillisecond41.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = fixedMillisecond41.previous();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries19.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond41);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener47 = null;
//        timeSeries46.addChangeListener(seriesChangeListener47);
//        int int49 = timeSeries46.getMaximumItemCount();
//        int int50 = year15.compareTo((java.lang.Object) timeSeries46);
//        java.beans.PropertyChangeListener propertyChangeListener51 = null;
//        timeSeries46.removePropertyChangeListener(propertyChangeListener51);
//        java.util.Collection collection53 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries46);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-62104204800001L) + "'", long17 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560182401871L + "'", long29 == 1560182401871L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560182401871L + "'", long33 == 1560182401871L);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560182401873L + "'", long44 == 1560182401873L);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2147483647 + "'", int49 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
//        org.junit.Assert.assertNotNull(collection53);
//    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test241");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date6);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date6);
//        java.lang.Object obj11 = null;
//        boolean boolean12 = day10.equals(obj11);
//        java.util.Calendar calendar13 = null;
//        try {
//            day10.peg(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182402125L + "'", long2 == 1560182402125L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test242");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.List list5 = timeSeries3.getItems();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, (java.lang.Number) (byte) 100);
//        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) (short) 10);
//        timeSeries3.add(timeSeriesDataItem8);
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener12);
//        timeSeries3.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getMiddleMillisecond(calendar17);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int21 = fixedMillisecond16.compareTo((java.lang.Object) "hi!");
//        java.util.Date date22 = fixedMillisecond16.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond16.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond16.next();
//        java.lang.String str25 = fixedMillisecond16.toString();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) 1560182375196L);
//        int int29 = fixedMillisecond16.compareTo((java.lang.Object) 1560182363809L);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list5);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560182402139L + "'", long18 == 1560182402139L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Mon Jun 10 09:00:02 PDT 2019" + "'", str25.equals("Mon Jun 10 09:00:02 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test243");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        timeSeries3.removeAgedItems((long) 10, false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener8);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        int int13 = month12.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.next();
//        timeSeries3.add(regularTimePeriod14, (double) 1560182345775L, false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        long long19 = fixedMillisecond18.getLastMillisecond();
//        java.util.Calendar calendar20 = null;
//        fixedMillisecond18.peg(calendar20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int27 = fixedMillisecond22.compareTo((java.lang.Object) "hi!");
//        java.util.Date date28 = fixedMillisecond22.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        java.lang.Object obj31 = timeSeries30.clone();
//        java.util.Collection collection32 = timeSeries30.getTimePeriods();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560182402311L + "'", long19 == 1560182402311L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560182402311L + "'", long24 == 1560182402311L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertNotNull(obj31);
//        org.junit.Assert.assertNotNull(collection32);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (java.lang.Number) 1546329600000L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.next();
        org.jfree.data.time.Year year7 = month2.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.next();
        long long9 = month2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-58987929600000L) + "'", long3 == (-58987929600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(year7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-58987929600000L) + "'", long9 == (-58987929600000L));
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar2 = null;
//        fixedMillisecond0.peg(calendar2);
//        java.lang.Number number4 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, number4);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182402427L + "'", long1 == 1560182402427L);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1560182345230L);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo2 = seriesChangeEvent1.getSummary();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertNull(seriesChangeInfo2);
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 1560182345230L + "'", obj3.equals(1560182345230L));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + 1560182345230L + "'", obj4.equals(1560182345230L));
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test248");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate5);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182402449L + "'", long2 == 1560182402449L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test249");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        java.util.TimeZone timeZone4 = null;
//        try {
//            org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182402473L + "'", long2 == 1560182402473L);
//        org.junit.Assert.assertNotNull(date3);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str13 = timeSeries12.getDescription();
        java.util.Collection collection14 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        timeSeries12.setMaximumItemAge(1560182348409L);
        java.lang.String str17 = timeSeries12.getDomainDescription();
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo13 = seriesChangeEvent12.getSummary();
        java.lang.Object obj14 = seriesChangeEvent12.getSource();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(seriesChangeInfo13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        timeSeriesDataItem7.setValue((java.lang.Number) 1560182373716L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.previous();
        long long10 = month6.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month6.previous();
        long long12 = month6.getFirstMillisecond();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-58987929600000L) + "'", long10 == (-58987929600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-58987929600000L) + "'", long12 == (-58987929600000L));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        timeSeries3.removeAgedItems((long) 10, false);
        boolean boolean8 = timeSeries3.isEmpty();
        boolean boolean9 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries3.removeChangeListener(seriesChangeListener10);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Mon Jun 10 09:00:02 PDT 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        java.util.Date date5 = month2.getEnd();
        java.util.Date date6 = month2.getStart();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj9 = null;
        int int10 = month8.compareTo(obj9);
        org.jfree.data.time.Year year11 = month8.getYear();
        java.lang.String str12 = year11.toString();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double17 = timeSeries16.getMaxY();
        java.util.List list18 = timeSeries16.getItems();
        timeSeries16.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries16.createCopy((int) (byte) 1, 9999);
        boolean boolean24 = year11.equals((java.lang.Object) timeSeries23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year11.next();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year11, (double) 1560182376166L);
        long long28 = year11.getFirstMillisecond();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100" + "'", str12.equals("100"));
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-59011603200000L) + "'", long28 == (-59011603200000L));
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test258");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.List list5 = timeSeries3.getItems();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, (java.lang.Number) (byte) 100);
//        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) (short) 10);
//        timeSeries3.add(timeSeriesDataItem8);
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener12);
//        timeSeries3.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getMiddleMillisecond(calendar17);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int21 = fixedMillisecond16.compareTo((java.lang.Object) "hi!");
//        java.util.Date date22 = fixedMillisecond16.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond16.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond16.next();
//        java.lang.String str25 = fixedMillisecond16.toString();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) 1560182375196L);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener30 = null;
//        timeSeries29.addChangeListener(seriesChangeListener30);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        boolean boolean34 = timeSeries29.equals((java.lang.Object) timePeriodFormatException33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) (byte) 100);
//        boolean boolean39 = timeSeriesDataItem37.equals((java.lang.Object) (short) 10);
//        boolean boolean40 = timeSeriesDataItem37.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double45 = timeSeries44.getMaxY();
//        int int46 = timeSeries44.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries44.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) 6);
//        long long50 = fixedMillisecond47.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double55 = timeSeries54.getMaxY();
//        java.util.List list56 = timeSeries54.getItems();
//        timeSeries54.removeAgedItems((long) (byte) 100, false);
//        boolean boolean60 = fixedMillisecond47.equals((java.lang.Object) (byte) 100);
//        int int61 = timeSeriesDataItem37.compareTo((java.lang.Object) fixedMillisecond47);
//        int int62 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
//        timeSeries29.clear();
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = year66.next();
//        long long68 = year66.getLastMillisecond();
//        int int69 = year66.getYear();
//        org.jfree.data.time.Month month70 = new org.jfree.data.time.Month(4, year66);
//        timeSeries29.setKey((java.lang.Comparable) month70);
//        boolean boolean72 = fixedMillisecond16.equals((java.lang.Object) month70);
//        java.util.Calendar calendar73 = null;
//        long long74 = fixedMillisecond16.getLastMillisecond(calendar73);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list5);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560182402826L + "'", long18 == 1560182402826L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Mon Jun 10 09:00:02 PDT 2019" + "'", str25.equals("Mon Jun 10 09:00:02 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560182402835L + "'", long50 == 1560182402835L);
//        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list56);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-62104204800001L) + "'", long68 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 1560182402826L + "'", long74 == 1560182402826L);
//    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test259");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, "Mon Jun 10 08:59:05 PDT 2019", "10-June-2019");
//        java.lang.String str17 = day8.toString();
//        java.util.Date date18 = day8.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day8.next();
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10-June-2019" + "'", str17.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str9 = timeSeries8.getDescription();
        java.lang.String str10 = timeSeries8.getDomainDescription();
        java.util.Collection collection11 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        java.lang.Comparable comparable12 = timeSeries3.getKey();
        boolean boolean13 = timeSeries3.getNotify();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertTrue("'" + comparable12 + "' != '" + 0.0f + "'", comparable12.equals(0.0f));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test261");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        long long9 = fixedMillisecond6.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double14 = timeSeries13.getMaxY();
//        java.util.List list15 = timeSeries13.getItems();
//        timeSeries13.removeAgedItems((long) (byte) 100, false);
//        boolean boolean19 = fixedMillisecond6.equals((java.lang.Object) (byte) 100);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        long long24 = timeSeries23.getMaximumItemAge();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day25, (java.lang.Number) (byte) 100);
//        boolean boolean29 = timeSeriesDataItem27.equals((java.lang.Object) (short) 10);
//        boolean boolean30 = timeSeriesDataItem27.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries23.addOrUpdate(timeSeriesDataItem27);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries33.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month38, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month38.next();
//        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) month38);
//        boolean boolean43 = fixedMillisecond6.equals((java.lang.Object) month38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month38.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = month38.previous();
//        java.lang.String str46 = month38.toString();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182403472L + "'", long9 == 1560182403472L);
//        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list15);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "October 100" + "'", str46.equals("October 100"));
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        long long3 = year1.getLastMillisecond();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year1.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-62104204800001L) + "'", long3 == (-62104204800001L));
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test263");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
//        java.lang.String str4 = timeSeries3.getDescription();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries9.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day12.previous();
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day12, (double) 6);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day16.previous();
//        int int18 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) day16);
//        long long19 = day16.getSerialIndex();
//        int int20 = day16.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) day16);
//        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        int int25 = month24.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month24.next();
//        long long27 = month24.getFirstMillisecond();
//        java.util.Date date28 = month24.getEnd();
//        org.jfree.data.time.Year year29 = month24.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year29, (double) 1560182396624L);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 43626L + "'", long19 == 43626L);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-58987929600000L) + "'", long27 == (-58987929600000L));
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(year29);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.Object obj13 = seriesChangeEvent12.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo14 = null;
        seriesChangeEvent12.setSummary(seriesChangeInfo14);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean6 = timeSeries1.equals((java.lang.Object) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.general.SeriesException seriesException11 = new org.jfree.data.general.SeriesException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) seriesException11);
        java.lang.Throwable[] throwableArray13 = seriesException11.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        seriesException11.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        java.lang.Throwable[] throwableArray17 = seriesException11.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray17);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("11-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test267");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        java.util.List list8 = timeSeries3.getItems();
//        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double16 = timeSeries15.getMaxY();
//        int int17 = timeSeries15.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 6);
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond18.getMiddleMillisecond(calendar21);
//        java.util.Calendar calendar23 = null;
//        fixedMillisecond18.peg(calendar23);
//        java.util.Date date25 = fixedMillisecond18.getTime();
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
//        java.util.TimeZone timeZone27 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date25, timeZone27);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560182403778L + "'", long22 == 1560182403778L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.setNotify(false);
        boolean boolean8 = timeSeries3.getNotify();
        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.createCopy((int) (byte) 0, 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = null;
        try {
            java.lang.Number number13 = timeSeries3.getValue(regularTimePeriod12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(timeSeries11);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test269");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.addChangeListener(seriesChangeListener8);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener10);
//        timeSeries3.setRangeDescription("org.jfree.data.general.SeriesException: ");
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries15.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day18, (java.lang.Number) (byte) 100);
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day18, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate23 = day18.getSerialDate();
//        java.lang.String str24 = day18.toString();
//        java.lang.String str25 = day18.toString();
//        java.lang.String str26 = day18.toString();
//        boolean boolean28 = day18.equals((java.lang.Object) 9999);
//        try {
//            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) day18, (java.lang.Number) 9223372036854775807L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10-June-2019" + "'", str24.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "10-June-2019" + "'", str25.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "10-June-2019" + "'", str26.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        java.lang.Comparable comparable14 = timeSeries1.getKey();
        long long15 = timeSeries1.getMaximumItemAge();
        timeSeries1.fireSeriesChanged();
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 9 + "'", comparable14.equals(9));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1560182345230L);
        java.lang.String str2 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1560182345230]" + "'", str2.equals("org.jfree.data.event.SeriesChangeEvent[source=1560182345230]"));
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test272");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        timeSeries3.setRangeDescription("");
//        boolean boolean8 = timeSeries3.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        java.util.Date date12 = fixedMillisecond9.getTime();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date12);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date12);
//        int int16 = month15.getYearValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) 10.0f);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) 1560182382470L);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182404821L + "'", long11 == 1560182404821L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test273");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond0.peg(calendar4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond0.next();
//        long long7 = fixedMillisecond0.getSerialIndex();
//        long long8 = fixedMillisecond0.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182404890L + "'", long2 == 1560182404890L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560182404890L + "'", long7 == 1560182404890L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560182404890L + "'", long8 == 1560182404890L);
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate9);
        java.util.Calendar calendar15 = null;
        try {
            long long16 = day14.getFirstMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries13.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.Year year23 = month18.getYear();
        long long24 = year23.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-58979980800001L) + "'", long24 == (-58979980800001L));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.removeAgedItems((long) (byte) 100, false);
        java.lang.Comparable comparable9 = timeSeries3.getKey();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj13 = null;
        int int14 = month12.compareTo(obj13);
        java.util.Date date15 = month12.getEnd();
        java.util.Date date16 = month12.getStart();
        boolean boolean17 = timeSeries3.equals((java.lang.Object) date16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 1560193199999L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 1560182368328L);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + 10.0d + "'", comparable9.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
    }

//    @Test
//    public void test278() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test278");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        long long15 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double21 = timeSeries20.getMaxY();
//        int int22 = timeSeries20.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 6);
//        long long26 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond23.previous();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
//        timeSeries28.addChangeListener(seriesChangeListener29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day31, (java.lang.Number) (byte) 100);
//        boolean boolean35 = timeSeriesDataItem33.equals((java.lang.Object) (short) 10);
//        timeSeriesDataItem33.setSelected(false);
//        int int39 = timeSeriesDataItem33.compareTo((java.lang.Object) 1560182341157L);
//        java.lang.Number number40 = timeSeriesDataItem33.getValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries28.addOrUpdate(timeSeriesDataItem33);
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        long long45 = month44.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month44, (java.lang.Number) 1546329600000L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month44.next();
//        org.jfree.data.time.Year year49 = month44.getYear();
//        timeSeries28.setKey((java.lang.Comparable) year49);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182405165L + "'", long11 == 1560182405165L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182405165L + "'", long15 == 1560182405165L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182405167L + "'", long26 == 1560182405167L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + number40 + "' != '" + (byte) 100 + "'", number40.equals((byte) 100));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-58987929600000L) + "'", long45 == (-58987929600000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(year49);
//    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries3.addChangeListener(seriesChangeListener16);
        java.util.Collection collection18 = timeSeries3.getTimePeriods();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) collection18);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo20 = seriesChangeEvent19.getSummary();
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertNull(seriesChangeInfo20);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        long long3 = month2.getFirstMillisecond();
        long long4 = month2.getFirstMillisecond();
        java.lang.String str5 = month2.toString();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-58987929600000L) + "'", long3 == (-58987929600000L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-58987929600000L) + "'", long4 == (-58987929600000L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "October 100" + "'", str5.equals("October 100"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) ' ', 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test283");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
//        long long14 = day8.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, (java.lang.Number) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day8.next();
//        org.jfree.data.time.SerialDate serialDate18 = day8.getSerialDate();
//        long long19 = day8.getMiddleMillisecond();
//        org.jfree.data.time.SerialDate serialDate20 = day8.getSerialDate();
//        long long21 = day8.getSerialIndex();
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560193199999L + "'", long19 == 1560193199999L);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43626L + "'", long21 == 43626L);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        int int3 = month2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        long long5 = month2.getSerialIndex();
        int int6 = month2.getMonth();
        long long7 = month2.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1210L + "'", long5 == 1210L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-58987929600000L) + "'", long7 == (-58987929600000L));
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test285");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
//        timeSeries1.addChangeListener(seriesChangeListener2);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        boolean boolean6 = timeSeries1.equals((java.lang.Object) timePeriodFormatException5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) (byte) 100);
//        boolean boolean11 = timeSeriesDataItem9.equals((java.lang.Object) (short) 10);
//        boolean boolean12 = timeSeriesDataItem9.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double17 = timeSeries16.getMaxY();
//        int int18 = timeSeries16.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 6);
//        long long22 = fixedMillisecond19.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double27 = timeSeries26.getMaxY();
//        java.util.List list28 = timeSeries26.getItems();
//        timeSeries26.removeAgedItems((long) (byte) 100, false);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) (byte) 100);
//        int int33 = timeSeriesDataItem9.compareTo((java.lang.Object) fixedMillisecond19);
//        int int34 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        timeSeries1.clear();
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.next();
//        long long40 = year38.getLastMillisecond();
//        int int41 = year38.getYear();
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(4, year38);
//        timeSeries1.setKey((java.lang.Comparable) month42);
//        org.jfree.data.time.Year year44 = month42.getYear();
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560182405606L + "'", long22 == 1560182405606L);
//        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list28);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-62104204800001L) + "'", long40 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertNotNull(year44);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        java.lang.Comparable comparable14 = timeSeries1.getKey();
        long long15 = timeSeries1.getMaximumItemAge();
        double double16 = timeSeries1.getMaxY();
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 9 + "'", comparable14.equals(9));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        java.util.List list14 = timeSeries1.getItems();
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(list14);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        int int6 = timeSeries3.getItemCount();
        boolean boolean7 = timeSeries3.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(1560182346836L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) 1560182367767L);
        boolean boolean14 = timeSeries3.isEmpty();
        try {
            timeSeries3.update(7, (java.lang.Number) 1560182371793L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182346836L + "'", long11 == 1560182346836L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        long long7 = timeSeries3.getMaximumItemAge();
        java.lang.String str8 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj12 = null;
        int int13 = month11.compareTo(obj12);
        java.util.Date date14 = month11.getEnd();
        int int16 = month11.compareTo((java.lang.Object) 1560182345060L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month11.next();
        org.jfree.data.time.Year year18 = month11.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year18, (java.lang.Number) 1560182352795L);
        timeSeries3.removeAgedItems(false);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test290");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond6.getMiddleMillisecond(calendar9);
//        java.util.Calendar calendar11 = null;
//        fixedMillisecond6.peg(calendar11);
//        java.util.Date date13 = fixedMillisecond6.getTime();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date13);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double20 = timeSeries19.getMaxY();
//        java.util.Collection collection21 = timeSeries19.getTimePeriods();
//        java.lang.String str22 = timeSeries19.getRangeDescription();
//        timeSeries19.setMaximumItemAge((long) 12);
//        timeSeries19.fireSeriesChanged();
//        timeSeries19.clear();
//        int int27 = month15.compareTo((java.lang.Object) timeSeries19);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560182405949L + "'", long10 == 1560182405949L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        timeSeries3.setMaximumItemAge((long) 12);
        boolean boolean9 = timeSeries3.isEmpty();
        timeSeries3.setDescription("Mon Jun 10 08:59:23 PDT 2019");
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        boolean boolean8 = timeSeriesDataItem6.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem6.setSelected(false);
        java.lang.Number number11 = timeSeriesDataItem6.getValue();
        timeSeries3.add(timeSeriesDataItem6, false);
        timeSeriesDataItem6.setSelected(true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (byte) 100 + "'", number11.equals((byte) 100));
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test293");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double7 = timeSeries6.getMaxY();
//        java.util.List list8 = timeSeries6.getItems();
//        timeSeries6.setNotify(false);
//        java.lang.String str11 = timeSeries6.getDomainDescription();
//        int int12 = day0.compareTo((java.lang.Object) timeSeries6);
//        java.util.Calendar calendar13 = null;
//        try {
//            long long14 = day0.getLastMillisecond(calendar13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test294");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        long long20 = day18.getFirstMillisecond();
//        int int21 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day18);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(0);
//        long long24 = year23.getSerialIndex();
//        long long25 = year23.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
//        java.lang.String str30 = timeSeries29.getDescription();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries29);
//        int int32 = year23.compareTo((java.lang.Object) seriesChangeEvent31);
//        int int33 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year23);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double38 = timeSeries37.getMaxY();
//        java.util.List list39 = timeSeries37.getItems();
//        timeSeries37.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries43.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day46, (java.lang.Number) (byte) 100);
//        timeSeries43.add((org.jfree.data.time.RegularTimePeriod) day46, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate51 = day46.getSerialDate();
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(serialDate51);
//        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) day53, (java.lang.Number) 1560182352596L, false);
//        int int57 = day53.getYear();
//        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj61 = null;
//        int int62 = month60.compareTo(obj61);
//        java.util.Date date63 = month60.getEnd();
//        int int65 = month60.compareTo((java.lang.Object) 1560182345060L);
//        java.lang.String str66 = month60.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = month60.previous();
//        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day53, regularTimePeriod67);
//        java.beans.PropertyChangeListener propertyChangeListener69 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener69);
//        timeSeries3.setNotify(false);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560150000000L + "'", long20 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNull(str30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertEquals((double) double38, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list39);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "October 100" + "'", str66.equals("October 100"));
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(timeSeries68);
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries13.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.Year year23 = month18.getYear();
        long long24 = month18.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double29 = timeSeries28.getMaxY();
        java.util.Collection collection30 = timeSeries28.getTimePeriods();
        timeSeries28.setRangeDescription("");
        boolean boolean33 = timeSeries28.getNotify();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(9, 6);
        java.lang.String str37 = month36.toString();
        int int38 = month36.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month36, 0.0d);
        int int41 = month18.compareTo((java.lang.Object) 0.0d);
        int int42 = month18.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = month18.next();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1210L + "'", long24 == 1210L);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "September 6" + "'", str37.equals("September 6"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 10 + "'", int42 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        java.lang.Object obj4 = timeSeries3.clone();
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        java.util.Date date5 = month2.getEnd();
        int int7 = month2.compareTo((java.lang.Object) 1560182345060L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.next();
        org.jfree.data.time.Year year9 = month2.getYear();
        long long10 = year9.getFirstMillisecond();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year9.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-59011603200000L) + "'", long10 == (-59011603200000L));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(35, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test299");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
//        java.lang.String str11 = day10.toString();
//        int int12 = day10.getDayOfMonth();
//        int int13 = day10.getYear();
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test300");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182406626L + "'", long2 == 1560182406626L);
//        org.junit.Assert.assertNotNull(date3);
//    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test301");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
//        timeSeries1.addChangeListener(seriesChangeListener2);
//        timeSeries1.removeAgedItems(1560182348434L, true);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) (byte) 100);
//        long long10 = day7.getSerialIndex();
//        int int11 = day7.getMonth();
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 1560182375602L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43626L + "'", long10 == 43626L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        timeSeries3.setDescription("");
        java.lang.String str7 = timeSeries3.getDomainDescription();
        java.lang.Comparable comparable8 = null;
        try {
            timeSeries3.setKey(comparable8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.Object obj6 = timeSeries3.clone();
        timeSeries3.setDescription("100");
        timeSeries3.clear();
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj6);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test304");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond0);
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries4.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day7.previous();
//        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day7, (double) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day7.next();
//        timeSeries2.add(regularTimePeriod11, (java.lang.Number) 1560182344001L);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj17 = null;
//        int int18 = month16.compareTo(obj17);
//        java.util.Date date19 = month16.getEnd();
//        int int21 = month16.compareTo((java.lang.Object) 1560182345060L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month16.next();
//        org.jfree.data.time.Year year23 = month16.getYear();
//        long long24 = year23.getFirstMillisecond();
//        timeSeries2.setKey((java.lang.Comparable) long24);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182406839L + "'", long1 == 1560182406839L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(year23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-59011603200000L) + "'", long24 == (-59011603200000L));
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.setNotify(false);
        java.lang.String str8 = timeSeries3.getDomainDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries3.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        long long7 = timeSeries3.getMaximumItemAge();
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(0);
        long long12 = year11.getSerialIndex();
        long long13 = year11.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries19.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month24, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month24.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries17.addOrUpdate(regularTimePeriod27, (double) (short) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener30 = null;
        timeSeries17.addChangeListener(seriesChangeListener30);
        java.util.Collection collection32 = timeSeries17.getTimePeriods();
        timeSeries17.setRangeDescription("");
        int int35 = year11.compareTo((java.lang.Object) timeSeries17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year11.previous();
        timeSeries3.add(regularTimePeriod36, (java.lang.Number) 1560182361360L);
        timeSeries3.setMaximumItemAge(1560182371699L);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test307");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        java.util.Calendar calendar2 = null;
//        fixedMillisecond0.peg(calendar2);
//        java.lang.String str4 = fixedMillisecond0.toString();
//        java.util.Date date5 = fixedMillisecond0.getTime();
//        java.util.TimeZone timeZone6 = null;
//        try {
//            org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182406996L + "'", long1 == 1560182406996L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Mon Jun 10 09:00:06 PDT 2019" + "'", str4.equals("Mon Jun 10 09:00:06 PDT 2019"));
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Mon Jun 10 08:59:25 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test309");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.addChangeListener(seriesChangeListener8);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond12.previous();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 1560182355429L, false);
//        long long18 = fixedMillisecond12.getMiddleMillisecond();
//        long long19 = fixedMillisecond12.getLastMillisecond();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560182407055L + "'", long13 == 1560182407055L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560182407055L + "'", long18 == 1560182407055L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560182407055L + "'", long19 == 1560182407055L);
//    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test310");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        long long20 = day18.getFirstMillisecond();
//        int int21 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day18);
//        long long22 = day18.getFirstMillisecond();
//        int int23 = day18.getMonth();
//        int int24 = day18.getYear();
//        java.util.Date date25 = day18.getEnd();
//        java.util.TimeZone timeZone26 = null;
//        try {
//            org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date25, timeZone26);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560150000000L + "'", long20 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560150000000L + "'", long22 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//        org.junit.Assert.assertNotNull(date25);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemCount((int) '#');
        timeSeries3.setDomainDescription("Mon Jun 10 08:59:36 PDT 2019");
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        org.jfree.data.time.Year year5 = month2.getYear();
        java.lang.Object obj6 = null;
        boolean boolean7 = year5.equals(obj6);
        long long8 = year5.getLastMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year5.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-58979980800001L) + "'", long8 == (-58979980800001L));
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test313");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        java.util.List list8 = timeSeries3.getItems();
//        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
//        java.util.Date date16 = fixedMillisecond13.getTime();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date16);
//        java.util.TimeZone timeZone19 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date16, timeZone19);
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date16, timeZone21);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date16);
//        java.util.TimeZone timeZone24 = null;
//        try {
//            org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date16, timeZone24);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182407127L + "'", long15 == 1560182407127L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test314");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
//        java.lang.String str10 = day4.toString();
//        int int11 = day4.getYear();
//        int int12 = day4.getMonth();
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.setNotify(false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.addChangeListener(seriesChangeListener8);
        timeSeries3.setDescription("hi!");
        try {
            timeSeries3.delete((-1), 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 1, 5, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test317");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
//        long long2 = year1.getSerialIndex();
//        long long3 = year1.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        long long5 = fixedMillisecond4.getMiddleMillisecond();
//        int int6 = year1.compareTo((java.lang.Object) fixedMillisecond4);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int6);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        long long12 = timeSeries11.getMaximumItemAge();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) (byte) 100);
//        boolean boolean17 = timeSeriesDataItem15.equals((java.lang.Object) (short) 10);
//        boolean boolean18 = timeSeriesDataItem15.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries11.addOrUpdate(timeSeriesDataItem15);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries21.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month26, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month26.next();
//        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) month26);
//        java.lang.String str31 = timeSeries11.getRangeDescription();
//        timeSeries11.removeAgedItems(1560182350391L, false);
//        java.util.Collection collection35 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries11);
//        java.lang.Comparable comparable36 = timeSeries11.getKey();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560182407195L + "'", long5 == 1560182407195L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
//        org.junit.Assert.assertNotNull(collection35);
//        org.junit.Assert.assertTrue("'" + comparable36 + "' != '" + 10.0d + "'", comparable36.equals(10.0d));
//    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test318");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        long long4 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
//        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
//        boolean boolean10 = timeSeriesDataItem7.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries13.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month18);
//        java.lang.String str23 = timeSeries3.getRangeDescription();
//        timeSeries3.setRangeDescription("");
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double30 = timeSeries29.getMaxY();
//        int int31 = timeSeries29.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries29.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (double) 6);
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond32.getMiddleMillisecond(calendar35);
//        java.util.Calendar calendar37 = null;
//        fixedMillisecond32.peg(calendar37);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 1560182353546L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries3.addOrUpdate(timeSeriesDataItem40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = timeSeries3.getNextTimePeriod();
//        try {
//            java.lang.Number number44 = timeSeries3.getValue((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
//        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560182407338L + "'", long36 == 1560182407338L);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.addChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean8 = timeSeries3.equals((java.lang.Object) timePeriodFormatException7);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException10 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) timePeriodFormatException10);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Throwable[] throwableArray13 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        java.lang.String str5 = timeSeries3.getDomainDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        timeSeries3.setRangeDescription("Mon Jun 10 08:59:05 PDT 2019");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries3.addChangeListener(seriesChangeListener10);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
        java.lang.String str9 = timeSeries3.getDescription();
        double double10 = timeSeries3.getMinY();
        java.lang.Object obj11 = timeSeries3.clone();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 6.0d + "'", double10 == 6.0d);
        org.junit.Assert.assertNotNull(obj11);
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test322");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.addChangeListener(seriesChangeListener8);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener10);
//        int int12 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
//        java.util.Date date16 = fixedMillisecond13.getTime();
//        java.util.Calendar calendar17 = null;
//        fixedMillisecond13.peg(calendar17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond13.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (double) 1.0f);
//        long long22 = timeSeries3.getMaximumItemAge();
//        try {
//            timeSeries3.delete((int) (byte) 100, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182407823L + "'", long15 == 1560182407823L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNull(timeSeriesDataItem21);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9223372036854775807L + "'", long22 == 9223372036854775807L);
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries13.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.Year year23 = month18.getYear();
        java.lang.String str24 = year23.toString();
        java.lang.String str25 = year23.toString();
        java.lang.String str26 = year23.toString();
        long long27 = year23.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "100" + "'", str24.equals("100"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "100" + "'", str25.equals("100"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "100" + "'", str26.equals("100"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-59011603200000L) + "'", long27 == (-59011603200000L));
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test324");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
//        long long14 = day8.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day8.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day8.next();
//        long long17 = regularTimePeriod16.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560279599999L + "'", long17 == 1560279599999L);
//    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test325");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        java.util.List list8 = timeSeries3.getItems();
//        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
//        java.util.Date date16 = fixedMillisecond13.getTime();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(date16);
//        java.util.TimeZone timeZone20 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date16, timeZone20);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertNotNull(class12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182407917L + "'", long15 == 1560182407917L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean6 = timeSeries1.equals((java.lang.Object) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test327");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        timeSeries3.removeAgedItems((long) 10, false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener8);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        int int13 = month12.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.next();
//        timeSeries3.add(regularTimePeriod14, (double) 1560182345775L, false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        long long19 = fixedMillisecond18.getLastMillisecond();
//        java.util.Calendar calendar20 = null;
//        fixedMillisecond18.peg(calendar20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int27 = fixedMillisecond22.compareTo((java.lang.Object) "hi!");
//        java.util.Date date28 = fixedMillisecond22.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        timeSeries30.setMaximumItemCount(7);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560182408053L + "'", long19 == 1560182408053L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560182408053L + "'", long24 == 1560182408053L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeSeries30);
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj4 = null;
        int int5 = month3.compareTo(obj4);
        org.jfree.data.time.Year year6 = month3.getYear();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(1, year6);
        org.jfree.data.time.Year year8 = month7.getYear();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(year8);
    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test329");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        long long9 = month8.getFirstMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month8);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month21.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries14.addOrUpdate(regularTimePeriod24, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
//        timeSeries14.addChangeListener(seriesChangeListener27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day29.previous();
//        long long31 = day29.getFirstMillisecond();
//        int int32 = timeSeries14.getIndex((org.jfree.data.time.RegularTimePeriod) day29);
//        long long33 = day29.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day29.previous();
//        timeSeries3.add(regularTimePeriod34, (double) 1560182341608L, false);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod34, "Mon Jun 10 08:59:09 PDT 2019", "org.jfree.data.time.TimePeriodFormatException: hi!");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond41.getMiddleMillisecond(calendar42);
//        java.util.Date date44 = fixedMillisecond41.getTime();
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond(date44);
//        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date44);
//        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) year47, (java.lang.Number) 1560182374632L);
//        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj53 = null;
//        int int54 = month52.compareTo(obj53);
//        org.jfree.data.time.Year year55 = month52.getYear();
//        java.lang.Object obj56 = null;
//        boolean boolean57 = year55.equals(obj56);
//        long long58 = year55.getLastMillisecond();
//        timeSeries40.add((org.jfree.data.time.RegularTimePeriod) year55, (double) 10, true);
//        try {
//            timeSeries40.delete(2019, 2, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-58987929600000L) + "'", long9 == (-58987929600000L));
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNull(timeSeriesDataItem26);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560150000000L + "'", long31 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560150000000L + "'", long33 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560182408626L + "'", long43 == 1560182408626L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
//        org.junit.Assert.assertNotNull(year55);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-58979980800001L) + "'", long58 == (-58979980800001L));
//    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test330");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
//        java.lang.String str4 = timeSeries3.getDescription();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 1560182355672L);
//        long long12 = fixedMillisecond8.getLastMillisecond();
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560182408646L + "'", long12 == 1560182408646L);
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException17 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.addChangeListener(seriesChangeListener20);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean24 = timeSeries19.equals((java.lang.Object) timePeriodFormatException23);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timePeriodFormatException23.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException26);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException30 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException17.addSuppressed((java.lang.Throwable) timePeriodFormatException30);
        boolean boolean32 = timeSeries3.equals((java.lang.Object) timePeriodFormatException30);
        java.lang.Object obj33 = timeSeries3.clone();
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(obj33);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560182385272L, "Mon Jun 10 08:59:41 PDT 2019", "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: hi!");
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test333");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        long long15 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double21 = timeSeries20.getMaxY();
//        int int22 = timeSeries20.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 6);
//        long long26 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond23.previous();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
//        timeSeries28.addChangeListener(seriesChangeListener29);
//        boolean boolean31 = timeSeries28.isEmpty();
//        timeSeries28.setMaximumItemCount((int) (short) 10);
//        java.lang.String str34 = timeSeries28.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182408873L + "'", long11 == 1560182408873L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182408873L + "'", long15 == 1560182408873L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182408878L + "'", long26 == 1560182408878L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str34.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560182367892L);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str9 = timeSeries8.getDescription();
        java.lang.String str10 = timeSeries8.getDomainDescription();
        java.util.Collection collection11 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
        timeSeries3.removeAgedItems((long) (-9999), true);
        java.lang.Class class15 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long20 = timeSeries19.getMaximumItemAge();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) (byte) 100);
        boolean boolean25 = timeSeriesDataItem23.equals((java.lang.Object) (short) 10);
        boolean boolean26 = timeSeriesDataItem23.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries19.addOrUpdate(timeSeriesDataItem23);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent28 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries19);
        java.util.List list29 = timeSeries19.getItems();
        java.util.Collection collection30 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries19.removeChangeListener(seriesChangeListener31);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(collection11);
        org.junit.Assert.assertNull(class15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNotNull(collection30);
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test336");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date6);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date6);
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date6);
//        java.util.TimeZone timeZone12 = null;
//        java.util.Locale locale13 = null;
//        try {
//            org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date6, timeZone12, locale13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182409401L + "'", long2 == 1560182409401L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double15 = timeSeries14.getMaxY();
        timeSeries14.removeAgedItems((long) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries14.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) (byte) 100);
        boolean boolean25 = timeSeriesDataItem23.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem23.setSelected(false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries14.addOrUpdate(timeSeriesDataItem23);
        java.lang.String str29 = timeSeries14.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries1.addAndOrUpdate(timeSeries14);
        int int31 = timeSeries14.getItemCount();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        long long35 = month34.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month34, (java.lang.Number) 1546329600000L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month34.next();
        boolean boolean39 = timeSeries14.equals((java.lang.Object) regularTimePeriod38);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-58987929600000L) + "'", long35 == (-58987929600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test338");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.addChangeListener(seriesChangeListener8);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond12.previous();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 1560182355429L, false);
//        long long18 = fixedMillisecond12.getMiddleMillisecond();
//        java.lang.String str19 = fixedMillisecond12.toString();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560182409494L + "'", long13 == 1560182409494L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560182409494L + "'", long18 == 1560182409494L);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Mon Jun 10 09:00:09 PDT 2019" + "'", str19.equals("Mon Jun 10 09:00:09 PDT 2019"));
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double19 = timeSeries18.getMaxY();
        java.util.List list20 = timeSeries18.getItems();
        timeSeries18.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries18.createCopy((int) (byte) 1, 9999);
        boolean boolean26 = day14.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day14);
        java.lang.Object obj28 = null;
        boolean boolean29 = day14.equals(obj28);
        java.util.Calendar calendar30 = null;
        try {
            day14.peg(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        int int6 = timeSeries3.getItemCount();
        boolean boolean7 = timeSeries3.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(1560182346836L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (double) 1560182367767L);
        long long14 = fixedMillisecond9.getLastMillisecond();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182346836L + "'", long11 == 1560182346836L);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560182346836L + "'", long14 == 1560182346836L);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getMaximumItemCount();
        timeSeries3.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean8 = timeSeries3.isEmpty();
        int int9 = timeSeries3.getItemCount();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double15 = timeSeries14.getMaxY();
        timeSeries14.removeAgedItems((long) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries14.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) (byte) 100);
        boolean boolean25 = timeSeriesDataItem23.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem23.setSelected(false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries14.addOrUpdate(timeSeriesDataItem23);
        java.lang.String str29 = timeSeries14.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries1.addAndOrUpdate(timeSeries14);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day31, (java.lang.Number) (byte) 100);
        boolean boolean35 = timeSeriesDataItem33.equals((java.lang.Object) (short) 10);
        boolean boolean36 = timeSeriesDataItem33.isSelected();
        java.lang.Object obj37 = timeSeriesDataItem33.clone();
        java.lang.Number number38 = null;
        timeSeriesDataItem33.setValue(number38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries30.addOrUpdate(timeSeriesDataItem33);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries30.addChangeListener(seriesChangeListener41);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(timeSeriesDataItem40);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        java.lang.Object obj6 = timeSeries3.clone();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) (byte) 100);
        boolean boolean11 = timeSeriesDataItem9.equals((java.lang.Object) (short) 10);
        boolean boolean12 = timeSeriesDataItem9.isSelected();
        java.lang.Object obj13 = timeSeriesDataItem9.clone();
        java.lang.Number number14 = null;
        timeSeriesDataItem9.setValue(number14);
        timeSeriesDataItem9.setSelected(true);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate(timeSeriesDataItem9);
        long long19 = timeSeries3.getMaximumItemAge();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeries3.getTimePeriod(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2147483647, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9223372036854775807L + "'", long19 == 9223372036854775807L);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test344");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
//        java.lang.String str4 = timeSeries3.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
//        java.lang.String str9 = timeSeries8.getDescription();
//        java.lang.String str10 = timeSeries8.getDomainDescription();
//        java.util.Collection collection11 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries8);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries17.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month22, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month22.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries15.addOrUpdate(regularTimePeriod25, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries15.addChangeListener(seriesChangeListener28);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 1560193199999L);
//        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond34.getMiddleMillisecond(calendar35);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException38 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int39 = fixedMillisecond34.compareTo((java.lang.Object) "hi!");
//        java.util.Date date40 = fixedMillisecond34.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = fixedMillisecond34.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries15.getDataItem(regularTimePeriod41);
//        timeSeries8.add(regularTimePeriod41, (java.lang.Number) 1560182385451L, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar47 = null;
//        long long48 = fixedMillisecond46.getMiddleMillisecond(calendar47);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException50 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int51 = fixedMillisecond46.compareTo((java.lang.Object) "hi!");
//        long long52 = fixedMillisecond46.getFirstMillisecond();
//        java.util.Calendar calendar53 = null;
//        fixedMillisecond46.peg(calendar53);
//        java.lang.Number number55 = timeSeries8.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46);
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertNull(timeSeriesDataItem24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560182410185L + "'", long36 == 1560182410185L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(timeSeriesDataItem42);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1560182410187L + "'", long48 == 1560182410187L);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560182410187L + "'", long52 == 1560182410187L);
//        org.junit.Assert.assertNull(number55);
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (byte) -1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        java.lang.String str5 = timeSeries3.getDomainDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        timeSeries3.setRangeDescription("Mon Jun 10 08:59:05 PDT 2019");
        java.util.Collection collection10 = timeSeries3.getTimePeriods();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(1560182349137L);
        timeSeries3.setKey((java.lang.Comparable) 1560182349137L);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNotNull(collection10);
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test347");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        long long20 = day18.getFirstMillisecond();
//        int int21 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day18);
//        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(0);
//        long long24 = year23.getSerialIndex();
//        long long25 = year23.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
//        java.lang.String str30 = timeSeries29.getDescription();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries29);
//        int int32 = year23.compareTo((java.lang.Object) seriesChangeEvent31);
//        int int33 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year23);
//        int int34 = year23.getYear();
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560150000000L + "'", long20 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNull(str30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test348");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond6.getMiddleMillisecond(calendar9);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double15 = timeSeries14.getMaxY();
//        int int16 = timeSeries14.getItemCount();
//        timeSeries14.setRangeDescription("October 100");
//        boolean boolean19 = fixedMillisecond6.equals((java.lang.Object) timeSeries14);
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond6.getMiddleMillisecond(calendar20);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560182410529L + "'", long10 == 1560182410529L);
//        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560182410529L + "'", long21 == 1560182410529L);
//    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test349");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (byte) 100);
//        boolean boolean4 = timeSeriesDataItem2.equals((java.lang.Object) (short) 10);
//        boolean boolean5 = timeSeriesDataItem2.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double10 = timeSeries9.getMaxY();
//        int int11 = timeSeries9.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 6);
//        long long15 = fixedMillisecond12.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double20 = timeSeries19.getMaxY();
//        java.util.List list21 = timeSeries19.getItems();
//        timeSeries19.removeAgedItems((long) (byte) 100, false);
//        boolean boolean25 = fixedMillisecond12.equals((java.lang.Object) (byte) 100);
//        int int26 = timeSeriesDataItem2.compareTo((java.lang.Object) fixedMillisecond12);
//        boolean boolean27 = timeSeriesDataItem2.isSelected();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182410562L + "'", long15 == 1560182410562L);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list21);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str8 = timeSeries7.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries7);
        java.lang.String str10 = seriesChangeEvent9.toString();
        boolean boolean11 = month2.equals((java.lang.Object) seriesChangeEvent9);
        long long12 = month2.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month2.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-58987929600000L) + "'", long3 == (-58987929600000L));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-58985251200001L) + "'", long12 == (-58985251200001L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getItemCount();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(0);
        long long8 = year7.getSerialIndex();
        int int9 = year7.getYear();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year7, (double) 1560182380410L);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        java.lang.Comparable comparable14 = timeSeries1.getKey();
        long long15 = timeSeries1.getMaximumItemAge();
        timeSeries1.clear();
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 9 + "'", comparable14.equals(9));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (byte) 100);
        boolean boolean4 = timeSeriesDataItem2.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem2.setValue((java.lang.Number) 9);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long11 = timeSeries10.getMaximumItemAge();
        boolean boolean12 = timeSeriesDataItem2.equals((java.lang.Object) timeSeries10);
        java.lang.Number number13 = timeSeriesDataItem2.getValue();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        long long17 = month16.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month16, (java.lang.Number) 1546329600000L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month16.next();
        java.lang.String str21 = regularTimePeriod20.toString();
        int int22 = timeSeriesDataItem2.compareTo((java.lang.Object) regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 9 + "'", number13.equals(9));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-58987929600000L) + "'", long17 == (-58987929600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "November 100" + "'", str21.equals("November 100"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries3.addChangeListener(seriesChangeListener16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) 1560193199999L);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        java.lang.String str22 = timeSeries3.getDescription();
        timeSeries3.setDescription("2019");
        org.junit.Assert.assertNull(timeSeriesDataItem12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertNull(str22);
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test355");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        java.util.List list8 = timeSeries3.getItems();
//        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond11.getMiddleMillisecond(calendar12);
//        java.util.Date date14 = fixedMillisecond11.getTime();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date14);
//        java.util.TimeZone timeZone17 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date14, timeZone17);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560182410847L + "'", long13 == 1560182410847L);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) (short) 100, seriesChangeInfo1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo3);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo5 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo5);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo7);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) seriesChangeEvent2);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        seriesChangeEvent9.setSummary(seriesChangeInfo10);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries15.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day18, (double) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day18.next();
        timeSeries1.add(regularTimePeriod22, (double) 1560182340527L);
        timeSeries1.setKey((java.lang.Comparable) '4');
        java.lang.String str27 = timeSeries1.getRangeDescription();
        timeSeries1.clear();
        java.lang.String str29 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str27.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str29.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj4 = null;
        int int5 = month3.compareTo(obj4);
        org.jfree.data.time.Year year6 = month3.getYear();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(1, year6);
        java.util.Date date8 = year6.getStart();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(date8);
    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test359");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        long long9 = fixedMillisecond6.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double14 = timeSeries13.getMaxY();
//        java.util.List list15 = timeSeries13.getItems();
//        timeSeries13.removeAgedItems((long) (byte) 100, false);
//        boolean boolean19 = fixedMillisecond6.equals((java.lang.Object) (byte) 100);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        long long24 = timeSeries23.getMaximumItemAge();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day25, (java.lang.Number) (byte) 100);
//        boolean boolean29 = timeSeriesDataItem27.equals((java.lang.Object) (short) 10);
//        boolean boolean30 = timeSeriesDataItem27.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries23.addOrUpdate(timeSeriesDataItem27);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries33.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month38, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = month38.next();
//        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) month38);
//        boolean boolean43 = fixedMillisecond6.equals((java.lang.Object) month38);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month38.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = month38.previous();
//        long long46 = month38.getSerialIndex();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182411026L + "'", long9 == 1560182411026L);
//        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list15);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9223372036854775807L + "'", long24 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertNull(timeSeriesDataItem40);
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1210L + "'", long46 == 1210L);
//    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        timeSeries1.removeAgedItems(false);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double15 = timeSeries14.getMaxY();
        timeSeries14.removeAgedItems((long) 10, false);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries14.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) (byte) 100);
        boolean boolean25 = timeSeriesDataItem23.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem23.setSelected(false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries14.addOrUpdate(timeSeriesDataItem23);
        java.lang.String str29 = timeSeries14.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries1.addAndOrUpdate(timeSeries14);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day31, (java.lang.Number) (byte) 100);
        boolean boolean35 = timeSeriesDataItem33.equals((java.lang.Object) (short) 10);
        boolean boolean36 = timeSeriesDataItem33.isSelected();
        java.lang.Object obj37 = timeSeriesDataItem33.clone();
        java.lang.Number number38 = null;
        timeSeriesDataItem33.setValue(number38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries30.addOrUpdate(timeSeriesDataItem33);
        java.lang.Number number41 = timeSeriesDataItem33.getValue();
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "hi!" + "'", str29.equals("hi!"));
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(obj37);
        org.junit.Assert.assertNotNull(timeSeriesDataItem40);
        org.junit.Assert.assertNull(number41);
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test361");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date3);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182411227L + "'", long2 == 1560182411227L);
//        org.junit.Assert.assertNotNull(date3);
//    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test362");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        java.util.List list8 = timeSeries3.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond9.previous();
//        long long16 = fixedMillisecond9.getLastMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int22 = fixedMillisecond17.compareTo((java.lang.Object) "hi!");
//        java.util.Date date23 = fixedMillisecond17.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond17.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond17.next();
//        java.lang.String str26 = fixedMillisecond17.toString();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = null;
//        try {
//            timeSeries3.delete(regularTimePeriod28);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182411277L + "'", long11 == 1560182411277L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560182411277L + "'", long16 == 1560182411277L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560182411278L + "'", long19 == 1560182411278L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Mon Jun 10 09:00:11 PDT 2019" + "'", str26.equals("Mon Jun 10 09:00:11 PDT 2019"));
//        org.junit.Assert.assertNotNull(timeSeries27);
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str13 = timeSeries12.getDescription();
        java.util.Collection collection14 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries12);
        int int15 = timeSeries1.getItemCount();
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test364");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj3 = null;
//        int int4 = month2.compareTo(obj3);
//        org.jfree.data.time.Year year5 = month2.getYear();
//        java.lang.String str6 = year5.toString();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double11 = timeSeries10.getMaxY();
//        java.util.List list12 = timeSeries10.getItems();
//        timeSeries10.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries10.createCopy((int) (byte) 1, 9999);
//        boolean boolean18 = year5.equals((java.lang.Object) timeSeries17);
//        java.lang.String str19 = year5.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar21 = null;
//        long long22 = fixedMillisecond20.getMiddleMillisecond(calendar21);
//        java.util.Date date23 = fixedMillisecond20.getTime();
//        java.util.Calendar calendar24 = null;
//        fixedMillisecond20.peg(calendar24);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond20.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond20.next();
//        int int28 = year5.compareTo((java.lang.Object) regularTimePeriod27);
//        long long29 = year5.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(year5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
//        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list12);
//        org.junit.Assert.assertNotNull(timeSeries17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "100" + "'", str19.equals("100"));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560182411322L + "'", long22 == 1560182411322L);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 100L + "'", long29 == 100L);
//    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        long long2 = year1.getSerialIndex();
        long long3 = year1.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries9.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month14.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries7.addOrUpdate(regularTimePeriod17, (double) (short) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries7.addChangeListener(seriesChangeListener20);
        java.util.Collection collection22 = timeSeries7.getTimePeriods();
        timeSeries7.setRangeDescription("");
        int int25 = year1.compareTo((java.lang.Object) timeSeries7);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries7);
        try {
            org.jfree.data.time.TimeSeries timeSeries29 = timeSeries7.createCopy((-1), 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries15.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day18, (double) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day18.next();
        timeSeries1.add(regularTimePeriod22, (double) 1560182340527L);
        timeSeries1.setKey((java.lang.Comparable) '4');
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries28.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day31, (java.lang.Number) (byte) 100);
        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) day31, (java.lang.Number) 9223372036854775807L);
        boolean boolean36 = timeSeries1.equals((java.lang.Object) timeSeries28);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test367");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (byte) 100);
//        boolean boolean4 = timeSeriesDataItem2.equals((java.lang.Object) (short) 10);
//        timeSeriesDataItem2.setValue((java.lang.Number) 9);
//        java.lang.Number number7 = timeSeriesDataItem2.getValue();
//        java.lang.Number number8 = timeSeriesDataItem2.getValue();
//        boolean boolean9 = timeSeriesDataItem2.isSelected();
//        java.lang.Object obj10 = null;
//        boolean boolean11 = timeSeriesDataItem2.equals(obj10);
//        boolean boolean12 = timeSeriesDataItem2.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries14.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (byte) 100);
//        timeSeries14.add((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int27 = fixedMillisecond22.compareTo((java.lang.Object) "hi!");
//        long long28 = fixedMillisecond22.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond22.next();
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double34 = timeSeries33.getMaxY();
//        int int35 = timeSeries33.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (double) 6);
//        long long39 = fixedMillisecond36.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = fixedMillisecond36.previous();
//        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries14.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond36);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener42 = null;
//        timeSeries41.addChangeListener(seriesChangeListener42);
//        timeSeries41.setMaximumItemAge(1560182353546L);
//        boolean boolean46 = timeSeriesDataItem2.equals((java.lang.Object) 1560182353546L);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 9 + "'", number7.equals(9));
//        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 9 + "'", number8.equals(9));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560182411514L + "'", long24 == 1560182411514L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560182411514L + "'", long28 == 1560182411514L);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560182411516L + "'", long39 == 1560182411516L);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(timeSeries41);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        double double4 = timeSeries1.getMaxY();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test369");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        java.util.List list8 = timeSeries3.getItems();
//        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond12.getMiddleMillisecond(calendar13);
//        java.util.Date date15 = fixedMillisecond12.getTime();
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date15);
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date15, timeZone18);
//        java.util.TimeZone timeZone20 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date15, timeZone20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int27 = fixedMillisecond22.compareTo((java.lang.Object) "hi!");
//        java.util.Date date28 = fixedMillisecond22.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date28);
//        java.util.TimeZone timeZone31 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date28, timeZone31);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond33.getMiddleMillisecond(calendar34);
//        java.util.Date date36 = fixedMillisecond33.getTime();
//        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date36);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date36);
//        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date36);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date36);
//        java.util.TimeZone timeZone41 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date36, timeZone41);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560182411635L + "'", long14 == 1560182411635L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560182411637L + "'", long24 == 1560182411637L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560182411638L + "'", long35 == 1560182411638L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        int int5 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test371");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        fixedMillisecond0.peg(calendar1);
//        java.lang.String str3 = fixedMillisecond0.toString();
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mon Jun 10 09:00:12 PDT 2019" + "'", str3.equals("Mon Jun 10 09:00:12 PDT 2019"));
//    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test372");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182412064L + "'", long2 == 1560182412064L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test373");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date3);
//        int int8 = year7.getYear();
//        long long9 = year7.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182412093L + "'", long2 == 1560182412093L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2019L + "'", long9 == 2019L);
//    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 1);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries13.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month18);
        java.lang.String str23 = month18.toString();
        org.jfree.data.time.Year year24 = month18.getYear();
        java.util.Calendar calendar25 = null;
        try {
            long long26 = month18.getFirstMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "October 100" + "'", str23.equals("October 100"));
        org.junit.Assert.assertNotNull(year24);
    }

//    @Test
//    public void test376() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test376");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate6 = day4.getSerialDate();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182412155L + "'", long2 == 1560182412155L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(6);
        java.lang.String str2 = year1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "6" + "'", str2.equals("6"));
    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test378");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar4 = null;
//        fixedMillisecond0.peg(calendar4);
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond0.getFirstMillisecond(calendar6);
//        long long8 = fixedMillisecond0.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond0.previous();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182412579L + "'", long2 == 1560182412579L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560182412579L + "'", long7 == 1560182412579L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560182412579L + "'", long8 == 1560182412579L);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
        java.lang.String str9 = timeSeries3.getDescription();
        timeSeries3.setDescription("");
        timeSeries3.fireSeriesChanged();
        boolean boolean13 = timeSeries3.getNotify();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        long long7 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, (java.lang.Number) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem10);
        timeSeries3.setDomainDescription("2019");
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test381");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond6.getMiddleMillisecond(calendar9);
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double15 = timeSeries14.getMaxY();
//        int int16 = timeSeries14.getItemCount();
//        timeSeries14.setRangeDescription("October 100");
//        boolean boolean19 = fixedMillisecond6.equals((java.lang.Object) timeSeries14);
//        boolean boolean21 = fixedMillisecond6.equals((java.lang.Object) 1);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560182412626L + "'", long10 == 1560182412626L);
//        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test382");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries15.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day18, (double) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day18.next();
//        timeSeries1.add(regularTimePeriod22, (double) 1560182340527L);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries26.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) (byte) 100);
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate34 = day29.getSerialDate();
//        java.lang.String str35 = day29.toString();
//        java.lang.String str36 = day29.toString();
//        java.lang.String str37 = day29.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day29.next();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day29);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "10-June-2019" + "'", str35.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "10-June-2019" + "'", str36.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "10-June-2019" + "'", str37.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries5.addChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean10 = timeSeries5.equals((java.lang.Object) timePeriodFormatException9);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        boolean boolean15 = year1.equals((java.lang.Object) timePeriodFormatException9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test384");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        java.util.Collection collection18 = timeSeries3.getTimePeriods();
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day19);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 1560193199999L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        java.util.Calendar calendar26 = null;
//        fixedMillisecond22.peg(calendar26);
//        long long28 = fixedMillisecond22.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(collection18);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560182412792L + "'", long28 == 1560182412792L);
//    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test385");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.List list5 = timeSeries3.getItems();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, (java.lang.Number) (byte) 100);
//        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) (short) 10);
//        timeSeries3.add(timeSeriesDataItem8);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
//        long long15 = year13.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries17.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day20, (java.lang.Number) (byte) 100);
//        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) day20, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond25.getMiddleMillisecond(calendar26);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int30 = fixedMillisecond25.compareTo((java.lang.Object) "hi!");
//        long long31 = fixedMillisecond25.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = fixedMillisecond25.next();
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double37 = timeSeries36.getMaxY();
//        int int38 = timeSeries36.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries36.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (double) 6);
//        long long42 = fixedMillisecond39.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = fixedMillisecond39.previous();
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries17.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond39);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener45 = null;
//        timeSeries44.addChangeListener(seriesChangeListener45);
//        int int47 = timeSeries44.getMaximumItemCount();
//        int int48 = year13.compareTo((java.lang.Object) timeSeries44);
//        java.lang.Object obj49 = timeSeries44.clone();
//        boolean boolean50 = timeSeriesDataItem8.equals((java.lang.Object) timeSeries44);
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double55 = timeSeries54.getMaxY();
//        java.util.Collection collection56 = timeSeries54.getTimePeriods();
//        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        long long60 = month59.getFirstMillisecond();
//        timeSeries54.delete((org.jfree.data.time.RegularTimePeriod) month59);
//        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries67.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month72 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries67.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month72, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = month72.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries65.addOrUpdate(regularTimePeriod75, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener78 = null;
//        timeSeries65.addChangeListener(seriesChangeListener78);
//        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = day80.previous();
//        long long82 = day80.getFirstMillisecond();
//        int int83 = timeSeries65.getIndex((org.jfree.data.time.RegularTimePeriod) day80);
//        long long84 = day80.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = day80.previous();
//        timeSeries54.add(regularTimePeriod85, (double) 1560182341608L, false);
//        org.jfree.data.time.TimeSeries timeSeries91 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod85, "Mon Jun 10 08:59:09 PDT 2019", "org.jfree.data.time.TimePeriodFormatException: hi!");
//        boolean boolean92 = timeSeriesDataItem8.equals((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: hi!");
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list5);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-62104204800001L) + "'", long15 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560182412884L + "'", long27 == 1560182412884L);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560182412884L + "'", long31 == 1560182412884L);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560182412887L + "'", long42 == 1560182412887L);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2147483647 + "'", int47 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertNotNull(obj49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection56);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-58987929600000L) + "'", long60 == (-58987929600000L));
//        org.junit.Assert.assertNull(timeSeriesDataItem74);
//        org.junit.Assert.assertNotNull(regularTimePeriod75);
//        org.junit.Assert.assertNull(timeSeriesDataItem77);
//        org.junit.Assert.assertNotNull(regularTimePeriod81);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 1560150000000L + "'", long82 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1560150000000L + "'", long84 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod85);
//        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
//    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test386");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
//        long long14 = day8.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, (java.lang.Number) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day8.next();
//        long long18 = day8.getFirstMillisecond();
//        int int19 = day8.getDayOfMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560150000000L + "'", long18 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        java.util.Date date5 = month2.getEnd();
        int int7 = month2.compareTo((java.lang.Object) 1560182345060L);
        java.lang.String str8 = month2.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month2.previous();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) regularTimePeriod9);
        java.lang.Object obj11 = seriesChangeEvent10.getSource();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "October 100" + "'", str8.equals("October 100"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        int int3 = month2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        long long5 = month2.getFirstMillisecond();
        java.util.Date date6 = month2.getEnd();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date6, "Mon Jun 10 08:59:23 PDT 2019", "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.event.SeriesChangeEvent[source=100]");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries9.getTimePeriod(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-58987929600000L) + "'", long5 == (-58987929600000L));
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test389");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
//        java.lang.String str4 = timeSeries3.getDescription();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
//        java.lang.Object obj6 = timeSeries3.clone();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) (byte) 100);
//        boolean boolean11 = timeSeriesDataItem9.equals((java.lang.Object) (short) 10);
//        boolean boolean12 = timeSeriesDataItem9.isSelected();
//        java.lang.Object obj13 = timeSeriesDataItem9.clone();
//        java.lang.Number number14 = null;
//        timeSeriesDataItem9.setValue(number14);
//        timeSeriesDataItem9.setSelected(true);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate(timeSeriesDataItem9);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries20.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) day23, (double) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day23.next();
//        long long28 = day23.getMiddleMillisecond();
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj33 = null;
//        int int34 = month32.compareTo(obj33);
//        org.jfree.data.time.Year year35 = month32.getYear();
//        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(1, year35);
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day23, (org.jfree.data.time.RegularTimePeriod) year35);
//        java.util.Calendar calendar38 = null;
//        try {
//            day23.peg(calendar38);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(str4);
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(obj13);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560193199999L + "'", long28 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertNotNull(year35);
//        org.junit.Assert.assertNotNull(timeSeries37);
//    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 1, (int) (byte) -1, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        timeSeries3.setRangeDescription("");
        boolean boolean8 = timeSeries3.getNotify();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(9, 6);
        java.lang.String str12 = month11.toString();
        int int13 = month11.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month11, 0.0d);
        long long16 = month11.getFirstMillisecond();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "September 6" + "'", str12.equals("September 6"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-61956979200000L) + "'", long16 == (-61956979200000L));
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test392");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date6);
//        long long10 = day9.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182414677L + "'", long2 == 1560182414677L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43626L + "'", long10 == 43626L);
//    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test393");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        long long4 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
//        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
//        boolean boolean10 = timeSeriesDataItem7.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries13.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month18);
//        java.lang.String str23 = timeSeries3.getRangeDescription();
//        timeSeries3.setRangeDescription("");
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double30 = timeSeries29.getMaxY();
//        int int31 = timeSeries29.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries29.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (double) 6);
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond32.getMiddleMillisecond(calendar35);
//        java.util.Calendar calendar37 = null;
//        fixedMillisecond32.peg(calendar37);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 1560182353546L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries3.addOrUpdate(timeSeriesDataItem40);
//        java.beans.PropertyChangeListener propertyChangeListener42 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener42);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
//        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560182414755L + "'", long36 == 1560182414755L);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test394");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        long long20 = day18.getFirstMillisecond();
//        int int21 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day18);
//        long long22 = day18.getFirstMillisecond();
//        int int23 = day18.getMonth();
//        int int24 = day18.getYear();
//        java.util.Date date25 = day18.getEnd();
//        java.util.Calendar calendar26 = null;
//        try {
//            long long27 = day18.getLastMillisecond(calendar26);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560150000000L + "'", long20 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560150000000L + "'", long22 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
//        org.junit.Assert.assertNotNull(date25);
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 6, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test396");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        long long2 = day0.getFirstMillisecond();
//        long long3 = day0.getSerialIndex();
//        int int4 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560150000000L + "'", long2 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test397");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener18);
//        timeSeries3.setDescription("Mon Jun 10 08:59:05 PDT 2019");
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries23.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day26, (java.lang.Number) (byte) 100);
//        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) day26, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate31 = day26.getSerialDate();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(serialDate31);
//        java.lang.String str33 = day32.toString();
//        java.lang.Number number34 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) day32);
//        boolean boolean35 = timeSeries3.isEmpty();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day36, (java.lang.Number) (byte) 100);
//        boolean boolean40 = timeSeriesDataItem38.equals((java.lang.Object) (short) 10);
//        boolean boolean41 = timeSeriesDataItem38.isSelected();
//        java.lang.Object obj42 = timeSeriesDataItem38.clone();
//        java.lang.Number number43 = null;
//        timeSeriesDataItem38.setValue(number43);
//        timeSeriesDataItem38.setSelected(true);
//        java.lang.Object obj47 = timeSeriesDataItem38.clone();
//        timeSeriesDataItem38.setSelected(true);
//        java.lang.Object obj50 = timeSeriesDataItem38.clone();
//        boolean boolean52 = timeSeriesDataItem38.equals((java.lang.Object) "Mon Jun 10 08:59:23 PDT 2019");
//        try {
//            timeSeries3.add(timeSeriesDataItem38, false);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "10-June-2019" + "'", str33.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 10.0d + "'", number34.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(obj42);
//        org.junit.Assert.assertNotNull(obj47);
//        org.junit.Assert.assertNotNull(obj50);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 1, (-2019));
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test399");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.List list5 = timeSeries3.getItems();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, (java.lang.Number) (byte) 100);
//        boolean boolean10 = timeSeriesDataItem8.equals((java.lang.Object) (short) 10);
//        timeSeries3.add(timeSeriesDataItem8);
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries3.addPropertyChangeListener(propertyChangeListener12);
//        timeSeries3.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getMiddleMillisecond(calendar17);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException20 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int21 = fixedMillisecond16.compareTo((java.lang.Object) "hi!");
//        java.util.Date date22 = fixedMillisecond16.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond16.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond16.next();
//        java.lang.String str25 = fixedMillisecond16.toString();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond16, (double) 1560182375196L);
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener30 = null;
//        timeSeries29.addChangeListener(seriesChangeListener30);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException33 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        boolean boolean34 = timeSeries29.equals((java.lang.Object) timePeriodFormatException33);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) (byte) 100);
//        boolean boolean39 = timeSeriesDataItem37.equals((java.lang.Object) (short) 10);
//        boolean boolean40 = timeSeriesDataItem37.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double45 = timeSeries44.getMaxY();
//        int int46 = timeSeries44.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries44.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (double) 6);
//        long long50 = fixedMillisecond47.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double55 = timeSeries54.getMaxY();
//        java.util.List list56 = timeSeries54.getItems();
//        timeSeries54.removeAgedItems((long) (byte) 100, false);
//        boolean boolean60 = fixedMillisecond47.equals((java.lang.Object) (byte) 100);
//        int int61 = timeSeriesDataItem37.compareTo((java.lang.Object) fixedMillisecond47);
//        int int62 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47);
//        timeSeries29.clear();
//        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = year66.next();
//        long long68 = year66.getLastMillisecond();
//        int int69 = year66.getYear();
//        org.jfree.data.time.Month month70 = new org.jfree.data.time.Month(4, year66);
//        timeSeries29.setKey((java.lang.Comparable) month70);
//        boolean boolean72 = fixedMillisecond16.equals((java.lang.Object) month70);
//        java.util.Calendar calendar73 = null;
//        long long74 = fixedMillisecond16.getFirstMillisecond(calendar73);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list5);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560182414933L + "'", long18 == 1560182414933L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Mon Jun 10 09:00:14 PDT 2019" + "'", str25.equals("Mon Jun 10 09:00:14 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1560182414936L + "'", long50 == 1560182414936L);
//        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list56);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod67);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-62104204800001L) + "'", long68 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 1560182414933L + "'", long74 == 1560182414933L);
//    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test400");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate9);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate9);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate9);
//        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(9, 6);
//        java.lang.String str17 = month16.toString();
//        int int18 = day13.compareTo((java.lang.Object) str17);
//        long long19 = day13.getMiddleMillisecond();
//        java.util.Calendar calendar20 = null;
//        try {
//            long long21 = day13.getLastMillisecond(calendar20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "September 6" + "'", str17.equals("September 6"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560193199999L + "'", long19 == 1560193199999L);
//    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test401");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
//        timeSeries1.addChangeListener(seriesChangeListener2);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        boolean boolean6 = timeSeries1.equals((java.lang.Object) timePeriodFormatException5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) (byte) 100);
//        boolean boolean11 = timeSeriesDataItem9.equals((java.lang.Object) (short) 10);
//        boolean boolean12 = timeSeriesDataItem9.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double17 = timeSeries16.getMaxY();
//        int int18 = timeSeries16.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (double) 6);
//        long long22 = fixedMillisecond19.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double27 = timeSeries26.getMaxY();
//        java.util.List list28 = timeSeries26.getItems();
//        timeSeries26.removeAgedItems((long) (byte) 100, false);
//        boolean boolean32 = fixedMillisecond19.equals((java.lang.Object) (byte) 100);
//        int int33 = timeSeriesDataItem9.compareTo((java.lang.Object) fixedMillisecond19);
//        int int34 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19);
//        timeSeries1.clear();
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.next();
//        long long40 = year38.getLastMillisecond();
//        int int41 = year38.getYear();
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(4, year38);
//        timeSeries1.setKey((java.lang.Comparable) month42);
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day44, (java.lang.Number) (byte) 100);
//        boolean boolean48 = timeSeriesDataItem46.equals((java.lang.Object) (short) 10);
//        boolean boolean49 = timeSeriesDataItem46.isSelected();
//        java.lang.Object obj50 = timeSeriesDataItem46.clone();
//        timeSeries1.add(timeSeriesDataItem46, false);
//        java.beans.PropertyChangeListener propertyChangeListener53 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener53);
//        java.beans.PropertyChangeListener propertyChangeListener55 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener55);
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double61 = timeSeries60.getMaxY();
//        java.util.Collection collection62 = timeSeries60.getTimePeriods();
//        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        long long66 = month65.getFirstMillisecond();
//        timeSeries60.delete((org.jfree.data.time.RegularTimePeriod) month65);
//        int int68 = timeSeries1.getIndex((org.jfree.data.time.RegularTimePeriod) month65);
//        int int69 = month65.getMonth();
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560182415229L + "'", long22 == 1560182415229L);
//        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list28);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-62104204800001L) + "'", long40 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(obj50);
//        org.junit.Assert.assertEquals((double) double61, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection62);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-58987929600000L) + "'", long66 == (-58987929600000L));
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 10 + "'", int69 == 10);
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getItemCount();
        timeSeries3.setRangeDescription("October 100");
        timeSeries3.setNotify(true);
        double double10 = timeSeries3.getMinY();
        timeSeries3.setMaximumItemCount(10);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test403");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
//        int int8 = month7.getYearValue();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.lang.String str10 = day9.toString();
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj14 = null;
//        int int15 = month13.compareTo(obj14);
//        java.util.Date date16 = month13.getEnd();
//        int int17 = day9.compareTo((java.lang.Object) month13);
//        org.jfree.data.time.Year year18 = month13.getYear();
//        int int20 = month13.compareTo((java.lang.Object) 1560182362032L);
//        boolean boolean21 = month7.equals((java.lang.Object) 1560182362032L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182415500L + "'", long2 == 1560182415500L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(year18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 6);
        java.lang.String str3 = month2.toString();
        int int4 = month2.getYearValue();
        long long5 = month2.getFirstMillisecond();
        long long6 = month2.getFirstMillisecond();
        java.util.Calendar calendar7 = null;
        try {
            month2.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "September 6" + "'", str3.equals("September 6"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-61956979200000L) + "'", long5 == (-61956979200000L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61956979200000L) + "'", long6 == (-61956979200000L));
    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test405");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.previous();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double12 = timeSeries11.getMaxY();
//        java.util.List list13 = timeSeries11.getItems();
//        int int14 = timeSeries11.getItemCount();
//        boolean boolean15 = fixedMillisecond0.equals((java.lang.Object) timeSeries11);
//        java.lang.Class class16 = timeSeries11.getTimePeriodClass();
//        timeSeries11.setNotify(false);
//        int int19 = timeSeries11.getMaximumItemCount();
//        java.util.List list20 = timeSeries11.getItems();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182415560L + "'", long2 == 1560182415560L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNull(class16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2147483647 + "'", int19 == 2147483647);
//        org.junit.Assert.assertNotNull(list20);
//    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test406");
//        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
//        long long2 = year1.getSerialIndex();
//        long long3 = year1.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        long long5 = fixedMillisecond4.getMiddleMillisecond();
//        int int6 = year1.compareTo((java.lang.Object) fixedMillisecond4);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int6);
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        long long12 = timeSeries11.getMaximumItemAge();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) (byte) 100);
//        boolean boolean17 = timeSeriesDataItem15.equals((java.lang.Object) (short) 10);
//        boolean boolean18 = timeSeriesDataItem15.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries11.addOrUpdate(timeSeriesDataItem15);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries21.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries21.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month26, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month26.next();
//        timeSeries11.delete((org.jfree.data.time.RegularTimePeriod) month26);
//        java.lang.String str31 = timeSeries11.getRangeDescription();
//        timeSeries11.removeAgedItems(1560182350391L, false);
//        java.util.Collection collection35 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries11);
//        try {
//            java.lang.Number number37 = timeSeries7.getValue((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560182415662L + "'", long5 == 1560182415662L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 9223372036854775807L + "'", long12 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
//        org.junit.Assert.assertNotNull(collection35);
//    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test407");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.addChangeListener(seriesChangeListener8);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond12.previous();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 1560182355429L, false);
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond12.getMiddleMillisecond(calendar18);
//        java.util.Calendar calendar20 = null;
//        long long21 = fixedMillisecond12.getFirstMillisecond(calendar20);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560182415681L + "'", long13 == 1560182415681L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560182415681L + "'", long19 == 1560182415681L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560182415681L + "'", long21 == 1560182415681L);
//    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test408");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener18);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double24 = timeSeries23.getMaxY();
//        java.util.List list25 = timeSeries23.getItems();
//        timeSeries23.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries23.createCopy((int) (byte) 1, 9999);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        long long35 = timeSeries34.getMaximumItemAge();
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day36, (java.lang.Number) (byte) 100);
//        boolean boolean40 = timeSeriesDataItem38.equals((java.lang.Object) (short) 10);
//        boolean boolean41 = timeSeriesDataItem38.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries34.addOrUpdate(timeSeriesDataItem38);
//        java.util.Collection collection43 = timeSeries34.getTimePeriods();
//        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries30.addAndOrUpdate(timeSeries34);
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries46.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day49, (java.lang.Number) (byte) 100);
//        timeSeries46.add((org.jfree.data.time.RegularTimePeriod) day49, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate54 = day49.getSerialDate();
//        java.lang.String str55 = day49.toString();
//        java.lang.String str56 = day49.toString();
//        java.lang.String str57 = day49.toString();
//        int int58 = timeSeries44.getIndex((org.jfree.data.time.RegularTimePeriod) day49);
//        java.util.Collection collection59 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries44);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = null;
//        try {
//            timeSeries3.add(timeSeriesDataItem60, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list25);
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 9223372036854775807L + "'", long35 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem42);
//        org.junit.Assert.assertNotNull(collection43);
//        org.junit.Assert.assertNotNull(timeSeries44);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "10-June-2019" + "'", str55.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "10-June-2019" + "'", str56.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "10-June-2019" + "'", str57.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
//        org.junit.Assert.assertNotNull(collection59);
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate9);
        int int14 = day13.getYear();
        boolean boolean16 = day13.equals((java.lang.Object) "Mon Jun 10 08:59:47 PDT 2019");
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(3, (int) '4', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        long long4 = year2.getLastMillisecond();
        int int5 = year2.getYear();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(4, year2);
        int int7 = month6.getYearValue();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-62104204800001L) + "'", long4 == (-62104204800001L));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560182401871L);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month2.next();
        int int8 = month2.getYearValue();
        java.lang.Object obj9 = null;
        boolean boolean10 = month2.equals(obj9);
        java.lang.String str11 = month2.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "October 100" + "'", str11.equals("October 100"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.List list5 = timeSeries3.getItems();
        timeSeries3.setNotify(false);
        int int8 = timeSeries3.getMaximumItemCount();
        timeSeries3.setMaximumItemAge(1560182365954L);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        int int5 = timeSeries3.getMaximumItemCount();
        timeSeries3.setMaximumItemAge(24234L);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        long long7 = timeSeries3.getMaximumItemAge();
        java.util.List list8 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries10.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) (byte) 100);
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 9223372036854775807L);
        timeSeries10.fireSeriesChanged();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) (byte) 100);
        boolean boolean23 = timeSeriesDataItem21.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem21.setValue((java.lang.Number) 9);
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long30 = timeSeries29.getMaximumItemAge();
        boolean boolean31 = timeSeriesDataItem21.equals((java.lang.Object) timeSeries29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries10.addOrUpdate(timeSeriesDataItem21);
        boolean boolean33 = timeSeriesDataItem32.isSelected();
        timeSeries3.add(timeSeriesDataItem32);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test417");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
//        java.util.Date date4 = fixedMillisecond1.getTime();
//        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date4);
//        org.jfree.data.time.Year year8 = month7.getYear();
//        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(12, year8);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560182416231L + "'", long3 == 1560182416231L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(year8);
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("10-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 1, seriesChangeInfo1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = null;
        seriesChangeEvent2.setSummary(seriesChangeInfo3);
        java.lang.String str5 = seriesChangeEvent2.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=1]" + "'", str5.equals("org.jfree.data.event.SeriesChangeEvent[source=1]"));
    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test420");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
//        org.jfree.data.time.Year year8 = month7.getYear();
//        long long9 = month7.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182416300L + "'", long2 == 1560182416300L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(year8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559372400000L + "'", long9 == 1559372400000L);
//    }

//    @Test
//    public void test421() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test421");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond0.previous();
//        long long3 = fixedMillisecond0.getFirstMillisecond();
//        java.lang.String str4 = fixedMillisecond0.toString();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, 0.0d);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        long long8 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560182416324L + "'", long1 == 1560182416324L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560182416324L + "'", long3 == 1560182416324L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Mon Jun 10 09:00:16 PDT 2019" + "'", str4.equals("Mon Jun 10 09:00:16 PDT 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560182416324L + "'", long8 == 1560182416324L);
//    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test422");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
//        timeSeries1.addChangeListener(seriesChangeListener2);
//        java.lang.String str4 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries6.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day9, (java.lang.Number) (byte) 100);
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day9, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate14 = day9.getSerialDate();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(serialDate14);
//        int int17 = day16.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (double) 1560182347707L);
//        long long20 = day16.getFirstMillisecond();
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560150000000L + "'", long20 == 1560150000000L);
//    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test423");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        long long4 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
//        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
//        boolean boolean10 = timeSeriesDataItem7.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries13.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month18);
//        java.lang.String str23 = month18.toString();
//        org.jfree.data.time.Year year24 = month18.getYear();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries26.setRangeDescription("100");
//        int int29 = month18.compareTo((java.lang.Object) timeSeries26);
//        timeSeries26.removeAgedItems(1560182377967L, true);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond33.getMiddleMillisecond(calendar34);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException37 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int38 = fixedMillisecond33.compareTo((java.lang.Object) "hi!");
//        java.util.Date date39 = fixedMillisecond33.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date39);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(date39);
//        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date39);
//        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month(date39);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month43.previous();
//        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) month43, (double) 1560182355672L);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "October 100" + "'", str23.equals("October 100"));
//        org.junit.Assert.assertNotNull(year24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560182416452L + "'", long35 == 1560182416452L);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean6 = timeSeries1.equals((java.lang.Object) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries11.addChangeListener(seriesChangeListener12);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException15 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean16 = timeSeries11.equals((java.lang.Object) timePeriodFormatException15);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException18 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timePeriodFormatException15.addSuppressed((java.lang.Throwable) timePeriodFormatException18);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException15);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries22.addChangeListener(seriesChangeListener23);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean27 = timeSeries22.equals((java.lang.Object) timePeriodFormatException26);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException29 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timePeriodFormatException26.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException29);
        org.jfree.data.general.SeriesException seriesException33 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray34 = seriesException33.getSuppressed();
        timePeriodFormatException29.addSuppressed((java.lang.Throwable) seriesException33);
        java.lang.String str36 = timePeriodFormatException29.toString();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str36.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.event.SeriesChangeEvent[source=100]"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 100, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test426");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
//        long long14 = day8.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, (java.lang.Number) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day8.previous();
//        java.util.Calendar calendar18 = null;
//        try {
//            long long19 = day8.getMiddleMillisecond(calendar18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries13.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month18);
        java.lang.String str23 = month18.toString();
        org.jfree.data.time.Year year24 = month18.getYear();
        java.util.Date date25 = year24.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date25);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "October 100" + "'", str23.equals("October 100"));
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertNotNull(date25);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test428");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        timeSeries1.fireSeriesChanged();
//        timeSeries1.setDescription("Mon Jun 10 08:59:09 PDT 2019");
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener12);
//        double double14 = timeSeries1.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double19 = timeSeries18.getMaxY();
//        java.util.List list20 = timeSeries18.getItems();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) (byte) 100);
//        boolean boolean25 = timeSeriesDataItem23.equals((java.lang.Object) (short) 10);
//        timeSeries18.add(timeSeriesDataItem23);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.next();
//        long long30 = year28.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries32.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) (byte) 100);
//        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar41 = null;
//        long long42 = fixedMillisecond40.getMiddleMillisecond(calendar41);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException44 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int45 = fixedMillisecond40.compareTo((java.lang.Object) "hi!");
//        long long46 = fixedMillisecond40.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = fixedMillisecond40.next();
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double52 = timeSeries51.getMaxY();
//        int int53 = timeSeries51.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries51.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (double) 6);
//        long long57 = fixedMillisecond54.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = fixedMillisecond54.previous();
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond54);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener60 = null;
//        timeSeries59.addChangeListener(seriesChangeListener60);
//        int int62 = timeSeries59.getMaximumItemCount();
//        int int63 = year28.compareTo((java.lang.Object) timeSeries59);
//        java.lang.Object obj64 = timeSeries59.clone();
//        boolean boolean65 = timeSeriesDataItem23.equals((java.lang.Object) timeSeries59);
//        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries1.addAndOrUpdate(timeSeries59);
//        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double71 = timeSeries70.getMaxY();
//        int int72 = timeSeries70.getItemCount();
//        double double73 = timeSeries70.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries74 = timeSeries66.addAndOrUpdate(timeSeries70);
//        org.jfree.data.time.TimeSeries timeSeries78 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double79 = timeSeries78.getMaxY();
//        int int80 = timeSeries78.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond81 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries78.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond81, (double) 6);
//        long long84 = fixedMillisecond81.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries88 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double89 = timeSeries88.getMaxY();
//        java.util.List list90 = timeSeries88.getItems();
//        timeSeries88.removeAgedItems((long) (byte) 100, false);
//        boolean boolean94 = fixedMillisecond81.equals((java.lang.Object) (byte) 100);
//        long long95 = fixedMillisecond81.getFirstMillisecond();
//        long long96 = fixedMillisecond81.getMiddleMillisecond();
//        java.lang.Number number97 = null;
//        timeSeries74.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond81, number97, false);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 9.223372036854776E18d + "'", double14 == 9.223372036854776E18d);
//        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list20);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-62104204800001L) + "'", long30 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560182417164L + "'", long42 == 1560182417164L);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560182417164L + "'", long46 == 1560182417164L);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560182417166L + "'", long57 == 1560182417166L);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2147483647 + "'", int62 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(obj64);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(timeSeries66);
//        org.junit.Assert.assertEquals((double) double71, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
//        org.junit.Assert.assertEquals((double) double73, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(timeSeries74);
//        org.junit.Assert.assertEquals((double) double79, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
//        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1560182417170L + "'", long84 == 1560182417170L);
//        org.junit.Assert.assertEquals((double) double89, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list90);
//        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
//        org.junit.Assert.assertTrue("'" + long95 + "' != '" + 1560182417170L + "'", long95 == 1560182417170L);
//        org.junit.Assert.assertTrue("'" + long96 + "' != '" + 1560182417170L + "'", long96 == 1560182417170L);
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(2147483647, (int) '#', (-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        int int3 = month2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        long long5 = month2.getSerialIndex();
        java.lang.String str6 = month2.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1210L + "'", long5 == 1210L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "October 100" + "'", str6.equals("October 100"));
    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test431");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        timeSeries1.removeAgedItems(false);
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries12.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) day19, (double) 6);
//        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) day19, 0.0d);
//        long long25 = day19.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day19.next();
//        org.jfree.data.time.SerialDate serialDate29 = day19.getSerialDate();
//        boolean boolean30 = timeSeries1.equals((java.lang.Object) day19);
//        long long31 = day19.getLastMillisecond();
//        java.util.Calendar calendar32 = null;
//        try {
//            long long33 = day19.getFirstMillisecond(calendar32);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560236399999L + "'", long25 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560236399999L + "'", long31 == 1560236399999L);
//    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.next();
        int int10 = month6.getYearValue();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Mon Jun 10 08:59:15 PDT 2019");
    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test434");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        long long15 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double21 = timeSeries20.getMaxY();
//        int int22 = timeSeries20.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 6);
//        long long26 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond23.previous();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
//        timeSeries28.addChangeListener(seriesChangeListener29);
//        timeSeries28.setMaximumItemAge(1560182353546L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar34 = null;
//        long long35 = fixedMillisecond33.getMiddleMillisecond(calendar34);
//        java.util.Date date36 = fixedMillisecond33.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(date36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond37.next();
//        timeSeries28.setKey((java.lang.Comparable) fixedMillisecond37);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar41 = null;
//        long long42 = fixedMillisecond40.getMiddleMillisecond(calendar41);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException44 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int45 = fixedMillisecond40.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = fixedMillisecond40.previous();
//        long long47 = fixedMillisecond40.getLastMillisecond();
//        try {
//            timeSeries28.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (double) 1560182351846L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182418193L + "'", long11 == 1560182418193L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182418193L + "'", long15 == 1560182418193L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182418195L + "'", long26 == 1560182418195L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560182418198L + "'", long35 == 1560182418198L);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560182418200L + "'", long42 == 1560182418200L);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560182418200L + "'", long47 == 1560182418200L);
//    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test435");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        long long15 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double21 = timeSeries20.getMaxY();
//        int int22 = timeSeries20.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 6);
//        long long26 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond23.previous();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond23.getMiddleMillisecond(calendar29);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182418217L + "'", long11 == 1560182418217L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182418217L + "'", long15 == 1560182418217L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182418218L + "'", long26 == 1560182418218L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560182418218L + "'", long30 == 1560182418218L);
//    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test436");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.List list5 = timeSeries3.getItems();
//        timeSeries3.setNotify(false);
//        java.lang.String str8 = timeSeries3.getDomainDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        java.util.Date date12 = fixedMillisecond9.getTime();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date12);
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date12);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date12);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year16, (java.lang.Number) 1560182358499L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year16.next();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182418281L + "'", long11 == 1560182418281L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test437");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        long long9 = fixedMillisecond6.getFirstMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond6.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond6.previous();
//        long long13 = fixedMillisecond6.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double18 = timeSeries17.getMaxY();
//        java.util.Collection collection19 = timeSeries17.getTimePeriods();
//        java.lang.String str20 = timeSeries17.getRangeDescription();
//        timeSeries17.setMaximumItemAge((long) 12);
//        boolean boolean23 = timeSeries17.isEmpty();
//        timeSeries17.setMaximumItemAge(10L);
//        timeSeries17.setMaximumItemAge((long) (short) 100);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond28.getMiddleMillisecond(calendar29);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int33 = fixedMillisecond28.compareTo((java.lang.Object) "hi!");
//        java.util.Date date34 = fixedMillisecond28.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = fixedMillisecond28.previous();
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double40 = timeSeries39.getMaxY();
//        java.util.List list41 = timeSeries39.getItems();
//        int int42 = timeSeries39.getItemCount();
//        boolean boolean43 = fixedMillisecond28.equals((java.lang.Object) timeSeries39);
//        java.util.Calendar calendar44 = null;
//        long long45 = fixedMillisecond28.getLastMillisecond(calendar44);
//        java.util.Date date46 = fixedMillisecond28.getTime();
//        long long47 = fixedMillisecond28.getSerialIndex();
//        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (double) 1560182397362L);
//        boolean boolean50 = fixedMillisecond6.equals((java.lang.Object) 1560182397362L);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182418404L + "'", long9 == 1560182418404L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182418404L + "'", long11 == 1560182418404L);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560182418404L + "'", long13 == 1560182418404L);
//        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560182418406L + "'", long30 == 1560182418406L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560182418406L + "'", long45 == 1560182418406L);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560182418406L + "'", long47 == 1560182418406L);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test438");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        long long6 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        java.lang.String str8 = fixedMillisecond0.toString();
//        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj12 = null;
//        int int13 = month11.compareTo(obj12);
//        org.jfree.data.time.Year year14 = month11.getYear();
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        int int19 = year14.compareTo((java.lang.Object) timeSeries16);
//        boolean boolean20 = fixedMillisecond0.equals((java.lang.Object) timeSeries16);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj24 = null;
//        int int25 = month23.compareTo(obj24);
//        org.jfree.data.time.Year year26 = month23.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) year26);
//        double double28 = timeSeries16.getMaxY();
//        timeSeries16.removeAgedItems(false);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182418533L + "'", long2 == 1560182418533L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182418533L + "'", long6 == 1560182418533L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Mon Jun 10 09:00:18 PDT 2019" + "'", str8.equals("Mon Jun 10 09:00:18 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(year14);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(year26);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
//    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        timeSeries3.setRangeDescription("");
        boolean boolean8 = timeSeries3.getNotify();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(9, 6);
        java.lang.String str12 = month11.toString();
        int int13 = month11.getYearValue();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month11, 0.0d);
        java.util.Calendar calendar16 = null;
        try {
            month11.peg(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "September 6" + "'", str12.equals("September 6"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries13.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.time.Year year23 = month18.getYear();
        java.lang.String str24 = year23.toString();
        java.lang.String str25 = year23.toString();
        java.lang.String str26 = year23.toString();
        java.lang.String str27 = year23.toString();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(year23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "100" + "'", str24.equals("100"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "100" + "'", str25.equals("100"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "100" + "'", str26.equals("100"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "100" + "'", str27.equals("100"));
    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test441");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        timeSeries3.setRangeDescription("October 100");
//        java.util.Collection collection8 = timeSeries3.getTimePeriods();
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond12.getMiddleMillisecond(calendar13);
//        java.util.Date date15 = fixedMillisecond12.getEnd();
//        boolean boolean16 = day11.equals((java.lang.Object) fixedMillisecond12);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond12.previous();
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond12);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.lang.String str20 = day19.toString();
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj24 = null;
//        int int25 = month23.compareTo(obj24);
//        java.util.Date date26 = month23.getEnd();
//        int int27 = day19.compareTo((java.lang.Object) month23);
//        org.jfree.data.time.Year year28 = month23.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.next();
//        int int30 = timeSeries3.getIndex(regularTimePeriod29);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560182418695L + "'", long14 == 1560182418695L);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10-June-2019" + "'", str20.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(year28);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries13.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month18);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo23 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent24 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month18, seriesChangeInfo23);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test443");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 1560182359592L);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries7.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 100);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
//        java.lang.String str19 = timeSeries18.getDescription();
//        java.util.Collection collection20 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
//        boolean boolean21 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries18);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries24 = timeSeries18.createCopy((int) (short) -1, 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertNotNull(collection20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test444");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond6.getMiddleMillisecond(calendar9);
//        java.util.Calendar calendar11 = null;
//        fixedMillisecond6.peg(calendar11);
//        java.util.Date date13 = fixedMillisecond6.getTime();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) (byte) 100);
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar25 = null;
//        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException28 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int29 = fixedMillisecond24.compareTo((java.lang.Object) "hi!");
//        long long30 = fixedMillisecond24.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond24.next();
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double36 = timeSeries35.getMaxY();
//        int int37 = timeSeries35.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries35.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, (double) 6);
//        long long41 = fixedMillisecond38.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = fixedMillisecond38.previous();
//        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries16.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond38);
//        timeSeries43.setMaximumItemCount(3);
//        java.beans.PropertyChangeListener propertyChangeListener46 = null;
//        timeSeries43.removePropertyChangeListener(propertyChangeListener46);
//        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries49.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries53.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = day56.previous();
//        timeSeries53.add((org.jfree.data.time.RegularTimePeriod) day56, (double) 6);
//        timeSeries49.add((org.jfree.data.time.RegularTimePeriod) day56, 0.0d);
//        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day56, "Mon Jun 10 08:59:05 PDT 2019", "10-June-2019");
//        java.util.Collection collection65 = timeSeries43.getTimePeriodsUniqueToOtherSeries(timeSeries64);
//        boolean boolean66 = month14.equals((java.lang.Object) timeSeries64);
//        java.util.Collection collection67 = timeSeries64.getTimePeriods();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560182419196L + "'", long10 == 1560182419196L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182419198L + "'", long26 == 1560182419198L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560182419198L + "'", long30 == 1560182419198L);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560182419199L + "'", long41 == 1560182419199L);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertNotNull(timeSeries43);
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertNotNull(collection65);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertNotNull(collection67);
//    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test445");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        int int5 = timeSeries3.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (double) 6);
//        java.lang.String str9 = timeSeries3.getDescription();
//        double double10 = timeSeries3.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries12.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries16.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.previous();
//        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) day19, (double) 6);
//        timeSeries12.add((org.jfree.data.time.RegularTimePeriod) day19, 0.0d);
//        long long25 = day19.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = day19.previous();
//        long long29 = day19.getLastMillisecond();
//        boolean boolean30 = timeSeries3.equals((java.lang.Object) day19);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day19.previous();
//        int int33 = day19.compareTo((java.lang.Object) 1560182364216L);
//        long long34 = day19.getSerialIndex();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 6.0d + "'", double10 == 6.0d);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560236399999L + "'", long25 == 1560236399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1560236399999L + "'", long29 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 43626L + "'", long34 == 43626L);
//    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test446");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("100");
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double8 = timeSeries7.getMaxY();
//        int int9 = timeSeries7.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (double) 6);
//        long long13 = fixedMillisecond10.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond10.previous();
//        java.lang.Object obj15 = null;
//        boolean boolean16 = fixedMillisecond10.equals(obj15);
//        java.lang.Number number17 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, number17);
//        timeSeries1.setDescription("");
//        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560182419559L + "'", long13 == 1560182419559L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem18);
//    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
        java.lang.String str4 = timeSeries3.getDescription();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (double) 1560182355672L);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long16 = timeSeries15.getMaximumItemAge();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day17, (java.lang.Number) (byte) 100);
        boolean boolean21 = timeSeriesDataItem19.equals((java.lang.Object) (short) 10);
        boolean boolean22 = timeSeriesDataItem19.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries15.addOrUpdate(timeSeriesDataItem19);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries25.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries25.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month30, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = month30.next();
        timeSeries15.delete((org.jfree.data.time.RegularTimePeriod) month30);
        java.lang.String str35 = timeSeries15.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries37.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day40, (java.lang.Number) (byte) 100);
        timeSeries37.add((org.jfree.data.time.RegularTimePeriod) day40, (java.lang.Number) 9223372036854775807L);
        timeSeries37.fireSeriesChanged();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day46, (java.lang.Number) (byte) 100);
        boolean boolean50 = timeSeriesDataItem48.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem48.setValue((java.lang.Number) 9);
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long57 = timeSeries56.getMaximumItemAge();
        boolean boolean58 = timeSeriesDataItem48.equals((java.lang.Object) timeSeries56);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries37.addOrUpdate(timeSeriesDataItem48);
        boolean boolean60 = timeSeriesDataItem59.isSelected();
        timeSeries15.add(timeSeriesDataItem59);
        int int62 = fixedMillisecond8.compareTo((java.lang.Object) timeSeries15);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9223372036854775807L + "'", long16 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 9223372036854775807L + "'", long57 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test448");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date3);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(1560182346836L);
//        boolean boolean13 = year7.equals((java.lang.Object) 1560182346836L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182419813L + "'", long2 == 1560182419813L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month6.previous();
        long long10 = month6.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month6.previous();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = month6.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-58987929600000L) + "'", long10 == (-58987929600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test450");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) 1560182359592L);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries7.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 100);
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0.0f, "", "");
//        java.lang.String str19 = timeSeries18.getDescription();
//        java.util.Collection collection20 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries18);
//        boolean boolean21 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries18);
//        timeSeriesDataItem5.setSelected(true);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertNotNull(collection20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false);
        int int2 = timeSeries1.getItemCount();
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        long long9 = month6.getFirstMillisecond();
        java.util.Date date10 = month6.getEnd();
        org.jfree.data.time.Year year11 = month6.getYear();
        java.lang.Number number12 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year11);
        java.util.Date date13 = year11.getEnd();
        long long14 = year11.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year11, "", "Mon Jun 10 08:59:23 PDT 2019");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-58987929600000L) + "'", long9 == (-58987929600000L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-58979980800001L) + "'", long14 == (-58979980800001L));
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test452");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        timeSeries3.removeAgedItems((long) 10, false);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener8);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        int int13 = month12.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month12.next();
//        timeSeries3.add(regularTimePeriod14, (double) 1560182345775L, false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        long long19 = fixedMillisecond18.getLastMillisecond();
//        java.util.Calendar calendar20 = null;
//        fixedMillisecond18.peg(calendar20);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getMiddleMillisecond(calendar23);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException26 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int27 = fixedMillisecond22.compareTo((java.lang.Object) "hi!");
//        java.util.Date date28 = fixedMillisecond22.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date28);
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        timeSeries3.removeAgedItems((long) 35, true);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries39.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries39.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month44, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = month44.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries37.addOrUpdate(regularTimePeriod47, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener50 = null;
//        timeSeries37.addChangeListener(seriesChangeListener50);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener52 = null;
//        timeSeries37.removeChangeListener(seriesChangeListener52);
//        timeSeries37.setNotify(false);
//        java.util.Collection collection56 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries37);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560182420070L + "'", long19 == 1560182420070L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560182420071L + "'", long24 == 1560182420071L);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertNull(timeSeriesDataItem46);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(collection56);
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Mon Jun 10 09:00:16 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560182343089L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 1560182366600L);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        java.util.Calendar calendar6 = null;
        fixedMillisecond1.peg(calendar6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: Mon Jun 10 08:59:13 PDT 2019");
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day4.previous();
        org.jfree.data.time.SerialDate serialDate11 = day4.getSerialDate();
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(serialDate11);
    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test457");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        long long9 = day4.getFirstMillisecond();
//        java.lang.String str10 = day4.toString();
//        int int11 = day4.getDayOfMonth();
//        int int12 = day4.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
        boolean boolean6 = timeSeries1.equals((java.lang.Object) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=100]");
        timePeriodFormatException5.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(throwableArray10);
    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test459");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.addChangeListener(seriesChangeListener8);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond12.previous();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 1560182355429L, false);
//        long long18 = fixedMillisecond12.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        long long23 = timeSeries22.getMaximumItemAge();
//        timeSeries22.fireSeriesChanged();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day25, (java.lang.Number) (byte) 100);
//        boolean boolean29 = timeSeriesDataItem27.equals((java.lang.Object) (short) 10);
//        timeSeriesDataItem27.setSelected(false);
//        int int33 = timeSeriesDataItem27.compareTo((java.lang.Object) 1560182341157L);
//        timeSeriesDataItem27.setSelected(true);
//        timeSeries22.add(timeSeriesDataItem27);
//        java.lang.Number number37 = timeSeriesDataItem27.getValue();
//        boolean boolean38 = fixedMillisecond12.equals((java.lang.Object) number37);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560182420357L + "'", long13 == 1560182420357L);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560182420357L + "'", long18 == 1560182420357L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9223372036854775807L + "'", long23 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + number37 + "' != '" + (byte) 100 + "'", number37.equals((byte) 100));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test460");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        long long4 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
//        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
//        boolean boolean10 = timeSeriesDataItem7.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries13.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month18);
//        java.lang.String str23 = timeSeries3.getRangeDescription();
//        timeSeries3.setRangeDescription("");
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double30 = timeSeries29.getMaxY();
//        int int31 = timeSeries29.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries29.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (double) 6);
//        java.util.Calendar calendar35 = null;
//        long long36 = fixedMillisecond32.getMiddleMillisecond(calendar35);
//        java.util.Calendar calendar37 = null;
//        fixedMillisecond32.peg(calendar37);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 1560182353546L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries3.addOrUpdate(timeSeriesDataItem40);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = timeSeries3.getNextTimePeriod();
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent43 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
//        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1560182420440L + "'", long36 == 1560182420440L);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
        long long2 = year1.getSerialIndex();
        long long3 = year1.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries9.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month14.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries7.addOrUpdate(regularTimePeriod17, (double) (short) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries7.addChangeListener(seriesChangeListener20);
        java.util.Collection collection22 = timeSeries7.getTimePeriods();
        timeSeries7.setRangeDescription("");
        int int25 = year1.compareTo((java.lang.Object) timeSeries7);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries7);
        timeSeries7.setDomainDescription("");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries7.removeChangeListener(seriesChangeListener29);
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener31);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test462");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.List list5 = timeSeries3.getItems();
//        timeSeries3.setNotify(false);
//        boolean boolean8 = timeSeries3.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries3.createCopy((int) (byte) 0, 4);
//        int int12 = timeSeries3.getItemCount();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) (byte) 100);
//        boolean boolean17 = timeSeriesDataItem15.equals((java.lang.Object) (short) 10);
//        boolean boolean18 = timeSeriesDataItem15.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double23 = timeSeries22.getMaxY();
//        int int24 = timeSeries22.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries22.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (double) 6);
//        long long28 = fixedMillisecond25.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double33 = timeSeries32.getMaxY();
//        java.util.List list34 = timeSeries32.getItems();
//        timeSeries32.removeAgedItems((long) (byte) 100, false);
//        boolean boolean38 = fixedMillisecond25.equals((java.lang.Object) (byte) 100);
//        int int39 = timeSeriesDataItem15.compareTo((java.lang.Object) fixedMillisecond25);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) 1560182347331L);
//        timeSeries3.removeAgedItems(false);
//        java.util.Collection collection44 = timeSeries3.getTimePeriods();
//        java.lang.String str45 = timeSeries3.getDomainDescription();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list5);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560182420538L + "'", long28 == 1560182420538L);
//        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list34);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//        org.junit.Assert.assertNotNull(collection44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "hi!" + "'", str45.equals("hi!"));
//    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test463");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        java.util.Date date3 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
//        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.Year year7 = month6.getYear();
//        long long8 = year7.getMiddleMillisecond();
//        long long9 = year7.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182420591L + "'", long2 == 1560182420591L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(year7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1562097599999L + "'", long8 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
//    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener2 = null;
        timeSeries1.addChangeListener(seriesChangeListener2);
        java.lang.String str4 = timeSeries1.getDomainDescription();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj8 = null;
        int int9 = month7.compareTo(obj8);
        java.util.Date date10 = month7.getEnd();
        int int12 = month7.compareTo((java.lang.Object) 1560182345060L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month7.next();
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month7, (double) 1560182354231L);
        java.util.Date date16 = month7.getStart();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) (byte) 100);
        boolean boolean14 = timeSeriesDataItem12.equals((java.lang.Object) (short) 10);
        timeSeriesDataItem12.setValue((java.lang.Number) 9);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long21 = timeSeries20.getMaximumItemAge();
        boolean boolean22 = timeSeriesDataItem12.equals((java.lang.Object) timeSeries20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries1.addOrUpdate(timeSeriesDataItem12);
        java.lang.Number number24 = timeSeriesDataItem23.getValue();
        java.lang.Object obj25 = null;
        boolean boolean26 = timeSeriesDataItem23.equals(obj25);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 9223372036854775807L + "'", long21 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 9223372036854775807L + "'", number24.equals(9223372036854775807L));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries15.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day18, (double) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day18.next();
        timeSeries1.add(regularTimePeriod22, (double) 1560182340527L);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(0);
        long long27 = year26.getSerialIndex();
        long long28 = year26.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries34.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries34.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month39, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month39.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries32.addOrUpdate(regularTimePeriod42, (double) (short) 10);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener45 = null;
        timeSeries32.addChangeListener(seriesChangeListener45);
        java.util.Collection collection47 = timeSeries32.getTimePeriods();
        timeSeries32.setRangeDescription("");
        int int50 = year26.compareTo((java.lang.Object) timeSeries32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year26.previous();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
        int int53 = day52.getMonth();
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries1.createCopy(regularTimePeriod51, (org.jfree.data.time.RegularTimePeriod) day52);
        java.lang.String str55 = timeSeries1.getDomainDescription();
        int int56 = timeSeries1.getMaximumItemCount();
        timeSeries1.setDescription("Mon Jun 10 08:59:56 PDT 2019");
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertNotNull(collection47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 6 + "'", int53 == 6);
        org.junit.Assert.assertNotNull(timeSeries54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Time" + "'", str55.equals("Time"));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2147483647 + "'", int56 == 2147483647);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(9, 6);
        int int3 = month2.getMonth();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        long long7 = timeSeries3.getMaximumItemAge();
        java.util.List list8 = timeSeries3.getItems();
        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(9, 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
        java.util.Date date15 = regularTimePeriod14.getStart();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date15, timeZone16);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        int int21 = month20.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month20.next();
        long long23 = month20.getFirstMillisecond();
        java.util.Date date24 = month20.getEnd();
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date24, timeZone25);
        java.util.TimeZone timeZone27 = null;
        try {
            org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date24, timeZone27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-58987929600000L) + "'", long23 == (-58987929600000L));
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(regularTimePeriod26);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        long long4 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
        boolean boolean10 = timeSeriesDataItem7.isSelected();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries13.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month18);
        int int23 = month18.getMonth();
        int int24 = month18.getYearValue();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test470");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date6);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date6);
//        java.lang.Object obj11 = null;
//        boolean boolean12 = day10.equals(obj11);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day10);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182420969L + "'", long2 == 1560182420969L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        int int3 = month2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        long long5 = month2.getFirstMillisecond();
        java.util.Date date6 = month2.getEnd();
        long long7 = month2.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.previous();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-58987929600000L) + "'", long5 == (-58987929600000L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1210L + "'", long7 == 1210L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
        org.jfree.data.time.SerialDate serialDate9 = day4.getSerialDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double19 = timeSeries18.getMaxY();
        java.util.List list20 = timeSeries18.getItems();
        timeSeries18.setNotify(false);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries18.createCopy((int) (byte) 1, 9999);
        boolean boolean26 = day14.equals((java.lang.Object) (byte) 1);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day14);
        java.lang.Object obj28 = null;
        boolean boolean29 = day14.equals(obj28);
        java.lang.Object obj30 = null;
        int int31 = day14.compareTo(obj30);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(timeSeries25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test473");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException11 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int12 = fixedMillisecond7.compareTo((java.lang.Object) "hi!");
//        java.util.Date date13 = fixedMillisecond7.getTime();
//        boolean boolean15 = fixedMillisecond7.equals((java.lang.Object) 1560182343140L);
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond7.getFirstMillisecond(calendar16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond7.previous();
//        java.lang.Number number19 = null;
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, number19, false);
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182421135L + "'", long9 == 1560182421135L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560182421135L + "'", long17 == 1560182421135L);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test474");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        java.util.List list8 = timeSeries3.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond9.previous();
//        long long16 = fixedMillisecond9.getLastMillisecond();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond17.getMiddleMillisecond(calendar18);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException21 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int22 = fixedMillisecond17.compareTo((java.lang.Object) "hi!");
//        java.util.Date date23 = fixedMillisecond17.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond17.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond17.next();
//        java.lang.String str26 = fixedMillisecond17.toString();
//        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
//        timeSeries3.setDomainDescription("Mon Jun 10 08:59:15 PDT 2019");
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries31.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day34, (java.lang.Number) (byte) 100);
//        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) day34, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate39 = day34.getSerialDate();
//        java.lang.String str40 = day34.toString();
//        java.lang.String str41 = day34.toString();
//        java.lang.String str42 = day34.toString();
//        boolean boolean44 = day34.equals((java.lang.Object) 9999);
//        try {
//            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) day34, (java.lang.Number) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182421160L + "'", long11 == 1560182421160L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560182421160L + "'", long16 == 1560182421160L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560182421161L + "'", long19 == 1560182421161L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Mon Jun 10 09:00:21 PDT 2019" + "'", str26.equals("Mon Jun 10 09:00:21 PDT 2019"));
//        org.junit.Assert.assertNotNull(timeSeries27);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "10-June-2019" + "'", str40.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "10-June-2019" + "'", str41.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "10-June-2019" + "'", str42.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560182357414L);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries15.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) day18, (double) 6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day18.next();
        timeSeries1.add(regularTimePeriod22, (double) 1560182340527L);
        long long25 = timeSeries1.getMaximumItemAge();
        java.lang.String str26 = timeSeries1.getDomainDescription();
        java.lang.String str27 = timeSeries1.getDomainDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 9223372036854775807L + "'", long25 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Time" + "'", str26.equals("Time"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        timeSeries3.removeAgedItems((long) 10, false);
        boolean boolean8 = timeSeries3.isEmpty();
        long long9 = timeSeries3.getMaximumItemAge();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test478");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.List list5 = timeSeries3.getItems();
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj11 = null;
//        int int12 = month10.compareTo(obj11);
//        java.util.Date date13 = month10.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (double) 1560182343140L);
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem15);
//        timeSeries3.add(timeSeriesDataItem15);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
//        timeSeries19.addChangeListener(seriesChangeListener20);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException23 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.time.TimePeriodFormatException: hi!");
//        boolean boolean24 = timeSeries19.equals((java.lang.Object) timePeriodFormatException23);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day25, (java.lang.Number) (byte) 100);
//        boolean boolean29 = timeSeriesDataItem27.equals((java.lang.Object) (short) 10);
//        boolean boolean30 = timeSeriesDataItem27.isSelected();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double35 = timeSeries34.getMaxY();
//        int int36 = timeSeries34.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries34.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (double) 6);
//        long long40 = fixedMillisecond37.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double45 = timeSeries44.getMaxY();
//        java.util.List list46 = timeSeries44.getItems();
//        timeSeries44.removeAgedItems((long) (byte) 100, false);
//        boolean boolean50 = fixedMillisecond37.equals((java.lang.Object) (byte) 100);
//        int int51 = timeSeriesDataItem27.compareTo((java.lang.Object) fixedMillisecond37);
//        int int52 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37);
//        timeSeries19.clear();
//        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = year56.next();
//        long long58 = year56.getLastMillisecond();
//        int int59 = year56.getYear();
//        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month(4, year56);
//        timeSeries19.setKey((java.lang.Comparable) month60);
//        boolean boolean62 = timeSeriesDataItem15.equals((java.lang.Object) timeSeries19);
//        org.jfree.data.time.Month month65 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        java.lang.Object obj66 = null;
//        int int67 = month65.compareTo(obj66);
//        java.util.Date date68 = month65.getEnd();
//        int int70 = month65.compareTo((java.lang.Object) 1560182345060L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = month65.next();
//        org.jfree.data.time.Year year72 = month65.getYear();
//        long long73 = year72.getFirstMillisecond();
//        java.lang.String str74 = year72.toString();
//        timeSeries19.add((org.jfree.data.time.RegularTimePeriod) year72, (java.lang.Number) 1560182363374L, false);
//        long long78 = year72.getLastMillisecond();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list5);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560182421274L + "'", long40 == 1560182421274L);
//        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list46);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
//        org.junit.Assert.assertNotNull(regularTimePeriod57);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-62104204800001L) + "'", long58 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod71);
//        org.junit.Assert.assertNotNull(year72);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-59011603200000L) + "'", long73 == (-59011603200000L));
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "100" + "'", str74.equals("100"));
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + (-58979980800001L) + "'", long78 == (-58979980800001L));
//    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test479");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.List list5 = timeSeries3.getItems();
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries9.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) (byte) 100);
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day12, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.SerialDate serialDate17 = day12.getSerialDate();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(serialDate17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate17);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day19, (java.lang.Number) 1560182352596L, false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond23.getMiddleMillisecond(calendar24);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException27 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int28 = fixedMillisecond23.compareTo((java.lang.Object) "hi!");
//        java.util.Date date29 = fixedMillisecond23.getTime();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond23.previous();
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double35 = timeSeries34.getMaxY();
//        java.util.List list36 = timeSeries34.getItems();
//        int int37 = timeSeries34.getItemCount();
//        boolean boolean38 = fixedMillisecond23.equals((java.lang.Object) timeSeries34);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day39, (java.lang.Number) (byte) 100);
//        boolean boolean43 = timeSeriesDataItem41.equals((java.lang.Object) (short) 10);
//        boolean boolean44 = timeSeriesDataItem41.isSelected();
//        java.lang.Object obj45 = timeSeriesDataItem41.clone();
//        java.lang.Number number46 = null;
//        timeSeriesDataItem41.setValue(number46);
//        boolean boolean48 = timeSeriesDataItem41.isSelected();
//        boolean boolean49 = timeSeriesDataItem41.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries34.addOrUpdate(timeSeriesDataItem41);
//        try {
//            timeSeries3.add(timeSeriesDataItem41);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are attempting to add an observation for the time period 10-June-2019 but the series already contains an observation for that time period. Duplicates are not permitted.  Try using the addOrUpdate() method.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list5);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560182421510L + "'", long25 == 1560182421510L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertEquals((double) double35, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(obj45);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem50);
//    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-2019), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        java.lang.Object obj3 = null;
        int int4 = month2.compareTo(obj3);
        java.util.Date date5 = month2.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, (double) 1560182343140L);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem7);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo9 = null;
        seriesChangeEvent8.setSummary(seriesChangeInfo9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (byte) 100);
        boolean boolean4 = timeSeriesDataItem2.equals((java.lang.Object) (short) 10);
        boolean boolean5 = timeSeriesDataItem2.isSelected();
        java.lang.Object obj6 = timeSeriesDataItem2.clone();
        java.lang.Number number7 = null;
        timeSeriesDataItem2.setValue(number7);
        timeSeriesDataItem2.setSelected(true);
        java.lang.Object obj11 = timeSeriesDataItem2.clone();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem2, "", "Mon Jun 10 08:59:26 PDT 2019");
        try {
            timeSeries14.delete(0, 3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(obj11);
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test483");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        long long15 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double21 = timeSeries20.getMaxY();
//        int int22 = timeSeries20.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 6);
//        long long26 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond23.previous();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
//        timeSeries28.addChangeListener(seriesChangeListener29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day31, (java.lang.Number) (byte) 100);
//        boolean boolean35 = timeSeriesDataItem33.equals((java.lang.Object) (short) 10);
//        timeSeriesDataItem33.setSelected(false);
//        int int39 = timeSeriesDataItem33.compareTo((java.lang.Object) 1560182341157L);
//        java.lang.Number number40 = timeSeriesDataItem33.getValue();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries28.addOrUpdate(timeSeriesDataItem33);
//        timeSeriesDataItem33.setValue((java.lang.Number) 1560182352400L);
//        timeSeriesDataItem33.setValue((java.lang.Number) (short) -1);
//        java.lang.Number number46 = timeSeriesDataItem33.getValue();
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182421604L + "'", long11 == 1560182421604L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182421604L + "'", long15 == 1560182421604L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182421606L + "'", long26 == 1560182421606L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + number40 + "' != '" + (byte) 100 + "'", number40.equals((byte) 100));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem41);
//        org.junit.Assert.assertTrue("'" + number46 + "' != '" + (short) -1 + "'", number46.equals((short) -1));
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) 6);
        java.lang.String str9 = month6.toString();
        long long10 = month6.getLastMillisecond();
        int int11 = month6.getMonth();
        org.junit.Assert.assertNull(timeSeriesDataItem8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "October 100" + "'", str9.equals("October 100"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-58985251200001L) + "'", long10 == (-58985251200001L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) (byte) 100);
        boolean boolean4 = timeSeriesDataItem2.equals((java.lang.Object) (short) 10);
        boolean boolean5 = timeSeriesDataItem2.isSelected();
        java.lang.Object obj6 = timeSeriesDataItem2.clone();
        boolean boolean7 = timeSeriesDataItem2.isSelected();
        java.lang.Object obj8 = timeSeriesDataItem2.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) false);
        int int2 = timeSeries1.getItemCount();
        timeSeries1.fireSeriesChanged();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(10, (int) (byte) 100);
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        long long9 = month6.getFirstMillisecond();
        java.util.Date date10 = month6.getEnd();
        org.jfree.data.time.Year year11 = month6.getYear();
        java.lang.Number number12 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year11);
        java.util.Date date13 = year11.getEnd();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        long long15 = month14.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-58987929600000L) + "'", long9 == (-58987929600000L));
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(year11);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-58981320000001L) + "'", long15 == (-58981320000001L));
    }

//    @Test
//    public void test488() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test488");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getMiddleMillisecond(calendar10);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException13 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int14 = fixedMillisecond9.compareTo((java.lang.Object) "hi!");
//        long long15 = fixedMillisecond9.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond9.next();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double21 = timeSeries20.getMaxY();
//        int int22 = timeSeries20.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (double) 6);
//        long long26 = fixedMillisecond23.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond23.previous();
//        org.jfree.data.time.TimeSeries timeSeries28 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
//        timeSeries28.setMaximumItemCount(3);
//        java.beans.PropertyChangeListener propertyChangeListener31 = null;
//        timeSeries28.removePropertyChangeListener(propertyChangeListener31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = timeSeries28.getTimePeriod(0);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = timeSeries28.getTimePeriod(6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560182421897L + "'", long11 == 1560182421897L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182421897L + "'", long15 == 1560182421897L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560182421901L + "'", long26 == 1560182421901L);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(timeSeries28);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//    }

//    @Test
//    public void test489() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test489");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
//        long long9 = fixedMillisecond8.getMiddleMillisecond();
//        java.lang.Class<?> wildcardClass10 = fixedMillisecond8.getClass();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182421919L + "'", long2 == 1560182421919L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560182421919L + "'", long9 == 1560182421919L);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test490");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) (byte) 100);
//        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 9223372036854775807L);
//        timeSeries1.fireSeriesChanged();
//        timeSeries1.setDescription("Mon Jun 10 08:59:09 PDT 2019");
//        java.beans.PropertyChangeListener propertyChangeListener12 = null;
//        timeSeries1.removePropertyChangeListener(propertyChangeListener12);
//        double double14 = timeSeries1.getMinY();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double19 = timeSeries18.getMaxY();
//        java.util.List list20 = timeSeries18.getItems();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) (byte) 100);
//        boolean boolean25 = timeSeriesDataItem23.equals((java.lang.Object) (short) 10);
//        timeSeries18.add(timeSeriesDataItem23);
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(0);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.next();
//        long long30 = year28.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries32.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) (byte) 100);
//        timeSeries32.add((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) 9223372036854775807L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar41 = null;
//        long long42 = fixedMillisecond40.getMiddleMillisecond(calendar41);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException44 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int45 = fixedMillisecond40.compareTo((java.lang.Object) "hi!");
//        long long46 = fixedMillisecond40.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = fixedMillisecond40.next();
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double52 = timeSeries51.getMaxY();
//        int int53 = timeSeries51.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries51.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (double) 6);
//        long long57 = fixedMillisecond54.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = fixedMillisecond54.previous();
//        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries32.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond40, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond54);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener60 = null;
//        timeSeries59.addChangeListener(seriesChangeListener60);
//        int int62 = timeSeries59.getMaximumItemCount();
//        int int63 = year28.compareTo((java.lang.Object) timeSeries59);
//        java.lang.Object obj64 = timeSeries59.clone();
//        boolean boolean65 = timeSeriesDataItem23.equals((java.lang.Object) timeSeries59);
//        org.jfree.data.time.TimeSeries timeSeries66 = timeSeries1.addAndOrUpdate(timeSeries59);
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day67, (java.lang.Number) (byte) 100);
//        boolean boolean71 = timeSeriesDataItem69.equals((java.lang.Object) (short) 10);
//        boolean boolean72 = timeSeriesDataItem69.isSelected();
//        java.lang.Object obj73 = timeSeriesDataItem69.clone();
//        java.lang.Number number74 = null;
//        timeSeriesDataItem69.setValue(number74);
//        timeSeriesDataItem69.setSelected(true);
//        java.lang.Object obj78 = timeSeriesDataItem69.clone();
//        timeSeriesDataItem69.setSelected(true);
//        timeSeriesDataItem69.setSelected(true);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = timeSeriesDataItem69.getPeriod();
//        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day();
//        int int85 = day84.getMonth();
//        int int86 = day84.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries89 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day84, "org.jfree.data.event.SeriesChangeEvent[source=1560182345230]", "");
//        org.jfree.data.time.TimeSeries timeSeries90 = timeSeries66.createCopy(regularTimePeriod83, (org.jfree.data.time.RegularTimePeriod) day84);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 9.223372036854776E18d + "'", double14 == 9.223372036854776E18d);
//        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(list20);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-62104204800001L) + "'", long30 == (-62104204800001L));
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560182422010L + "'", long42 == 1560182422010L);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1560182422010L + "'", long46 == 1560182422010L);
//        org.junit.Assert.assertNotNull(regularTimePeriod47);
//        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1560182422012L + "'", long57 == 1560182422012L);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNotNull(timeSeries59);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2147483647 + "'", int62 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNotNull(obj64);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertNotNull(timeSeries66);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNotNull(obj73);
//        org.junit.Assert.assertNotNull(obj78);
//        org.junit.Assert.assertNotNull(regularTimePeriod83);
//        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 6 + "'", int85 == 6);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 6 + "'", int86 == 6);
//        org.junit.Assert.assertNotNull(timeSeries90);
//    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test491");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        long long6 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond0.next();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182423006L + "'", long2 == 1560182423006L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182423006L + "'", long6 == 1560182423006L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        timeSeries3.setMaximumItemAge((long) 12);
        timeSeries3.fireSeriesChanged();
        timeSeries3.setDomainDescription("Mon Jun 10 08:59:33 PDT 2019");
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test493");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        long long4 = timeSeries3.getMaximumItemAge();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) (byte) 100);
//        boolean boolean9 = timeSeriesDataItem7.equals((java.lang.Object) (short) 10);
//        boolean boolean10 = timeSeriesDataItem7.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.addOrUpdate(timeSeriesDataItem7);
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries13.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month18.next();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month18);
//        java.lang.String str23 = timeSeries3.getRangeDescription();
//        timeSeries3.removeAgedItems(1560182350391L, false);
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        long long31 = timeSeries30.getMaximumItemAge();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day32, (java.lang.Number) (byte) 100);
//        boolean boolean36 = timeSeriesDataItem34.equals((java.lang.Object) (short) 10);
//        boolean boolean37 = timeSeriesDataItem34.isSelected();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries30.addOrUpdate(timeSeriesDataItem34);
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries40.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month45, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = month45.next();
//        timeSeries30.delete((org.jfree.data.time.RegularTimePeriod) month45);
//        java.lang.String str50 = timeSeries30.getRangeDescription();
//        timeSeries30.setRangeDescription("");
//        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double57 = timeSeries56.getMaxY();
//        int int58 = timeSeries56.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond();
//        timeSeries56.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59, (double) 6);
//        java.util.Calendar calendar62 = null;
//        long long63 = fixedMillisecond59.getMiddleMillisecond(calendar62);
//        java.util.Calendar calendar64 = null;
//        fixedMillisecond59.peg(calendar64);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond59, (java.lang.Number) 1560182353546L);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = timeSeries30.addOrUpdate(timeSeriesDataItem67);
//        timeSeries30.setNotify(true);
//        boolean boolean71 = timeSeries3.equals((java.lang.Object) true);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 9223372036854775807L + "'", long4 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem11);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hi!" + "'", str23.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 9223372036854775807L + "'", long31 == 9223372036854775807L);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem38);
//        org.junit.Assert.assertNull(timeSeriesDataItem47);
//        org.junit.Assert.assertNotNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "hi!" + "'", str50.equals("hi!"));
//        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1560182423072L + "'", long63 == 1560182423072L);
//        org.junit.Assert.assertNull(timeSeriesDataItem68);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
        double double4 = timeSeries3.getMaxY();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        java.lang.String str6 = timeSeries3.getRangeDescription();
        int int7 = timeSeries3.getMaximumItemCount();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(0);
        int int10 = year9.getYear();
        int int11 = year9.getYear();
        timeSeries3.setKey((java.lang.Comparable) int11);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test495");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
//        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(10, (int) (byte) 100);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) 6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month10.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate(regularTimePeriod13, (double) (short) 10);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
//        timeSeries3.addChangeListener(seriesChangeListener16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.previous();
//        long long20 = day18.getFirstMillisecond();
//        int int21 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day18);
//        long long22 = day18.getFirstMillisecond();
//        int int23 = day18.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day18.next();
//        org.junit.Assert.assertNull(timeSeriesDataItem12);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560150000000L + "'", long20 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560150000000L + "'", long22 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//    }

//    @Test
//    public void test496() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test496");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        long long6 = fixedMillisecond0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond0.next();
//        java.util.Date date8 = fixedMillisecond0.getTime();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182423290L + "'", long2 == 1560182423290L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560182423290L + "'", long6 == 1560182423290L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test497");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        long long2 = fixedMillisecond0.getMiddleMillisecond(calendar1);
//        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//        int int5 = fixedMillisecond0.compareTo((java.lang.Object) "hi!");
//        java.util.Date date6 = fixedMillisecond0.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(date6);
//        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date6);
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date6);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560182423306L + "'", long2 == 1560182423306L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) 100, seriesChangeInfo1);
        java.lang.String str3 = seriesChangeEvent2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=100]" + "'", str3.equals("org.jfree.data.event.SeriesChangeEvent[source=100]"));
    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test499");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "hi!", "hi!");
//        double double4 = timeSeries3.getMaxY();
//        java.util.Collection collection5 = timeSeries3.getTimePeriods();
//        java.lang.String str6 = timeSeries3.getRangeDescription();
//        long long7 = timeSeries3.getMaximumItemAge();
//        java.util.List list8 = timeSeries3.getItems();
//        java.lang.Class<?> wildcardClass9 = timeSeries3.getClass();
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
//        java.lang.Class class12 = null;
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getMiddleMillisecond(calendar14);
//        java.util.Date date16 = fixedMillisecond13.getTime();
//        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date16);
//        java.util.TimeZone timeZone19 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date16, timeZone19);
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date16, timeZone21);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date16);
//        long long24 = month23.getFirstMillisecond();
//        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 9223372036854775807L + "'", long7 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(list8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(class11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560182423390L + "'", long15 == 1560182423390L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(regularTimePeriod20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1559372400000L + "'", long24 == 1559372400000L);
//    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries1.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9);
        timeSeries5.setRangeDescription("org.jfree.data.event.SeriesChangeEvent[source=100]");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day8, (double) 6);
        timeSeries1.add((org.jfree.data.time.RegularTimePeriod) day8, 0.0d);
        java.lang.Comparable comparable14 = timeSeries1.getKey();
        java.util.List list15 = timeSeries1.getItems();
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 9 + "'", comparable14.equals(9));
        org.junit.Assert.assertNotNull(list15);
    }
}

