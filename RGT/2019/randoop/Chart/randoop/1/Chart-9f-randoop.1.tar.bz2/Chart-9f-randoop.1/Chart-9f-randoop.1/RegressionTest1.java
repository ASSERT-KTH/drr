import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        long long5 = month3.getSerialIndex();
        boolean boolean6 = spreadsheetDate1.equals((java.lang.Object) month3);
        long long7 = month3.getLastMillisecond();
        long long8 = month3.getLastMillisecond();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = month3.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 24234L + "'", long5 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        timeSeries3.setKey((java.lang.Comparable) 1560189770680L);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass10 = timeZone9.getClass();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass10);
        timeSeries11.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries11.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.lang.Object obj17 = null;
        boolean boolean18 = year16.equals(obj17);
        int int19 = year16.getYear();
        int int20 = year16.getYear();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        boolean boolean22 = year16.equals((java.lang.Object) year21);
        java.lang.Number number23 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries3.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.TimeSeries timeSeries27 = timeSeries3.createCopy((int) (byte) 0, 0);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(timeSeries27);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        java.lang.Object obj6 = timeSeries3.clone();
        java.util.List list7 = timeSeries3.getItems();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((int) (short) 10, 1900);
        java.lang.String str11 = timeSeries10.getDescription();
        java.util.Collection collection12 = timeSeries10.getTimePeriods();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(collection12);
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date5 = fixedMillisecond4.getTime();
//        java.util.Date date6 = fixedMillisecond4.getTime();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6, timeZone7);
//        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
//        java.lang.String str10 = serialDate9.toString();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate9);
//        int int12 = spreadsheetDate1.compare(serialDate9);
//        int int13 = spreadsheetDate1.getDayOfWeek();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date17 = fixedMillisecond16.getTime();
//        java.util.Date date18 = fixedMillisecond16.getTime();
//        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date18, timeZone19);
//        org.jfree.data.time.SerialDate serialDate21 = day20.getSerialDate();
//        java.lang.String str22 = serialDate21.toString();
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays((int) (short) 100, serialDate21);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date25 = fixedMillisecond24.getTime();
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass27 = timeZone26.getClass();
//        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date25, timeZone26);
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance(date25);
//        org.jfree.data.time.SerialDate serialDate30 = serialDate23.getEndOfCurrentMonth(serialDate29);
//        org.jfree.data.time.SerialDate serialDate32 = serialDate29.getNearestDayOfWeek(4);
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addDays((int) (short) 0, serialDate32);
//        boolean boolean34 = spreadsheetDate1.isOnOrAfter(serialDate33);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-43616) + "'", int12 == (-43616));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeZone19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10-June-2019" + "'", str22.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNotNull(wildcardClass27);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date5 = fixedMillisecond4.getTime();
//        java.util.Date date6 = fixedMillisecond4.getTime();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6, timeZone7);
//        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
//        java.lang.String str10 = serialDate9.toString();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate9);
//        int int12 = spreadsheetDate1.compare(serialDate9);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int15 = spreadsheetDate14.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        java.util.Date date19 = fixedMillisecond17.getTime();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date19, timeZone20);
//        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
//        java.lang.String str23 = serialDate22.toString();
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate22);
//        int int25 = spreadsheetDate14.compare(serialDate22);
//        int int26 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        spreadsheetDate1.setDescription("28-February-1981");
//        int int29 = spreadsheetDate1.getMonth();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-43616) + "'", int12 == (-43616));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-43616) + "'", int25 == (-43616));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date7 = fixedMillisecond6.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 10.0f);
        timeSeriesDataItem12.setValue((java.lang.Number) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeriesDataItem12.getPeriod();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass18 = timeZone17.getClass();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass18);
        timeSeries19.setDescription("");
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass24 = timeZone23.getClass();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass24);
        timeSeries25.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date29 = fixedMillisecond28.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date31 = fixedMillisecond30.getTime();
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 10.0f);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass37 = timeZone36.getClass();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass37);
        java.beans.PropertyChangeListener propertyChangeListener39 = null;
        timeSeries38.removePropertyChangeListener(propertyChangeListener39);
        int int41 = timeSeries38.getItemCount();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass44 = timeZone43.getClass();
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass44);
        timeSeries45.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date49 = fixedMillisecond48.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date51 = fixedMillisecond50.getTime();
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries45.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond50);
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass55 = timeZone54.getClass();
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass55);
        java.util.Collection collection57 = timeSeries45.getTimePeriodsUniqueToOtherSeries(timeSeries56);
        java.util.Collection collection58 = timeSeries38.getTimePeriodsUniqueToOtherSeries(timeSeries56);
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date60 = fixedMillisecond59.getTime();
        java.util.Date date61 = fixedMillisecond59.getTime();
        timeSeries38.setKey((java.lang.Comparable) fixedMillisecond59);
        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries19.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond59);
        boolean boolean64 = timeSeriesDataItem12.equals((java.lang.Object) timeSeries63);
        timeSeriesDataItem12.setValue((java.lang.Number) 520764324);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeSeries52);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(collection57);
        org.junit.Assert.assertNotNull(collection58);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(timeSeries63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        java.util.Date date2 = fixedMillisecond0.getTime();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2, timeZone3);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        int int6 = day4.getYear();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(1560189800410L);
        boolean boolean9 = day4.equals((java.lang.Object) fixedMillisecond8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (-1.0d));
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date5 = fixedMillisecond4.getTime();
//        java.util.Date date6 = fixedMillisecond4.getTime();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6, timeZone7);
//        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
//        java.lang.String str10 = serialDate9.toString();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate9);
//        int int12 = spreadsheetDate1.compare(serialDate9);
//        int int13 = spreadsheetDate1.getDayOfWeek();
//        int int14 = spreadsheetDate1.toSerial();
//        int int15 = spreadsheetDate1.getMonth();
//        int int16 = spreadsheetDate1.getDayOfWeek();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date21 = fixedMillisecond20.getTime();
//        java.util.Date date22 = fixedMillisecond20.getTime();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22, timeZone23);
//        org.jfree.data.time.SerialDate serialDate25 = day24.getSerialDate();
//        java.lang.String str26 = serialDate25.toString();
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths((-460), serialDate25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date30 = fixedMillisecond29.getTime();
//        java.util.Date date31 = fixedMillisecond29.getTime();
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31, timeZone32);
//        org.jfree.data.time.SerialDate serialDate34 = day33.getSerialDate();
//        java.lang.String str35 = serialDate34.toString();
//        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.addMonths((-460), serialDate34);
//        boolean boolean38 = spreadsheetDate18.isInRange(serialDate27, serialDate36, (-457));
//        boolean boolean39 = spreadsheetDate1.isOn(serialDate27);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-43616) + "'", int12 == (-43616));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "10-June-2019" + "'", str26.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "10-June-2019" + "'", str35.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) '#');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        java.lang.Object obj6 = timeSeries3.clone();
        java.util.List list7 = timeSeries3.getItems();
        boolean boolean8 = timeSeries3.isEmpty();
        java.lang.Object obj9 = timeSeries3.clone();
        timeSeries3.removeAgedItems(true);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560189811724L);
        timeSeries1.setNotify(true);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1.0f));
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.String str3 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (-1.0f) + "'", obj2.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1.0]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=-1.0]"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date7 = fixedMillisecond6.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 10.0f);
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass17 = timeZone16.getClass();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "Value", "Mon Jun 10 11:02:50 PDT 2019", "10-June-2019", (java.lang.Class) wildcardClass17);
        int int19 = timeSeriesDataItem12.compareTo((java.lang.Object) "Value");
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        java.lang.Object obj21 = null;
        boolean boolean22 = year20.equals(obj21);
        int int23 = year20.getYear();
        int int24 = timeSeriesDataItem12.compareTo((java.lang.Object) year20);
        java.util.Calendar calendar25 = null;
        try {
            year20.peg(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2019 + "'", int23 == 2019);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date5 = fixedMillisecond4.getTime();
//        java.util.Date date6 = fixedMillisecond4.getTime();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6, timeZone7);
//        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
//        java.lang.String str10 = serialDate9.toString();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate9);
//        int int12 = spreadsheetDate1.compare(serialDate9);
//        int int13 = spreadsheetDate1.getDayOfWeek();
//        int int14 = spreadsheetDate1.toSerial();
//        int int15 = spreadsheetDate1.getMonth();
//        boolean boolean17 = spreadsheetDate1.equals((java.lang.Object) "Mon Jun 10 11:03:00 PDT 2019");
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-43616) + "'", int12 == (-43616));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date5 = fixedMillisecond4.getTime();
//        java.util.Date date6 = fixedMillisecond4.getTime();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6, timeZone7);
//        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
//        java.lang.String str10 = serialDate9.toString();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate9);
//        int int12 = spreadsheetDate1.compare(serialDate9);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int15 = spreadsheetDate14.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        java.util.Date date19 = fixedMillisecond17.getTime();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date19, timeZone20);
//        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
//        java.lang.String str23 = serialDate22.toString();
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate22);
//        int int25 = spreadsheetDate14.compare(serialDate22);
//        int int26 = spreadsheetDate14.getDayOfWeek();
//        int int27 = spreadsheetDate14.toSerial();
//        int int28 = spreadsheetDate14.getMonth();
//        boolean boolean29 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        int int30 = spreadsheetDate1.getDayOfWeek();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-43616) + "'", int12 == (-43616));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-43616) + "'", int25 == (-43616));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3 + "'", int26 == 3);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(9);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
//        timeSeries3.setDescription("");
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass8 = timeZone7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass8);
//        timeSeries9.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date13 = fixedMillisecond12.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date15 = fixedMillisecond14.getTime();
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) 10.0f);
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass21 = timeZone20.getClass();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass21);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timeSeries22.removePropertyChangeListener(propertyChangeListener23);
//        int int25 = timeSeries22.getItemCount();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass28 = timeZone27.getClass();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass28);
//        timeSeries29.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date33 = fixedMillisecond32.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date35 = fixedMillisecond34.getTime();
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass39 = timeZone38.getClass();
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass39);
//        java.util.Collection collection41 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries40);
//        java.util.Collection collection42 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries40);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date44 = fixedMillisecond43.getTime();
//        java.util.Date date45 = fixedMillisecond43.getTime();
//        timeSeries22.setKey((java.lang.Comparable) fixedMillisecond43);
//        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass50 = timeZone49.getClass();
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass50);
//        timeSeries51.setDescription("");
//        java.lang.Object obj54 = timeSeries51.clone();
//        java.util.List list55 = timeSeries51.getItems();
//        boolean boolean56 = fixedMillisecond43.equals((java.lang.Object) list55);
//        java.util.Calendar calendar57 = null;
//        long long58 = fixedMillisecond43.getFirstMillisecond(calendar57);
//        java.lang.String str59 = fixedMillisecond43.toString();
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(collection41);
//        org.junit.Assert.assertNotNull(collection42);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeSeries47);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//        org.junit.Assert.assertNotNull(obj54);
//        org.junit.Assert.assertNotNull(list55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560189847353L + "'", long58 == 1560189847353L);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Mon Jun 10 11:04:07 PDT 2019" + "'", str59.equals("Mon Jun 10 11:04:07 PDT 2019"));
//    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        java.util.Date date4 = fixedMillisecond2.getTime();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4, timeZone5);
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        java.lang.String str8 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths((-460), serialDate7);
//        try {
//            org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) -1, serialDate7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate9);
//    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond2 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date3 = fixedMillisecond2.getTime();
//        java.util.Date date4 = fixedMillisecond2.getTime();
//        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4, timeZone5);
//        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
//        java.lang.String str8 = serialDate7.toString();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays((int) (short) 100, serialDate7);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date11 = fixedMillisecond10.getTime();
//        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass13 = timeZone12.getClass();
//        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date11, timeZone12);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date11);
//        org.jfree.data.time.SerialDate serialDate16 = serialDate9.getEndOfCurrentMonth(serialDate15);
//        org.jfree.data.time.SerialDate serialDate18 = serialDate15.getNearestDayOfWeek(4);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addDays((int) (short) 0, serialDate18);
//        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getFollowingDayOfWeek(3);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int24 = spreadsheetDate23.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date27 = fixedMillisecond26.getTime();
//        java.util.Date date28 = fixedMillisecond26.getTime();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date28, timeZone29);
//        org.jfree.data.time.SerialDate serialDate31 = day30.getSerialDate();
//        java.lang.String str32 = serialDate31.toString();
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate31);
//        int int34 = spreadsheetDate23.compare(serialDate31);
//        int int35 = spreadsheetDate23.getDayOfWeek();
//        int int36 = spreadsheetDate23.toSerial();
//        int int37 = spreadsheetDate23.getMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date42 = fixedMillisecond41.getTime();
//        java.util.Date date43 = fixedMillisecond41.getTime();
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date43, timeZone44);
//        org.jfree.data.time.SerialDate serialDate46 = day45.getSerialDate();
//        java.lang.String str47 = serialDate46.toString();
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.addMonths((-460), serialDate46);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date51 = fixedMillisecond50.getTime();
//        java.util.Date date52 = fixedMillisecond50.getTime();
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date52, timeZone53);
//        org.jfree.data.time.SerialDate serialDate55 = day54.getSerialDate();
//        java.lang.String str56 = serialDate55.toString();
//        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.addMonths((-460), serialDate55);
//        boolean boolean59 = spreadsheetDate39.isInRange(serialDate48, serialDate57, (-457));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date63 = fixedMillisecond62.getTime();
//        java.util.Date date64 = fixedMillisecond62.getTime();
//        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date64, timeZone65);
//        org.jfree.data.time.SerialDate serialDate67 = day66.getSerialDate();
//        java.lang.String str68 = serialDate67.toString();
//        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.addDays((int) (short) 100, serialDate67);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date71 = fixedMillisecond70.getTime();
//        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass73 = timeZone72.getClass();
//        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date71, timeZone72);
//        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.createInstance(date71);
//        org.jfree.data.time.SerialDate serialDate76 = serialDate69.getEndOfCurrentMonth(serialDate75);
//        org.jfree.data.time.SerialDate serialDate78 = serialDate75.getNearestDayOfWeek(4);
//        org.jfree.data.time.SerialDate serialDate79 = org.jfree.data.time.SerialDate.addDays((int) (short) 0, serialDate78);
//        java.lang.String str80 = serialDate79.getDescription();
//        boolean boolean81 = spreadsheetDate39.isOnOrBefore(serialDate79);
//        boolean boolean82 = spreadsheetDate23.isBefore(serialDate79);
//        org.jfree.data.time.SerialDate serialDate83 = serialDate19.getEndOfCurrentMonth(serialDate79);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 9 + "'", int24 == 9);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-43616) + "'", int34 == (-43616));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 3 + "'", int35 == 3);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "10-June-2019" + "'", str47.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "10-June-2019" + "'", str56.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(timeZone65);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "10-June-2019" + "'", str68.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate69);
//        org.junit.Assert.assertNotNull(date71);
//        org.junit.Assert.assertNotNull(timeZone72);
//        org.junit.Assert.assertNotNull(wildcardClass73);
//        org.junit.Assert.assertNotNull(serialDate75);
//        org.junit.Assert.assertNotNull(serialDate76);
//        org.junit.Assert.assertNotNull(serialDate78);
//        org.junit.Assert.assertNotNull(serialDate79);
//        org.junit.Assert.assertNull(str80);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
//        org.junit.Assert.assertNotNull(serialDate83);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date7 = fixedMillisecond6.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        boolean boolean11 = timeSeries10.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date15 = fixedMillisecond14.getTime();
        java.util.Date date16 = fixedMillisecond14.getTime();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date16, timeZone17);
        org.jfree.data.time.SerialDate serialDate19 = day18.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day18.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries10.addOrUpdate(regularTimePeriod20, (java.lang.Number) 1560189785801L);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        java.lang.Object obj24 = null;
        boolean boolean25 = year23.equals(obj24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year23, (double) 100L);
        long long28 = year23.getLastMillisecond();
        java.lang.Class<?> wildcardClass29 = year23.getClass();
        java.lang.String str30 = year23.toString();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
        int int33 = spreadsheetDate32.getDayOfMonth();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        int int35 = month34.getMonth();
        long long36 = month34.getSerialIndex();
        boolean boolean37 = spreadsheetDate32.equals((java.lang.Object) month34);
        long long38 = month34.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) year23, (org.jfree.data.time.RegularTimePeriod) month34);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577865599999L + "'", long28 == 1577865599999L);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2019" + "'", str30.equals("2019"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 9 + "'", int33 == 9);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 24234L + "'", long36 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1561964399999L + "'", long38 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries39);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-43616), (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
//        timeSeries3.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date7 = fixedMillisecond6.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getTime();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        boolean boolean11 = timeSeries3.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date13 = fixedMillisecond12.getTime();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond12.getFirstMillisecond(calendar14);
//        java.lang.String str16 = fixedMillisecond12.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond12.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 8);
//        java.util.Date date20 = fixedMillisecond12.getTime();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560189850276L + "'", long15 == 1560189850276L);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Mon Jun 10 11:04:10 PDT 2019" + "'", str16.equals("Mon Jun 10 11:04:10 PDT 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertNotNull(date20);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 100.0d);
        long long3 = year0.getLastMillisecond();
        int int4 = year0.getYear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (byte) -1);
        boolean boolean2 = timeSeries1.getNotify();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        java.lang.Object obj6 = timeSeries3.clone();
        java.util.List list7 = timeSeries3.getItems();
        java.lang.Class class8 = timeSeries3.getTimePeriodClass();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass11 = timeZone10.getClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass11);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries12.removePropertyChangeListener(propertyChangeListener13);
        timeSeries12.setKey((java.lang.Comparable) 1560189770680L);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass19 = timeZone18.getClass();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass19);
        timeSeries20.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timeSeries20.addPropertyChangeListener(propertyChangeListener23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        java.lang.Object obj26 = null;
        boolean boolean27 = year25.equals(obj26);
        int int28 = year25.getYear();
        int int29 = year25.getYear();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        boolean boolean31 = year25.equals((java.lang.Object) year30);
        java.lang.Number number32 = timeSeries20.getValue((org.jfree.data.time.RegularTimePeriod) year25);
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries12.addAndOrUpdate(timeSeries20);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.addAndOrUpdate(timeSeries12);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass37 = timeZone36.getClass();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass37);
        timeSeries38.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date42 = fixedMillisecond41.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date44 = fixedMillisecond43.getTime();
        org.jfree.data.time.TimeSeries timeSeries45 = timeSeries38.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43, (java.lang.Number) 10.0f);
        timeSeriesDataItem47.setValue((java.lang.Number) (-1.0d));
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException51 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str52 = timePeriodFormatException51.toString();
        boolean boolean53 = timeSeriesDataItem47.equals((java.lang.Object) str52);
        java.lang.Object obj54 = null;
        int int55 = timeSeriesDataItem47.compareTo(obj54);
        java.lang.Number number56 = timeSeriesDataItem47.getValue();
        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass59 = timeZone58.getClass();
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass59);
        timeSeries60.setDescription("");
        timeSeries60.setMaximumItemCount((int) (byte) 0);
        java.lang.String str65 = timeSeries60.getDescription();
        boolean boolean66 = timeSeriesDataItem47.equals((java.lang.Object) timeSeries60);
        int int67 = timeSeries60.getMaximumItemCount();
        java.util.Collection collection68 = timeSeries34.getTimePeriodsUniqueToOtherSeries(timeSeries60);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2019 + "'", int29 == 2019);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(number32);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeSeries45);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str52.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + (-1.0d) + "'", number56.equals((-1.0d)));
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "" + "'", str65.equals(""));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNotNull(collection68);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date7 = fixedMillisecond6.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        boolean boolean11 = timeSeries3.getNotify();
        timeSeries3.setDescription("2019");
        int int14 = timeSeries3.getMaximumItemCount();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        long long17 = month15.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month15.next();
        long long19 = month15.getSerialIndex();
        java.lang.Number number20 = null;
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month15, number20, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of sun.util.calendar.ZoneInfo.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 24234L + "'", long17 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 24234L + "'", long19 == 24234L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        java.lang.Class class6 = timeSeries3.getTimePeriodClass();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass9 = timeZone8.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass9);
        timeSeries10.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date14 = fixedMillisecond13.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date16 = fixedMillisecond15.getTime();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        boolean boolean18 = timeSeries17.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries17.addPropertyChangeListener(propertyChangeListener19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date22 = fixedMillisecond21.getTime();
        java.util.Date date23 = fixedMillisecond21.getTime();
        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date23, timeZone24);
        org.jfree.data.time.SerialDate serialDate26 = day25.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = day25.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries17.addOrUpdate(regularTimePeriod27, (java.lang.Number) 1560189785801L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date31 = fixedMillisecond30.getTime();
        java.util.Date date32 = fixedMillisecond30.getTime();
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
        org.jfree.data.time.SerialDate serialDate35 = day34.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = day34.next();
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass39 = timeZone38.getClass();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass39);
        java.beans.PropertyChangeListener propertyChangeListener41 = null;
        timeSeries40.removePropertyChangeListener(propertyChangeListener41);
        java.lang.String str43 = timeSeries40.getDomainDescription();
        timeSeries40.clear();
        timeSeries40.setNotify(true);
        java.lang.Object obj47 = timeSeries40.clone();
        int int48 = day34.compareTo((java.lang.Object) timeSeries40);
        org.jfree.data.time.SerialDate serialDate49 = day34.getSerialDate();
        int int50 = day34.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries17.getDataItem((org.jfree.data.time.RegularTimePeriod) day34);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day34, 0.0d);
        java.lang.String str54 = timeSeries3.getDomainDescription();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Time" + "'", str43.equals("Time"));
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 6 + "'", int50 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertNull(timeSeriesDataItem53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Time" + "'", str54.equals("Time"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        java.util.Date date2 = fixedMillisecond0.getTime();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2, timeZone3);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass9 = timeZone8.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass9);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries10.removePropertyChangeListener(propertyChangeListener11);
        java.lang.String str13 = timeSeries10.getDomainDescription();
        timeSeries10.clear();
        timeSeries10.setNotify(true);
        java.lang.Object obj17 = timeSeries10.clone();
        int int18 = day4.compareTo((java.lang.Object) timeSeries10);
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass21 = timeZone20.getClass();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass21);
        timeSeries22.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date26 = fixedMillisecond25.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date28 = fixedMillisecond27.getTime();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        boolean boolean30 = timeSeries29.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries29.addPropertyChangeListener(propertyChangeListener31);
        boolean boolean33 = day4.equals((java.lang.Object) propertyChangeListener31);
        int int34 = day4.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
//        timeSeries3.setDescription("");
//        java.lang.Object obj6 = timeSeries3.clone();
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
//        java.lang.Object obj8 = null;
//        boolean boolean9 = year7.equals(obj8);
//        int int10 = year7.getYear();
//        int int11 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass14 = timeZone13.getClass();
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass14);
//        java.beans.PropertyChangeListener propertyChangeListener16 = null;
//        timeSeries15.removePropertyChangeListener(propertyChangeListener16);
//        int int18 = timeSeries15.getItemCount();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass21 = timeZone20.getClass();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass21);
//        timeSeries22.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date26 = fixedMillisecond25.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date28 = fixedMillisecond27.getTime();
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass32 = timeZone31.getClass();
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass32);
//        java.util.Collection collection34 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries33);
//        java.util.Collection collection35 = timeSeries15.getTimePeriodsUniqueToOtherSeries(timeSeries33);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date37 = fixedMillisecond36.getTime();
//        java.util.Date date38 = fixedMillisecond36.getTime();
//        timeSeries15.setKey((java.lang.Comparable) fixedMillisecond36);
//        timeSeries15.setDomainDescription("Value");
//        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries3.addAndOrUpdate(timeSeries15);
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass45 = timeZone44.getClass();
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass45);
//        timeSeries46.setDescription("");
//        java.lang.Class class49 = timeSeries46.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date51 = fixedMillisecond50.getTime();
//        java.util.Date date52 = fixedMillisecond50.getTime();
//        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date52, timeZone53);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries46.getDataItem((org.jfree.data.time.RegularTimePeriod) day54);
//        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries3.addAndOrUpdate(timeSeries46);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date58 = fixedMillisecond57.getTime();
//        java.util.Date date59 = fixedMillisecond57.getTime();
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date59, timeZone60);
//        org.jfree.data.time.SerialDate serialDate62 = day61.getSerialDate();
//        int int63 = day61.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries56.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day61, (double) 4);
//        long long66 = day61.getLastMillisecond();
//        java.lang.Object obj67 = null;
//        int int68 = day61.compareTo(obj67);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNotNull(wildcardClass32);
//        org.junit.Assert.assertNotNull(collection34);
//        org.junit.Assert.assertNotNull(collection35);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeSeries42);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNotNull(wildcardClass45);
//        org.junit.Assert.assertNotNull(class49);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNotNull(timeZone53);
//        org.junit.Assert.assertNull(timeSeriesDataItem55);
//        org.junit.Assert.assertNotNull(timeSeries56);
//        org.junit.Assert.assertNotNull(date58);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 2019 + "'", int63 == 2019);
//        org.junit.Assert.assertNull(timeSeriesDataItem65);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1560236399999L + "'", long66 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sunday" + "'", str1.equals("Sunday"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2958465);
        boolean boolean2 = timeSeries1.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date7 = fixedMillisecond6.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 10.0f);
        timeSeriesDataItem12.setValue((java.lang.Number) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeriesDataItem12.getPeriod();
        java.util.Date date16 = regularTimePeriod15.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date16);
        java.lang.String str19 = year18.toString();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int3 = spreadsheetDate2.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date6 = fixedMillisecond5.getTime();
//        java.util.Date date7 = fixedMillisecond5.getTime();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
//        org.jfree.data.time.SerialDate serialDate10 = day9.getSerialDate();
//        java.lang.String str11 = serialDate10.toString();
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate10);
//        int int13 = spreadsheetDate2.compare(serialDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int16 = spreadsheetDate15.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date19 = fixedMillisecond18.getTime();
//        java.util.Date date20 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20, timeZone21);
//        org.jfree.data.time.SerialDate serialDate23 = day22.getSerialDate();
//        java.lang.String str24 = serialDate23.toString();
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate23);
//        int int26 = spreadsheetDate15.compare(serialDate23);
//        int int27 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, (org.jfree.data.time.SerialDate) spreadsheetDate15);
//        org.jfree.data.time.SerialDate serialDate30 = spreadsheetDate15.getFollowingDayOfWeek(4);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-43616) + "'", int13 == (-43616));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 9 + "'", int16 == 9);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10-June-2019" + "'", str24.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-43616) + "'", int26 == (-43616));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate30);
//    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date5 = fixedMillisecond4.getTime();
//        java.util.Date date6 = fixedMillisecond4.getTime();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6, timeZone7);
//        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
//        java.lang.String str10 = serialDate9.toString();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate9);
//        int int12 = spreadsheetDate1.compare(serialDate9);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int15 = spreadsheetDate14.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        java.util.Date date19 = fixedMillisecond17.getTime();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date19, timeZone20);
//        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
//        java.lang.String str23 = serialDate22.toString();
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate22);
//        int int25 = spreadsheetDate14.compare(serialDate22);
//        int int26 = spreadsheetDate14.getDayOfWeek();
//        int int27 = spreadsheetDate14.toSerial();
//        int int28 = spreadsheetDate14.getMonth();
//        boolean boolean29 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date34 = fixedMillisecond33.getTime();
//        java.util.Date date35 = fixedMillisecond33.getTime();
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date35, timeZone36);
//        org.jfree.data.time.SerialDate serialDate38 = day37.getSerialDate();
//        java.lang.String str39 = serialDate38.toString();
//        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addMonths((-460), serialDate38);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date43 = fixedMillisecond42.getTime();
//        java.util.Date date44 = fixedMillisecond42.getTime();
//        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date44, timeZone45);
//        org.jfree.data.time.SerialDate serialDate47 = day46.getSerialDate();
//        java.lang.String str48 = serialDate47.toString();
//        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addMonths((-460), serialDate47);
//        boolean boolean51 = spreadsheetDate31.isInRange(serialDate40, serialDate49, (-457));
//        boolean boolean52 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate31);
//        try {
//            org.jfree.data.time.SerialDate serialDate54 = spreadsheetDate31.getPreviousDayOfWeek(9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-43616) + "'", int12 == (-43616));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-43616) + "'", int25 == (-43616));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3 + "'", int26 == 3);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "10-June-2019" + "'", str39.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNotNull(date43);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(timeZone45);
//        org.junit.Assert.assertNotNull(serialDate47);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "10-June-2019" + "'", str48.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date5 = fixedMillisecond4.getTime();
//        java.util.Date date6 = fixedMillisecond4.getTime();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6, timeZone7);
//        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
//        java.lang.String str10 = serialDate9.toString();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate9);
//        int int12 = spreadsheetDate1.compare(serialDate9);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int15 = spreadsheetDate14.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        java.util.Date date19 = fixedMillisecond17.getTime();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date19, timeZone20);
//        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
//        java.lang.String str23 = serialDate22.toString();
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate22);
//        int int25 = spreadsheetDate14.compare(serialDate22);
//        int int26 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        int int27 = spreadsheetDate1.getDayOfMonth();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass30 = timeZone29.getClass();
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass30);
//        timeSeries31.setDescription("");
//        java.lang.Class class34 = timeSeries31.getTimePeriodClass();
//        boolean boolean35 = spreadsheetDate1.equals((java.lang.Object) class34);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-43616) + "'", int12 == (-43616));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-43616) + "'", int25 == (-43616));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 9 + "'", int27 == 9);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(class34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2, timeZone3);
//        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
//        java.lang.String str6 = serialDate5.toString();
//        org.jfree.data.time.SerialDate serialDate8 = serialDate5.getFollowingDayOfWeek(2);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate8);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        timeSeries3.setKey((java.lang.Comparable) 1560189770680L);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass10 = timeZone9.getClass();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass10);
        timeSeries11.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries11.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.lang.Object obj17 = null;
        boolean boolean18 = year16.equals(obj17);
        int int19 = year16.getYear();
        int int20 = year16.getYear();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        boolean boolean22 = year16.equals((java.lang.Object) year21);
        java.lang.Number number23 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries3.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date26 = fixedMillisecond25.getTime();
        java.util.Date date27 = fixedMillisecond25.getTime();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date27, timeZone28);
        org.jfree.data.time.SerialDate serialDate30 = day29.getSerialDate();
        int int31 = day29.getYear();
        java.util.Date date32 = day29.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day29.next();
        java.lang.Number number34 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) day29);
        int int35 = day29.getYear();
        int int36 = day29.getMonth();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNull(number34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2019 + "'", int35 == 2019);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        long long4 = month0.getFirstMillisecond();
        org.jfree.data.time.Year year5 = month0.getYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        timeSeries3.setKey((java.lang.Comparable) 1560189770680L);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass10 = timeZone9.getClass();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass10);
        timeSeries11.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries11.addPropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.lang.Object obj17 = null;
        boolean boolean18 = year16.equals(obj17);
        int int19 = year16.getYear();
        int int20 = year16.getYear();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        boolean boolean22 = year16.equals((java.lang.Object) year21);
        java.lang.Number number23 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.TimeSeries timeSeries24 = timeSeries3.addAndOrUpdate(timeSeries11);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass27 = timeZone26.getClass();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass27);
        timeSeries28.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date32 = fixedMillisecond31.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date34 = fixedMillisecond33.getTime();
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (java.lang.Number) 10.0f);
        timeSeriesDataItem37.setValue((java.lang.Number) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = timeSeriesDataItem37.getPeriod();
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass43 = timeZone42.getClass();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass43);
        timeSeries44.setDescription("");
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass49 = timeZone48.getClass();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass49);
        timeSeries50.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date54 = fixedMillisecond53.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date56 = fixedMillisecond55.getTime();
        org.jfree.data.time.TimeSeries timeSeries57 = timeSeries50.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond55);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, (java.lang.Number) 10.0f);
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass62 = timeZone61.getClass();
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass62);
        java.beans.PropertyChangeListener propertyChangeListener64 = null;
        timeSeries63.removePropertyChangeListener(propertyChangeListener64);
        int int66 = timeSeries63.getItemCount();
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass69 = timeZone68.getClass();
        org.jfree.data.time.TimeSeries timeSeries70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass69);
        timeSeries70.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date74 = fixedMillisecond73.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date76 = fixedMillisecond75.getTime();
        org.jfree.data.time.TimeSeries timeSeries77 = timeSeries70.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond75);
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass80 = timeZone79.getClass();
        org.jfree.data.time.TimeSeries timeSeries81 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass80);
        java.util.Collection collection82 = timeSeries70.getTimePeriodsUniqueToOtherSeries(timeSeries81);
        java.util.Collection collection83 = timeSeries63.getTimePeriodsUniqueToOtherSeries(timeSeries81);
        org.jfree.data.time.FixedMillisecond fixedMillisecond84 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date85 = fixedMillisecond84.getTime();
        java.util.Date date86 = fixedMillisecond84.getTime();
        timeSeries63.setKey((java.lang.Comparable) fixedMillisecond84);
        org.jfree.data.time.TimeSeries timeSeries88 = timeSeries44.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond55, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond84);
        boolean boolean89 = timeSeriesDataItem37.equals((java.lang.Object) timeSeries88);
        try {
            timeSeries11.add(timeSeriesDataItem37);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of sun.util.calendar.ZoneInfo.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertNotNull(timeSeries24);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(timeSeries57);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(timeZone68);
        org.junit.Assert.assertNotNull(wildcardClass69);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(timeSeries77);
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertNotNull(wildcardClass80);
        org.junit.Assert.assertNotNull(collection82);
        org.junit.Assert.assertNotNull(collection83);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(date86);
        org.junit.Assert.assertNotNull(timeSeries88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timeSeries3.getItemCount();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass9 = timeZone8.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass9);
        timeSeries10.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date14 = fixedMillisecond13.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date16 = fixedMillisecond15.getTime();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass20 = timeZone19.getClass();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass20);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries21);
        java.util.Collection collection23 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date25 = fixedMillisecond24.getTime();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass27 = timeZone26.getClass();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date25, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.previous();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass32 = timeZone31.getClass();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass32);
        timeSeries33.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timeSeries33.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        java.lang.Object obj39 = null;
        boolean boolean40 = year38.equals(obj39);
        int int41 = year38.getYear();
        int int42 = year38.getYear();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        boolean boolean44 = year38.equals((java.lang.Object) year43);
        java.lang.Number number45 = timeSeries33.getValue((org.jfree.data.time.RegularTimePeriod) year38);
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year28, (org.jfree.data.time.RegularTimePeriod) year38);
        java.util.Date date47 = year38.getEnd();
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance(date47);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNull(number45);
        org.junit.Assert.assertNotNull(timeSeries46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(serialDate48);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
//        timeSeries3.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date7 = fixedMillisecond6.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getTime();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        boolean boolean11 = timeSeries3.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date13 = fixedMillisecond12.getTime();
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond12.getFirstMillisecond(calendar14);
//        java.lang.String str16 = fixedMillisecond12.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond12.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (double) 8);
//        java.util.List list20 = timeSeries3.getItems();
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass23 = timeZone22.getClass();
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass23);
//        timeSeries24.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date28 = fixedMillisecond27.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date30 = fixedMillisecond29.getTime();
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass34 = timeZone33.getClass();
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass34);
//        java.util.Collection collection36 = timeSeries24.getTimePeriodsUniqueToOtherSeries(timeSeries35);
//        java.lang.String str37 = timeSeries35.getDescription();
//        timeSeries35.setMaximumItemAge(1560189782905L);
//        java.util.Collection collection40 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries35);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560189853460L + "'", long15 == 1560189853460L);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Mon Jun 10 11:04:13 PDT 2019" + "'", str16.equals("Mon Jun 10 11:04:13 PDT 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertNotNull(list20);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(collection36);
//        org.junit.Assert.assertNull(str37);
//        org.junit.Assert.assertNotNull(collection40);
//    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int3 = spreadsheetDate2.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date6 = fixedMillisecond5.getTime();
//        java.util.Date date7 = fixedMillisecond5.getTime();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
//        org.jfree.data.time.SerialDate serialDate10 = day9.getSerialDate();
//        java.lang.String str11 = serialDate10.toString();
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate10);
//        int int13 = spreadsheetDate2.compare(serialDate10);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int16 = spreadsheetDate15.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date19 = fixedMillisecond18.getTime();
//        java.util.Date date20 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20, timeZone21);
//        org.jfree.data.time.SerialDate serialDate23 = day22.getSerialDate();
//        java.lang.String str24 = serialDate23.toString();
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate23);
//        int int26 = spreadsheetDate15.compare(serialDate23);
//        int int27 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        try {
//            org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(2019, (org.jfree.data.time.SerialDate) spreadsheetDate15);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-43616) + "'", int13 == (-43616));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 9 + "'", int16 == 9);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10-June-2019" + "'", str24.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-43616) + "'", int26 == (-43616));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        java.util.Date date2 = fixedMillisecond0.getTime();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2, timeZone3);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass7 = timeZone6.getClass();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass7);
        timeSeries8.setDescription("");
        java.lang.Class class11 = timeSeries8.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date13 = fixedMillisecond12.getTime();
        java.util.Date date14 = fixedMillisecond12.getTime();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date14, timeZone17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date20 = fixedMillisecond19.getTime();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass22 = timeZone21.getClass();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date20, timeZone21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date25 = fixedMillisecond24.getTime();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass27 = timeZone26.getClass();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date25, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date20, timeZone26);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date2, timeZone26);
        org.jfree.data.time.SerialDate serialDate31 = day30.getSerialDate();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(serialDate31);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date7 = fixedMillisecond6.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 10.0f);
        timeSeriesDataItem12.setValue((java.lang.Number) (-1.0d));
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str17 = timePeriodFormatException16.toString();
        boolean boolean18 = timeSeriesDataItem12.equals((java.lang.Object) str17);
        java.lang.Object obj19 = null;
        int int20 = timeSeriesDataItem12.compareTo(obj19);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass23 = timeZone22.getClass();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass23);
        timeSeries24.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date28 = fixedMillisecond27.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date30 = fixedMillisecond29.getTime();
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        boolean boolean32 = timeSeries31.isEmpty();
        int int33 = timeSeriesDataItem12.compareTo((java.lang.Object) timeSeries31);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        int int35 = timeSeriesDataItem12.compareTo((java.lang.Object) month34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        java.lang.Object obj37 = null;
        boolean boolean38 = year36.equals(obj37);
        int int39 = year36.getYear();
        int int40 = year36.getYear();
        int int42 = year36.compareTo((java.lang.Object) 1577865599999L);
        int int43 = year36.getYear();
        boolean boolean44 = timeSeriesDataItem12.equals((java.lang.Object) year36);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass47 = timeZone46.getClass();
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass47);
        java.beans.PropertyChangeListener propertyChangeListener49 = null;
        timeSeries48.removePropertyChangeListener(propertyChangeListener49);
        java.lang.String str51 = timeSeries48.getDomainDescription();
        timeSeries48.clear();
        timeSeries48.setNotify(true);
        java.lang.Object obj55 = timeSeries48.clone();
        java.util.List list56 = timeSeries48.getItems();
        boolean boolean57 = year36.equals((java.lang.Object) list56);
        java.util.Calendar calendar58 = null;
        try {
            long long59 = year36.getMiddleMillisecond(calendar58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Time" + "'", str51.equals("Time"));
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(list56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        long long4 = month0.getSerialIndex();
        org.jfree.data.time.Year year5 = month0.getYear();
        java.util.Date date6 = month0.getEnd();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = month0.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 24234L + "'", long4 == 24234L);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(date6);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getFirstMillisecond(calendar2);
//        java.lang.String str4 = fixedMillisecond0.toString();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getMiddleMillisecond(calendar5);
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond0.getMiddleMillisecond(calendar7);
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond0.peg(calendar9);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560189854057L + "'", long3 == 1560189854057L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Mon Jun 10 11:04:14 PDT 2019" + "'", str4.equals("Mon Jun 10 11:04:14 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560189854057L + "'", long6 == 1560189854057L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560189854057L + "'", long8 == 1560189854057L);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1560189786995L);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
//        timeSeries3.setDescription("");
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass8 = timeZone7.getClass();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass8);
//        timeSeries9.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date13 = fixedMillisecond12.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date15 = fixedMillisecond14.getTime();
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) 10.0f);
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass21 = timeZone20.getClass();
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass21);
//        java.beans.PropertyChangeListener propertyChangeListener23 = null;
//        timeSeries22.removePropertyChangeListener(propertyChangeListener23);
//        int int25 = timeSeries22.getItemCount();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass28 = timeZone27.getClass();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass28);
//        timeSeries29.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date33 = fixedMillisecond32.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date35 = fixedMillisecond34.getTime();
//        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
//        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass39 = timeZone38.getClass();
//        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass39);
//        java.util.Collection collection41 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries40);
//        java.util.Collection collection42 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries40);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date44 = fixedMillisecond43.getTime();
//        java.util.Date date45 = fixedMillisecond43.getTime();
//        timeSeries22.setKey((java.lang.Comparable) fixedMillisecond43);
//        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass50 = timeZone49.getClass();
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass50);
//        timeSeries51.setDescription("");
//        java.lang.Object obj54 = timeSeries51.clone();
//        java.util.List list55 = timeSeries51.getItems();
//        boolean boolean56 = fixedMillisecond43.equals((java.lang.Object) list55);
//        java.util.Calendar calendar57 = null;
//        long long58 = fixedMillisecond43.getFirstMillisecond(calendar57);
//        java.util.Calendar calendar59 = null;
//        long long60 = fixedMillisecond43.getMiddleMillisecond(calendar59);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(timeSeries36);
//        org.junit.Assert.assertNotNull(timeZone38);
//        org.junit.Assert.assertNotNull(wildcardClass39);
//        org.junit.Assert.assertNotNull(collection41);
//        org.junit.Assert.assertNotNull(collection42);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeSeries47);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//        org.junit.Assert.assertNotNull(obj54);
//        org.junit.Assert.assertNotNull(list55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560189854085L + "'", long58 == 1560189854085L);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560189854085L + "'", long60 == 1560189854085L);
//    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        java.util.Date date5 = fixedMillisecond0.getTime();
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
//        int int7 = year6.getYear();
//        java.lang.String str8 = year6.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560189854385L + "'", long4 == 1560189854385L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timeSeries3.getDomainDescription();
        timeSeries3.clear();
        timeSeries3.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries3.addChangeListener(seriesChangeListener10);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2958465);
        java.util.List list2 = timeSeries1.getItems();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass5);
        timeSeries6.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date12 = fixedMillisecond11.getTime();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 10.0f);
        timeSeriesDataItem15.setValue((java.lang.Number) (-1.0d));
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str20 = timePeriodFormatException19.toString();
        boolean boolean21 = timeSeriesDataItem15.equals((java.lang.Object) str20);
        java.lang.Object obj22 = null;
        int int23 = timeSeriesDataItem15.compareTo(obj22);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass26 = timeZone25.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass26);
        timeSeries27.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date31 = fixedMillisecond30.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date33 = fixedMillisecond32.getTime();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries27.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        boolean boolean35 = timeSeries34.isEmpty();
        int int36 = timeSeriesDataItem15.compareTo((java.lang.Object) timeSeries34);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        int int38 = timeSeriesDataItem15.compareTo((java.lang.Object) month37);
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass40 = timeZone39.getClass();
        java.lang.Class class41 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass40);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, class41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = month37.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month37, (java.lang.Number) 1560189787850L);
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener46);
        java.lang.String str48 = timeSeries1.getRangeDescription();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str20.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(class41);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Value" + "'", str48.equals("Value"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        java.util.Date date4 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.junit.Assert.assertNotNull(serialDate1);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2, timeZone3);
//        long long5 = day4.getLastMillisecond();
//        java.util.Calendar calendar6 = null;
//        try {
//            day4.peg(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        java.lang.Object obj6 = timeSeries3.clone();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.lang.Object obj8 = null;
        boolean boolean9 = year7.equals(obj8);
        int int10 = year7.getYear();
        int int11 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass14 = timeZone13.getClass();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries15.removePropertyChangeListener(propertyChangeListener16);
        int int18 = timeSeries15.getItemCount();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass21 = timeZone20.getClass();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass21);
        timeSeries22.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date26 = fixedMillisecond25.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date28 = fixedMillisecond27.getTime();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass32 = timeZone31.getClass();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass32);
        java.util.Collection collection34 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries33);
        java.util.Collection collection35 = timeSeries15.getTimePeriodsUniqueToOtherSeries(timeSeries33);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date37 = fixedMillisecond36.getTime();
        java.util.Date date38 = fixedMillisecond36.getTime();
        timeSeries15.setKey((java.lang.Comparable) fixedMillisecond36);
        timeSeries15.setDomainDescription("Value");
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date44 = fixedMillisecond43.getTime();
        java.util.Date date45 = fixedMillisecond43.getTime();
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date45, timeZone46);
        org.jfree.data.time.SerialDate serialDate48 = day47.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = day47.next();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day47);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Mon Jun 10 11:04:13 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the year.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
//        timeSeries3.removeAgedItems(false);
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
//        java.lang.Object obj7 = null;
//        boolean boolean8 = year6.equals(obj7);
//        int int9 = year6.getYear();
//        int int10 = year6.getYear();
//        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
//        boolean boolean12 = year6.equals((java.lang.Object) year11);
//        java.lang.Number number13 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year11);
//        java.lang.String str14 = timeSeries3.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date16 = fixedMillisecond15.getTime();
//        java.util.Date date17 = fixedMillisecond15.getTime();
//        java.util.Calendar calendar18 = null;
//        long long19 = fixedMillisecond15.getMiddleMillisecond(calendar18);
//        java.util.Date date20 = fixedMillisecond15.getTime();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries3.getDataItem(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
//        org.junit.Assert.assertNull(number13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560189855056L + "'", long19 == 1560189855056L);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNull(timeSeriesDataItem23);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        timeSeries3.setMaximumItemCount((int) (byte) 0);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass10 = timeZone9.getClass();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass10);
        timeSeries11.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date15 = fixedMillisecond14.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date17 = fixedMillisecond16.getTime();
        org.jfree.data.time.TimeSeries timeSeries18 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond16);
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass21 = timeZone20.getClass();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass21);
        java.util.Collection collection23 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries22);
        java.lang.String str24 = timeSeries22.getDescription();
        java.util.Collection collection25 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries22);
        java.util.Collection collection26 = timeSeries3.getTimePeriods();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeSeries18);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertNotNull(collection26);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("November");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException5);
        java.lang.Throwable[] throwableArray7 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str10 = timePeriodFormatException9.toString();
        java.lang.Throwable[] throwableArray11 = timePeriodFormatException9.getSuppressed();
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("November");
        timePeriodFormatException9.addSuppressed((java.lang.Throwable) seriesException13);
        java.lang.Throwable[] throwableArray15 = timePeriodFormatException9.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass5);
        timeSeries6.setDescription("");
        java.lang.Class class9 = timeSeries6.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date11 = fixedMillisecond10.getTime();
        java.util.Date date12 = fixedMillisecond10.getTime();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date12, timeZone13);
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date12, timeZone15);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10L, "", "", class9);
        timeSeries17.fireSeriesChanged();
        timeSeries17.setMaximumItemCount((int) (byte) 0);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(class9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod16);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date5 = fixedMillisecond4.getTime();
//        java.util.Date date6 = fixedMillisecond4.getTime();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6, timeZone7);
//        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
//        java.lang.String str10 = serialDate9.toString();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate9);
//        int int12 = spreadsheetDate1.compare(serialDate9);
//        java.lang.String str13 = serialDate9.getDescription();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-43616) + "'", int12 == (-43616));
//        org.junit.Assert.assertNull(str13);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        java.lang.Object obj7 = null;
        boolean boolean8 = year6.equals(obj7);
        int int9 = year6.getYear();
        int int10 = year6.getYear();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        boolean boolean12 = year6.equals((java.lang.Object) year11);
        java.lang.Number number13 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year11);
        java.lang.String str14 = timeSeries3.getDescription();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = null;
        try {
            timeSeries3.add(timeSeriesDataItem15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2958465) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(7, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jul" + "'", str2.equals("Jul"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date7 = fixedMillisecond6.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 10.0f);
        timeSeriesDataItem12.setValue((java.lang.Number) (-1.0d));
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str17 = timePeriodFormatException16.toString();
        boolean boolean18 = timeSeriesDataItem12.equals((java.lang.Object) str17);
        java.lang.Object obj19 = null;
        int int20 = timeSeriesDataItem12.compareTo(obj19);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass23 = timeZone22.getClass();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass23);
        timeSeries24.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date28 = fixedMillisecond27.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date30 = fixedMillisecond29.getTime();
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        boolean boolean32 = timeSeries31.isEmpty();
        int int33 = timeSeriesDataItem12.compareTo((java.lang.Object) timeSeries31);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        int int35 = timeSeriesDataItem12.compareTo((java.lang.Object) month34);
        long long36 = month34.getSerialIndex();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 24234L + "'", long36 == 24234L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1560189780818L);
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 1560189780818L + "'", obj2.equals(1560189780818L));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date7 = fixedMillisecond6.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 10.0f);
        timeSeriesDataItem12.setValue((java.lang.Number) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeriesDataItem12.getPeriod();
        java.util.Date date16 = regularTimePeriod15.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date16);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date19 = fixedMillisecond18.getTime();
        java.util.Date date20 = fixedMillisecond18.getTime();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20, timeZone21);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass24 = timeZone23.getClass();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date20, timeZone23);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date16, timeZone23);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getMonth();
//        long long2 = month0.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        java.util.Date date5 = fixedMillisecond3.getTime();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getMiddleMillisecond(calendar6);
//        java.lang.String str8 = fixedMillisecond3.toString();
//        int int9 = month0.compareTo((java.lang.Object) fixedMillisecond3);
//        int int10 = month0.getMonth();
//        long long11 = month0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560189855930L + "'", long7 == 1560189855930L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Mon Jun 10 11:04:15 PDT 2019" + "'", str8.equals("Mon Jun 10 11:04:15 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 24234L + "'", long11 == 24234L);
//    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
//        timeSeries3.setDescription("");
//        java.lang.Object obj6 = timeSeries3.clone();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass9 = timeZone8.getClass();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass9);
//        timeSeries10.setDescription("");
//        java.lang.Class class13 = timeSeries10.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date15 = fixedMillisecond14.getTime();
//        java.util.Date date16 = fixedMillisecond14.getTime();
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date16, timeZone17);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
//        boolean boolean20 = timeSeries3.equals((java.lang.Object) timeSeries10);
//        timeSeries10.clear();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass24 = timeZone23.getClass();
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass24);
//        timeSeries25.setDescription("");
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass30 = timeZone29.getClass();
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass30);
//        timeSeries31.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date35 = fixedMillisecond34.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date37 = fixedMillisecond36.getTime();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries31.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond36);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (java.lang.Number) 10.0f);
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass43 = timeZone42.getClass();
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass43);
//        java.beans.PropertyChangeListener propertyChangeListener45 = null;
//        timeSeries44.removePropertyChangeListener(propertyChangeListener45);
//        int int47 = timeSeries44.getItemCount();
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass50 = timeZone49.getClass();
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass50);
//        timeSeries51.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date55 = fixedMillisecond54.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date57 = fixedMillisecond56.getTime();
//        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries51.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond56);
//        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass61 = timeZone60.getClass();
//        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass61);
//        java.util.Collection collection63 = timeSeries51.getTimePeriodsUniqueToOtherSeries(timeSeries62);
//        java.util.Collection collection64 = timeSeries44.getTimePeriodsUniqueToOtherSeries(timeSeries62);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date66 = fixedMillisecond65.getTime();
//        java.util.Date date67 = fixedMillisecond65.getTime();
//        timeSeries44.setKey((java.lang.Comparable) fixedMillisecond65);
//        org.jfree.data.time.TimeSeries timeSeries69 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond65);
//        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass72 = timeZone71.getClass();
//        org.jfree.data.time.TimeSeries timeSeries73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass72);
//        timeSeries73.setDescription("");
//        java.lang.Object obj76 = timeSeries73.clone();
//        java.util.List list77 = timeSeries73.getItems();
//        boolean boolean78 = fixedMillisecond65.equals((java.lang.Object) list77);
//        long long79 = fixedMillisecond65.getLastMillisecond();
//        int int81 = fixedMillisecond65.compareTo((java.lang.Object) (-1L));
//        java.util.Date date82 = fixedMillisecond65.getTime();
//        java.lang.Object obj83 = null;
//        boolean boolean84 = fixedMillisecond65.equals(obj83);
//        try {
//            timeSeries10.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond65, (java.lang.Number) (-1.0d));
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(class13);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(timeSeriesDataItem19);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertNotNull(timeSeries58);
//        org.junit.Assert.assertNotNull(timeZone60);
//        org.junit.Assert.assertNotNull(wildcardClass61);
//        org.junit.Assert.assertNotNull(collection63);
//        org.junit.Assert.assertNotNull(collection64);
//        org.junit.Assert.assertNotNull(date66);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(timeSeries69);
//        org.junit.Assert.assertNotNull(timeZone71);
//        org.junit.Assert.assertNotNull(wildcardClass72);
//        org.junit.Assert.assertNotNull(obj76);
//        org.junit.Assert.assertNotNull(list77);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 1560189855957L + "'", long79 == 1560189855957L);
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass8 = timeZone7.getClass();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass8);
        timeSeries9.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date13 = fixedMillisecond12.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date15 = fixedMillisecond14.getTime();
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries9.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (java.lang.Number) 10.0f);
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass21 = timeZone20.getClass();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass21);
        java.beans.PropertyChangeListener propertyChangeListener23 = null;
        timeSeries22.removePropertyChangeListener(propertyChangeListener23);
        int int25 = timeSeries22.getItemCount();
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass28 = timeZone27.getClass();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass28);
        timeSeries29.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date33 = fixedMillisecond32.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date35 = fixedMillisecond34.getTime();
        org.jfree.data.time.TimeSeries timeSeries36 = timeSeries29.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond34);
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass39 = timeZone38.getClass();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass39);
        java.util.Collection collection41 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        java.util.Collection collection42 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries40);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date44 = fixedMillisecond43.getTime();
        java.util.Date date45 = fixedMillisecond43.getTime();
        timeSeries22.setKey((java.lang.Comparable) fixedMillisecond43);
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond43);
        int int48 = timeSeries47.getItemCount();
        java.lang.String str49 = timeSeries47.getDescription();
        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass52 = timeZone51.getClass();
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass52);
        timeSeries53.removeAgedItems(false);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        java.lang.Object obj57 = null;
        boolean boolean58 = year56.equals(obj57);
        int int59 = year56.getYear();
        int int60 = year56.getYear();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        boolean boolean62 = year56.equals((java.lang.Object) year61);
        java.lang.Number number63 = timeSeries53.getValue((org.jfree.data.time.RegularTimePeriod) year61);
        timeSeries47.setKey((java.lang.Comparable) year61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = year61.next();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeSeries36);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertNotNull(collection42);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeSeries47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "" + "'", str49.equals(""));
        org.junit.Assert.assertNotNull(timeZone51);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNull(number63);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass4 = timeZone3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f, "Mon Jun 10 11:02:50 PDT 2019", "October", (java.lang.Class) wildcardClass4);
        try {
            java.lang.Number number8 = timeSeries6.getValue((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(0, 2, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass3 = timeZone2.getClass();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date1, timeZone2);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day6.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar3 = null;
//        long long4 = fixedMillisecond0.getMiddleMillisecond(calendar3);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = fixedMillisecond0.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond0.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond0, (double) 1560189811724L);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560189856489L + "'", long4 == 1560189856489L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-460));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date7 = fixedMillisecond6.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        timeSeries3.setDescription("hi!");
        java.util.List list13 = timeSeries3.getItems();
        java.lang.Class class14 = timeSeries3.getTimePeriodClass();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(class14);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        java.lang.Object obj9 = null;
        boolean boolean10 = year8.equals(obj9);
        int int11 = year8.getYear();
        int int12 = year8.getYear();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        boolean boolean14 = year8.equals((java.lang.Object) year13);
        java.lang.Number number15 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year8);
        boolean boolean16 = timeSeries3.isEmpty();
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass19 = timeZone18.getClass();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass19);
        timeSeries20.setDescription("");
        java.lang.Object obj23 = timeSeries20.clone();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year();
        java.lang.Object obj25 = null;
        boolean boolean26 = year24.equals(obj25);
        int int27 = year24.getYear();
        int int28 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) year24);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass31 = timeZone30.getClass();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass31);
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries32.removePropertyChangeListener(propertyChangeListener33);
        int int35 = timeSeries32.getItemCount();
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass38 = timeZone37.getClass();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass38);
        timeSeries39.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date43 = fixedMillisecond42.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date45 = fixedMillisecond44.getTime();
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries39.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond44);
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass49 = timeZone48.getClass();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass49);
        java.util.Collection collection51 = timeSeries39.getTimePeriodsUniqueToOtherSeries(timeSeries50);
        java.util.Collection collection52 = timeSeries32.getTimePeriodsUniqueToOtherSeries(timeSeries50);
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date54 = fixedMillisecond53.getTime();
        java.util.Date date55 = fixedMillisecond53.getTime();
        timeSeries32.setKey((java.lang.Comparable) fixedMillisecond53);
        timeSeries32.setDomainDescription("Value");
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries20.addAndOrUpdate(timeSeries32);
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass62 = timeZone61.getClass();
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass62);
        timeSeries63.setDescription("");
        java.lang.Class class66 = timeSeries63.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond67 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date68 = fixedMillisecond67.getTime();
        java.util.Date date69 = fixedMillisecond67.getTime();
        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(date69, timeZone70);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries63.getDataItem((org.jfree.data.time.RegularTimePeriod) day71);
        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries20.addAndOrUpdate(timeSeries63);
        org.jfree.data.time.FixedMillisecond fixedMillisecond74 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date75 = fixedMillisecond74.getTime();
        java.util.Date date76 = fixedMillisecond74.getTime();
        java.util.TimeZone timeZone77 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day(date76, timeZone77);
        org.jfree.data.time.SerialDate serialDate79 = day78.getSerialDate();
        int int80 = day78.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem82 = timeSeries73.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day78, (double) 4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = day78.next();
        int int84 = day78.getMonth();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day78);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeSeries46);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertNotNull(collection51);
        org.junit.Assert.assertNotNull(collection52);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertNotNull(class66);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertNotNull(timeZone70);
        org.junit.Assert.assertNull(timeSeriesDataItem72);
        org.junit.Assert.assertNotNull(timeSeries73);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(timeZone77);
        org.junit.Assert.assertNotNull(serialDate79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 2019 + "'", int80 == 2019);
        org.junit.Assert.assertNull(timeSeriesDataItem82);
        org.junit.Assert.assertNotNull(regularTimePeriod83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 6 + "'", int84 == 6);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 2958465);
        java.util.List list2 = timeSeries1.getItems();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass5 = timeZone4.getClass();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass5);
        timeSeries6.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date10 = fixedMillisecond9.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date12 = fixedMillisecond11.getTime();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 10.0f);
        timeSeriesDataItem15.setValue((java.lang.Number) (-1.0d));
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException19 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str20 = timePeriodFormatException19.toString();
        boolean boolean21 = timeSeriesDataItem15.equals((java.lang.Object) str20);
        java.lang.Object obj22 = null;
        int int23 = timeSeriesDataItem15.compareTo(obj22);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass26 = timeZone25.getClass();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass26);
        timeSeries27.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date31 = fixedMillisecond30.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date33 = fixedMillisecond32.getTime();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries27.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        boolean boolean35 = timeSeries34.isEmpty();
        int int36 = timeSeriesDataItem15.compareTo((java.lang.Object) timeSeries34);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        int int38 = timeSeriesDataItem15.compareTo((java.lang.Object) month37);
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass40 = timeZone39.getClass();
        java.lang.Class class41 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass40);
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month37, class41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = month37.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month37, (java.lang.Number) 1560189787850L);
        java.beans.PropertyChangeListener propertyChangeListener46 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener46);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener48 = null;
        timeSeries1.removeChangeListener(seriesChangeListener48);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str20.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(class41);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timeSeries3.getItemCount();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass9 = timeZone8.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass9);
        timeSeries10.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date14 = fixedMillisecond13.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date16 = fixedMillisecond15.getTime();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries10.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass20 = timeZone19.getClass();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass20);
        java.util.Collection collection22 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries21);
        java.util.Collection collection23 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date25 = fixedMillisecond24.getTime();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass27 = timeZone26.getClass();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date25, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.previous();
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass32 = timeZone31.getClass();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass32);
        timeSeries33.setDescription("");
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timeSeries33.addPropertyChangeListener(propertyChangeListener36);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        java.lang.Object obj39 = null;
        boolean boolean40 = year38.equals(obj39);
        int int41 = year38.getYear();
        int int42 = year38.getYear();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        boolean boolean44 = year38.equals((java.lang.Object) year43);
        java.lang.Number number45 = timeSeries33.getValue((org.jfree.data.time.RegularTimePeriod) year38);
        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year28, (org.jfree.data.time.RegularTimePeriod) year38);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year38.previous();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent48 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year38);
        java.lang.Object obj49 = seriesChangeEvent48.getSource();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeSeries17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2019 + "'", int41 == 2019);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2019 + "'", int42 == 2019);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNull(number45);
        org.junit.Assert.assertNotNull(timeSeries46);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(obj49);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Last");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getSerialIndex();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 24234L + "'", long1 == 24234L);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        java.util.Date date2 = fixedMillisecond0.getTime();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2, timeZone3);
        java.lang.Class<?> wildcardClass5 = date2.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date7 = fixedMillisecond6.getTime();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass9 = timeZone8.getClass();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date7, timeZone8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date7);
        int int13 = year11.compareTo((java.lang.Object) 9);
        java.util.Date date14 = year11.getStart();
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date2, timeZone15);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        java.lang.Object obj6 = timeSeries3.clone();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        java.lang.Object obj8 = null;
        boolean boolean9 = year7.equals(obj8);
        int int10 = year7.getYear();
        int int11 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year7);
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass14 = timeZone13.getClass();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timeSeries15.removePropertyChangeListener(propertyChangeListener16);
        int int18 = timeSeries15.getItemCount();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass21 = timeZone20.getClass();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass21);
        timeSeries22.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date26 = fixedMillisecond25.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date28 = fixedMillisecond27.getTime();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass32 = timeZone31.getClass();
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass32);
        java.util.Collection collection34 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries33);
        java.util.Collection collection35 = timeSeries15.getTimePeriodsUniqueToOtherSeries(timeSeries33);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date37 = fixedMillisecond36.getTime();
        java.util.Date date38 = fixedMillisecond36.getTime();
        timeSeries15.setKey((java.lang.Comparable) fixedMillisecond36);
        timeSeries15.setDomainDescription("Value");
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries3.addAndOrUpdate(timeSeries15);
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timeSeries42.removePropertyChangeListener(propertyChangeListener43);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeSeries42);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(9999);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        java.util.Date date0 = null;
//        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass3 = timeZone2.getClass();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass3);
//        timeSeries4.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date10 = fixedMillisecond9.getTime();
//        org.jfree.data.time.TimeSeries timeSeries11 = timeSeries4.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) 10.0f);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond9.getFirstMillisecond(calendar14);
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond9.getMiddleMillisecond(calendar16);
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass22 = timeZone21.getClass();
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass22);
//        timeSeries23.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date27 = fixedMillisecond26.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date29 = fixedMillisecond28.getTime();
//        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond28);
//        boolean boolean31 = timeSeries30.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener32 = null;
//        timeSeries30.addPropertyChangeListener(propertyChangeListener32);
//        java.lang.Class<?> wildcardClass34 = timeSeries30.getClass();
//        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond9, "October", "Mon Jun 10 11:02:50 PDT 2019", (java.lang.Class) wildcardClass34);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date37 = fixedMillisecond36.getTime();
//        java.util.Date date38 = fixedMillisecond36.getTime();
//        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date38, timeZone39);
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass43 = timeZone42.getClass();
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass43);
//        timeSeries44.setDescription("");
//        java.lang.Class class47 = timeSeries44.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date49 = fixedMillisecond48.getTime();
//        java.util.Date date50 = fixedMillisecond48.getTime();
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date50, timeZone51);
//        java.util.TimeZone timeZone53 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date50, timeZone53);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date56 = fixedMillisecond55.getTime();
//        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass58 = timeZone57.getClass();
//        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date56, timeZone57);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date61 = fixedMillisecond60.getTime();
//        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass63 = timeZone62.getClass();
//        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date61, timeZone62);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = org.jfree.data.time.RegularTimePeriod.createInstance(class47, date56, timeZone62);
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date38, timeZone62);
//        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass34, date38, timeZone67);
//        try {
//            org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date0, timeZone67);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeSeries11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560189858100L + "'", long15 == 1560189858100L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560189858100L + "'", long17 == 1560189858100L);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNotNull(wildcardClass22);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeSeries30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
//        org.junit.Assert.assertNotNull(wildcardClass34);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(date38);
//        org.junit.Assert.assertNotNull(timeZone39);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertNotNull(class47);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNull(regularTimePeriod54);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertNotNull(timeZone57);
//        org.junit.Assert.assertNotNull(wildcardClass58);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(timeZone62);
//        org.junit.Assert.assertNotNull(wildcardClass63);
//        org.junit.Assert.assertNull(regularTimePeriod65);
//        org.junit.Assert.assertNotNull(timeZone67);
//        org.junit.Assert.assertNull(regularTimePeriod68);
//    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date5 = fixedMillisecond4.getTime();
//        java.util.Date date6 = fixedMillisecond4.getTime();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6, timeZone7);
//        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
//        java.lang.String str10 = serialDate9.toString();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate9);
//        int int12 = spreadsheetDate1.compare(serialDate9);
//        int int13 = spreadsheetDate1.getDayOfWeek();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        java.util.Date date19 = fixedMillisecond17.getTime();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date19, timeZone20);
//        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
//        java.lang.String str23 = serialDate22.toString();
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths((-460), serialDate22);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date27 = fixedMillisecond26.getTime();
//        java.util.Date date28 = fixedMillisecond26.getTime();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date28, timeZone29);
//        org.jfree.data.time.SerialDate serialDate31 = day30.getSerialDate();
//        java.lang.String str32 = serialDate31.toString();
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addMonths((-460), serialDate31);
//        boolean boolean35 = spreadsheetDate15.isInRange(serialDate24, serialDate33, (-457));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date39 = fixedMillisecond38.getTime();
//        java.util.Date date40 = fixedMillisecond38.getTime();
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date40, timeZone41);
//        org.jfree.data.time.SerialDate serialDate43 = day42.getSerialDate();
//        java.lang.String str44 = serialDate43.toString();
//        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays((int) (short) 100, serialDate43);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date47 = fixedMillisecond46.getTime();
//        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass49 = timeZone48.getClass();
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date47, timeZone48);
//        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.createInstance(date47);
//        org.jfree.data.time.SerialDate serialDate52 = serialDate45.getEndOfCurrentMonth(serialDate51);
//        org.jfree.data.time.SerialDate serialDate54 = serialDate51.getNearestDayOfWeek(4);
//        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addDays((int) (short) 0, serialDate54);
//        java.lang.String str56 = serialDate55.getDescription();
//        boolean boolean57 = spreadsheetDate15.isOnOrBefore(serialDate55);
//        int int58 = spreadsheetDate15.getDayOfWeek();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate60 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int61 = spreadsheetDate60.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond63 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date64 = fixedMillisecond63.getTime();
//        java.util.Date date65 = fixedMillisecond63.getTime();
//        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date65, timeZone66);
//        org.jfree.data.time.SerialDate serialDate68 = day67.getSerialDate();
//        java.lang.String str69 = serialDate68.toString();
//        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate68);
//        int int71 = spreadsheetDate60.compare(serialDate68);
//        boolean boolean72 = spreadsheetDate15.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate60);
//        int int73 = spreadsheetDate1.compare((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-43616) + "'", int12 == (-43616));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "10-June-2019" + "'", str44.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(timeZone48);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertNull(str56);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 3 + "'", int58 == 3);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 9 + "'", int61 == 9);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(timeZone66);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "10-June-2019" + "'", str69.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate70);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-43616) + "'", int71 == (-43616));
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        java.lang.Object obj6 = timeSeries3.clone();
        java.util.List list7 = timeSeries3.getItems();
        timeSeries3.setMaximumItemCount(9999);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date7 = fixedMillisecond6.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        timeSeries3.setDescription("hi!");
        java.util.List list13 = timeSeries3.getItems();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        java.lang.Object obj6 = timeSeries3.clone();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass9 = timeZone8.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass9);
        timeSeries10.setDescription("");
        java.lang.Class class13 = timeSeries10.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date15 = fixedMillisecond14.getTime();
        java.util.Date date16 = fixedMillisecond14.getTime();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date16, timeZone17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        boolean boolean20 = timeSeries3.equals((java.lang.Object) timeSeries10);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass23 = timeZone22.getClass();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass23);
        timeSeries24.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date28 = fixedMillisecond27.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date30 = fixedMillisecond29.getTime();
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (java.lang.Number) 10.0f);
        timeSeriesDataItem33.setValue((java.lang.Number) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = timeSeriesDataItem33.getPeriod();
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass39 = timeZone38.getClass();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass39);
        timeSeries40.setDescription("");
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass45 = timeZone44.getClass();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass45);
        timeSeries46.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date50 = fixedMillisecond49.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond51 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date52 = fixedMillisecond51.getTime();
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries46.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond51);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51, (java.lang.Number) 10.0f);
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass58 = timeZone57.getClass();
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass58);
        java.beans.PropertyChangeListener propertyChangeListener60 = null;
        timeSeries59.removePropertyChangeListener(propertyChangeListener60);
        int int62 = timeSeries59.getItemCount();
        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass65 = timeZone64.getClass();
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass65);
        timeSeries66.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date70 = fixedMillisecond69.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond71 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date72 = fixedMillisecond71.getTime();
        org.jfree.data.time.TimeSeries timeSeries73 = timeSeries66.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond69, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond71);
        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass76 = timeZone75.getClass();
        org.jfree.data.time.TimeSeries timeSeries77 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass76);
        java.util.Collection collection78 = timeSeries66.getTimePeriodsUniqueToOtherSeries(timeSeries77);
        java.util.Collection collection79 = timeSeries59.getTimePeriodsUniqueToOtherSeries(timeSeries77);
        org.jfree.data.time.FixedMillisecond fixedMillisecond80 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date81 = fixedMillisecond80.getTime();
        java.util.Date date82 = fixedMillisecond80.getTime();
        timeSeries59.setKey((java.lang.Comparable) fixedMillisecond80);
        org.jfree.data.time.TimeSeries timeSeries84 = timeSeries40.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond51, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond80);
        boolean boolean85 = timeSeriesDataItem33.equals((java.lang.Object) timeSeries84);
        boolean boolean87 = timeSeriesDataItem33.equals((java.lang.Object) 1559372400000L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod88 = timeSeriesDataItem33.getPeriod();
        try {
            timeSeries3.add(timeSeriesDataItem33, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of sun.util.calendar.ZoneInfo.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(timeZone64);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(timeSeries73);
        org.junit.Assert.assertNotNull(timeZone75);
        org.junit.Assert.assertNotNull(wildcardClass76);
        org.junit.Assert.assertNotNull(collection78);
        org.junit.Assert.assertNotNull(collection79);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertNotNull(timeSeries84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod88);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        java.util.Date date5 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5, timeZone6);
//        org.jfree.data.time.SerialDate serialDate8 = day7.getSerialDate();
//        java.lang.String str9 = serialDate8.toString();
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addMonths((-460), serialDate8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date13 = fixedMillisecond12.getTime();
//        java.util.Date date14 = fixedMillisecond12.getTime();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
//        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
//        java.lang.String str18 = serialDate17.toString();
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths((-460), serialDate17);
//        boolean boolean21 = spreadsheetDate1.isInRange(serialDate10, serialDate19, (-457));
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate23 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int24 = spreadsheetDate23.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date27 = fixedMillisecond26.getTime();
//        java.util.Date date28 = fixedMillisecond26.getTime();
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date28, timeZone29);
//        org.jfree.data.time.SerialDate serialDate31 = day30.getSerialDate();
//        java.lang.String str32 = serialDate31.toString();
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate31);
//        int int34 = spreadsheetDate23.compare(serialDate31);
//        int int35 = spreadsheetDate23.getDayOfWeek();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date40 = fixedMillisecond39.getTime();
//        java.util.Date date41 = fixedMillisecond39.getTime();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date41, timeZone42);
//        org.jfree.data.time.SerialDate serialDate44 = day43.getSerialDate();
//        java.lang.String str45 = serialDate44.toString();
//        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addMonths((-460), serialDate44);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date49 = fixedMillisecond48.getTime();
//        java.util.Date date50 = fixedMillisecond48.getTime();
//        java.util.TimeZone timeZone51 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date50, timeZone51);
//        org.jfree.data.time.SerialDate serialDate53 = day52.getSerialDate();
//        java.lang.String str54 = serialDate53.toString();
//        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addMonths((-460), serialDate53);
//        boolean boolean57 = spreadsheetDate37.isInRange(serialDate46, serialDate55, (-457));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date61 = fixedMillisecond60.getTime();
//        java.util.Date date62 = fixedMillisecond60.getTime();
//        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date62, timeZone63);
//        org.jfree.data.time.SerialDate serialDate65 = day64.getSerialDate();
//        java.lang.String str66 = serialDate65.toString();
//        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.addDays((int) (short) 100, serialDate65);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date69 = fixedMillisecond68.getTime();
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass71 = timeZone70.getClass();
//        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(date69, timeZone70);
//        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.createInstance(date69);
//        org.jfree.data.time.SerialDate serialDate74 = serialDate67.getEndOfCurrentMonth(serialDate73);
//        org.jfree.data.time.SerialDate serialDate76 = serialDate73.getNearestDayOfWeek(4);
//        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.addDays((int) (short) 0, serialDate76);
//        java.lang.String str78 = serialDate77.getDescription();
//        boolean boolean79 = spreadsheetDate37.isOnOrBefore(serialDate77);
//        int int80 = spreadsheetDate23.compare((org.jfree.data.time.SerialDate) spreadsheetDate37);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond81 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date82 = fixedMillisecond81.getTime();
//        java.util.Date date83 = fixedMillisecond81.getTime();
//        java.util.TimeZone timeZone84 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day(date83, timeZone84);
//        org.jfree.data.time.SerialDate serialDate86 = day85.getSerialDate();
//        java.lang.String str87 = serialDate86.getDescription();
//        boolean boolean88 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate23, serialDate86);
//        int int89 = spreadsheetDate1.getYYYY();
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10-June-2019" + "'", str18.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 9 + "'", int24 == 9);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-43616) + "'", int34 == (-43616));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 3 + "'", int35 == 3);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "10-June-2019" + "'", str45.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(timeZone51);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "10-June-2019" + "'", str54.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(timeZone63);
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "10-June-2019" + "'", str66.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertNotNull(wildcardClass71);
//        org.junit.Assert.assertNotNull(serialDate73);
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertNotNull(serialDate76);
//        org.junit.Assert.assertNotNull(serialDate77);
//        org.junit.Assert.assertNull(str78);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertNotNull(date83);
//        org.junit.Assert.assertNotNull(timeZone84);
//        org.junit.Assert.assertNotNull(serialDate86);
//        org.junit.Assert.assertNull(str87);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1900 + "'", int89 == 1900);
//    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        java.util.Date date5 = fixedMillisecond3.getTime();
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5, timeZone6);
//        org.jfree.data.time.SerialDate serialDate8 = day7.getSerialDate();
//        java.lang.String str9 = serialDate8.toString();
//        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addMonths((-460), serialDate8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date13 = fixedMillisecond12.getTime();
//        java.util.Date date14 = fixedMillisecond12.getTime();
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
//        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
//        java.lang.String str18 = serialDate17.toString();
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addMonths((-460), serialDate17);
//        boolean boolean21 = spreadsheetDate1.isInRange(serialDate10, serialDate19, (-457));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date25 = fixedMillisecond24.getTime();
//        java.util.Date date26 = fixedMillisecond24.getTime();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date26, timeZone27);
//        org.jfree.data.time.SerialDate serialDate29 = day28.getSerialDate();
//        java.lang.String str30 = serialDate29.toString();
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addDays((int) (short) 100, serialDate29);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date33 = fixedMillisecond32.getTime();
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass35 = timeZone34.getClass();
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date33, timeZone34);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date33);
//        org.jfree.data.time.SerialDate serialDate38 = serialDate31.getEndOfCurrentMonth(serialDate37);
//        org.jfree.data.time.SerialDate serialDate40 = serialDate37.getNearestDayOfWeek(4);
//        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addDays((int) (short) 0, serialDate40);
//        java.lang.String str42 = serialDate41.getDescription();
//        boolean boolean43 = spreadsheetDate1.isOnOrBefore(serialDate41);
//        int int44 = spreadsheetDate1.getDayOfWeek();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate46 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int47 = spreadsheetDate46.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date50 = fixedMillisecond49.getTime();
//        java.util.Date date51 = fixedMillisecond49.getTime();
//        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date51, timeZone52);
//        org.jfree.data.time.SerialDate serialDate54 = day53.getSerialDate();
//        java.lang.String str55 = serialDate54.toString();
//        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate54);
//        int int57 = spreadsheetDate46.compare(serialDate54);
//        boolean boolean58 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate46);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond61 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date62 = fixedMillisecond61.getTime();
//        java.util.Date date63 = fixedMillisecond61.getTime();
//        java.util.TimeZone timeZone64 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date63, timeZone64);
//        org.jfree.data.time.SerialDate serialDate66 = day65.getSerialDate();
//        java.lang.String str67 = serialDate66.toString();
//        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.addDays((int) (short) 100, serialDate66);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date70 = fixedMillisecond69.getTime();
//        java.util.TimeZone timeZone71 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass72 = timeZone71.getClass();
//        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date70, timeZone71);
//        org.jfree.data.time.SerialDate serialDate74 = org.jfree.data.time.SerialDate.createInstance(date70);
//        org.jfree.data.time.SerialDate serialDate75 = serialDate68.getEndOfCurrentMonth(serialDate74);
//        org.jfree.data.time.SerialDate serialDate76 = org.jfree.data.time.SerialDate.addMonths((-460), serialDate75);
//        java.lang.String str77 = serialDate76.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond80 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date81 = fixedMillisecond80.getTime();
//        java.util.Date date82 = fixedMillisecond80.getTime();
//        java.util.TimeZone timeZone83 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day84 = new org.jfree.data.time.Day(date82, timeZone83);
//        org.jfree.data.time.SerialDate serialDate85 = day84.getSerialDate();
//        java.lang.String str86 = serialDate85.toString();
//        org.jfree.data.time.SerialDate serialDate87 = org.jfree.data.time.SerialDate.addDays((int) (short) 100, serialDate85);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond88 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date89 = fixedMillisecond88.getTime();
//        java.util.TimeZone timeZone90 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass91 = timeZone90.getClass();
//        org.jfree.data.time.Year year92 = new org.jfree.data.time.Year(date89, timeZone90);
//        org.jfree.data.time.SerialDate serialDate93 = org.jfree.data.time.SerialDate.createInstance(date89);
//        org.jfree.data.time.SerialDate serialDate94 = serialDate87.getEndOfCurrentMonth(serialDate93);
//        org.jfree.data.time.SerialDate serialDate95 = org.jfree.data.time.SerialDate.addMonths((-460), serialDate94);
//        java.lang.String str96 = serialDate95.toString();
//        org.jfree.data.time.SerialDate serialDate97 = serialDate76.getEndOfCurrentMonth(serialDate95);
//        boolean boolean98 = spreadsheetDate1.isOnOrBefore(serialDate76);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10-June-2019" + "'", str9.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10-June-2019" + "'", str18.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNull(str42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 3 + "'", int44 == 3);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 9 + "'", int47 == 9);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertNotNull(date51);
//        org.junit.Assert.assertNotNull(timeZone52);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "10-June-2019" + "'", str55.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-43616) + "'", int57 == (-43616));
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(date62);
//        org.junit.Assert.assertNotNull(date63);
//        org.junit.Assert.assertNotNull(timeZone64);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "10-June-2019" + "'", str67.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertNotNull(date70);
//        org.junit.Assert.assertNotNull(timeZone71);
//        org.junit.Assert.assertNotNull(wildcardClass72);
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertNotNull(serialDate75);
//        org.junit.Assert.assertNotNull(serialDate76);
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "28-February-1981" + "'", str77.equals("28-February-1981"));
//        org.junit.Assert.assertNotNull(date81);
//        org.junit.Assert.assertNotNull(date82);
//        org.junit.Assert.assertNotNull(timeZone83);
//        org.junit.Assert.assertNotNull(serialDate85);
//        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "10-June-2019" + "'", str86.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate87);
//        org.junit.Assert.assertNotNull(date89);
//        org.junit.Assert.assertNotNull(timeZone90);
//        org.junit.Assert.assertNotNull(wildcardClass91);
//        org.junit.Assert.assertNotNull(serialDate93);
//        org.junit.Assert.assertNotNull(serialDate94);
//        org.junit.Assert.assertNotNull(serialDate95);
//        org.junit.Assert.assertTrue("'" + str96 + "' != '" + "28-February-1981" + "'", str96.equals("28-February-1981"));
//        org.junit.Assert.assertNotNull(serialDate97);
//        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + true + "'", boolean98 == true);
//    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2, timeZone3);
//        long long5 = day4.getLastMillisecond();
//        int int6 = day4.getYear();
//        long long7 = day4.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day4.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day4.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day4.previous();
//        java.lang.String str11 = day4.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar1 = null;
//        fixedMillisecond0.peg(calendar1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        java.util.Date date5 = fixedMillisecond3.getTime();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getMiddleMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getTime();
//        boolean boolean9 = fixedMillisecond0.equals((java.lang.Object) date8);
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass14 = timeZone13.getClass();
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
//        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0f, "Mon Jun 10 11:02:50 PDT 2019", "October", (java.lang.Class) wildcardClass14);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int19 = spreadsheetDate18.getDayOfMonth();
//        int int20 = spreadsheetDate18.getDayOfMonth();
//        java.util.Date date21 = spreadsheetDate18.toDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date23 = fixedMillisecond22.getTime();
//        java.util.Date date24 = fixedMillisecond22.getTime();
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date24, timeZone25);
//        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass29 = timeZone28.getClass();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass29);
//        timeSeries30.setDescription("");
//        java.lang.Class class33 = timeSeries30.getTimePeriodClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date35 = fixedMillisecond34.getTime();
//        java.util.Date date36 = fixedMillisecond34.getTime();
//        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date36, timeZone37);
//        java.util.TimeZone timeZone39 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date36, timeZone39);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date42 = fixedMillisecond41.getTime();
//        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass44 = timeZone43.getClass();
//        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date42, timeZone43);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date47 = fixedMillisecond46.getTime();
//        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass49 = timeZone48.getClass();
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date47, timeZone48);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance(class33, date42, timeZone48);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date24, timeZone48);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date54 = fixedMillisecond53.getTime();
//        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass56 = timeZone55.getClass();
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date54, timeZone55);
//        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date24, timeZone55);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date21, timeZone55);
//        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month(date8, timeZone55);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560189862459L + "'", long7 == 1560189862459L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 9 + "'", int20 == 9);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNotNull(timeZone28);
//        org.junit.Assert.assertNotNull(wildcardClass29);
//        org.junit.Assert.assertNotNull(class33);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNotNull(timeZone37);
//        org.junit.Assert.assertNull(regularTimePeriod40);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeZone43);
//        org.junit.Assert.assertNotNull(wildcardClass44);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertNotNull(timeZone48);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertNull(regularTimePeriod51);
//        org.junit.Assert.assertNotNull(date54);
//        org.junit.Assert.assertNotNull(timeZone55);
//        org.junit.Assert.assertNotNull(wildcardClass56);
//        org.junit.Assert.assertNull(regularTimePeriod59);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((-43616));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        int int1 = month0.getMonth();
//        long long2 = month0.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date4 = fixedMillisecond3.getTime();
//        java.util.Date date5 = fixedMillisecond3.getTime();
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getMiddleMillisecond(calendar6);
//        java.lang.String str8 = fixedMillisecond3.toString();
//        int int9 = month0.compareTo((java.lang.Object) fixedMillisecond3);
//        int int10 = month0.getMonth();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = month0.getLastMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560189863663L + "'", long7 == 1560189863663L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Mon Jun 10 11:04:23 PDT 2019" + "'", str8.equals("Mon Jun 10 11:04:23 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=-1.0]");
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond0.getFirstMillisecond(calendar2);
//        java.lang.String str4 = fixedMillisecond0.toString();
//        java.util.Calendar calendar5 = null;
//        long long6 = fixedMillisecond0.getMiddleMillisecond(calendar5);
//        long long7 = fixedMillisecond0.getLastMillisecond();
//        long long8 = fixedMillisecond0.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560189863681L + "'", long3 == 1560189863681L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Mon Jun 10 11:04:23 PDT 2019" + "'", str4.equals("Mon Jun 10 11:04:23 PDT 2019"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560189863681L + "'", long6 == 1560189863681L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560189863681L + "'", long7 == 1560189863681L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560189863681L + "'", long8 == 1560189863681L);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.String str3 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("Mon Jun 10 11:03:22 PDT 2019");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str9 = timePeriodFormatException8.toString();
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException8.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException12 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str13 = timePeriodFormatException12.toString();
        java.lang.Throwable[] throwableArray14 = timePeriodFormatException12.getSuppressed();
        timePeriodFormatException8.addSuppressed((java.lang.Throwable) timePeriodFormatException12);
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str3.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str9.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str13.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date7 = fixedMillisecond6.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass13 = timeZone12.getClass();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass13);
        timeSeries14.setDescription("");
        java.lang.Object obj17 = timeSeries14.clone();
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass20 = timeZone19.getClass();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass20);
        timeSeries21.setDescription("");
        java.lang.Class class24 = timeSeries21.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date26 = fixedMillisecond25.getTime();
        java.util.Date date27 = fixedMillisecond25.getTime();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date27, timeZone28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) day29);
        boolean boolean31 = timeSeries14.equals((java.lang.Object) timeSeries21);
        timeSeries21.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
        java.util.Collection collection34 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries21);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(class24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(collection34);
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date1 = fixedMillisecond0.getTime();
//        java.util.Date date2 = fixedMillisecond0.getTime();
//        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2, timeZone3);
//        long long5 = day4.getLastMillisecond();
//        int int6 = day4.getYear();
//        long long7 = day4.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day4.previous();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass11 = timeZone10.getClass();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass11);
//        timeSeries12.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date16 = fixedMillisecond15.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, (java.lang.Number) 10.0f);
//        java.util.Calendar calendar22 = null;
//        long long23 = fixedMillisecond17.getFirstMillisecond(calendar22);
//        java.util.Calendar calendar24 = null;
//        long long25 = fixedMillisecond17.getMiddleMillisecond(calendar24);
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass30 = timeZone29.getClass();
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass30);
//        timeSeries31.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date35 = fixedMillisecond34.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date37 = fixedMillisecond36.getTime();
//        org.jfree.data.time.TimeSeries timeSeries38 = timeSeries31.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond34, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond36);
//        boolean boolean39 = timeSeries38.isEmpty();
//        java.beans.PropertyChangeListener propertyChangeListener40 = null;
//        timeSeries38.addPropertyChangeListener(propertyChangeListener40);
//        java.lang.Class<?> wildcardClass42 = timeSeries38.getClass();
//        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond17, "October", "Mon Jun 10 11:02:50 PDT 2019", (java.lang.Class) wildcardClass42);
//        timeSeries43.clear();
//        boolean boolean45 = day4.equals((java.lang.Object) timeSeries43);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(timeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 43626L + "'", long7 == 43626L);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(timeSeries19);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560189863902L + "'", long23 == 1560189863902L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560189863902L + "'", long25 == 1560189863902L);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(timeSeries38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertNotNull(wildcardClass42);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date7 = fixedMillisecond6.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond6.next();
        java.util.Calendar calendar12 = null;
        fixedMillisecond6.peg(calendar12);
        java.util.Date date14 = fixedMillisecond6.getEnd();
        java.util.Date date15 = fixedMillisecond6.getTime();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass4 = timeZone3.getClass();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass4);
        timeSeries5.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date11 = fixedMillisecond10.getTime();
        org.jfree.data.time.TimeSeries timeSeries12 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond10);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond10, (java.lang.Number) 10.0f);
        timeSeriesDataItem14.setValue((java.lang.Number) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeriesDataItem14.getPeriod();
        java.util.Date date18 = regularTimePeriod17.getEnd();
        java.lang.Class<?> wildcardClass19 = regularTimePeriod17.getClass();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int1, (java.lang.Class) wildcardClass19);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeSeries12);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
//        timeSeries3.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date7 = fixedMillisecond6.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getTime();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass13 = timeZone12.getClass();
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass13);
//        java.util.Collection collection15 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
//        timeSeries14.removeAgedItems(false);
//        boolean boolean19 = timeSeries14.equals((java.lang.Object) 1560189779570L);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int22 = spreadsheetDate21.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date25 = fixedMillisecond24.getTime();
//        java.util.Date date26 = fixedMillisecond24.getTime();
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date26, timeZone27);
//        org.jfree.data.time.SerialDate serialDate29 = day28.getSerialDate();
//        java.lang.String str30 = serialDate29.toString();
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate29);
//        int int32 = spreadsheetDate21.compare(serialDate29);
//        int int33 = spreadsheetDate21.getDayOfWeek();
//        int int34 = spreadsheetDate21.getMonth();
//        int int35 = spreadsheetDate21.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(6);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int40 = spreadsheetDate39.getDayOfMonth();
//        int int41 = spreadsheetDate39.getMonth();
//        boolean boolean43 = spreadsheetDate21.isInRange(serialDate37, (org.jfree.data.time.SerialDate) spreadsheetDate39, (int) '#');
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate39);
//        java.util.Date date45 = day44.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day44, (double) 1560189789154L);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertNotNull(collection15);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 9 + "'", int22 == 9);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "10-June-2019" + "'", str30.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-43616) + "'", int32 == (-43616));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 3 + "'", int33 == 3);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 9 + "'", int35 == 9);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 9 + "'", int40 == 9);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNull(timeSeriesDataItem47);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray4 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str8 = timePeriodFormatException7.toString();
        java.lang.Throwable[] throwableArray9 = timePeriodFormatException7.getSuppressed();
        java.lang.Throwable[] throwableArray10 = timePeriodFormatException7.getSuppressed();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException7.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str8.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
//        java.beans.PropertyChangeListener propertyChangeListener4 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
//        timeSeries3.setKey((java.lang.Comparable) 1560189770680L);
//        java.lang.Object obj8 = timeSeries3.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        java.lang.Number number12 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
//        java.util.Date date13 = fixedMillisecond9.getTime();
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560189864650L + "'", long11 == 1560189864650L);
//        org.junit.Assert.assertNull(number12);
//        org.junit.Assert.assertNotNull(date13);
//    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560189786995L);
//        java.util.Date date2 = fixedMillisecond1.getEnd();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int5 = spreadsheetDate4.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date8 = fixedMillisecond7.getTime();
//        java.util.Date date9 = fixedMillisecond7.getTime();
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9, timeZone10);
//        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
//        java.lang.String str13 = serialDate12.toString();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate12);
//        int int15 = spreadsheetDate4.compare(serialDate12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int18 = spreadsheetDate17.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date21 = fixedMillisecond20.getTime();
//        java.util.Date date22 = fixedMillisecond20.getTime();
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22, timeZone23);
//        org.jfree.data.time.SerialDate serialDate25 = day24.getSerialDate();
//        java.lang.String str26 = serialDate25.toString();
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate25);
//        int int28 = spreadsheetDate17.compare(serialDate25);
//        int int29 = spreadsheetDate4.compare((org.jfree.data.time.SerialDate) spreadsheetDate17);
//        spreadsheetDate4.setDescription("28-February-1981");
//        boolean boolean32 = fixedMillisecond1.equals((java.lang.Object) "28-February-1981");
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10-June-2019" + "'", str13.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-43616) + "'", int15 == (-43616));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "10-June-2019" + "'", str26.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-43616) + "'", int28 == (-43616));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        java.util.Date date2 = fixedMillisecond0.getTime();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2, timeZone3);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 10.0f);
        org.jfree.data.time.SerialDate serialDate8 = day4.getSerialDate();
        serialDate8.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int2 = month0.compareTo((java.lang.Object) 0.0f);
        int int3 = month0.getMonth();
        long long4 = month0.getLastMillisecond();
        org.jfree.data.time.Year year5 = month0.getYear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1561964399999L + "'", long4 == 1561964399999L);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Mon Jun 10 11:03:22 PDT 2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        java.lang.Object obj6 = timeSeries3.clone();
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass9 = timeZone8.getClass();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass9);
        timeSeries10.setDescription("");
        java.lang.Class class13 = timeSeries10.getTimePeriodClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date15 = fixedMillisecond14.getTime();
        java.util.Date date16 = fixedMillisecond14.getTime();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date16, timeZone17);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries10.getDataItem((org.jfree.data.time.RegularTimePeriod) day18);
        boolean boolean20 = timeSeries3.equals((java.lang.Object) timeSeries10);
        timeSeries10.clear();
        timeSeries10.delete((-43716), 2147483647);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass27 = timeZone26.getClass();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass27);
        timeSeries28.setDescription("");
        java.lang.Object obj31 = timeSeries28.clone();
        java.util.List list32 = timeSeries28.getItems();
        java.lang.String str33 = timeSeries28.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries28.addPropertyChangeListener(propertyChangeListener34);
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass38 = timeZone37.getClass();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass38);
        java.beans.PropertyChangeListener propertyChangeListener40 = null;
        timeSeries39.removePropertyChangeListener(propertyChangeListener40);
        java.lang.String str42 = timeSeries39.getDomainDescription();
        timeSeries39.clear();
        timeSeries39.setNotify(true);
        java.lang.Object obj46 = timeSeries39.clone();
        java.util.List list47 = timeSeries39.getItems();
        java.lang.String str48 = timeSeries39.getRangeDescription();
        java.util.Collection collection49 = timeSeries28.getTimePeriodsUniqueToOtherSeries(timeSeries39);
        java.util.Collection collection50 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries39);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertNotNull(list32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Time" + "'", str42.equals("Time"));
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertNotNull(list47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Value" + "'", str48.equals("Value"));
        org.junit.Assert.assertNotNull(collection49);
        org.junit.Assert.assertNotNull(collection50);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date7 = fixedMillisecond6.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond6.next();
        java.util.Calendar calendar12 = null;
        fixedMillisecond6.peg(calendar12);
        java.util.Date date14 = fixedMillisecond6.getEnd();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date14);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date7 = fixedMillisecond6.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 10.0f);
        timeSeriesDataItem12.setValue((java.lang.Number) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeriesDataItem12.getPeriod();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass18 = timeZone17.getClass();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass18);
        timeSeries19.setDescription("");
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass24 = timeZone23.getClass();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass24);
        timeSeries25.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date29 = fixedMillisecond28.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date31 = fixedMillisecond30.getTime();
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond28, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 10.0f);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass37 = timeZone36.getClass();
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass37);
        java.beans.PropertyChangeListener propertyChangeListener39 = null;
        timeSeries38.removePropertyChangeListener(propertyChangeListener39);
        int int41 = timeSeries38.getItemCount();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass44 = timeZone43.getClass();
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass44);
        timeSeries45.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date49 = fixedMillisecond48.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date51 = fixedMillisecond50.getTime();
        org.jfree.data.time.TimeSeries timeSeries52 = timeSeries45.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond50);
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass55 = timeZone54.getClass();
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass55);
        java.util.Collection collection57 = timeSeries45.getTimePeriodsUniqueToOtherSeries(timeSeries56);
        java.util.Collection collection58 = timeSeries38.getTimePeriodsUniqueToOtherSeries(timeSeries56);
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date60 = fixedMillisecond59.getTime();
        java.util.Date date61 = fixedMillisecond59.getTime();
        timeSeries38.setKey((java.lang.Comparable) fixedMillisecond59);
        org.jfree.data.time.TimeSeries timeSeries63 = timeSeries19.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond59);
        boolean boolean64 = timeSeriesDataItem12.equals((java.lang.Object) timeSeries63);
        boolean boolean66 = timeSeriesDataItem12.equals((java.lang.Object) 1559372400000L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = timeSeriesDataItem12.getPeriod();
        java.lang.Number number68 = timeSeriesDataItem12.getValue();
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeSeries52);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertNotNull(collection57);
        org.junit.Assert.assertNotNull(collection58);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(timeSeries63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertTrue("'" + number68 + "' != '" + 10 + "'", number68.equals(10));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener4);
        timeSeries3.setKey((java.lang.Comparable) 1560189770680L);
        java.lang.Object obj8 = timeSeries3.clone();
        try {
            timeSeries3.removeAgedItems(1560668399999L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(obj8);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int3 = spreadsheetDate2.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date6 = fixedMillisecond5.getTime();
//        java.util.Date date7 = fixedMillisecond5.getTime();
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
//        org.jfree.data.time.SerialDate serialDate10 = day9.getSerialDate();
//        java.lang.String str11 = serialDate10.toString();
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate10);
//        int int13 = spreadsheetDate2.compare(serialDate10);
//        int int14 = spreadsheetDate2.getDayOfWeek();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date19 = fixedMillisecond18.getTime();
//        java.util.Date date20 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date20, timeZone21);
//        org.jfree.data.time.SerialDate serialDate23 = day22.getSerialDate();
//        java.lang.String str24 = serialDate23.toString();
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addMonths((-460), serialDate23);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date28 = fixedMillisecond27.getTime();
//        java.util.Date date29 = fixedMillisecond27.getTime();
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date29, timeZone30);
//        org.jfree.data.time.SerialDate serialDate32 = day31.getSerialDate();
//        java.lang.String str33 = serialDate32.toString();
//        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addMonths((-460), serialDate32);
//        boolean boolean36 = spreadsheetDate16.isInRange(serialDate25, serialDate34, (-457));
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date40 = fixedMillisecond39.getTime();
//        java.util.Date date41 = fixedMillisecond39.getTime();
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date41, timeZone42);
//        org.jfree.data.time.SerialDate serialDate44 = day43.getSerialDate();
//        java.lang.String str45 = serialDate44.toString();
//        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addDays((int) (short) 100, serialDate44);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date48 = fixedMillisecond47.getTime();
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass50 = timeZone49.getClass();
//        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date48, timeZone49);
//        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance(date48);
//        org.jfree.data.time.SerialDate serialDate53 = serialDate46.getEndOfCurrentMonth(serialDate52);
//        org.jfree.data.time.SerialDate serialDate55 = serialDate52.getNearestDayOfWeek(4);
//        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.addDays((int) (short) 0, serialDate55);
//        java.lang.String str57 = serialDate56.getDescription();
//        boolean boolean58 = spreadsheetDate16.isOnOrBefore(serialDate56);
//        int int59 = spreadsheetDate2.compare((org.jfree.data.time.SerialDate) spreadsheetDate16);
//        try {
//            org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1900, (org.jfree.data.time.SerialDate) spreadsheetDate2);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-43616) + "'", int13 == (-43616));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(timeZone21);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "10-June-2019" + "'", str24.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "10-June-2019" + "'", str33.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "10-June-2019" + "'", str45.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertNotNull(date48);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertNotNull(wildcardClass50);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertNull(str57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date7 = fixedMillisecond6.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 10.0f);
        timeSeriesDataItem12.setValue((java.lang.Number) (-1.0d));
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException16 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str17 = timePeriodFormatException16.toString();
        boolean boolean18 = timeSeriesDataItem12.equals((java.lang.Object) str17);
        java.lang.Object obj19 = null;
        int int20 = timeSeriesDataItem12.compareTo(obj19);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass23 = timeZone22.getClass();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass23);
        timeSeries24.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date28 = fixedMillisecond27.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date30 = fixedMillisecond29.getTime();
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
        boolean boolean32 = timeSeries31.isEmpty();
        int int33 = timeSeriesDataItem12.compareTo((java.lang.Object) timeSeries31);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        int int35 = timeSeriesDataItem12.compareTo((java.lang.Object) month34);
        int int36 = month34.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month34, (java.lang.Number) 1560189813880L);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str17.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
//        timeSeries3.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date7 = fixedMillisecond6.getTime();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date9 = fixedMillisecond8.getTime();
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8, (java.lang.Number) 10.0f);
//        java.util.Calendar calendar13 = null;
//        long long14 = fixedMillisecond8.getFirstMillisecond(calendar13);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond8.getMiddleMillisecond(calendar15);
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond8.getFirstMillisecond(calendar17);
//        long long19 = fixedMillisecond8.getSerialIndex();
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560189866028L + "'", long14 == 1560189866028L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560189866028L + "'", long16 == 1560189866028L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560189866028L + "'", long18 == 1560189866028L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560189866028L + "'", long19 == 1560189866028L);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        long long2 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        long long4 = month0.getSerialIndex();
        org.jfree.data.time.Year year5 = month0.getYear();
        long long6 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 24234L + "'", long4 == 24234L);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24234L + "'", long6 == 24234L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date1 = fixedMillisecond0.getTime();
        java.util.Date date2 = fixedMillisecond0.getTime();
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2, timeZone3);
        org.jfree.data.time.SerialDate serialDate5 = day4.getSerialDate();
        int int6 = day4.getYear();
        java.util.Date date7 = day4.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass11 = timeZone10.getClass();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date9, timeZone10);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date7, timeZone10);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date7 = fixedMillisecond6.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        boolean boolean11 = timeSeries10.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
        java.lang.Number number13 = timeSeries10.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
        java.lang.String str14 = timeSeries10.getRangeDescription();
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass17 = timeZone16.getClass();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass17);
        timeSeries18.removeAgedItems(false);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        java.lang.Object obj22 = null;
        boolean boolean23 = year21.equals(obj22);
        int int24 = year21.getYear();
        int int25 = year21.getYear();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        boolean boolean27 = year21.equals((java.lang.Object) year26);
        java.lang.Number number28 = timeSeries18.getValue((org.jfree.data.time.RegularTimePeriod) year26);
        java.lang.String str29 = timeSeries18.getDescription();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries10.addAndOrUpdate(timeSeries18);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Value" + "'", str14.equals("Value"));
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(timeSeries30);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass2 = timeZone1.getClass();
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass2);
        timeSeries3.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date7 = fixedMillisecond6.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date9 = fixedMillisecond8.getTime();
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond6, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        timeSeries3.setDescription("hi!");
        java.util.List list13 = timeSeries3.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timeSeries3.addChangeListener(seriesChangeListener14);
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass18 = timeZone17.getClass();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass18);
        timeSeries19.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date23 = fixedMillisecond22.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date25 = fixedMillisecond24.getTime();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries19.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (java.lang.Number) 10.0f);
        timeSeriesDataItem28.setValue((java.lang.Number) (-1.0d));
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException32 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str33 = timePeriodFormatException32.toString();
        boolean boolean34 = timeSeriesDataItem28.equals((java.lang.Object) str33);
        java.lang.Object obj35 = null;
        int int36 = timeSeriesDataItem28.compareTo(obj35);
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass39 = timeZone38.getClass();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass39);
        timeSeries40.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date44 = fixedMillisecond43.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond();
        java.util.Date date46 = fixedMillisecond45.getTime();
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries40.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond45);
        boolean boolean48 = timeSeries47.isEmpty();
        int int49 = timeSeriesDataItem28.compareTo((java.lang.Object) timeSeries47);
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
        int int51 = timeSeriesDataItem28.compareTo((java.lang.Object) month50);
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        java.lang.Object obj53 = null;
        boolean boolean54 = year52.equals(obj53);
        int int55 = year52.getYear();
        int int56 = year52.getYear();
        int int58 = year52.compareTo((java.lang.Object) 1577865599999L);
        int int59 = year52.getYear();
        boolean boolean60 = timeSeriesDataItem28.equals((java.lang.Object) year52);
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        java.lang.Class<?> wildcardClass63 = timeZone62.getClass();
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0f), (java.lang.Class) wildcardClass63);
        java.beans.PropertyChangeListener propertyChangeListener65 = null;
        timeSeries64.removePropertyChangeListener(propertyChangeListener65);
        java.lang.String str67 = timeSeries64.getDomainDescription();
        timeSeries64.clear();
        timeSeries64.setNotify(true);
        java.lang.Object obj71 = timeSeries64.clone();
        java.util.List list72 = timeSeries64.getItems();
        boolean boolean73 = year52.equals((java.lang.Object) list72);
        long long74 = year52.getFirstMillisecond();
        int int75 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year52);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str33.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeSeries47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2019 + "'", int55 == 2019);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2019 + "'", int56 == 2019);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2019 + "'", int59 == 2019);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "Time" + "'", str67.equals("Time"));
        org.junit.Assert.assertNotNull(obj71);
        org.junit.Assert.assertNotNull(list72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 1546329600000L + "'", long74 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date5 = fixedMillisecond4.getTime();
//        java.util.Date date6 = fixedMillisecond4.getTime();
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6, timeZone7);
//        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
//        java.lang.String str10 = serialDate9.toString();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate9);
//        int int12 = spreadsheetDate1.compare(serialDate9);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (short) 10);
//        int int15 = spreadsheetDate14.getDayOfMonth();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date18 = fixedMillisecond17.getTime();
//        java.util.Date date19 = fixedMillisecond17.getTime();
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date19, timeZone20);
//        org.jfree.data.time.SerialDate serialDate22 = day21.getSerialDate();
//        java.lang.String str23 = serialDate22.toString();
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate22);
//        int int25 = spreadsheetDate14.compare(serialDate22);
//        int int26 = spreadsheetDate14.getDayOfWeek();
//        int int27 = spreadsheetDate14.toSerial();
//        int int28 = spreadsheetDate14.getMonth();
//        boolean boolean29 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate14);
//        int int30 = spreadsheetDate1.toSerial();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent31 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) spreadsheetDate1);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond();
//        java.util.Date date33 = fixedMillisecond32.getTime();
//        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        java.lang.Class<?> wildcardClass35 = timeZone34.getClass();
//        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date33, timeZone34);
//        long long37 = year36.getMiddleMillisecond();
//        java.lang.Object obj38 = null;
//        boolean boolean39 = year36.equals(obj38);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year36, (double) 1560189768416L);
//        boolean boolean43 = timeSeriesDataItem41.equals((java.lang.Object) 100);
//        boolean boolean44 = spreadsheetDate1.equals((java.lang.Object) 100);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-43616) + "'", int12 == (-43616));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10-June-2019" + "'", str23.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-43616) + "'", int25 == (-43616));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3 + "'", int26 == 3);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone34);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1562097599999L + "'", long37 == 1562097599999L);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//    }
//}

