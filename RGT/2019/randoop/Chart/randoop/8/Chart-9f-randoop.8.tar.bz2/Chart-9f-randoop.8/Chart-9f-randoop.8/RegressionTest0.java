import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(7);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Saturday" + "'", str1.equals("Saturday"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Calendar calendar1 = null;
        try {
            month0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 0, (int) '4', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 10, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test016");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getFirstMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Saturday");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(31, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getMiddleMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        int int2 = day0.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Saturday");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.util.Calendar calendar3 = null;
        try {
            month2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 10, (int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate3);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate11 = serialDate3.getEndOfCurrentMonth(serialDate10);
        try {
            org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) ' ', serialDate11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 100.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        long long5 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(31, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-457) + "'", int1 == (-457));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate3);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate11 = serialDate3.getEndOfCurrentMonth(serialDate10);
        try {
            org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1900, serialDate11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth((int) (short) 100, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test053");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        java.util.Calendar calendar3 = null;
//        try {
//            day0.peg(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4);
        java.util.Calendar calendar7 = null;
        try {
            year6.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        java.util.Date date2 = day1.getEnd();
        java.lang.Class class3 = null;
        java.util.Date date4 = null;
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date4, timeZone5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date2, timeZone5);
        int int9 = year7.compareTo((java.lang.Object) "Saturday");
        try {
            org.jfree.data.time.Month month10 = new org.jfree.data.time.Month((int) (byte) 100, year7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.Comparable comparable0 = null;
        java.lang.Class class3 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries(comparable0, "June 2019", "10-June-2019", class3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4);
        int int8 = year6.compareTo((java.lang.Object) "Saturday");
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year6.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        org.junit.Assert.assertNotNull(strArray0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.lang.Comparable comparable0 = null;
        java.lang.Class class1 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries(comparable0, class1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test060");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43626L + "'", long5 == 43626L);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Saturday");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addYears(6, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) 'a', serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        java.lang.Object obj4 = null;
        boolean boolean5 = day0.equals(obj4);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day0.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        java.lang.String str4 = timeSeries3.getDomainDescription();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date1, timeZone4);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date1);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day7.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((-1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Preceding" + "'", str1.equals("Preceding"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        try {
            timeSeries3.removeAgedItems((long) 10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        long long5 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (byte) 100, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        int int3 = month2.getMonth();
        int int5 = month2.compareTo((java.lang.Object) (-1.0d));
        java.util.Calendar calendar6 = null;
        try {
            month2.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(0, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        long long12 = fixedMillisecond11.getMiddleMillisecond();
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (5) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        try {
            org.jfree.data.time.TimeSeries timeSeries8 = timeSeries3.createCopy((int) (byte) -1, (-457));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate2);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate10 = serialDate2.getEndOfCurrentMonth(serialDate9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate13 = serialDate9.getEndOfCurrentMonth(serialDate12);
        try {
            org.jfree.data.time.SerialDate serialDate15 = serialDate9.getFollowingDayOfWeek((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("10-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.setMaximumItemCount(9999);
        try {
            timeSeries7.delete((int) (byte) 10, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test092");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.previous();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day2.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        timeSeries3.setDescription("10-June-2019");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date9, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year14);
        try {
            java.lang.Number number18 = timeSeries3.getValue(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1900, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate2);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate10 = serialDate2.getEndOfCurrentMonth(serialDate9);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate13 = serialDate9.getEndOfCurrentMonth(serialDate12);
        java.lang.String str14 = serialDate12.getDescription();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate2);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate6 = serialDate3.getEndOfCurrentMonth(serialDate5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
        int int8 = day7.getDayOfMonth();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.clear();
        boolean boolean11 = timeSeries7.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar14 = null;
        fixedMillisecond13.peg(calendar14);
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond13, (java.lang.Number) 1560150000000L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(9, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-460), 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        timeSeries3.setDescription("10-June-2019");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date9, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year14);
        java.util.Calendar calendar17 = null;
        try {
            year14.peg(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(1900, 8, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        int int3 = month2.getYearValue();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month2.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        int int3 = month2.getYearValue();
        int int4 = month2.getYearValue();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month2.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        timeSeries3.clear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test107");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate3);
//    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test108");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int1, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "hi!", class4);
//        try {
//            java.lang.Number number7 = timeSeries5.getValue(7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getMiddleMillisecond(calendar8);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(0, (int) (short) 100, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test111");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int1, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "hi!", class4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = null;
//        try {
//            timeSeries5.delete(regularTimePeriod6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        timeSeries3.setDescription("10-June-2019");
        try {
            timeSeries3.update(10, (java.lang.Number) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate3);
        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getFollowingDayOfWeek(5);
        serialDate4.setDescription("Preceding");
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays(9, serialDate4);
        try {
            org.jfree.data.time.SerialDate serialDate11 = serialDate9.getFollowingDayOfWeek((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getFirstMillisecond();
//        java.lang.Object obj4 = null;
//        boolean boolean5 = day0.equals(obj4);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        timeSeries3.setDescription("org.jfree.data.general.SeriesException: hi!");
        try {
            timeSeries3.setMaximumItemAge((long) (-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'periods' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getStart();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.previous();
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) 6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        long long8 = fixedMillisecond7.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) 1900);
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        timeSeries3.setMaximumItemCount(31);
        try {
            timeSeries3.update(5, (java.lang.Number) 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate5);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate13 = serialDate5.getEndOfCurrentMonth(serialDate12);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate16 = serialDate12.getEndOfCurrentMonth(serialDate15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addYears(4, serialDate16);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 1, serialDate16);
        try {
            org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) 'a', serialDate16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate5);
//        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getFollowingDayOfWeek(5);
//        int int9 = day0.compareTo((java.lang.Object) serialDate8);
//        long long10 = day0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day0.previous();
//        java.util.Calendar calendar12 = null;
//        try {
//            day0.peg(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560193199999L + "'", long10 == 1560193199999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.util.Calendar calendar2 = null;
        try {
            day0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.util.Date date0 = null;
        java.lang.Class class1 = null;
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        java.util.Date date3 = day2.getStart();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.util.Date date7 = day6.getStart();
        java.lang.Class class8 = null;
        java.util.Date date9 = null;
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date9, timeZone10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date7, timeZone10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class1, date3, timeZone10);
        try {
            org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date0, timeZone10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod11);
        org.junit.Assert.assertNull(regularTimePeriod13);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year6.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.clear();
        boolean boolean19 = timeSeries15.getNotify();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.addAndOrUpdate(timeSeries15);
        timeSeries20.setDomainDescription("13-April-2000");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        long long8 = year6.getSerialIndex();
        java.util.Calendar calendar9 = null;
        try {
            year6.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        try {
            timeSeries3.update(2019, (java.lang.Number) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(4, 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        int int3 = month2.getYearValue();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month2.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.general.SeriesException seriesException8 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray9 = seriesException8.getSuppressed();
        boolean boolean10 = spreadsheetDate1.equals((java.lang.Object) throwableArray9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        java.util.List list7 = timeSeries3.getItems();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(list7);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test139");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int1, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "hi!", class4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getStart();
//        java.lang.String str8 = day6.toString();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate11);
//        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getFollowingDayOfWeek(5);
//        int int15 = day6.compareTo((java.lang.Object) serialDate14);
//        org.jfree.data.time.SerialDate serialDate16 = day6.getSerialDate();
//        timeSeries5.setKey((java.lang.Comparable) day6);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.util.Date date19 = day18.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day18, (java.lang.Number) 7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day18.previous();
//        try {
//            timeSeries5.add(regularTimePeriod22, (double) 1900);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        try {
            org.jfree.data.time.TimeSeries timeSeries12 = timeSeries3.createCopy(1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
//        java.lang.Object obj3 = seriesChangeEvent2.getSource();
//        java.lang.String str4 = seriesChangeEvent2.toString();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(obj3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Mon Jun 10 00:00:00 PDT 2019]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=Mon Jun 10 00:00:00 PDT 2019]"));
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond11.next();
        long long13 = fixedMillisecond11.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) 0);
        try {
            timeSeries3.add(timeSeriesDataItem15, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1L));
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + (-1L) + "'", obj2.equals((-1L)));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesChangeEvent[source=Mon Jun 10 00:00:00 PDT 2019]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        timeSeries3.setDescription("10-June-2019");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date9, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year14);
        timeSeries3.setRangeDescription("Preceding");
        org.jfree.data.time.Month month20 = org.jfree.data.time.Month.parseMonth("June 2019");
        int int21 = month20.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries23 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) month20, regularTimePeriod22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'end' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(month20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        long long8 = year6.getSerialIndex();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year6.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate2);
        org.jfree.data.time.SerialDate serialDate5 = serialDate3.getFollowingDayOfWeek(5);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day6.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str5 = seriesException4.toString();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.String str7 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str2.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str5.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str7.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-459) + "'", int1 == (-459));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
        boolean boolean7 = spreadsheetDate1.isOnOrAfter(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = null;
        try {
            boolean boolean9 = spreadsheetDate1.isBefore(serialDate8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        long long6 = timeSeries3.getMaximumItemAge();
        try {
            timeSeries3.delete(31, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) 'a', 0, (-457));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.clear();
        boolean boolean19 = timeSeries15.getNotify();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar23 = null;
        fixedMillisecond22.peg(calendar23);
        long long25 = fixedMillisecond22.getFirstMillisecond();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        java.util.Date date27 = day26.getEnd();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        boolean boolean29 = fixedMillisecond22.equals((java.lang.Object) date27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond31.getLastMillisecond(calendar32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = timeSeries3.getTimePeriod((-457));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(8, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "August" + "'", str2.equals("August"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        timeSeries3.setDescription("org.jfree.data.general.SeriesException: hi!");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = null;
        try {
            timeSeries3.add(regularTimePeriod10, 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.setRangeDescription("");
        timeSeries3.setDomainDescription("Saturday");
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = null;
        try {
            timeSeries3.add(timeSeriesDataItem14, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.setRangeDescription("");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        java.util.Date date15 = null;
        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date15, timeZone16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13, timeZone16);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date13);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date13);
        java.lang.Number number21 = null;
        try {
            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) day20, number21);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNull(regularTimePeriod17);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.setMaximumItemCount(9999);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
        int int21 = year19.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month12, regularTimePeriod22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = null;
        try {
            timeSeries7.add(timeSeriesDataItem24, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeSeries23);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (35) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.clear();
        boolean boolean19 = timeSeries15.getNotify();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        java.util.Date date22 = day21.getStart();
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date22, timeZone25);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date22);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date22);
        boolean boolean30 = timeSeries20.equals((java.lang.Object) date22);
        java.util.TimeZone timeZone31 = null;
        try {
            org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date22, timeZone31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test165");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
//        long long5 = day0.getFirstMillisecond();
//        long long6 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560150000000L + "'", long5 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560150000000L + "'", long6 == 1560150000000L);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("June 2019");
        int int2 = month1.getYearValue();
        long long3 = month1.getLastMillisecond();
        org.junit.Assert.assertNotNull(month1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4);
        int int8 = year6.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        java.lang.String str10 = year6.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year6.previous();
        long long12 = year6.getSerialIndex();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 9, 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid 'day' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        int int3 = month2.getMonth();
        java.lang.String str4 = month2.toString();
        long long5 = month2.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month2.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1559372400000L + "'", long5 == 1559372400000L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            year0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate5);
//        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getFollowingDayOfWeek(5);
//        int int9 = day0.compareTo((java.lang.Object) serialDate8);
//        long long10 = day0.getLastMillisecond();
//        long long11 = day0.getSerialIndex();
//        long long12 = day0.getSerialIndex();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43626L + "'", long12 == 43626L);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.removeChangeListener(seriesChangeListener10);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries7.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        int int3 = month2.getMonth();
        int int5 = month2.compareTo((java.lang.Object) (-1.0d));
        int int6 = month2.getMonth();
        int int7 = month2.getYearValue();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month2.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date1, timeZone4);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date1);
        java.util.TimeZone timeZone8 = null;
        try {
            org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date1, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        timeSeries3.setMaximumItemCount(31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 0.0d, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (short) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) (byte) 1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(2019);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(5, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.removeAgedItems(false);
        try {
            timeSeries3.setMaximumItemCount((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("Preceding");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.setRangeDescription("");
        timeSeries3.setDomainDescription("Saturday");
        timeSeries3.fireSeriesChanged();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
//        timeSeries3.setMaximumItemAge(1L);
//        java.lang.Object obj6 = timeSeries3.clone();
//        boolean boolean7 = timeSeries3.isEmpty();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getStart();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.util.Date date13 = day12.getStart();
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
//        java.lang.String str16 = timeSeries15.getDomainDescription();
//        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
//        timeSeries15.clear();
//        boolean boolean19 = timeSeries15.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.util.Date date22 = day21.getStart();
//        java.lang.Class class23 = null;
//        java.util.Date date24 = null;
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date22, timeZone25);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date22);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date22);
//        boolean boolean30 = timeSeries20.equals((java.lang.Object) date22);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        int int32 = day31.getDayOfMonth();
//        java.lang.Class<?> wildcardClass33 = day31.getClass();
//        timeSeries20.delete((org.jfree.data.time.RegularTimePeriod) day31);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 10 + "'", int32 == 10);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test188");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int1, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "hi!", class4);
//        boolean boolean6 = timeSeries5.getNotify();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        java.util.Date date8 = day7.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 7);
//        java.lang.Number number11 = timeSeriesDataItem10.getValue();
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate14);
//        org.jfree.data.time.SerialDate serialDate17 = serialDate15.getFollowingDayOfWeek(5);
//        int int18 = timeSeriesDataItem10.compareTo((java.lang.Object) 5);
//        java.lang.Object obj19 = timeSeriesDataItem10.clone();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeriesDataItem10.getPeriod();
//        try {
//            timeSeries5.add(timeSeriesDataItem10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 7 + "'", number11.equals(7));
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(obj19);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 7);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day0.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate3);
        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate4);
        java.lang.String str8 = serialDate7.toString();
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "9-July-2833" + "'", str8.equals("9-July-2833"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(4, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = serialDate2.getEndOfCurrentMonth(serialDate6);
        try {
            org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addDays((-457), serialDate6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        java.util.Date date2 = day1.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day1.next();
        java.util.Date date4 = day1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        try {
            org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(8, serialDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day10, class12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.util.Date date15 = day14.getStart();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day14, class16);
        java.lang.String str18 = timeSeries17.getDomainDescription();
        java.util.Collection collection19 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        java.lang.String str20 = timeSeries13.getDomainDescription();
        java.util.Collection collection21 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond23.getLastMillisecond(calendar24);
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond23.getLastMillisecond(calendar26);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond23.getFirstMillisecond(calendar28);
        int int30 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("June 2019");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getStart();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
//        java.lang.String str8 = timeSeries7.getDomainDescription();
//        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        timeSeries7.setMaximumItemCount(9999);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        java.lang.Class class15 = null;
//        java.util.Date date16 = null;
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
//        int int21 = year19.compareTo((java.lang.Object) "Saturday");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month12, regularTimePeriod22);
//        java.lang.Class class24 = timeSeries23.getTimePeriodClass();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        java.util.Date date26 = day25.getStart();
//        java.lang.Class class27 = null;
//        java.util.Date date28 = null;
//        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date26, timeZone29);
//        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date26);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day33.previous();
//        java.lang.String str35 = day33.toString();
//        try {
//            timeSeries23.add((org.jfree.data.time.RegularTimePeriod) day33, (java.lang.Number) 1577865599999L, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertNull(class24);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeZone29);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "10-June-2019" + "'", str35.equals("10-June-2019"));
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addDays(4, serialDate2);
        java.lang.String str4 = serialDate3.toString();
        try {
            org.jfree.data.time.SerialDate serialDate6 = serialDate3.getPreviousDayOfWeek((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "13-April-1900" + "'", str4.equals("13-April-1900"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.clear();
        boolean boolean19 = timeSeries15.getNotify();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.addAndOrUpdate(timeSeries15);
        java.lang.Class class21 = timeSeries3.getTimePeriodClass();
        timeSeries3.setMaximumItemCount((int) '#');
        timeSeries3.fireSeriesChanged();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNull(class21);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 7);
        java.lang.Number number4 = timeSeriesDataItem3.getValue();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getFollowingDayOfWeek(5);
        int int11 = timeSeriesDataItem3.compareTo((java.lang.Object) 5);
        java.lang.Object obj12 = timeSeriesDataItem3.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem3.getPeriod();
        timeSeriesDataItem3.setValue((java.lang.Number) 1559372400000L);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 7 + "'", number4.equals(7));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.clear();
        boolean boolean19 = timeSeries15.getNotify();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.addAndOrUpdate(timeSeries15);
        java.lang.Class class21 = timeSeries15.getTimePeriodClass();
        java.util.Collection collection22 = timeSeries15.getTimePeriods();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeries15.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertNotNull(collection22);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.setMaximumItemCount(9999);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
        int int21 = year19.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month12, regularTimePeriod22);
        java.lang.Class class24 = timeSeries7.getTimePeriodClass();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.util.Date date26 = day25.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day25, (java.lang.Number) 7);
        try {
            timeSeries7.add(timeSeriesDataItem28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNull(class24);
        org.junit.Assert.assertNotNull(date26);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("13-April-1900");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 13-April-1900" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: 13-April-1900"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.setRangeDescription("");
        timeSeries3.setDomainDescription("Saturday");
        boolean boolean14 = timeSeries3.isEmpty();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.util.Date date16 = day15.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
        java.util.Date date18 = day15.getStart();
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day15, (double) 2, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        java.util.List list7 = timeSeries3.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        try {
            org.jfree.data.time.TimeSeries timeSeries12 = timeSeries3.createCopy((int) (byte) 100, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 1560150000000L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.setRangeDescription("");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        int int15 = month14.getMonth();
        int int17 = month14.compareTo((java.lang.Object) (-1.0d));
        timeSeries3.setKey((java.lang.Comparable) int17);
        timeSeries3.setRangeDescription("Saturday");
        try {
            timeSeries3.delete(0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        java.util.Date date3 = day2.getEnd();
        java.lang.Class class4 = null;
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date5, timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date3, timeZone6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getSerialIndex();
        int int11 = month0.compareTo((java.lang.Object) long10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month0.next();
        org.jfree.data.time.Year year13 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
        java.lang.String str15 = year13.toString();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = year13.getFirstMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("June 2019");
        int int2 = month1.getYearValue();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month1.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(month1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((-457));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 7);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day0.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getMiddleMillisecond(calendar3);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate5);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate13 = serialDate5.getEndOfCurrentMonth(serialDate12);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate16 = serialDate12.getEndOfCurrentMonth(serialDate15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addYears(4, serialDate16);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 1, serialDate16);
        try {
            org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1900, serialDate16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        java.util.Date date2 = day1.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date2);
        java.lang.Class class4 = null;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getStart();
        java.lang.Class class11 = null;
        java.util.Date date12 = null;
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date10, timeZone13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone13);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date2, timeZone13);
        try {
            org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(0, year17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNull(regularTimePeriod16);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int9 = spreadsheetDate8.getDayOfMonth();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays(4, serialDate17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate17);
        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getPreviousDayOfWeek(7);
        boolean boolean22 = spreadsheetDate8.isBefore(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int29 = spreadsheetDate28.getDayOfMonth();
        int int30 = spreadsheetDate28.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate33 = spreadsheetDate28.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addDays(4, serialDate37);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate37);
        org.jfree.data.time.SerialDate serialDate41 = serialDate39.getPreviousDayOfWeek(7);
        boolean boolean42 = spreadsheetDate28.isBefore(serialDate41);
        boolean boolean44 = spreadsheetDate8.isInRange(serialDate26, serialDate41, (-457));
        boolean boolean45 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int46 = spreadsheetDate8.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int49 = spreadsheetDate48.getDayOfMonth();
        int int50 = spreadsheetDate48.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate53 = spreadsheetDate48.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate52);
        java.util.Date date54 = spreadsheetDate52.toDate();
        boolean boolean55 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.SerialDate serialDate56 = null;
        try {
            boolean boolean57 = spreadsheetDate52.isOnOrBefore(serialDate56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 9 + "'", int29 == 9);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1900 + "'", int30 == 1900);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 9 + "'", int49 == 9);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1900 + "'", int50 == 1900);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.setDomainDescription("Nearest");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.util.Date date4 = day3.getStart();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date4);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
//        boolean boolean7 = spreadsheetDate1.isOnOrAfter(serialDate6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        java.lang.Class<?> wildcardClass10 = day8.getClass();
//        boolean boolean11 = spreadsheetDate1.equals((java.lang.Object) day8);
//        java.util.Date date12 = spreadsheetDate1.toDate();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date12);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(date12);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.setMaximumItemCount(9999);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
        int int21 = year19.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month12, regularTimePeriod22);
        java.lang.Object obj24 = timeSeries7.clone();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.util.Date date26 = day25.getStart();
        int int27 = day25.getMonth();
        int int28 = day25.getMonth();
        boolean boolean30 = day25.equals((java.lang.Object) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day25, (double) 10.0f);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        java.lang.String str34 = month33.toString();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        java.util.Date date36 = day35.getEnd();
        java.lang.Class class37 = null;
        java.util.Date date38 = null;
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance(class37, date38, timeZone39);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date36, timeZone39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year41.previous();
        long long43 = year41.getSerialIndex();
        int int44 = month33.compareTo((java.lang.Object) long43);
        int int46 = month33.compareTo((java.lang.Object) (byte) 10);
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month33, (java.lang.Number) 8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "June 2019" + "'", str34.equals("June 2019"));
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 2019L + "'", long43 == 2019L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, 0.0d);
        java.util.Date date7 = fixedMillisecond1.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) (byte) 100);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        java.util.Date date7 = day4.getStart();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.setMaximumItemCount(9999);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        java.util.Date date22 = day21.getEnd();
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date22, timeZone25);
        int int29 = year27.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year27.previous();
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month20, regularTimePeriod30);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day4, regularTimePeriod30);
        timeSeries3.setNotify(false);
        java.util.Collection collection35 = timeSeries3.getTimePeriods();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertNotNull(collection35);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-457));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -457");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        long long8 = fixedMillisecond1.getSerialIndex();
        long long9 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month2.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate5);
//        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getFollowingDayOfWeek(5);
//        int int9 = day0.compareTo((java.lang.Object) serialDate8);
//        long long10 = day0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day0.previous();
//        long long12 = regularTimePeriod11.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560193199999L + "'", long10 == 1560193199999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560106799999L + "'", long12 == 1560106799999L);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.clear();
        boolean boolean19 = timeSeries15.getNotify();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.addAndOrUpdate(timeSeries15);
        java.lang.Class class21 = timeSeries3.getTimePeriodClass();
        boolean boolean22 = timeSeries3.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries3.addChangeListener(seriesChangeListener23);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        long long3 = fixedMillisecond1.getLastMillisecond();
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        boolean boolean7 = fixedMillisecond1.equals((java.lang.Object) 100.0f);
        long long8 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        long long8 = fixedMillisecond5.getFirstMillisecond();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        boolean boolean12 = fixedMillisecond5.equals((java.lang.Object) date10);
        java.util.Calendar calendar13 = null;
        fixedMillisecond5.peg(calendar13);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        try {
            timeSeries3.delete(2019, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 7);
        java.lang.Number number4 = timeSeriesDataItem3.getValue();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getFollowingDayOfWeek(5);
        int int11 = timeSeriesDataItem3.compareTo((java.lang.Object) 5);
        java.lang.Object obj12 = timeSeriesDataItem3.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem3.getPeriod();
        java.lang.Object obj14 = timeSeriesDataItem3.clone();
        java.lang.Number number15 = timeSeriesDataItem3.getValue();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 7 + "'", number4.equals(7));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 7 + "'", number15.equals(7));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int3 = spreadsheetDate2.getDayOfMonth();
        int int4 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears(10, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.setMaximumItemCount(9999);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
        int int21 = year19.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month12, regularTimePeriod22);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener24);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeSeries23);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        boolean boolean8 = fixedMillisecond1.equals((java.lang.Object) date6);
        java.util.Calendar calendar9 = null;
        fixedMillisecond1.peg(calendar9);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond1.getFirstMillisecond(calendar11);
        long long13 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date1, timeZone4);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date1);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day8.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test240");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.util.Date date4 = day3.getStart();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date4);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
//        boolean boolean7 = spreadsheetDate1.isOnOrAfter(serialDate6);
//        int int8 = spreadsheetDate1.toSerial();
//        int int9 = spreadsheetDate1.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        int int12 = spreadsheetDate11.getDayOfMonth();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getStart();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date14);
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date14);
//        boolean boolean17 = spreadsheetDate11.isOnOrAfter(serialDate16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        int int19 = day18.getDayOfMonth();
//        java.lang.Class<?> wildcardClass20 = day18.getClass();
//        boolean boolean21 = spreadsheetDate11.equals((java.lang.Object) day18);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) spreadsheetDate11);
//        boolean boolean23 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        int int26 = spreadsheetDate25.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        int int29 = spreadsheetDate28.getDayOfMonth();
//        int int30 = spreadsheetDate28.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate33 = spreadsheetDate28.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate32);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        int int36 = spreadsheetDate35.getDayOfMonth();
//        int int37 = spreadsheetDate35.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate40 = spreadsheetDate35.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate39);
//        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.addDays(4, serialDate44);
//        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate44);
//        org.jfree.data.time.SerialDate serialDate48 = serialDate46.getPreviousDayOfWeek(7);
//        boolean boolean49 = spreadsheetDate35.isBefore(serialDate48);
//        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate52);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        int int56 = spreadsheetDate55.getDayOfMonth();
//        int int57 = spreadsheetDate55.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate60 = spreadsheetDate55.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate59);
//        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addDays(4, serialDate64);
//        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate64);
//        org.jfree.data.time.SerialDate serialDate68 = serialDate66.getPreviousDayOfWeek(7);
//        boolean boolean69 = spreadsheetDate55.isBefore(serialDate68);
//        boolean boolean71 = spreadsheetDate35.isInRange(serialDate53, serialDate68, (-457));
//        boolean boolean72 = spreadsheetDate28.isOn((org.jfree.data.time.SerialDate) spreadsheetDate35);
//        int int73 = spreadsheetDate35.getDayOfWeek();
//        java.util.Date date74 = spreadsheetDate35.toDate();
//        boolean boolean75 = spreadsheetDate25.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate35);
//        org.jfree.data.time.SerialDate serialDate76 = null;
//        try {
//            boolean boolean78 = spreadsheetDate11.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate35, serialDate76, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1900 + "'", int9 == 1900);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 9 + "'", int29 == 9);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1900 + "'", int30 == 1900);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 9 + "'", int36 == 9);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1900 + "'", int37 == 1900);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 9 + "'", int56 == 9);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1900 + "'", int57 == 1900);
//        org.junit.Assert.assertNotNull(serialDate60);
//        org.junit.Assert.assertNotNull(serialDate64);
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertNotNull(serialDate66);
//        org.junit.Assert.assertNotNull(serialDate68);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2 + "'", int73 == 2);
//        org.junit.Assert.assertNotNull(date74);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2, (int) (byte) 1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(1900);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        boolean boolean8 = fixedMillisecond1.equals((java.lang.Object) date6);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date6);
        java.lang.Object obj10 = seriesChangeEvent9.getSource();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int3 = spreadsheetDate2.getDayOfMonth();
        int int4 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int10 = spreadsheetDate9.getDayOfMonth();
        int int11 = spreadsheetDate9.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate14 = spreadsheetDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addDays(4, serialDate18);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate18);
        org.jfree.data.time.SerialDate serialDate22 = serialDate20.getPreviousDayOfWeek(7);
        boolean boolean23 = spreadsheetDate9.isBefore(serialDate22);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int30 = spreadsheetDate29.getDayOfMonth();
        int int31 = spreadsheetDate29.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate34 = spreadsheetDate29.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addDays(4, serialDate38);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate38);
        org.jfree.data.time.SerialDate serialDate42 = serialDate40.getPreviousDayOfWeek(7);
        boolean boolean43 = spreadsheetDate29.isBefore(serialDate42);
        boolean boolean45 = spreadsheetDate9.isInRange(serialDate27, serialDate42, (-457));
        boolean boolean46 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        try {
            org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) '4', (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1900 + "'", int11 == 1900);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1900 + "'", int31 == 1900);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
        java.util.Date date3 = day0.getStart();
        java.lang.Class class4 = null;
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getStart();
        java.lang.Class class11 = null;
        java.util.Date date12 = null;
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date10, timeZone13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date6, timeZone13);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date3, timeZone13);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNull(regularTimePeriod16);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("June 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar2 = null;
//        fixedMillisecond1.peg(calendar2);
//        long long4 = fixedMillisecond1.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, 0.0d);
//        java.lang.Object obj7 = timeSeriesDataItem6.clone();
//        java.lang.Object obj8 = timeSeriesDataItem6.clone();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        int int11 = spreadsheetDate10.getDayOfMonth();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.util.Date date13 = day12.getStart();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date13);
//        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date13);
//        boolean boolean16 = spreadsheetDate10.isOnOrAfter(serialDate15);
//        int int17 = spreadsheetDate10.toSerial();
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate20);
//        boolean boolean22 = spreadsheetDate10.isOnOrAfter(serialDate21);
//        java.util.Date date23 = spreadsheetDate10.toDate();
//        int int24 = timeSeriesDataItem6.compareTo((java.lang.Object) spreadsheetDate10);
//        int int25 = spreadsheetDate10.getDayOfWeek();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.util.Date date27 = day26.getStart();
//        java.lang.String str28 = day26.toString();
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate31);
//        org.jfree.data.time.SerialDate serialDate34 = serialDate32.getFollowingDayOfWeek(5);
//        int int35 = day26.compareTo((java.lang.Object) serialDate34);
//        org.jfree.data.time.SerialDate serialDate36 = day26.getSerialDate();
//        boolean boolean37 = spreadsheetDate10.isOnOrAfter(serialDate36);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2 + "'", int25 == 2);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "10-June-2019" + "'", str28.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-459), (int) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Time");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        java.lang.String[] strArray4 = org.jfree.data.time.SerialDate.getMonths(false);
        int int5 = year2.compareTo((java.lang.Object) strArray4);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getFirstMillisecond();
//        java.lang.String str4 = day0.toString();
//        int int5 = day0.getMonth();
//        long long6 = day0.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.setRangeDescription("");
        try {
            java.lang.Number number13 = timeSeries3.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) 1900);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        java.lang.Class class7 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day5, class7);
        timeSeries8.setMaximumItemAge(1L);
        timeSeries8.setDescription("10-June-2019");
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year19.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) year19);
        timeSeries8.setRangeDescription("Preceding");
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        java.util.Date date25 = day24.getStart();
        java.lang.Class class26 = null;
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day24, class26);
        timeSeries27.setMaximumItemAge(1L);
        java.lang.Object obj30 = timeSeries27.clone();
        boolean boolean31 = timeSeries27.isEmpty();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        java.util.Date date33 = day32.getStart();
        java.lang.Class class34 = null;
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day32, class34);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
        java.util.Date date37 = day36.getStart();
        java.lang.Class class38 = null;
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day36, class38);
        java.lang.String str40 = timeSeries39.getDomainDescription();
        java.util.Collection collection41 = timeSeries35.getTimePeriodsUniqueToOtherSeries(timeSeries39);
        timeSeries39.clear();
        boolean boolean43 = timeSeries39.getNotify();
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries27.addAndOrUpdate(timeSeries39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond46 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar47 = null;
        fixedMillisecond46.peg(calendar47);
        long long49 = fixedMillisecond46.getFirstMillisecond();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day();
        java.util.Date date51 = day50.getEnd();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date51);
        boolean boolean53 = fixedMillisecond46.equals((java.lang.Object) date51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond55 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar56 = null;
        long long57 = fixedMillisecond55.getLastMillisecond(calendar56);
        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries27.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond46, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond55);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener59 = null;
        timeSeries27.addChangeListener(seriesChangeListener59);
        java.util.Collection collection61 = timeSeries8.getTimePeriodsUniqueToOtherSeries(timeSeries27);
        int int62 = timeSeriesDataItem4.compareTo((java.lang.Object) collection61);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Time" + "'", str40.equals("Time"));
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 0L + "'", long57 == 0L);
        org.junit.Assert.assertNotNull(timeSeries58);
        org.junit.Assert.assertNotNull(collection61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getStart();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day3, class5);
        timeSeries6.setMaximumItemAge(1L);
        timeSeries6.setDescription("10-June-2019");
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.util.Date date12 = day11.getEnd();
        java.lang.Class class13 = null;
        java.util.Date date14 = null;
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date12, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) year17);
        timeSeries6.setRangeDescription("Preceding");
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        java.util.Date date23 = day22.getStart();
        java.lang.Class class24 = null;
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day22, class24);
        timeSeries25.setMaximumItemAge(1L);
        java.lang.Object obj28 = timeSeries25.clone();
        boolean boolean29 = timeSeries25.isEmpty();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        java.util.Date date31 = day30.getStart();
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day30, class32);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        java.util.Date date35 = day34.getStart();
        java.lang.Class class36 = null;
        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day34, class36);
        java.lang.String str38 = timeSeries37.getDomainDescription();
        java.util.Collection collection39 = timeSeries33.getTimePeriodsUniqueToOtherSeries(timeSeries37);
        timeSeries37.clear();
        boolean boolean41 = timeSeries37.getNotify();
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries25.addAndOrUpdate(timeSeries37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar45 = null;
        fixedMillisecond44.peg(calendar45);
        long long47 = fixedMillisecond44.getFirstMillisecond();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
        java.util.Date date49 = day48.getEnd();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date49);
        boolean boolean51 = fixedMillisecond44.equals((java.lang.Object) date49);
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar54 = null;
        long long55 = fixedMillisecond53.getLastMillisecond(calendar54);
        org.jfree.data.time.TimeSeries timeSeries56 = timeSeries25.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond44, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond53);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener57 = null;
        timeSeries25.addChangeListener(seriesChangeListener57);
        java.util.Collection collection59 = timeSeries6.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
        java.util.Date date61 = day60.getStart();
        java.lang.Class class62 = null;
        org.jfree.data.time.TimeSeries timeSeries63 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day60, class62);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day();
        java.util.Date date65 = day64.getStart();
        java.lang.Class class66 = null;
        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day64, class66);
        java.lang.String str68 = timeSeries67.getDomainDescription();
        java.util.Collection collection69 = timeSeries63.getTimePeriodsUniqueToOtherSeries(timeSeries67);
        timeSeries67.setMaximumItemCount(9999);
        org.jfree.data.time.Month month72 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day();
        java.util.Date date74 = day73.getEnd();
        java.lang.Class class75 = null;
        java.util.Date date76 = null;
        java.util.TimeZone timeZone77 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance(class75, date76, timeZone77);
        org.jfree.data.time.Year year79 = new org.jfree.data.time.Year(date74, timeZone77);
        int int81 = year79.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod82 = year79.previous();
        org.jfree.data.time.TimeSeries timeSeries83 = timeSeries67.createCopy((org.jfree.data.time.RegularTimePeriod) month72, regularTimePeriod82);
        java.lang.Class class84 = timeSeries83.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries85 = timeSeries25.addAndOrUpdate(timeSeries83);
        try {
            int int86 = spreadsheetDate1.compareTo((java.lang.Object) timeSeries83);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimeSeries cannot be cast to org.jfree.data.time.SerialDate");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Time" + "'", str38.equals("Time"));
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
        org.junit.Assert.assertNotNull(timeSeries56);
        org.junit.Assert.assertNotNull(collection59);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "Time" + "'", str68.equals("Time"));
        org.junit.Assert.assertNotNull(collection69);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(timeZone77);
        org.junit.Assert.assertNull(regularTimePeriod78);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod82);
        org.junit.Assert.assertNotNull(timeSeries83);
        org.junit.Assert.assertNull(class84);
        org.junit.Assert.assertNotNull(timeSeries85);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.clear();
        boolean boolean19 = timeSeries15.getNotify();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar23 = null;
        fixedMillisecond22.peg(calendar23);
        long long25 = fixedMillisecond22.getFirstMillisecond();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        java.util.Date date27 = day26.getEnd();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        boolean boolean29 = fixedMillisecond22.equals((java.lang.Object) date27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond31.getLastMillisecond(calendar32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar37 = null;
        fixedMillisecond36.peg(calendar37);
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36, (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate2);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate6 = serialDate3.getEndOfCurrentMonth(serialDate5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.SerialDate serialDate8 = day7.getSerialDate();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar9 = null;
        fixedMillisecond8.peg(calendar9);
        long long11 = fixedMillisecond8.getFirstMillisecond();
        java.util.Calendar calendar12 = null;
        fixedMillisecond8.peg(calendar12);
        java.util.Date date14 = fixedMillisecond8.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond8.previous();
        boolean boolean16 = spreadsheetDate5.equals((java.lang.Object) regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.clear();
        boolean boolean19 = timeSeries15.getNotify();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar23 = null;
        fixedMillisecond22.peg(calendar23);
        long long25 = fixedMillisecond22.getFirstMillisecond();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        java.util.Date date27 = day26.getEnd();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        boolean boolean29 = fixedMillisecond22.equals((java.lang.Object) date27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond31.getLastMillisecond(calendar32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (double) (-459));
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(timeSeries34);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(4, (int) (byte) 100, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays(4, serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate4);
        try {
            org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(2958465, serialDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4);
        int int8 = year6.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = regularTimePeriod9.getMiddleMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate2);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate6 = serialDate3.getEndOfCurrentMonth(serialDate5);
        try {
            org.jfree.data.time.SerialDate serialDate8 = serialDate6.getFollowingDayOfWeek((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        try {
            org.jfree.data.time.SerialDate serialDate8 = serialDate6.getPreviousDayOfWeek(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate5);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate13 = serialDate5.getEndOfCurrentMonth(serialDate12);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = serialDate17.getFollowingDayOfWeek(5);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        java.lang.String str21 = serialDate19.toString();
        boolean boolean22 = spreadsheetDate1.isInRange(serialDate13, serialDate19);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addDays(4, serialDate28);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate28);
        org.jfree.data.time.SerialDate serialDate31 = serialDate24.getEndOfCurrentMonth(serialDate28);
        boolean boolean32 = spreadsheetDate1.isAfter(serialDate24);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "13-April-2000" + "'", str21.equals("13-April-2000"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(2019);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        long long3 = day0.getLastMillisecond();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getLastMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, 0.0d);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 7);
        java.lang.Number number11 = timeSeriesDataItem10.getValue();
        java.lang.Object obj12 = timeSeriesDataItem10.clone();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate15);
        org.jfree.data.time.SerialDate serialDate18 = serialDate16.getFollowingDayOfWeek(5);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate16);
        java.lang.String str20 = serialDate16.toString();
        boolean boolean21 = timeSeriesDataItem10.equals((java.lang.Object) str20);
        boolean boolean22 = timeSeriesDataItem6.equals((java.lang.Object) boolean21);
        timeSeriesDataItem6.setValue((java.lang.Number) 1560150000000L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 7 + "'", number11.equals(7));
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "9-April-2000" + "'", str20.equals("9-April-2000"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(31);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-452) + "'", int1 == (-452));
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.previous();
//        java.util.Calendar calendar5 = null;
//        try {
//            day2.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        timeSeries3.setDescription("10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy(7, (int) (short) 100);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        long long8 = fixedMillisecond5.getFirstMillisecond();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        boolean boolean12 = fixedMillisecond5.equals((java.lang.Object) date10);
        java.util.Calendar calendar13 = null;
        fixedMillisecond5.peg(calendar13);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar18 = null;
        fixedMillisecond17.peg(calendar18);
        long long20 = fixedMillisecond17.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, 0.0d);
        java.lang.Object obj23 = timeSeriesDataItem22.clone();
        java.lang.Object obj24 = timeSeriesDataItem22.clone();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int27 = spreadsheetDate26.getDayOfMonth();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        java.util.Date date29 = day28.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date29);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date29);
        boolean boolean32 = spreadsheetDate26.isOnOrAfter(serialDate31);
        int int33 = spreadsheetDate26.toSerial();
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate36);
        boolean boolean38 = spreadsheetDate26.isOnOrAfter(serialDate37);
        java.util.Date date39 = spreadsheetDate26.toDate();
        int int40 = timeSeriesDataItem22.compareTo((java.lang.Object) spreadsheetDate26);
        int int41 = fixedMillisecond5.compareTo((java.lang.Object) timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 9 + "'", int27 == 9);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 100 + "'", int33 == 100);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int3 = spreadsheetDate2.getDayOfMonth();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date5);
        boolean boolean8 = spreadsheetDate2.isOnOrAfter(serialDate7);
        int int9 = spreadsheetDate2.toSerial();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate12);
        boolean boolean14 = spreadsheetDate2.isOnOrAfter(serialDate13);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addMonths(8, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(serialDate15);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4);
        int int8 = year6.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year6.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("August");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.setRangeDescription("");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        int int15 = month14.getMonth();
        int int17 = month14.compareTo((java.lang.Object) (-1.0d));
        timeSeries3.setKey((java.lang.Comparable) int17);
        timeSeries3.setRangeDescription("Saturday");
        timeSeries3.setDescription("org.jfree.data.general.SeriesException: hi!");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        int int3 = month2.getMonth();
        int int5 = month2.compareTo((java.lang.Object) (-1.0d));
        int int6 = month2.getMonth();
        int int7 = month2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month2.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(10);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        timeSeries3.setDescription("10-June-2019");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date9, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year14);
        timeSeries3.setRangeDescription("Preceding");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        java.util.Date date20 = day19.getStart();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day19, class21);
        timeSeries22.setMaximumItemAge(1L);
        java.lang.Object obj25 = timeSeries22.clone();
        boolean boolean26 = timeSeries22.isEmpty();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        java.util.Date date28 = day27.getStart();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day27, class29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        java.util.Date date32 = day31.getStart();
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day31, class33);
        java.lang.String str35 = timeSeries34.getDomainDescription();
        java.util.Collection collection36 = timeSeries30.getTimePeriodsUniqueToOtherSeries(timeSeries34);
        timeSeries34.clear();
        boolean boolean38 = timeSeries34.getNotify();
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries22.addAndOrUpdate(timeSeries34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar42 = null;
        fixedMillisecond41.peg(calendar42);
        long long44 = fixedMillisecond41.getFirstMillisecond();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
        java.util.Date date46 = day45.getEnd();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date46);
        boolean boolean48 = fixedMillisecond41.equals((java.lang.Object) date46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar51 = null;
        long long52 = fixedMillisecond50.getLastMillisecond(calendar51);
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond50);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener54 = null;
        timeSeries22.addChangeListener(seriesChangeListener54);
        java.util.Collection collection56 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries22);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
        java.util.Date date58 = day57.getStart();
        java.lang.Class class59 = null;
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day57, class59);
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day();
        java.util.Date date62 = day61.getStart();
        java.lang.Class class63 = null;
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day61, class63);
        java.lang.String str65 = timeSeries64.getDomainDescription();
        java.util.Collection collection66 = timeSeries60.getTimePeriodsUniqueToOtherSeries(timeSeries64);
        timeSeries64.setMaximumItemCount(9999);
        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day();
        java.util.Date date71 = day70.getEnd();
        java.lang.Class class72 = null;
        java.util.Date date73 = null;
        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance(class72, date73, timeZone74);
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(date71, timeZone74);
        int int78 = year76.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = year76.previous();
        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries64.createCopy((org.jfree.data.time.RegularTimePeriod) month69, regularTimePeriod79);
        java.lang.Class class81 = timeSeries80.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries82 = timeSeries22.addAndOrUpdate(timeSeries80);
        int int83 = timeSeries22.getMaximumItemCount();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = timeSeries22.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Time" + "'", str35.equals("Time"));
        org.junit.Assert.assertNotNull(collection36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertNotNull(collection56);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "Time" + "'", str65.equals("Time"));
        org.junit.Assert.assertNotNull(collection66);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(timeZone74);
        org.junit.Assert.assertNull(regularTimePeriod75);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(timeSeries80);
        org.junit.Assert.assertNull(class81);
        org.junit.Assert.assertNotNull(timeSeries82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 2147483647 + "'", int83 == 2147483647);
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
//        timeSeries3.setMaximumItemAge(1L);
//        java.lang.Object obj6 = timeSeries3.clone();
//        boolean boolean7 = timeSeries3.isEmpty();
//        timeSeries3.setDescription("org.jfree.data.general.SeriesException: hi!");
//        timeSeries3.removeAgedItems(false);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        long long13 = day12.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day12, (double) 1560193199999L);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries18 = timeSeries3.createCopy((int) 'a', (int) 'a');
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 1");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560236399999L + "'", long13 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, 0.0d);
        java.util.Date date7 = fixedMillisecond1.getStart();
        java.lang.String str8 = fixedMillisecond1.toString();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str8.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod4, 10.0d);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.setRangeDescription("");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        int int15 = month14.getMonth();
        int int17 = month14.compareTo((java.lang.Object) (-1.0d));
        timeSeries3.setKey((java.lang.Comparable) int17);
        timeSeries3.setRangeDescription("Saturday");
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
        int int24 = fixedMillisecond22.compareTo((java.lang.Object) 100.0f);
        java.util.Date date25 = fixedMillisecond22.getTime();
        boolean boolean26 = timeSeries3.equals((java.lang.Object) date25);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date25);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(serialDate27);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("June 2019");
        org.jfree.data.time.Year year2 = month1.getYear();
        java.util.Calendar calendar3 = null;
        try {
            year2.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(month1);
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("13-April-1900");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int9 = spreadsheetDate8.getDayOfMonth();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays(4, serialDate17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate17);
        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getPreviousDayOfWeek(7);
        boolean boolean22 = spreadsheetDate8.isBefore(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int29 = spreadsheetDate28.getDayOfMonth();
        int int30 = spreadsheetDate28.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate33 = spreadsheetDate28.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addDays(4, serialDate37);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate37);
        org.jfree.data.time.SerialDate serialDate41 = serialDate39.getPreviousDayOfWeek(7);
        boolean boolean42 = spreadsheetDate28.isBefore(serialDate41);
        boolean boolean44 = spreadsheetDate8.isInRange(serialDate26, serialDate41, (-457));
        boolean boolean45 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int46 = spreadsheetDate8.getDayOfWeek();
        java.util.Date date47 = spreadsheetDate8.toDate();
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addDays(4, serialDate50);
        boolean boolean52 = spreadsheetDate8.isOnOrAfter(serialDate50);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 9 + "'", int29 == 9);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1900 + "'", int30 == 1900);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.clear();
        boolean boolean19 = timeSeries15.getNotify();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.addAndOrUpdate(timeSeries15);
        java.lang.Class class21 = timeSeries3.getTimePeriodClass();
        boolean boolean22 = timeSeries3.getNotify();
        int int23 = timeSeries3.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries24 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries25 = timeSeries3.addAndOrUpdate(timeSeries24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2147483647 + "'", int23 == 2147483647);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(5);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("June 2019");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate4);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate8);
        org.jfree.data.time.SerialDate serialDate11 = serialDate9.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate12 = serialDate4.getEndOfCurrentMonth(serialDate11);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate15 = serialDate11.getEndOfCurrentMonth(serialDate14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears(4, serialDate15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 1, serialDate15);
        try {
            org.jfree.data.time.SerialDate serialDate19 = serialDate17.getPreviousDayOfWeek(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 9999);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        java.util.Date date3 = day2.getStart();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month4.next();
        boolean boolean7 = fixedMillisecond1.equals((java.lang.Object) month4);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar2 = null;
//        fixedMillisecond1.peg(calendar2);
//        long long4 = fixedMillisecond1.getFirstMillisecond();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.util.Date date6 = day5.getEnd();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        boolean boolean8 = fixedMillisecond1.equals((java.lang.Object) date6);
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond1.peg(calendar9);
//        long long11 = fixedMillisecond1.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int16 = day15.getDayOfMonth();
//        java.lang.Class<?> wildcardClass17 = day15.getClass();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond12, "Saturday", "Nearest", (java.lang.Class) wildcardClass17);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long11, (java.lang.Class) wildcardClass17);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeries19.getTimePeriod(100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int1, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "hi!", class4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getStart();
//        java.lang.String str8 = day6.toString();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate11);
//        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getFollowingDayOfWeek(5);
//        int int15 = day6.compareTo((java.lang.Object) serialDate14);
//        org.jfree.data.time.SerialDate serialDate16 = day6.getSerialDate();
//        timeSeries5.setKey((java.lang.Comparable) day6);
//        try {
//            org.jfree.data.time.TimeSeries timeSeries20 = timeSeries5.createCopy(9, 7);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(serialDate16);
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        java.util.Date date7 = day4.getStart();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.setMaximumItemCount(9999);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        java.util.Date date22 = day21.getEnd();
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date22, timeZone25);
        int int29 = year27.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year27.previous();
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month20, regularTimePeriod30);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day4, regularTimePeriod30);
        java.lang.Comparable comparable33 = timeSeries32.getKey();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertNotNull(comparable33);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        boolean boolean8 = fixedMillisecond1.equals((java.lang.Object) date6);
        java.util.Calendar calendar9 = null;
        fixedMillisecond1.peg(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        long long8 = year6.getLastMillisecond();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getEnd();
        java.lang.Class class11 = null;
        java.util.Date date12 = null;
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date10, timeZone13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.previous();
        int int17 = year15.getYear();
        int int18 = year6.compareTo((java.lang.Object) year15);
        long long19 = year15.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate4);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate8);
        org.jfree.data.time.SerialDate serialDate11 = serialDate9.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate12 = serialDate4.getEndOfCurrentMonth(serialDate11);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate15 = serialDate11.getEndOfCurrentMonth(serialDate14);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears(4, serialDate15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate15);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.clear();
        boolean boolean19 = timeSeries15.getNotify();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.addAndOrUpdate(timeSeries15);
        java.lang.Class class21 = timeSeries3.getTimePeriodClass();
        boolean boolean22 = timeSeries3.getNotify();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar25 = null;
        fixedMillisecond24.peg(calendar25);
        long long27 = fixedMillisecond24.getFirstMillisecond();
        java.util.Calendar calendar28 = null;
        fixedMillisecond24.peg(calendar28);
        java.util.Date date30 = fixedMillisecond24.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond24.previous();
        try {
            timeSeries3.add(regularTimePeriod31, (java.lang.Number) 100, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond8.next();
        long long10 = fixedMillisecond8.getFirstMillisecond();
        java.util.Date date11 = fixedMillisecond8.getTime();
        java.lang.Class<?> wildcardClass12 = date11.getClass();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod4, "hi!", "Wed Dec 31 16:00:00 PST 1969", (java.lang.Class) wildcardClass12);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate5);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate13 = serialDate5.getEndOfCurrentMonth(serialDate12);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate16 = serialDate12.getEndOfCurrentMonth(serialDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int19 = spreadsheetDate18.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate22);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate26);
        org.jfree.data.time.SerialDate serialDate29 = serialDate27.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate30 = serialDate22.getEndOfCurrentMonth(serialDate29);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate33);
        org.jfree.data.time.SerialDate serialDate36 = serialDate34.getFollowingDayOfWeek(5);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate36);
        java.lang.String str38 = serialDate36.toString();
        boolean boolean39 = spreadsheetDate18.isInRange(serialDate30, serialDate36);
        boolean boolean41 = spreadsheetDate2.isInRange(serialDate15, serialDate36, (int) (short) 100);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(3, serialDate36);
        try {
            org.jfree.data.time.SerialDate serialDate44 = serialDate36.getFollowingDayOfWeek(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "13-April-2000" + "'", str38.equals("13-April-2000"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(serialDate42);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        timeSeries3.setDescription("10-June-2019");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date9, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year14);
        timeSeries3.setRangeDescription("Preceding");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        java.util.Date date20 = day19.getStart();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day19, class21);
        timeSeries22.setMaximumItemAge(1L);
        java.lang.Object obj25 = timeSeries22.clone();
        boolean boolean26 = timeSeries22.isEmpty();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        java.util.Date date28 = day27.getStart();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day27, class29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        java.util.Date date32 = day31.getStart();
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day31, class33);
        java.lang.String str35 = timeSeries34.getDomainDescription();
        java.util.Collection collection36 = timeSeries30.getTimePeriodsUniqueToOtherSeries(timeSeries34);
        timeSeries34.clear();
        boolean boolean38 = timeSeries34.getNotify();
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries22.addAndOrUpdate(timeSeries34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar42 = null;
        fixedMillisecond41.peg(calendar42);
        long long44 = fixedMillisecond41.getFirstMillisecond();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
        java.util.Date date46 = day45.getEnd();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date46);
        boolean boolean48 = fixedMillisecond41.equals((java.lang.Object) date46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar51 = null;
        long long52 = fixedMillisecond50.getLastMillisecond(calendar51);
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond50);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener54 = null;
        timeSeries22.addChangeListener(seriesChangeListener54);
        java.util.Collection collection56 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries22);
        timeSeries3.removeAgedItems(true);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Time" + "'", str35.equals("Time"));
        org.junit.Assert.assertNotNull(collection36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertNotNull(collection56);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        boolean boolean8 = fixedMillisecond1.equals((java.lang.Object) date6);
        java.util.Date date9 = fixedMillisecond1.getEnd();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(date9);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        long long3 = day0.getFirstMillisecond();
//        java.lang.String str4 = day0.toString();
//        java.util.Date date5 = day0.getStart();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560150000000L + "'", long3 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date5);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("9-July-2833");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        timeSeries3.setDescription("10-June-2019");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date9, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year14);
        timeSeries3.setRangeDescription("Preceding");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        java.util.Date date20 = day19.getStart();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day19, class21);
        timeSeries22.setMaximumItemAge(1L);
        java.lang.Object obj25 = timeSeries22.clone();
        boolean boolean26 = timeSeries22.isEmpty();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        java.util.Date date28 = day27.getStart();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day27, class29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        java.util.Date date32 = day31.getStart();
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day31, class33);
        java.lang.String str35 = timeSeries34.getDomainDescription();
        java.util.Collection collection36 = timeSeries30.getTimePeriodsUniqueToOtherSeries(timeSeries34);
        timeSeries34.clear();
        boolean boolean38 = timeSeries34.getNotify();
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries22.addAndOrUpdate(timeSeries34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar42 = null;
        fixedMillisecond41.peg(calendar42);
        long long44 = fixedMillisecond41.getFirstMillisecond();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
        java.util.Date date46 = day45.getEnd();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date46);
        boolean boolean48 = fixedMillisecond41.equals((java.lang.Object) date46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar51 = null;
        long long52 = fixedMillisecond50.getLastMillisecond(calendar51);
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond50);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener54 = null;
        timeSeries22.addChangeListener(seriesChangeListener54);
        java.util.Collection collection56 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = null;
        try {
            timeSeries3.add(timeSeriesDataItem57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Time" + "'", str35.equals("Time"));
        org.junit.Assert.assertNotNull(collection36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertNotNull(collection56);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 12);
        java.lang.String str2 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=12]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=12]"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getLastMillisecond(calendar2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int1, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "hi!", class4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getStart();
//        java.lang.String str8 = day6.toString();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate11);
//        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getFollowingDayOfWeek(5);
//        int int15 = day6.compareTo((java.lang.Object) serialDate14);
//        org.jfree.data.time.SerialDate serialDate16 = day6.getSerialDate();
//        timeSeries5.setKey((java.lang.Comparable) day6);
//        try {
//            timeSeries5.update((int) (byte) 0, (java.lang.Number) 9999);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(serialDate16);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.setRangeDescription("");
        boolean boolean12 = timeSeries3.getNotify();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
//        timeSeries3.setMaximumItemAge(1L);
//        java.lang.Object obj6 = timeSeries3.clone();
//        boolean boolean7 = timeSeries3.isEmpty();
//        timeSeries3.setDescription("org.jfree.data.general.SeriesException: hi!");
//        timeSeries3.removeAgedItems(false);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        long long13 = day12.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day12, (double) 1560193199999L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(100L);
//        boolean boolean18 = timeSeries3.equals((java.lang.Object) 100L);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560236399999L + "'", long13 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560190644621L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 7);
        java.lang.Number number4 = timeSeriesDataItem3.getValue();
        java.lang.Object obj5 = null;
        int int6 = timeSeriesDataItem3.compareTo(obj5);
        java.lang.Number number7 = timeSeriesDataItem3.getValue();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 7 + "'", number4.equals(7));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 7 + "'", number7.equals(7));
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
//        long long3 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0);
//        try {
//            org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = timeSeries4.getNextTimePeriod();
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560236399999L + "'", long3 == 1560236399999L);
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        timeSeries3.setDescription("10-June-2019");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date9, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year14);
        timeSeries3.setRangeDescription("Preceding");
        timeSeries3.setDomainDescription("ERROR : Relative To String");
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        java.util.Date date22 = day21.getStart();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day21, class23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.util.Date date26 = day25.getStart();
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day25, class27);
        java.lang.String str29 = timeSeries28.getDomainDescription();
        java.util.Collection collection30 = timeSeries24.getTimePeriodsUniqueToOtherSeries(timeSeries28);
        timeSeries28.setMaximumItemCount(9999);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        java.util.Date date35 = day34.getEnd();
        java.lang.Class class36 = null;
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date35, timeZone38);
        int int42 = year40.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year40.previous();
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) month33, regularTimePeriod43);
        java.lang.String str45 = timeSeries28.getRangeDescription();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
        java.util.Date date47 = day46.getStart();
        java.lang.Class class48 = null;
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day46, class48);
        timeSeries49.setMaximumItemAge(1L);
        timeSeries49.setDescription("10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries28.addAndOrUpdate(timeSeries49);
        java.util.Collection collection55 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries49);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Time" + "'", str29.equals("Time"));
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Value" + "'", str45.equals("Value"));
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(timeSeries54);
        org.junit.Assert.assertNotNull(collection55);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int9 = spreadsheetDate8.getDayOfMonth();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays(4, serialDate17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate17);
        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getPreviousDayOfWeek(7);
        boolean boolean22 = spreadsheetDate8.isBefore(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int29 = spreadsheetDate28.getDayOfMonth();
        int int30 = spreadsheetDate28.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate33 = spreadsheetDate28.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addDays(4, serialDate37);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate37);
        org.jfree.data.time.SerialDate serialDate41 = serialDate39.getPreviousDayOfWeek(7);
        boolean boolean42 = spreadsheetDate28.isBefore(serialDate41);
        boolean boolean44 = spreadsheetDate8.isInRange(serialDate26, serialDate41, (-457));
        boolean boolean45 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate50);
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate54);
        org.jfree.data.time.SerialDate serialDate57 = serialDate55.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate58 = serialDate50.getEndOfCurrentMonth(serialDate57);
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate61 = serialDate57.getEndOfCurrentMonth(serialDate60);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int64 = spreadsheetDate63.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate67);
        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate71);
        org.jfree.data.time.SerialDate serialDate74 = serialDate72.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate75 = serialDate67.getEndOfCurrentMonth(serialDate74);
        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate79 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate78);
        org.jfree.data.time.SerialDate serialDate81 = serialDate79.getFollowingDayOfWeek(5);
        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day(serialDate81);
        java.lang.String str83 = serialDate81.toString();
        boolean boolean84 = spreadsheetDate63.isInRange(serialDate75, serialDate81);
        boolean boolean86 = spreadsheetDate47.isInRange(serialDate60, serialDate81, (int) (short) 100);
        org.jfree.data.time.SerialDate serialDate87 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SerialDate serialDate90 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate91 = org.jfree.data.time.SerialDate.addDays(4, serialDate90);
        org.jfree.data.time.SerialDate serialDate92 = spreadsheetDate47.getEndOfCurrentMonth(serialDate90);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 9 + "'", int29 == 9);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1900 + "'", int30 == 1900);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 9 + "'", int64 == 9);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertNotNull(serialDate75);
        org.junit.Assert.assertNotNull(serialDate78);
        org.junit.Assert.assertNotNull(serialDate79);
        org.junit.Assert.assertNotNull(serialDate81);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "13-April-2000" + "'", str83.equals("13-April-2000"));
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(serialDate87);
        org.junit.Assert.assertNotNull(serialDate90);
        org.junit.Assert.assertNotNull(serialDate91);
        org.junit.Assert.assertNotNull(serialDate92);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        java.lang.Class class3 = null;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date9, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date5, timeZone12);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date1, timeZone12);
        java.util.Calendar calendar17 = null;
        try {
            year16.peg(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNull(regularTimePeriod15);
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test322");
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        java.util.Date date2 = day1.getStart();
//        java.lang.String str3 = day1.toString();
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate6);
//        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getFollowingDayOfWeek(5);
//        int int10 = day1.compareTo((java.lang.Object) serialDate9);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(3, serialDate9);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(serialDate11);
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.clear();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.util.Date date12 = day11.getStart();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        int int14 = month13.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) (short) 0);
        timeSeries7.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener19 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener19);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: 13-April-1900");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.setMaximumItemCount(9999);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
        int int21 = year19.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month12, regularTimePeriod22);
        java.lang.Object obj24 = timeSeries7.clone();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.util.Date date26 = day25.getStart();
        int int27 = day25.getMonth();
        int int28 = day25.getMonth();
        boolean boolean30 = day25.equals((java.lang.Object) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day25, (double) 10.0f);
        java.util.Collection collection33 = timeSeries7.getTimePeriods();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener34 = null;
        timeSeries7.addChangeListener(seriesChangeListener34);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNotNull(collection33);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        java.util.Date date7 = day4.getStart();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.setMaximumItemCount(9999);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        java.util.Date date22 = day21.getEnd();
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date22, timeZone25);
        int int29 = year27.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year27.previous();
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month20, regularTimePeriod30);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day4, regularTimePeriod30);
        timeSeries3.setNotify(false);
        boolean boolean35 = timeSeries3.getNotify();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray6 = seriesException5.getSuppressed();
        java.lang.Throwable[] throwableArray7 = seriesException5.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException5);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 100.0f);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getMiddleMillisecond(calendar4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.util.Date date7 = day6.getStart();
        java.lang.Class class8 = null;
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day6, class8);
        timeSeries9.setMaximumItemAge(1L);
        timeSeries9.setDescription("10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries9.createCopy(7, (int) (short) 100);
        timeSeries16.fireSeriesChanged();
        timeSeries16.setNotify(false);
        int int20 = fixedMillisecond1.compareTo((java.lang.Object) false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.Class class2 = null;
//        java.util.Date date3 = null;
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date1, timeZone4);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date1);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        java.lang.String str10 = day8.toString();
//        java.util.Calendar calendar11 = null;
//        try {
//            day8.peg(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10-June-2019" + "'", str10.equals("10-June-2019"));
//    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, 0.0d);
        java.lang.Object obj7 = timeSeriesDataItem6.clone();
        java.lang.Object obj8 = timeSeriesDataItem6.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeriesDataItem6.getPeriod();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.setRangeDescription("");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        int int15 = month14.getMonth();
        int int17 = month14.compareTo((java.lang.Object) (-1.0d));
        timeSeries3.setKey((java.lang.Comparable) int17);
        timeSeries3.setRangeDescription("Saturday");
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
        int int24 = fixedMillisecond22.compareTo((java.lang.Object) 100.0f);
        java.util.Date date25 = fixedMillisecond22.getTime();
        boolean boolean26 = timeSeries3.equals((java.lang.Object) date25);
        timeSeries3.setDescription("org.jfree.data.time.TimePeriodFormatException: 13-April-1900");
        java.lang.String str29 = timeSeries3.getRangeDescription();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Saturday" + "'", str29.equals("Saturday"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        java.util.Calendar calendar5 = null;
        try {
            month3.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((-459), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4);
        int int8 = year6.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        java.util.Date date10 = year6.getEnd();
        java.util.Calendar calendar11 = null;
        try {
            year6.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4);
        int int8 = year6.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        java.lang.String str10 = year6.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year6.previous();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod11);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("13-April-2000");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.clear();
        boolean boolean19 = timeSeries15.getNotify();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        java.util.Date date22 = day21.getStart();
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date22, timeZone25);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date22);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date22);
        boolean boolean30 = timeSeries20.equals((java.lang.Object) date22);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance(date22);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(serialDate31);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        try {
            org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        int int8 = year6.getYear();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date10);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance(date10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date10);
        boolean boolean14 = year6.equals((java.lang.Object) fixedMillisecond13);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.clear();
        boolean boolean19 = timeSeries15.getNotify();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.addAndOrUpdate(timeSeries15);
        java.lang.Class class21 = timeSeries15.getTimePeriodClass();
        timeSeries15.setNotify(false);
        timeSeries15.setRangeDescription("Saturday");
        java.lang.Comparable comparable26 = timeSeries15.getKey();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertNotNull(comparable26);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        long long8 = year6.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        java.lang.Class<?> wildcardClass10 = year6.getClass();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate5);
//        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getFollowingDayOfWeek(5);
//        int int9 = day0.compareTo((java.lang.Object) serialDate8);
//        long long10 = day0.getLastMillisecond();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.util.Date date12 = day11.getStart();
//        java.lang.String str13 = day11.toString();
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate16);
//        org.jfree.data.time.SerialDate serialDate19 = serialDate17.getFollowingDayOfWeek(5);
//        int int20 = day11.compareTo((java.lang.Object) serialDate19);
//        boolean boolean21 = day0.equals((java.lang.Object) day11);
//        java.util.Calendar calendar22 = null;
//        try {
//            long long23 = day0.getLastMillisecond(calendar22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10-June-2019" + "'", str13.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        long long3 = month2.getFirstMillisecond();
        java.util.Date date4 = month2.getStart();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
        java.util.Date date3 = regularTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date1, timeZone4);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        java.util.Calendar calendar9 = null;
        try {
            year7.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar2 = null;
//        fixedMillisecond1.peg(calendar2);
//        long long4 = fixedMillisecond1.getFirstMillisecond();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.util.Date date6 = day5.getEnd();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        boolean boolean8 = fixedMillisecond1.equals((java.lang.Object) date6);
//        java.util.Calendar calendar9 = null;
//        fixedMillisecond1.peg(calendar9);
//        long long11 = fixedMillisecond1.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
//        int int16 = day15.getDayOfMonth();
//        java.lang.Class<?> wildcardClass17 = day15.getClass();
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond12, "Saturday", "Nearest", (java.lang.Class) wildcardClass17);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long11, (java.lang.Class) wildcardClass17);
//        timeSeries19.setRangeDescription("org.jfree.data.general.SeriesException: hi!");
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//        org.junit.Assert.assertNotNull(wildcardClass17);
//    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int1, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "hi!", class4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getStart();
//        java.lang.String str8 = day6.toString();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate11);
//        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getFollowingDayOfWeek(5);
//        int int15 = day6.compareTo((java.lang.Object) serialDate14);
//        org.jfree.data.time.SerialDate serialDate16 = day6.getSerialDate();
//        timeSeries5.setKey((java.lang.Comparable) day6);
//        java.lang.Class class18 = timeSeries5.getTimePeriodClass();
//        timeSeries5.setRangeDescription("");
//        int int21 = timeSeries5.getMaximumItemCount();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNull(class18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
//    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.setRangeDescription("");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        int int15 = month14.getMonth();
        int int17 = month14.compareTo((java.lang.Object) (-1.0d));
        timeSeries3.setKey((java.lang.Comparable) int17);
        timeSeries3.setRangeDescription("Saturday");
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
        int int24 = fixedMillisecond22.compareTo((java.lang.Object) 100.0f);
        java.util.Date date25 = fixedMillisecond22.getTime();
        boolean boolean26 = timeSeries3.equals((java.lang.Object) date25);
        timeSeries3.setDescription("org.jfree.data.time.TimePeriodFormatException: 13-April-1900");
        java.lang.Object obj29 = timeSeries3.clone();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        java.util.Date date7 = day4.getStart();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.setMaximumItemCount(9999);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        java.util.Date date22 = day21.getEnd();
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date22, timeZone25);
        int int29 = year27.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year27.previous();
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month20, regularTimePeriod30);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day4, regularTimePeriod30);
        boolean boolean33 = timeSeries3.getNotify();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
//        timeSeries3.setMaximumItemAge(1L);
//        java.lang.Object obj6 = timeSeries3.clone();
//        boolean boolean7 = timeSeries3.isEmpty();
//        timeSeries3.setDescription("org.jfree.data.general.SeriesException: hi!");
//        timeSeries3.removeAgedItems(false);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        long long13 = day12.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day12, (double) 1560193199999L);
//        java.util.Date date16 = day12.getStart();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560236399999L + "'", long13 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(date16);
//    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
//        java.util.List list4 = timeSeries3.getItems();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        java.lang.Class<?> wildcardClass10 = day8.getClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond5, "Saturday", "Nearest", (java.lang.Class) wildcardClass10);
//        try {
//            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (java.lang.Number) 2019);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(list4);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        java.util.Date date3 = day2.getEnd();
        java.lang.Class class4 = null;
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date5, timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date3, timeZone6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getSerialIndex();
        int int11 = month0.compareTo((java.lang.Object) long10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month0.next();
        org.jfree.data.time.Year year13 = month0.getYear();
        long long14 = month0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24234L + "'", long14 == 24234L);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test357");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
//        timeSeries3.setMaximumItemAge(1L);
//        java.lang.Object obj6 = timeSeries3.clone();
//        boolean boolean7 = timeSeries3.isEmpty();
//        timeSeries3.setDescription("org.jfree.data.general.SeriesException: hi!");
//        timeSeries3.removeAgedItems(false);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.util.Date date13 = day12.getEnd();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        int int15 = day14.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day14.previous();
//        int int17 = timeSeries3.getIndex(regularTimePeriod16);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month3.getLastMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(9, 2958465, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.setMaximumItemCount(9999);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
        int int21 = year19.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month12, regularTimePeriod22);
        java.util.Calendar calendar24 = null;
        try {
            long long25 = month12.getLastMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeSeries23);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(9999, 9999, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day8, (java.lang.Number) 7);
        java.lang.Number number12 = timeSeriesDataItem11.getValue();
        java.lang.Object obj13 = null;
        int int14 = timeSeriesDataItem11.compareTo(obj13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeriesDataItem11.getPeriod();
        try {
            timeSeries3.add(timeSeriesDataItem11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 7 + "'", number12.equals(7));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("June 2019");
        org.jfree.data.time.Year year2 = month1.getYear();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month1.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(month1);
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setDescription("9-April-2000");
        java.lang.Number number7 = null;
        try {
            timeSeries3.update((-452), number7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        java.util.Date date2 = day1.getEnd();
        java.lang.Class class3 = null;
        java.util.Date date4 = null;
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date4, timeZone5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date2, timeZone5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getEnd();
        java.lang.Class class12 = null;
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date11, timeZone14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        int int18 = year16.getYear();
        int int19 = year7.compareTo((java.lang.Object) year16);
        try {
            org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(0, year16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        java.util.Date date3 = day2.getStart();
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day2, class4);
        timeSeries5.setMaximumItemAge(1L);
        timeSeries5.setDescription("10-June-2019");
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getEnd();
        java.lang.Class class12 = null;
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date11, timeZone14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries5.getDataItem((org.jfree.data.time.RegularTimePeriod) year16);
        timeSeries5.setRangeDescription("Preceding");
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        java.util.Date date22 = day21.getStart();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day21, class23);
        timeSeries24.setMaximumItemAge(1L);
        java.lang.Object obj27 = timeSeries24.clone();
        boolean boolean28 = timeSeries24.isEmpty();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        java.util.Date date30 = day29.getStart();
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day29, class31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        java.util.Date date34 = day33.getStart();
        java.lang.Class class35 = null;
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day33, class35);
        java.lang.String str37 = timeSeries36.getDomainDescription();
        java.util.Collection collection38 = timeSeries32.getTimePeriodsUniqueToOtherSeries(timeSeries36);
        timeSeries36.clear();
        boolean boolean40 = timeSeries36.getNotify();
        org.jfree.data.time.TimeSeries timeSeries41 = timeSeries24.addAndOrUpdate(timeSeries36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar44 = null;
        fixedMillisecond43.peg(calendar44);
        long long46 = fixedMillisecond43.getFirstMillisecond();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
        java.util.Date date48 = day47.getEnd();
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date48);
        boolean boolean50 = fixedMillisecond43.equals((java.lang.Object) date48);
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar53 = null;
        long long54 = fixedMillisecond52.getLastMillisecond(calendar53);
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries24.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond43, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener56 = null;
        timeSeries24.addChangeListener(seriesChangeListener56);
        java.util.Collection collection58 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries24);
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
        java.util.Date date60 = day59.getStart();
        java.lang.Class class61 = null;
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day59, class61);
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day();
        java.util.Date date64 = day63.getStart();
        java.lang.Class class65 = null;
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day63, class65);
        java.lang.String str67 = timeSeries66.getDomainDescription();
        java.util.Collection collection68 = timeSeries62.getTimePeriodsUniqueToOtherSeries(timeSeries66);
        timeSeries66.setMaximumItemCount(9999);
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day();
        java.util.Date date73 = day72.getEnd();
        java.lang.Class class74 = null;
        java.util.Date date75 = null;
        java.util.TimeZone timeZone76 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod77 = org.jfree.data.time.RegularTimePeriod.createInstance(class74, date75, timeZone76);
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year(date73, timeZone76);
        int int80 = year78.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = year78.previous();
        org.jfree.data.time.TimeSeries timeSeries82 = timeSeries66.createCopy((org.jfree.data.time.RegularTimePeriod) month71, regularTimePeriod81);
        java.lang.Class class83 = timeSeries82.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries84 = timeSeries24.addAndOrUpdate(timeSeries82);
        int int85 = timeSeries24.getMaximumItemCount();
        boolean boolean86 = fixedMillisecond1.equals((java.lang.Object) int85);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Time" + "'", str37.equals("Time"));
        org.junit.Assert.assertNotNull(collection38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(timeSeries41);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertNotNull(collection58);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "Time" + "'", str67.equals("Time"));
        org.junit.Assert.assertNotNull(collection68);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertNotNull(timeZone76);
        org.junit.Assert.assertNull(regularTimePeriod77);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod81);
        org.junit.Assert.assertNotNull(timeSeries82);
        org.junit.Assert.assertNull(class83);
        org.junit.Assert.assertNotNull(timeSeries84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 2147483647 + "'", int85 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        long long3 = fixedMillisecond1.getLastMillisecond();
        long long4 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.clear();
        boolean boolean19 = timeSeries15.getNotify();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar23 = null;
        fixedMillisecond22.peg(calendar23);
        long long25 = fixedMillisecond22.getFirstMillisecond();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        java.util.Date date27 = day26.getEnd();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        boolean boolean29 = fixedMillisecond22.equals((java.lang.Object) date27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond31.getLastMillisecond(calendar32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        timeSeries3.addChangeListener(seriesChangeListener35);
        int int37 = timeSeries3.getMaximumItemCount();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2147483647 + "'", int37 == 2147483647);
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date1);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate7);
//        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getFollowingDayOfWeek(5);
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate8);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        int int13 = day12.getDayOfMonth();
//        java.lang.Class<?> wildcardClass14 = day12.getClass();
//        java.lang.Class class15 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getEnd();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.util.Date date20 = day19.getStart();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date20);
//        java.lang.Class class22 = null;
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.util.Date date24 = day23.getStart();
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date24);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
//        java.util.Date date28 = day27.getStart();
//        java.lang.Class class29 = null;
//        java.util.Date date30 = null;
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date28, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class22, date24, timeZone31);
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date20, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date17, timeZone31);
//        org.jfree.data.time.TimeSeries timeSeries37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate11, class15);
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate3, class15);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertNotNull(class15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.setMaximumItemCount(9999);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
        int int21 = year19.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month12, regularTimePeriod22);
        timeSeries23.setDomainDescription("Wed Dec 31 15:59:59 PST 1969");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeSeries23);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2147483647, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int1, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "hi!", class4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getStart();
//        java.lang.String str8 = day6.toString();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate11);
//        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getFollowingDayOfWeek(5);
//        int int15 = day6.compareTo((java.lang.Object) serialDate14);
//        org.jfree.data.time.SerialDate serialDate16 = day6.getSerialDate();
//        timeSeries5.setKey((java.lang.Comparable) day6);
//        java.lang.Class class18 = timeSeries5.getTimePeriodClass();
//        timeSeries5.setNotify(false);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNull(class18);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        long long6 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        int int9 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        java.lang.String str10 = timeSeries3.getRangeDescription();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.util.Date date12 = day11.getStart();
        int int13 = day11.getMonth();
        int int14 = day11.getMonth();
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day11, (double) 4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        java.lang.String str4 = timeSeries3.getDomainDescription();
        java.lang.String str5 = timeSeries3.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener6);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
        boolean boolean7 = spreadsheetDate1.isOnOrAfter(serialDate6);
        int int8 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate11);
        boolean boolean13 = spreadsheetDate1.isOnOrAfter(serialDate12);
        java.util.Date date14 = spreadsheetDate1.toDate();
        java.lang.String str15 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int18 = spreadsheetDate17.getDayOfMonth();
        int int19 = spreadsheetDate17.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate22 = spreadsheetDate17.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate24 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int25 = spreadsheetDate24.getDayOfMonth();
        int int26 = spreadsheetDate24.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate29 = spreadsheetDate24.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate28);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addDays(4, serialDate33);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate33);
        org.jfree.data.time.SerialDate serialDate37 = serialDate35.getPreviousDayOfWeek(7);
        boolean boolean38 = spreadsheetDate24.isBefore(serialDate37);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate41);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int45 = spreadsheetDate44.getDayOfMonth();
        int int46 = spreadsheetDate44.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate49 = spreadsheetDate44.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate48);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addDays(4, serialDate53);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate53);
        org.jfree.data.time.SerialDate serialDate57 = serialDate55.getPreviousDayOfWeek(7);
        boolean boolean58 = spreadsheetDate44.isBefore(serialDate57);
        boolean boolean60 = spreadsheetDate24.isInRange(serialDate42, serialDate57, (-457));
        boolean boolean61 = spreadsheetDate17.isOn((org.jfree.data.time.SerialDate) spreadsheetDate24);
        boolean boolean62 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate24);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1900 + "'", int19 == 1900);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 9 + "'", int25 == 9);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1900 + "'", int26 == 1900);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 9 + "'", int45 == 9);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1900 + "'", int46 == 1900);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        int int3 = month2.getYearValue();
        int int4 = month2.getMonth();
        java.lang.String[] strArray6 = org.jfree.data.time.SerialDate.getMonths(false);
        int int7 = month2.compareTo((java.lang.Object) strArray6);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.setMaximumItemCount(9999);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
        int int21 = year19.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month12, regularTimePeriod22);
        java.lang.Class class24 = timeSeries23.getTimePeriodClass();
        timeSeries23.removeAgedItems(true);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = timeSeries23.getTimePeriod((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNull(class24);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.setMaximumItemCount(9999);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
        int int21 = year19.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month12, regularTimePeriod22);
        java.lang.Object obj24 = timeSeries7.clone();
        timeSeries7.setNotify(false);
        java.lang.Class class27 = timeSeries7.getTimePeriodClass();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNull(class27);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        long long8 = fixedMillisecond5.getFirstMillisecond();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        boolean boolean12 = fixedMillisecond5.equals((java.lang.Object) date10);
        java.util.Calendar calendar13 = null;
        fixedMillisecond5.peg(calendar13);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        java.util.Date date17 = day16.getStart();
        int int18 = day16.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 12);
        boolean boolean21 = timeSeries3.isEmpty();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getDayOfMonth();
//        java.lang.String str4 = day2.toString();
//        java.util.Calendar calendar5 = null;
//        try {
//            day2.peg(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test381");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.Class class2 = null;
//        java.util.Date date3 = null;
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date1, timeZone4);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date1);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        int int10 = day8.getDayOfMonth();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        java.util.Date date12 = day11.getStart();
//        java.lang.Class class13 = null;
//        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day11, class13);
//        java.lang.String str15 = timeSeries14.getDomainDescription();
//        java.lang.String str16 = timeSeries14.getRangeDescription();
//        int int17 = timeSeries14.getItemCount();
//        boolean boolean18 = day8.equals((java.lang.Object) int17);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Value" + "'", str16.equals("Value"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        int int3 = month0.getMonth();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = month0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        int int2 = day0.getMonth();
//        int int3 = day0.getMonth();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        long long5 = day4.getLastMillisecond();
//        int int6 = day0.compareTo((java.lang.Object) long5);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.next();
        long long3 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (double) 0);
        long long6 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("June 2019");
        org.jfree.data.time.Year year2 = month1.getYear();
        long long3 = year2.getSerialIndex();
        org.junit.Assert.assertNotNull(month1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2019L + "'", long3 == 2019L);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 7);
        java.lang.Number number4 = timeSeriesDataItem3.getValue();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getFollowingDayOfWeek(5);
        int int11 = timeSeriesDataItem3.compareTo((java.lang.Object) 5);
        java.lang.Object obj12 = timeSeriesDataItem3.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem3.getPeriod();
        java.lang.Object obj14 = null;
        boolean boolean15 = timeSeriesDataItem3.equals(obj14);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 7 + "'", number4.equals(7));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getStart();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
//        java.lang.String str8 = timeSeries7.getDomainDescription();
//        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        timeSeries7.setMaximumItemCount(9999);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        java.lang.Class class15 = null;
//        java.util.Date date16 = null;
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
//        int int21 = year19.compareTo((java.lang.Object) "Saturday");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month12, regularTimePeriod22);
//        java.lang.Object obj24 = timeSeries7.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        int int29 = day28.getDayOfMonth();
//        java.lang.Class<?> wildcardClass30 = day28.getClass();
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond25, "Saturday", "Nearest", (java.lang.Class) wildcardClass30);
//        try {
//            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25, (java.lang.Number) (-1.0f), false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertNotNull(obj24);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertNotNull(wildcardClass30);
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        java.util.Date date7 = spreadsheetDate5.toDate();
        org.jfree.data.time.SerialDate serialDate8 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int11 = spreadsheetDate10.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate14);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate18);
        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate22 = serialDate14.getEndOfCurrentMonth(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate25);
        org.jfree.data.time.SerialDate serialDate28 = serialDate26.getFollowingDayOfWeek(5);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(serialDate28);
        java.lang.String str30 = serialDate28.toString();
        boolean boolean31 = spreadsheetDate10.isInRange(serialDate22, serialDate28);
        try {
            boolean boolean32 = spreadsheetDate5.isInRange(serialDate8, (org.jfree.data.time.SerialDate) spreadsheetDate10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "13-April-2000" + "'", str30.equals("13-April-2000"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

//    @Test
//    public void test389() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test389");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.util.Date date4 = day3.getStart();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date4);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
//        boolean boolean7 = spreadsheetDate1.isOnOrAfter(serialDate6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        java.lang.Class<?> wildcardClass10 = day8.getClass();
//        boolean boolean11 = spreadsheetDate1.equals((java.lang.Object) day8);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) spreadsheetDate1);
//        int int13 = spreadsheetDate1.getYYYY();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
//    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
        java.util.Date date3 = day0.getStart();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(date3);
        java.lang.Class class5 = null;
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
        java.util.Date date7 = day6.getStart();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date7);
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date7, timeZone9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date3, timeZone9);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(regularTimePeriod10);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        int int2 = day0.getMonth();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=Mon Jun 10 00:00:00 PDT 2019]");
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("Nearest");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Could not find separator.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar6 = null;
        fixedMillisecond5.peg(calendar6);
        long long8 = fixedMillisecond5.getFirstMillisecond();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        boolean boolean12 = fixedMillisecond5.equals((java.lang.Object) date10);
        java.util.Calendar calendar13 = null;
        fixedMillisecond5.peg(calendar13);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries3.getDataItem(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4);
        int int8 = year6.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        long long10 = year6.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.Class class2 = null;
//        java.util.Date date3 = null;
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date1, timeZone4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date1);
//        long long8 = fixedMillisecond7.getFirstMillisecond();
//        java.util.Calendar calendar9 = null;
//        long long10 = fixedMillisecond7.getLastMillisecond(calendar9);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560150000000L + "'", long8 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        long long10 = timeSeries7.getMaximumItemAge();
        timeSeries7.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9223372036854775807L + "'", long10 == 9223372036854775807L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        boolean boolean4 = fixedMillisecond1.equals((java.lang.Object) 1900);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate11 = serialDate8.getEndOfCurrentMonth(serialDate10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate8);
        boolean boolean13 = fixedMillisecond1.equals((java.lang.Object) day12);
        long long14 = day12.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 955263600000L + "'", long14 == 955263600000L);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day10, class12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.util.Date date15 = day14.getStart();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day14, class16);
        java.lang.String str18 = timeSeries17.getDomainDescription();
        java.util.Collection collection19 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        java.lang.String str20 = timeSeries13.getDomainDescription();
        java.util.Collection collection21 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        java.util.Date date23 = day22.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day22.next();
        java.util.Date date25 = day22.getStart();
        boolean boolean26 = timeSeries3.equals((java.lang.Object) day22);
        timeSeries3.setRangeDescription("");
        timeSeries3.setKey((java.lang.Comparable) 1560236399999L);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
//        timeSeries3.setMaximumItemAge(1L);
//        java.lang.Object obj6 = timeSeries3.clone();
//        boolean boolean7 = timeSeries3.isEmpty();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getStart();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.util.Date date13 = day12.getStart();
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
//        java.lang.String str16 = timeSeries15.getDomainDescription();
//        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
//        timeSeries15.clear();
//        boolean boolean19 = timeSeries15.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.addAndOrUpdate(timeSeries15);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries15.removeChangeListener(seriesChangeListener21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.util.Date date24 = day23.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day23.next();
//        long long26 = day23.getLastMillisecond();
//        java.lang.Number number27 = timeSeries15.getValue((org.jfree.data.time.RegularTimePeriod) day23);
//        org.jfree.data.time.TimeSeries timeSeries28 = null;
//        try {
//            java.util.Collection collection29 = timeSeries15.getTimePeriodsUniqueToOtherSeries(timeSeries28);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560236399999L + "'", long26 == 1560236399999L);
//        org.junit.Assert.assertNull(number27);
//    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(12, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        java.lang.String str3 = day0.toString();
//        java.util.Calendar calendar4 = null;
//        try {
//            long long5 = day0.getMiddleMillisecond(calendar4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 5);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 10);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int5 = spreadsheetDate4.getDayOfMonth();
        int int6 = spreadsheetDate4.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int12 = spreadsheetDate11.getDayOfMonth();
        int int13 = spreadsheetDate11.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate16 = spreadsheetDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addDays(4, serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate20);
        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getPreviousDayOfWeek(7);
        boolean boolean25 = spreadsheetDate11.isBefore(serialDate24);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int32 = spreadsheetDate31.getDayOfMonth();
        int int33 = spreadsheetDate31.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate36 = spreadsheetDate31.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addDays(4, serialDate40);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate40);
        org.jfree.data.time.SerialDate serialDate44 = serialDate42.getPreviousDayOfWeek(7);
        boolean boolean45 = spreadsheetDate31.isBefore(serialDate44);
        boolean boolean47 = spreadsheetDate11.isInRange(serialDate29, serialDate44, (-457));
        boolean boolean48 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int49 = spreadsheetDate11.getDayOfWeek();
        java.util.Date date50 = spreadsheetDate11.toDate();
        boolean boolean51 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate1);
        int int53 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 9 + "'", int32 == 9);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1900 + "'", int33 == 1900);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2 + "'", int49 == 2);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 9 + "'", int53 == 9);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        int int3 = month2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.clear();
        boolean boolean19 = timeSeries15.getNotify();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) 9999);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond22.getFirstMillisecond(calendar23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9999L + "'", long24 == 9999L);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        int int8 = month7.getMonth();
        java.lang.String str9 = month7.toString();
        int int10 = month3.compareTo((java.lang.Object) month7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month3.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "June 2019" + "'", str9.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Wed Dec 31 16:00:00 PST 1969");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(2019);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date1, timeZone4);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date1);
        java.util.Date date9 = month8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.util.Date date12 = day11.getStart();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date12);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.util.Date date16 = day15.getStart();
        java.lang.Class class17 = null;
        java.util.Date date18 = null;
        java.util.TimeZone timeZone19 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date18, timeZone19);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date16, timeZone19);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date12, timeZone19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(date12);
        java.lang.Class class24 = null;
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.util.Date date26 = day25.getStart();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date26);
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date26, timeZone28);
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date12, timeZone28);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date9, timeZone28);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (-1L));
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.String str3 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=-1]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=-1]" + "'", str3.equals("org.jfree.data.general.SeriesChangeEvent[source=-1]"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        timeSeries3.setDescription("10-June-2019");
        try {
            timeSeries3.setMaximumItemCount((-460));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesChangeEvent[source=Mon Jun 10 00:00:00 PDT 2019]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date1, timeZone4);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date1);
        int int8 = day7.getMonth();
        int int9 = day7.getMonth();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = day7.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 1, 2958465, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.setRangeDescription("");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        int int15 = month14.getMonth();
        int int17 = month14.compareTo((java.lang.Object) (-1.0d));
        timeSeries3.setKey((java.lang.Comparable) int17);
        timeSeries3.setRangeDescription("Saturday");
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        java.util.Date date22 = day21.getStart();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day21, class23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.util.Date date26 = day25.getStart();
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day25, class27);
        java.lang.String str29 = timeSeries28.getDomainDescription();
        java.util.Collection collection30 = timeSeries24.getTimePeriodsUniqueToOtherSeries(timeSeries28);
        timeSeries28.setMaximumItemCount(9999);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        java.util.Date date35 = day34.getEnd();
        java.lang.Class class36 = null;
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date35, timeZone38);
        int int42 = year40.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year40.previous();
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) month33, regularTimePeriod43);
        java.lang.Object obj45 = timeSeries28.clone();
        timeSeries28.setNotify(false);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
        java.util.Date date49 = day48.getStart();
        java.lang.Class class50 = null;
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day48, class50);
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar54 = null;
        fixedMillisecond53.peg(calendar54);
        long long56 = fixedMillisecond53.getFirstMillisecond();
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
        java.util.Date date58 = day57.getEnd();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date58);
        boolean boolean60 = fixedMillisecond53.equals((java.lang.Object) date58);
        java.util.Calendar calendar61 = null;
        fixedMillisecond53.peg(calendar61);
        timeSeries51.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53, (java.lang.Number) 3);
        timeSeries28.setMaximumItemAge((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries3.addAndOrUpdate(timeSeries28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = fixedMillisecond70.next();
        long long72 = fixedMillisecond70.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond70, (double) 0);
        try {
            timeSeries3.add(timeSeriesDataItem74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Time" + "'", str29.equals("Time"));
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem65);
        org.junit.Assert.assertNotNull(timeSeries68);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-1L) + "'", long72 == (-1L));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.clear();
        boolean boolean19 = timeSeries15.getNotify();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar23 = null;
        fixedMillisecond22.peg(calendar23);
        long long25 = fixedMillisecond22.getFirstMillisecond();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        java.util.Date date27 = day26.getEnd();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        boolean boolean29 = fixedMillisecond22.equals((java.lang.Object) date27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond31.getLastMillisecond(calendar32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
        java.util.Date date35 = fixedMillisecond22.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar38 = null;
        fixedMillisecond37.peg(calendar38);
        long long40 = fixedMillisecond37.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, 0.0d);
        java.lang.Object obj43 = timeSeriesDataItem42.clone();
        java.lang.Object obj44 = timeSeriesDataItem42.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent45 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem42);
        boolean boolean46 = fixedMillisecond22.equals((java.lang.Object) seriesChangeEvent45);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, 0.0d);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 7);
        java.lang.Number number11 = timeSeriesDataItem10.getValue();
        java.lang.Object obj12 = timeSeriesDataItem10.clone();
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate15);
        org.jfree.data.time.SerialDate serialDate18 = serialDate16.getFollowingDayOfWeek(5);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(serialDate16);
        java.lang.String str20 = serialDate16.toString();
        boolean boolean21 = timeSeriesDataItem10.equals((java.lang.Object) str20);
        boolean boolean22 = timeSeriesDataItem6.equals((java.lang.Object) boolean21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeriesDataItem6.getPeriod();
        java.lang.Number number24 = timeSeriesDataItem6.getValue();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 7 + "'", number11.equals(7));
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "9-April-2000" + "'", str20.equals("9-April-2000"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0.0d + "'", number24.equals(0.0d));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate5);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate9);
        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate13 = serialDate5.getEndOfCurrentMonth(serialDate12);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate16);
        org.jfree.data.time.SerialDate serialDate19 = serialDate17.getFollowingDayOfWeek(5);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate19);
        java.lang.String str21 = serialDate19.toString();
        boolean boolean22 = spreadsheetDate1.isInRange(serialDate13, serialDate19);
        org.jfree.data.time.SerialDate serialDate23 = null;
        org.jfree.data.time.SerialDate serialDate24 = null;
        try {
            boolean boolean26 = spreadsheetDate1.isInRange(serialDate23, serialDate24, (-36525));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "13-April-2000" + "'", str21.equals("13-April-2000"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(1, (int) 'a', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate5);
//        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getFollowingDayOfWeek(5);
//        int int9 = day0.compareTo((java.lang.Object) serialDate8);
//        org.jfree.data.time.SerialDate serialDate10 = day0.getSerialDate();
//        int int11 = day0.getYear();
//        java.util.Calendar calendar12 = null;
//        try {
//            long long13 = day0.getMiddleMillisecond(calendar12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2019 + "'", int11 == 2019);
//    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        int int3 = month0.getMonth();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day4, (java.lang.Number) 7);
        java.lang.Number number8 = timeSeriesDataItem7.getValue();
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate11);
        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getFollowingDayOfWeek(5);
        int int15 = timeSeriesDataItem7.compareTo((java.lang.Object) 5);
        java.lang.Number number16 = timeSeriesDataItem7.getValue();
        boolean boolean17 = month0.equals((java.lang.Object) timeSeriesDataItem7);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 7 + "'", number8.equals(7));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 7 + "'", number16.equals(7));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((-36525));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
        boolean boolean7 = spreadsheetDate1.isOnOrAfter(serialDate6);
        int int8 = spreadsheetDate1.toSerial();
        java.util.Date date9 = spreadsheetDate1.toDate();
        int int10 = spreadsheetDate1.getMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate5);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date9, timeZone12);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date9);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate15);
        boolean boolean17 = spreadsheetDate2.isInRange(serialDate6, serialDate15);
        try {
            org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) '4', serialDate15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.setMaximumItemCount(9999);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
        int int21 = year19.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month12, regularTimePeriod22);
        boolean boolean24 = timeSeries7.getNotify();
        timeSeries7.fireSeriesChanged();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        java.util.Date date7 = day4.getStart();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.setMaximumItemCount(9999);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        java.util.Date date22 = day21.getEnd();
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date22, timeZone25);
        int int29 = year27.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year27.previous();
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month20, regularTimePeriod30);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day4, regularTimePeriod30);
        timeSeries3.setNotify(false);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        java.util.Date date36 = day35.getStart();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(date36);
        int int38 = month37.getMonth();
        java.lang.String str39 = month37.toString();
        timeSeries3.setKey((java.lang.Comparable) str39);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "June 2019" + "'", str39.equals("June 2019"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.previous();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        int int7 = month6.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        int int9 = month6.getMonth();
        int int10 = year2.compareTo((java.lang.Object) int9);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        int int2 = day0.getMonth();
        int int3 = day0.getMonth();
        boolean boolean5 = day0.equals((java.lang.Object) 100L);
        java.lang.Object obj6 = null;
        boolean boolean7 = day0.equals(obj6);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        int int3 = month0.getYearValue();
        org.jfree.data.time.Year year4 = month0.getYear();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year4.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(year4);
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
//        timeSeries3.setMaximumItemAge(1L);
//        timeSeries3.setDescription("10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy(7, (int) (short) 100);
//        timeSeries10.setDomainDescription("");
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getDayOfMonth();
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int14, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "hi!", class17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.util.Date date20 = day19.getStart();
//        java.lang.String str21 = day19.toString();
//        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate24);
//        org.jfree.data.time.SerialDate serialDate27 = serialDate25.getFollowingDayOfWeek(5);
//        int int28 = day19.compareTo((java.lang.Object) serialDate27);
//        org.jfree.data.time.SerialDate serialDate29 = day19.getSerialDate();
//        timeSeries18.setKey((java.lang.Comparable) day19);
//        java.lang.Number number31 = null;
//        try {
//            timeSeries10.update((org.jfree.data.time.RegularTimePeriod) day19, number31);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeSeries10);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10-June-2019" + "'", str21.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertNotNull(serialDate29);
//    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SpreadsheetDate: Serial must be in range 2 to 2958465.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        long long3 = month2.getFirstMillisecond();
        org.jfree.data.time.Year year4 = month2.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertNotNull(year4);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        int int3 = spreadsheetDate1.getYYYY();
        int int4 = spreadsheetDate1.getYYYY();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("August");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        java.util.Calendar calendar5 = null;
        try {
            month2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, 0.0d);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int9 = spreadsheetDate8.getDayOfMonth();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        java.util.Date date14 = spreadsheetDate12.toDate();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.util.Date date16 = day15.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
        java.util.Date date18 = day15.getStart();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        boolean boolean20 = spreadsheetDate12.isOnOrAfter(serialDate19);
        java.util.Date date21 = spreadsheetDate12.toDate();
        int int22 = spreadsheetDate12.getDayOfMonth();
        boolean boolean23 = timeSeriesDataItem6.equals((java.lang.Object) spreadsheetDate12);
        java.lang.String str24 = spreadsheetDate12.toString();
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate29);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate33);
        org.jfree.data.time.SerialDate serialDate36 = serialDate34.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate37 = serialDate29.getEndOfCurrentMonth(serialDate36);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate40 = serialDate36.getEndOfCurrentMonth(serialDate39);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addYears(4, serialDate40);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) 1, serialDate40);
        org.jfree.data.time.SerialDate serialDate44 = serialDate40.getPreviousDayOfWeek(7);
        boolean boolean45 = spreadsheetDate12.isAfter(serialDate44);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 9 + "'", int22 == 9);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "9-April-1900" + "'", str24.equals("9-April-1900"));
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int1, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "hi!", class4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getStart();
//        java.lang.String str8 = day6.toString();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate11);
//        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getFollowingDayOfWeek(5);
//        int int15 = day6.compareTo((java.lang.Object) serialDate14);
//        org.jfree.data.time.SerialDate serialDate16 = day6.getSerialDate();
//        timeSeries5.setKey((java.lang.Comparable) day6);
//        java.lang.String str18 = day6.toString();
//        int int19 = day6.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10-June-2019" + "'", str18.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays(4, serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate6);
        org.jfree.data.time.SerialDate serialDate9 = serialDate2.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate11 = serialDate9.getPreviousDayOfWeek(1);
        try {
            org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears(9999, serialDate11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate11);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(3, 9999, (-459));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        int int8 = timeSeries3.getItemCount();
        timeSeries3.setMaximumItemCount(0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(7);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        long long8 = year6.getLastMillisecond();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getEnd();
        java.lang.Class class11 = null;
        java.util.Date date12 = null;
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date10, timeZone13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.previous();
        int int17 = year15.getYear();
        int int18 = year6.compareTo((java.lang.Object) year15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year6.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        java.lang.String str10 = timeSeries3.getDomainDescription();
        try {
            timeSeries3.delete((-457), 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -457");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Time" + "'", str10.equals("Time"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(1900);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(9999, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 9999");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode((int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        int int1 = day0.getMonth();
        java.util.Calendar calendar2 = null;
        try {
            day0.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day0.previous();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test454");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int1, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "hi!", class4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getStart();
//        java.lang.String str8 = day6.toString();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate11);
//        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getFollowingDayOfWeek(5);
//        int int15 = day6.compareTo((java.lang.Object) serialDate14);
//        org.jfree.data.time.SerialDate serialDate16 = day6.getSerialDate();
//        timeSeries5.setKey((java.lang.Comparable) day6);
//        java.lang.Class class18 = timeSeries5.getTimePeriodClass();
//        java.lang.Object obj19 = timeSeries5.clone();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNull(class18);
//        org.junit.Assert.assertNotNull(obj19);
//    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        boolean boolean8 = fixedMillisecond1.equals((java.lang.Object) date6);
        java.util.Calendar calendar9 = null;
        fixedMillisecond1.peg(calendar9);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond1.getFirstMillisecond(calendar11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        fixedMillisecond14.peg(calendar15);
        long long17 = fixedMillisecond14.getFirstMillisecond();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        java.util.Date date19 = day18.getEnd();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        boolean boolean21 = fixedMillisecond14.equals((java.lang.Object) date19);
        int int22 = fixedMillisecond1.compareTo((java.lang.Object) boolean21);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.clear();
        boolean boolean19 = timeSeries15.getNotify();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        java.util.Date date22 = day21.getEnd();
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date22, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
        long long29 = year27.getLastMillisecond();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
        java.util.Date date31 = day30.getEnd();
        java.lang.Class class32 = null;
        java.util.Date date33 = null;
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date33, timeZone34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year(date31, timeZone34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year36.previous();
        int int38 = year36.getYear();
        int int39 = year27.compareTo((java.lang.Object) year36);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year36, (double) 1560150000000L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year36.next();
        try {
            timeSeries20.add(regularTimePeriod42, (java.lang.Number) 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getEnd();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
//        java.util.Date date7 = day4.getStart();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getStart();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.util.Date date13 = day12.getStart();
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
//        java.lang.String str16 = timeSeries15.getDomainDescription();
//        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
//        timeSeries15.setMaximumItemCount(9999);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        java.util.Date date22 = day21.getEnd();
//        java.lang.Class class23 = null;
//        java.util.Date date24 = null;
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date22, timeZone25);
//        int int29 = year27.compareTo((java.lang.Object) "Saturday");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year27.previous();
//        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month20, regularTimePeriod30);
//        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day4, regularTimePeriod30);
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        java.util.Date date36 = day35.getStart();
//        int int37 = day35.getMonth();
//        int int38 = day35.getMonth();
//        boolean boolean40 = day35.equals((java.lang.Object) 100L);
//        long long41 = day35.getSerialIndex();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day35);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertNull(regularTimePeriod26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(timeSeries31);
//        org.junit.Assert.assertNotNull(timeSeries32);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 43626L + "'", long41 == 43626L);
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.setMaximumItemCount(9999);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
        int int21 = year19.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month12, regularTimePeriod22);
        boolean boolean24 = timeSeries7.getNotify();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.util.Date date26 = day25.getStart();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = month27.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = month27.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) month27);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        java.util.Date date32 = day31.getStart();
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day31, class33);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        java.util.Date date36 = day35.getStart();
        java.lang.Class class37 = null;
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day35, class37);
        java.lang.String str39 = timeSeries38.getDomainDescription();
        java.util.Collection collection40 = timeSeries34.getTimePeriodsUniqueToOtherSeries(timeSeries38);
        timeSeries38.setMaximumItemCount(9999);
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day();
        java.util.Date date45 = day44.getEnd();
        java.lang.Class class46 = null;
        java.util.Date date47 = null;
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class46, date47, timeZone48);
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date45, timeZone48);
        int int52 = year50.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = year50.previous();
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries38.createCopy((org.jfree.data.time.RegularTimePeriod) month43, regularTimePeriod53);
        java.lang.Object obj55 = timeSeries38.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener56 = null;
        timeSeries38.addChangeListener(seriesChangeListener56);
        java.util.Collection collection58 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries38);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Time" + "'", str39.equals("Time"));
        org.junit.Assert.assertNotNull(collection40);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(timeSeries54);
        org.junit.Assert.assertNotNull(obj55);
        org.junit.Assert.assertNotNull(collection58);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.clear();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.util.Date date12 = day11.getStart();
        java.lang.Class class13 = null;
        java.util.Date date14 = null;
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date14, timeZone15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date12, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date12);
        int int19 = day18.getMonth();
        timeSeries7.setKey((java.lang.Comparable) day18);
        try {
            timeSeries7.update((-460), (java.lang.Number) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate5);
//        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getFollowingDayOfWeek(5);
//        int int9 = day0.compareTo((java.lang.Object) serialDate8);
//        long long10 = day0.getLastMillisecond();
//        long long11 = day0.getSerialIndex();
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.util.Date date13 = day12.getStart();
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
//        boolean boolean15 = day0.equals((java.lang.Object) date13);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560236399999L + "'", long10 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        java.lang.String str3 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        int int5 = day0.getYear();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10-June-2019" + "'", str3.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2958465) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        timeSeries3.setDescription("10-June-2019");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date9, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year14);
        timeSeries3.setRangeDescription("Preceding");
        java.lang.Comparable comparable19 = timeSeries3.getKey();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(comparable19);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.setMaximumItemCount(9999);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
        int int21 = year19.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month12, regularTimePeriod22);
        java.lang.Object obj24 = timeSeries7.clone();
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate27);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate31);
        org.jfree.data.time.SerialDate serialDate34 = serialDate32.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate35 = serialDate27.getEndOfCurrentMonth(serialDate34);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate38);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate42 = serialDate39.getEndOfCurrentMonth(serialDate41);
        org.jfree.data.time.SerialDate serialDate43 = serialDate34.getEndOfCurrentMonth(serialDate39);
        timeSeries7.setKey((java.lang.Comparable) serialDate39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries7.addOrUpdate(regularTimePeriod45, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.setRangeDescription("");
        java.util.Collection collection12 = timeSeries3.getTimePeriods();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(collection12);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date1, timeZone4);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, (java.lang.Number) 10.0f);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date1);
        int int9 = month8.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int3 = spreadsheetDate2.getDayOfMonth();
        int int4 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addDays(4, serialDate11);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate11);
        org.jfree.data.time.SerialDate serialDate15 = serialDate13.getPreviousDayOfWeek(7);
        boolean boolean16 = spreadsheetDate2.isBefore(serialDate15);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int23 = spreadsheetDate22.getDayOfMonth();
        int int24 = spreadsheetDate22.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate27 = spreadsheetDate22.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate26);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addDays(4, serialDate31);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate31);
        org.jfree.data.time.SerialDate serialDate35 = serialDate33.getPreviousDayOfWeek(7);
        boolean boolean36 = spreadsheetDate22.isBefore(serialDate35);
        boolean boolean38 = spreadsheetDate2.isInRange(serialDate20, serialDate35, (-457));
        try {
            org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) '#', (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1900 + "'", int24 == 1900);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.clear();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.util.Date date12 = day11.getStart();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date12);
        int int14 = month13.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) (short) 0);
        timeSeries7.fireSeriesChanged();
        java.lang.String str19 = timeSeries7.getRangeDescription();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Value" + "'", str19.equals("Value"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(3, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        boolean boolean3 = day0.equals((java.lang.Object) 10.0d);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        try {
            timeSeries7.removeAgedItems((long) 100, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int5 = spreadsheetDate4.getDayOfMonth();
        int int6 = spreadsheetDate4.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int12 = spreadsheetDate11.getDayOfMonth();
        int int13 = spreadsheetDate11.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate16 = spreadsheetDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addDays(4, serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate20);
        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getPreviousDayOfWeek(7);
        boolean boolean25 = spreadsheetDate11.isBefore(serialDate24);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int32 = spreadsheetDate31.getDayOfMonth();
        int int33 = spreadsheetDate31.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate36 = spreadsheetDate31.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addDays(4, serialDate40);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate40);
        org.jfree.data.time.SerialDate serialDate44 = serialDate42.getPreviousDayOfWeek(7);
        boolean boolean45 = spreadsheetDate31.isBefore(serialDate44);
        boolean boolean47 = spreadsheetDate11.isInRange(serialDate29, serialDate44, (-457));
        boolean boolean48 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int49 = spreadsheetDate11.getDayOfWeek();
        java.util.Date date50 = spreadsheetDate11.toDate();
        boolean boolean51 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
        java.util.Date date54 = day53.getEnd();
        java.lang.Class class55 = null;
        java.util.Date date56 = null;
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class55, date56, timeZone57);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date54, timeZone57);
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.createInstance(date54);
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate60);
        boolean boolean62 = spreadsheetDate1.isOnOrBefore(serialDate60);
        int int63 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate69 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate70 = org.jfree.data.time.SerialDate.addDays(4, serialDate69);
        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate69);
        org.jfree.data.time.SerialDate serialDate72 = serialDate65.getEndOfCurrentMonth(serialDate69);
        org.jfree.data.time.SerialDate serialDate74 = serialDate72.getPreviousDayOfWeek(1);
        org.jfree.data.time.SerialDate serialDate76 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate80 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate81 = org.jfree.data.time.SerialDate.addDays(4, serialDate80);
        org.jfree.data.time.SerialDate serialDate82 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate80);
        org.jfree.data.time.SerialDate serialDate83 = serialDate76.getEndOfCurrentMonth(serialDate80);
        boolean boolean85 = spreadsheetDate1.isInRange(serialDate74, serialDate76, 9999);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 9 + "'", int32 == 9);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1900 + "'", int33 == 1900);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2 + "'", int49 == 2);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 9 + "'", int63 == 9);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertNotNull(serialDate70);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertNotNull(serialDate76);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertNotNull(serialDate81);
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("13-April-2000");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.setMaximumItemCount(9999);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
        int int21 = year19.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month12, regularTimePeriod22);
        java.lang.Object obj24 = timeSeries7.clone();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.util.Date date26 = day25.getStart();
        int int27 = day25.getMonth();
        int int28 = day25.getMonth();
        boolean boolean30 = day25.equals((java.lang.Object) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day25, (double) 10.0f);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        java.util.Date date34 = day33.getStart();
        java.lang.Class class35 = null;
        java.util.Date date36 = null;
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date36, timeZone37);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date34, timeZone37);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date34);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date34);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day41.previous();
        try {
            timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day41, (java.lang.Number) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem32);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) 1900);
        timeSeriesDataItem4.setValue((java.lang.Number) 1560236399999L);
        timeSeriesDataItem4.setValue((java.lang.Number) 7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(2958465, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        boolean boolean8 = fixedMillisecond1.equals((java.lang.Object) date6);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(date6);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        int int3 = month2.getMonth();
        int int5 = month2.compareTo((java.lang.Object) (-1.0d));
        int int6 = month2.getMonth();
        java.lang.String str7 = month2.toString();
        int int8 = month2.getMonth();
        java.util.Calendar calendar9 = null;
        try {
            month2.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        int int3 = month2.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.setMaximumItemCount(9999);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
        int int21 = year19.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month12, regularTimePeriod22);
        java.lang.String str24 = timeSeries7.getRangeDescription();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.util.Date date26 = day25.getStart();
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date26, timeZone29);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year32.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year32, (double) 9);
        java.util.Calendar calendar37 = null;
        try {
            long long38 = year32.getFirstMillisecond(calendar37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Value" + "'", str24.equals("Value"));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNull(timeSeriesDataItem36);
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        java.util.Date date2 = day1.getStart();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.util.Date date6 = day5.getStart();
//        java.lang.Class class7 = null;
//        java.util.Date date8 = null;
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date6, timeZone9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date2);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getFirstMillisecond(calendar14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond13.previous();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560150000000L + "'", long15 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        timeSeries3.setDescription("10-June-2019");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date9, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year14);
        timeSeries3.setRangeDescription("Preceding");
        timeSeries3.setDomainDescription("ERROR : Relative To String");
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = fixedMillisecond22.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond22.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond22.previous();
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond22.getMiddleMillisecond(calendar26);
        java.util.Date date28 = fixedMillisecond22.getTime();
        int int29 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar32 = null;
        fixedMillisecond31.peg(calendar32);
        long long34 = fixedMillisecond31.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, 0.0d);
        java.util.Date date37 = fixedMillisecond31.getTime();
        long long38 = fixedMillisecond31.getLastMillisecond();
        java.util.Calendar calendar39 = null;
        fixedMillisecond31.peg(calendar39);
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond31, (double) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-1L) + "'", long27 == (-1L));
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int5 = spreadsheetDate4.getDayOfMonth();
        int int6 = spreadsheetDate4.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int12 = spreadsheetDate11.getDayOfMonth();
        int int13 = spreadsheetDate11.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate16 = spreadsheetDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addDays(4, serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate20);
        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getPreviousDayOfWeek(7);
        boolean boolean25 = spreadsheetDate11.isBefore(serialDate24);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int32 = spreadsheetDate31.getDayOfMonth();
        int int33 = spreadsheetDate31.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate36 = spreadsheetDate31.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addDays(4, serialDate40);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate40);
        org.jfree.data.time.SerialDate serialDate44 = serialDate42.getPreviousDayOfWeek(7);
        boolean boolean45 = spreadsheetDate31.isBefore(serialDate44);
        boolean boolean47 = spreadsheetDate11.isInRange(serialDate29, serialDate44, (-457));
        boolean boolean48 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int49 = spreadsheetDate11.getDayOfWeek();
        java.util.Date date50 = spreadsheetDate11.toDate();
        boolean boolean51 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day();
        java.util.Date date54 = day53.getEnd();
        java.lang.Class class55 = null;
        java.util.Date date56 = null;
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class55, date56, timeZone57);
        org.jfree.data.time.Year year59 = new org.jfree.data.time.Year(date54, timeZone57);
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.createInstance(date54);
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate60);
        boolean boolean62 = spreadsheetDate1.isOnOrBefore(serialDate60);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent63 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) spreadsheetDate1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 9 + "'", int32 == 9);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1900 + "'", int33 == 1900);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2 + "'", int49 == 2);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addDays(4, serialDate3);
        java.lang.String str5 = serialDate4.toString();
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((int) (byte) 10, serialDate4);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "13-April-1900" + "'", str5.equals("13-April-1900"));
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        timeSeries3.setDescription("10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy(7, (int) (short) 100);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.util.Date date12 = day11.getStart();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day11, class13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.util.Date date16 = day15.getStart();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day15, class17);
        java.lang.String str19 = timeSeries18.getDomainDescription();
        java.util.Collection collection20 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        timeSeries14.setRangeDescription("");
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        java.util.Date date24 = day23.getStart();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date24);
        int int26 = month25.getMonth();
        int int28 = month25.compareTo((java.lang.Object) (-1.0d));
        timeSeries14.setKey((java.lang.Comparable) int28);
        timeSeries14.setRangeDescription("Saturday");
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(0L);
        int int35 = fixedMillisecond33.compareTo((java.lang.Object) 100.0f);
        java.util.Date date36 = fixedMillisecond33.getTime();
        boolean boolean37 = timeSeries14.equals((java.lang.Object) date36);
        timeSeries14.setDescription("org.jfree.data.time.TimePeriodFormatException: 13-April-1900");
        java.util.Collection collection40 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeSeries10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Time" + "'", str19.equals("Time"));
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(collection40);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10, 1, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(2019, 12, 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate3);
        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getFollowingDayOfWeek(5);
        serialDate4.setDescription("Preceding");
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addDays(9, serialDate4);
        java.lang.Class<?> wildcardClass10 = serialDate4.getClass();
        java.lang.Class class11 = null;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date13);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
        java.util.Date date17 = day16.getStart();
        java.lang.Class class18 = null;
        java.util.Date date19 = null;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date17, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date13, timeZone20);
        java.lang.Class class24 = null;
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.util.Date date26 = day25.getStart();
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date26);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date26);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        java.util.Date date30 = day29.getStart();
        java.lang.Class class31 = null;
        java.util.Date date32 = null;
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date32, timeZone33);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date30, timeZone33);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date26, timeZone33);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month(date13, timeZone33);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day();
        java.util.Date date39 = day38.getStart();
        java.lang.Class class40 = null;
        java.util.Date date41 = null;
        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class40, date41, timeZone42);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date39, timeZone42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date13, timeZone42);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertNotNull(timeZone42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNull(regularTimePeriod45);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.setMaximumItemCount(9999);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
        int int21 = year19.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month12, regularTimePeriod22);
        java.lang.Object obj24 = timeSeries7.clone();
        timeSeries7.setNotify(false);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        java.util.Date date28 = day27.getStart();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day27, class29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar33 = null;
        fixedMillisecond32.peg(calendar33);
        long long35 = fixedMillisecond32.getFirstMillisecond();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
        java.util.Date date37 = day36.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        boolean boolean39 = fixedMillisecond32.equals((java.lang.Object) date37);
        java.util.Calendar calendar40 = null;
        fixedMillisecond32.peg(calendar40);
        timeSeries30.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries7.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 3);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond32, (java.lang.Number) 0.0f);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 7);
        java.lang.Number number4 = timeSeriesDataItem3.getValue();
        java.lang.Object obj5 = null;
        int int6 = timeSeriesDataItem3.compareTo(obj5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeriesDataItem3.getPeriod();
        java.lang.Object obj8 = null;
        boolean boolean9 = timeSeriesDataItem3.equals(obj8);
        java.lang.Number number10 = null;
        timeSeriesDataItem3.setValue(number10);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 7 + "'", number4.equals(7));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate3);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate7 = serialDate4.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate4);
        try {
            org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addMonths((-36525), serialDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        java.lang.String str4 = timeSeries3.getDomainDescription();
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.previous();
        long long9 = fixedMillisecond7.getLastMillisecond();
        int int10 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        timeSeries3.setDescription("10-June-2019");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date9, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year14);
        timeSeries3.setRangeDescription("Preceding");
        timeSeries3.setDomainDescription("ERROR : Relative To String");
        boolean boolean21 = timeSeries3.isEmpty();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.clear();
        boolean boolean19 = timeSeries15.getNotify();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar23 = null;
        fixedMillisecond22.peg(calendar23);
        long long25 = fixedMillisecond22.getFirstMillisecond();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        java.util.Date date27 = day26.getEnd();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        boolean boolean29 = fixedMillisecond22.equals((java.lang.Object) date27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond31.getLastMillisecond(calendar32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
        java.util.Calendar calendar35 = null;
        fixedMillisecond31.peg(calendar35);
        java.util.Calendar calendar37 = null;
        long long38 = fixedMillisecond31.getMiddleMillisecond(calendar37);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
    }
}

