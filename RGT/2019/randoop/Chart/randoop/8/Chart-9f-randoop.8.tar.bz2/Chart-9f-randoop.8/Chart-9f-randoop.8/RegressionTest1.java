import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        java.util.Date date2 = day1.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        java.lang.Class class7 = null;
        java.util.Date date8 = null;
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date6, timeZone9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone9);
        java.lang.Class class13 = null;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.util.Date date15 = day14.getStart();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        java.util.Date date19 = day18.getStart();
        java.lang.Class class20 = null;
        java.util.Date date21 = null;
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date19, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date15, timeZone22);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date2, timeZone22);
        java.lang.String str27 = month26.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "June 2019" + "'", str27.equals("June 2019"));
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.Class class2 = null;
//        java.util.Date date3 = null;
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date1, timeZone4);
//        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date1);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day8.previous();
//        int int10 = day8.getDayOfMonth();
//        java.util.Calendar calendar11 = null;
//        try {
//            long long12 = day8.getFirstMillisecond(calendar11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        java.util.Date date3 = day2.getEnd();
        java.lang.Class class4 = null;
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date5, timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date3, timeZone6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getSerialIndex();
        int int11 = month0.compareTo((java.lang.Object) long10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month0.next();
        org.jfree.data.time.Year year13 = month0.getYear();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.util.Date date15 = day14.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date15);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date15);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date15);
        int int19 = month0.compareTo((java.lang.Object) month18);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.clear();
        boolean boolean19 = timeSeries15.getNotify();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.addAndOrUpdate(timeSeries15);
        java.lang.Class class21 = timeSeries3.getTimePeriodClass();
        timeSeries3.clear();
        timeSeries3.removeAgedItems(true);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNull(class21);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        timeSeries3.setMaximumItemCount(31);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        long long8 = year6.getLastMillisecond();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getEnd();
        java.lang.Class class11 = null;
        java.util.Date date12 = null;
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date10, timeZone13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.previous();
        int int17 = year15.getYear();
        int int18 = year6.compareTo((java.lang.Object) year15);
        long long19 = year6.getLastMillisecond();
        java.util.Calendar calendar20 = null;
        try {
            long long21 = year6.getLastMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        java.lang.String str4 = month3.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("June 2019");
        org.jfree.data.time.Year year2 = month1.getYear();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getStart();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day3, class5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day7.next();
        java.util.Date date10 = day7.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.util.Date date12 = day11.getStart();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day11, class13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.util.Date date16 = day15.getStart();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day15, class17);
        java.lang.String str19 = timeSeries18.getDomainDescription();
        java.util.Collection collection20 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        timeSeries18.setMaximumItemCount(9999);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        java.util.Date date25 = day24.getEnd();
        java.lang.Class class26 = null;
        java.util.Date date27 = null;
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date27, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date25, timeZone28);
        int int32 = year30.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year30.previous();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) month23, regularTimePeriod33);
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) day7, regularTimePeriod33);
        boolean boolean36 = month1.equals((java.lang.Object) day7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day7.next();
        org.junit.Assert.assertNotNull(month1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Time" + "'", str19.equals("Time"));
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.clear();
        boolean boolean19 = timeSeries15.getNotify();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.addAndOrUpdate(timeSeries15);
        timeSeries3.clear();
        try {
            timeSeries3.delete(0, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(7, (int) (byte) 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
        java.util.Date date7 = fixedMillisecond1.getTime();
        long long8 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.setRangeDescription("");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        int int15 = month14.getMonth();
        int int17 = month14.compareTo((java.lang.Object) (-1.0d));
        timeSeries3.setKey((java.lang.Comparable) int17);
        timeSeries3.setRangeDescription("Saturday");
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        java.util.Date date22 = day21.getStart();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day21, class23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.util.Date date26 = day25.getStart();
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day25, class27);
        java.lang.String str29 = timeSeries28.getDomainDescription();
        java.util.Collection collection30 = timeSeries24.getTimePeriodsUniqueToOtherSeries(timeSeries28);
        timeSeries28.setMaximumItemCount(9999);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        java.util.Date date35 = day34.getEnd();
        java.lang.Class class36 = null;
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date35, timeZone38);
        int int42 = year40.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year40.previous();
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) month33, regularTimePeriod43);
        java.lang.Object obj45 = timeSeries28.clone();
        timeSeries28.setNotify(false);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
        java.util.Date date49 = day48.getStart();
        java.lang.Class class50 = null;
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day48, class50);
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar54 = null;
        fixedMillisecond53.peg(calendar54);
        long long56 = fixedMillisecond53.getFirstMillisecond();
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
        java.util.Date date58 = day57.getEnd();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date58);
        boolean boolean60 = fixedMillisecond53.equals((java.lang.Object) date58);
        java.util.Calendar calendar61 = null;
        fixedMillisecond53.peg(calendar61);
        timeSeries51.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53, (java.lang.Number) 3);
        timeSeries28.setMaximumItemAge((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries3.addAndOrUpdate(timeSeries28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond(0L);
        int int72 = fixedMillisecond70.compareTo((java.lang.Object) 100.0f);
        java.util.Date date73 = fixedMillisecond70.getTime();
        java.util.Calendar calendar74 = null;
        long long75 = fixedMillisecond70.getLastMillisecond(calendar74);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries68.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond70, (double) (byte) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = null;
        try {
            timeSeries68.delete(regularTimePeriod78);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Time" + "'", str29.equals("Time"));
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem65);
        org.junit.Assert.assertNotNull(timeSeries68);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 0L + "'", long75 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem77);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        java.lang.String str3 = regularTimePeriod2.toString();
        java.util.Date date4 = regularTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Wed Dec 31 15:59:59 PST 1969" + "'", str3.equals("Wed Dec 31 15:59:59 PST 1969"));
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        long long6 = timeSeries3.getMaximumItemAge();
        timeSeries3.removeAgedItems(false);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date1, timeZone4);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date1);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date1);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        java.lang.String str8 = year6.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.util.Date date3 = day2.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) 7);
//        int int6 = fixedMillisecond1.compareTo((java.lang.Object) timeSeriesDataItem5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getDayOfMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int8, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "hi!", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getStart();
//        java.lang.String str15 = day13.toString();
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate18);
//        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getFollowingDayOfWeek(5);
//        int int22 = day13.compareTo((java.lang.Object) serialDate21);
//        org.jfree.data.time.SerialDate serialDate23 = day13.getSerialDate();
//        timeSeries12.setKey((java.lang.Comparable) day13);
//        java.lang.Class class25 = timeSeries12.getTimePeriodClass();
//        timeSeries12.setRangeDescription("");
//        boolean boolean28 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        timeSeriesDataItem5.setValue((java.lang.Number) (short) 0);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNull(class25);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        long long8 = regularTimePeriod7.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1530561599999L + "'", long8 == 1530561599999L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        java.util.Date date2 = day1.getStart();
        java.lang.Class class3 = null;
        java.util.Date date4 = null;
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date4, timeZone5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date2, timeZone5);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date2);
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date2);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNull(regularTimePeriod11);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.setRangeDescription("");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        int int15 = month14.getMonth();
        int int17 = month14.compareTo((java.lang.Object) (-1.0d));
        timeSeries3.setKey((java.lang.Comparable) int17);
        timeSeries3.setRangeDescription("Saturday");
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        java.util.Date date22 = day21.getStart();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day21, class23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.util.Date date26 = day25.getStart();
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day25, class27);
        java.lang.String str29 = timeSeries28.getDomainDescription();
        java.util.Collection collection30 = timeSeries24.getTimePeriodsUniqueToOtherSeries(timeSeries28);
        timeSeries28.setMaximumItemCount(9999);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        java.util.Date date35 = day34.getEnd();
        java.lang.Class class36 = null;
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date35, timeZone38);
        int int42 = year40.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year40.previous();
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) month33, regularTimePeriod43);
        java.lang.Object obj45 = timeSeries28.clone();
        timeSeries28.setNotify(false);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
        java.util.Date date49 = day48.getStart();
        java.lang.Class class50 = null;
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day48, class50);
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar54 = null;
        fixedMillisecond53.peg(calendar54);
        long long56 = fixedMillisecond53.getFirstMillisecond();
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
        java.util.Date date58 = day57.getEnd();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date58);
        boolean boolean60 = fixedMillisecond53.equals((java.lang.Object) date58);
        java.util.Calendar calendar61 = null;
        fixedMillisecond53.peg(calendar61);
        timeSeries51.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53, (java.lang.Number) 3);
        timeSeries28.setMaximumItemAge((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries3.addAndOrUpdate(timeSeries28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond(0L);
        int int72 = fixedMillisecond70.compareTo((java.lang.Object) 100.0f);
        java.util.Date date73 = fixedMillisecond70.getTime();
        java.util.Calendar calendar74 = null;
        long long75 = fixedMillisecond70.getLastMillisecond(calendar74);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries68.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond70, (double) (byte) 0);
        org.jfree.data.time.SerialDate serialDate80 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate81 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate80);
        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate84 = serialDate81.getEndOfCurrentMonth(serialDate83);
        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day(serialDate81);
        timeSeries68.delete((org.jfree.data.time.RegularTimePeriod) day85);
        int int87 = day85.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Time" + "'", str29.equals("Time"));
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem65);
        org.junit.Assert.assertNotNull(timeSeries68);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 0L + "'", long75 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem77);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertNotNull(serialDate81);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 4 + "'", int87 == 4);
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.previous();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = regularTimePeriod4.getMiddleMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.clear();
        boolean boolean19 = timeSeries15.getNotify();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.addAndOrUpdate(timeSeries15);
        java.lang.Class class21 = timeSeries15.getTimePeriodClass();
        java.util.Collection collection22 = timeSeries15.getTimePeriods();
        java.lang.String str23 = timeSeries15.getDomainDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond((long) 9999);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond25.previous();
        timeSeries15.setKey((java.lang.Comparable) regularTimePeriod26);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Time" + "'", str23.equals("Time"));
        org.junit.Assert.assertNotNull(regularTimePeriod26);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable throwable2 = null;
        try {
            seriesException1.addSuppressed(throwable2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addDays(4, serialDate4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate4);
        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getPreviousDayOfWeek(7);
        try {
            org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (byte) -1, serialDate6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 7);
        java.util.Calendar calendar4 = null;
        try {
            day0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        boolean boolean4 = spreadsheetDate1.equals((java.lang.Object) 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        java.lang.Class class2 = null;
//        java.util.Date date3 = null;
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        long long8 = year6.getLastMillisecond();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        java.lang.Class class11 = null;
//        java.util.Date date12 = null;
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date10, timeZone13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.previous();
//        int int17 = year15.getYear();
//        int int18 = year6.compareTo((java.lang.Object) year15);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year15, (double) 1560150000000L);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        int int23 = spreadsheetDate22.getDayOfMonth();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.util.Date date25 = day24.getStart();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date25);
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date25);
//        boolean boolean28 = spreadsheetDate22.isOnOrAfter(serialDate27);
//        int int29 = spreadsheetDate22.toSerial();
//        int int30 = spreadsheetDate22.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        int int33 = spreadsheetDate32.getDayOfMonth();
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.util.Date date35 = day34.getStart();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date35);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance(date35);
//        boolean boolean38 = spreadsheetDate32.isOnOrAfter(serialDate37);
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        int int40 = day39.getDayOfMonth();
//        java.lang.Class<?> wildcardClass41 = day39.getClass();
//        boolean boolean42 = spreadsheetDate32.equals((java.lang.Object) day39);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent43 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) spreadsheetDate32);
//        boolean boolean44 = spreadsheetDate22.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate32);
//        int int45 = spreadsheetDate22.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        int int48 = spreadsheetDate47.getDayOfMonth();
//        int int49 = spreadsheetDate47.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate52 = spreadsheetDate47.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate51);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        int int55 = spreadsheetDate54.getDayOfMonth();
//        int int56 = spreadsheetDate54.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate58 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate59 = spreadsheetDate54.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate58);
//        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.addDays(4, serialDate63);
//        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate63);
//        org.jfree.data.time.SerialDate serialDate67 = serialDate65.getPreviousDayOfWeek(7);
//        boolean boolean68 = spreadsheetDate54.isBefore(serialDate67);
//        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate71);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate74 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        int int75 = spreadsheetDate74.getDayOfMonth();
//        int int76 = spreadsheetDate74.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate78 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate79 = spreadsheetDate74.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate78);
//        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate84 = org.jfree.data.time.SerialDate.addDays(4, serialDate83);
//        org.jfree.data.time.SerialDate serialDate85 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate83);
//        org.jfree.data.time.SerialDate serialDate87 = serialDate85.getPreviousDayOfWeek(7);
//        boolean boolean88 = spreadsheetDate74.isBefore(serialDate87);
//        boolean boolean90 = spreadsheetDate54.isInRange(serialDate72, serialDate87, (-457));
//        boolean boolean91 = spreadsheetDate47.isOn((org.jfree.data.time.SerialDate) spreadsheetDate54);
//        int int92 = spreadsheetDate54.getDayOfWeek();
//        boolean boolean93 = spreadsheetDate22.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate54);
//        boolean boolean94 = year15.equals((java.lang.Object) spreadsheetDate54);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 100 + "'", int29 == 100);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1900 + "'", int30 == 1900);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 9 + "'", int33 == 9);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 9 + "'", int48 == 9);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1900 + "'", int49 == 1900);
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 9 + "'", int55 == 9);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1900 + "'", int56 == 1900);
//        org.junit.Assert.assertNotNull(serialDate59);
//        org.junit.Assert.assertNotNull(serialDate63);
//        org.junit.Assert.assertNotNull(serialDate64);
//        org.junit.Assert.assertNotNull(serialDate65);
//        org.junit.Assert.assertNotNull(serialDate67);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertNotNull(serialDate71);
//        org.junit.Assert.assertNotNull(serialDate72);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 9 + "'", int75 == 9);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1900 + "'", int76 == 1900);
//        org.junit.Assert.assertNotNull(serialDate79);
//        org.junit.Assert.assertNotNull(serialDate83);
//        org.junit.Assert.assertNotNull(serialDate84);
//        org.junit.Assert.assertNotNull(serialDate85);
//        org.junit.Assert.assertNotNull(serialDate87);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
//        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
//        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 2 + "'", int92 == 2);
//        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
//        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str2 = seriesException1.toString();
        java.lang.String str3 = seriesException1.toString();
        java.lang.Throwable[] throwableArray4 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray5 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray6 = seriesException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str2.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str3.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.util.Date date4 = day3.getStart();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date4);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
//        boolean boolean7 = spreadsheetDate1.isOnOrAfter(serialDate6);
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        int int9 = day8.getDayOfMonth();
//        java.lang.Class<?> wildcardClass10 = day8.getClass();
//        boolean boolean11 = spreadsheetDate1.equals((java.lang.Object) day8);
//        java.lang.String str12 = spreadsheetDate1.toString();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9-April-1900" + "'", str12.equals("9-April-1900"));
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries7.createCopy((int) (byte) 10, (int) 'a');
        try {
            timeSeries7.update(2958465, (java.lang.Number) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2958465, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(timeSeries13);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day10, class12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.util.Date date15 = day14.getStart();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day14, class16);
        java.lang.String str18 = timeSeries17.getDomainDescription();
        java.util.Collection collection19 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        java.lang.String str20 = timeSeries13.getDomainDescription();
        java.util.Collection collection21 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        java.util.Date date23 = day22.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day22.next();
        java.util.Date date25 = day22.getStart();
        boolean boolean26 = timeSeries3.equals((java.lang.Object) day22);
        timeSeries3.setDescription("org.jfree.data.general.SeriesException: hi!");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        int int3 = month0.getYearValue();
        org.jfree.data.time.Year year4 = month0.getYear();
        long long5 = year4.getFirstMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year4.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.Class class2 = null;
//        java.util.Date date3 = null;
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date1, timeZone4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getFirstMillisecond(calendar8);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date1, timeZone4);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date1);
        int int9 = day8.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Nearest" + "'", str1.equals("Nearest"));
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date1);
//        int int3 = day2.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = day2.previous();
//        long long5 = day2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day2.previous();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560150000000L + "'", long5 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
//        timeSeries3.setMaximumItemAge(1L);
//        java.lang.Object obj6 = timeSeries3.clone();
//        boolean boolean7 = timeSeries3.isEmpty();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        java.util.Date date9 = day8.getStart();
//        java.lang.Class class10 = null;
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.util.Date date13 = day12.getStart();
//        java.lang.Class class14 = null;
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
//        java.lang.String str16 = timeSeries15.getDomainDescription();
//        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
//        timeSeries15.clear();
//        boolean boolean19 = timeSeries15.getNotify();
//        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.addAndOrUpdate(timeSeries15);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar23 = null;
//        fixedMillisecond22.peg(calendar23);
//        long long25 = fixedMillisecond22.getFirstMillisecond();
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
//        java.util.Date date27 = day26.getEnd();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
//        boolean boolean29 = fixedMillisecond22.equals((java.lang.Object) date27);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar32 = null;
//        long long33 = fixedMillisecond31.getLastMillisecond(calendar32);
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
//        java.util.Date date35 = fixedMillisecond22.getTime();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        int int38 = spreadsheetDate37.getDayOfMonth();
//        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
//        java.util.Date date40 = day39.getStart();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date40);
//        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(date40);
//        boolean boolean43 = spreadsheetDate37.isOnOrAfter(serialDate42);
//        int int44 = spreadsheetDate37.toSerial();
//        java.util.Date date45 = spreadsheetDate37.toDate();
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
//        int int47 = fixedMillisecond22.compareTo((java.lang.Object) date45);
//        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
//        java.util.Date date49 = day48.getStart();
//        java.lang.String str50 = day48.toString();
//        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate53);
//        org.jfree.data.time.SerialDate serialDate56 = serialDate54.getFollowingDayOfWeek(5);
//        int int57 = day48.compareTo((java.lang.Object) serialDate56);
//        org.jfree.data.time.SerialDate serialDate58 = day48.getSerialDate();
//        java.util.Date date59 = day48.getStart();
//        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(date59);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond62 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int64 = fixedMillisecond62.compareTo((java.lang.Object) 100.0f);
//        java.util.Date date65 = fixedMillisecond62.getTime();
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day();
//        java.util.Date date67 = day66.getEnd();
//        java.lang.Class class68 = null;
//        java.util.Date date69 = null;
//        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance(class68, date69, timeZone70);
//        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(date67, timeZone70);
//        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day(date65, timeZone70);
//        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date59, timeZone70);
//        org.jfree.data.time.Month month75 = new org.jfree.data.time.Month(date45, timeZone70);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(timeSeries20);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
//        org.junit.Assert.assertNotNull(date27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 9 + "'", int38 == 9);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 100 + "'", int44 == 100);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//        org.junit.Assert.assertNotNull(date49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "10-June-2019" + "'", str50.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1 + "'", int57 == 1);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1 + "'", int64 == 1);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(date67);
//        org.junit.Assert.assertNotNull(timeZone70);
//        org.junit.Assert.assertNull(regularTimePeriod71);
//    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.Class class2 = null;
//        java.util.Date date3 = null;
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date1, timeZone4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
//        long long10 = fixedMillisecond7.getSerialIndex();
//        java.util.Date date11 = fixedMillisecond7.getEnd();
//        java.util.Calendar calendar12 = null;
//        long long13 = fixedMillisecond7.getFirstMillisecond(calendar12);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560150000000L + "'", long13 == 1560150000000L);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date1, timeZone4);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date1);
        java.util.Date date9 = month8.getStart();
        long long10 = month8.getLastMillisecond();
        java.util.Calendar calendar11 = null;
        try {
            month8.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.setMaximumItemCount(9999);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
        int int21 = year19.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month12, regularTimePeriod22);
        java.lang.String str24 = timeSeries7.getRangeDescription();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.util.Date date26 = day25.getStart();
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day25, class27);
        timeSeries28.setMaximumItemAge(1L);
        timeSeries28.setDescription("10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries7.addAndOrUpdate(timeSeries28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = null;
        try {
            java.lang.Number number35 = timeSeries7.getValue(regularTimePeriod34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Value" + "'", str24.equals("Value"));
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeSeries33);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date1);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond(date1);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date1);
        java.lang.String str6 = month5.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "June 2019" + "'", str6.equals("June 2019"));
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
//        timeSeries3.setMaximumItemAge(1L);
//        java.lang.Object obj6 = timeSeries3.clone();
//        boolean boolean7 = timeSeries3.isEmpty();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        java.lang.String str9 = month8.toString();
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        java.util.Date date11 = day10.getEnd();
//        java.lang.Class class12 = null;
//        java.util.Date date13 = null;
//        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
//        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date11, timeZone14);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
//        long long18 = year16.getSerialIndex();
//        int int19 = month8.compareTo((java.lang.Object) long18);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month8.next();
//        org.jfree.data.time.Year year21 = month8.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.previous();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.util.Date date24 = day23.getEnd();
//        java.lang.Class class25 = null;
//        java.util.Date date26 = null;
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone27);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date24, timeZone27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year29.previous();
//        long long31 = year29.getLastMillisecond();
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        java.util.Date date33 = day32.getEnd();
//        java.lang.Class class34 = null;
//        java.util.Date date35 = null;
//        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date35, timeZone36);
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date33, timeZone36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.previous();
//        int int40 = year38.getYear();
//        int int41 = year29.compareTo((java.lang.Object) year38);
//        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries3.createCopy(regularTimePeriod22, (org.jfree.data.time.RegularTimePeriod) year38);
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        java.util.Date date44 = day43.getStart();
//        java.lang.String str45 = day43.toString();
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate48);
//        org.jfree.data.time.SerialDate serialDate51 = serialDate49.getFollowingDayOfWeek(5);
//        int int52 = day43.compareTo((java.lang.Object) serialDate51);
//        long long53 = day43.getMiddleMillisecond();
//        int int54 = day43.getMonth();
//        try {
//            timeSeries42.update((org.jfree.data.time.RegularTimePeriod) day43, (java.lang.Number) 955263600000L);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "June 2019" + "'", str9.equals("June 2019"));
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone14);
//        org.junit.Assert.assertNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertNotNull(year21);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date33);
//        org.junit.Assert.assertNotNull(timeZone36);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertNotNull(timeSeries42);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "10-June-2019" + "'", str45.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate48);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(serialDate51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1560193199999L + "'", long53 == 1560193199999L);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 6 + "'", int54 == 6);
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.setMaximumItemCount(9999);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
        int int21 = year19.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month12, regularTimePeriod22);
        java.lang.Object obj24 = timeSeries7.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener27);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries7.removeChangeListener(seriesChangeListener29);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(obj24);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getStart();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
//        java.lang.String str8 = timeSeries7.getDomainDescription();
//        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        timeSeries7.clear();
//        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries7.createCopy((int) (byte) 10, (int) 'a');
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = day14.getDayOfMonth();
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int15, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "hi!", class18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getStart();
//        java.lang.String str22 = day20.toString();
//        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate25);
//        org.jfree.data.time.SerialDate serialDate28 = serialDate26.getFollowingDayOfWeek(5);
//        int int29 = day20.compareTo((java.lang.Object) serialDate28);
//        org.jfree.data.time.SerialDate serialDate30 = day20.getSerialDate();
//        timeSeries19.setKey((java.lang.Comparable) day20);
//        java.lang.String str32 = day20.toString();
//        org.jfree.data.time.SerialDate serialDate33 = day20.getSerialDate();
//        int int34 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) day20);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertNotNull(timeSeries13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10-June-2019" + "'", str22.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate25);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(serialDate30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "10-June-2019" + "'", str32.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.removeChangeListener(seriesChangeListener10);
        java.lang.Comparable comparable12 = timeSeries7.getKey();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(comparable12);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        java.util.Date date2 = day1.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        java.lang.Class class7 = null;
        java.util.Date date8 = null;
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date6, timeZone9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone9);
        java.lang.Class class13 = null;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.util.Date date15 = day14.getStart();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        java.util.Date date19 = day18.getStart();
        java.lang.Class class20 = null;
        java.util.Date date21 = null;
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date19, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date15, timeZone22);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date2, timeZone22);
        java.lang.Class class27 = null;
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        java.util.Date date29 = day28.getStart();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date29);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date29);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        java.util.Date date33 = day32.getStart();
        java.lang.Class class34 = null;
        java.util.Date date35 = null;
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date35, timeZone36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date33, timeZone36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date29, timeZone36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date29);
        java.lang.Class class41 = null;
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        java.util.Date date43 = day42.getStart();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date43);
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date43, timeZone45);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date29, timeZone45);
        boolean boolean48 = month26.equals((java.lang.Object) date29);
        boolean boolean50 = month26.equals((java.lang.Object) (-1L));
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        timeSeries3.setDescription("10-June-2019");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date9, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year14);
        java.lang.String str17 = year14.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        spreadsheetDate5.setDescription("Time");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        java.util.Date date3 = day2.getEnd();
        java.lang.Class class4 = null;
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date5, timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date3, timeZone6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getSerialIndex();
        int int11 = month0.compareTo((java.lang.Object) long10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month0.next();
        org.jfree.data.time.Year year13 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
        java.lang.String str15 = year13.toString();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        java.lang.String str17 = month16.toString();
        int int18 = month16.getYearValue();
        int int19 = month16.getYearValue();
        org.jfree.data.time.Year year20 = month16.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year20.next();
        int int22 = year13.compareTo((java.lang.Object) year20);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June 2019" + "'", str17.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
        org.junit.Assert.assertNotNull(year20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "9-April-1900");
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int9 = spreadsheetDate8.getDayOfMonth();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays(4, serialDate17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate17);
        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getPreviousDayOfWeek(7);
        boolean boolean22 = spreadsheetDate8.isBefore(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int29 = spreadsheetDate28.getDayOfMonth();
        int int30 = spreadsheetDate28.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate33 = spreadsheetDate28.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addDays(4, serialDate37);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate37);
        org.jfree.data.time.SerialDate serialDate41 = serialDate39.getPreviousDayOfWeek(7);
        boolean boolean42 = spreadsheetDate28.isBefore(serialDate41);
        boolean boolean44 = spreadsheetDate8.isInRange(serialDate26, serialDate41, (-457));
        boolean boolean45 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate49);
        org.jfree.data.time.SerialDate serialDate52 = serialDate50.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate50);
        serialDate53.setDescription("2019");
        boolean boolean56 = spreadsheetDate8.isBefore(serialDate53);
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.createInstance((int) 'a');
        boolean boolean59 = spreadsheetDate8.isAfter(serialDate58);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 9 + "'", int29 == 9);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1900 + "'", int30 == 1900);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.clear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
//        long long3 = fixedMillisecond1.getLastMillisecond();
//        java.util.Calendar calendar4 = null;
//        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
//        boolean boolean7 = fixedMillisecond1.equals((java.lang.Object) 100.0f);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        int int14 = day13.getDayOfMonth();
//        java.lang.Class<?> wildcardClass15 = day13.getClass();
//        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass15);
//        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0d, "hi!", "9-July-2833", (java.lang.Class) wildcardClass15);
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1, "August", "", (java.lang.Class) wildcardClass15);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertNotNull(class16);
//    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate5);
//        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getFollowingDayOfWeek(5);
//        int int9 = day0.compareTo((java.lang.Object) serialDate8);
//        long long10 = day0.getMiddleMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day0.previous();
//        int int12 = day0.getYear();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560193199999L + "'", long10 == 1560193199999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
        boolean boolean7 = spreadsheetDate1.isOnOrAfter(serialDate6);
        int int8 = spreadsheetDate1.toSerial();
        int int9 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.addDays(4, serialDate12);
        java.lang.String str14 = serialDate13.toString();
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate17);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate21 = serialDate18.getEndOfCurrentMonth(serialDate20);
        boolean boolean22 = spreadsheetDate1.isInRange(serialDate13, serialDate18);
        int int23 = spreadsheetDate1.toSerial();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1900 + "'", int9 == 1900);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-April-1900" + "'", str14.equals("13-April-1900"));
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addDays(4, serialDate5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate5);
        org.jfree.data.time.SerialDate serialDate8 = serialDate1.getEndOfCurrentMonth(serialDate5);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getEnd();
        java.lang.Class class11 = null;
        java.util.Date date12 = null;
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date10, timeZone13);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int19 = spreadsheetDate18.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate20 = serialDate16.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SerialDate serialDate21 = serialDate8.getEndOfCurrentMonth(serialDate16);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 9 + "'", int19 == 9);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        int int3 = month0.getYearValue();
        org.jfree.data.time.Year year4 = month0.getYear();
        long long5 = year4.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        boolean boolean4 = fixedMillisecond1.equals((java.lang.Object) 1900);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate11 = serialDate8.getEndOfCurrentMonth(serialDate10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate8);
        boolean boolean13 = fixedMillisecond1.equals((java.lang.Object) day12);
        long long14 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.setRangeDescription("");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        int int15 = month14.getMonth();
        int int17 = month14.compareTo((java.lang.Object) (-1.0d));
        timeSeries3.setKey((java.lang.Comparable) int17);
        timeSeries3.setRangeDescription("Saturday");
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        java.util.Date date22 = day21.getStart();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day21, class23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.util.Date date26 = day25.getStart();
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day25, class27);
        java.lang.String str29 = timeSeries28.getDomainDescription();
        java.util.Collection collection30 = timeSeries24.getTimePeriodsUniqueToOtherSeries(timeSeries28);
        timeSeries28.setMaximumItemCount(9999);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        java.util.Date date35 = day34.getEnd();
        java.lang.Class class36 = null;
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date35, timeZone38);
        int int42 = year40.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year40.previous();
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) month33, regularTimePeriod43);
        java.lang.Object obj45 = timeSeries28.clone();
        timeSeries28.setNotify(false);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
        java.util.Date date49 = day48.getStart();
        java.lang.Class class50 = null;
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day48, class50);
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar54 = null;
        fixedMillisecond53.peg(calendar54);
        long long56 = fixedMillisecond53.getFirstMillisecond();
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
        java.util.Date date58 = day57.getEnd();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date58);
        boolean boolean60 = fixedMillisecond53.equals((java.lang.Object) date58);
        java.util.Calendar calendar61 = null;
        fixedMillisecond53.peg(calendar61);
        timeSeries51.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53, (java.lang.Number) 3);
        timeSeries28.setMaximumItemAge((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries3.addAndOrUpdate(timeSeries28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar71 = null;
        fixedMillisecond70.peg(calendar71);
        long long73 = fixedMillisecond70.getFirstMillisecond();
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day();
        java.util.Date date75 = day74.getEnd();
        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(date75);
        boolean boolean77 = fixedMillisecond70.equals((java.lang.Object) date75);
        long long78 = fixedMillisecond70.getMiddleMillisecond();
        timeSeries3.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond70, (java.lang.Number) 1560193199999L);
        timeSeries3.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Time" + "'", str29.equals("Time"));
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem65);
        org.junit.Assert.assertNotNull(timeSeries68);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 0L + "'", long73 == 0L);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.setRangeDescription("");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        int int15 = month14.getMonth();
        int int17 = month14.compareTo((java.lang.Object) (-1.0d));
        timeSeries3.setKey((java.lang.Comparable) int17);
        timeSeries3.setRangeDescription("Saturday");
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        java.util.Date date22 = day21.getStart();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day21, class23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.util.Date date26 = day25.getStart();
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day25, class27);
        java.lang.String str29 = timeSeries28.getDomainDescription();
        java.util.Collection collection30 = timeSeries24.getTimePeriodsUniqueToOtherSeries(timeSeries28);
        timeSeries28.setMaximumItemCount(9999);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        java.util.Date date35 = day34.getEnd();
        java.lang.Class class36 = null;
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date35, timeZone38);
        int int42 = year40.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year40.previous();
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) month33, regularTimePeriod43);
        java.lang.Object obj45 = timeSeries28.clone();
        timeSeries28.setNotify(false);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
        java.util.Date date49 = day48.getStart();
        java.lang.Class class50 = null;
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day48, class50);
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar54 = null;
        fixedMillisecond53.peg(calendar54);
        long long56 = fixedMillisecond53.getFirstMillisecond();
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
        java.util.Date date58 = day57.getEnd();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date58);
        boolean boolean60 = fixedMillisecond53.equals((java.lang.Object) date58);
        java.util.Calendar calendar61 = null;
        fixedMillisecond53.peg(calendar61);
        timeSeries51.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53, (java.lang.Number) 3);
        timeSeries28.setMaximumItemAge((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries3.addAndOrUpdate(timeSeries28);
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day();
        java.util.Date date70 = day69.getStart();
        java.lang.Class class71 = null;
        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day69, class71);
        timeSeries72.setMaximumItemAge(1L);
        java.lang.Object obj75 = timeSeries72.clone();
        boolean boolean76 = timeSeries72.isEmpty();
        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day();
        java.util.Date date78 = day77.getStart();
        java.lang.Class class79 = null;
        org.jfree.data.time.TimeSeries timeSeries80 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day77, class79);
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day();
        java.util.Date date82 = day81.getStart();
        java.lang.Class class83 = null;
        org.jfree.data.time.TimeSeries timeSeries84 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day81, class83);
        java.lang.String str85 = timeSeries84.getDomainDescription();
        java.util.Collection collection86 = timeSeries80.getTimePeriodsUniqueToOtherSeries(timeSeries84);
        timeSeries84.clear();
        boolean boolean88 = timeSeries84.getNotify();
        org.jfree.data.time.TimeSeries timeSeries89 = timeSeries72.addAndOrUpdate(timeSeries84);
        java.lang.Class class90 = timeSeries84.getTimePeriodClass();
        timeSeries84.setNotify(false);
        timeSeries84.setRangeDescription("Saturday");
        org.jfree.data.time.TimeSeries timeSeries95 = timeSeries3.addAndOrUpdate(timeSeries84);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Time" + "'", str29.equals("Time"));
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem65);
        org.junit.Assert.assertNotNull(timeSeries68);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertNotNull(obj75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "Time" + "'", str85.equals("Time"));
        org.junit.Assert.assertNotNull(collection86);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertNotNull(timeSeries89);
        org.junit.Assert.assertNull(class90);
        org.junit.Assert.assertNotNull(timeSeries95);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.setMaximumItemCount(9999);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) '4');
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day10, class12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.util.Date date15 = day14.getStart();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day14, class16);
        java.lang.String str18 = timeSeries17.getDomainDescription();
        java.util.Collection collection19 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        java.lang.String str20 = timeSeries13.getDomainDescription();
        java.util.Collection collection21 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        java.util.Date date23 = day22.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day22.next();
        java.util.Date date25 = day22.getStart();
        boolean boolean26 = timeSeries3.equals((java.lang.Object) day22);
        timeSeries3.setRangeDescription("");
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        java.util.Date date30 = day29.getEnd();
        java.lang.Class class31 = null;
        java.util.Date date32 = null;
        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date32, timeZone33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date30, timeZone33);
        int int37 = year35.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year35.previous();
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year35, (java.lang.Number) 2019L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone33);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.clear();
        boolean boolean19 = timeSeries15.getNotify();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.addAndOrUpdate(timeSeries15);
        java.lang.Class class21 = timeSeries3.getTimePeriodClass();
        boolean boolean22 = timeSeries3.getNotify();
        int int23 = timeSeries3.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener24);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2147483647 + "'", int23 == 2147483647);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
        boolean boolean7 = spreadsheetDate1.isOnOrAfter(serialDate6);
        int int8 = spreadsheetDate1.toSerial();
        java.util.Date date9 = spreadsheetDate1.toDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar13 = null;
        fixedMillisecond12.peg(calendar13);
        long long15 = fixedMillisecond12.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, 0.0d);
        java.util.Date date18 = fixedMillisecond12.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar21 = null;
        fixedMillisecond20.peg(calendar21);
        long long23 = fixedMillisecond20.getFirstMillisecond();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        java.util.Date date25 = day24.getEnd();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        boolean boolean27 = fixedMillisecond20.equals((java.lang.Object) date25);
        java.lang.Class class28 = null;
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date25, timeZone30);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date18, timeZone30);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date9, timeZone30);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        timeSeries3.setDescription("org.jfree.data.general.SeriesException: hi!");
        java.util.Collection collection10 = timeSeries3.getTimePeriods();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(collection10);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int3 = spreadsheetDate2.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int6 = spreadsheetDate5.getDayOfMonth();
        int int7 = spreadsheetDate5.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate10 = spreadsheetDate5.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int13 = spreadsheetDate12.getDayOfMonth();
        int int14 = spreadsheetDate12.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate16 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate17 = spreadsheetDate12.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate16);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays(4, serialDate21);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = serialDate23.getPreviousDayOfWeek(7);
        boolean boolean26 = spreadsheetDate12.isBefore(serialDate25);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate29);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int33 = spreadsheetDate32.getDayOfMonth();
        int int34 = spreadsheetDate32.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate37 = spreadsheetDate32.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate36);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addDays(4, serialDate41);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate41);
        org.jfree.data.time.SerialDate serialDate45 = serialDate43.getPreviousDayOfWeek(7);
        boolean boolean46 = spreadsheetDate32.isBefore(serialDate45);
        boolean boolean48 = spreadsheetDate12.isInRange(serialDate30, serialDate45, (-457));
        boolean boolean49 = spreadsheetDate5.isOn((org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int50 = spreadsheetDate12.getDayOfWeek();
        java.util.Date date51 = spreadsheetDate12.toDate();
        boolean boolean52 = spreadsheetDate2.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate12);
        int int53 = spreadsheetDate2.toSerial();
        try {
            org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) (byte) -1, (org.jfree.data.time.SerialDate) spreadsheetDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1900 + "'", int7 == 1900);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1900 + "'", int14 == 1900);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 9 + "'", int33 == 9);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1900 + "'", int34 == 1900);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2 + "'", int50 == 2);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 100 + "'", int53 == 100);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        boolean boolean4 = fixedMillisecond1.equals((java.lang.Object) 1900);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate11 = serialDate8.getEndOfCurrentMonth(serialDate10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate8);
        boolean boolean13 = fixedMillisecond1.equals((java.lang.Object) day12);
        int int15 = fixedMillisecond1.compareTo((java.lang.Object) 1.0d);
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond1.getMiddleMillisecond(calendar16);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
//        timeSeries3.setMaximumItemAge(1L);
//        java.lang.Object obj6 = timeSeries3.clone();
//        boolean boolean7 = timeSeries3.isEmpty();
//        timeSeries3.setDescription("org.jfree.data.general.SeriesException: hi!");
//        timeSeries3.removeAgedItems(false);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        long long13 = day12.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day12, (double) 1560193199999L);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getStart();
//        java.lang.Class class18 = null;
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day16, class18);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day();
//        java.util.Date date21 = day20.getStart();
//        java.lang.Class class22 = null;
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day20, class22);
//        java.lang.String str24 = timeSeries23.getDomainDescription();
//        java.util.Collection collection25 = timeSeries19.getTimePeriodsUniqueToOtherSeries(timeSeries23);
//        timeSeries23.setMaximumItemCount(9999);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        java.util.Date date30 = day29.getEnd();
//        java.lang.Class class31 = null;
//        java.util.Date date32 = null;
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance(class31, date32, timeZone33);
//        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date30, timeZone33);
//        int int37 = year35.compareTo((java.lang.Object) "Saturday");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year35.previous();
//        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries23.createCopy((org.jfree.data.time.RegularTimePeriod) month28, regularTimePeriod38);
//        java.lang.String str40 = timeSeries23.getRangeDescription();
//        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day();
//        java.util.Date date42 = day41.getStart();
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day41, class43);
//        timeSeries44.setMaximumItemAge(1L);
//        timeSeries44.setDescription("10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries49 = timeSeries23.addAndOrUpdate(timeSeries44);
//        java.lang.Class class50 = timeSeries23.getTimePeriodClass();
//        java.util.Collection collection51 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries23);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560236399999L + "'", long13 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Time" + "'", str24.equals("Time"));
//        org.junit.Assert.assertNotNull(collection25);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(timeSeries39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Value" + "'", str40.equals("Value"));
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertNotNull(timeSeries49);
//        org.junit.Assert.assertNull(class50);
//        org.junit.Assert.assertNotNull(collection51);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        long long8 = year6.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year6.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year6.next();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year6.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2019L + "'", long8 == 2019L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.clear();
        boolean boolean19 = timeSeries15.getNotify();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.addAndOrUpdate(timeSeries15);
        java.lang.Class class21 = timeSeries3.getTimePeriodClass();
        timeSeries3.removeAgedItems(false);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertNull(class21);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) '#', (-452), 2958465);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int9 = spreadsheetDate8.getDayOfMonth();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays(4, serialDate17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate17);
        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getPreviousDayOfWeek(7);
        boolean boolean22 = spreadsheetDate8.isBefore(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int29 = spreadsheetDate28.getDayOfMonth();
        int int30 = spreadsheetDate28.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate33 = spreadsheetDate28.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addDays(4, serialDate37);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate37);
        org.jfree.data.time.SerialDate serialDate41 = serialDate39.getPreviousDayOfWeek(7);
        boolean boolean42 = spreadsheetDate28.isBefore(serialDate41);
        boolean boolean44 = spreadsheetDate8.isInRange(serialDate26, serialDate41, (-457));
        boolean boolean45 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int46 = spreadsheetDate8.getDayOfWeek();
        org.jfree.data.time.SerialDate serialDate47 = null;
        try {
            boolean boolean48 = spreadsheetDate8.isBefore(serialDate47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 9 + "'", int29 == 9);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1900 + "'", int30 == 1900);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        java.util.Date date2 = day1.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = day1.next();
        java.util.Date date4 = day1.getStart();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date4);
        try {
            org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-459), serialDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate5);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getStart();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
//        java.lang.String str8 = timeSeries7.getDomainDescription();
//        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
//        timeSeries3.addChangeListener(seriesChangeListener10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getMiddleMillisecond();
//        try {
//            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) 0.0d, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560190687327L + "'", long13 == 1560190687327L);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.setRangeDescription("");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        int int15 = month14.getMonth();
        int int17 = month14.compareTo((java.lang.Object) (-1.0d));
        timeSeries3.setKey((java.lang.Comparable) int17);
        java.util.Collection collection19 = timeSeries3.getTimePeriods();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(collection19);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        long long8 = year6.getLastMillisecond();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getEnd();
        java.lang.Class class11 = null;
        java.util.Date date12 = null;
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date10, timeZone13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.previous();
        int int17 = year15.getYear();
        int int18 = year6.compareTo((java.lang.Object) year15);
        long long19 = year6.getLastMillisecond();
        java.util.Calendar calendar20 = null;
        try {
            year6.peg(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.lang.String str9 = month8.toString();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getEnd();
        java.lang.Class class12 = null;
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date11, timeZone14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        long long18 = year16.getSerialIndex();
        int int19 = month8.compareTo((java.lang.Object) long18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month8.next();
        org.jfree.data.time.Year year21 = month8.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.previous();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        java.util.Date date24 = day23.getEnd();
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date24, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year29.previous();
        long long31 = year29.getLastMillisecond();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        java.util.Date date33 = day32.getEnd();
        java.lang.Class class34 = null;
        java.util.Date date35 = null;
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date35, timeZone36);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date33, timeZone36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.previous();
        int int40 = year38.getYear();
        int int41 = year29.compareTo((java.lang.Object) year38);
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries3.createCopy(regularTimePeriod22, (org.jfree.data.time.RegularTimePeriod) year38);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
        java.util.Date date44 = day43.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day43, (java.lang.Number) 7);
        java.lang.Number number47 = timeSeriesDataItem46.getValue();
        java.lang.Object obj48 = timeSeriesDataItem46.clone();
        try {
            timeSeries42.add(timeSeriesDataItem46, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "June 2019" + "'", str9.equals("June 2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + 7 + "'", number47.equals(7));
        org.junit.Assert.assertNotNull(obj48);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.lang.String str9 = month8.toString();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getEnd();
        java.lang.Class class12 = null;
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date11, timeZone14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        long long18 = year16.getSerialIndex();
        int int19 = month8.compareTo((java.lang.Object) long18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month8.next();
        org.jfree.data.time.Year year21 = month8.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.previous();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        java.util.Date date24 = day23.getEnd();
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date24, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year29.previous();
        long long31 = year29.getLastMillisecond();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        java.util.Date date33 = day32.getEnd();
        java.lang.Class class34 = null;
        java.util.Date date35 = null;
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date35, timeZone36);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date33, timeZone36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.previous();
        int int40 = year38.getYear();
        int int41 = year29.compareTo((java.lang.Object) year38);
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries3.createCopy(regularTimePeriod22, (org.jfree.data.time.RegularTimePeriod) year38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar45 = null;
        fixedMillisecond44.peg(calendar45);
        long long47 = fixedMillisecond44.getFirstMillisecond();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
        java.util.Date date49 = day48.getEnd();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date49);
        boolean boolean51 = fixedMillisecond44.equals((java.lang.Object) date49);
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond(date49);
        java.lang.Number number53 = timeSeries42.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "June 2019" + "'", str9.equals("June 2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(number53);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar6 = null;
//        fixedMillisecond5.peg(calendar6);
//        long long8 = fixedMillisecond5.getFirstMillisecond();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
//        boolean boolean12 = fixedMillisecond5.equals((java.lang.Object) date10);
//        java.util.Calendar calendar13 = null;
//        fixedMillisecond5.peg(calendar13);
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.Date date17 = day16.getStart();
//        int int18 = day16.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 12);
//        int int21 = day16.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries7.removeChangeListener(seriesChangeListener10);
        java.lang.Class class12 = timeSeries7.getTimePeriodClass();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNull(class12);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate2);
        org.jfree.data.time.SerialDate serialDate5 = serialDate3.getFollowingDayOfWeek(5);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
        int int8 = day6.compareTo((java.lang.Object) 6);
        java.util.Calendar calendar9 = null;
        try {
            day6.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int9 = spreadsheetDate8.getDayOfMonth();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays(4, serialDate17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate17);
        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getPreviousDayOfWeek(7);
        boolean boolean22 = spreadsheetDate8.isBefore(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int29 = spreadsheetDate28.getDayOfMonth();
        int int30 = spreadsheetDate28.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate33 = spreadsheetDate28.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addDays(4, serialDate37);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate37);
        org.jfree.data.time.SerialDate serialDate41 = serialDate39.getPreviousDayOfWeek(7);
        boolean boolean42 = spreadsheetDate28.isBefore(serialDate41);
        boolean boolean44 = spreadsheetDate8.isInRange(serialDate26, serialDate41, (-457));
        boolean boolean45 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        int int46 = spreadsheetDate8.getDayOfWeek();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int49 = spreadsheetDate48.getDayOfMonth();
        int int50 = spreadsheetDate48.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate52 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate53 = spreadsheetDate48.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate52);
        java.util.Date date54 = spreadsheetDate52.toDate();
        boolean boolean55 = spreadsheetDate8.isOn((org.jfree.data.time.SerialDate) spreadsheetDate52);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int58 = spreadsheetDate57.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate61);
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate65);
        org.jfree.data.time.SerialDate serialDate68 = serialDate66.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate69 = serialDate61.getEndOfCurrentMonth(serialDate68);
        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate72);
        org.jfree.data.time.SerialDate serialDate75 = serialDate73.getFollowingDayOfWeek(5);
        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(serialDate75);
        java.lang.String str77 = serialDate75.toString();
        boolean boolean78 = spreadsheetDate57.isInRange(serialDate69, serialDate75);
        boolean boolean79 = spreadsheetDate52.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 9 + "'", int29 == 9);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1900 + "'", int30 == 1900);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 9 + "'", int49 == 9);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1900 + "'", int50 == 1900);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 9 + "'", int58 == 9);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertNotNull(serialDate69);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertNotNull(serialDate75);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "13-April-2000" + "'", str77.equals("13-April-2000"));
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate4);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        java.lang.Class class9 = null;
        java.util.Date date10 = null;
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class9, date10, timeZone11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date8, timeZone11);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(date8);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate14);
        boolean boolean16 = spreadsheetDate1.isInRange(serialDate5, serialDate14);
        int int17 = spreadsheetDate1.toSerial();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        timeSeries3.setMaximumItemCount(31);
        timeSeries3.removeAgedItems(false);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.setRangeDescription("");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        int int15 = month14.getMonth();
        int int17 = month14.compareTo((java.lang.Object) (-1.0d));
        timeSeries3.setKey((java.lang.Comparable) int17);
        timeSeries3.setRangeDescription("Saturday");
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        java.util.Date date22 = day21.getStart();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day21, class23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.util.Date date26 = day25.getStart();
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day25, class27);
        java.lang.String str29 = timeSeries28.getDomainDescription();
        java.util.Collection collection30 = timeSeries24.getTimePeriodsUniqueToOtherSeries(timeSeries28);
        timeSeries28.setMaximumItemCount(9999);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        java.util.Date date35 = day34.getEnd();
        java.lang.Class class36 = null;
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date35, timeZone38);
        int int42 = year40.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year40.previous();
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) month33, regularTimePeriod43);
        java.lang.Object obj45 = timeSeries28.clone();
        timeSeries28.setNotify(false);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
        java.util.Date date49 = day48.getStart();
        java.lang.Class class50 = null;
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day48, class50);
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar54 = null;
        fixedMillisecond53.peg(calendar54);
        long long56 = fixedMillisecond53.getFirstMillisecond();
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
        java.util.Date date58 = day57.getEnd();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date58);
        boolean boolean60 = fixedMillisecond53.equals((java.lang.Object) date58);
        java.util.Calendar calendar61 = null;
        fixedMillisecond53.peg(calendar61);
        timeSeries51.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53, (java.lang.Number) 3);
        timeSeries28.setMaximumItemAge((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries3.addAndOrUpdate(timeSeries28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond(0L);
        int int72 = fixedMillisecond70.compareTo((java.lang.Object) 100.0f);
        java.util.Date date73 = fixedMillisecond70.getTime();
        java.util.Calendar calendar74 = null;
        long long75 = fixedMillisecond70.getLastMillisecond(calendar74);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries68.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond70, (double) (byte) 0);
        org.jfree.data.time.SerialDate serialDate80 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate81 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate80);
        org.jfree.data.time.SerialDate serialDate83 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate84 = serialDate81.getEndOfCurrentMonth(serialDate83);
        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day(serialDate81);
        timeSeries68.delete((org.jfree.data.time.RegularTimePeriod) day85);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod87 = day85.previous();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Time" + "'", str29.equals("Time"));
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem65);
        org.junit.Assert.assertNotNull(timeSeries68);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 0L + "'", long75 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem77);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertNotNull(serialDate81);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(serialDate84);
        org.junit.Assert.assertNotNull(regularTimePeriod87);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.setMaximumItemCount(9999);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
        int int21 = year19.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month12, regularTimePeriod22);
        java.lang.Object obj24 = timeSeries7.clone();
        timeSeries7.setNotify(false);
        java.lang.String str27 = timeSeries7.getDomainDescription();
        java.lang.Comparable comparable28 = timeSeries7.getKey();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
        org.junit.Assert.assertNotNull(comparable28);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.setMaximumItemCount(9999);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
        int int21 = year19.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month12, regularTimePeriod22);
        java.lang.Object obj24 = timeSeries7.clone();
        timeSeries7.setNotify(false);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        java.util.Date date28 = day27.getStart();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day27, class29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        java.util.Date date32 = day31.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day31.next();
        java.util.Date date34 = day31.getStart();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
        java.util.Date date36 = day35.getStart();
        java.lang.Class class37 = null;
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day35, class37);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
        java.util.Date date40 = day39.getStart();
        java.lang.Class class41 = null;
        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day39, class41);
        java.lang.String str43 = timeSeries42.getDomainDescription();
        java.util.Collection collection44 = timeSeries38.getTimePeriodsUniqueToOtherSeries(timeSeries42);
        timeSeries42.setMaximumItemCount(9999);
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
        java.util.Date date49 = day48.getEnd();
        java.lang.Class class50 = null;
        java.util.Date date51 = null;
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = org.jfree.data.time.RegularTimePeriod.createInstance(class50, date51, timeZone52);
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year(date49, timeZone52);
        int int56 = year54.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = year54.previous();
        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries42.createCopy((org.jfree.data.time.RegularTimePeriod) month47, regularTimePeriod57);
        org.jfree.data.time.TimeSeries timeSeries59 = timeSeries30.createCopy((org.jfree.data.time.RegularTimePeriod) day31, regularTimePeriod57);
        java.util.Date date60 = day31.getStart();
        int int61 = day31.getMonth();
        try {
            timeSeries7.update((org.jfree.data.time.RegularTimePeriod) day31, (java.lang.Number) 7);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Time" + "'", str43.equals("Time"));
        org.junit.Assert.assertNotNull(collection44);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(timeSeries58);
        org.junit.Assert.assertNotNull(timeSeries59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 6 + "'", int61 == 6);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(4, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30 + "'", int2 == 30);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str2 = seriesException1.toString();
        java.lang.String str3 = seriesException1.toString();
        java.lang.Throwable[] throwableArray4 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray5 = seriesException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("13-April-1900");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str2.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str3.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int1, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "hi!", class4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getStart();
//        java.lang.String str8 = day6.toString();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate11);
//        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getFollowingDayOfWeek(5);
//        int int15 = day6.compareTo((java.lang.Object) serialDate14);
//        org.jfree.data.time.SerialDate serialDate16 = day6.getSerialDate();
//        timeSeries5.setKey((java.lang.Comparable) day6);
//        java.lang.Class class18 = timeSeries5.getTimePeriodClass();
//        timeSeries5.setRangeDescription("");
//        try {
//            org.jfree.data.time.TimeSeries timeSeries23 = timeSeries5.createCopy((int) (short) 100, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNull(class18);
//    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        java.util.Date date2 = day1.getStart();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.util.Date date6 = day5.getStart();
//        java.lang.Class class7 = null;
//        java.util.Date date8 = null;
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date6, timeZone9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date2);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date2);
//        java.lang.String str15 = seriesChangeEvent14.toString();
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=Mon Jun 10 00:00:00 PDT 2019]" + "'", str15.equals("org.jfree.data.general.SeriesChangeEvent[source=Mon Jun 10 00:00:00 PDT 2019]"));
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        try {
            int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1900, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1900");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getStart();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day7, class9);
        timeSeries10.setMaximumItemAge(1L);
        long long13 = timeSeries10.getMaximumItemAge();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (byte) 0);
        int int16 = timeSeries10.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        boolean boolean17 = year6.equals((java.lang.Object) timeSeries10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar20 = null;
        fixedMillisecond19.peg(calendar20);
        long long22 = fixedMillisecond19.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, 0.0d);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.util.Date date26 = day25.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day25, (java.lang.Number) 7);
        java.lang.Number number29 = timeSeriesDataItem28.getValue();
        java.lang.Object obj30 = timeSeriesDataItem28.clone();
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate33);
        org.jfree.data.time.SerialDate serialDate36 = serialDate34.getFollowingDayOfWeek(5);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(serialDate34);
        java.lang.String str38 = serialDate34.toString();
        boolean boolean39 = timeSeriesDataItem28.equals((java.lang.Object) str38);
        boolean boolean40 = timeSeriesDataItem24.equals((java.lang.Object) boolean39);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = timeSeriesDataItem24.getPeriod();
        try {
            timeSeries10.add(timeSeriesDataItem24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 7 + "'", number29.equals(7));
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "9-April-2000" + "'", str38.equals("9-April-2000"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        timeSeries3.setDescription("10-June-2019");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date9, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year14);
        timeSeries3.setRangeDescription("Preceding");
        timeSeries3.setDomainDescription("ERROR : Relative To String");
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        java.util.Date date22 = day21.getStart();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day21, class23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.util.Date date26 = day25.getStart();
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day25, class27);
        java.lang.String str29 = timeSeries28.getDomainDescription();
        java.util.Collection collection30 = timeSeries24.getTimePeriodsUniqueToOtherSeries(timeSeries28);
        timeSeries28.setMaximumItemCount(9999);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        java.util.Date date35 = day34.getEnd();
        java.lang.Class class36 = null;
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date35, timeZone38);
        int int42 = year40.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year40.previous();
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) month33, regularTimePeriod43);
        java.lang.Object obj45 = timeSeries28.clone();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day();
        java.util.Date date47 = day46.getStart();
        int int48 = day46.getMonth();
        int int49 = day46.getMonth();
        boolean boolean51 = day46.equals((java.lang.Object) 100L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day46, (double) 10.0f);
        java.util.Collection collection54 = timeSeries28.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries3.addAndOrUpdate(timeSeries28);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Time" + "'", str29.equals("Time"));
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem53);
        org.junit.Assert.assertNotNull(collection54);
        org.junit.Assert.assertNotNull(timeSeries55);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int10 = spreadsheetDate9.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate11 = serialDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        int int12 = spreadsheetDate9.getMonth();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        timeSeries3.setDescription("10-June-2019");
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy(7, (int) (short) 100);
        timeSeries10.fireSeriesChanged();
        timeSeries10.setNotify(false);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries10.addOrUpdate(regularTimePeriod14, 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getStart();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
//        java.lang.String str8 = timeSeries7.getDomainDescription();
//        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        timeSeries7.setMaximumItemCount(9999);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        java.util.Date date13 = day12.getStart();
//        java.lang.Class class14 = null;
//        java.util.Date date15 = null;
//        java.util.TimeZone timeZone16 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class14, date15, timeZone16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date13, timeZone16);
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date13);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day20.previous();
//        java.lang.String str22 = day20.toString();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        java.util.Date date24 = day23.getEnd();
//        java.lang.Class class25 = null;
//        java.util.Date date26 = null;
//        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone27);
//        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date24, timeZone27);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year29.previous();
//        boolean boolean31 = day20.equals((java.lang.Object) regularTimePeriod30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day20.next();
//        try {
//            timeSeries7.add(regularTimePeriod32, (double) 2019L, false);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(timeZone16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10-June-2019" + "'", str22.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        java.lang.String str3 = month2.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (byte) 10);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.util.Date date3 = day2.getStart();
//        java.lang.String str4 = day2.toString();
//        java.util.Date date5 = day2.getStart();
//        boolean boolean6 = fixedMillisecond1.equals((java.lang.Object) date5);
//        java.lang.String str7 = fixedMillisecond1.toString();
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str7.equals("Wed Dec 31 16:00:00 PST 1969"));
//    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate2);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate6);
//        org.jfree.data.time.SerialDate serialDate9 = serialDate7.getFollowingDayOfWeek(5);
//        org.jfree.data.time.SerialDate serialDate10 = serialDate2.getEndOfCurrentMonth(serialDate9);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate13 = serialDate9.getEndOfCurrentMonth(serialDate12);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        int int16 = spreadsheetDate15.getDayOfMonth();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.util.Date date18 = day17.getStart();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date18);
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance(date18);
//        boolean boolean21 = spreadsheetDate15.isOnOrAfter(serialDate20);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        int int23 = day22.getDayOfMonth();
//        java.lang.Class<?> wildcardClass24 = day22.getClass();
//        boolean boolean25 = spreadsheetDate15.equals((java.lang.Object) day22);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) spreadsheetDate15);
//        org.jfree.data.time.SerialDate serialDate27 = serialDate12.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 9 + "'", int16 == 9);
//        org.junit.Assert.assertNotNull(date18);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(serialDate27);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        long long3 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.setMaximumItemCount(9999);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
        int int21 = year19.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month12, regularTimePeriod22);
        java.lang.Object obj24 = timeSeries7.clone();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries7.addChangeListener(seriesChangeListener25);
        java.beans.PropertyChangeListener propertyChangeListener27 = null;
        timeSeries7.removePropertyChangeListener(propertyChangeListener27);
        try {
            timeSeries7.delete((int) (byte) 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.lang.String str9 = month8.toString();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getEnd();
        java.lang.Class class12 = null;
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date11, timeZone14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        long long18 = year16.getSerialIndex();
        int int19 = month8.compareTo((java.lang.Object) long18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month8.next();
        org.jfree.data.time.Year year21 = month8.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.previous();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        java.util.Date date24 = day23.getEnd();
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date24, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year29.previous();
        long long31 = year29.getLastMillisecond();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        java.util.Date date33 = day32.getEnd();
        java.lang.Class class34 = null;
        java.util.Date date35 = null;
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date35, timeZone36);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date33, timeZone36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.previous();
        int int40 = year38.getYear();
        int int41 = year29.compareTo((java.lang.Object) year38);
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries3.createCopy(regularTimePeriod22, (org.jfree.data.time.RegularTimePeriod) year38);
        boolean boolean43 = timeSeries42.getNotify();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "June 2019" + "'", str9.equals("June 2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        timeSeries3.setDescription("10-June-2019");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date9, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year14);
        timeSeries3.setRangeDescription("Preceding");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        java.util.Date date20 = day19.getStart();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day19, class21);
        timeSeries22.setMaximumItemAge(1L);
        java.lang.Object obj25 = timeSeries22.clone();
        boolean boolean26 = timeSeries22.isEmpty();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        java.util.Date date28 = day27.getStart();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day27, class29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        java.util.Date date32 = day31.getStart();
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day31, class33);
        java.lang.String str35 = timeSeries34.getDomainDescription();
        java.util.Collection collection36 = timeSeries30.getTimePeriodsUniqueToOtherSeries(timeSeries34);
        timeSeries34.clear();
        boolean boolean38 = timeSeries34.getNotify();
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries22.addAndOrUpdate(timeSeries34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar42 = null;
        fixedMillisecond41.peg(calendar42);
        long long44 = fixedMillisecond41.getFirstMillisecond();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
        java.util.Date date46 = day45.getEnd();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date46);
        boolean boolean48 = fixedMillisecond41.equals((java.lang.Object) date46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar51 = null;
        long long52 = fixedMillisecond50.getLastMillisecond(calendar51);
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond50);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener54 = null;
        timeSeries22.addChangeListener(seriesChangeListener54);
        java.util.Collection collection56 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries22);
        timeSeries22.clear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Time" + "'", str35.equals("Time"));
        org.junit.Assert.assertNotNull(collection36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertNotNull(collection56);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getEnd();
//        java.lang.Class class2 = null;
//        java.util.Date date3 = null;
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
//        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
//        long long8 = year6.getLastMillisecond();
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        java.util.Date date10 = day9.getEnd();
//        java.lang.Class class11 = null;
//        java.util.Date date12 = null;
//        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
//        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date10, timeZone13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.previous();
//        int int17 = year15.getYear();
//        int int18 = year6.compareTo((java.lang.Object) year15);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
//        java.util.Date date20 = day19.getStart();
//        java.lang.String str21 = day19.toString();
//        java.lang.String str22 = day19.toString();
//        org.jfree.data.time.SerialDate serialDate23 = day19.getSerialDate();
//        int int24 = year15.compareTo((java.lang.Object) day19);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1577865599999L + "'", long8 == 1577865599999L);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10-June-2019" + "'", str21.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10-June-2019" + "'", str22.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        java.util.Date date2 = day1.getEnd();
        java.lang.Class class3 = null;
        java.util.Date date4 = null;
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date4, timeZone5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date2, timeZone5);
        long long8 = year7.getFirstMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(2, year7);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = month9.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        int int3 = month2.getYearValue();
        int int4 = month2.getYearValue();
        java.util.Calendar calendar5 = null;
        try {
            month2.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, 0.0d);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int9 = spreadsheetDate8.getDayOfMonth();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        java.util.Date date14 = spreadsheetDate12.toDate();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.util.Date date16 = day15.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.next();
        java.util.Date date18 = day15.getStart();
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.createInstance(date18);
        boolean boolean20 = spreadsheetDate12.isOnOrAfter(serialDate19);
        java.util.Date date21 = spreadsheetDate12.toDate();
        int int22 = spreadsheetDate12.getDayOfMonth();
        boolean boolean23 = timeSeriesDataItem6.equals((java.lang.Object) spreadsheetDate12);
        int int24 = spreadsheetDate12.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int27 = spreadsheetDate26.getDayOfMonth();
        int int28 = spreadsheetDate26.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate30 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate31 = spreadsheetDate26.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate30);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int34 = spreadsheetDate33.getDayOfMonth();
        int int35 = spreadsheetDate33.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate38 = spreadsheetDate33.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addDays(4, serialDate42);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate42);
        org.jfree.data.time.SerialDate serialDate46 = serialDate44.getPreviousDayOfWeek(7);
        boolean boolean47 = spreadsheetDate33.isBefore(serialDate46);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate50);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate53 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int54 = spreadsheetDate53.getDayOfMonth();
        int int55 = spreadsheetDate53.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate57 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate58 = spreadsheetDate53.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate57);
        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate63 = org.jfree.data.time.SerialDate.addDays(4, serialDate62);
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate62);
        org.jfree.data.time.SerialDate serialDate66 = serialDate64.getPreviousDayOfWeek(7);
        boolean boolean67 = spreadsheetDate53.isBefore(serialDate66);
        boolean boolean69 = spreadsheetDate33.isInRange(serialDate51, serialDate66, (-457));
        boolean boolean70 = spreadsheetDate26.isOn((org.jfree.data.time.SerialDate) spreadsheetDate33);
        int int71 = spreadsheetDate33.getDayOfWeek();
        java.util.Date date72 = spreadsheetDate33.toDate();
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day();
        java.util.Date date75 = day74.getEnd();
        java.lang.Class class76 = null;
        java.util.Date date77 = null;
        java.util.TimeZone timeZone78 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance(class76, date77, timeZone78);
        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year(date75, timeZone78);
        org.jfree.data.time.SerialDate serialDate81 = org.jfree.data.time.SerialDate.createInstance(date75);
        org.jfree.data.time.SerialDate serialDate82 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate81);
        boolean boolean83 = spreadsheetDate12.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate33, serialDate82);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 9 + "'", int22 == 9);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 9 + "'", int24 == 9);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 9 + "'", int27 == 9);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1900 + "'", int28 == 1900);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 9 + "'", int34 == 9);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1900 + "'", int35 == 1900);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 9 + "'", int54 == 9);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1900 + "'", int55 == 1900);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 2 + "'", int71 == 2);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(timeZone78);
        org.junit.Assert.assertNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(serialDate81);
        org.junit.Assert.assertNotNull(serialDate82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, 0.0d);
        java.util.Date date7 = fixedMillisecond1.getStart();
        java.lang.Class class8 = null;
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getStart();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date10);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getStart();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date14, timeZone17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance(class8, date10, timeZone17);
        java.lang.Class class21 = null;
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        java.util.Date date23 = day22.getStart();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date23);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date23);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        java.util.Date date27 = day26.getStart();
        java.lang.Class class28 = null;
        java.util.Date date29 = null;
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone30);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date27, timeZone30);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date23, timeZone30);
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month(date10, timeZone30);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date7, timeZone30);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNull(regularTimePeriod31);
        org.junit.Assert.assertNull(regularTimePeriod33);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.setMaximumItemCount(9999);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
        int int21 = year19.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month12, regularTimePeriod22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month12.next();
        java.lang.String str25 = month12.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "June 2019" + "'", str25.equals("June 2019"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate4);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate8);
        org.jfree.data.time.SerialDate serialDate11 = serialDate9.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate12 = serialDate4.getEndOfCurrentMonth(serialDate11);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate15 = serialDate11.getEndOfCurrentMonth(serialDate14);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate17 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int18 = spreadsheetDate17.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate25);
        org.jfree.data.time.SerialDate serialDate28 = serialDate26.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate29 = serialDate21.getEndOfCurrentMonth(serialDate28);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate32);
        org.jfree.data.time.SerialDate serialDate35 = serialDate33.getFollowingDayOfWeek(5);
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate35);
        java.lang.String str37 = serialDate35.toString();
        boolean boolean38 = spreadsheetDate17.isInRange(serialDate29, serialDate35);
        boolean boolean40 = spreadsheetDate1.isInRange(serialDate14, serialDate35, (int) (short) 100);
        int int41 = spreadsheetDate1.getDayOfWeek();
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "13-April-2000" + "'", str37.equals("13-April-2000"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2 + "'", int41 == 2);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        timeSeries3.setDescription("10-June-2019");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date9, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year14);
        timeSeries3.setRangeDescription("Preceding");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        java.util.Date date20 = day19.getStart();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day19, class21);
        timeSeries22.setMaximumItemAge(1L);
        java.lang.Object obj25 = timeSeries22.clone();
        boolean boolean26 = timeSeries22.isEmpty();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        java.util.Date date28 = day27.getStart();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day27, class29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        java.util.Date date32 = day31.getStart();
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day31, class33);
        java.lang.String str35 = timeSeries34.getDomainDescription();
        java.util.Collection collection36 = timeSeries30.getTimePeriodsUniqueToOtherSeries(timeSeries34);
        timeSeries34.clear();
        boolean boolean38 = timeSeries34.getNotify();
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries22.addAndOrUpdate(timeSeries34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar42 = null;
        fixedMillisecond41.peg(calendar42);
        long long44 = fixedMillisecond41.getFirstMillisecond();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
        java.util.Date date46 = day45.getEnd();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date46);
        boolean boolean48 = fixedMillisecond41.equals((java.lang.Object) date46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar51 = null;
        long long52 = fixedMillisecond50.getLastMillisecond(calendar51);
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond50);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener54 = null;
        timeSeries22.addChangeListener(seriesChangeListener54);
        java.util.Collection collection56 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries22);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
        java.util.Date date58 = day57.getStart();
        java.lang.Class class59 = null;
        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day57, class59);
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day();
        java.util.Date date62 = day61.getStart();
        java.lang.Class class63 = null;
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day61, class63);
        java.lang.String str65 = timeSeries64.getDomainDescription();
        java.util.Collection collection66 = timeSeries60.getTimePeriodsUniqueToOtherSeries(timeSeries64);
        timeSeries64.setMaximumItemCount(9999);
        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day();
        java.util.Date date71 = day70.getEnd();
        java.lang.Class class72 = null;
        java.util.Date date73 = null;
        java.util.TimeZone timeZone74 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = org.jfree.data.time.RegularTimePeriod.createInstance(class72, date73, timeZone74);
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(date71, timeZone74);
        int int78 = year76.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = year76.previous();
        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries64.createCopy((org.jfree.data.time.RegularTimePeriod) month69, regularTimePeriod79);
        java.lang.Class class81 = timeSeries80.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries82 = timeSeries22.addAndOrUpdate(timeSeries80);
        long long83 = timeSeries22.getMaximumItemAge();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem84 = null;
        try {
            timeSeries22.add(timeSeriesDataItem84);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Time" + "'", str35.equals("Time"));
        org.junit.Assert.assertNotNull(collection36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertNotNull(collection56);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "Time" + "'", str65.equals("Time"));
        org.junit.Assert.assertNotNull(collection66);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(timeZone74);
        org.junit.Assert.assertNull(regularTimePeriod75);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
        org.junit.Assert.assertNotNull(timeSeries80);
        org.junit.Assert.assertNull(class81);
        org.junit.Assert.assertNotNull(timeSeries82);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 1L + "'", long83 == 1L);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate5);
//        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getFollowingDayOfWeek(5);
//        int int9 = day0.compareTo((java.lang.Object) serialDate8);
//        org.jfree.data.time.SerialDate serialDate10 = day0.getSerialDate();
//        java.util.Date date11 = day0.getStart();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.next();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate5);
//        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getFollowingDayOfWeek(5);
//        int int9 = day0.compareTo((java.lang.Object) serialDate8);
//        org.jfree.data.time.SerialDate serialDate10 = day0.getSerialDate();
//        java.util.Date date11 = day0.getStart();
//        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int16 = fixedMillisecond14.compareTo((java.lang.Object) 100.0f);
//        java.util.Date date17 = fixedMillisecond14.getTime();
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        java.util.Date date19 = day18.getEnd();
//        java.lang.Class class20 = null;
//        java.util.Date date21 = null;
//        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone22);
//        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date19, timeZone22);
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date17, timeZone22);
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date11, timeZone22);
//        int int27 = day26.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
        boolean boolean7 = spreadsheetDate1.isOnOrAfter(serialDate6);
        int int8 = spreadsheetDate1.toSerial();
        int int9 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int12 = spreadsheetDate11.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate14 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int15 = spreadsheetDate14.getDayOfMonth();
        int int16 = spreadsheetDate14.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate19 = spreadsheetDate14.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate18);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate21 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int22 = spreadsheetDate21.getDayOfMonth();
        int int23 = spreadsheetDate21.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate25 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate26 = spreadsheetDate21.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate25);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.addDays(4, serialDate30);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate30);
        org.jfree.data.time.SerialDate serialDate34 = serialDate32.getPreviousDayOfWeek(7);
        boolean boolean35 = spreadsheetDate21.isBefore(serialDate34);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate38);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int42 = spreadsheetDate41.getDayOfMonth();
        int int43 = spreadsheetDate41.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate46 = spreadsheetDate41.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate45);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addDays(4, serialDate50);
        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate50);
        org.jfree.data.time.SerialDate serialDate54 = serialDate52.getPreviousDayOfWeek(7);
        boolean boolean55 = spreadsheetDate41.isBefore(serialDate54);
        boolean boolean57 = spreadsheetDate21.isInRange(serialDate39, serialDate54, (-457));
        boolean boolean58 = spreadsheetDate14.isOn((org.jfree.data.time.SerialDate) spreadsheetDate21);
        int int59 = spreadsheetDate21.getDayOfWeek();
        java.util.Date date60 = spreadsheetDate21.toDate();
        boolean boolean61 = spreadsheetDate11.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate21);
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate64);
        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate68 = serialDate65.getEndOfCurrentMonth(serialDate67);
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(serialDate65);
        int int70 = spreadsheetDate11.compare(serialDate65);
        boolean boolean71 = spreadsheetDate1.isOnOrBefore(serialDate65);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1900 + "'", int9 == 1900);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 9 + "'", int15 == 9);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1900 + "'", int16 == 1900);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 9 + "'", int22 == 9);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1900 + "'", int23 == 1900);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 9 + "'", int42 == 9);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1900 + "'", int43 == 1900);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2 + "'", int59 == 2);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-36525) + "'", int70 == (-36525));
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(6);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Friday" + "'", str1.equals("Friday"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((int) (byte) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        java.util.Date date2 = day1.getEnd();
        java.lang.Class class3 = null;
        java.util.Date date4 = null;
        java.util.TimeZone timeZone5 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date4, timeZone5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date2, timeZone5);
        long long8 = year7.getFirstMillisecond();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(2, year7);
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year7.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        int int8 = year6.getYear();
        java.lang.String str9 = year6.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        java.util.Date date3 = day2.getEnd();
        java.lang.Class class4 = null;
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date5, timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date3, timeZone6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getSerialIndex();
        int int11 = month0.compareTo((java.lang.Object) long10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month0.next();
        org.jfree.data.time.Year year13 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        long long16 = year13.getMiddleMillisecond();
        java.lang.String str17 = year13.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1562097599999L + "'", long16 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getStart();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
//        timeSeries7.setMaximumItemAge(1L);
//        timeSeries7.setDescription("10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries7.createCopy(7, (int) (short) 100);
//        timeSeries14.fireSeriesChanged();
//        int int16 = day0.compareTo((java.lang.Object) timeSeries14);
//        java.lang.String str17 = timeSeries14.getDomainDescription();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Time" + "'", str17.equals("Time"));
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Friday");
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.Class class2 = null;
//        java.util.Date date3 = null;
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date1, timeZone4);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date1);
//        java.util.Calendar calendar8 = null;
//        long long9 = fixedMillisecond7.getMiddleMillisecond(calendar8);
//        long long10 = fixedMillisecond7.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond7.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond7.next();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNull(regularTimePeriod5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560150000000L + "'", long9 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560150000000L + "'", long10 == 1560150000000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        java.util.Date date2 = day1.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        java.lang.Class class7 = null;
        java.util.Date date8 = null;
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date6, timeZone9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone9);
        java.lang.Class class13 = null;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.util.Date date15 = day14.getStart();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        java.util.Date date19 = day18.getStart();
        java.lang.Class class20 = null;
        java.util.Date date21 = null;
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date19, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date15, timeZone22);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date2, timeZone22);
        java.lang.Class class27 = null;
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        java.util.Date date29 = day28.getStart();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date29);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date29);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        java.util.Date date33 = day32.getStart();
        java.lang.Class class34 = null;
        java.util.Date date35 = null;
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date35, timeZone36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date33, timeZone36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date29, timeZone36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date29);
        java.lang.Class class41 = null;
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        java.util.Date date43 = day42.getStart();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date43);
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date43, timeZone45);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date29, timeZone45);
        boolean boolean48 = month26.equals((java.lang.Object) date29);
        org.jfree.data.time.FixedMillisecond fixedMillisecond49 = new org.jfree.data.time.FixedMillisecond(date29);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond49, (double) 9999);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
        java.util.Date date7 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond1.previous();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond1.getMiddleMillisecond(calendar9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, (java.lang.Number) 1562097599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        java.lang.String str4 = timeSeries3.getDomainDescription();
        timeSeries3.setNotify(true);
        timeSeries3.clear();
        timeSeries3.clear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getStart();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
//        java.lang.String str8 = timeSeries7.getDomainDescription();
//        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        timeSeries7.setMaximumItemCount(9999);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        java.lang.Class class15 = null;
//        java.util.Date date16 = null;
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
//        int int21 = year19.compareTo((java.lang.Object) "Saturday");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month12, regularTimePeriod22);
//        java.lang.String str24 = timeSeries7.getRangeDescription();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        java.util.Date date26 = day25.getStart();
//        java.lang.Class class27 = null;
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day25, class27);
//        timeSeries28.setMaximumItemAge(1L);
//        timeSeries28.setDescription("10-June-2019");
//        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries7.addAndOrUpdate(timeSeries28);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
//        java.util.Date date35 = day34.getStart();
//        java.lang.String str36 = day34.toString();
//        long long37 = day34.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day34, (java.lang.Number) 5);
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
//        long long41 = day40.getLastMillisecond();
//        java.lang.String str42 = day40.toString();
//        boolean boolean43 = day34.equals((java.lang.Object) day40);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Value" + "'", str24.equals("Value"));
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(timeSeries33);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "10-June-2019" + "'", str36.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560150000000L + "'", long37 == 1560150000000L);
//        org.junit.Assert.assertNull(timeSeriesDataItem39);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1560236399999L + "'", long41 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "10-June-2019" + "'", str42.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date4);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
        boolean boolean7 = spreadsheetDate1.isOnOrAfter(serialDate6);
        int int8 = spreadsheetDate1.toSerial();
        int int9 = spreadsheetDate1.getYYYY();
        int int10 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1900 + "'", int9 == 1900);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.setRangeDescription("");
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date13);
        int int15 = month14.getMonth();
        int int17 = month14.compareTo((java.lang.Object) (-1.0d));
        timeSeries3.setKey((java.lang.Comparable) int17);
        timeSeries3.setRangeDescription("Saturday");
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        java.util.Date date22 = day21.getStart();
        java.lang.Class class23 = null;
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day21, class23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.util.Date date26 = day25.getStart();
        java.lang.Class class27 = null;
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day25, class27);
        java.lang.String str29 = timeSeries28.getDomainDescription();
        java.util.Collection collection30 = timeSeries24.getTimePeriodsUniqueToOtherSeries(timeSeries28);
        timeSeries28.setMaximumItemCount(9999);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day();
        java.util.Date date35 = day34.getEnd();
        java.lang.Class class36 = null;
        java.util.Date date37 = null;
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date37, timeZone38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date35, timeZone38);
        int int42 = year40.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year40.previous();
        org.jfree.data.time.TimeSeries timeSeries44 = timeSeries28.createCopy((org.jfree.data.time.RegularTimePeriod) month33, regularTimePeriod43);
        java.lang.Object obj45 = timeSeries28.clone();
        timeSeries28.setNotify(false);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day();
        java.util.Date date49 = day48.getStart();
        java.lang.Class class50 = null;
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day48, class50);
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar54 = null;
        fixedMillisecond53.peg(calendar54);
        long long56 = fixedMillisecond53.getFirstMillisecond();
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day();
        java.util.Date date58 = day57.getEnd();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date58);
        boolean boolean60 = fixedMillisecond53.equals((java.lang.Object) date58);
        java.util.Calendar calendar61 = null;
        fixedMillisecond53.peg(calendar61);
        timeSeries51.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem65 = timeSeries28.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53, (java.lang.Number) 3);
        timeSeries28.setMaximumItemAge((long) 'a');
        org.jfree.data.time.TimeSeries timeSeries68 = timeSeries3.addAndOrUpdate(timeSeries28);
        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = fixedMillisecond70.next();
        long long72 = fixedMillisecond70.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem73 = timeSeries28.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond70);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Time" + "'", str29.equals("Time"));
        org.junit.Assert.assertNotNull(collection30);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(timeSeries44);
        org.junit.Assert.assertNotNull(obj45);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem65);
        org.junit.Assert.assertNotNull(timeSeries68);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-1L) + "'", long72 == (-1L));
        org.junit.Assert.assertNull(timeSeriesDataItem73);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        int int3 = month2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        int int5 = month2.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(0L);
        int int9 = fixedMillisecond7.compareTo((java.lang.Object) 100.0f);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.util.Date date12 = day11.getEnd();
        java.lang.Class class13 = null;
        java.util.Date date14 = null;
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date12, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date10, timeZone15);
        boolean boolean19 = month2.equals((java.lang.Object) date10);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate22);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate26);
        org.jfree.data.time.SerialDate serialDate29 = serialDate27.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate30 = serialDate22.getEndOfCurrentMonth(serialDate29);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate33);
        org.jfree.data.time.SerialDate serialDate36 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate37 = serialDate34.getEndOfCurrentMonth(serialDate36);
        org.jfree.data.time.SerialDate serialDate38 = serialDate29.getEndOfCurrentMonth(serialDate34);
        boolean boolean39 = month2.equals((java.lang.Object) serialDate34);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        int int4 = day0.getMonth();
//        int int5 = day0.getDayOfMonth();
//        int int6 = day0.getMonth();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        int int3 = month2.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month2.next();
        int int5 = month2.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(0L);
        int int9 = fixedMillisecond7.compareTo((java.lang.Object) 100.0f);
        java.util.Date date10 = fixedMillisecond7.getTime();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.util.Date date12 = day11.getEnd();
        java.lang.Class class13 = null;
        java.util.Date date14 = null;
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date14, timeZone15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date12, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date10, timeZone15);
        boolean boolean19 = month2.equals((java.lang.Object) date10);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date10);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = fixedMillisecond1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = fixedMillisecond1.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getMiddleMillisecond(calendar5);
        java.util.Date date7 = fixedMillisecond1.getTime();
        java.util.Date date8 = fixedMillisecond1.getTime();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.setMaximumItemCount(9999);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
        int int21 = year19.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month12, regularTimePeriod22);
        long long24 = month12.getFirstMillisecond();
        int int25 = month12.getMonth();
        int int26 = month12.getYearValue();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1559372400000L + "'", long24 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((-459), (int) (byte) 100, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int9 = spreadsheetDate8.getDayOfMonth();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays(4, serialDate17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate17);
        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getPreviousDayOfWeek(7);
        boolean boolean22 = spreadsheetDate8.isBefore(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int29 = spreadsheetDate28.getDayOfMonth();
        int int30 = spreadsheetDate28.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate33 = spreadsheetDate28.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addDays(4, serialDate37);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate37);
        org.jfree.data.time.SerialDate serialDate41 = serialDate39.getPreviousDayOfWeek(7);
        boolean boolean42 = spreadsheetDate28.isBefore(serialDate41);
        boolean boolean44 = spreadsheetDate8.isInRange(serialDate26, serialDate41, (-457));
        boolean boolean45 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SerialDate serialDate49 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate49);
        org.jfree.data.time.SerialDate serialDate52 = serialDate50.getFollowingDayOfWeek(5);
        serialDate50.setDescription("Preceding");
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addDays(9, serialDate50);
        java.lang.Class<?> wildcardClass56 = serialDate50.getClass();
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) spreadsheetDate8, (java.lang.Class) wildcardClass56);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 9 + "'", int29 == 9);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1900 + "'", int30 == 1900);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(wildcardClass56);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate3);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate11 = serialDate3.getEndOfCurrentMonth(serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate14 = serialDate10.getEndOfCurrentMonth(serialDate13);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(7, serialDate14);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate15);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate2);
        org.jfree.data.time.SerialDate serialDate5 = serialDate3.getFollowingDayOfWeek(5);
        serialDate3.setDescription("Preceding");
        serialDate3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
//        timeSeries3.setMaximumItemAge(1L);
//        java.lang.Object obj6 = timeSeries3.clone();
//        boolean boolean7 = timeSeries3.isEmpty();
//        timeSeries3.setDescription("org.jfree.data.general.SeriesException: hi!");
//        timeSeries3.removeAgedItems(false);
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
//        long long13 = day12.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day12, (double) 1560193199999L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar18 = null;
//        fixedMillisecond17.peg(calendar18);
//        long long20 = fixedMillisecond17.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17, 0.0d);
//        java.lang.Object obj23 = timeSeriesDataItem22.clone();
//        java.lang.Object obj24 = timeSeriesDataItem22.clone();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent25 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem22);
//        int int26 = day12.compareTo((java.lang.Object) timeSeriesDataItem22);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(obj6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560236399999L + "'", long13 == 1560236399999L);
//        org.junit.Assert.assertNull(timeSeriesDataItem15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
//        org.junit.Assert.assertNotNull(obj23);
//        org.junit.Assert.assertNotNull(obj24);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(date1);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int10 = spreadsheetDate9.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate11 = serialDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate9);
        serialDate11.setDescription("org.jfree.data.general.SeriesChangeEvent[source=Mon Jun 10 00:00:00 PDT 2019]");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertNotNull(serialDate11);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test149");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        int int5 = spreadsheetDate4.getDayOfMonth();
//        int int6 = spreadsheetDate4.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        int int12 = spreadsheetDate11.getDayOfMonth();
//        int int13 = spreadsheetDate11.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate16 = spreadsheetDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate15);
//        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addDays(4, serialDate20);
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate20);
//        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getPreviousDayOfWeek(7);
//        boolean boolean25 = spreadsheetDate11.isBefore(serialDate24);
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate28);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        int int32 = spreadsheetDate31.getDayOfMonth();
//        int int33 = spreadsheetDate31.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate36 = spreadsheetDate31.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate35);
//        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addDays(4, serialDate40);
//        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate40);
//        org.jfree.data.time.SerialDate serialDate44 = serialDate42.getPreviousDayOfWeek(7);
//        boolean boolean45 = spreadsheetDate31.isBefore(serialDate44);
//        boolean boolean47 = spreadsheetDate11.isInRange(serialDate29, serialDate44, (-457));
//        boolean boolean48 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate11);
//        int int49 = spreadsheetDate11.getDayOfWeek();
//        java.util.Date date50 = spreadsheetDate11.toDate();
//        boolean boolean51 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
//        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
//        java.util.Date date53 = day52.getEnd();
//        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date53);
//        int int55 = day54.getDayOfMonth();
//        boolean boolean56 = spreadsheetDate1.equals((java.lang.Object) day54);
//        java.util.Calendar calendar57 = null;
//        try {
//            day54.peg(calendar57);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNotNull(serialDate20);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertNotNull(serialDate24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 9 + "'", int32 == 9);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1900 + "'", int33 == 1900);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNotNull(serialDate40);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertNotNull(serialDate44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2 + "'", int49 == 2);
//        org.junit.Assert.assertNotNull(date50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertNotNull(date53);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 10 + "'", int55 == 10);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        java.lang.String str9 = month8.toString();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getEnd();
        java.lang.Class class12 = null;
        java.util.Date date13 = null;
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance(class12, date13, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date11, timeZone14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.previous();
        long long18 = year16.getSerialIndex();
        int int19 = month8.compareTo((java.lang.Object) long18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month8.next();
        org.jfree.data.time.Year year21 = month8.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.previous();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
        java.util.Date date24 = day23.getEnd();
        java.lang.Class class25 = null;
        java.util.Date date26 = null;
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance(class25, date26, timeZone27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date24, timeZone27);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year29.previous();
        long long31 = year29.getLastMillisecond();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        java.util.Date date33 = day32.getEnd();
        java.lang.Class class34 = null;
        java.util.Date date35 = null;
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date35, timeZone36);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date33, timeZone36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.previous();
        int int40 = year38.getYear();
        int int41 = year29.compareTo((java.lang.Object) year38);
        org.jfree.data.time.TimeSeries timeSeries42 = timeSeries3.createCopy(regularTimePeriod22, (org.jfree.data.time.RegularTimePeriod) year38);
        long long43 = year38.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "June 2019" + "'", str9.equals("June 2019"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2019L + "'", long18 == 2019L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(timeSeries42);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1546329600000L + "'", long43 == 1546329600000L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int5 = spreadsheetDate4.getDayOfMonth();
        int int6 = spreadsheetDate4.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate9 = spreadsheetDate4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int12 = spreadsheetDate11.getDayOfMonth();
        int int13 = spreadsheetDate11.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate16 = spreadsheetDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addDays(4, serialDate20);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate20);
        org.jfree.data.time.SerialDate serialDate24 = serialDate22.getPreviousDayOfWeek(7);
        boolean boolean25 = spreadsheetDate11.isBefore(serialDate24);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate28);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate31 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int32 = spreadsheetDate31.getDayOfMonth();
        int int33 = spreadsheetDate31.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate36 = spreadsheetDate31.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate35);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.addDays(4, serialDate40);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate40);
        org.jfree.data.time.SerialDate serialDate44 = serialDate42.getPreviousDayOfWeek(7);
        boolean boolean45 = spreadsheetDate31.isBefore(serialDate44);
        boolean boolean47 = spreadsheetDate11.isInRange(serialDate29, serialDate44, (-457));
        boolean boolean48 = spreadsheetDate4.isOn((org.jfree.data.time.SerialDate) spreadsheetDate11);
        int int49 = spreadsheetDate11.getDayOfWeek();
        java.util.Date date50 = spreadsheetDate11.toDate();
        boolean boolean51 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate54);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate58 = serialDate55.getEndOfCurrentMonth(serialDate57);
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(serialDate55);
        int int60 = spreadsheetDate1.compare(serialDate55);
        int int61 = spreadsheetDate1.toSerial();
        int int62 = spreadsheetDate1.toSerial();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1900 + "'", int6 == 1900);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 9 + "'", int32 == 9);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1900 + "'", int33 == 1900);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 2 + "'", int49 == 2);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-36525) + "'", int60 == (-36525));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 100 + "'", int61 == 100);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 100 + "'", int62 == 100);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.clear();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.util.Date date12 = day11.getStart();
        java.lang.Class class13 = null;
        java.util.Date date14 = null;
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date14, timeZone15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date12, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date12);
        int int19 = day18.getMonth();
        timeSeries7.setKey((java.lang.Comparable) day18);
        try {
            timeSeries7.removeAgedItems((long) 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        long long2 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar3 = null;
        long long4 = fixedMillisecond1.getFirstMillisecond(calendar3);
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.lang.Class class0 = null;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
        java.util.Date date2 = day1.getStart();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        java.lang.Class class7 = null;
        java.util.Date date8 = null;
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date6, timeZone9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone9);
        java.lang.Class class13 = null;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.util.Date date15 = day14.getStart();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month(date15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        java.util.Date date19 = day18.getStart();
        java.lang.Class class20 = null;
        java.util.Date date21 = null;
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date21, timeZone22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date19, timeZone22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date15, timeZone22);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date2, timeZone22);
        java.lang.Class class27 = null;
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        java.util.Date date29 = day28.getStart();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date29);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date29);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
        java.util.Date date33 = day32.getStart();
        java.lang.Class class34 = null;
        java.util.Date date35 = null;
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date35, timeZone36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date33, timeZone36);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date29, timeZone36);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date29);
        java.lang.Class class41 = null;
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day();
        java.util.Date date43 = day42.getStart();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month(date43);
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance(class41, date43, timeZone45);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date29, timeZone45);
        boolean boolean48 = month26.equals((java.lang.Object) date29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = month26.previous();
        java.lang.String str50 = regularTimePeriod49.toString();
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNull(regularTimePeriod23);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNull(regularTimePeriod37);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "May 2019" + "'", str50.equals("May 2019"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.clear();
        boolean boolean19 = timeSeries15.getNotify();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar23 = null;
        fixedMillisecond22.peg(calendar23);
        long long25 = fixedMillisecond22.getFirstMillisecond();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        java.util.Date date27 = day26.getEnd();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        boolean boolean29 = fixedMillisecond22.equals((java.lang.Object) date27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond31.getLastMillisecond(calendar32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
        java.lang.String str35 = timeSeries3.getRangeDescription();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Value" + "'", str35.equals("Value"));
    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.Class class2 = null;
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
//        java.util.Date date5 = day4.getStart();
//        java.lang.Class class6 = null;
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
//        java.lang.String str8 = timeSeries7.getDomainDescription();
//        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
//        timeSeries7.setMaximumItemCount(9999);
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getEnd();
//        java.lang.Class class15 = null;
//        java.util.Date date16 = null;
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
//        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
//        int int21 = year19.compareTo((java.lang.Object) "Saturday");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month12, regularTimePeriod22);
//        java.lang.Object obj24 = timeSeries7.clone();
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate27);
//        org.jfree.data.time.SerialDate serialDate31 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate31);
//        org.jfree.data.time.SerialDate serialDate34 = serialDate32.getFollowingDayOfWeek(5);
//        org.jfree.data.time.SerialDate serialDate35 = serialDate27.getEndOfCurrentMonth(serialDate34);
//        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate38);
//        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate42 = serialDate39.getEndOfCurrentMonth(serialDate41);
//        org.jfree.data.time.SerialDate serialDate43 = serialDate34.getEndOfCurrentMonth(serialDate39);
//        timeSeries7.setKey((java.lang.Comparable) serialDate39);
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day();
//        int int48 = day47.getDayOfMonth();
//        java.lang.Class<?> wildcardClass49 = day47.getClass();
//        java.lang.Class class50 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass49);
//        java.lang.Class class51 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass49);
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate39, "Friday", "9-April-1900", (java.lang.Class) wildcardClass49);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertNotNull(obj24);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate31);
//        org.junit.Assert.assertNotNull(serialDate32);
//        org.junit.Assert.assertNotNull(serialDate34);
//        org.junit.Assert.assertNotNull(serialDate35);
//        org.junit.Assert.assertNotNull(serialDate38);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertNotNull(serialDate43);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 10 + "'", int48 == 10);
//        org.junit.Assert.assertNotNull(wildcardClass49);
//        org.junit.Assert.assertNotNull(class50);
//        org.junit.Assert.assertNotNull(class51);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) 100.0f);
        java.util.Date date4 = fixedMillisecond1.getTime();
        java.util.Calendar calendar5 = null;
        long long6 = fixedMillisecond1.getLastMillisecond(calendar5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getStart();
        java.lang.Class class9 = null;
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day7, class9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.util.Date date12 = day11.getStart();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day11, class13);
        java.lang.String str15 = timeSeries14.getDomainDescription();
        java.util.Collection collection16 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        timeSeries14.clear();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        java.util.Date date19 = day18.getStart();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date19);
        int int21 = month20.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month20.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries14.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) (short) 0);
        boolean boolean26 = month20.equals((java.lang.Object) 10.0d);
        boolean boolean27 = fixedMillisecond1.equals((java.lang.Object) 10.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Time" + "'", str15.equals("Time"));
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day();
//        java.util.Date date2 = day1.getStart();
//        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.util.Date date6 = day5.getStart();
//        java.lang.Class class7 = null;
//        java.util.Date date8 = null;
//        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date6, timeZone9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date2, timeZone9);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date2);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getFirstMillisecond(calendar14);
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond13.getLastMillisecond(calendar16);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone9);
//        org.junit.Assert.assertNull(regularTimePeriod10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560150000000L + "'", long15 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560150000000L + "'", long17 == 1560150000000L);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 7);
        java.lang.Number number4 = timeSeriesDataItem3.getValue();
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = serialDate8.getFollowingDayOfWeek(5);
        int int11 = timeSeriesDataItem3.compareTo((java.lang.Object) 5);
        java.lang.Number number12 = timeSeriesDataItem3.getValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem3.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeriesDataItem3.getPeriod();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 7 + "'", number4.equals(7));
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 7 + "'", number12.equals(7));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        int int8 = month7.getMonth();
        java.lang.String str9 = month7.toString();
        int int10 = month3.compareTo((java.lang.Object) month7);
        java.lang.Object obj11 = null;
        int int12 = month7.compareTo(obj11);
        int int13 = month7.getYearValue();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "June 2019" + "'", str9.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        java.util.Date date3 = day2.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date3);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date3);
        boolean boolean7 = month0.equals((java.lang.Object) date3);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, 0.0d);
        java.lang.Object obj7 = timeSeriesDataItem6.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.general.SeriesChangeEvent(obj7);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(obj7);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.util.Date date3 = day2.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day2, (java.lang.Number) 7);
//        int int6 = fixedMillisecond1.compareTo((java.lang.Object) timeSeriesDataItem5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
//        int int8 = day7.getDayOfMonth();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int8, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "hi!", class11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getStart();
//        java.lang.String str15 = day13.toString();
//        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate18);
//        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getFollowingDayOfWeek(5);
//        int int22 = day13.compareTo((java.lang.Object) serialDate21);
//        org.jfree.data.time.SerialDate serialDate23 = day13.getSerialDate();
//        timeSeries12.setKey((java.lang.Comparable) day13);
//        java.lang.Class class25 = timeSeries12.getTimePeriodClass();
//        timeSeries12.setRangeDescription("");
//        boolean boolean28 = timeSeriesDataItem5.equals((java.lang.Object) timeSeries12);
//        timeSeriesDataItem5.setValue((java.lang.Number) 0L);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10-June-2019" + "'", str15.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate18);
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertNull(class25);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("May 2019");
        org.junit.Assert.assertNotNull(month1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        timeSeries3.setDescription("10-June-2019");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date9, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year14);
        timeSeries3.setRangeDescription("Preceding");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        java.util.Date date20 = day19.getStart();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day19, class21);
        timeSeries22.setMaximumItemAge(1L);
        java.lang.Object obj25 = timeSeries22.clone();
        boolean boolean26 = timeSeries22.isEmpty();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        java.util.Date date28 = day27.getStart();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day27, class29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        java.util.Date date32 = day31.getStart();
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day31, class33);
        java.lang.String str35 = timeSeries34.getDomainDescription();
        java.util.Collection collection36 = timeSeries30.getTimePeriodsUniqueToOtherSeries(timeSeries34);
        timeSeries34.clear();
        boolean boolean38 = timeSeries34.getNotify();
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries22.addAndOrUpdate(timeSeries34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar42 = null;
        fixedMillisecond41.peg(calendar42);
        long long44 = fixedMillisecond41.getFirstMillisecond();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
        java.util.Date date46 = day45.getEnd();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date46);
        boolean boolean48 = fixedMillisecond41.equals((java.lang.Object) date46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar51 = null;
        long long52 = fixedMillisecond50.getLastMillisecond(calendar51);
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond50);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener54 = null;
        timeSeries22.addChangeListener(seriesChangeListener54);
        java.util.Collection collection56 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries22);
        java.lang.String str57 = timeSeries22.getDescription();
        timeSeries22.setMaximumItemCount(5);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Time" + "'", str35.equals("Time"));
        org.junit.Assert.assertNotNull(collection36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertNotNull(collection56);
        org.junit.Assert.assertNull(str57);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day4.next();
        java.util.Date date7 = day4.getStart();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.setMaximumItemCount(9999);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
        java.util.Date date22 = day21.getEnd();
        java.lang.Class class23 = null;
        java.util.Date date24 = null;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class23, date24, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date22, timeZone25);
        int int29 = year27.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year27.previous();
        org.jfree.data.time.TimeSeries timeSeries31 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month20, regularTimePeriod30);
        org.jfree.data.time.TimeSeries timeSeries32 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day4, regularTimePeriod30);
        timeSeries32.setNotify(false);
        java.lang.Object obj35 = null;
        boolean boolean36 = timeSeries32.equals(obj35);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(timeSeries31);
        org.junit.Assert.assertNotNull(timeSeries32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10);
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getNearestDayOfWeek((-452));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Nearest");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries3.setRangeDescription("");
        int int12 = timeSeries3.getMaximumItemCount();
        timeSeries3.clear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("June 2019");
        org.jfree.data.time.Year year2 = month1.getYear();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
        java.util.Date date4 = day3.getStart();
        java.lang.Class class5 = null;
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day3, class5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day();
        java.util.Date date8 = day7.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day7.next();
        java.util.Date date10 = day7.getStart();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.util.Date date12 = day11.getStart();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day11, class13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day();
        java.util.Date date16 = day15.getStart();
        java.lang.Class class17 = null;
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day15, class17);
        java.lang.String str19 = timeSeries18.getDomainDescription();
        java.util.Collection collection20 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        timeSeries18.setMaximumItemCount(9999);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        java.util.Date date25 = day24.getEnd();
        java.lang.Class class26 = null;
        java.util.Date date27 = null;
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = org.jfree.data.time.RegularTimePeriod.createInstance(class26, date27, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date25, timeZone28);
        int int32 = year30.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year30.previous();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries18.createCopy((org.jfree.data.time.RegularTimePeriod) month23, regularTimePeriod33);
        org.jfree.data.time.TimeSeries timeSeries35 = timeSeries6.createCopy((org.jfree.data.time.RegularTimePeriod) day7, regularTimePeriod33);
        boolean boolean36 = month1.equals((java.lang.Object) day7);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar39 = null;
        fixedMillisecond38.peg(calendar39);
        long long41 = fixedMillisecond38.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond38, 0.0d);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate45 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int46 = spreadsheetDate45.getDayOfMonth();
        int int47 = spreadsheetDate45.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate49 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate50 = spreadsheetDate45.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate49);
        java.util.Date date51 = spreadsheetDate49.toDate();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day();
        java.util.Date date53 = day52.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = day52.next();
        java.util.Date date55 = day52.getStart();
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(date55);
        boolean boolean57 = spreadsheetDate49.isOnOrAfter(serialDate56);
        java.util.Date date58 = spreadsheetDate49.toDate();
        int int59 = spreadsheetDate49.getDayOfMonth();
        boolean boolean60 = timeSeriesDataItem43.equals((java.lang.Object) spreadsheetDate49);
        int int61 = spreadsheetDate49.getDayOfMonth();
        int int62 = month1.compareTo((java.lang.Object) spreadsheetDate49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = month1.previous();
        org.junit.Assert.assertNotNull(month1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Time" + "'", str19.equals("Time"));
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(timeSeries35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 9 + "'", int46 == 9);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1900 + "'", int47 == 1900);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 9 + "'", int59 == 9);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 9 + "'", int61 == 9);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getStart();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day8, class10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        java.lang.Class class14 = null;
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day12, class14);
        java.lang.String str16 = timeSeries15.getDomainDescription();
        java.util.Collection collection17 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries15);
        timeSeries15.clear();
        boolean boolean19 = timeSeries15.getNotify();
        org.jfree.data.time.TimeSeries timeSeries20 = timeSeries3.addAndOrUpdate(timeSeries15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar23 = null;
        fixedMillisecond22.peg(calendar23);
        long long25 = fixedMillisecond22.getFirstMillisecond();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        java.util.Date date27 = day26.getEnd();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        boolean boolean29 = fixedMillisecond22.equals((java.lang.Object) date27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar32 = null;
        long long33 = fixedMillisecond31.getLastMillisecond(calendar32);
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond31);
        java.util.Date date35 = fixedMillisecond22.getTime();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int38 = spreadsheetDate37.getDayOfMonth();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
        java.util.Date date40 = day39.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent41 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date40);
        org.jfree.data.time.SerialDate serialDate42 = org.jfree.data.time.SerialDate.createInstance(date40);
        boolean boolean43 = spreadsheetDate37.isOnOrAfter(serialDate42);
        int int44 = spreadsheetDate37.toSerial();
        java.util.Date date45 = spreadsheetDate37.toDate();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        int int47 = fixedMillisecond22.compareTo((java.lang.Object) date45);
        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance(date45);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Time" + "'", str16.equals("Time"));
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(timeSeries20);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 9 + "'", int38 == 9);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 100 + "'", int44 == 100);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertNotNull(serialDate48);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        long long4 = fixedMillisecond1.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, 0.0d);
        java.lang.Object obj7 = timeSeriesDataItem6.clone();
        java.lang.Object obj8 = timeSeriesDataItem6.clone();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int11 = spreadsheetDate10.getDayOfMonth();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day();
        java.util.Date date13 = day12.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date13);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(date13);
        boolean boolean16 = spreadsheetDate10.isOnOrAfter(serialDate15);
        int int17 = spreadsheetDate10.toSerial();
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate21 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate20);
        boolean boolean22 = spreadsheetDate10.isOnOrAfter(serialDate21);
        java.util.Date date23 = spreadsheetDate10.toDate();
        int int24 = timeSeriesDataItem6.compareTo((java.lang.Object) spreadsheetDate10);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate26 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate29);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate33);
        org.jfree.data.time.SerialDate serialDate36 = serialDate34.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate37 = serialDate29.getEndOfCurrentMonth(serialDate36);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate40 = serialDate36.getEndOfCurrentMonth(serialDate39);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate42 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int43 = spreadsheetDate42.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate47 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate46);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate50);
        org.jfree.data.time.SerialDate serialDate53 = serialDate51.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate54 = serialDate46.getEndOfCurrentMonth(serialDate53);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate57);
        org.jfree.data.time.SerialDate serialDate60 = serialDate58.getFollowingDayOfWeek(5);
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(serialDate60);
        java.lang.String str62 = serialDate60.toString();
        boolean boolean63 = spreadsheetDate42.isInRange(serialDate54, serialDate60);
        boolean boolean65 = spreadsheetDate26.isInRange(serialDate39, serialDate60, (int) (short) 100);
        int int66 = spreadsheetDate10.compare(serialDate60);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 9 + "'", int43 == 9);
        org.junit.Assert.assertNotNull(serialDate46);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate53);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "13-April-2000" + "'", str62.equals("13-April-2000"));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-36529) + "'", int66 == (-36529));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        int int3 = month2.getMonth();
        int int5 = month2.compareTo((java.lang.Object) (-1.0d));
        int int6 = month2.getMonth();
        java.lang.String str7 = month2.toString();
        int int8 = month2.getMonth();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getStart();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day9, class11);
        timeSeries12.setMaximumItemAge(1L);
        timeSeries12.setDescription("10-June-2019");
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
        java.util.Date date18 = day17.getEnd();
        java.lang.Class class19 = null;
        java.util.Date date20 = null;
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date20, timeZone21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date18, timeZone21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year23.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) year23);
        timeSeries12.setRangeDescription("Preceding");
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        java.util.Date date29 = day28.getStart();
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day28, class30);
        timeSeries31.setMaximumItemAge(1L);
        java.lang.Object obj34 = timeSeries31.clone();
        boolean boolean35 = timeSeries31.isEmpty();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
        java.util.Date date37 = day36.getStart();
        java.lang.Class class38 = null;
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day36, class38);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day();
        java.util.Date date41 = day40.getStart();
        java.lang.Class class42 = null;
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day40, class42);
        java.lang.String str44 = timeSeries43.getDomainDescription();
        java.util.Collection collection45 = timeSeries39.getTimePeriodsUniqueToOtherSeries(timeSeries43);
        timeSeries43.clear();
        boolean boolean47 = timeSeries43.getNotify();
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries31.addAndOrUpdate(timeSeries43);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar51 = null;
        fixedMillisecond50.peg(calendar51);
        long long53 = fixedMillisecond50.getFirstMillisecond();
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day();
        java.util.Date date55 = day54.getEnd();
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date55);
        boolean boolean57 = fixedMillisecond50.equals((java.lang.Object) date55);
        org.jfree.data.time.FixedMillisecond fixedMillisecond59 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar60 = null;
        long long61 = fixedMillisecond59.getLastMillisecond(calendar60);
        org.jfree.data.time.TimeSeries timeSeries62 = timeSeries31.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond59);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener63 = null;
        timeSeries31.addChangeListener(seriesChangeListener63);
        java.util.Collection collection65 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries31);
        boolean boolean66 = month2.equals((java.lang.Object) timeSeries31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = month2.next();
        java.util.Date date68 = regularTimePeriod67.getStart();
        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month(date68);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "June 2019" + "'", str7.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Time" + "'", str44.equals("Time"));
        org.junit.Assert.assertNotNull(collection45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
        org.junit.Assert.assertNotNull(timeSeries62);
        org.junit.Assert.assertNotNull(collection65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(date68);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test174");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int1, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "hi!", class4);
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        java.util.Date date7 = day6.getStart();
//        java.lang.String str8 = day6.toString();
//        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate12 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate11);
//        org.jfree.data.time.SerialDate serialDate14 = serialDate12.getFollowingDayOfWeek(5);
//        int int15 = day6.compareTo((java.lang.Object) serialDate14);
//        org.jfree.data.time.SerialDate serialDate16 = day6.getSerialDate();
//        timeSeries5.setKey((java.lang.Comparable) day6);
//        java.lang.Class class18 = timeSeries5.getTimePeriodClass();
//        timeSeries5.setMaximumItemCount(0);
//        timeSeries5.removeAgedItems(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond24.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond24.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = fixedMillisecond24.previous();
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
//        java.util.Date date29 = day28.getStart();
//        java.lang.Class class30 = null;
//        java.util.Date date31 = null;
//        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone32);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date29, timeZone32);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(date29);
//        java.util.Calendar calendar36 = null;
//        long long37 = fixedMillisecond35.getMiddleMillisecond(calendar36);
//        long long38 = fixedMillisecond35.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
//        long long40 = fixedMillisecond24.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10-June-2019" + "'", str8.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertNull(class18);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(regularTimePeriod26);
//        org.junit.Assert.assertNotNull(regularTimePeriod27);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone32);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560150000000L + "'", long37 == 1560150000000L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560150000000L + "'", long38 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeries39);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-1L) + "'", long40 == (-1L));
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int2 = spreadsheetDate1.getDayOfMonth();
        int int3 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate5 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate6 = spreadsheetDate1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int9 = spreadsheetDate8.getDayOfMonth();
        int int10 = spreadsheetDate8.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate13 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate12);
        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.addDays(4, serialDate17);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate17);
        org.jfree.data.time.SerialDate serialDate21 = serialDate19.getPreviousDayOfWeek(7);
        boolean boolean22 = spreadsheetDate8.isBefore(serialDate21);
        org.jfree.data.time.SerialDate serialDate25 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate25);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate28 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int29 = spreadsheetDate28.getDayOfMonth();
        int int30 = spreadsheetDate28.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate32 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate33 = spreadsheetDate28.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate32);
        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.addDays(4, serialDate37);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate37);
        org.jfree.data.time.SerialDate serialDate41 = serialDate39.getPreviousDayOfWeek(7);
        boolean boolean42 = spreadsheetDate28.isBefore(serialDate41);
        boolean boolean44 = spreadsheetDate8.isInRange(serialDate26, serialDate41, (-457));
        boolean boolean45 = spreadsheetDate1.isOn((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate50 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate51 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate50);
        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate54);
        org.jfree.data.time.SerialDate serialDate57 = serialDate55.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate58 = serialDate50.getEndOfCurrentMonth(serialDate57);
        org.jfree.data.time.SerialDate serialDate60 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate61 = serialDate57.getEndOfCurrentMonth(serialDate60);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate63 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int64 = spreadsheetDate63.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate67 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate68 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate67);
        org.jfree.data.time.SerialDate serialDate71 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate72 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate71);
        org.jfree.data.time.SerialDate serialDate74 = serialDate72.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate75 = serialDate67.getEndOfCurrentMonth(serialDate74);
        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate79 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate78);
        org.jfree.data.time.SerialDate serialDate81 = serialDate79.getFollowingDayOfWeek(5);
        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day(serialDate81);
        java.lang.String str83 = serialDate81.toString();
        boolean boolean84 = spreadsheetDate63.isInRange(serialDate75, serialDate81);
        boolean boolean86 = spreadsheetDate47.isInRange(serialDate60, serialDate81, (int) (short) 100);
        org.jfree.data.time.SerialDate serialDate87 = spreadsheetDate8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SerialDate serialDate89 = spreadsheetDate8.getPreviousDayOfWeek(5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1900 + "'", int10 == 1900);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 9 + "'", int29 == 9);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1900 + "'", int30 == 1900);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertNotNull(serialDate55);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 9 + "'", int64 == 9);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertNotNull(serialDate74);
        org.junit.Assert.assertNotNull(serialDate75);
        org.junit.Assert.assertNotNull(serialDate78);
        org.junit.Assert.assertNotNull(serialDate79);
        org.junit.Assert.assertNotNull(serialDate81);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "13-April-2000" + "'", str83.equals("13-April-2000"));
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(serialDate87);
        org.junit.Assert.assertNotNull(serialDate89);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int1, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "hi!", class4);
//        boolean boolean6 = timeSeries5.getNotify();
//        int int7 = timeSeries5.getItemCount();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        java.util.Date date7 = null;
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date7, timeZone8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date5, timeZone8);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year11.next();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.util.Date date15 = day14.getStart();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day14, class16);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
        java.util.Date date19 = day18.getStart();
        java.lang.Class class20 = null;
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day18, class20);
        java.lang.String str22 = timeSeries21.getDomainDescription();
        java.util.Collection collection23 = timeSeries17.getTimePeriodsUniqueToOtherSeries(timeSeries21);
        timeSeries21.setMaximumItemCount(9999);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        java.util.Date date28 = day27.getEnd();
        java.lang.Class class29 = null;
        java.util.Date date30 = null;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date28, timeZone31);
        int int35 = year33.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year33.previous();
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) month26, regularTimePeriod36);
        boolean boolean38 = timeSeries21.getNotify();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day();
        java.util.Date date40 = day39.getStart();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date40);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = month41.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = month41.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) month41);
        int int45 = year11.compareTo((java.lang.Object) timeSeries21);
        int int46 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year11);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Time" + "'", str22.equals("Time"));
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str2 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str5 = seriesException4.toString();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.Throwable[] throwableArray7 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray8 = seriesException1.getSuppressed();
        java.lang.String str9 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str2.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str5.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str9.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        timeSeries3.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=-1]");
        java.lang.String str10 = timeSeries3.getDescription();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries3.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str10);
    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (java.lang.Number) 7);
//        java.lang.Number number4 = timeSeriesDataItem3.getValue();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        java.util.Date date6 = day5.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (java.lang.Number) 7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day5.previous();
//        int int10 = timeSeriesDataItem3.compareTo((java.lang.Object) regularTimePeriod9);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate12 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        int int13 = spreadsheetDate12.getDayOfMonth();
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        java.util.Date date15 = day14.getStart();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date15);
//        org.jfree.data.time.SerialDate serialDate17 = org.jfree.data.time.SerialDate.createInstance(date15);
//        boolean boolean18 = spreadsheetDate12.isOnOrAfter(serialDate17);
//        int int19 = spreadsheetDate12.toSerial();
//        int int20 = spreadsheetDate12.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        int int23 = spreadsheetDate22.getDayOfMonth();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        java.util.Date date25 = day24.getStart();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date25);
//        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance(date25);
//        boolean boolean28 = spreadsheetDate22.isOnOrAfter(serialDate27);
//        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
//        int int30 = day29.getDayOfMonth();
//        java.lang.Class<?> wildcardClass31 = day29.getClass();
//        boolean boolean32 = spreadsheetDate22.equals((java.lang.Object) day29);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent33 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) spreadsheetDate22);
//        boolean boolean34 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        int int35 = spreadsheetDate12.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        int int38 = spreadsheetDate37.getDayOfMonth();
//        int int39 = spreadsheetDate37.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate41 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate42 = spreadsheetDate37.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate41);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        int int45 = spreadsheetDate44.getDayOfMonth();
//        int int46 = spreadsheetDate44.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate48 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate49 = spreadsheetDate44.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate48);
//        org.jfree.data.time.SerialDate serialDate53 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate54 = org.jfree.data.time.SerialDate.addDays(4, serialDate53);
//        org.jfree.data.time.SerialDate serialDate55 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate53);
//        org.jfree.data.time.SerialDate serialDate57 = serialDate55.getPreviousDayOfWeek(7);
//        boolean boolean58 = spreadsheetDate44.isBefore(serialDate57);
//        org.jfree.data.time.SerialDate serialDate61 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate62 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate61);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate64 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        int int65 = spreadsheetDate64.getDayOfMonth();
//        int int66 = spreadsheetDate64.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate68 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate69 = spreadsheetDate64.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate68);
//        org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate74 = org.jfree.data.time.SerialDate.addDays(4, serialDate73);
//        org.jfree.data.time.SerialDate serialDate75 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate73);
//        org.jfree.data.time.SerialDate serialDate77 = serialDate75.getPreviousDayOfWeek(7);
//        boolean boolean78 = spreadsheetDate64.isBefore(serialDate77);
//        boolean boolean80 = spreadsheetDate44.isInRange(serialDate62, serialDate77, (-457));
//        boolean boolean81 = spreadsheetDate37.isOn((org.jfree.data.time.SerialDate) spreadsheetDate44);
//        int int82 = spreadsheetDate44.getDayOfWeek();
//        boolean boolean83 = spreadsheetDate12.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate44);
//        int int84 = timeSeriesDataItem3.compareTo((java.lang.Object) boolean83);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 7 + "'", number4.equals(7));
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 9 + "'", int13 == 9);
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(serialDate17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1900 + "'", int20 == 1900);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 9 + "'", int23 == 9);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
//        org.junit.Assert.assertNotNull(wildcardClass31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 100 + "'", int35 == 100);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 9 + "'", int38 == 9);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1900 + "'", int39 == 1900);
//        org.junit.Assert.assertNotNull(serialDate42);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 9 + "'", int45 == 9);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1900 + "'", int46 == 1900);
//        org.junit.Assert.assertNotNull(serialDate49);
//        org.junit.Assert.assertNotNull(serialDate53);
//        org.junit.Assert.assertNotNull(serialDate54);
//        org.junit.Assert.assertNotNull(serialDate55);
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertNotNull(serialDate62);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 9 + "'", int65 == 9);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1900 + "'", int66 == 1900);
//        org.junit.Assert.assertNotNull(serialDate69);
//        org.junit.Assert.assertNotNull(serialDate73);
//        org.junit.Assert.assertNotNull(serialDate74);
//        org.junit.Assert.assertNotNull(serialDate75);
//        org.junit.Assert.assertNotNull(serialDate77);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 2 + "'", int82 == 2);
//        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
//        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate6);
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate11 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate10);
        org.jfree.data.time.SerialDate serialDate13 = serialDate11.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate14 = serialDate6.getEndOfCurrentMonth(serialDate13);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate17 = serialDate13.getEndOfCurrentMonth(serialDate16);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int20 = spreadsheetDate19.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate23);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate28 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate27);
        org.jfree.data.time.SerialDate serialDate30 = serialDate28.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate31 = serialDate23.getEndOfCurrentMonth(serialDate30);
        org.jfree.data.time.SerialDate serialDate34 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate34);
        org.jfree.data.time.SerialDate serialDate37 = serialDate35.getFollowingDayOfWeek(5);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(serialDate37);
        java.lang.String str39 = serialDate37.toString();
        boolean boolean40 = spreadsheetDate19.isInRange(serialDate31, serialDate37);
        boolean boolean42 = spreadsheetDate3.isInRange(serialDate16, serialDate37, (int) (short) 100);
        org.jfree.data.time.SerialDate serialDate43 = org.jfree.data.time.SerialDate.addDays((int) '#', serialDate16);
        org.jfree.data.time.SerialDate serialDate44 = org.jfree.data.time.SerialDate.addMonths((int) (short) 100, serialDate16);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 9 + "'", int20 == 9);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(serialDate31);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(serialDate37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "13-April-2000" + "'", str39.equals("13-April-2000"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(serialDate43);
        org.junit.Assert.assertNotNull(serialDate44);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        java.lang.String str4 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        java.util.Date date6 = day5.getStart();
        java.lang.Class class7 = null;
        java.util.Date date8 = null;
        java.util.TimeZone timeZone9 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date8, timeZone9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date6, timeZone9);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date6);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date6);
        java.util.Date date14 = month13.getStart();
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month13, (double) 10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.clear();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
        java.util.Date date12 = day11.getStart();
        java.lang.Class class13 = null;
        java.util.Date date14 = null;
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date14, timeZone15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date12, timeZone15);
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date12);
        int int19 = day18.getMonth();
        timeSeries7.setKey((java.lang.Comparable) day18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = null;
        try {
            timeSeries7.delete(regularTimePeriod21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        java.util.Date date3 = day2.getEnd();
        java.lang.Class class4 = null;
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date5, timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date3, timeZone6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getSerialIndex();
        int int11 = month0.compareTo((java.lang.Object) long10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month0.next();
        org.jfree.data.time.Year year13 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
        java.lang.String str15 = year13.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year13.next();
        org.jfree.data.general.SeriesException seriesException18 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str19 = seriesException18.toString();
        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str22 = seriesException21.toString();
        seriesException18.addSuppressed((java.lang.Throwable) seriesException21);
        java.lang.Throwable[] throwableArray24 = seriesException18.getSuppressed();
        java.lang.Throwable[] throwableArray25 = seriesException18.getSuppressed();
        boolean boolean26 = year13.equals((java.lang.Object) seriesException18);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019" + "'", str15.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str19.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str22.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getEnd();
        java.lang.Class class2 = null;
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date3, timeZone4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date1, timeZone4);
        long long7 = year6.getLastMillisecond();
        java.lang.String str8 = year6.toString();
        java.lang.String str9 = year6.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1577865599999L + "'", long7 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
        java.util.Date date11 = day10.getStart();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day10, class12);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.util.Date date15 = day14.getStart();
        java.lang.Class class16 = null;
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day14, class16);
        java.lang.String str18 = timeSeries17.getDomainDescription();
        java.util.Collection collection19 = timeSeries13.getTimePeriodsUniqueToOtherSeries(timeSeries17);
        java.lang.String str20 = timeSeries13.getDomainDescription();
        java.util.Collection collection21 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
        java.util.Date date23 = day22.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day22.next();
        java.util.Date date25 = day22.getStart();
        boolean boolean26 = timeSeries3.equals((java.lang.Object) day22);
        timeSeries3.setDescription("");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Time" + "'", str18.equals("Time"));
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.lang.String str2 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate5);
//        org.jfree.data.time.SerialDate serialDate8 = serialDate6.getFollowingDayOfWeek(5);
//        int int9 = day0.compareTo((java.lang.Object) serialDate8);
//        serialDate8.setDescription("org.jfree.data.time.TimePeriodFormatException: 13-April-1900");
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10-June-2019" + "'", str2.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertNotNull(serialDate8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month(date1);
        int int4 = month3.getYearValue();
        java.lang.String str5 = month3.toString();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        java.util.Date date3 = day2.getEnd();
        java.lang.Class class4 = null;
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date5, timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date3, timeZone6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getSerialIndex();
        int int11 = month0.compareTo((java.lang.Object) long10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month0.next();
        org.jfree.data.time.Year year13 = month0.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
        java.util.Date date15 = year13.getStart();
        java.util.Calendar calendar16 = null;
        try {
            long long17 = year13.getLastMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.clear();
        org.jfree.data.time.TimeSeries timeSeries13 = timeSeries7.createCopy((int) (byte) 10, (int) 'a');
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar16 = null;
        fixedMillisecond15.peg(calendar16);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15, (double) 100);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(timeSeries13);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        long long1 = fixedMillisecond0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560190705971L + "'", long1 == 1560190705971L);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        boolean boolean7 = timeSeries3.isEmpty();
        timeSeries3.setDescription("org.jfree.data.general.SeriesException: hi!");
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond((long) (-1));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond11.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = fixedMillisecond11.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) (byte) 100);
        boolean boolean16 = timeSeries3.getNotify();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date1);
        int int3 = month2.getYearValue();
        int int4 = month2.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month2, 0.0d);
        java.lang.Object obj7 = null;
        boolean boolean8 = timeSeriesDataItem6.equals(obj7);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        java.util.Date date3 = day2.getEnd();
        java.lang.Class class4 = null;
        java.util.Date date5 = null;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date5, timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date3, timeZone6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.previous();
        long long10 = year8.getSerialIndex();
        int int11 = month0.compareTo((java.lang.Object) long10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month0.next();
        org.jfree.data.time.Year year13 = month0.getYear();
        org.jfree.data.time.Year year14 = month0.getYear();
        java.util.Calendar calendar15 = null;
        try {
            year14.peg(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2019L + "'", long10 == 2019L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(year13);
        org.junit.Assert.assertNotNull(year14);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(100L);
        java.util.Calendar calendar2 = null;
        fixedMillisecond1.peg(calendar2);
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        java.util.Calendar calendar5 = null;
        fixedMillisecond1.peg(calendar5);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        timeSeries3.setDescription("10-June-2019");
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
        java.util.Date date9 = day8.getEnd();
        java.lang.Class class10 = null;
        java.util.Date date11 = null;
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date11, timeZone12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date9, timeZone12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year14.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year14);
        timeSeries3.setRangeDescription("Preceding");
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day();
        java.util.Date date20 = day19.getStart();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day19, class21);
        timeSeries22.setMaximumItemAge(1L);
        java.lang.Object obj25 = timeSeries22.clone();
        boolean boolean26 = timeSeries22.isEmpty();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day();
        java.util.Date date28 = day27.getStart();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day27, class29);
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
        java.util.Date date32 = day31.getStart();
        java.lang.Class class33 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day31, class33);
        java.lang.String str35 = timeSeries34.getDomainDescription();
        java.util.Collection collection36 = timeSeries30.getTimePeriodsUniqueToOtherSeries(timeSeries34);
        timeSeries34.clear();
        boolean boolean38 = timeSeries34.getNotify();
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries22.addAndOrUpdate(timeSeries34);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar42 = null;
        fixedMillisecond41.peg(calendar42);
        long long44 = fixedMillisecond41.getFirstMillisecond();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
        java.util.Date date46 = day45.getEnd();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date46);
        boolean boolean48 = fixedMillisecond41.equals((java.lang.Object) date46);
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar51 = null;
        long long52 = fixedMillisecond50.getLastMillisecond(calendar51);
        org.jfree.data.time.TimeSeries timeSeries53 = timeSeries22.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond50);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener54 = null;
        timeSeries22.addChangeListener(seriesChangeListener54);
        java.util.Collection collection56 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries22);
        timeSeries3.setMaximumItemCount((int) 'a');
        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month();
        java.lang.String str60 = month59.toString();
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day();
        java.util.Date date62 = day61.getEnd();
        java.lang.Class class63 = null;
        java.util.Date date64 = null;
        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance(class63, date64, timeZone65);
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(date62, timeZone65);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = year67.previous();
        long long69 = year67.getSerialIndex();
        int int70 = month59.compareTo((java.lang.Object) long69);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = month59.next();
        org.jfree.data.time.Year year72 = month59.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = year72.previous();
        java.lang.String str74 = year72.toString();
        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day();
        java.util.Date date76 = day75.getStart();
        org.jfree.data.time.Year year77 = new org.jfree.data.time.Year(date76);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = year77.previous();
        int int79 = year72.compareTo((java.lang.Object) year77);
        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day();
        java.util.Date date81 = day80.getEnd();
        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day(date81);
        org.jfree.data.time.TimeSeries timeSeries83 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year77, (org.jfree.data.time.RegularTimePeriod) day82);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Time" + "'", str35.equals("Time"));
        org.junit.Assert.assertNotNull(collection36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
        org.junit.Assert.assertNotNull(timeSeries53);
        org.junit.Assert.assertNotNull(collection56);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "June 2019" + "'", str60.equals("June 2019"));
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertNotNull(timeZone65);
        org.junit.Assert.assertNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 2019L + "'", long69 == 2019L);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod71);
        org.junit.Assert.assertNotNull(year72);
        org.junit.Assert.assertNotNull(regularTimePeriod73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "2019" + "'", str74.equals("2019"));
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(regularTimePeriod78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertNotNull(timeSeries83);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        int int1 = day0.getDayOfMonth();
//        java.lang.Class class4 = null;
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) int1, "org.jfree.data.general.SeriesChangeEvent[source=-1]", "hi!", class4);
//        boolean boolean6 = timeSeries5.getNotify();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond((long) (-1));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond8.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond8.previous();
//        try {
//            timeSeries5.update(regularTimePeriod10, (java.lang.Number) 10);
//            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
//        } catch (org.jfree.data.general.SeriesException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(regularTimePeriod10);
//    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        int int2 = spreadsheetDate1.getDayOfMonth();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        java.util.Date date4 = day3.getStart();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date4);
//        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(date4);
//        boolean boolean7 = spreadsheetDate1.isOnOrAfter(serialDate6);
//        int int8 = spreadsheetDate1.toSerial();
//        int int9 = spreadsheetDate1.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
//        int int12 = spreadsheetDate11.getDayOfMonth();
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        java.util.Date date14 = day13.getStart();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date14);
//        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(date14);
//        boolean boolean17 = spreadsheetDate11.isOnOrAfter(serialDate16);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        int int19 = day18.getDayOfMonth();
//        java.lang.Class<?> wildcardClass20 = day18.getClass();
//        boolean boolean21 = spreadsheetDate11.equals((java.lang.Object) day18);
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) spreadsheetDate11);
//        boolean boolean23 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate11);
//        int int24 = spreadsheetDate1.toSerial();
//        int int25 = spreadsheetDate1.getMonth();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1900 + "'", int9 == 1900);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(serialDate16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int3 = spreadsheetDate2.getDayOfMonth();
        int int4 = spreadsheetDate2.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate7 = spreadsheetDate2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate9 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int10 = spreadsheetDate9.getDayOfMonth();
        int int11 = spreadsheetDate9.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate13 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate14 = spreadsheetDate9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate13);
        org.jfree.data.time.SerialDate serialDate18 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate19 = org.jfree.data.time.SerialDate.addDays(4, serialDate18);
        org.jfree.data.time.SerialDate serialDate20 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate18);
        org.jfree.data.time.SerialDate serialDate22 = serialDate20.getPreviousDayOfWeek(7);
        boolean boolean23 = spreadsheetDate9.isBefore(serialDate22);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate27 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate26);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate29 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int30 = spreadsheetDate29.getDayOfMonth();
        int int31 = spreadsheetDate29.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate33 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate34 = spreadsheetDate29.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate33);
        org.jfree.data.time.SerialDate serialDate38 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate39 = org.jfree.data.time.SerialDate.addDays(4, serialDate38);
        org.jfree.data.time.SerialDate serialDate40 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate38);
        org.jfree.data.time.SerialDate serialDate42 = serialDate40.getPreviousDayOfWeek(7);
        boolean boolean43 = spreadsheetDate29.isBefore(serialDate42);
        boolean boolean45 = spreadsheetDate9.isInRange(serialDate27, serialDate42, (-457));
        boolean boolean46 = spreadsheetDate2.isOn((org.jfree.data.time.SerialDate) spreadsheetDate9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar49 = null;
        fixedMillisecond48.peg(calendar49);
        long long51 = fixedMillisecond48.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond48, 0.0d);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate55 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int56 = spreadsheetDate55.getDayOfMonth();
        int int57 = spreadsheetDate55.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate59 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate60 = spreadsheetDate55.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate59);
        java.util.Date date61 = spreadsheetDate59.toDate();
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day();
        java.util.Date date63 = day62.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = day62.next();
        java.util.Date date65 = day62.getStart();
        org.jfree.data.time.SerialDate serialDate66 = org.jfree.data.time.SerialDate.createInstance(date65);
        boolean boolean67 = spreadsheetDate59.isOnOrAfter(serialDate66);
        java.util.Date date68 = spreadsheetDate59.toDate();
        int int69 = spreadsheetDate59.getDayOfMonth();
        boolean boolean70 = timeSeriesDataItem53.equals((java.lang.Object) spreadsheetDate59);
        int int71 = spreadsheetDate59.getDayOfMonth();
        boolean boolean72 = spreadsheetDate9.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate59);
        try {
            org.jfree.data.time.SerialDate serialDate73 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, (org.jfree.data.time.SerialDate) spreadsheetDate59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1900 + "'", int11 == 1900);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertNotNull(serialDate27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 9 + "'", int30 == 9);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1900 + "'", int31 == 1900);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(serialDate38);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 9 + "'", int56 == 9);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1900 + "'", int57 == 1900);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 9 + "'", int69 == 9);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 9 + "'", int71 == 9);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        timeSeries3.setMaximumItemAge(1L);
        java.lang.Object obj6 = timeSeries3.clone();
        java.util.List list7 = timeSeries3.getItems();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timeSeries3.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = null;
        try {
            timeSeries3.add(regularTimePeriod10, (java.lang.Number) 10.0f, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        int int2 = month0.getYearValue();
        long long3 = month0.getMiddleMillisecond();
        java.lang.String str4 = month0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        java.lang.Class class2 = null;
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day0, class2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day();
        java.util.Date date5 = day4.getStart();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day4, class6);
        java.lang.String str8 = timeSeries7.getDomainDescription();
        java.util.Collection collection9 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries7);
        timeSeries7.setMaximumItemCount(9999);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        java.util.Date date14 = day13.getEnd();
        java.lang.Class class15 = null;
        java.util.Date date16 = null;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date14, timeZone17);
        int int21 = year19.compareTo((java.lang.Object) "Saturday");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year19.previous();
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month12, regularTimePeriod22);
        java.lang.Object obj24 = timeSeries7.clone();
        timeSeries7.setNotify(false);
        java.lang.String str27 = timeSeries7.getDomainDescription();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day();
        java.util.Date date29 = day28.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day28, (java.lang.Number) 7);
        java.lang.Number number32 = timeSeriesDataItem31.getValue();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day();
        java.util.Date date34 = day33.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day33, (java.lang.Number) 7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day33.previous();
        int int38 = timeSeriesDataItem31.compareTo((java.lang.Object) regularTimePeriod37);
        java.lang.Number number39 = timeSeries7.getValue(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Time" + "'", str8.equals("Time"));
        org.junit.Assert.assertNotNull(collection9);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Time" + "'", str27.equals("Time"));
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 7 + "'", number32.equals(7));
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNull(number39);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate3);
        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getFollowingDayOfWeek(5);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.addMonths(9999, serialDate4);
        serialDate7.setDescription("2019");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate11 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int12 = spreadsheetDate11.getDayOfMonth();
        int int13 = spreadsheetDate11.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate15 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate16 = spreadsheetDate11.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SerialDate serialDate17 = serialDate7.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate15);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate19 = new org.jfree.data.time.SpreadsheetDate(2019);
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate22);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
        java.util.Date date26 = day25.getEnd();
        java.lang.Class class27 = null;
        java.util.Date date28 = null;
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance(class27, date28, timeZone29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date26, timeZone29);
        org.jfree.data.time.SerialDate serialDate32 = org.jfree.data.time.SerialDate.createInstance(date26);
        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 0, serialDate32);
        boolean boolean34 = spreadsheetDate19.isInRange(serialDate23, serialDate32);
        boolean boolean35 = spreadsheetDate15.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate19);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate37 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int38 = spreadsheetDate37.getDayOfMonth();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate40 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int41 = spreadsheetDate40.getDayOfMonth();
        int int42 = spreadsheetDate40.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate44 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate45 = spreadsheetDate40.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate44);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int48 = spreadsheetDate47.getDayOfMonth();
        int int49 = spreadsheetDate47.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate51 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate52 = spreadsheetDate47.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate51);
        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate57 = org.jfree.data.time.SerialDate.addDays(4, serialDate56);
        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate56);
        org.jfree.data.time.SerialDate serialDate60 = serialDate58.getPreviousDayOfWeek(7);
        boolean boolean61 = spreadsheetDate47.isBefore(serialDate60);
        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate65 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate64);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate67 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        int int68 = spreadsheetDate67.getDayOfMonth();
        int int69 = spreadsheetDate67.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate71 = new org.jfree.data.time.SpreadsheetDate((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate72 = spreadsheetDate67.getEndOfCurrentMonth((org.jfree.data.time.SerialDate) spreadsheetDate71);
        org.jfree.data.time.SerialDate serialDate76 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate77 = org.jfree.data.time.SerialDate.addDays(4, serialDate76);
        org.jfree.data.time.SerialDate serialDate78 = org.jfree.data.time.SerialDate.addDays((int) (byte) 0, serialDate76);
        org.jfree.data.time.SerialDate serialDate80 = serialDate78.getPreviousDayOfWeek(7);
        boolean boolean81 = spreadsheetDate67.isBefore(serialDate80);
        boolean boolean83 = spreadsheetDate47.isInRange(serialDate65, serialDate80, (-457));
        boolean boolean84 = spreadsheetDate40.isOn((org.jfree.data.time.SerialDate) spreadsheetDate47);
        int int85 = spreadsheetDate47.getDayOfWeek();
        java.util.Date date86 = spreadsheetDate47.toDate();
        boolean boolean87 = spreadsheetDate37.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate47);
        org.jfree.data.time.SerialDate serialDate90 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate91 = org.jfree.data.time.SerialDate.addYears((int) (byte) 100, serialDate90);
        org.jfree.data.time.SerialDate serialDate93 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate94 = serialDate91.getEndOfCurrentMonth(serialDate93);
        org.jfree.data.time.Day day95 = new org.jfree.data.time.Day(serialDate91);
        int int96 = spreadsheetDate37.compare(serialDate91);
        boolean boolean97 = spreadsheetDate19.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate37);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1900 + "'", int13 == 1900);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(serialDate33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 9 + "'", int38 == 9);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 9 + "'", int41 == 9);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1900 + "'", int42 == 1900);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 9 + "'", int48 == 9);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1900 + "'", int49 == 1900);
        org.junit.Assert.assertNotNull(serialDate52);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertNotNull(serialDate60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(serialDate64);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 9 + "'", int68 == 9);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1900 + "'", int69 == 1900);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertNotNull(serialDate76);
        org.junit.Assert.assertNotNull(serialDate77);
        org.junit.Assert.assertNotNull(serialDate78);
        org.junit.Assert.assertNotNull(serialDate80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 2 + "'", int85 == 2);
        org.junit.Assert.assertNotNull(date86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(serialDate90);
        org.junit.Assert.assertNotNull(serialDate91);
        org.junit.Assert.assertNotNull(serialDate93);
        org.junit.Assert.assertNotNull(serialDate94);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + (-36525) + "'", int96 == (-36525));
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
    }
}

