import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, 25568L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        timePeriodValues1.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        java.beans.PropertyChangeListener propertyChangeListener10 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener10);
        int int12 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        int int6 = year5.getYear();
        int int7 = year5.getYear();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1969 + "'", int6 == 1969);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3, "Value", "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=a]");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (double) 0);
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date3, date14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date3);
        java.lang.String str18 = year17.toString();
        long long19 = year17.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969" + "'", str18.equals("1969"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-31507200000L) + "'", long19 == (-31507200000L));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "Time", "org.jfree.data.general.SeriesException: hi!", "");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timePeriodValues3.getKey();
        int int7 = timePeriodValues3.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + "Time" + "'", comparable6.equals("Time"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        java.lang.Comparable comparable7 = timePeriodValues1.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        boolean boolean12 = simpleTimePeriod10.equals((java.lang.Object) 0.0d);
        boolean boolean13 = timePeriodValues1.equals((java.lang.Object) 0.0d);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener16);
        int int18 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + ' ' + "'", comparable7.equals(' '));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 'a');
        boolean boolean2 = timePeriodValues1.isEmpty();
        timePeriodValues1.setNotify(false);
        int int5 = timePeriodValues1.getItemCount();
        boolean boolean6 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        int int16 = day13.getMonth();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.util.Date date20 = simpleTimePeriod19.getStart();
        java.util.TimeZone timeZone21 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20, timeZone21);
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year22);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 11);
        long long27 = simpleTimePeriod26.getStartMillis();
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) simpleTimePeriod26, (double) (short) 100);
        int int30 = day13.compareTo((java.lang.Object) (short) 100);
        java.util.Calendar calendar31 = null;
        try {
            long long32 = day13.getLastMillisecond(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(timeZone21);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getFirstMillisecond();
        long long10 = year7.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) (-14400001L));
        java.lang.String str13 = year7.toString();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year7.getLastMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-31507200000L) + "'", long9 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1969L + "'", long10 == 1969L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969" + "'", str13.equals("1969"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setKey((java.lang.Comparable) 'a');
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy((int) '#', (int) (short) 100);
        try {
            java.lang.Number number9 = timePeriodValues1.getValue(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriodValues7);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        java.lang.Object obj7 = timePeriodValues1.clone();
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + ' ' + "'", comparable6.equals(' '));
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 10L);
        java.util.Date date3 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int2 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.delete(8, (int) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener8);
        java.lang.String str10 = timePeriodValues1.getDescription();
        boolean boolean11 = timePeriodValues1.isEmpty();
        int int12 = timePeriodValues1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener13);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue16 = timePeriodValues1.getDataItem((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        java.lang.Class class6 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass10 = simpleTimePeriod9.getClass();
        long long11 = simpleTimePeriod9.getEndMillis();
        long long12 = simpleTimePeriod9.getStartMillis();
        java.util.Date date13 = simpleTimePeriod9.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj17 = null;
        boolean boolean18 = simpleTimePeriod16.equals(obj17);
        java.util.Date date19 = simpleTimePeriod16.getEnd();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        boolean boolean22 = day20.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate23 = day20.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass27 = simpleTimePeriod26.getClass();
        long long28 = simpleTimePeriod26.getEndMillis();
        long long29 = simpleTimePeriod26.getStartMillis();
        java.util.Date date30 = simpleTimePeriod26.getStart();
        boolean boolean31 = day20.equals((java.lang.Object) date30);
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date30, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date13, timeZone32);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj38 = null;
        boolean boolean39 = simpleTimePeriod37.equals(obj38);
        java.util.Date date40 = simpleTimePeriod37.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod44.equals(obj45);
        java.util.Date date47 = simpleTimePeriod44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date47);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod(date40, date47);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod(date13, date40);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj55 = null;
        boolean boolean56 = simpleTimePeriod54.equals(obj55);
        java.util.Date date57 = simpleTimePeriod54.getEnd();
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date57);
        boolean boolean60 = day58.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate61 = day58.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod64 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass65 = simpleTimePeriod64.getClass();
        long long66 = simpleTimePeriod64.getEndMillis();
        long long67 = simpleTimePeriod64.getStartMillis();
        java.util.Date date68 = simpleTimePeriod64.getStart();
        boolean boolean69 = day58.equals((java.lang.Object) date68);
        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(date68, timeZone70);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date13, timeZone70);
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date5, timeZone70);
        long long74 = year73.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 10L + "'", long66 == 10L);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 0L + "'", long67 == 0L);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(timeZone70);
        org.junit.Assert.assertNull(regularTimePeriod72);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-15739200001L) + "'", long74 == (-15739200001L));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        java.lang.Class class6 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass10 = simpleTimePeriod9.getClass();
        long long11 = simpleTimePeriod9.getEndMillis();
        long long12 = simpleTimePeriod9.getStartMillis();
        java.util.Date date13 = simpleTimePeriod9.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj17 = null;
        boolean boolean18 = simpleTimePeriod16.equals(obj17);
        java.util.Date date19 = simpleTimePeriod16.getEnd();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        boolean boolean22 = day20.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate23 = day20.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass27 = simpleTimePeriod26.getClass();
        long long28 = simpleTimePeriod26.getEndMillis();
        long long29 = simpleTimePeriod26.getStartMillis();
        java.util.Date date30 = simpleTimePeriod26.getStart();
        boolean boolean31 = day20.equals((java.lang.Object) date30);
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date30, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date13, timeZone32);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj38 = null;
        boolean boolean39 = simpleTimePeriod37.equals(obj38);
        java.util.Date date40 = simpleTimePeriod37.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod44.equals(obj45);
        java.util.Date date47 = simpleTimePeriod44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date47);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod(date40, date47);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod(date13, date40);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj55 = null;
        boolean boolean56 = simpleTimePeriod54.equals(obj55);
        java.util.Date date57 = simpleTimePeriod54.getEnd();
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date57);
        boolean boolean60 = day58.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate61 = day58.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod64 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass65 = simpleTimePeriod64.getClass();
        long long66 = simpleTimePeriod64.getEndMillis();
        long long67 = simpleTimePeriod64.getStartMillis();
        java.util.Date date68 = simpleTimePeriod64.getStart();
        boolean boolean69 = day58.equals((java.lang.Object) date68);
        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(date68, timeZone70);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date13, timeZone70);
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date5, timeZone70);
        org.jfree.data.time.Day day74 = new org.jfree.data.time.Day(date5);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 10L + "'", long66 == 10L);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 0L + "'", long67 == 0L);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(timeZone70);
        org.junit.Assert.assertNull(regularTimePeriod72);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 10, (long) ' ');
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 12);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        long long6 = simpleTimePeriod2.getStartMillis();
        java.util.Date date7 = simpleTimePeriod2.getStart();
        java.util.Date date8 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues10.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener13);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues10.removeChangeListener(seriesChangeListener15);
        java.lang.Class<?> wildcardClass17 = timePeriodValues10.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.util.Date date21 = simpleTimePeriod20.getStart();
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21, timeZone22);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.util.Date date27 = simpleTimePeriod26.getStart();
        java.util.TimeZone timeZone28 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27, timeZone28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date21, timeZone28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod33, (double) 0);
        java.util.Date date36 = simpleTimePeriod33.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj41 = null;
        boolean boolean42 = simpleTimePeriod40.equals(obj41);
        java.util.Date date43 = simpleTimePeriod40.getEnd();
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
        boolean boolean46 = day44.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate47 = day44.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass51 = simpleTimePeriod50.getClass();
        long long52 = simpleTimePeriod50.getEndMillis();
        long long53 = simpleTimePeriod50.getStartMillis();
        java.util.Date date54 = simpleTimePeriod50.getStart();
        boolean boolean55 = day44.equals((java.lang.Object) date54);
        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date54, timeZone56);
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date36, timeZone56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass17, date21, timeZone56);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod60 = new org.jfree.data.time.SimpleTimePeriod(date8, date21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(serialDate47);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 10L + "'", long52 == 10L);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(timeZone56);
        org.junit.Assert.assertNull(regularTimePeriod59);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener6);
        int int8 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int2 = timePeriodValues1.getMaxEndIndex();
        java.lang.Comparable comparable3 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(9, (int) (byte) 1);
        timePeriodValues6.setDescription("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + ' ' + "'", comparable3.equals(' '));
        org.junit.Assert.assertNotNull(timePeriodValues6);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "", "Value");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues8.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues8.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "", "Value");
        timePeriodValues16.fireSeriesChanged();
        boolean boolean18 = timePeriodValues8.equals((java.lang.Object) timePeriodValues16);
        boolean boolean19 = timePeriodValues3.equals((java.lang.Object) timePeriodValues16);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener20);
        java.lang.Comparable comparable22 = timePeriodValues3.getKey();
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + "hi!" + "'", comparable22.equals("hi!"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        int int16 = day13.getDayOfMonth();
        boolean boolean18 = day13.equals((java.lang.Object) (-15739200001L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 31 + "'", int16 == 31);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj43 = null;
        boolean boolean44 = simpleTimePeriod42.equals(obj43);
        java.util.Date date45 = simpleTimePeriod42.getEnd();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        boolean boolean48 = day46.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate49 = day46.getSerialDate();
        long long50 = day46.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate51 = day46.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = day46.next();
        timePeriodValues28.add((org.jfree.data.time.TimePeriod) day46, (java.lang.Number) 71999999L);
        boolean boolean55 = timePeriodValues28.getNotify();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj59 = null;
        boolean boolean60 = simpleTimePeriod58.equals(obj59);
        java.util.Date date61 = simpleTimePeriod58.getEnd();
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date61);
        boolean boolean64 = day62.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate65 = day62.getSerialDate();
        long long66 = day62.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate67 = day62.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = day62.next();
        long long69 = regularTimePeriod68.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue71 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod68, (double) 28799999L);
        java.lang.String str72 = timePeriodValue71.toString();
        timePeriodValues28.add(timePeriodValue71);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 25568L + "'", long50 == 25568L);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 25568L + "'", long66 == 25568L);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 71999999L + "'", long69 == 71999999L);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "TimePeriodValue[1-January-1970,2.8799999E7]" + "'", str72.equals("TimePeriodValue[1-January-1970,2.8799999E7]"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "", "Value");
        timePeriodValues9.fireSeriesChanged();
        boolean boolean11 = timePeriodValues1.equals((java.lang.Object) timePeriodValues9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (double) 0);
        java.lang.Number number17 = timePeriodValue16.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        boolean boolean26 = day24.equals((java.lang.Object) '4');
        long long27 = day24.getMiddleMillisecond();
        long long28 = day24.getFirstMillisecond();
        boolean boolean29 = timePeriodValue16.equals((java.lang.Object) day24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day24.next();
        java.lang.String str31 = day24.toString();
        timePeriodValues1.setKey((java.lang.Comparable) day24);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.fireSeriesChanged();
        try {
            java.lang.Number number37 = timePeriodValues1.getValue(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0.0d + "'", number17.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-14400001L) + "'", long27 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-57600000L) + "'", long28 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "31-December-1969" + "'", str31.equals("31-December-1969"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "", "Value");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        long long11 = day10.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-57600000L) + "'", long11 == (-57600000L));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Time");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodFormatException1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        long long6 = simpleTimePeriod2.getStartMillis();
        java.util.Date date7 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod10, (double) 0);
        java.lang.Number number13 = timePeriodValue12.getValue();
        boolean boolean14 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValue12);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.0d + "'", number13.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        int int3 = timePeriodValues1.getMaxStartIndex();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        timePeriodValues1.setDescription("1969");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3, "Value", "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=a]");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (double) 0);
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date3, date14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue22 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod20, (double) 0);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(date3, date23);
        long long26 = simpleTimePeriod25.getEndMillis();
        java.util.Date date27 = simpleTimePeriod25.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 5L + "'", long26 == 5L);
        org.junit.Assert.assertNotNull(date27);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int6 = timePeriodValues5.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues5.addChangeListener(seriesChangeListener7);
        boolean boolean9 = timePeriodValues1.equals((java.lang.Object) seriesChangeListener7);
        java.lang.Comparable comparable10 = timePeriodValues1.getKey();
        int int11 = timePeriodValues1.getItemCount();
        java.lang.Object obj12 = timePeriodValues1.clone();
        timePeriodValues1.setDomainDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=a]");
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 'a' + "'", comparable10.equals('a'));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        java.lang.Comparable comparable7 = timePeriodValues1.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        boolean boolean12 = simpleTimePeriod10.equals((java.lang.Object) 0.0d);
        boolean boolean13 = timePeriodValues1.equals((java.lang.Object) 0.0d);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener16);
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + ' ' + "'", comparable7.equals(' '));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getLastMillisecond();
        long long12 = year7.getFirstMillisecond();
        long long13 = year7.getSerialIndex();
        java.lang.Object obj14 = null;
        boolean boolean15 = year7.equals(obj14);
        java.util.Date date16 = year7.getEnd();
        long long17 = year7.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-31507200000L) + "'", long12 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1969L + "'", long13 == 1969L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1969L + "'", long17 == 1969L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        boolean boolean4 = timePeriodValues1.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener5);
        try {
            timePeriodValues1.delete(4, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass13 = simpleTimePeriod12.getClass();
        long long14 = simpleTimePeriod12.getEndMillis();
        long long15 = simpleTimePeriod12.getStartMillis();
        java.util.Date date16 = simpleTimePeriod12.getStart();
        boolean boolean17 = day6.equals((java.lang.Object) date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16, timeZone18);
        java.util.Date date20 = day19.getStart();
        java.util.Date date21 = day19.getStart();
        long long22 = day19.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-14400001L) + "'", long22 == (-14400001L));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str8 = seriesException7.toString();
        boolean boolean9 = timePeriodValues1.equals((java.lang.Object) seriesException7);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy(7, 0);
        timePeriodValues1.setDomainDescription("");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj18 = null;
        boolean boolean19 = simpleTimePeriod17.equals(obj18);
        java.util.Date date20 = simpleTimePeriod17.getEnd();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20);
        java.lang.String str23 = year22.toString();
        long long24 = year22.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year22.next();
        long long26 = year22.getLastMillisecond();
        long long27 = year22.getFirstMillisecond();
        long long28 = year22.getSerialIndex();
        boolean boolean29 = timePeriodValues1.equals((java.lang.Object) long28);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str8.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1969" + "'", str23.equals("1969"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28799999L + "'", long24 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 28799999L + "'", long26 == 28799999L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-31507200000L) + "'", long27 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1969L + "'", long28 == 1969L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        int int10 = day6.getYear();
        java.lang.String str11 = day6.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-1969" + "'", str11.equals("31-December-1969"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        java.lang.String str5 = timePeriodValues1.getDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        int int7 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 9, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean3 = timePeriodValues2.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues2.addChangeListener(seriesChangeListener4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues2.addChangeListener(seriesChangeListener6);
        int int8 = year0.compareTo((java.lang.Object) timePeriodValues2);
        int int10 = year0.compareTo((java.lang.Object) 10);
        long long11 = year0.getSerialIndex();
        long long12 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2019L + "'", long11 == 2019L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        int int16 = day13.getMonth();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj20 = null;
        boolean boolean21 = simpleTimePeriod19.equals(obj20);
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        boolean boolean25 = day23.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate26 = day23.getSerialDate();
        int int27 = day23.getYear();
        long long28 = day23.getFirstMillisecond();
        int int29 = day13.compareTo((java.lang.Object) long28);
        int int30 = day13.getDayOfMonth();
        int int31 = day13.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-57600000L) + "'", long28 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 31 + "'", int30 == 31);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 31 + "'", int31 == 31);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        long long9 = day6.getMiddleMillisecond();
        java.lang.String str10 = day6.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day6.previous();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-14400001L) + "'", long9 == (-14400001L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-1969" + "'", str10.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        java.util.Date date11 = year7.getStart();
        java.lang.Number number12 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, number12);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 10, (long) ' ');
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 12);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean8 = timePeriodValues7.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener9);
        timePeriodValues7.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj16 = null;
        boolean boolean17 = simpleTimePeriod15.equals(obj16);
        java.util.Date date18 = simpleTimePeriod15.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) 100);
        int int22 = day19.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) (byte) 100);
        org.jfree.data.time.TimePeriod timePeriod25 = timePeriodValue24.getPeriod();
        org.jfree.data.time.TimePeriodValue timePeriodValue27 = new org.jfree.data.time.TimePeriodValue(timePeriod25, (java.lang.Number) 15796799999L);
        try {
            int int28 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodValue27);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValue cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
        org.junit.Assert.assertNotNull(timePeriod25);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        java.lang.Number number18 = timePeriodValue4.getValue();
        java.lang.String str19 = timePeriodValue4.toString();
        org.jfree.data.time.TimePeriod timePeriod20 = timePeriodValue4.getPeriod();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent21 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValue4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 0.0d + "'", number18.equals(0.0d));
        org.junit.Assert.assertNotNull(timePeriod20);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass9 = simpleTimePeriod8.getClass();
        long long10 = simpleTimePeriod8.getEndMillis();
        long long11 = simpleTimePeriod8.getStartMillis();
        boolean boolean12 = simpleTimePeriod2.equals((java.lang.Object) long11);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 28799999L);
        long long15 = simpleTimePeriod2.getStartMillis();
        java.util.Date date16 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        long long18 = day17.getFirstMillisecond();
        org.jfree.data.time.SerialDate serialDate19 = day17.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day17.previous();
        org.jfree.data.time.SerialDate serialDate21 = day17.getSerialDate();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-57600000L) + "'", long18 == (-57600000L));
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(serialDate21);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getLastMillisecond();
        long long12 = year7.getFirstMillisecond();
        long long13 = year7.getFirstMillisecond();
        int int14 = year7.getYear();
        long long15 = year7.getFirstMillisecond();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (double) 0);
        java.util.Date date21 = simpleTimePeriod18.getEnd();
        long long22 = simpleTimePeriod18.getStartMillis();
        java.util.Date date23 = simpleTimePeriod18.getEnd();
        int int24 = year7.compareTo((java.lang.Object) date23);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-31507200000L) + "'", long12 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-31507200000L) + "'", long13 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-31507200000L) + "'", long15 == (-31507200000L));
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        boolean boolean41 = day12.equals((java.lang.Object) 1L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod44.equals(obj45);
        java.util.Date date47 = simpleTimePeriod44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        boolean boolean50 = day48.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate51 = day48.getSerialDate();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
        boolean boolean53 = day12.equals((java.lang.Object) serialDate51);
        int int54 = day12.getYear();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent55 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day12);
        org.jfree.data.time.TimePeriodValues timePeriodValues56 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day12);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1969 + "'", int54 == 1969);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day5.previous();
        int int7 = simpleTimePeriod2.compareTo((java.lang.Object) regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        java.lang.String str7 = timePeriodValues1.getDescription();
        int int8 = timePeriodValues1.getMaxMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener9);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass3 = simpleTimePeriod2.getClass();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        boolean boolean15 = day13.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass20 = simpleTimePeriod19.getClass();
        long long21 = simpleTimePeriod19.getEndMillis();
        long long22 = simpleTimePeriod19.getStartMillis();
        java.util.Date date23 = simpleTimePeriod19.getStart();
        boolean boolean24 = day13.equals((java.lang.Object) date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date6, timeZone25);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj31 = null;
        boolean boolean32 = simpleTimePeriod30.equals(obj31);
        java.util.Date date33 = simpleTimePeriod30.getEnd();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj38 = null;
        boolean boolean39 = simpleTimePeriod37.equals(obj38);
        java.util.Date date40 = simpleTimePeriod37.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date40);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date33, date40);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod(date6, date33);
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date33, timeZone45);
        org.jfree.data.time.SerialDate serialDate47 = day46.getSerialDate();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(serialDate47);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNotNull(serialDate47);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        int int11 = day10.getDayOfMonth();
        long long12 = day10.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        long long9 = day6.getMiddleMillisecond();
        java.lang.String str10 = day6.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day6.next();
        int int12 = day6.getYear();
        long long13 = day6.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day6.previous();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-14400001L) + "'", long9 == (-14400001L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-1969" + "'", str10.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-57600000L) + "'", long13 == (-57600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.delete(0, (int) (byte) -1);
        timePeriodValues1.setRangeDescription("org.jfree.data.general.SeriesException: ");
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.next();
        java.lang.Class<?> wildcardClass10 = regularTimePeriod9.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(class13);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Object obj5 = timePeriodValue4.clone();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) long16);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues19.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues19.addPropertyChangeListener(propertyChangeListener22);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timePeriodValues19.removeChangeListener(seriesChangeListener24);
        boolean boolean26 = timePeriodValue4.equals((java.lang.Object) seriesChangeListener24);
        timePeriodValue4.setValue((java.lang.Number) 28799999L);
        timePeriodValue4.setValue((java.lang.Number) 1.0d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod5, (double) 0);
        try {
            int int8 = simpleTimePeriod2.compareTo((java.lang.Object) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 2, (long) 1969);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 11);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 11L + "'", long4 == 11L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        java.util.Date date2 = regularTimePeriod1.getEnd();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 10, (long) ' ');
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 12);
        java.lang.String str5 = timePeriodValue4.toString();
        java.lang.Object obj6 = timePeriodValue4.clone();
        java.lang.Number number7 = timePeriodValue4.getValue();
        java.lang.Object obj8 = timePeriodValue4.clone();
        org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValue4.getPeriod();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 12 + "'", number7.equals(12));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(timePeriod9);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.setDescription("TimePeriodValue[1-January-1970,2.8799999E7]");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str8 = seriesException7.toString();
        boolean boolean9 = timePeriodValues1.equals((java.lang.Object) seriesException7);
        try {
            java.lang.Number number11 = timePeriodValues1.getValue(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str8.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        boolean boolean41 = day12.equals((java.lang.Object) 1L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod44.equals(obj45);
        java.util.Date date47 = simpleTimePeriod44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        boolean boolean50 = day48.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate51 = day48.getSerialDate();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
        boolean boolean53 = day12.equals((java.lang.Object) serialDate51);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(serialDate51);
        org.jfree.data.time.TimePeriodValue timePeriodValue56 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day54, (double) 10.0f);
        long long57 = day54.getSerialIndex();
        long long58 = day54.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 25568L + "'", long57 == 25568L);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 28799999L + "'", long58 == 28799999L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setKey((java.lang.Comparable) 'a');
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy((int) '#', (int) (short) 100);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = null;
        try {
            timePeriodValues1.add(timePeriodValue8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertNotNull(timePeriodValues7);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        long long5 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        java.lang.String str7 = timePeriodValues1.getDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues9.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener12 = null;
        timePeriodValues9.removeChangeListener(seriesChangeListener12);
        boolean boolean14 = timePeriodValues9.isEmpty();
        timePeriodValues9.delete(0, (int) (short) -1);
        boolean boolean18 = timePeriodValues1.equals((java.lang.Object) (short) -1);
        timePeriodValues1.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=a]");
        try {
            timePeriodValues1.delete((int) (short) 1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(date5, date12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass19 = simpleTimePeriod18.getClass();
        long long20 = simpleTimePeriod18.getEndMillis();
        long long21 = simpleTimePeriod18.getStartMillis();
        java.util.Date date22 = simpleTimePeriod18.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj26 = null;
        boolean boolean27 = simpleTimePeriod25.equals(obj26);
        java.util.Date date28 = simpleTimePeriod25.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        boolean boolean31 = day29.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate32 = day29.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass36 = simpleTimePeriod35.getClass();
        long long37 = simpleTimePeriod35.getEndMillis();
        long long38 = simpleTimePeriod35.getStartMillis();
        java.util.Date date39 = simpleTimePeriod35.getStart();
        boolean boolean40 = day29.equals((java.lang.Object) date39);
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date39, timeZone41);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date22, timeZone41);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date5, timeZone41);
        org.jfree.data.time.SerialDate serialDate45 = day44.getSerialDate();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(serialDate45);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 10L + "'", long37 == 10L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNotNull(serialDate45);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.String str5 = timePeriodValue4.toString();
        java.lang.Object obj6 = timePeriodValue4.clone();
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        int int10 = day6.getYear();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, (java.lang.Number) 3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getLastMillisecond();
        long long12 = year7.getFirstMillisecond();
        java.lang.String str13 = year7.toString();
        long long14 = year7.getSerialIndex();
        long long15 = year7.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-31507200000L) + "'", long12 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969" + "'", str13.equals("1969"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1969L + "'", long14 == 1969L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1969L + "'", long15 == 1969L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.Object obj6 = timePeriodValues1.clone();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "", "Value");
        timePeriodValues9.fireSeriesChanged();
        boolean boolean11 = timePeriodValues1.equals((java.lang.Object) timePeriodValues9);
        int int12 = timePeriodValues9.getMaxMiddleIndex();
        int int13 = timePeriodValues9.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day12.next();
        java.lang.String str19 = day12.toString();
        java.lang.Object obj20 = null;
        boolean boolean21 = day12.equals(obj20);
        java.util.Calendar calendar22 = null;
        try {
            long long23 = day12.getLastMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31-December-1969" + "'", str19.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setKey((java.lang.Comparable) 'a');
        int int4 = timePeriodValues1.getItemCount();
        int int5 = timePeriodValues1.getMinEndIndex();
        boolean boolean6 = timePeriodValues1.getNotify();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass10 = simpleTimePeriod9.getClass();
        long long11 = simpleTimePeriod9.getEndMillis();
        long long12 = simpleTimePeriod9.getStartMillis();
        long long13 = simpleTimePeriod9.getEndMillis();
        timePeriodValues1.setKey((java.lang.Comparable) simpleTimePeriod9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        boolean boolean41 = day12.equals((java.lang.Object) 1L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod44.equals(obj45);
        java.util.Date date47 = simpleTimePeriod44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        boolean boolean50 = day48.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate51 = day48.getSerialDate();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
        boolean boolean53 = day12.equals((java.lang.Object) serialDate51);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(serialDate51);
        java.util.Date date55 = day54.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues57 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int58 = timePeriodValues57.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener59 = null;
        timePeriodValues57.addChangeListener(seriesChangeListener59);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener61 = null;
        timePeriodValues57.addChangeListener(seriesChangeListener61);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener63 = null;
        timePeriodValues57.removeChangeListener(seriesChangeListener63);
        boolean boolean65 = day54.equals((java.lang.Object) timePeriodValues57);
        int int66 = timePeriodValues57.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        long long9 = day6.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 25568L + "'", long9 == 25568L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "", "Value");
        timePeriodValues9.fireSeriesChanged();
        boolean boolean11 = timePeriodValues1.equals((java.lang.Object) timePeriodValues9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (double) 0);
        java.lang.Number number17 = timePeriodValue16.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        boolean boolean26 = day24.equals((java.lang.Object) '4');
        long long27 = day24.getMiddleMillisecond();
        long long28 = day24.getFirstMillisecond();
        boolean boolean29 = timePeriodValue16.equals((java.lang.Object) day24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day24.next();
        java.lang.String str31 = day24.toString();
        timePeriodValues1.setKey((java.lang.Comparable) day24);
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener35);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0.0d + "'", number17.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-14400001L) + "'", long27 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-57600000L) + "'", long28 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "31-December-1969" + "'", str31.equals("31-December-1969"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        long long7 = day6.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 25568L + "'", long7 == 25568L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 'a');
        timePeriodValues1.setNotify(false);
        int int4 = timePeriodValues1.getMaxStartIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        java.lang.Class class6 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass10 = simpleTimePeriod9.getClass();
        long long11 = simpleTimePeriod9.getEndMillis();
        long long12 = simpleTimePeriod9.getStartMillis();
        java.util.Date date13 = simpleTimePeriod9.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj17 = null;
        boolean boolean18 = simpleTimePeriod16.equals(obj17);
        java.util.Date date19 = simpleTimePeriod16.getEnd();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        boolean boolean22 = day20.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate23 = day20.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass27 = simpleTimePeriod26.getClass();
        long long28 = simpleTimePeriod26.getEndMillis();
        long long29 = simpleTimePeriod26.getStartMillis();
        java.util.Date date30 = simpleTimePeriod26.getStart();
        boolean boolean31 = day20.equals((java.lang.Object) date30);
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date30, timeZone32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date13, timeZone32);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj38 = null;
        boolean boolean39 = simpleTimePeriod37.equals(obj38);
        java.util.Date date40 = simpleTimePeriod37.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod44.equals(obj45);
        java.util.Date date47 = simpleTimePeriod44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date47);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod(date40, date47);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod(date13, date40);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj55 = null;
        boolean boolean56 = simpleTimePeriod54.equals(obj55);
        java.util.Date date57 = simpleTimePeriod54.getEnd();
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date57);
        boolean boolean60 = day58.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate61 = day58.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod64 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass65 = simpleTimePeriod64.getClass();
        long long66 = simpleTimePeriod64.getEndMillis();
        long long67 = simpleTimePeriod64.getStartMillis();
        java.util.Date date68 = simpleTimePeriod64.getStart();
        boolean boolean69 = day58.equals((java.lang.Object) date68);
        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(date68, timeZone70);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date13, timeZone70);
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date5, timeZone70);
        java.util.Calendar calendar74 = null;
        try {
            long long75 = year73.getLastMillisecond(calendar74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 10L + "'", long28 == 10L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(serialDate61);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 10L + "'", long66 == 10L);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 0L + "'", long67 == 0L);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(timeZone70);
        org.junit.Assert.assertNull(regularTimePeriod72);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        long long9 = day6.getMiddleMillisecond();
        java.lang.String str10 = day6.toString();
        java.util.Date date11 = day6.getStart();
        long long12 = day6.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues14.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener17 = null;
        timePeriodValues14.removeChangeListener(seriesChangeListener17);
        java.lang.Comparable comparable19 = timePeriodValues14.getKey();
        int int20 = timePeriodValues14.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = timePeriodValues14.createCopy(12, 3);
        java.lang.Class<?> wildcardClass24 = timePeriodValues23.getClass();
        int int25 = day6.compareTo((java.lang.Object) timePeriodValues23);
        long long26 = day6.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-14400001L) + "'", long9 == (-14400001L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-1969" + "'", str10.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + ' ' + "'", comparable19.equals(' '));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues23);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 25568L + "'", long26 == 25568L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass9 = simpleTimePeriod8.getClass();
        long long10 = simpleTimePeriod8.getEndMillis();
        long long11 = simpleTimePeriod8.getStartMillis();
        boolean boolean12 = simpleTimePeriod2.equals((java.lang.Object) long11);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 28799999L);
        long long15 = simpleTimePeriod2.getStartMillis();
        java.util.Date date16 = simpleTimePeriod2.getStart();
        java.lang.Class class17 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass21 = simpleTimePeriod20.getClass();
        long long22 = simpleTimePeriod20.getEndMillis();
        long long23 = simpleTimePeriod20.getStartMillis();
        java.util.Date date24 = simpleTimePeriod20.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj28 = null;
        boolean boolean29 = simpleTimePeriod27.equals(obj28);
        java.util.Date date30 = simpleTimePeriod27.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        boolean boolean33 = day31.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate34 = day31.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass38 = simpleTimePeriod37.getClass();
        long long39 = simpleTimePeriod37.getEndMillis();
        long long40 = simpleTimePeriod37.getStartMillis();
        java.util.Date date41 = simpleTimePeriod37.getStart();
        boolean boolean42 = day31.equals((java.lang.Object) date41);
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date41, timeZone43);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date24, timeZone43);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj49 = null;
        boolean boolean50 = simpleTimePeriod48.equals(obj49);
        java.util.Date date51 = simpleTimePeriod48.getEnd();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date51);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod55 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj56 = null;
        boolean boolean57 = simpleTimePeriod55.equals(obj56);
        java.util.Date date58 = simpleTimePeriod55.getEnd();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date58);
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(date58);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod61 = new org.jfree.data.time.SimpleTimePeriod(date51, date58);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod62 = new org.jfree.data.time.SimpleTimePeriod(date24, date51);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod65 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj66 = null;
        boolean boolean67 = simpleTimePeriod65.equals(obj66);
        java.util.Date date68 = simpleTimePeriod65.getEnd();
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date68);
        boolean boolean71 = day69.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate72 = day69.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod75 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass76 = simpleTimePeriod75.getClass();
        long long77 = simpleTimePeriod75.getEndMillis();
        long long78 = simpleTimePeriod75.getStartMillis();
        java.util.Date date79 = simpleTimePeriod75.getStart();
        boolean boolean80 = day69.equals((java.lang.Object) date79);
        java.util.TimeZone timeZone81 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day(date79, timeZone81);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date24, timeZone81);
        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year(date16, timeZone81);
        long long85 = year84.getFirstMillisecond();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 10L + "'", long39 == 10L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertNotNull(wildcardClass76);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 10L + "'", long77 == 10L);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(timeZone81);
        org.junit.Assert.assertNull(regularTimePeriod83);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + (-31507200000L) + "'", long85 == (-31507200000L));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setKey((java.lang.Comparable) 'a');
        int int4 = timePeriodValues1.getItemCount();
        int int5 = timePeriodValues1.getMinEndIndex();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesChangeEvent[source=31-December-1969]");
        try {
            org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues1.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("1969");
        int int2 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year1.previous();
        long long5 = year1.getLastMillisecond();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 28799999L + "'", long5 == 28799999L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timePeriodValues1.isEmpty();
        timePeriodValues1.delete(0, (int) (short) -1);
        try {
            timePeriodValues1.update(4, (java.lang.Number) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "", "Value");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        int int7 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setRangeDescription("org.jfree.data.general.SeriesException: hi!");
        java.lang.String str10 = timePeriodValues3.getDescription();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getFirstMillisecond();
        long long10 = year7.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) (-14400001L));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj16 = null;
        boolean boolean17 = simpleTimePeriod15.equals(obj16);
        java.util.Date date18 = simpleTimePeriod15.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        boolean boolean21 = day19.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day23.previous();
        int int26 = year7.compareTo((java.lang.Object) day23);
        org.jfree.data.time.SerialDate serialDate27 = day23.getSerialDate();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-31507200000L) + "'", long9 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1969L + "'", long10 == 1969L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(serialDate27);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        long long9 = day6.getMiddleMillisecond();
        long long10 = day6.getSerialIndex();
        int int11 = day6.getDayOfMonth();
        long long12 = day6.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-14400001L) + "'", long9 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        int int3 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues5.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues5.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "", "Value");
        timePeriodValues13.fireSeriesChanged();
        boolean boolean15 = timePeriodValues5.equals((java.lang.Object) timePeriodValues13);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (double) 0);
        java.lang.Number number21 = timePeriodValue20.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj25 = null;
        boolean boolean26 = simpleTimePeriod24.equals(obj25);
        java.util.Date date27 = simpleTimePeriod24.getEnd();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        boolean boolean30 = day28.equals((java.lang.Object) '4');
        long long31 = day28.getMiddleMillisecond();
        long long32 = day28.getFirstMillisecond();
        boolean boolean33 = timePeriodValue20.equals((java.lang.Object) day28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day28.next();
        java.lang.String str35 = day28.toString();
        timePeriodValues5.setKey((java.lang.Comparable) day28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue41 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod39, (double) 0);
        java.lang.Number number42 = timePeriodValue41.getValue();
        java.lang.Number number43 = timePeriodValue41.getValue();
        org.jfree.data.time.TimePeriod timePeriod44 = timePeriodValue41.getPeriod();
        int int45 = day28.compareTo((java.lang.Object) timePeriodValue41);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day28, (java.lang.Number) (-57600000L));
        timePeriodValues1.setNotify(true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0.0d + "'", number21.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-14400001L) + "'", long31 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-57600000L) + "'", long32 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "31-December-1969" + "'", str35.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 0.0d + "'", number42.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 0.0d + "'", number43.equals(0.0d));
        org.junit.Assert.assertNotNull(timePeriod44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        long long16 = day13.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues18.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timePeriodValues18.removeChangeListener(seriesChangeListener21);
        boolean boolean23 = timePeriodValues18.isEmpty();
        boolean boolean24 = day13.equals((java.lang.Object) boolean23);
        java.util.Calendar calendar25 = null;
        try {
            long long26 = day13.getFirstMillisecond(calendar25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28799999L + "'", long16 == 28799999L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues9.setKey((java.lang.Comparable) 'a');
        int int12 = timePeriodValues9.getItemCount();
        int int13 = timePeriodValues9.getMinEndIndex();
        boolean boolean14 = timePeriodValues9.getNotify();
        int int15 = day6.compareTo((java.lang.Object) timePeriodValues9);
        long long16 = day6.getSerialIndex();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 25568L + "'", long16 == 25568L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues1.getClass();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 10, (long) ' ');
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (java.lang.Number) 12);
        java.lang.Object obj14 = timePeriodValue13.clone();
        timePeriodValue13.setValue((java.lang.Number) 1969L);
        java.lang.Object obj17 = timePeriodValue13.clone();
        boolean boolean18 = timePeriodValues1.equals((java.lang.Object) timePeriodValue13);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(obj14);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener6);
        java.lang.Class<?> wildcardClass8 = timePeriodValues1.getClass();
        try {
            timePeriodValues1.delete((int) (short) 1, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int2 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        try {
            java.lang.Number number6 = timePeriodValues1.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.delete(0, (int) (byte) -1);
        int int10 = timePeriodValues1.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str8 = seriesException7.toString();
        boolean boolean9 = timePeriodValues1.equals((java.lang.Object) seriesException7);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy(7, 0);
        int int13 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str8.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2, "1969", "");
        java.util.Date date9 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.Object obj6 = timePeriodValues1.clone();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date12);
        java.lang.String str15 = year14.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.next();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year14, (double) 9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year14.next();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969" + "'", str15.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timePeriodValues1.isEmpty();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener7);
        int int9 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        boolean boolean41 = day12.equals((java.lang.Object) 1L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod44.equals(obj45);
        java.util.Date date47 = simpleTimePeriod44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        boolean boolean50 = day48.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate51 = day48.getSerialDate();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
        boolean boolean53 = day12.equals((java.lang.Object) serialDate51);
        int int54 = day12.getYear();
        java.util.Date date55 = day12.getStart();
        long long56 = day12.getSerialIndex();
        java.util.Date date57 = day12.getStart();
        long long58 = day12.getSerialIndex();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1969 + "'", int54 == 1969);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 25568L + "'", long56 == 25568L);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 25568L + "'", long58 == 25568L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        boolean boolean41 = day12.equals((java.lang.Object) 1L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod44.equals(obj45);
        java.util.Date date47 = simpleTimePeriod44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        boolean boolean50 = day48.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate51 = day48.getSerialDate();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
        boolean boolean53 = day12.equals((java.lang.Object) serialDate51);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(serialDate51);
        org.jfree.data.time.TimePeriodValue timePeriodValue56 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day54, (double) 10.0f);
        java.lang.Number number57 = timePeriodValue56.getValue();
        java.lang.Object obj58 = timePeriodValue56.clone();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + number57 + "' != '" + 10.0d + "'", number57.equals(10.0d));
        org.junit.Assert.assertNotNull(obj58);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getLastMillisecond();
        java.lang.String str12 = year7.toString();
        java.util.Date date13 = year7.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
        java.util.Date date15 = day14.getStart();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod19, (double) 0);
        java.lang.Number number22 = timePeriodValue21.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj26 = null;
        boolean boolean27 = simpleTimePeriod25.equals(obj26);
        java.util.Date date28 = simpleTimePeriod25.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        boolean boolean31 = day29.equals((java.lang.Object) '4');
        long long32 = day29.getMiddleMillisecond();
        long long33 = day29.getFirstMillisecond();
        boolean boolean34 = timePeriodValue21.equals((java.lang.Object) day29);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj38 = null;
        boolean boolean39 = simpleTimePeriod37.equals(obj38);
        java.util.Date date40 = simpleTimePeriod37.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date40);
        int int43 = day29.compareTo((java.lang.Object) date40);
        org.jfree.data.time.TimePeriodValues timePeriodValues45 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues45.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = timePeriodValues45.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues52.setKey((java.lang.Comparable) 'a');
        boolean boolean55 = timePeriodValues45.equals((java.lang.Object) 'a');
        boolean boolean56 = day29.equals((java.lang.Object) timePeriodValues45);
        boolean boolean58 = day29.equals((java.lang.Object) 1L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod61 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj62 = null;
        boolean boolean63 = simpleTimePeriod61.equals(obj62);
        java.util.Date date64 = simpleTimePeriod61.getEnd();
        org.jfree.data.time.Day day65 = new org.jfree.data.time.Day(date64);
        boolean boolean67 = day65.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate68 = day65.getSerialDate();
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(serialDate68);
        boolean boolean70 = day29.equals((java.lang.Object) serialDate68);
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(serialDate68);
        boolean boolean72 = year16.equals((java.lang.Object) serialDate68);
        boolean boolean73 = year7.equals((java.lang.Object) year16);
        java.util.Date date74 = year7.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod75 = year7.previous();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969" + "'", str12.equals("1969"));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 0.0d + "'", number22.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-14400001L) + "'", long32 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-57600000L) + "'", long33 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues50);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(serialDate68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNotNull(regularTimePeriod75);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        boolean boolean19 = timePeriodValue4.equals((java.lang.Object) 25568L);
        timePeriodValue4.setValue((java.lang.Number) 25568L);
        java.lang.Object obj22 = timePeriodValue4.clone();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        boolean boolean41 = day12.equals((java.lang.Object) 1L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod44.equals(obj45);
        java.util.Date date47 = simpleTimePeriod44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        boolean boolean50 = day48.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate51 = day48.getSerialDate();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
        boolean boolean53 = day12.equals((java.lang.Object) serialDate51);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(serialDate51);
        org.jfree.data.time.TimePeriodValue timePeriodValue56 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day54, (double) 10.0f);
        long long57 = day54.getSerialIndex();
        java.lang.Class<?> wildcardClass58 = day54.getClass();
        int int59 = day54.getMonth();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 25568L + "'", long57 == 25568L);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 12 + "'", int59 == 12);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        long long9 = day6.getMiddleMillisecond();
        long long10 = day6.getMiddleMillisecond();
        long long11 = day6.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-14400001L) + "'", long9 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-14400001L) + "'", long10 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 25568L + "'", long11 == 25568L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int2 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.delete(8, (int) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener8);
        java.lang.String str10 = timePeriodValues1.getDescription();
        boolean boolean11 = timePeriodValues1.isEmpty();
        int int12 = timePeriodValues1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener13);
        try {
            org.jfree.data.time.TimePeriod timePeriod16 = timePeriodValues1.getTimePeriod((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int2 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.delete(8, (int) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener8);
        java.lang.String str10 = timePeriodValues1.getRangeDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = day13.previous();
        timePeriodValues1.setKey((java.lang.Comparable) regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Value" + "'", str10.equals("Value"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.next();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getSerialIndex();
        long long12 = year7.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year7.next();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1969L + "'", long11 == 1969L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1969L + "'", long12 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener6);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) -1, (-1), 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'month' argument must be in the range 1 to 12.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener16);
        int int18 = timePeriodValues1.getMaxEndIndex();
        boolean boolean19 = timePeriodValues1.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener20);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        int int16 = day13.getMonth();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj20 = null;
        boolean boolean21 = simpleTimePeriod19.equals(obj20);
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        boolean boolean25 = day23.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate26 = day23.getSerialDate();
        int int27 = day23.getYear();
        long long28 = day23.getFirstMillisecond();
        int int29 = day13.compareTo((java.lang.Object) long28);
        long long30 = day13.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues32.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        timePeriodValues32.removeChangeListener(seriesChangeListener35);
        int int37 = day13.compareTo((java.lang.Object) timePeriodValues32);
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = timePeriodValues32.createCopy(6, (int) (short) 100);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj44 = null;
        boolean boolean45 = simpleTimePeriod43.equals(obj44);
        java.util.Date date46 = simpleTimePeriod43.getEnd();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date46);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date46);
        java.lang.String str49 = year48.toString();
        long long50 = year48.getFirstMillisecond();
        long long51 = year48.getSerialIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue53 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year48, (double) (-14400001L));
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod56 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj57 = null;
        boolean boolean58 = simpleTimePeriod56.equals(obj57);
        java.util.Date date59 = simpleTimePeriod56.getEnd();
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date59);
        boolean boolean62 = day60.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate63 = day60.getSerialDate();
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(serialDate63);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = day64.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = day64.previous();
        int int67 = year48.compareTo((java.lang.Object) day64);
        timePeriodValues32.add((org.jfree.data.time.TimePeriod) year48, (java.lang.Number) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-57600000L) + "'", long28 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-14400001L) + "'", long30 == (-14400001L));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues40);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "1969" + "'", str49.equals("1969"));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-31507200000L) + "'", long50 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1969L + "'", long51 == 1969L);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(serialDate63);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        java.lang.String str7 = day6.toString();
        long long8 = day6.getFirstMillisecond();
        long long9 = day6.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-1969" + "'", str7.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-57600000L) + "'", long8 == (-57600000L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        long long10 = day6.getSerialIndex();
        long long11 = day6.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-14400001L) + "'", long11 == (-14400001L));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        int int10 = year7.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year7.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass3 = simpleTimePeriod2.getClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize(class4);
        java.lang.Class class6 = org.jfree.data.time.RegularTimePeriod.downsize(class4);
        java.lang.Class class7 = org.jfree.data.time.RegularTimePeriod.downsize(class6);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertNotNull(class6);
        org.junit.Assert.assertNotNull(class7);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass13 = simpleTimePeriod12.getClass();
        long long14 = simpleTimePeriod12.getEndMillis();
        long long15 = simpleTimePeriod12.getStartMillis();
        java.util.Date date16 = simpleTimePeriod12.getStart();
        boolean boolean17 = day6.equals((java.lang.Object) date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16, timeZone18);
        java.util.Date date20 = day19.getStart();
        long long21 = day19.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-57600000L) + "'", long21 == (-57600000L));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "", "Value");
        timePeriodValues9.fireSeriesChanged();
        boolean boolean11 = timePeriodValues1.equals((java.lang.Object) timePeriodValues9);
        int int12 = timePeriodValues9.getMaxMiddleIndex();
        int int13 = timePeriodValues9.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        long long10 = day6.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate11 = day6.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day6.next();
        long long13 = regularTimePeriod12.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod12);
        int int15 = timePeriodValues14.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 71999999L + "'", long13 == 71999999L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        int int3 = timePeriodValues1.getMaxStartIndex();
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        java.lang.String str5 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean8 = timePeriodValues7.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener9);
        timePeriodValues7.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj16 = null;
        boolean boolean17 = simpleTimePeriod15.equals(obj16);
        java.util.Date date18 = simpleTimePeriod15.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) 100);
        int int22 = day19.getMonth();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj26 = null;
        boolean boolean27 = simpleTimePeriod25.equals(obj26);
        java.util.Date date28 = simpleTimePeriod25.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        boolean boolean31 = day29.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate32 = day29.getSerialDate();
        int int33 = day29.getYear();
        long long34 = day29.getFirstMillisecond();
        int int35 = day19.compareTo((java.lang.Object) long34);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) (short) -1);
        java.util.Date date38 = day19.getEnd();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1969 + "'", int33 == 1969);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-57600000L) + "'", long34 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(date38);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        long long10 = day6.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day6.previous();
        long long12 = day6.getSerialIndex();
        java.lang.String str13 = day6.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 25568L + "'", long12 == 25568L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-1969" + "'", str13.equals("31-December-1969"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int6 = timePeriodValues5.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues5.addChangeListener(seriesChangeListener7);
        boolean boolean9 = timePeriodValues1.equals((java.lang.Object) seriesChangeListener7);
        java.lang.Comparable comparable10 = timePeriodValues1.getKey();
        int int11 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = timePeriodValues1.createCopy(0, (int) ' ');
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 'a' + "'", comparable10.equals('a'));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(timePeriodValues14);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        int int3 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues5.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues5.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "", "Value");
        timePeriodValues13.fireSeriesChanged();
        boolean boolean15 = timePeriodValues5.equals((java.lang.Object) timePeriodValues13);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (double) 0);
        java.lang.Number number21 = timePeriodValue20.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj25 = null;
        boolean boolean26 = simpleTimePeriod24.equals(obj25);
        java.util.Date date27 = simpleTimePeriod24.getEnd();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        boolean boolean30 = day28.equals((java.lang.Object) '4');
        long long31 = day28.getMiddleMillisecond();
        long long32 = day28.getFirstMillisecond();
        boolean boolean33 = timePeriodValue20.equals((java.lang.Object) day28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day28.next();
        java.lang.String str35 = day28.toString();
        timePeriodValues5.setKey((java.lang.Comparable) day28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue41 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod39, (double) 0);
        java.lang.Number number42 = timePeriodValue41.getValue();
        java.lang.Number number43 = timePeriodValue41.getValue();
        org.jfree.data.time.TimePeriod timePeriod44 = timePeriodValue41.getPeriod();
        int int45 = day28.compareTo((java.lang.Object) timePeriodValue41);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day28, (java.lang.Number) (-57600000L));
        java.util.Calendar calendar48 = null;
        try {
            long long49 = day28.getMiddleMillisecond(calendar48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0.0d + "'", number21.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-14400001L) + "'", long31 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-57600000L) + "'", long32 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "31-December-1969" + "'", str35.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 0.0d + "'", number42.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 0.0d + "'", number43.equals(0.0d));
        org.junit.Assert.assertNotNull(timePeriod44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        int int16 = day13.getMonth();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj20 = null;
        boolean boolean21 = simpleTimePeriod19.equals(obj20);
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        boolean boolean25 = day23.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate26 = day23.getSerialDate();
        int int27 = day23.getYear();
        long long28 = day23.getFirstMillisecond();
        int int29 = day13.compareTo((java.lang.Object) long28);
        long long30 = day13.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues32.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        timePeriodValues32.removeChangeListener(seriesChangeListener35);
        int int37 = day13.compareTo((java.lang.Object) timePeriodValues32);
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = timePeriodValues32.createCopy(6, (int) (short) 100);
        timePeriodValues32.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-57600000L) + "'", long28 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-14400001L) + "'", long30 == (-14400001L));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues40);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod9, (java.lang.Number) 12);
        java.lang.Object obj12 = null;
        boolean boolean13 = timePeriodValue11.equals(obj12);
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues15.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timePeriodValues15.removePropertyChangeListener(propertyChangeListener18);
        org.jfree.data.general.SeriesException seriesException21 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str22 = seriesException21.toString();
        boolean boolean23 = timePeriodValues15.equals((java.lang.Object) seriesException21);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = timePeriodValues15.createCopy(7, 0);
        timePeriodValues15.setDomainDescription("");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue33 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod31, (double) 0);
        java.lang.Number number34 = timePeriodValue33.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj38 = null;
        boolean boolean39 = simpleTimePeriod37.equals(obj38);
        java.util.Date date40 = simpleTimePeriod37.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        boolean boolean43 = day41.equals((java.lang.Object) '4');
        long long44 = day41.getMiddleMillisecond();
        long long45 = day41.getFirstMillisecond();
        boolean boolean46 = timePeriodValue33.equals((java.lang.Object) day41);
        java.lang.String str47 = day41.toString();
        long long48 = day41.getFirstMillisecond();
        timePeriodValues15.add((org.jfree.data.time.TimePeriod) day41, (double) 'a');
        boolean boolean51 = timePeriodValue11.equals((java.lang.Object) timePeriodValues15);
        try {
            timePeriodValues15.delete(8, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str22.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timePeriodValues26);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 0.0d + "'", number34.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-14400001L) + "'", long44 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-57600000L) + "'", long45 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "31-December-1969" + "'", str47.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-57600000L) + "'", long48 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        long long9 = day6.getMiddleMillisecond();
        java.lang.String str10 = day6.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day6.next();
        java.lang.String str12 = day6.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-14400001L) + "'", long9 == (-14400001L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-1969" + "'", str10.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-1969" + "'", str12.equals("31-December-1969"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        long long16 = day13.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day13);
        timePeriodValues17.setDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timePeriodValues17.removeChangeListener(seriesChangeListener20);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28799999L + "'", long16 == 28799999L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass3 = simpleTimePeriod2.getClass();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        long long6 = simpleTimePeriod2.getEndMillis();
        java.util.Date date7 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str4 = seriesException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        seriesException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.String str9 = seriesException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str4.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str9.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.data.time.SerialDate serialDate8 = day6.getSerialDate();
        long long9 = day6.getLastMillisecond();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        long long16 = day13.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues18.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timePeriodValues18.removeChangeListener(seriesChangeListener21);
        boolean boolean23 = timePeriodValues18.isEmpty();
        boolean boolean24 = day13.equals((java.lang.Object) boolean23);
        int int25 = day13.getDayOfMonth();
        org.jfree.data.time.SerialDate serialDate26 = day13.getSerialDate();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28799999L + "'", long16 == 28799999L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
        org.junit.Assert.assertNotNull(serialDate26);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getLastMillisecond();
        long long12 = year7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year7.next();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-31507200000L) + "'", long12 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        long long9 = day6.getMiddleMillisecond();
        java.lang.String str10 = day6.toString();
        java.util.Date date11 = day6.getStart();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-14400001L) + "'", long9 == (-14400001L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-1969" + "'", str10.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[1-January-1970,2.8799999E7]");
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getSerialIndex();
        long long12 = year7.getLastMillisecond();
        long long13 = year7.getLastMillisecond();
        java.util.Date date14 = year7.getStart();
        java.lang.Class<?> wildcardClass15 = date14.getClass();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1969L + "'", long11 == 1969L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28799999L + "'", long13 == 28799999L);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        int int3 = timePeriodValues1.getMaxStartIndex();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj12 = null;
        boolean boolean13 = simpleTimePeriod11.equals(obj12);
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        boolean boolean17 = day15.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate18 = day15.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass22 = simpleTimePeriod21.getClass();
        long long23 = simpleTimePeriod21.getEndMillis();
        long long24 = simpleTimePeriod21.getStartMillis();
        java.util.Date date25 = simpleTimePeriod21.getStart();
        boolean boolean26 = day15.equals((java.lang.Object) date25);
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date25, timeZone27);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day28, (java.lang.Number) 25568L);
        java.lang.Class<?> wildcardClass31 = timePeriodValues1.getClass();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(wildcardClass31);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "", "Value");
        timePeriodValues9.fireSeriesChanged();
        boolean boolean11 = timePeriodValues1.equals((java.lang.Object) timePeriodValues9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (double) 0);
        java.lang.Number number17 = timePeriodValue16.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        boolean boolean26 = day24.equals((java.lang.Object) '4');
        long long27 = day24.getMiddleMillisecond();
        long long28 = day24.getFirstMillisecond();
        boolean boolean29 = timePeriodValue16.equals((java.lang.Object) day24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day24.next();
        java.lang.String str31 = day24.toString();
        timePeriodValues1.setKey((java.lang.Comparable) day24);
        timePeriodValues1.setNotify(true);
        timePeriodValues1.fireSeriesChanged();
        int int36 = timePeriodValues1.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0.0d + "'", number17.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-14400001L) + "'", long27 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-57600000L) + "'", long28 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "31-December-1969" + "'", str31.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Time");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3, "Value", "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=a]");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (double) 0);
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date3, date14);
        java.util.Date date17 = simpleTimePeriod16.getEnd();
        long long18 = simpleTimePeriod16.getStartMillis();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
        java.lang.String str2 = seriesException1.toString();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("Value");
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=a]");
        seriesException7.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        seriesException5.addSuppressed((java.lang.Throwable) seriesException7);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException7);
        org.jfree.data.general.SeriesException seriesException14 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj18 = null;
        boolean boolean19 = simpleTimePeriod17.equals(obj18);
        java.util.Date date20 = simpleTimePeriod17.getEnd();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        boolean boolean23 = day21.equals((java.lang.Object) '4');
        long long24 = day21.getMiddleMillisecond();
        long long25 = day21.getSerialIndex();
        java.util.Date date26 = day21.getStart();
        org.jfree.data.general.SeriesException seriesException28 = new org.jfree.data.general.SeriesException("");
        int int29 = day21.compareTo((java.lang.Object) seriesException28);
        java.lang.String str30 = seriesException28.toString();
        java.lang.String str31 = seriesException28.toString();
        seriesException14.addSuppressed((java.lang.Throwable) seriesException28);
        seriesException7.addSuppressed((java.lang.Throwable) seriesException14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: Value" + "'", str2.equals("org.jfree.data.general.SeriesException: Value"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-14400001L) + "'", long24 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 25568L + "'", long25 == 25568L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str30.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str31.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-15739200001L), "org.jfree.data.general.SeriesException: hi!", "TimePeriodValue[31-December-1969,100]");
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj43 = null;
        boolean boolean44 = simpleTimePeriod42.equals(obj43);
        java.util.Date date45 = simpleTimePeriod42.getEnd();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        boolean boolean48 = day46.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate49 = day46.getSerialDate();
        long long50 = day46.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate51 = day46.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = day46.next();
        timePeriodValues28.add((org.jfree.data.time.TimePeriod) day46, (java.lang.Number) 71999999L);
        boolean boolean55 = timePeriodValues28.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener56 = null;
        timePeriodValues28.removeChangeListener(seriesChangeListener56);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 25568L + "'", long50 == 25568L);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-15739200001L), (long) 1969);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-15739200001L), (long) 8);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj6 = null;
        boolean boolean7 = simpleTimePeriod5.equals(obj6);
        java.util.Date date8 = simpleTimePeriod5.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date8);
        java.lang.String str11 = year10.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod12, (java.lang.Number) 12);
        long long15 = regularTimePeriod12.getMiddleMillisecond();
        int int16 = simpleTimePeriod2.compareTo((java.lang.Object) regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969" + "'", str11.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-47318400001L) + "'", long15 == (-47318400001L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
        boolean boolean9 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues9.setKey((java.lang.Comparable) 'a');
        int int12 = timePeriodValues9.getItemCount();
        int int13 = timePeriodValues9.getMinEndIndex();
        boolean boolean14 = timePeriodValues9.getNotify();
        int int15 = day6.compareTo((java.lang.Object) timePeriodValues9);
        java.util.Calendar calendar16 = null;
        try {
            long long17 = day6.getLastMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues9.setKey((java.lang.Comparable) 'a');
        int int12 = timePeriodValues9.getItemCount();
        int int13 = timePeriodValues9.getMinEndIndex();
        boolean boolean14 = timePeriodValues9.getNotify();
        int int15 = day6.compareTo((java.lang.Object) timePeriodValues9);
        java.lang.String str16 = timePeriodValues9.getRangeDescription();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Value" + "'", str16.equals("Value"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass13 = simpleTimePeriod12.getClass();
        long long14 = simpleTimePeriod12.getEndMillis();
        long long15 = simpleTimePeriod12.getStartMillis();
        java.util.Date date16 = simpleTimePeriod12.getStart();
        boolean boolean17 = day6.equals((java.lang.Object) date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16, timeZone18);
        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate20);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(serialDate20);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass9 = simpleTimePeriod8.getClass();
        long long10 = simpleTimePeriod8.getEndMillis();
        long long11 = simpleTimePeriod8.getStartMillis();
        java.util.Date date12 = simpleTimePeriod8.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj16 = null;
        boolean boolean17 = simpleTimePeriod15.equals(obj16);
        java.util.Date date18 = simpleTimePeriod15.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        boolean boolean21 = day19.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass26 = simpleTimePeriod25.getClass();
        long long27 = simpleTimePeriod25.getEndMillis();
        long long28 = simpleTimePeriod25.getStartMillis();
        java.util.Date date29 = simpleTimePeriod25.getStart();
        boolean boolean30 = day19.equals((java.lang.Object) date29);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date29, timeZone31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date12, timeZone31);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass37 = simpleTimePeriod36.getClass();
        long long38 = simpleTimePeriod36.getEndMillis();
        long long39 = simpleTimePeriod36.getStartMillis();
        java.util.Date date40 = simpleTimePeriod36.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj44 = null;
        boolean boolean45 = simpleTimePeriod43.equals(obj44);
        java.util.Date date46 = simpleTimePeriod43.getEnd();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date46);
        boolean boolean49 = day47.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate50 = day47.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass54 = simpleTimePeriod53.getClass();
        long long55 = simpleTimePeriod53.getEndMillis();
        long long56 = simpleTimePeriod53.getStartMillis();
        java.util.Date date57 = simpleTimePeriod53.getStart();
        boolean boolean58 = day47.equals((java.lang.Object) date57);
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date57, timeZone59);
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date40, timeZone59);
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date12, timeZone59);
        java.util.TimeZone timeZone63 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date12, timeZone63);
        int int65 = simpleTimePeriod2.compareTo((java.lang.Object) year64);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 10L + "'", long38 == 10L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 10L + "'", long55 == 10L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNotNull(timeZone63);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setKey((java.lang.Comparable) 'a');
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        int int5 = timePeriodValues1.getMinMiddleIndex();
        int int6 = timePeriodValues1.getMinEndIndex();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue9 = timePeriodValues1.getDataItem(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues8.setKey((java.lang.Comparable) 'a');
        boolean boolean11 = timePeriodValues1.equals((java.lang.Object) 'a');
        int int12 = timePeriodValues1.getMinMiddleIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj16 = null;
        boolean boolean17 = simpleTimePeriod15.equals(obj16);
        java.util.Date date18 = simpleTimePeriod15.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        boolean boolean21 = day19.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
        long long23 = day19.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate24 = day19.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        long long26 = regularTimePeriod25.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod25, (double) 28799999L);
        timePeriodValues1.add(timePeriodValue28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj33 = null;
        boolean boolean34 = simpleTimePeriod32.equals(obj33);
        java.util.Date date35 = simpleTimePeriod32.getEnd();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date35);
        java.lang.String str38 = year37.toString();
        long long39 = year37.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year37.next();
        long long41 = year37.getLastMillisecond();
        java.lang.String str42 = year37.toString();
        java.util.Date date43 = year37.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year37.next();
        boolean boolean45 = timePeriodValues1.equals((java.lang.Object) year37);
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 25568L + "'", long23 == 25568L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 71999999L + "'", long26 == 71999999L);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "1969" + "'", str38.equals("1969"));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 28799999L + "'", long39 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 28799999L + "'", long41 == 28799999L);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "1969" + "'", str42.equals("1969"));
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getLastMillisecond();
        long long12 = year7.getFirstMillisecond();
        long long13 = year7.getSerialIndex();
        java.lang.Object obj14 = null;
        boolean boolean15 = year7.equals(obj14);
        java.util.Date date16 = year7.getEnd();
        long long17 = year7.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-31507200000L) + "'", long12 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1969L + "'", long13 == 1969L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-31507200000L) + "'", long17 == (-31507200000L));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        int int16 = day13.getMonth();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj20 = null;
        boolean boolean21 = simpleTimePeriod19.equals(obj20);
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        boolean boolean25 = day23.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate26 = day23.getSerialDate();
        int int27 = day23.getYear();
        long long28 = day23.getFirstMillisecond();
        int int29 = day13.compareTo((java.lang.Object) long28);
        java.util.Date date30 = day13.getEnd();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-57600000L) + "'", long28 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(date30);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValue4.getPeriod();
        timePeriodValue4.setValue((java.lang.Number) 2);
        java.lang.Object obj9 = timePeriodValue4.clone();
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue4.getPeriod();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertNotNull(timePeriod6);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(timePeriod10);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        long long16 = day13.getLastMillisecond();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj20 = null;
        boolean boolean21 = simpleTimePeriod19.equals(obj20);
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date22);
        java.lang.String str25 = year24.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year24.next();
        java.lang.Class<?> wildcardClass27 = regularTimePeriod26.getClass();
        java.lang.Class class28 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass27);
        boolean boolean29 = day13.equals((java.lang.Object) wildcardClass27);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod32, (double) 0);
        java.util.Date date35 = simpleTimePeriod32.getEnd();
        long long36 = simpleTimePeriod32.getStartMillis();
        java.util.Date date37 = simpleTimePeriod32.getEnd();
        java.util.Date date38 = simpleTimePeriod32.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj42 = null;
        boolean boolean43 = simpleTimePeriod41.equals(obj42);
        java.util.Date date44 = simpleTimePeriod41.getEnd();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj49 = null;
        boolean boolean50 = simpleTimePeriod48.equals(obj49);
        java.util.Date date51 = simpleTimePeriod48.getEnd();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date51);
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date51);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod(date44, date51);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod57 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass58 = simpleTimePeriod57.getClass();
        long long59 = simpleTimePeriod57.getEndMillis();
        long long60 = simpleTimePeriod57.getStartMillis();
        java.util.Date date61 = simpleTimePeriod57.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod64 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj65 = null;
        boolean boolean66 = simpleTimePeriod64.equals(obj65);
        java.util.Date date67 = simpleTimePeriod64.getEnd();
        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day(date67);
        boolean boolean70 = day68.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate71 = day68.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod74 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass75 = simpleTimePeriod74.getClass();
        long long76 = simpleTimePeriod74.getEndMillis();
        long long77 = simpleTimePeriod74.getStartMillis();
        java.util.Date date78 = simpleTimePeriod74.getStart();
        boolean boolean79 = day68.equals((java.lang.Object) date78);
        java.util.TimeZone timeZone80 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day(date78, timeZone80);
        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year(date61, timeZone80);
        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day(date44, timeZone80);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date38, timeZone80);
        org.jfree.data.time.Year year85 = new org.jfree.data.time.Year(date38);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28799999L + "'", long16 == 28799999L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1969" + "'", str25.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(class28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-1L) + "'", long36 == (-1L));
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 10L + "'", long59 == 10L);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(serialDate71);
        org.junit.Assert.assertNotNull(wildcardClass75);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 10L + "'", long76 == 10L);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 0L + "'", long77 == 0L);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(timeZone80);
        org.junit.Assert.assertNotNull(regularTimePeriod84);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        long long3 = simpleTimePeriod2.getEndMillis();
        java.util.Date date4 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        long long6 = day5.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28799999L + "'", long6 == 28799999L);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
        int int17 = day13.getYear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean10 = timePeriodValues9.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues9.addChangeListener(seriesChangeListener11);
        timePeriodValues9.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj18 = null;
        boolean boolean19 = simpleTimePeriod17.equals(obj18);
        java.util.Date date20 = simpleTimePeriod17.getEnd();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        timePeriodValues9.add((org.jfree.data.time.TimePeriod) day21, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day21.next();
        java.util.Date date25 = regularTimePeriod24.getEnd();
        int int26 = year7.compareTo((java.lang.Object) regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(10L, (long) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        int int16 = day13.getMonth();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj20 = null;
        boolean boolean21 = simpleTimePeriod19.equals(obj20);
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        boolean boolean25 = day23.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate26 = day23.getSerialDate();
        int int27 = day23.getYear();
        long long28 = day23.getFirstMillisecond();
        int int29 = day13.compareTo((java.lang.Object) long28);
        long long30 = day13.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues32.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        timePeriodValues32.removeChangeListener(seriesChangeListener35);
        int int37 = day13.compareTo((java.lang.Object) timePeriodValues32);
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = timePeriodValues32.createCopy(6, (int) (short) 100);
        timePeriodValues32.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=31-December-1969]");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-57600000L) + "'", long28 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-14400001L) + "'", long30 == (-14400001L));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues40);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "", "Value");
        java.lang.Object obj4 = timePeriodValues3.clone();
        boolean boolean5 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        boolean boolean15 = day13.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass20 = simpleTimePeriod19.getClass();
        long long21 = simpleTimePeriod19.getEndMillis();
        long long22 = simpleTimePeriod19.getStartMillis();
        java.util.Date date23 = simpleTimePeriod19.getStart();
        boolean boolean24 = day13.equals((java.lang.Object) date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date5, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues30.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timePeriodValues30.removePropertyChangeListener(propertyChangeListener33);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        timePeriodValues30.removeChangeListener(seriesChangeListener35);
        java.lang.Class<?> wildcardClass37 = timePeriodValues30.getClass();
        boolean boolean38 = year27.equals((java.lang.Object) wildcardClass37);
        int int39 = year27.getYear();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1969 + "'", int39 == 1969);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass3 = simpleTimePeriod2.getClass();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        boolean boolean15 = day13.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass20 = simpleTimePeriod19.getClass();
        long long21 = simpleTimePeriod19.getEndMillis();
        long long22 = simpleTimePeriod19.getStartMillis();
        java.util.Date date23 = simpleTimePeriod19.getStart();
        boolean boolean24 = day13.equals((java.lang.Object) date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date6, timeZone25);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass31 = simpleTimePeriod30.getClass();
        long long32 = simpleTimePeriod30.getEndMillis();
        long long33 = simpleTimePeriod30.getStartMillis();
        java.util.Date date34 = simpleTimePeriod30.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj38 = null;
        boolean boolean39 = simpleTimePeriod37.equals(obj38);
        java.util.Date date40 = simpleTimePeriod37.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        boolean boolean43 = day41.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate44 = day41.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass48 = simpleTimePeriod47.getClass();
        long long49 = simpleTimePeriod47.getEndMillis();
        long long50 = simpleTimePeriod47.getStartMillis();
        java.util.Date date51 = simpleTimePeriod47.getStart();
        boolean boolean52 = day41.equals((java.lang.Object) date51);
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date51, timeZone53);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date34, timeZone53);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date6, timeZone53);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date6);
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date6);
        java.lang.Class<?> wildcardClass59 = date6.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 10L + "'", long49 == 10L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNotNull(wildcardClass59);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        boolean boolean15 = day13.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass20 = simpleTimePeriod19.getClass();
        long long21 = simpleTimePeriod19.getEndMillis();
        long long22 = simpleTimePeriod19.getStartMillis();
        java.util.Date date23 = simpleTimePeriod19.getStart();
        boolean boolean24 = day13.equals((java.lang.Object) date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date5, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
        java.util.Calendar calendar29 = null;
        try {
            long long30 = year27.getLastMillisecond(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        int int3 = timePeriodValues1.getMaxStartIndex();
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        java.lang.String str5 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean8 = timePeriodValues7.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener9);
        timePeriodValues7.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj16 = null;
        boolean boolean17 = simpleTimePeriod15.equals(obj16);
        java.util.Date date18 = simpleTimePeriod15.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) 100);
        int int22 = day19.getMonth();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj26 = null;
        boolean boolean27 = simpleTimePeriod25.equals(obj26);
        java.util.Date date28 = simpleTimePeriod25.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        boolean boolean31 = day29.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate32 = day29.getSerialDate();
        int int33 = day29.getYear();
        long long34 = day29.getFirstMillisecond();
        int int35 = day19.compareTo((java.lang.Object) long34);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) (short) -1);
        org.jfree.data.time.TimePeriodValue timePeriodValue39 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day19, (double) 10L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1969 + "'", int33 == 1969);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-57600000L) + "'", long34 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass5 = simpleTimePeriod4.getClass();
        long long6 = simpleTimePeriod4.getEndMillis();
        long long7 = simpleTimePeriod4.getStartMillis();
        long long8 = simpleTimePeriod4.getEndMillis();
        java.lang.Class<?> wildcardClass9 = simpleTimePeriod4.getClass();
        int int10 = year0.compareTo((java.lang.Object) simpleTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass9 = simpleTimePeriod8.getClass();
        long long10 = simpleTimePeriod8.getEndMillis();
        long long11 = simpleTimePeriod8.getStartMillis();
        boolean boolean12 = simpleTimePeriod2.equals((java.lang.Object) long11);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 28799999L);
        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValue14.getPeriod();
        java.lang.Object obj16 = timePeriodValue14.clone();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(timePeriod15);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getLastMillisecond();
        long long12 = year7.getFirstMillisecond();
        java.lang.String str13 = year7.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year7.previous();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-31507200000L) + "'", long12 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969" + "'", str13.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3, "Value", "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=a]");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (double) 0);
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date3, date14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date3);
        long long18 = year17.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.next();
        long long20 = year17.getSerialIndex();
        java.util.Calendar calendar21 = null;
        try {
            long long22 = year17.getFirstMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-31507200000L) + "'", long18 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1969L + "'", long20 == 1969L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getLastMillisecond();
        long long12 = year7.getFirstMillisecond();
        long long13 = year7.getFirstMillisecond();
        int int14 = year7.getYear();
        long long15 = year7.getFirstMillisecond();
        int int16 = year7.getYear();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int19 = timePeriodValues18.getMinEndIndex();
        int int20 = timePeriodValues18.getMaxStartIndex();
        java.lang.String str21 = timePeriodValues18.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timePeriodValues18.addChangeListener(seriesChangeListener22);
        int int24 = year7.compareTo((java.lang.Object) timePeriodValues18);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-31507200000L) + "'", long12 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-31507200000L) + "'", long13 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-31507200000L) + "'", long15 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1969 + "'", int16 == 1969);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Time" + "'", str21.equals("Time"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        int int16 = day13.getMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean19 = timePeriodValues18.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timePeriodValues18.addChangeListener(seriesChangeListener20);
        timePeriodValues18.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj27 = null;
        boolean boolean28 = simpleTimePeriod26.equals(obj27);
        java.util.Date date29 = simpleTimePeriod26.getEnd();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
        timePeriodValues18.add((org.jfree.data.time.TimePeriod) day30, (java.lang.Number) 100);
        int int33 = day30.getMonth();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.util.Date date37 = simpleTimePeriod36.getStart();
        java.util.TimeZone timeZone38 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date37, timeZone38);
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year39);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 11);
        long long44 = simpleTimePeriod43.getStartMillis();
        timePeriodValues40.add((org.jfree.data.time.TimePeriod) simpleTimePeriod43, (double) (short) 100);
        int int47 = day30.compareTo((java.lang.Object) (short) 100);
        boolean boolean48 = day13.equals((java.lang.Object) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 12 + "'", int33 == 12);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(timeZone38);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        timePeriodValues1.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj13 = null;
        boolean boolean14 = simpleTimePeriod12.equals(obj13);
        java.util.Date date15 = simpleTimePeriod12.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        boolean boolean18 = day16.equals((java.lang.Object) '4');
        timePeriodValues1.setKey((java.lang.Comparable) '4');
        java.lang.Comparable comparable20 = timePeriodValues1.getKey();
        java.lang.Comparable comparable21 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + '4' + "'", comparable20.equals('4'));
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + '4' + "'", comparable21.equals('4'));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        boolean boolean15 = day13.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass20 = simpleTimePeriod19.getClass();
        long long21 = simpleTimePeriod19.getEndMillis();
        long long22 = simpleTimePeriod19.getStartMillis();
        java.util.Date date23 = simpleTimePeriod19.getStart();
        boolean boolean24 = day13.equals((java.lang.Object) date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date5, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year27);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        int int7 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.delete((int) ' ', (int) (short) 1);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + ' ' + "'", comparable6.equals(' '));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Object obj5 = timePeriodValue4.clone();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) long16);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues19.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues19.addPropertyChangeListener(propertyChangeListener22);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timePeriodValues19.removeChangeListener(seriesChangeListener24);
        boolean boolean26 = timePeriodValue4.equals((java.lang.Object) seriesChangeListener24);
        timePeriodValue4.setValue((java.lang.Number) 28799999L);
        java.lang.Object obj29 = timePeriodValue4.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent30 = new org.jfree.data.general.SeriesChangeEvent(obj29);
        java.lang.String str31 = seriesChangeEvent30.toString();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date12);
        java.lang.String str15 = year14.toString();
        long long16 = year14.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year14.next();
        long long18 = year14.getSerialIndex();
        long long19 = year14.getLastMillisecond();
        java.util.Date date20 = year14.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date6, date20);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod24, (double) 0);
        java.util.Date date27 = simpleTimePeriod24.getEnd();
        java.lang.Class class28 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass32 = simpleTimePeriod31.getClass();
        long long33 = simpleTimePeriod31.getEndMillis();
        long long34 = simpleTimePeriod31.getStartMillis();
        java.util.Date date35 = simpleTimePeriod31.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj39 = null;
        boolean boolean40 = simpleTimePeriod38.equals(obj39);
        java.util.Date date41 = simpleTimePeriod38.getEnd();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
        boolean boolean44 = day42.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate45 = day42.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass49 = simpleTimePeriod48.getClass();
        long long50 = simpleTimePeriod48.getEndMillis();
        long long51 = simpleTimePeriod48.getStartMillis();
        java.util.Date date52 = simpleTimePeriod48.getStart();
        boolean boolean53 = day42.equals((java.lang.Object) date52);
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date52, timeZone54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date35, timeZone54);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod59 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj60 = null;
        boolean boolean61 = simpleTimePeriod59.equals(obj60);
        java.util.Date date62 = simpleTimePeriod59.getEnd();
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date62);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod66 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj67 = null;
        boolean boolean68 = simpleTimePeriod66.equals(obj67);
        java.util.Date date69 = simpleTimePeriod66.getEnd();
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date69);
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(date69);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod72 = new org.jfree.data.time.SimpleTimePeriod(date62, date69);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod73 = new org.jfree.data.time.SimpleTimePeriod(date35, date62);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod76 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj77 = null;
        boolean boolean78 = simpleTimePeriod76.equals(obj77);
        java.util.Date date79 = simpleTimePeriod76.getEnd();
        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day(date79);
        boolean boolean82 = day80.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate83 = day80.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod86 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass87 = simpleTimePeriod86.getClass();
        long long88 = simpleTimePeriod86.getEndMillis();
        long long89 = simpleTimePeriod86.getStartMillis();
        java.util.Date date90 = simpleTimePeriod86.getStart();
        boolean boolean91 = day80.equals((java.lang.Object) date90);
        java.util.TimeZone timeZone92 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day93 = new org.jfree.data.time.Day(date90, timeZone92);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date35, timeZone92);
        org.jfree.data.time.Year year95 = new org.jfree.data.time.Year(date27, timeZone92);
        org.jfree.data.time.Day day96 = new org.jfree.data.time.Day(date20, timeZone92);
        org.jfree.data.time.Year year97 = new org.jfree.data.time.Year(date20);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969" + "'", str15.equals("1969"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28799999L + "'", long16 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1969L + "'", long18 == 1969L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28799999L + "'", long19 == 28799999L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 10L + "'", long50 == 10L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(wildcardClass87);
        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 10L + "'", long88 == 10L);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 0L + "'", long89 == 0L);
        org.junit.Assert.assertNotNull(date90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(timeZone92);
        org.junit.Assert.assertNull(regularTimePeriod94);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        boolean boolean7 = timePeriodValues1.isEmpty();
        java.lang.String str8 = timePeriodValues1.getDescription();
        int int9 = timePeriodValues1.getMaxMiddleIndex();
        try {
            java.lang.Number number11 = timePeriodValues1.getValue(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + ' ' + "'", comparable6.equals(' '));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
        org.jfree.data.time.SerialDate serialDate9 = day8.getSerialDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate9);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str4 = seriesException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str6 = seriesException3.toString();
        java.lang.Throwable[] throwableArray7 = seriesException3.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("");
        seriesException3.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
        java.lang.String str11 = seriesException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str4.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str6.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str11.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setKey((java.lang.Comparable) 'a');
        int int4 = timePeriodValues1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener5);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue8 = timePeriodValues1.getDataItem((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.previous();
        long long11 = year7.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        java.lang.String str7 = timePeriodValues1.getDescription();
        boolean boolean8 = timePeriodValues1.isEmpty();
        timePeriodValues1.setKey((java.lang.Comparable) 5);
        try {
            timePeriodValues1.update(9, (java.lang.Number) 15796799999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean42 = timePeriodValues41.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener43 = null;
        timePeriodValues41.addChangeListener(seriesChangeListener43);
        timePeriodValues41.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj50 = null;
        boolean boolean51 = simpleTimePeriod49.equals(obj50);
        java.util.Date date52 = simpleTimePeriod49.getEnd();
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date52);
        timePeriodValues41.add((org.jfree.data.time.TimePeriod) day53, (java.lang.Number) 100);
        int int56 = day53.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue58 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day53, (java.lang.Number) (byte) 100);
        org.jfree.data.time.TimePeriod timePeriod59 = timePeriodValue58.getPeriod();
        java.lang.String str60 = timePeriodValue58.toString();
        boolean boolean61 = timePeriodValues28.equals((java.lang.Object) timePeriodValue58);
        timePeriodValues28.setRangeDescription("TimePeriodValue[1-January-1970,2.8799999E7]");
        boolean boolean64 = timePeriodValues28.getNotify();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 12 + "'", int56 == 12);
        org.junit.Assert.assertNotNull(timePeriod59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "TimePeriodValue[31-December-1969,100]" + "'", str60.equals("TimePeriodValue[31-December-1969,100]"));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(12, 4);
        timePeriodValues6.setNotify(true);
        org.junit.Assert.assertNotNull(timePeriodValues6);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        boolean boolean41 = day12.equals((java.lang.Object) 1L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod44.equals(obj45);
        java.util.Date date47 = simpleTimePeriod44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        boolean boolean50 = day48.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate51 = day48.getSerialDate();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
        boolean boolean53 = day12.equals((java.lang.Object) serialDate51);
        java.util.Date date54 = day12.getStart();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date54);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=a]");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        java.lang.Throwable throwable3 = null;
        try {
            timePeriodFormatException1.addSuppressed(throwable3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate9);
        int int12 = day11.getDayOfMonth();
        long long13 = day11.getFirstMillisecond();
        int int14 = day11.getMonth();
        int int15 = day11.getDayOfMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues17.setKey((java.lang.Comparable) 'a');
        java.lang.String str20 = timePeriodValues17.getDomainDescription();
        int int21 = timePeriodValues17.getMinMiddleIndex();
        java.lang.Comparable comparable22 = timePeriodValues17.getKey();
        int int23 = timePeriodValues17.getMaxMiddleIndex();
        int int24 = day11.compareTo((java.lang.Object) timePeriodValues17);
        int int25 = day11.getMonth();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-57600000L) + "'", long13 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 31 + "'", int15 == 31);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + 'a' + "'", comparable22.equals('a'));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 12 + "'", int25 == 12);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean3 = timePeriodValues2.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues2.addChangeListener(seriesChangeListener4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues2.addChangeListener(seriesChangeListener6);
        int int8 = year0.compareTo((java.lang.Object) timePeriodValues2);
        int int10 = year0.compareTo((java.lang.Object) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year0.previous();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year0.getMiddleMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        long long10 = day6.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day6.previous();
        long long12 = regularTimePeriod11.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-100800001L) + "'", long12 == (-100800001L));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3, "Value", "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=a]");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (double) 0);
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date3, date14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues19.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues19.addPropertyChangeListener(propertyChangeListener22);
        java.lang.Object obj24 = timePeriodValues19.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = timePeriodValues19.createCopy(6, 1);
        boolean boolean28 = year17.equals((java.lang.Object) timePeriodValues27);
        java.lang.Object obj29 = null;
        int int30 = year17.compareTo(obj29);
        java.util.Calendar calendar31 = null;
        try {
            long long32 = year17.getFirstMillisecond(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(timePeriodValues27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        java.lang.Number number6 = timePeriodValue4.getValue();
        boolean boolean8 = timePeriodValue4.equals((java.lang.Object) "TimePeriodValue[1-January-1970,2.8799999E7]");
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0d + "'", number6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 10, (long) ' ');
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 12);
        java.lang.Object obj5 = timePeriodValue4.clone();
        timePeriodValue4.setValue((java.lang.Number) 1969L);
        java.lang.Object obj8 = timePeriodValue4.clone();
        java.lang.String str9 = timePeriodValue4.toString();
        org.jfree.data.time.TimePeriod timePeriod10 = timePeriodValue4.getPeriod();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(timePeriod10);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass9 = simpleTimePeriod8.getClass();
        long long10 = simpleTimePeriod8.getEndMillis();
        long long11 = simpleTimePeriod8.getStartMillis();
        boolean boolean12 = simpleTimePeriod2.equals((java.lang.Object) long11);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 28799999L);
        long long15 = simpleTimePeriod2.getStartMillis();
        java.util.Date date16 = simpleTimePeriod2.getStart();
        java.lang.Class class17 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass21 = simpleTimePeriod20.getClass();
        long long22 = simpleTimePeriod20.getEndMillis();
        long long23 = simpleTimePeriod20.getStartMillis();
        java.util.Date date24 = simpleTimePeriod20.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj28 = null;
        boolean boolean29 = simpleTimePeriod27.equals(obj28);
        java.util.Date date30 = simpleTimePeriod27.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        boolean boolean33 = day31.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate34 = day31.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass38 = simpleTimePeriod37.getClass();
        long long39 = simpleTimePeriod37.getEndMillis();
        long long40 = simpleTimePeriod37.getStartMillis();
        java.util.Date date41 = simpleTimePeriod37.getStart();
        boolean boolean42 = day31.equals((java.lang.Object) date41);
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date41, timeZone43);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date24, timeZone43);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj49 = null;
        boolean boolean50 = simpleTimePeriod48.equals(obj49);
        java.util.Date date51 = simpleTimePeriod48.getEnd();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date51);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod55 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj56 = null;
        boolean boolean57 = simpleTimePeriod55.equals(obj56);
        java.util.Date date58 = simpleTimePeriod55.getEnd();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date58);
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(date58);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod61 = new org.jfree.data.time.SimpleTimePeriod(date51, date58);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod62 = new org.jfree.data.time.SimpleTimePeriod(date24, date51);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod65 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj66 = null;
        boolean boolean67 = simpleTimePeriod65.equals(obj66);
        java.util.Date date68 = simpleTimePeriod65.getEnd();
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date68);
        boolean boolean71 = day69.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate72 = day69.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod75 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass76 = simpleTimePeriod75.getClass();
        long long77 = simpleTimePeriod75.getEndMillis();
        long long78 = simpleTimePeriod75.getStartMillis();
        java.util.Date date79 = simpleTimePeriod75.getStart();
        boolean boolean80 = day69.equals((java.lang.Object) date79);
        java.util.TimeZone timeZone81 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day(date79, timeZone81);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date24, timeZone81);
        org.jfree.data.time.Year year84 = new org.jfree.data.time.Year(date16, timeZone81);
        java.util.Date date85 = year84.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = year84.previous();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(serialDate34);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 10L + "'", long39 == 10L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(serialDate72);
        org.junit.Assert.assertNotNull(wildcardClass76);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 10L + "'", long77 == 10L);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(timeZone81);
        org.junit.Assert.assertNull(regularTimePeriod83);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertNotNull(regularTimePeriod86);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        boolean boolean41 = day12.equals((java.lang.Object) 1L);
        long long42 = day12.getSerialIndex();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 25568L + "'", long42 == 25568L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        int int6 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int9 = timePeriodValues8.getMinEndIndex();
        int int10 = timePeriodValues8.getMinEndIndex();
        boolean boolean11 = timePeriodValues8.isEmpty();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (double) 0);
        java.lang.Number number17 = timePeriodValue16.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        boolean boolean26 = day24.equals((java.lang.Object) '4');
        long long27 = day24.getMiddleMillisecond();
        long long28 = day24.getFirstMillisecond();
        boolean boolean29 = timePeriodValue16.equals((java.lang.Object) day24);
        java.lang.Number number30 = timePeriodValue16.getValue();
        java.lang.Object obj31 = timePeriodValue16.clone();
        timePeriodValues8.add(timePeriodValue16);
        timePeriodValues1.add(timePeriodValue16);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0.0d + "'", number17.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-14400001L) + "'", long27 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-57600000L) + "'", long28 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 0.0d + "'", number30.equals(0.0d));
        org.junit.Assert.assertNotNull(obj31);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean42 = timePeriodValues41.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener43 = null;
        timePeriodValues41.addChangeListener(seriesChangeListener43);
        timePeriodValues41.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj50 = null;
        boolean boolean51 = simpleTimePeriod49.equals(obj50);
        java.util.Date date52 = simpleTimePeriod49.getEnd();
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date52);
        timePeriodValues41.add((org.jfree.data.time.TimePeriod) day53, (java.lang.Number) 100);
        int int56 = day53.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue58 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day53, (java.lang.Number) (byte) 100);
        org.jfree.data.time.TimePeriod timePeriod59 = timePeriodValue58.getPeriod();
        java.lang.String str60 = timePeriodValue58.toString();
        boolean boolean61 = timePeriodValues28.equals((java.lang.Object) timePeriodValue58);
        timePeriodValues28.setRangeDescription("TimePeriodValue[1-January-1970,2.8799999E7]");
        java.lang.String str64 = timePeriodValues28.getDomainDescription();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 12 + "'", int56 == 12);
        org.junit.Assert.assertNotNull(timePeriod59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "TimePeriodValue[31-December-1969,100]" + "'", str60.equals("TimePeriodValue[31-December-1969,100]"));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "Time" + "'", str64.equals("Time"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "", "Value");
        timePeriodValues9.fireSeriesChanged();
        boolean boolean11 = timePeriodValues1.equals((java.lang.Object) timePeriodValues9);
        int int12 = timePeriodValues9.getMaxMiddleIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj16 = null;
        boolean boolean17 = simpleTimePeriod15.equals(obj16);
        java.util.Date date18 = simpleTimePeriod15.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        boolean boolean21 = day19.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day23.previous();
        timePeriodValues9.setKey((java.lang.Comparable) day23);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener27 = null;
        timePeriodValues9.addChangeListener(seriesChangeListener27);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        int int3 = timePeriodValues1.getMaxStartIndex();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener5);
        boolean boolean7 = timePeriodValues1.getNotify();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 10, (long) ' ');
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 12);
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2);
        java.lang.Object obj6 = timePeriodValues5.clone();
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getLastMillisecond();
        java.lang.String str12 = year7.toString();
        long long13 = year7.getFirstMillisecond();
        java.util.Calendar calendar14 = null;
        try {
            year7.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969" + "'", str12.equals("1969"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-31507200000L) + "'", long13 == (-31507200000L));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3, "Value", "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=a]");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (double) 0);
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date3, date14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date3);
        long long18 = year17.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue21 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod19, (java.lang.Number) (short) -1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod24, (double) 0);
        java.util.Date date27 = simpleTimePeriod24.getEnd();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        org.jfree.data.time.SerialDate serialDate29 = day28.getSerialDate();
        boolean boolean30 = timePeriodValue21.equals((java.lang.Object) day28);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-31507200000L) + "'", long18 == (-31507200000L));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year7.getMiddleMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day10, "Value", "org.jfree.data.general.SeriesException: hi!");
        org.jfree.data.time.SerialDate serialDate14 = day10.getSerialDate();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(serialDate14);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass9 = simpleTimePeriod8.getClass();
        long long10 = simpleTimePeriod8.getEndMillis();
        long long11 = simpleTimePeriod8.getStartMillis();
        boolean boolean12 = simpleTimePeriod2.equals((java.lang.Object) long11);
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 28799999L);
        long long15 = simpleTimePeriod2.getEndMillis();
        java.util.Date date16 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 5L + "'", long15 == 5L);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass11 = simpleTimePeriod10.getClass();
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass11);
        boolean boolean14 = year7.equals((java.lang.Object) wildcardClass11);
        java.util.Date date15 = year7.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        long long19 = simpleTimePeriod18.getEndMillis();
        long long20 = simpleTimePeriod18.getStartMillis();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj24 = null;
        boolean boolean25 = simpleTimePeriod23.equals(obj24);
        java.util.Date date26 = simpleTimePeriod23.getEnd();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
        boolean boolean29 = day27.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate30 = day27.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass34 = simpleTimePeriod33.getClass();
        long long35 = simpleTimePeriod33.getEndMillis();
        long long36 = simpleTimePeriod33.getStartMillis();
        java.util.Date date37 = simpleTimePeriod33.getStart();
        boolean boolean38 = day27.equals((java.lang.Object) date37);
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date37, timeZone39);
        long long41 = day40.getMiddleMillisecond();
        int int42 = day40.getMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int45 = timePeriodValues44.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener46 = null;
        timePeriodValues44.addChangeListener(seriesChangeListener46);
        int int48 = timePeriodValues44.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean51 = timePeriodValues50.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener52 = null;
        timePeriodValues50.addChangeListener(seriesChangeListener52);
        timePeriodValues50.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj59 = null;
        boolean boolean60 = simpleTimePeriod58.equals(obj59);
        java.util.Date date61 = simpleTimePeriod58.getEnd();
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date61);
        timePeriodValues50.add((org.jfree.data.time.TimePeriod) day62, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = day62.next();
        long long66 = day62.getSerialIndex();
        timePeriodValues44.add((org.jfree.data.time.TimePeriod) day62, (java.lang.Number) 1);
        boolean boolean69 = day40.equals((java.lang.Object) day62);
        boolean boolean70 = simpleTimePeriod18.equals((java.lang.Object) day40);
        int int71 = year7.compareTo((java.lang.Object) day40);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(class12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 5L + "'", long19 == 5L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 10L + "'", long35 == 10L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-14400001L) + "'", long41 == (-14400001L));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 12 + "'", int42 == 12);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 25568L + "'", long66 == 25568L);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
    }
}

