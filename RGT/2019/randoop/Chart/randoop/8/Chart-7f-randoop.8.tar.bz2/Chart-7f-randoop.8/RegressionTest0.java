import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (12) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = null;
        try {
            timePeriodValues1.add(timePeriodValue6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(9, 11, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (10) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue6 = timePeriodValues1.getDataItem((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue4 = timePeriodValues1.getDataItem((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(12, 4);
        java.lang.Number number8 = null;
        try {
            timePeriodValues1.update(5, number8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues6);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        try {
            timePeriodValues1.update((int) (byte) 100, (java.lang.Number) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 100, (int) (short) 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int2 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        int int5 = timePeriodValues1.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        try {
            int int4 = simpleTimePeriod2.compareTo((java.lang.Object) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Short cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (java.lang.Number) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(9, (int) ' ', 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(12, 4);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue8 = timePeriodValues6.getDataItem((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues6);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Class<?> wildcardClass2 = seriesException1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int2 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        try {
            timePeriodValues1.update((int) (short) 1, (java.lang.Number) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        long long9 = day6.getMiddleMillisecond();
        long long10 = day6.getSerialIndex();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = day6.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-14400001L) + "'", long9 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(25568L, (long) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Value");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        java.util.Calendar calendar7 = null;
        try {
            day6.peg(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (35) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + ' ' + "'", comparable6.equals(' '));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(12, 4);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue8 = timePeriodValues6.getDataItem((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues6);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timePeriodValues1.getNotify();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int2 = timePeriodValues1.getMaxEndIndex();
        try {
            java.lang.Number number4 = timePeriodValues1.getValue(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "", "Value");
        timePeriodValues9.fireSeriesChanged();
        boolean boolean11 = timePeriodValues1.equals((java.lang.Object) timePeriodValues9);
        boolean boolean12 = timePeriodValues9.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (-14400001L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day6.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        java.util.Calendar calendar9 = null;
        try {
            year7.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timePeriodValues1.isEmpty();
        timePeriodValues1.delete(0, (int) (short) -1);
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setKey((java.lang.Comparable) 'a');
        try {
            org.jfree.data.time.TimePeriod timePeriod5 = timePeriodValues1.getTimePeriod((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        timePeriodValues1.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        timePeriodValues1.setDomainDescription("Value");
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "", "Value");
        timePeriodValues9.fireSeriesChanged();
        boolean boolean11 = timePeriodValues1.equals((java.lang.Object) timePeriodValues9);
        try {
            timePeriodValues9.update(11, (java.lang.Number) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year7.getLastMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 10, (long) ' ');
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 12);
        java.lang.Object obj5 = timePeriodValue4.clone();
        boolean boolean7 = timePeriodValue4.equals((java.lang.Object) 1L);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        long long9 = day6.getMiddleMillisecond();
        long long10 = day6.getSerialIndex();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = day6.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-14400001L) + "'", long9 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        long long10 = day6.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day6.previous();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day6.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 9, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (100) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        java.util.Calendar calendar10 = null;
        try {
            year7.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.util.Calendar calendar8 = null;
        try {
            long long9 = year7.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.String str4 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 'a' + "'", obj2.equals('a'));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 'a' + "'", obj3.equals('a'));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=a]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=a]"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) -1, 0, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = day12.getFirstMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int2 = timePeriodValues1.getMaxEndIndex();
        java.lang.String str3 = timePeriodValues1.getDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        java.lang.String str18 = day12.toString();
        java.util.Calendar calendar19 = null;
        try {
            long long20 = day12.getLastMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "31-December-1969" + "'", str18.equals("31-December-1969"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("1969");
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        long long9 = day6.getMiddleMillisecond();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = day6.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-14400001L) + "'", long9 == (-14400001L));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        long long9 = day6.getMiddleMillisecond();
        long long10 = day6.getSerialIndex();
        java.util.Calendar calendar11 = null;
        try {
            day6.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-14400001L) + "'", long9 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getFirstMillisecond();
        java.util.Calendar calendar10 = null;
        try {
            year7.peg(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-31507200000L) + "'", long9 == (-31507200000L));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("1969");
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        try {
            org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValues1.getTimePeriod(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int2 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy(2, (int) 'a');
        try {
            timePeriodValues1.delete((int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 0, (int) (byte) 100, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        long long6 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass3 = simpleTimePeriod2.getClass();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        java.util.Date date7 = simpleTimePeriod2.getEnd();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(11, (int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        boolean boolean4 = simpleTimePeriod2.equals((java.lang.Object) 0.0d);
        long long5 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        int int3 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int2 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        int int5 = timePeriodValues1.getItemCount();
        int int6 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day6.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=a]");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=a]" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=a]"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        int int10 = day6.getYear();
        int int11 = day6.getMonth();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day6.getMiddleMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 12 + "'", int11 == 12);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str8 = seriesException7.toString();
        boolean boolean9 = timePeriodValues1.equals((java.lang.Object) seriesException7);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str8.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass3 = simpleTimePeriod2.getClass();
        long long4 = simpleTimePeriod2.getEndMillis();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        boolean boolean9 = simpleTimePeriod7.equals((java.lang.Object) 0.0d);
        try {
            int int10 = simpleTimePeriod2.compareTo((java.lang.Object) boolean9);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Boolean cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 'a');
        try {
            org.jfree.data.time.TimePeriod timePeriod3 = timePeriodValues1.getTimePeriod((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        timePeriodValues1.setDescription("");
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: Value");
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getSerialIndex();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = year7.getMiddleMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1969L + "'", long11 == 1969L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        boolean boolean41 = day12.equals((java.lang.Object) 1L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod44.equals(obj45);
        java.util.Date date47 = simpleTimePeriod44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        boolean boolean50 = day48.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate51 = day48.getSerialDate();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
        boolean boolean53 = day12.equals((java.lang.Object) serialDate51);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(serialDate51);
        java.util.Calendar calendar55 = null;
        try {
            day54.peg(calendar55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (4) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean3 = timePeriodValues2.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues2.addChangeListener(seriesChangeListener4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues2.addChangeListener(seriesChangeListener6);
        int int8 = year0.compareTo((java.lang.Object) timePeriodValues2);
        int int10 = year0.compareTo((java.lang.Object) 10);
        java.util.Calendar calendar11 = null;
        try {
            year0.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener3);
        timePeriodValues1.fireSeriesChanged();
        try {
            org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValues1.getTimePeriod((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 10, (long) ' ');
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 12);
        java.lang.Object obj5 = timePeriodValue4.clone();
        org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValue4.getPeriod();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(timePeriod6);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("1969");
        int int2 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.next();
        java.util.Calendar calendar4 = null;
        try {
            year1.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener4);
        java.lang.Object obj6 = timePeriodValues1.clone();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timePeriodValues1);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str8 = seriesException7.toString();
        boolean boolean9 = timePeriodValues1.equals((java.lang.Object) seriesException7);
        try {
            timePeriodValues1.update((int) (byte) 0, (java.lang.Number) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str8.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        java.util.Date date8 = day6.getStart();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 10L);
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues4.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues4.removePropertyChangeListener(propertyChangeListener7);
        java.lang.String str9 = timePeriodValues4.getDescription();
        java.lang.String str10 = timePeriodValues4.getDescription();
        boolean boolean11 = timePeriodValues4.isEmpty();
        timePeriodValues4.setKey((java.lang.Comparable) 5);
        try {
            int int14 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodValues4);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getSerialIndex();
        long long12 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year7.next();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1969L + "'", long11 == 1969L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        timePeriodValues28.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener41 = null;
        timePeriodValues28.addChangeListener(seriesChangeListener41);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str10 = seriesException9.toString();
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) seriesException9);
        boolean boolean12 = timePeriodValue4.equals((java.lang.Object) seriesException9);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str10.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        long long9 = day6.getMiddleMillisecond();
        java.lang.String str10 = day6.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day6.next();
        int int12 = day6.getYear();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = day6.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-14400001L) + "'", long9 == (-14400001L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-1969" + "'", str10.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        boolean boolean15 = day13.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass20 = simpleTimePeriod19.getClass();
        long long21 = simpleTimePeriod19.getEndMillis();
        long long22 = simpleTimePeriod19.getStartMillis();
        java.util.Date date23 = simpleTimePeriod19.getStart();
        boolean boolean24 = day13.equals((java.lang.Object) date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date5, timeZone25);
        java.util.Calendar calendar28 = null;
        try {
            year27.peg(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeZone25);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("1969");
        int int2 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean6 = year1.equals((java.lang.Object) timePeriodValues5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year1.getMiddleMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(25568L, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        long long9 = day6.getMiddleMillisecond();
        java.lang.String str10 = day6.toString();
        java.util.Date date11 = day6.getStart();
        int int12 = day6.getYear();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-14400001L) + "'", long9 == (-14400001L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-1969" + "'", str10.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (31) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        boolean boolean15 = day13.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass20 = simpleTimePeriod19.getClass();
        long long21 = simpleTimePeriod19.getEndMillis();
        long long22 = simpleTimePeriod19.getStartMillis();
        java.util.Date date23 = simpleTimePeriod19.getStart();
        boolean boolean24 = day13.equals((java.lang.Object) date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date5, timeZone25);
        java.util.Calendar calendar28 = null;
        try {
            long long29 = year27.getLastMillisecond(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeZone25);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        long long9 = day6.getMiddleMillisecond();
        java.lang.String str10 = day6.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day6.next();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day6.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-14400001L) + "'", long9 == (-14400001L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-1969" + "'", str10.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        timePeriodValues1.setNotify(false);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue9 = timePeriodValues1.getDataItem((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timePeriodValues1.isEmpty();
        try {
            timePeriodValues1.delete((int) (byte) 0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date5, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        int int5 = timePeriodValues1.getMaxStartIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue7 = timePeriodValues1.getDataItem((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (2) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        java.util.Date date18 = day12.getStart();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year7.next();
        java.util.Calendar calendar13 = null;
        try {
            year7.peg(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1969L + "'", long11 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Time");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        boolean boolean41 = day12.equals((java.lang.Object) 1L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod44.equals(obj45);
        java.util.Date date47 = simpleTimePeriod44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        boolean boolean50 = day48.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate51 = day48.getSerialDate();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
        boolean boolean53 = day12.equals((java.lang.Object) serialDate51);
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) serialDate51);
        timePeriodValues54.delete((int) 'a', 0);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1969L, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        boolean boolean41 = day12.equals((java.lang.Object) 1L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod44.equals(obj45);
        java.util.Date date47 = simpleTimePeriod44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        boolean boolean50 = day48.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate51 = day48.getSerialDate();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
        boolean boolean53 = day12.equals((java.lang.Object) serialDate51);
        int int54 = day12.getYear();
        java.util.Calendar calendar55 = null;
        try {
            long long56 = day12.getMiddleMillisecond(calendar55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1969 + "'", int54 == 1969);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        boolean boolean41 = day12.equals((java.lang.Object) 1L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod44.equals(obj45);
        java.util.Date date47 = simpleTimePeriod44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        boolean boolean50 = day48.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate51 = day48.getSerialDate();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
        boolean boolean53 = day12.equals((java.lang.Object) serialDate51);
        int int54 = day12.getYear();
        java.util.Date date55 = day12.getStart();
        int int56 = day12.getDayOfMonth();
        java.util.Calendar calendar57 = null;
        try {
            long long58 = day12.getFirstMillisecond(calendar57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1969 + "'", int54 == 1969);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 31 + "'", int56 == 31);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year7.next();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = year7.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1969L + "'", long11 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "", "Value");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        try {
            timePeriodValues3.delete((int) (short) 100, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "", "Value");
        timePeriodValues9.fireSeriesChanged();
        boolean boolean11 = timePeriodValues1.equals((java.lang.Object) timePeriodValues9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj15 = null;
        boolean boolean16 = simpleTimePeriod14.equals(obj15);
        java.util.Date date17 = simpleTimePeriod14.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        boolean boolean20 = day18.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate21 = day18.getSerialDate();
        long long22 = day18.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day18.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod23, (java.lang.Number) (short) 1);
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 25568L + "'", long22 == 25568L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year7.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        int int3 = timePeriodValues1.getMaxStartIndex();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        boolean boolean5 = timePeriodValues1.getNotify();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        int int3 = timePeriodValues1.getMaxStartIndex();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (double) 0);
        java.lang.Number number14 = timePeriodValue13.getValue();
        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValue13.getPeriod();
        timePeriodValue13.setValue((java.lang.Number) 2);
        timePeriodValues1.add(timePeriodValue13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.0d + "'", number14.equals(0.0d));
        org.junit.Assert.assertNotNull(timePeriod15);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener4);
        java.lang.Object obj6 = timePeriodValues1.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(6, 1);
        timePeriodValues9.setRangeDescription("org.jfree.data.general.SeriesException: Value");
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(timePeriodValues9);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        long long9 = day6.getMiddleMillisecond();
        long long10 = day6.getSerialIndex();
        java.util.Date date11 = day6.getStart();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day6.getLastMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-14400001L) + "'", long9 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        java.lang.String str7 = day6.toString();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day6.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-December-1969" + "'", str7.equals("31-December-1969"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        java.lang.String str7 = timePeriodValues1.getDescription();
        int int8 = timePeriodValues1.getMaxMiddleIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue10 = timePeriodValues1.getDataItem(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate9);
        java.lang.String str13 = day12.toString();
        int int14 = day12.getDayOfMonth();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = day12.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-1969" + "'", str13.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.next();
        java.lang.Class<?> wildcardClass10 = regularTimePeriod9.getClass();
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(class12);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        try {
            timePeriodValues1.update(10, (java.lang.Number) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        boolean boolean15 = day13.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass20 = simpleTimePeriod19.getClass();
        long long21 = simpleTimePeriod19.getEndMillis();
        long long22 = simpleTimePeriod19.getStartMillis();
        java.util.Date date23 = simpleTimePeriod19.getStart();
        boolean boolean24 = day13.equals((java.lang.Object) date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date5, timeZone25);
        java.util.Calendar calendar28 = null;
        try {
            long long29 = year27.getMiddleMillisecond(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeZone25);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("hi!");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "", "Value");
        timePeriodValues9.fireSeriesChanged();
        boolean boolean11 = timePeriodValues1.equals((java.lang.Object) timePeriodValues9);
        try {
            java.lang.Number number13 = timePeriodValues1.getValue(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day6.getLastMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        int int16 = day13.getMonth();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj20 = null;
        boolean boolean21 = simpleTimePeriod19.equals(obj20);
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        boolean boolean25 = day23.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate26 = day23.getSerialDate();
        int int27 = day23.getYear();
        long long28 = day23.getFirstMillisecond();
        int int29 = day13.compareTo((java.lang.Object) long28);
        java.lang.Object obj30 = null;
        boolean boolean31 = day13.equals(obj30);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-57600000L) + "'", long28 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "Time", "org.jfree.data.general.SeriesException: hi!", "");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        timePeriodValues3.setRangeDescription("1969");
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean8 = timePeriodValues7.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener9);
        timePeriodValues7.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj16 = null;
        boolean boolean17 = simpleTimePeriod15.equals(obj16);
        java.util.Date date18 = simpleTimePeriod15.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) 100);
        int int22 = day19.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue24 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) (byte) 100);
        org.jfree.data.time.TimePeriod timePeriod25 = timePeriodValue24.getPeriod();
        timePeriodValues1.add(timePeriod25, (java.lang.Number) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
        org.junit.Assert.assertNotNull(timePeriod25);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(date5, date12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass19 = simpleTimePeriod18.getClass();
        long long20 = simpleTimePeriod18.getEndMillis();
        long long21 = simpleTimePeriod18.getStartMillis();
        java.util.Date date22 = simpleTimePeriod18.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj26 = null;
        boolean boolean27 = simpleTimePeriod25.equals(obj26);
        java.util.Date date28 = simpleTimePeriod25.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        boolean boolean31 = day29.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate32 = day29.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod35 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass36 = simpleTimePeriod35.getClass();
        long long37 = simpleTimePeriod35.getEndMillis();
        long long38 = simpleTimePeriod35.getStartMillis();
        java.util.Date date39 = simpleTimePeriod35.getStart();
        boolean boolean40 = day29.equals((java.lang.Object) date39);
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date39, timeZone41);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date22, timeZone41);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date5, timeZone41);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date5);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 10L + "'", long20 == 10L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 10L + "'", long37 == 10L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(timeZone41);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.String str5 = timePeriodValue4.toString();
        org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValue4.getPeriod();
        org.junit.Assert.assertNotNull(timePeriod6);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(12, (int) '#', 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass13 = simpleTimePeriod12.getClass();
        long long14 = simpleTimePeriod12.getEndMillis();
        long long15 = simpleTimePeriod12.getStartMillis();
        java.util.Date date16 = simpleTimePeriod12.getStart();
        boolean boolean17 = day6.equals((java.lang.Object) date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16, timeZone18);
        long long20 = day19.getMiddleMillisecond();
        int int21 = day19.getMonth();
        java.util.Calendar calendar22 = null;
        try {
            day19.peg(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-14400001L) + "'", long20 == (-14400001L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int2 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy(2, (int) 'a');
        try {
            org.jfree.data.time.TimePeriod timePeriod9 = timePeriodValues7.getTimePeriod(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        boolean boolean41 = day12.equals((java.lang.Object) 1L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod44.equals(obj45);
        java.util.Date date47 = simpleTimePeriod44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        boolean boolean50 = day48.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate51 = day48.getSerialDate();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
        boolean boolean53 = day12.equals((java.lang.Object) serialDate51);
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) serialDate51);
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(serialDate51);
        java.util.Calendar calendar56 = null;
        try {
            day55.peg(calendar56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int2 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj8 = null;
        boolean boolean9 = simpleTimePeriod7.equals(obj8);
        java.util.Date date10 = simpleTimePeriod7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date10);
        java.lang.String str13 = year12.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod14, (double) 12);
        try {
            timePeriodValues1.update((int) 'a', (java.lang.Number) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969" + "'", str13.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getSerialIndex();
        long long12 = year7.getLastMillisecond();
        java.util.Date date13 = year7.getEnd();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year7.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1969L + "'", long11 == 1969L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int2 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        int int5 = timePeriodValues1.getItemCount();
        int int6 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setKey((java.lang.Comparable) 'a');
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        try {
            timePeriodValues1.delete((int) (byte) 100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass13 = simpleTimePeriod12.getClass();
        long long14 = simpleTimePeriod12.getEndMillis();
        long long15 = simpleTimePeriod12.getStartMillis();
        java.util.Date date16 = simpleTimePeriod12.getStart();
        boolean boolean17 = day6.equals((java.lang.Object) date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16, timeZone18);
        long long20 = day19.getMiddleMillisecond();
        int int21 = day19.getMonth();
        long long22 = day19.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-14400001L) + "'", long20 == (-14400001L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 25568L + "'", long22 == 25568L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        long long9 = day6.getMiddleMillisecond();
        java.lang.String str10 = day6.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day6.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues13.setKey((java.lang.Comparable) 'a');
        int int16 = timePeriodValues13.getItemCount();
        int int17 = timePeriodValues13.getMinEndIndex();
        int int18 = day6.compareTo((java.lang.Object) int17);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-14400001L) + "'", long9 == (-14400001L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-1969" + "'", str10.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        int int3 = timePeriodValues1.getMaxStartIndex();
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        java.lang.String str5 = timePeriodValues1.getDomainDescription();
        try {
            timePeriodValues1.update(6, (java.lang.Number) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getFirstMillisecond();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year7.getFirstMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-31507200000L) + "'", long9 == (-31507200000L));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener4);
        java.lang.Object obj6 = timePeriodValues1.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(6, 1);
        try {
            java.lang.Number number11 = timePeriodValues1.getValue((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(timePeriodValues9);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        long long10 = day6.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate11 = day6.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day6.next();
        long long13 = regularTimePeriod12.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod12, (double) 28799999L);
        long long16 = regularTimePeriod12.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 71999999L + "'", long13 == 71999999L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 71999999L + "'", long16 == 71999999L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.general.SeriesException seriesException5 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str6 = seriesException5.toString();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) seriesException5);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str6.equals("org.jfree.data.general.SeriesException: hi!"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(12, 4);
        java.lang.String str7 = timePeriodValues6.getDomainDescription();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        try {
            org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValues1.getTimePeriod(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Object obj5 = timePeriodValue4.clone();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) long16);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues19.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues19.addPropertyChangeListener(propertyChangeListener22);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timePeriodValues19.removeChangeListener(seriesChangeListener24);
        boolean boolean26 = timePeriodValue4.equals((java.lang.Object) seriesChangeListener24);
        timePeriodValue4.setValue((java.lang.Number) 28799999L);
        java.lang.Number number29 = timePeriodValue4.getValue();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 28799999L + "'", number29.equals(28799999L));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(12, 4);
        try {
            java.lang.Number number8 = timePeriodValues1.getValue((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues6);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        java.lang.Comparable comparable7 = timePeriodValues1.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        boolean boolean12 = simpleTimePeriod10.equals((java.lang.Object) 0.0d);
        boolean boolean13 = timePeriodValues1.equals((java.lang.Object) 0.0d);
        try {
            timePeriodValues1.delete((int) (byte) 100, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + ' ' + "'", comparable7.equals(' '));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int2 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy(2, (int) 'a');
        timePeriodValues7.setDescription("1969");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues7);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass13 = simpleTimePeriod12.getClass();
        long long14 = simpleTimePeriod12.getEndMillis();
        long long15 = simpleTimePeriod12.getStartMillis();
        java.util.Date date16 = simpleTimePeriod12.getStart();
        boolean boolean17 = day6.equals((java.lang.Object) date16);
        java.lang.String str18 = day6.toString();
        java.lang.Object obj19 = null;
        int int20 = day6.compareTo(obj19);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "31-December-1969" + "'", str18.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        int int16 = day13.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) (byte) 100);
        java.util.Calendar calendar19 = null;
        try {
            day13.peg(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        java.lang.Number number18 = timePeriodValue4.getValue();
        java.lang.Object obj19 = timePeriodValue4.clone();
        java.lang.Object obj20 = timePeriodValue4.clone();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 0.0d + "'", number18.equals(0.0d));
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.String str4 = seriesChangeEvent1.toString();
        java.lang.String str5 = seriesChangeEvent1.toString();
        java.lang.Object obj6 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=a]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=a]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 'a' + "'", obj3.equals('a'));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=a]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=a]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=a]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=a]"));
        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + 'a' + "'", obj6.equals('a'));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        boolean boolean41 = day12.equals((java.lang.Object) 1L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod44.equals(obj45);
        java.util.Date date47 = simpleTimePeriod44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        boolean boolean50 = day48.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate51 = day48.getSerialDate();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
        boolean boolean53 = day12.equals((java.lang.Object) serialDate51);
        int int54 = day12.getYear();
        java.util.Date date55 = day12.getStart();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent56 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) date55);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1969 + "'", int54 == 1969);
        org.junit.Assert.assertNotNull(date55);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass3 = simpleTimePeriod2.getClass();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        boolean boolean15 = day13.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass20 = simpleTimePeriod19.getClass();
        long long21 = simpleTimePeriod19.getEndMillis();
        long long22 = simpleTimePeriod19.getStartMillis();
        java.util.Date date23 = simpleTimePeriod19.getStart();
        boolean boolean24 = day13.equals((java.lang.Object) date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date6, timeZone25);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj31 = null;
        boolean boolean32 = simpleTimePeriod30.equals(obj31);
        java.util.Date date33 = simpleTimePeriod30.getEnd();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj38 = null;
        boolean boolean39 = simpleTimePeriod37.equals(obj38);
        java.util.Date date40 = simpleTimePeriod37.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date40);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date33, date40);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod(date6, date33);
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date33, timeZone45);
        java.util.Calendar calendar47 = null;
        try {
            long long48 = day46.getFirstMillisecond(calendar47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone45);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        long long9 = day6.getMiddleMillisecond();
        long long10 = day6.getSerialIndex();
        java.lang.String str11 = day6.toString();
        java.lang.String str12 = day6.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-14400001L) + "'", long9 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "31-December-1969" + "'", str11.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-1969" + "'", str12.equals("31-December-1969"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        int int10 = day6.getYear();
        int int11 = day6.getYear();
        java.util.Date date12 = day6.getStart();
        java.util.Calendar calendar13 = null;
        try {
            long long14 = day6.getLastMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        boolean boolean4 = timePeriodValues1.isEmpty();
        try {
            org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValues1.getTimePeriod((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        int int4 = timePeriodValues1.getMaxEndIndex();
        int int5 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=a]");
        seriesException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str8 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: Value" + "'", str8.equals("org.jfree.data.general.SeriesException: Value"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.util.Date date9 = simpleTimePeriod8.getStart();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date9, timeZone10);
        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date9, timeZone12);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date5, date9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(timeZone12);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValue4.getPeriod();
        timePeriodValue4.setValue((java.lang.Number) 6);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertNotNull(timePeriod6);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.fireSeriesChanged();
        java.lang.String str7 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Value" + "'", str7.equals("Value"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (java.lang.Number) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getLastMillisecond();
        java.lang.String str12 = year7.toString();
        java.util.Date date13 = year7.getEnd();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = year7.getLastMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969" + "'", str12.equals("1969"));
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        long long9 = day6.getMiddleMillisecond();
        java.lang.String str10 = day6.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day6.next();
        int int12 = day6.getMonth();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-14400001L) + "'", long9 == (-14400001L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-1969" + "'", str10.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.Year year4 = org.jfree.data.time.Year.parseYear("1969");
        int int5 = year2.compareTo((java.lang.Object) "1969");
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=a]");
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.String str4 = seriesChangeEvent1.toString();
        java.lang.String str5 = seriesChangeEvent1.toString();
        java.lang.String str6 = seriesChangeEvent1.toString();
        java.lang.String str7 = seriesChangeEvent1.toString();
        java.lang.Object obj8 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=a]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=a]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 'a' + "'", obj3.equals('a'));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=a]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=a]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=a]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=a]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=a]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=a]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=a]" + "'", str7.equals("org.jfree.data.general.SeriesChangeEvent[source=a]"));
        org.junit.Assert.assertTrue("'" + obj8 + "' != '" + 'a' + "'", obj8.equals('a'));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass3 = simpleTimePeriod2.getClass();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 'a');
        timePeriodValues7.setNotify(false);
        try {
            int int10 = simpleTimePeriod2.compareTo((java.lang.Object) timePeriodValues7);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.time.TimePeriodValues cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        int int12 = day10.getYear();
        long long13 = day10.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28799999L + "'", long13 == 28799999L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValue4.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue4.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue4.getPeriod();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertNotNull(timePeriod6);
        org.junit.Assert.assertNotNull(timePeriod7);
        org.junit.Assert.assertNotNull(timePeriod8);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass13 = simpleTimePeriod12.getClass();
        long long14 = simpleTimePeriod12.getEndMillis();
        long long15 = simpleTimePeriod12.getStartMillis();
        java.util.Date date16 = simpleTimePeriod12.getStart();
        boolean boolean17 = day6.equals((java.lang.Object) date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16, timeZone18);
        long long20 = day19.getMiddleMillisecond();
        int int21 = day19.getMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int24 = timePeriodValues23.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timePeriodValues23.addChangeListener(seriesChangeListener25);
        int int27 = timePeriodValues23.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean30 = timePeriodValues29.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timePeriodValues29.addChangeListener(seriesChangeListener31);
        timePeriodValues29.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj38 = null;
        boolean boolean39 = simpleTimePeriod37.equals(obj38);
        java.util.Date date40 = simpleTimePeriod37.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        timePeriodValues29.add((org.jfree.data.time.TimePeriod) day41, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day41.next();
        long long45 = day41.getSerialIndex();
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) day41, (java.lang.Number) 1);
        boolean boolean48 = day19.equals((java.lang.Object) day41);
        org.jfree.data.time.SerialDate serialDate49 = day19.getSerialDate();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-14400001L) + "'", long20 == (-14400001L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 25568L + "'", long45 == 25568L);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(serialDate49);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        timePeriodValues1.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        boolean boolean10 = timePeriodValues1.getNotify();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setKey((java.lang.Comparable) 'a');
        int int4 = timePeriodValues1.getItemCount();
        boolean boolean5 = timePeriodValues1.isEmpty();
        try {
            java.lang.Number number7 = timePeriodValues1.getValue(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        try {
            timePeriodValues1.delete((int) (byte) -1, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day6.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod8);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues(comparable0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Object obj5 = timePeriodValue4.clone();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) long16);
        timePeriodValue4.setValue((java.lang.Number) (-31507200000L));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str8 = seriesException7.toString();
        boolean boolean9 = timePeriodValues1.equals((java.lang.Object) seriesException7);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy(7, 0);
        java.lang.String str13 = timePeriodValues12.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str8.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Time" + "'", str13.equals("Time"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setKey((java.lang.Comparable) 'a');
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        int int5 = timePeriodValues1.getMinMiddleIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue7 = timePeriodValues1.getDataItem((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date5, "org.jfree.data.general.SeriesException: hi!", "hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj12 = null;
        boolean boolean13 = simpleTimePeriod11.equals(obj12);
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(date5, date14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj19 = null;
        boolean boolean20 = simpleTimePeriod18.equals(obj19);
        java.util.Date date21 = simpleTimePeriod18.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date21);
        java.lang.String str24 = year23.toString();
        long long25 = year23.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year23.next();
        long long27 = year23.getLastMillisecond();
        long long28 = year23.getFirstMillisecond();
        long long29 = year23.getSerialIndex();
        java.util.Date date30 = year23.getEnd();
        int int31 = year23.getYear();
        try {
            int int32 = simpleTimePeriod15.compareTo((java.lang.Object) int31);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969" + "'", str24.equals("1969"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 28799999L + "'", long25 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 28799999L + "'", long27 == 28799999L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-31507200000L) + "'", long28 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1969L + "'", long29 == 1969L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1969 + "'", int31 == 1969);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass13 = simpleTimePeriod12.getClass();
        long long14 = simpleTimePeriod12.getEndMillis();
        long long15 = simpleTimePeriod12.getStartMillis();
        java.util.Date date16 = simpleTimePeriod12.getStart();
        boolean boolean17 = day6.equals((java.lang.Object) date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16, timeZone18);
        java.util.Date date20 = day19.getStart();
        java.util.Calendar calendar21 = null;
        try {
            day19.peg(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timePeriodValues1.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener7);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj12 = null;
        boolean boolean13 = simpleTimePeriod11.equals(obj12);
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(date14);
        java.lang.String str17 = year16.toString();
        long long18 = year16.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year16.next();
        long long20 = year16.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year16.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent22 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) regularTimePeriod21);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod21, (double) 0L);
        try {
            timePeriodValues1.update(8, (java.lang.Number) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1969" + "'", str17.equals("1969"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28799999L + "'", long18 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1969L + "'", long20 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "", "Value");
        timePeriodValues9.fireSeriesChanged();
        boolean boolean11 = timePeriodValues1.equals((java.lang.Object) timePeriodValues9);
        try {
            java.lang.Number number13 = timePeriodValues1.getValue((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        timePeriodValues1.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) seriesChangeListener8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int2 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.delete(8, (int) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener8);
        java.lang.String str10 = timePeriodValues1.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Object obj5 = timePeriodValue4.clone();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) long16);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues19.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues19.addPropertyChangeListener(propertyChangeListener22);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timePeriodValues19.removeChangeListener(seriesChangeListener24);
        boolean boolean26 = timePeriodValue4.equals((java.lang.Object) seriesChangeListener24);
        java.lang.Object obj27 = timePeriodValue4.clone();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setKey((java.lang.Comparable) 'a');
        int int4 = timePeriodValues1.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener5);
        java.lang.Comparable comparable7 = timePeriodValues1.getKey();
        java.lang.String str8 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 'a' + "'", comparable7.equals('a'));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        boolean boolean7 = timePeriodValues1.isEmpty();
        java.lang.String str8 = timePeriodValues1.getDescription();
        timePeriodValues1.setNotify(false);
        java.lang.Object obj11 = timePeriodValues1.clone();
        java.lang.Class<?> wildcardClass12 = timePeriodValues1.getClass();
        try {
            java.lang.Number number14 = timePeriodValues1.getValue(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + ' ' + "'", comparable6.equals(' '));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass13 = simpleTimePeriod12.getClass();
        long long14 = simpleTimePeriod12.getEndMillis();
        long long15 = simpleTimePeriod12.getStartMillis();
        java.util.Date date16 = simpleTimePeriod12.getStart();
        boolean boolean17 = day6.equals((java.lang.Object) date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
        int int21 = day19.getYear();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year7.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) regularTimePeriod12);
        java.lang.Object obj14 = seriesChangeEvent13.getSource();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1969L + "'", long11 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            year0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues8.setKey((java.lang.Comparable) 'a');
        boolean boolean11 = timePeriodValues1.equals((java.lang.Object) 'a');
        int int12 = timePeriodValues1.getMinMiddleIndex();
        java.lang.String str13 = timePeriodValues1.getDescription();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 'a');
        timePeriodValues1.setNotify(false);
        java.lang.String str4 = timePeriodValues1.getDescription();
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        int int3 = timePeriodValues1.getMaxStartIndex();
        java.lang.Object obj4 = timePeriodValues1.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener7);
        int int9 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        boolean boolean41 = day12.equals((java.lang.Object) 1L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod44.equals(obj45);
        java.util.Date date47 = simpleTimePeriod44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        boolean boolean50 = day48.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate51 = day48.getSerialDate();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
        boolean boolean53 = day12.equals((java.lang.Object) serialDate51);
        int int54 = day12.getYear();
        java.util.Date date55 = day12.getStart();
        int int56 = day12.getMonth();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1969 + "'", int54 == 1969);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 12 + "'", int56 == 12);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        long long5 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 5L + "'", long5 == 5L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass13 = simpleTimePeriod12.getClass();
        long long14 = simpleTimePeriod12.getEndMillis();
        long long15 = simpleTimePeriod12.getStartMillis();
        java.util.Date date16 = simpleTimePeriod12.getStart();
        boolean boolean17 = day6.equals((java.lang.Object) date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16, timeZone18);
        java.util.Date date20 = day19.getStart();
        long long21 = day19.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28799999L + "'", long21 == 28799999L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        java.lang.Number number18 = timePeriodValue4.getValue();
        java.lang.String str19 = timePeriodValue4.toString();
        timePeriodValue4.setValue((java.lang.Number) (byte) 0);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 0.0d + "'", number18.equals(0.0d));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("1969");
        int int2 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.next();
        long long4 = year1.getMiddleMillisecond();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year1.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-15739200001L) + "'", long4 == (-15739200001L));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        java.util.Date date7 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date5, date7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getSerialIndex();
        long long12 = year7.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 12);
        org.jfree.data.time.TimePeriod timePeriod15 = timePeriodValue14.getPeriod();
        java.lang.Object obj16 = timePeriodValue14.clone();
        java.lang.Class<?> wildcardClass17 = obj16.getClass();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1969L + "'", long11 == 1969L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
        org.junit.Assert.assertNotNull(timePeriod15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.util.Date date9 = simpleTimePeriod8.getStart();
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date9, timeZone10);
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date3, timeZone10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = year12.previous();
        long long14 = year12.getLastMillisecond();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 28799999L + "'", long14 == 28799999L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        timePeriodValues1.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        boolean boolean10 = timePeriodValues1.getNotify();
        int int11 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues13.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timePeriodValues13.removeChangeListener(seriesChangeListener18);
        int int20 = timePeriodValues13.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timePeriodValues13.addChangeListener(seriesChangeListener21);
        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues13);
        java.lang.String str24 = timePeriodValues1.getRangeDescription();
        boolean boolean25 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getFirstMillisecond();
        int int10 = year7.getYear();
        java.util.Calendar calendar11 = null;
        try {
            year7.peg(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-31507200000L) + "'", long9 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        timePeriodValues1.fireSeriesChanged();
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        boolean boolean15 = day13.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass20 = simpleTimePeriod19.getClass();
        long long21 = simpleTimePeriod19.getEndMillis();
        long long22 = simpleTimePeriod19.getStartMillis();
        java.util.Date date23 = simpleTimePeriod19.getStart();
        boolean boolean24 = day13.equals((java.lang.Object) date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date5, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues30.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timePeriodValues30.removePropertyChangeListener(propertyChangeListener33);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        timePeriodValues30.removeChangeListener(seriesChangeListener35);
        java.lang.Class<?> wildcardClass37 = timePeriodValues30.getClass();
        boolean boolean38 = year27.equals((java.lang.Object) wildcardClass37);
        java.lang.Class class39 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass37);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(class39);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int2 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener7);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (double) 0);
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        timePeriodValues1.setKey((java.lang.Comparable) simpleTimePeriod11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day10, "Value", "org.jfree.data.general.SeriesException: hi!");
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues13.addPropertyChangeListener(propertyChangeListener14);
        int int16 = timePeriodValues13.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        int int7 = timePeriodValues1.getMinEndIndex();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        java.lang.Comparable comparable4 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + ' ' + "'", comparable4.equals(' '));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3, "Value", "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=a]");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (double) 0);
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date3, date14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues19.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues19.addPropertyChangeListener(propertyChangeListener22);
        java.lang.Object obj24 = timePeriodValues19.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = timePeriodValues19.createCopy(6, 1);
        boolean boolean28 = year17.equals((java.lang.Object) timePeriodValues27);
        java.util.Calendar calendar29 = null;
        try {
            long long30 = year17.getLastMillisecond(calendar29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(timePeriodValues27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        int int3 = timePeriodValues1.getMaxStartIndex();
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener5);
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesException: Value");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        boolean boolean41 = day12.equals((java.lang.Object) 1L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod44.equals(obj45);
        java.util.Date date47 = simpleTimePeriod44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        boolean boolean50 = day48.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate51 = day48.getSerialDate();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
        boolean boolean53 = day12.equals((java.lang.Object) serialDate51);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(serialDate51);
        org.jfree.data.time.TimePeriodValue timePeriodValue56 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day54, (double) 10.0f);
        int int57 = day54.getYear();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 1969 + "'", int57 == 1969);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        java.lang.Number number18 = timePeriodValue4.getValue();
        java.lang.Object obj19 = timePeriodValue4.clone();
        java.lang.Number number20 = timePeriodValue4.getValue();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 0.0d + "'", number18.equals(0.0d));
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0d + "'", number20.equals(0.0d));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        java.lang.String str6 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        java.lang.Number number18 = timePeriodValue4.getValue();
        java.lang.Number number19 = timePeriodValue4.getValue();
        java.lang.String str20 = timePeriodValue4.toString();
        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValue4.getPeriod();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 0.0d + "'", number18.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0.0d + "'", number19.equals(0.0d));
        org.junit.Assert.assertNotNull(timePeriod21);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(71999999L, (long) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate9);
        java.lang.String str13 = day12.toString();
        int int14 = day12.getDayOfMonth();
        long long15 = day12.getLastMillisecond();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj19 = null;
        boolean boolean20 = simpleTimePeriod18.equals(obj19);
        java.util.Date date21 = simpleTimePeriod18.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj26 = null;
        boolean boolean27 = simpleTimePeriod25.equals(obj26);
        java.util.Date date28 = simpleTimePeriod25.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(date21, date28);
        int int32 = day12.compareTo((java.lang.Object) date21);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-1969" + "'", str13.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28799999L + "'", long15 == 28799999L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        int int16 = day13.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) (byte) 100);
        java.lang.String str19 = day13.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31-December-1969" + "'", str19.equals("31-December-1969"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj8 = null;
        boolean boolean9 = simpleTimePeriod7.equals(obj8);
        java.util.Date date10 = simpleTimePeriod7.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        boolean boolean13 = day11.equals((java.lang.Object) '4');
        long long14 = day11.getMiddleMillisecond();
        long long15 = day11.getFirstMillisecond();
        int int16 = simpleTimePeriod2.compareTo((java.lang.Object) day11);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-14400001L) + "'", long14 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-57600000L) + "'", long15 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int2 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.delete(8, (int) (short) 0);
        int int8 = timePeriodValues1.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        int int5 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date11);
        java.lang.String str14 = year13.toString();
        long long15 = year13.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year13.next();
        long long17 = year13.getSerialIndex();
        long long18 = year13.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year13, (double) 12);
        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValue20.getPeriod();
        timePeriodValues1.setKey((java.lang.Comparable) timePeriod21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1969" + "'", str14.equals("1969"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28799999L + "'", long15 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1969L + "'", long17 == 1969L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28799999L + "'", long18 == 28799999L);
        org.junit.Assert.assertNotNull(timePeriod21);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass13 = simpleTimePeriod12.getClass();
        long long14 = simpleTimePeriod12.getEndMillis();
        long long15 = simpleTimePeriod12.getStartMillis();
        java.util.Date date16 = simpleTimePeriod12.getStart();
        boolean boolean17 = day6.equals((java.lang.Object) date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16, timeZone18);
        long long20 = day19.getMiddleMillisecond();
        int int21 = day19.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day19.previous();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-14400001L) + "'", long20 == (-14400001L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        boolean boolean41 = day12.equals((java.lang.Object) 1L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod44.equals(obj45);
        java.util.Date date47 = simpleTimePeriod44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        boolean boolean50 = day48.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate51 = day48.getSerialDate();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
        boolean boolean53 = day12.equals((java.lang.Object) serialDate51);
        int int54 = day12.getYear();
        java.util.Date date55 = day12.getStart();
        int int56 = day12.getDayOfMonth();
        java.util.Calendar calendar57 = null;
        try {
            day12.peg(calendar57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1969 + "'", int54 == 1969);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 31 + "'", int56 == 31);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=a]");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException8 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=a]");
        seriesException6.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException8);
        java.lang.String str11 = timePeriodFormatException8.toString();
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=a]" + "'", str11.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=a]"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        try {
            timePeriodValues1.delete(9, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        java.lang.String str18 = day12.toString();
        java.util.Calendar calendar19 = null;
        try {
            day12.peg(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "31-December-1969" + "'", str18.equals("31-December-1969"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener16);
        int int18 = timePeriodValues1.getMaxEndIndex();
        boolean boolean19 = timePeriodValues1.getNotify();
        try {
            timePeriodValues1.delete(5, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 5, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timePeriodValues1.isEmpty();
        int int7 = timePeriodValues1.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = day6.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean3 = timePeriodValues2.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues2.addChangeListener(seriesChangeListener4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues2.addChangeListener(seriesChangeListener6);
        int int8 = year0.compareTo((java.lang.Object) timePeriodValues2);
        java.lang.Object obj9 = timePeriodValues2.clone();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        boolean boolean41 = day12.equals((java.lang.Object) 1L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod44.equals(obj45);
        java.util.Date date47 = simpleTimePeriod44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        boolean boolean50 = day48.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate51 = day48.getSerialDate();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
        boolean boolean53 = day12.equals((java.lang.Object) serialDate51);
        int int54 = day12.getYear();
        java.util.Calendar calendar55 = null;
        try {
            day12.peg(calendar55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1969 + "'", int54 == 1969);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        int int16 = day13.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) (byte) 100);
        org.jfree.data.time.TimePeriod timePeriod19 = timePeriodValue18.getPeriod();
        java.lang.String str20 = timePeriodValue18.toString();
        org.jfree.data.time.TimePeriod timePeriod21 = timePeriodValue18.getPeriod();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertNotNull(timePeriod19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "TimePeriodValue[31-December-1969,100]" + "'", str20.equals("TimePeriodValue[31-December-1969,100]"));
        org.junit.Assert.assertNotNull(timePeriod21);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int2 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        int int5 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean8 = timePeriodValues7.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener9);
        timePeriodValues7.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj16 = null;
        boolean boolean17 = simpleTimePeriod15.equals(obj16);
        java.util.Date date18 = simpleTimePeriod15.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day19.next();
        long long23 = day19.getSerialIndex();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) 1);
        java.util.Calendar calendar26 = null;
        try {
            long long27 = day19.getLastMillisecond(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 25568L + "'", long23 == 25568L);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int2 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener5);
        int int7 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.fireSeriesChanged();
        int int8 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 'a');
        boolean boolean2 = timePeriodValues1.isEmpty();
        timePeriodValues1.setNotify(false);
        int int5 = timePeriodValues1.getItemCount();
        java.lang.String str6 = timePeriodValues1.getDescription();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        java.lang.String str5 = timePeriodValues1.getDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        try {
            timePeriodValues1.update(10, (java.lang.Number) 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setKey((java.lang.Comparable) 'a');
        int int4 = timePeriodValues1.getMinStartIndex();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue6 = timePeriodValues1.getDataItem(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(11, (int) (byte) -1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Time");
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        java.lang.String str7 = timePeriodValues1.getDescription();
        boolean boolean8 = timePeriodValues1.isEmpty();
        timePeriodValues1.setKey((java.lang.Comparable) 5);
        try {
            org.jfree.data.time.TimePeriod timePeriod12 = timePeriodValues1.getTimePeriod(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        int int3 = timePeriodValues1.getMaxStartIndex();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener5);
        try {
            org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValues1.getTimePeriod((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getLastMillisecond();
        java.lang.String str12 = year7.toString();
        java.util.Date date13 = year7.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year7.previous();
        java.util.Date date15 = year7.getEnd();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969" + "'", str12.equals("1969"));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(12, 4);
        int int7 = timePeriodValues6.getMaxMiddleIndex();
        boolean boolean8 = timePeriodValues6.isEmpty();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener9);
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        java.lang.String str7 = timePeriodValues1.getDescription();
        boolean boolean8 = timePeriodValues1.isEmpty();
        timePeriodValues1.setKey((java.lang.Comparable) 5);
        int int11 = timePeriodValues1.getMinStartIndex();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.Object obj6 = timePeriodValues1.clone();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesException: hi!");
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day6.previous();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day6.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "", "Value");
        timePeriodValues9.fireSeriesChanged();
        boolean boolean11 = timePeriodValues1.equals((java.lang.Object) timePeriodValues9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (double) 0);
        java.lang.Number number17 = timePeriodValue16.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        boolean boolean26 = day24.equals((java.lang.Object) '4');
        long long27 = day24.getMiddleMillisecond();
        long long28 = day24.getFirstMillisecond();
        boolean boolean29 = timePeriodValue16.equals((java.lang.Object) day24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = day24.next();
        java.lang.String str31 = day24.toString();
        timePeriodValues1.setKey((java.lang.Comparable) day24);
        timePeriodValues1.setNotify(true);
        int int35 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0.0d + "'", number17.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-14400001L) + "'", long27 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-57600000L) + "'", long28 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "31-December-1969" + "'", str31.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        boolean boolean41 = day12.equals((java.lang.Object) 1L);
        java.util.Calendar calendar42 = null;
        try {
            long long43 = day12.getFirstMillisecond(calendar42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj12 = null;
        boolean boolean13 = simpleTimePeriod11.equals(obj12);
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        boolean boolean17 = day15.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate18 = day15.getSerialDate();
        long long19 = day15.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day15.previous();
        long long21 = day15.getLastMillisecond();
        int int22 = year7.compareTo((java.lang.Object) long21);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 25568L + "'", long19 == 25568L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28799999L + "'", long21 == 28799999L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setKey((java.lang.Comparable) 'a');
        timePeriodValues1.fireSeriesChanged();
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 'a');
        boolean boolean2 = timePeriodValues1.isEmpty();
        int int3 = timePeriodValues1.getItemCount();
        int int4 = timePeriodValues1.getItemCount();
        java.lang.Comparable comparable5 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 'a' + "'", comparable5.equals('a'));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 'a');
        boolean boolean2 = timePeriodValues1.isEmpty();
        int int3 = timePeriodValues1.getItemCount();
        int int4 = timePeriodValues1.getItemCount();
        int int5 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "", "Value");
        java.lang.Object obj4 = timePeriodValues3.clone();
        int int5 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        long long9 = day6.getMiddleMillisecond();
        long long10 = day6.getSerialIndex();
        java.util.Date date11 = day6.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod14, (double) 0);
        java.util.Date date17 = simpleTimePeriod14.getEnd();
        java.lang.Class class18 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass22 = simpleTimePeriod21.getClass();
        long long23 = simpleTimePeriod21.getEndMillis();
        long long24 = simpleTimePeriod21.getStartMillis();
        java.util.Date date25 = simpleTimePeriod21.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj29 = null;
        boolean boolean30 = simpleTimePeriod28.equals(obj29);
        java.util.Date date31 = simpleTimePeriod28.getEnd();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        boolean boolean34 = day32.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate35 = day32.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass39 = simpleTimePeriod38.getClass();
        long long40 = simpleTimePeriod38.getEndMillis();
        long long41 = simpleTimePeriod38.getStartMillis();
        java.util.Date date42 = simpleTimePeriod38.getStart();
        boolean boolean43 = day32.equals((java.lang.Object) date42);
        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date42, timeZone44);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date25, timeZone44);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj50 = null;
        boolean boolean51 = simpleTimePeriod49.equals(obj50);
        java.util.Date date52 = simpleTimePeriod49.getEnd();
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date52);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod56 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj57 = null;
        boolean boolean58 = simpleTimePeriod56.equals(obj57);
        java.util.Date date59 = simpleTimePeriod56.getEnd();
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date59);
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date59);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod62 = new org.jfree.data.time.SimpleTimePeriod(date52, date59);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod63 = new org.jfree.data.time.SimpleTimePeriod(date25, date52);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod66 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj67 = null;
        boolean boolean68 = simpleTimePeriod66.equals(obj67);
        java.util.Date date69 = simpleTimePeriod66.getEnd();
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date69);
        boolean boolean72 = day70.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate73 = day70.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod76 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass77 = simpleTimePeriod76.getClass();
        long long78 = simpleTimePeriod76.getEndMillis();
        long long79 = simpleTimePeriod76.getStartMillis();
        java.util.Date date80 = simpleTimePeriod76.getStart();
        boolean boolean81 = day70.equals((java.lang.Object) date80);
        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day(date80, timeZone82);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date25, timeZone82);
        org.jfree.data.time.Year year85 = new org.jfree.data.time.Year(date17, timeZone82);
        org.jfree.data.time.Year year86 = new org.jfree.data.time.Year(date11, timeZone82);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-14400001L) + "'", long9 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(serialDate35);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(serialDate73);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 10L + "'", long78 == 10L);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 0L + "'", long79 == 0L);
        org.junit.Assert.assertNotNull(date80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(timeZone82);
        org.junit.Assert.assertNull(regularTimePeriod84);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setKey((java.lang.Comparable) 'a');
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener5);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        boolean boolean41 = day12.equals((java.lang.Object) 1L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod44.equals(obj45);
        java.util.Date date47 = simpleTimePeriod44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        boolean boolean50 = day48.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate51 = day48.getSerialDate();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
        boolean boolean53 = day12.equals((java.lang.Object) serialDate51);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(serialDate51);
        java.util.Date date55 = day54.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues57 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int58 = timePeriodValues57.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener59 = null;
        timePeriodValues57.addChangeListener(seriesChangeListener59);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener61 = null;
        timePeriodValues57.addChangeListener(seriesChangeListener61);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener63 = null;
        timePeriodValues57.removeChangeListener(seriesChangeListener63);
        boolean boolean65 = day54.equals((java.lang.Object) timePeriodValues57);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod68 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue70 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod68, (double) 0);
        java.util.Date date71 = simpleTimePeriod68.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues74 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date71, "org.jfree.data.general.SeriesException: hi!", "hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod77 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj78 = null;
        boolean boolean79 = simpleTimePeriod77.equals(obj78);
        java.util.Date date80 = simpleTimePeriod77.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod81 = new org.jfree.data.time.SimpleTimePeriod(date71, date80);
        timePeriodValues57.add((org.jfree.data.time.TimePeriod) simpleTimePeriod81, (java.lang.Number) (byte) 0);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(date80);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2, "1969", "");
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "1969", "", "hi!");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getLastMillisecond();
        java.lang.String str12 = year7.toString();
        java.util.Date date13 = year7.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year7.previous();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = year7.getFirstMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969" + "'", str12.equals("1969"));
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass3 = simpleTimePeriod2.getClass();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        boolean boolean15 = day13.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass20 = simpleTimePeriod19.getClass();
        long long21 = simpleTimePeriod19.getEndMillis();
        long long22 = simpleTimePeriod19.getStartMillis();
        java.util.Date date23 = simpleTimePeriod19.getStart();
        boolean boolean24 = day13.equals((java.lang.Object) date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date6, timeZone25);
        int int28 = year27.getYear();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1969 + "'", int28 == 1969);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean3 = timePeriodValues2.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues2.addChangeListener(seriesChangeListener4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues2.addChangeListener(seriesChangeListener6);
        int int8 = year0.compareTo((java.lang.Object) timePeriodValues2);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = year0.getLastMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.String str4 = seriesChangeEvent1.toString();
        java.lang.Object obj5 = seriesChangeEvent1.getSource();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) seriesChangeEvent1);
        java.lang.Object obj7 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=a]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=a]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 'a' + "'", obj3.equals('a'));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=a]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=a]"));
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + 'a' + "'", obj5.equals('a'));
        org.junit.Assert.assertTrue("'" + obj7 + "' != '" + 'a' + "'", obj7.equals('a'));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass13 = simpleTimePeriod12.getClass();
        long long14 = simpleTimePeriod12.getEndMillis();
        long long15 = simpleTimePeriod12.getStartMillis();
        java.util.Date date16 = simpleTimePeriod12.getStart();
        boolean boolean17 = day6.equals((java.lang.Object) date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16, timeZone18);
        long long20 = day19.getMiddleMillisecond();
        int int21 = day19.getMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int24 = timePeriodValues23.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timePeriodValues23.addChangeListener(seriesChangeListener25);
        int int27 = timePeriodValues23.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean30 = timePeriodValues29.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timePeriodValues29.addChangeListener(seriesChangeListener31);
        timePeriodValues29.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj38 = null;
        boolean boolean39 = simpleTimePeriod37.equals(obj38);
        java.util.Date date40 = simpleTimePeriod37.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        timePeriodValues29.add((org.jfree.data.time.TimePeriod) day41, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day41.next();
        long long45 = day41.getSerialIndex();
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) day41, (java.lang.Number) 1);
        boolean boolean48 = day19.equals((java.lang.Object) day41);
        long long49 = day41.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-14400001L) + "'", long20 == (-14400001L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 25568L + "'", long45 == 25568L);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 28799999L + "'", long49 == 28799999L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        long long9 = day6.getMiddleMillisecond();
        long long10 = day6.getSerialIndex();
        int int11 = day6.getYear();
        java.util.Date date12 = day6.getStart();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-14400001L) + "'", long9 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        boolean boolean7 = timePeriodValues1.isEmpty();
        timePeriodValues1.setDescription("org.jfree.data.general.SeriesException: hi!");
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + ' ' + "'", comparable6.equals(' '));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        int int16 = day13.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue18 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) (byte) 100);
        org.jfree.data.time.TimePeriod timePeriod19 = timePeriodValue18.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod20 = timePeriodValue18.getPeriod();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertNotNull(timePeriod19);
        org.junit.Assert.assertNotNull(timePeriod20);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, 5L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int2 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        int int5 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean8 = timePeriodValues7.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener9);
        timePeriodValues7.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj16 = null;
        boolean boolean17 = simpleTimePeriod15.equals(obj16);
        java.util.Date date18 = simpleTimePeriod15.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day19.next();
        long long23 = day19.getSerialIndex();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) 1);
        try {
            timePeriodValues1.delete((int) (byte) 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 25568L + "'", long23 == 25568L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.TimePeriodValues timePeriodValues2 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean3 = timePeriodValues2.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues2.addChangeListener(seriesChangeListener4);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues2.addChangeListener(seriesChangeListener6);
        int int8 = year0.compareTo((java.lang.Object) timePeriodValues2);
        java.lang.String str9 = timePeriodValues2.getDescription();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        long long10 = day6.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate11 = day6.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day6.next();
        long long13 = regularTimePeriod12.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod12);
        try {
            timePeriodValues14.update(4, (java.lang.Number) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 71999999L + "'", long13 == 71999999L);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.fireSeriesChanged();
        java.lang.Comparable comparable7 = timePeriodValues1.getKey();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + ' ' + "'", comparable7.equals(' '));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.Object obj4 = seriesChangeEvent1.getSource();
        java.lang.String str5 = seriesChangeEvent1.toString();
        java.lang.String str6 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 'a' + "'", obj2.equals('a'));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 'a' + "'", obj3.equals('a'));
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + 'a' + "'", obj4.equals('a'));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=a]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=a]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=a]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=a]"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        java.lang.String str8 = day6.toString();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31-December-1969" + "'", str8.equals("31-December-1969"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("1969");
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year1, (double) (-1L));
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        java.util.Date date7 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date5, date7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues8.setKey((java.lang.Comparable) 'a');
        boolean boolean11 = timePeriodValues1.equals((java.lang.Object) 'a');
        int int12 = timePeriodValues1.getMinMiddleIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj16 = null;
        boolean boolean17 = simpleTimePeriod15.equals(obj16);
        java.util.Date date18 = simpleTimePeriod15.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        boolean boolean21 = day19.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
        long long23 = day19.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate24 = day19.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        long long26 = regularTimePeriod25.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod25, (double) 28799999L);
        timePeriodValues1.add(timePeriodValue28);
        java.lang.String str30 = timePeriodValues1.getDescription();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 25568L + "'", long23 == 25568L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 71999999L + "'", long26 == 71999999L);
        org.junit.Assert.assertNull(str30);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        int int10 = day6.getYear();
        int int11 = day6.getYear();
        java.util.Date date12 = day6.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
        int int14 = timePeriodValues13.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        java.lang.String str7 = timePeriodValues1.getDescription();
        boolean boolean8 = timePeriodValues1.isEmpty();
        timePeriodValues1.setKey((java.lang.Comparable) 5);
        java.lang.String str11 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        boolean boolean7 = timePeriodValues1.isEmpty();
        java.lang.String str8 = timePeriodValues1.getDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues12.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues12.removeChangeListener(seriesChangeListener15);
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "", "Value");
        timePeriodValues20.fireSeriesChanged();
        boolean boolean22 = timePeriodValues12.equals((java.lang.Object) timePeriodValues20);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj26 = null;
        boolean boolean27 = simpleTimePeriod25.equals(obj26);
        java.util.Date date28 = simpleTimePeriod25.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        boolean boolean31 = day29.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate32 = day29.getSerialDate();
        long long33 = day29.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day29.previous();
        timePeriodValues12.add((org.jfree.data.time.TimePeriod) regularTimePeriod34, (java.lang.Number) (short) 1);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod34, (java.lang.Number) (short) 1);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + ' ' + "'", comparable6.equals(' '));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 25568L + "'", long33 == 25568L);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        int int3 = timePeriodValues1.getMaxStartIndex();
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        java.lang.String str5 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean8 = timePeriodValues7.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener9);
        timePeriodValues7.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj16 = null;
        boolean boolean17 = simpleTimePeriod15.equals(obj16);
        java.util.Date date18 = simpleTimePeriod15.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) 100);
        int int22 = day19.getMonth();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj26 = null;
        boolean boolean27 = simpleTimePeriod25.equals(obj26);
        java.util.Date date28 = simpleTimePeriod25.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        boolean boolean31 = day29.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate32 = day29.getSerialDate();
        int int33 = day29.getYear();
        long long34 = day29.getFirstMillisecond();
        int int35 = day19.compareTo((java.lang.Object) long34);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) (short) -1);
        java.util.Calendar calendar38 = null;
        try {
            long long39 = day19.getFirstMillisecond(calendar38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1969 + "'", int33 == 1969);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-57600000L) + "'", long34 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "", "Value");
        timePeriodValues9.fireSeriesChanged();
        boolean boolean11 = timePeriodValues1.equals((java.lang.Object) timePeriodValues9);
        int int12 = timePeriodValues9.getMaxMiddleIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj16 = null;
        boolean boolean17 = simpleTimePeriod15.equals(obj16);
        java.util.Date date18 = simpleTimePeriod15.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        boolean boolean21 = day19.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day23.previous();
        timePeriodValues9.setKey((java.lang.Comparable) day23);
        java.util.Calendar calendar27 = null;
        try {
            day23.peg(calendar27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        java.lang.String str5 = timePeriodValues1.getDescription();
        java.lang.Object obj6 = timePeriodValues1.clone();
        timePeriodValues1.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        long long9 = day6.getMiddleMillisecond();
        long long10 = day6.getSerialIndex();
        int int11 = day6.getDayOfMonth();
        long long12 = day6.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-14400001L) + "'", long9 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 31 + "'", int11 == 31);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 25568L + "'", long12 == 25568L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        long long9 = day6.getMiddleMillisecond();
        java.lang.String str10 = day6.toString();
        java.util.Date date11 = day6.getStart();
        long long12 = day6.getLastMillisecond();
        long long13 = day6.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-14400001L) + "'", long9 == (-14400001L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "31-December-1969" + "'", str10.equals("31-December-1969"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 25568L + "'", long13 == 25568L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        long long10 = day6.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate11 = day6.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day6.next();
        long long13 = day6.getSerialIndex();
        java.util.Calendar calendar14 = null;
        try {
            long long15 = day6.getFirstMillisecond(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 25568L + "'", long13 == 25568L);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 11);
        long long10 = simpleTimePeriod9.getStartMillis();
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) simpleTimePeriod9, (double) (short) 100);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues6.removePropertyChangeListener(propertyChangeListener13);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        boolean boolean7 = timePeriodValues1.isEmpty();
        java.lang.String str8 = timePeriodValues1.getDescription();
        timePeriodValues1.setNotify(false);
        int int11 = timePeriodValues1.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + ' ' + "'", comparable6.equals(' '));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setKey((java.lang.Comparable) 'a');
        int int4 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setNotify(false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        long long9 = day6.getMiddleMillisecond();
        long long10 = day6.getSerialIndex();
        java.util.Date date11 = day6.getStart();
        org.jfree.data.general.SeriesException seriesException13 = new org.jfree.data.general.SeriesException("");
        int int14 = day6.compareTo((java.lang.Object) seriesException13);
        java.lang.String str15 = seriesException13.toString();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj19 = null;
        boolean boolean20 = simpleTimePeriod18.equals(obj19);
        java.util.Date date21 = simpleTimePeriod18.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        boolean boolean24 = day22.equals((java.lang.Object) '4');
        long long25 = day22.getMiddleMillisecond();
        long long26 = day22.getSerialIndex();
        java.util.Date date27 = day22.getStart();
        org.jfree.data.general.SeriesException seriesException29 = new org.jfree.data.general.SeriesException("");
        int int30 = day22.compareTo((java.lang.Object) seriesException29);
        seriesException13.addSuppressed((java.lang.Throwable) seriesException29);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-14400001L) + "'", long9 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str15.equals("org.jfree.data.general.SeriesException: "));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-14400001L) + "'", long25 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 25568L + "'", long26 == 25568L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        int int16 = day13.getMonth();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj20 = null;
        boolean boolean21 = simpleTimePeriod19.equals(obj20);
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        boolean boolean25 = day23.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate26 = day23.getSerialDate();
        int int27 = day23.getYear();
        long long28 = day23.getFirstMillisecond();
        int int29 = day13.compareTo((java.lang.Object) long28);
        java.util.Calendar calendar30 = null;
        try {
            long long31 = day13.getFirstMillisecond(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-57600000L) + "'", long28 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getMinStartIndex();
        boolean boolean7 = timePeriodValues1.isEmpty();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        timePeriodValues1.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj13 = null;
        boolean boolean14 = simpleTimePeriod12.equals(obj13);
        java.util.Date date15 = simpleTimePeriod12.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        boolean boolean18 = day16.equals((java.lang.Object) '4');
        timePeriodValues1.setKey((java.lang.Comparable) '4');
        int int20 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        long long10 = day6.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate11 = day6.getSerialDate();
        int int12 = day6.getDayOfMonth();
        int int13 = day6.getYear();
        java.lang.String str14 = day6.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 31 + "'", int12 == 31);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1969 + "'", int13 == 1969);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "31-December-1969" + "'", str14.equals("31-December-1969"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: Value");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date5, "org.jfree.data.general.SeriesException: hi!", "hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj12 = null;
        boolean boolean13 = simpleTimePeriod11.equals(obj12);
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(date5, date14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.util.Date date19 = simpleTimePeriod18.getStart();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19, timeZone20);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.util.Date date25 = simpleTimePeriod24.getStart();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date25, timeZone26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date19, timeZone26);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date5, timeZone26);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        long long8 = year7.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1969L + "'", long8 == 1969L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date5, "org.jfree.data.general.SeriesException: hi!", "hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj12 = null;
        boolean boolean13 = simpleTimePeriod11.equals(obj12);
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(date5, date14);
        org.jfree.data.time.TimePeriodValue timePeriodValue17 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod15, (double) 1);
        java.lang.Number number18 = timePeriodValue17.getValue();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.0d + "'", number18.equals(1.0d));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3, "Value", "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=a]");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (double) 0);
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date3, date14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues19.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues19.addPropertyChangeListener(propertyChangeListener22);
        java.lang.Object obj24 = timePeriodValues19.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = timePeriodValues19.createCopy(6, 1);
        boolean boolean28 = year17.equals((java.lang.Object) timePeriodValues27);
        long long29 = year17.getSerialIndex();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(obj24);
        org.junit.Assert.assertNotNull(timePeriodValues27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1969L + "'", long29 == 1969L);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 'a');
        boolean boolean2 = timePeriodValues1.isEmpty();
        int int3 = timePeriodValues1.getItemCount();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener4);
        boolean boolean6 = timePeriodValues1.getNotify();
        java.lang.String str7 = timePeriodValues1.getDomainDescription();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Time" + "'", str7.equals("Time"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getLastMillisecond();
        java.lang.String str12 = year7.toString();
        long long13 = year7.getLastMillisecond();
        java.util.Calendar calendar14 = null;
        try {
            year7.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969" + "'", str12.equals("1969"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28799999L + "'", long13 == 28799999L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        boolean boolean41 = day12.equals((java.lang.Object) 1L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod44.equals(obj45);
        java.util.Date date47 = simpleTimePeriod44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        boolean boolean50 = day48.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate51 = day48.getSerialDate();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
        boolean boolean53 = day12.equals((java.lang.Object) serialDate51);
        int int54 = day12.getYear();
        long long55 = day12.getFirstMillisecond();
        long long56 = day12.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1969 + "'", int54 == 1969);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-57600000L) + "'", long55 == (-57600000L));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-57600000L) + "'", long56 == (-57600000L));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener4);
        java.lang.Object obj6 = timePeriodValues1.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = timePeriodValues1.createCopy(6, 1);
        java.lang.Number number11 = null;
        try {
            timePeriodValues9.update(100, number11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(timePeriodValues9);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TimePeriodValue[1-January-1970,2.8799999E7]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(100L, (-57600000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        int int3 = timePeriodValues1.getMaxStartIndex();
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        java.lang.Class<?> wildcardClass5 = timePeriodValues1.getClass();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.Object obj6 = timePeriodValues1.clone();
        try {
            java.lang.Number number8 = timePeriodValues1.getValue((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(12, 4);
        int int7 = timePeriodValues6.getMaxMiddleIndex();
        boolean boolean8 = timePeriodValues6.isEmpty();
        try {
            timePeriodValues6.delete(0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        java.lang.Comparable comparable7 = timePeriodValues1.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        boolean boolean12 = simpleTimePeriod10.equals((java.lang.Object) 0.0d);
        boolean boolean13 = timePeriodValues1.equals((java.lang.Object) 0.0d);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener14);
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener16);
        int int18 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + ' ' + "'", comparable7.equals(' '));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date5, "org.jfree.data.general.SeriesException: hi!", "hi!");
        int int9 = timePeriodValues8.getMaxEndIndex();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        timePeriodValues1.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj13 = null;
        boolean boolean14 = simpleTimePeriod12.equals(obj13);
        java.util.Date date15 = simpleTimePeriod12.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        boolean boolean18 = day16.equals((java.lang.Object) '4');
        timePeriodValues1.setKey((java.lang.Comparable) '4');
        org.jfree.data.general.SeriesChangeListener seriesChangeListener20 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener20);
        try {
            org.jfree.data.time.TimePeriod timePeriod23 = timePeriodValues1.getTimePeriod((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
        java.lang.String str2 = seriesException1.toString();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str6 = timePeriodFormatException5.toString();
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: Value" + "'", str2.equals("org.jfree.data.general.SeriesException: Value"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str6.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "", "Value");
        timePeriodValues9.fireSeriesChanged();
        boolean boolean11 = timePeriodValues1.equals((java.lang.Object) timePeriodValues9);
        java.lang.String str12 = timePeriodValues9.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timePeriodValues9.removePropertyChangeListener(propertyChangeListener13);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener6);
        try {
            java.lang.Number number9 = timePeriodValues1.getValue((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        long long7 = day6.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-14400001L) + "'", long7 == (-14400001L));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue8 = timePeriodValues1.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException5 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=a]");
        seriesException3.addSuppressed((java.lang.Throwable) timePeriodFormatException5);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException9 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=a]");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException9);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        long long10 = day6.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate11 = day6.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day6.next();
        long long13 = regularTimePeriod12.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod12, (double) 28799999L);
        java.lang.Number number16 = timePeriodValue15.getValue();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 71999999L + "'", long13 == 71999999L);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 2.8799999E7d + "'", number16.equals(2.8799999E7d));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "", "Value");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        int int7 = timePeriodValues3.getMinStartIndex();
        try {
            timePeriodValues3.update((int) (short) 10, (java.lang.Number) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 10, (long) ' ');
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 12);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        long long6 = simpleTimePeriod2.getStartMillis();
        long long7 = simpleTimePeriod2.getStartMillis();
        long long8 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        boolean boolean41 = day12.equals((java.lang.Object) 1L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod44.equals(obj45);
        java.util.Date date47 = simpleTimePeriod44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        boolean boolean50 = day48.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate51 = day48.getSerialDate();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
        boolean boolean53 = day12.equals((java.lang.Object) serialDate51);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(serialDate51);
        org.jfree.data.time.TimePeriodValue timePeriodValue56 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day54, (double) 10.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = day54.previous();
        java.util.Date date58 = regularTimePeriod57.getEnd();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(date58);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass3 = simpleTimePeriod2.getClass();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        boolean boolean15 = day13.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass20 = simpleTimePeriod19.getClass();
        long long21 = simpleTimePeriod19.getEndMillis();
        long long22 = simpleTimePeriod19.getStartMillis();
        java.util.Date date23 = simpleTimePeriod19.getStart();
        boolean boolean24 = day13.equals((java.lang.Object) date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date6, timeZone25);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass31 = simpleTimePeriod30.getClass();
        long long32 = simpleTimePeriod30.getEndMillis();
        long long33 = simpleTimePeriod30.getStartMillis();
        java.util.Date date34 = simpleTimePeriod30.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj38 = null;
        boolean boolean39 = simpleTimePeriod37.equals(obj38);
        java.util.Date date40 = simpleTimePeriod37.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        boolean boolean43 = day41.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate44 = day41.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass48 = simpleTimePeriod47.getClass();
        long long49 = simpleTimePeriod47.getEndMillis();
        long long50 = simpleTimePeriod47.getStartMillis();
        java.util.Date date51 = simpleTimePeriod47.getStart();
        boolean boolean52 = day41.equals((java.lang.Object) date51);
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date51, timeZone53);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date34, timeZone53);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date6, timeZone53);
        org.jfree.data.time.TimePeriodValue timePeriodValue58 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day56, (double) 11);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 10L + "'", long49 == 10L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(timeZone53);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        long long40 = day12.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-14400001L) + "'", long40 == (-14400001L));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass3 = simpleTimePeriod2.getClass();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getStart();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues9 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) simpleTimePeriod2, "org.jfree.data.general.SeriesException: hi!", "1969");
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        long long10 = day6.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day6.previous();
        java.util.Calendar calendar12 = null;
        try {
            long long13 = day6.getFirstMillisecond(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int2 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.delete(8, (int) (short) 0);
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener8);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        int int3 = timePeriodValues1.getMinEndIndex();
        boolean boolean4 = timePeriodValues1.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener5);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue8 = timePeriodValues1.getDataItem(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("31-December-1969");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass3 = simpleTimePeriod2.getClass();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        boolean boolean15 = day13.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass20 = simpleTimePeriod19.getClass();
        long long21 = simpleTimePeriod19.getEndMillis();
        long long22 = simpleTimePeriod19.getStartMillis();
        java.util.Date date23 = simpleTimePeriod19.getStart();
        boolean boolean24 = day13.equals((java.lang.Object) date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date6, timeZone25);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass31 = simpleTimePeriod30.getClass();
        long long32 = simpleTimePeriod30.getEndMillis();
        long long33 = simpleTimePeriod30.getStartMillis();
        java.util.Date date34 = simpleTimePeriod30.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj38 = null;
        boolean boolean39 = simpleTimePeriod37.equals(obj38);
        java.util.Date date40 = simpleTimePeriod37.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        boolean boolean43 = day41.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate44 = day41.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass48 = simpleTimePeriod47.getClass();
        long long49 = simpleTimePeriod47.getEndMillis();
        long long50 = simpleTimePeriod47.getStartMillis();
        java.util.Date date51 = simpleTimePeriod47.getStart();
        boolean boolean52 = day41.equals((java.lang.Object) date51);
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date51, timeZone53);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date34, timeZone53);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date6, timeZone53);
        int int57 = day56.getDayOfMonth();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 10L + "'", long49 == 10L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 31 + "'", int57 == 31);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        int int3 = timePeriodValues1.getMaxStartIndex();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener5);
        timePeriodValues1.delete((int) '4', 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getSerialIndex();
        long long12 = year7.getLastMillisecond();
        java.util.Date date13 = year7.getEnd();
        java.lang.Class<?> wildcardClass14 = date13.getClass();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1969L + "'", long11 == 1969L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        java.util.Date date6 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date12);
        java.lang.String str15 = year14.toString();
        long long16 = year14.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year14.next();
        long long18 = year14.getSerialIndex();
        long long19 = year14.getLastMillisecond();
        java.util.Date date20 = year14.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date6, date20);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod24, (double) 0);
        java.util.Date date27 = simpleTimePeriod24.getEnd();
        java.lang.Class class28 = null;
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass32 = simpleTimePeriod31.getClass();
        long long33 = simpleTimePeriod31.getEndMillis();
        long long34 = simpleTimePeriod31.getStartMillis();
        java.util.Date date35 = simpleTimePeriod31.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj39 = null;
        boolean boolean40 = simpleTimePeriod38.equals(obj39);
        java.util.Date date41 = simpleTimePeriod38.getEnd();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
        boolean boolean44 = day42.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate45 = day42.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod48 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass49 = simpleTimePeriod48.getClass();
        long long50 = simpleTimePeriod48.getEndMillis();
        long long51 = simpleTimePeriod48.getStartMillis();
        java.util.Date date52 = simpleTimePeriod48.getStart();
        boolean boolean53 = day42.equals((java.lang.Object) date52);
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date52, timeZone54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date35, timeZone54);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod59 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj60 = null;
        boolean boolean61 = simpleTimePeriod59.equals(obj60);
        java.util.Date date62 = simpleTimePeriod59.getEnd();
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date62);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod66 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj67 = null;
        boolean boolean68 = simpleTimePeriod66.equals(obj67);
        java.util.Date date69 = simpleTimePeriod66.getEnd();
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date69);
        org.jfree.data.time.Year year71 = new org.jfree.data.time.Year(date69);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod72 = new org.jfree.data.time.SimpleTimePeriod(date62, date69);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod73 = new org.jfree.data.time.SimpleTimePeriod(date35, date62);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod76 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj77 = null;
        boolean boolean78 = simpleTimePeriod76.equals(obj77);
        java.util.Date date79 = simpleTimePeriod76.getEnd();
        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day(date79);
        boolean boolean82 = day80.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate83 = day80.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod86 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass87 = simpleTimePeriod86.getClass();
        long long88 = simpleTimePeriod86.getEndMillis();
        long long89 = simpleTimePeriod86.getStartMillis();
        java.util.Date date90 = simpleTimePeriod86.getStart();
        boolean boolean91 = day80.equals((java.lang.Object) date90);
        java.util.TimeZone timeZone92 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day93 = new org.jfree.data.time.Day(date90, timeZone92);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date35, timeZone92);
        org.jfree.data.time.Year year95 = new org.jfree.data.time.Year(date27, timeZone92);
        org.jfree.data.time.Day day96 = new org.jfree.data.time.Day(date20, timeZone92);
        java.lang.String str97 = day96.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969" + "'", str15.equals("1969"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28799999L + "'", long16 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1969L + "'", long18 == 1969L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28799999L + "'", long19 == 28799999L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 10L + "'", long33 == 10L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 10L + "'", long50 == 10L);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(serialDate83);
        org.junit.Assert.assertNotNull(wildcardClass87);
        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 10L + "'", long88 == 10L);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 0L + "'", long89 == 0L);
        org.junit.Assert.assertNotNull(date90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(timeZone92);
        org.junit.Assert.assertNull(regularTimePeriod94);
        org.junit.Assert.assertTrue("'" + str97 + "' != '" + "31-December-1969" + "'", str97.equals("31-December-1969"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "", "Value");
        timePeriodValues3.fireSeriesChanged();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener5);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues8.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues8.removeChangeListener(seriesChangeListener11);
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "", "Value");
        timePeriodValues16.fireSeriesChanged();
        boolean boolean18 = timePeriodValues8.equals((java.lang.Object) timePeriodValues16);
        boolean boolean19 = timePeriodValues3.equals((java.lang.Object) timePeriodValues16);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener20);
        int int22 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date5, "org.jfree.data.general.SeriesException: hi!", "hi!");
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        java.util.Date date10 = day9.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date5, date10);
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (double) '#');
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        boolean boolean41 = day12.equals((java.lang.Object) 1L);
        int int42 = day12.getMonth();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 12 + "'", int42 == 12);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass13 = simpleTimePeriod12.getClass();
        long long14 = simpleTimePeriod12.getEndMillis();
        long long15 = simpleTimePeriod12.getStartMillis();
        java.util.Date date16 = simpleTimePeriod12.getStart();
        boolean boolean17 = day6.equals((java.lang.Object) date16);
        java.lang.String str18 = day6.toString();
        java.util.Calendar calendar19 = null;
        try {
            long long20 = day6.getMiddleMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "31-December-1969" + "'", str18.equals("31-December-1969"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-14400001L), 0L);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[31-December-1969,100]");
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
        long long9 = day8.getSerialIndex();
        int int10 = day8.getDayOfMonth();
        java.util.Date date11 = day8.getStart();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 25568L + "'", long9 == 25568L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(12, 4);
        int int7 = timePeriodValues6.getMaxMiddleIndex();
        int int8 = timePeriodValues6.getMaxEndIndex();
        timePeriodValues6.setDescription("TimePeriodValue[1-January-1970,2.8799999E7]");
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        boolean boolean41 = day12.equals((java.lang.Object) 1L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod44.equals(obj45);
        java.util.Date date47 = simpleTimePeriod44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        boolean boolean50 = day48.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate51 = day48.getSerialDate();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
        boolean boolean53 = day12.equals((java.lang.Object) serialDate51);
        int int54 = day12.getYear();
        java.util.Date date55 = day12.getStart();
        int int56 = day12.getDayOfMonth();
        java.util.Calendar calendar57 = null;
        try {
            long long58 = day12.getLastMillisecond(calendar57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1969 + "'", int54 == 1969);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 31 + "'", int56 == 31);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getFirstMillisecond();
        long long10 = year7.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year7.previous();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-31507200000L) + "'", long9 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1969L + "'", long10 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("1969");
        int int2 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.next();
        long long4 = regularTimePeriod3.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 15796799999L + "'", long4 == 15796799999L);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        long long16 = day13.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day13.previous();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28799999L + "'", long16 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        int int16 = day13.getMonth();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj20 = null;
        boolean boolean21 = simpleTimePeriod19.equals(obj20);
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        boolean boolean25 = day23.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate26 = day23.getSerialDate();
        int int27 = day23.getYear();
        long long28 = day23.getFirstMillisecond();
        int int29 = day13.compareTo((java.lang.Object) long28);
        int int30 = day13.getDayOfMonth();
        java.lang.String str31 = day13.toString();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-57600000L) + "'", long28 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 31 + "'", int30 == 31);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "31-December-1969" + "'", str31.equals("31-December-1969"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod4 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.util.Date date5 = simpleTimePeriod4.getStart();
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5, timeZone6);
        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date5, timeZone8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date1, timeZone8);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(timeZone8);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getSerialIndex();
        long long12 = year7.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, (double) 12);
        java.lang.String str15 = year7.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1969L + "'", long11 == 1969L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28799999L + "'", long12 == 28799999L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969" + "'", str15.equals("1969"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getFirstMillisecond();
        long long10 = year7.getLastMillisecond();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = year7.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-31507200000L) + "'", long9 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28799999L + "'", long10 == 28799999L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        int int10 = day6.getYear();
        int int11 = day6.getYear();
        java.util.Date date12 = day6.getStart();
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day6, (double) (short) 0);
        long long15 = day6.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 25568L + "'", long15 == 25568L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date5, "org.jfree.data.general.SeriesException: hi!", "hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj12 = null;
        boolean boolean13 = simpleTimePeriod11.equals(obj12);
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(date5, date14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod18, (double) 0);
        java.lang.Number number21 = timePeriodValue20.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj25 = null;
        boolean boolean26 = simpleTimePeriod24.equals(obj25);
        java.util.Date date27 = simpleTimePeriod24.getEnd();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        boolean boolean30 = day28.equals((java.lang.Object) '4');
        long long31 = day28.getMiddleMillisecond();
        long long32 = day28.getFirstMillisecond();
        boolean boolean33 = timePeriodValue20.equals((java.lang.Object) day28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day28.next();
        java.lang.String str35 = day28.toString();
        java.lang.Object obj36 = null;
        boolean boolean37 = day28.equals(obj36);
        try {
            int int38 = simpleTimePeriod15.compareTo(obj36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0.0d + "'", number21.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-14400001L) + "'", long31 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-57600000L) + "'", long32 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "31-December-1969" + "'", str35.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass13 = simpleTimePeriod12.getClass();
        long long14 = simpleTimePeriod12.getEndMillis();
        long long15 = simpleTimePeriod12.getStartMillis();
        java.util.Date date16 = simpleTimePeriod12.getStart();
        boolean boolean17 = day6.equals((java.lang.Object) date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16, timeZone18);
        java.util.Date date20 = day19.getStart();
        java.util.Date date21 = day19.getStart();
        java.util.Calendar calendar22 = null;
        try {
            long long23 = day19.getFirstMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.TimePeriod timePeriod6 = timePeriodValue4.getPeriod();
        org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValue4.getPeriod();
        java.lang.Number number8 = timePeriodValue4.getValue();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertNotNull(timePeriod6);
        org.junit.Assert.assertNotNull(timePeriod7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.0d + "'", number8.equals(0.0d));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        int int3 = timePeriodValues1.getMaxStartIndex();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener5);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener7 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener7);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj12 = null;
        boolean boolean13 = simpleTimePeriod11.equals(obj12);
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        boolean boolean17 = day15.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate18 = day15.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass22 = simpleTimePeriod21.getClass();
        long long23 = simpleTimePeriod21.getEndMillis();
        long long24 = simpleTimePeriod21.getStartMillis();
        java.util.Date date25 = simpleTimePeriod21.getStart();
        boolean boolean26 = day15.equals((java.lang.Object) date25);
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date25, timeZone27);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day28, (java.lang.Number) 25568L);
        java.util.Calendar calendar31 = null;
        try {
            long long32 = day28.getFirstMillisecond(calendar31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(timeZone27);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3, "Value", "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=a]");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (double) 0);
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date3, date14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date3);
        java.lang.String str18 = year17.toString();
        java.util.Calendar calendar19 = null;
        try {
            long long20 = year17.getFirstMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969" + "'", str18.equals("1969"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass3 = simpleTimePeriod2.getClass();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        boolean boolean15 = day13.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass20 = simpleTimePeriod19.getClass();
        long long21 = simpleTimePeriod19.getEndMillis();
        long long22 = simpleTimePeriod19.getStartMillis();
        java.util.Date date23 = simpleTimePeriod19.getStart();
        boolean boolean24 = day13.equals((java.lang.Object) date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date6, timeZone25);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj31 = null;
        boolean boolean32 = simpleTimePeriod30.equals(obj31);
        java.util.Date date33 = simpleTimePeriod30.getEnd();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj38 = null;
        boolean boolean39 = simpleTimePeriod37.equals(obj38);
        java.util.Date date40 = simpleTimePeriod37.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date40);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod(date33, date40);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod(date6, date33);
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date33, timeZone45);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod49 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj50 = null;
        boolean boolean51 = simpleTimePeriod49.equals(obj50);
        java.util.Date date52 = simpleTimePeriod49.getEnd();
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date52);
        boolean boolean55 = day53.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate56 = day53.getSerialDate();
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(serialDate56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = day57.previous();
        int int59 = day57.getYear();
        java.util.Date date60 = day57.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod63 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.util.Date date64 = simpleTimePeriod63.getStart();
        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year(date64, timeZone65);
        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year(date64, timeZone67);
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date60, timeZone67);
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date33, timeZone67);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(serialDate56);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1969 + "'", int59 == 1969);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertNotNull(timeZone65);
        org.junit.Assert.assertNotNull(timeZone67);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day12.next();
        java.lang.String str19 = day12.toString();
        java.util.Calendar calendar20 = null;
        try {
            long long21 = day12.getFirstMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "31-December-1969" + "'", str19.equals("31-December-1969"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year7.next();
        long long13 = year7.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1969L + "'", long11 == 1969L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-31507200000L) + "'", long13 == (-31507200000L));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3, "Value", "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=a]");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (double) 0);
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date3, date14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date3);
        java.lang.String str18 = year17.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.previous();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1969" + "'", str18.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: ");
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj43 = null;
        boolean boolean44 = simpleTimePeriod42.equals(obj43);
        java.util.Date date45 = simpleTimePeriod42.getEnd();
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date45);
        boolean boolean48 = day46.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate49 = day46.getSerialDate();
        long long50 = day46.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate51 = day46.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = day46.next();
        timePeriodValues28.add((org.jfree.data.time.TimePeriod) day46, (java.lang.Number) 71999999L);
        timePeriodValues28.setRangeDescription("hi!");
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(date45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 25568L + "'", long50 == 25568L);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        java.lang.Number number18 = timePeriodValue4.getValue();
        java.lang.Number number19 = timePeriodValue4.getValue();
        java.lang.Object obj20 = timePeriodValue4.clone();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 0.0d + "'", number18.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0.0d + "'", number19.equals(0.0d));
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        boolean boolean41 = day12.equals((java.lang.Object) 1L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod44.equals(obj45);
        java.util.Date date47 = simpleTimePeriod44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        boolean boolean50 = day48.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate51 = day48.getSerialDate();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
        boolean boolean53 = day12.equals((java.lang.Object) serialDate51);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(serialDate51);
        java.util.Date date55 = day54.getEnd();
        org.jfree.data.time.SerialDate serialDate56 = day54.getSerialDate();
        java.util.Calendar calendar57 = null;
        try {
            long long58 = day54.getFirstMillisecond(calendar57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(serialDate56);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 11);
        long long10 = simpleTimePeriod9.getStartMillis();
        timePeriodValues6.add((org.jfree.data.time.TimePeriod) simpleTimePeriod9, (double) (short) 100);
        java.util.Date date13 = simpleTimePeriod9.getStart();
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Date date1 = day0.getStart();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod5 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod5, (double) 0);
        java.lang.Number number8 = timePeriodValue7.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj12 = null;
        boolean boolean13 = simpleTimePeriod11.equals(obj12);
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        boolean boolean17 = day15.equals((java.lang.Object) '4');
        long long18 = day15.getMiddleMillisecond();
        long long19 = day15.getFirstMillisecond();
        boolean boolean20 = timePeriodValue7.equals((java.lang.Object) day15);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj24 = null;
        boolean boolean25 = simpleTimePeriod23.equals(obj24);
        java.util.Date date26 = simpleTimePeriod23.getEnd();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date26);
        int int29 = day15.compareTo((java.lang.Object) date26);
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues31.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = timePeriodValues31.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues38 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues38.setKey((java.lang.Comparable) 'a');
        boolean boolean41 = timePeriodValues31.equals((java.lang.Object) 'a');
        boolean boolean42 = day15.equals((java.lang.Object) timePeriodValues31);
        boolean boolean44 = day15.equals((java.lang.Object) 1L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj48 = null;
        boolean boolean49 = simpleTimePeriod47.equals(obj48);
        java.util.Date date50 = simpleTimePeriod47.getEnd();
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date50);
        boolean boolean53 = day51.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate54 = day51.getSerialDate();
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(serialDate54);
        boolean boolean56 = day15.equals((java.lang.Object) serialDate54);
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(serialDate54);
        boolean boolean58 = year2.equals((java.lang.Object) serialDate54);
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(serialDate54);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.0d + "'", number8.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-14400001L) + "'", long18 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-57600000L) + "'", long19 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues36);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(serialDate54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        boolean boolean7 = timePeriodValues1.isEmpty();
        java.lang.String str8 = timePeriodValues1.getDescription();
        java.lang.Comparable comparable9 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = null;
        try {
            timePeriodValues1.add(timePeriodValue10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + ' ' + "'", comparable6.equals(' '));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + comparable9 + "' != '" + ' ' + "'", comparable9.equals(' '));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day10.previous();
        org.jfree.data.time.SerialDate serialDate12 = day10.getSerialDate();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(12, 4);
        int int7 = timePeriodValues6.getMaxMiddleIndex();
        int int8 = timePeriodValues6.getMaxEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener9 = null;
        timePeriodValues6.addPropertyChangeListener(propertyChangeListener9);
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("1969");
        int int2 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues5 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean6 = year1.equals((java.lang.Object) timePeriodValues5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod9, (double) 0);
        java.lang.Number number12 = timePeriodValue11.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj16 = null;
        boolean boolean17 = simpleTimePeriod15.equals(obj16);
        java.util.Date date18 = simpleTimePeriod15.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        boolean boolean21 = day19.equals((java.lang.Object) '4');
        long long22 = day19.getMiddleMillisecond();
        long long23 = day19.getFirstMillisecond();
        boolean boolean24 = timePeriodValue11.equals((java.lang.Object) day19);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj28 = null;
        boolean boolean29 = simpleTimePeriod27.equals(obj28);
        java.util.Date date30 = simpleTimePeriod27.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year(date30);
        int int33 = day19.compareTo((java.lang.Object) date30);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues35.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = timePeriodValues35.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues42.setKey((java.lang.Comparable) 'a');
        boolean boolean45 = timePeriodValues35.equals((java.lang.Object) 'a');
        boolean boolean46 = day19.equals((java.lang.Object) timePeriodValues35);
        boolean boolean48 = day19.equals((java.lang.Object) 1L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod51 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj52 = null;
        boolean boolean53 = simpleTimePeriod51.equals(obj52);
        java.util.Date date54 = simpleTimePeriod51.getEnd();
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date54);
        boolean boolean57 = day55.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate58 = day55.getSerialDate();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(serialDate58);
        boolean boolean60 = day19.equals((java.lang.Object) serialDate58);
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(serialDate58);
        java.util.Date date62 = day61.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues64 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int65 = timePeriodValues64.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener66 = null;
        timePeriodValues64.addChangeListener(seriesChangeListener66);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener68 = null;
        timePeriodValues64.addChangeListener(seriesChangeListener68);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener70 = null;
        timePeriodValues64.removeChangeListener(seriesChangeListener70);
        boolean boolean72 = day61.equals((java.lang.Object) timePeriodValues64);
        int int73 = timePeriodValues64.getMinStartIndex();
        int int74 = year1.compareTo((java.lang.Object) timePeriodValues64);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.0d + "'", number12.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-14400001L) + "'", long22 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-57600000L) + "'", long23 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues40);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(serialDate58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 25568L, "", "31-December-1969");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener4);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        int int10 = day6.getYear();
        int int11 = day6.getYear();
        java.util.Date date12 = day6.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date12);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener14 = null;
        timePeriodValues13.removeChangeListener(seriesChangeListener14);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertNotNull(date12);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod9, (java.lang.Number) 12);
        java.lang.String str12 = timePeriodValue11.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TimePeriodValue[1968,12]" + "'", str12.equals("TimePeriodValue[1968,12]"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int2 = timePeriodValues1.getMaxEndIndex();
        timePeriodValues1.setNotify(true);
        try {
            timePeriodValues1.update((int) '#', (java.lang.Number) (-47318400001L));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Object obj5 = timePeriodValue4.clone();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) long16);
        java.lang.String str18 = timePeriodValue4.toString();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, 10L);
        long long3 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str8 = seriesException7.toString();
        boolean boolean9 = timePeriodValues1.equals((java.lang.Object) seriesException7);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues1.createCopy(7, 0);
        timePeriodValues1.setDomainDescription("");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod17, (double) 0);
        java.lang.Number number20 = timePeriodValue19.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj24 = null;
        boolean boolean25 = simpleTimePeriod23.equals(obj24);
        java.util.Date date26 = simpleTimePeriod23.getEnd();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
        boolean boolean29 = day27.equals((java.lang.Object) '4');
        long long30 = day27.getMiddleMillisecond();
        long long31 = day27.getFirstMillisecond();
        boolean boolean32 = timePeriodValue19.equals((java.lang.Object) day27);
        java.lang.String str33 = day27.toString();
        long long34 = day27.getFirstMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day27, (double) 'a');
        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day27, "org.jfree.data.general.SeriesException: Value", "Time");
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str8.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(timePeriodValues12);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0d + "'", number20.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-14400001L) + "'", long30 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-57600000L) + "'", long31 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "31-December-1969" + "'", str33.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-57600000L) + "'", long34 == (-57600000L));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass13 = simpleTimePeriod12.getClass();
        long long14 = simpleTimePeriod12.getEndMillis();
        long long15 = simpleTimePeriod12.getStartMillis();
        java.util.Date date16 = simpleTimePeriod12.getStart();
        boolean boolean17 = day6.equals((java.lang.Object) date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16, timeZone18);
        long long20 = day19.getMiddleMillisecond();
        int int21 = day19.getMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int24 = timePeriodValues23.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timePeriodValues23.addChangeListener(seriesChangeListener25);
        int int27 = timePeriodValues23.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean30 = timePeriodValues29.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timePeriodValues29.addChangeListener(seriesChangeListener31);
        timePeriodValues29.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj38 = null;
        boolean boolean39 = simpleTimePeriod37.equals(obj38);
        java.util.Date date40 = simpleTimePeriod37.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        timePeriodValues29.add((org.jfree.data.time.TimePeriod) day41, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day41.next();
        long long45 = day41.getSerialIndex();
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) day41, (java.lang.Number) 1);
        boolean boolean48 = day19.equals((java.lang.Object) day41);
        int int49 = day19.getMonth();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-14400001L) + "'", long20 == (-14400001L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 25568L + "'", long45 == 25568L);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 12 + "'", int49 == 12);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        boolean boolean6 = timePeriodValues1.getNotify();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setKey((java.lang.Comparable) 'a');
        int int4 = timePeriodValues1.getItemCount();
        int int5 = timePeriodValues1.getMinEndIndex();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener6);
        java.lang.String str8 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        int int16 = day13.getMonth();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj20 = null;
        boolean boolean21 = simpleTimePeriod19.equals(obj20);
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        boolean boolean25 = day23.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate26 = day23.getSerialDate();
        int int27 = day23.getYear();
        long long28 = day23.getFirstMillisecond();
        int int29 = day13.compareTo((java.lang.Object) long28);
        long long30 = day13.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day13.next();
        long long32 = day13.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue34 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day13, (double) (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-57600000L) + "'", long28 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-14400001L) + "'", long30 == (-14400001L));
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 28799999L + "'", long32 == 28799999L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Object obj5 = timePeriodValue4.clone();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) long16);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues19.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues19.addPropertyChangeListener(propertyChangeListener22);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timePeriodValues19.removeChangeListener(seriesChangeListener24);
        boolean boolean26 = timePeriodValue4.equals((java.lang.Object) seriesChangeListener24);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timePeriodValues28.removeChangeListener(seriesChangeListener31);
        timePeriodValues28.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        timePeriodValues28.removeChangeListener(seriesChangeListener35);
        boolean boolean37 = timePeriodValues28.getNotify();
        int int38 = timePeriodValues28.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues40 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues40.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener43 = null;
        timePeriodValues40.removePropertyChangeListener(propertyChangeListener43);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener45 = null;
        timePeriodValues40.removeChangeListener(seriesChangeListener45);
        int int47 = timePeriodValues40.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener48 = null;
        timePeriodValues40.addChangeListener(seriesChangeListener48);
        boolean boolean50 = timePeriodValues28.equals((java.lang.Object) timePeriodValues40);
        java.lang.String str51 = timePeriodValues28.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener52 = null;
        timePeriodValues28.addPropertyChangeListener(propertyChangeListener52);
        boolean boolean54 = timePeriodValue4.equals((java.lang.Object) propertyChangeListener52);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "hi!" + "'", str51.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesChangeEvent[source=a]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues8.setKey((java.lang.Comparable) 'a');
        boolean boolean11 = timePeriodValues1.equals((java.lang.Object) 'a');
        int int12 = timePeriodValues1.getMinMiddleIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj16 = null;
        boolean boolean17 = simpleTimePeriod15.equals(obj16);
        java.util.Date date18 = simpleTimePeriod15.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        boolean boolean21 = day19.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
        long long23 = day19.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate24 = day19.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day19.next();
        long long26 = regularTimePeriod25.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod25, (double) 28799999L);
        timePeriodValues1.add(timePeriodValue28);
        timePeriodValues1.delete(0, 0);
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 25568L + "'", long23 == 25568L);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 71999999L + "'", long26 == 71999999L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setKey((java.lang.Comparable) 'a');
        int int4 = timePeriodValues1.getItemCount();
        int int5 = timePeriodValues1.getMinEndIndex();
        boolean boolean6 = timePeriodValues1.getNotify();
        java.lang.String str7 = timePeriodValues1.getDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        int int7 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues1.createCopy(12, 3);
        java.lang.String str11 = timePeriodValues10.getDomainDescription();
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + ' ' + "'", comparable6.equals(' '));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Time" + "'", str11.equals("Time"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.next();
        java.util.Calendar calendar10 = null;
        try {
            long long11 = year7.getMiddleMillisecond(calendar10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        int int5 = timePeriodValues1.getMaxStartIndex();
        timePeriodValues1.setNotify(true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass3 = simpleTimePeriod2.getClass();
        long long4 = simpleTimePeriod2.getEndMillis();
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass9 = simpleTimePeriod8.getClass();
        long long10 = simpleTimePeriod8.getEndMillis();
        long long11 = simpleTimePeriod8.getStartMillis();
        java.util.Date date12 = simpleTimePeriod8.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj16 = null;
        boolean boolean17 = simpleTimePeriod15.equals(obj16);
        java.util.Date date18 = simpleTimePeriod15.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        boolean boolean21 = day19.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass26 = simpleTimePeriod25.getClass();
        long long27 = simpleTimePeriod25.getEndMillis();
        long long28 = simpleTimePeriod25.getStartMillis();
        java.util.Date date29 = simpleTimePeriod25.getStart();
        boolean boolean30 = day19.equals((java.lang.Object) date29);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date29, timeZone31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date12, timeZone31);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass37 = simpleTimePeriod36.getClass();
        long long38 = simpleTimePeriod36.getEndMillis();
        long long39 = simpleTimePeriod36.getStartMillis();
        java.util.Date date40 = simpleTimePeriod36.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj44 = null;
        boolean boolean45 = simpleTimePeriod43.equals(obj44);
        java.util.Date date46 = simpleTimePeriod43.getEnd();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date46);
        boolean boolean49 = day47.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate50 = day47.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass54 = simpleTimePeriod53.getClass();
        long long55 = simpleTimePeriod53.getEndMillis();
        long long56 = simpleTimePeriod53.getStartMillis();
        java.util.Date date57 = simpleTimePeriod53.getStart();
        boolean boolean58 = day47.equals((java.lang.Object) date57);
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date57, timeZone59);
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date40, timeZone59);
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date12, timeZone59);
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date12);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date12);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod65 = new org.jfree.data.time.SimpleTimePeriod(date5, date12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 10L + "'", long38 == 10L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(serialDate50);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 10L + "'", long55 == 10L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(timeZone59);
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.util.Date date1 = day0.getStart();
//        java.util.Date date2 = day0.getStart();
//        long long3 = day0.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int2 = timePeriodValues1.getMaxEndIndex();
        java.lang.Comparable comparable3 = timePeriodValues1.getKey();
        int int4 = timePeriodValues1.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + ' ' + "'", comparable3.equals(' '));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        java.lang.String str5 = timePeriodValues1.getRangeDescription();
        timePeriodValues1.fireSeriesChanged();
        java.lang.String str7 = timePeriodValues1.getDescription();
        java.lang.String str8 = timePeriodValues1.getRangeDescription();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Value" + "'", str5.equals("Value"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Value" + "'", str8.equals("Value"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener16);
        int int18 = timePeriodValues1.getMaxEndIndex();
        java.lang.Class<?> wildcardClass19 = timePeriodValues1.getClass();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("1969");
        org.jfree.data.time.TimePeriodValue timePeriodValue3 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year1, 10.0d);
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=a]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        java.lang.Number number18 = timePeriodValue4.getValue();
        java.lang.Object obj19 = timePeriodValue4.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues21.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timePeriodValues21.removeChangeListener(seriesChangeListener24);
        java.lang.Comparable comparable26 = timePeriodValues21.getKey();
        int int27 = timePeriodValues21.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = timePeriodValues21.createCopy(12, 3);
        boolean boolean31 = timePeriodValue4.equals((java.lang.Object) timePeriodValues30);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues33.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener36 = null;
        timePeriodValues33.removeChangeListener(seriesChangeListener36);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "hi!", "", "Value");
        timePeriodValues41.fireSeriesChanged();
        boolean boolean43 = timePeriodValues33.equals((java.lang.Object) timePeriodValues41);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod46 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue48 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod46, (double) 0);
        java.lang.Number number49 = timePeriodValue48.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod52 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj53 = null;
        boolean boolean54 = simpleTimePeriod52.equals(obj53);
        java.util.Date date55 = simpleTimePeriod52.getEnd();
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date55);
        boolean boolean58 = day56.equals((java.lang.Object) '4');
        long long59 = day56.getMiddleMillisecond();
        long long60 = day56.getFirstMillisecond();
        boolean boolean61 = timePeriodValue48.equals((java.lang.Object) day56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = day56.next();
        java.lang.String str63 = day56.toString();
        timePeriodValues33.setKey((java.lang.Comparable) day56);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod67 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue69 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod67, (double) 0);
        java.lang.Number number70 = timePeriodValue69.getValue();
        java.lang.Number number71 = timePeriodValue69.getValue();
        org.jfree.data.time.TimePeriod timePeriod72 = timePeriodValue69.getPeriod();
        int int73 = day56.compareTo((java.lang.Object) timePeriodValue69);
        timePeriodValues30.add((org.jfree.data.time.TimePeriod) day56, (java.lang.Number) 100);
        java.util.Date date76 = day56.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod79 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj80 = null;
        boolean boolean81 = simpleTimePeriod79.equals(obj80);
        java.util.Date date82 = simpleTimePeriod79.getEnd();
        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day(date82);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod86 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj87 = null;
        boolean boolean88 = simpleTimePeriod86.equals(obj87);
        java.util.Date date89 = simpleTimePeriod86.getEnd();
        org.jfree.data.time.Day day90 = new org.jfree.data.time.Day(date89);
        org.jfree.data.time.Year year91 = new org.jfree.data.time.Year(date89);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod92 = new org.jfree.data.time.SimpleTimePeriod(date82, date89);
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod93 = new org.jfree.data.time.SimpleTimePeriod(date76, date89);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 0.0d + "'", number18.equals(0.0d));
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + comparable26 + "' != '" + ' ' + "'", comparable26.equals(' '));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + 0.0d + "'", number49.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-14400001L) + "'", long59 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-57600000L) + "'", long60 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "31-December-1969" + "'", str63.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + number70 + "' != '" + 0.0d + "'", number70.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number71 + "' != '" + 0.0d + "'", number71.equals(0.0d));
        org.junit.Assert.assertNotNull(timePeriod72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(date82);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(date89);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setNotify(false);
        timePeriodValues1.setDescription("hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(12, 4);
        int int7 = timePeriodValues1.getMaxMiddleIndex();
        int int8 = timePeriodValues1.getMaxEndIndex();
        boolean boolean9 = timePeriodValues1.getNotify();
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        long long9 = day6.getMiddleMillisecond();
        long long10 = day6.getSerialIndex();
        java.util.Date date11 = day6.getStart();
        int int12 = day6.getYear();
        long long13 = day6.getLastMillisecond();
        java.util.Date date14 = day6.getEnd();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-14400001L) + "'", long9 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1969 + "'", int12 == 1969);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28799999L + "'", long13 == 28799999L);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(1, 0, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass9 = simpleTimePeriod8.getClass();
        long long10 = simpleTimePeriod8.getEndMillis();
        long long11 = simpleTimePeriod8.getStartMillis();
        boolean boolean12 = simpleTimePeriod2.equals((java.lang.Object) long11);
        java.lang.Number number13 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue14 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, number13);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setKey((java.lang.Comparable) 'a');
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        boolean boolean5 = timePeriodValues1.getNotify();
        org.jfree.data.time.TimePeriod timePeriod6 = null;
        try {
            timePeriodValues1.add(timePeriod6, (double) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        int int16 = day13.getMonth();
        long long17 = day13.getLastMillisecond();
        int int18 = day13.getMonth();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28799999L + "'", long17 == 28799999L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Object obj5 = timePeriodValue4.clone();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate15 = day12.getSerialDate();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) long16);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues19.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener22 = null;
        timePeriodValues19.addPropertyChangeListener(propertyChangeListener22);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timePeriodValues19.removeChangeListener(seriesChangeListener24);
        boolean boolean26 = timePeriodValue4.equals((java.lang.Object) seriesChangeListener24);
        timePeriodValue4.setValue((java.lang.Number) 28799999L);
        org.jfree.data.time.TimePeriod timePeriod29 = timePeriodValue4.getPeriod();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(timePeriod29);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int2 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        int int5 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean8 = timePeriodValues7.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener9);
        timePeriodValues7.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj16 = null;
        boolean boolean17 = simpleTimePeriod15.equals(obj16);
        java.util.Date date18 = simpleTimePeriod15.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day19.next();
        long long23 = day19.getSerialIndex();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) 1);
        long long26 = day19.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 25568L + "'", long23 == 25568L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 25568L + "'", long26 == 25568L);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("1969");
        int int2 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.next();
        long long4 = year1.getSerialIndex();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1969 + "'", int2 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1969L + "'", long4 == 1969L);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        int int3 = timePeriodValues1.getMaxStartIndex();
        java.lang.String str4 = timePeriodValues1.getDomainDescription();
        java.lang.String str5 = timePeriodValues1.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean8 = timePeriodValues7.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener9 = null;
        timePeriodValues7.addChangeListener(seriesChangeListener9);
        timePeriodValues7.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj16 = null;
        boolean boolean17 = simpleTimePeriod15.equals(obj16);
        java.util.Date date18 = simpleTimePeriod15.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        timePeriodValues7.add((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) 100);
        int int22 = day19.getMonth();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj26 = null;
        boolean boolean27 = simpleTimePeriod25.equals(obj26);
        java.util.Date date28 = simpleTimePeriod25.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        boolean boolean31 = day29.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate32 = day29.getSerialDate();
        int int33 = day29.getYear();
        long long34 = day29.getFirstMillisecond();
        int int35 = day19.compareTo((java.lang.Object) long34);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day19, (java.lang.Number) (short) -1);
        int int38 = timePeriodValues1.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Time" + "'", str4.equals("Time"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(serialDate32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1969 + "'", int33 == 1969);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-57600000L) + "'", long34 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3, "Value", "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=a]");
        java.lang.String str9 = timePeriodValues8.getDomainDescription();
        timePeriodValues8.setNotify(true);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Value" + "'", str9.equals("Value"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day10, "Value", "org.jfree.data.general.SeriesException: hi!");
        long long14 = day10.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 25568L + "'", long14 == 25568L);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        long long9 = day6.getMiddleMillisecond();
        long long10 = day6.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day6.previous();
        org.jfree.data.time.SerialDate serialDate12 = day6.getSerialDate();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-14400001L) + "'", long9 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-57600000L) + "'", long10 == (-57600000L));
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(serialDate12);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.time.TimePeriodFormatException: ");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        int int6 = timePeriodValues1.getMaxMiddleIndex();
        timePeriodValues1.fireSeriesChanged();
        int int8 = timePeriodValues1.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.TimePeriod timePeriod18 = timePeriodValue4.getPeriod();
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue(timePeriod18, (java.lang.Number) 5L);
        java.lang.String str21 = timePeriodValue20.toString();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timePeriod18);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        boolean boolean15 = day13.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass20 = simpleTimePeriod19.getClass();
        long long21 = simpleTimePeriod19.getEndMillis();
        long long22 = simpleTimePeriod19.getStartMillis();
        java.util.Date date23 = simpleTimePeriod19.getStart();
        boolean boolean24 = day13.equals((java.lang.Object) date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date5, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues30.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timePeriodValues30.removePropertyChangeListener(propertyChangeListener33);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        timePeriodValues30.removeChangeListener(seriesChangeListener35);
        java.lang.Class<?> wildcardClass37 = timePeriodValues30.getClass();
        boolean boolean38 = year27.equals((java.lang.Object) wildcardClass37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year27.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year27.previous();
        java.util.Calendar calendar41 = null;
        try {
            long long42 = year27.getLastMillisecond(calendar41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        int int3 = timePeriodValues1.getMaxStartIndex();
        int int4 = timePeriodValues1.getMinMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener5);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue8 = timePeriodValues1.getDataItem((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(100, (int) 'a', 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 'a');
        java.lang.String str2 = seriesChangeEvent1.toString();
        java.lang.Object obj3 = seriesChangeEvent1.getSource();
        java.lang.String str4 = seriesChangeEvent1.toString();
        java.lang.String str5 = seriesChangeEvent1.toString();
        java.lang.String str6 = seriesChangeEvent1.toString();
        java.lang.String str7 = seriesChangeEvent1.toString();
        java.lang.String str8 = seriesChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=a]" + "'", str2.equals("org.jfree.data.general.SeriesChangeEvent[source=a]"));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 'a' + "'", obj3.equals('a'));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=a]" + "'", str4.equals("org.jfree.data.general.SeriesChangeEvent[source=a]"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=a]" + "'", str5.equals("org.jfree.data.general.SeriesChangeEvent[source=a]"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=a]" + "'", str6.equals("org.jfree.data.general.SeriesChangeEvent[source=a]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=a]" + "'", str7.equals("org.jfree.data.general.SeriesChangeEvent[source=a]"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=a]" + "'", str8.equals("org.jfree.data.general.SeriesChangeEvent[source=a]"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getFirstMillisecond();
        int int10 = year7.getYear();
        long long11 = year7.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-31507200000L) + "'", long9 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1969L + "'", long11 == 1969L);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesChangeEvent[source=a]");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str5 = timePeriodFormatException3.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=a]" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=a]"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date5, "org.jfree.data.general.SeriesException: hi!", "hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj12 = null;
        boolean boolean13 = simpleTimePeriod11.equals(obj12);
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod(date5, date14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.util.Date date19 = simpleTimePeriod18.getStart();
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19, timeZone20);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date19, timeZone22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date14, timeZone22);
        long long25 = year24.getSerialIndex();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1969L + "'", long25 == 1969L);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        boolean boolean41 = day12.equals((java.lang.Object) 1L);
        org.jfree.data.time.TimePeriodValue timePeriodValue43 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day12, (java.lang.Number) (short) 1);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getLastMillisecond();
        long long12 = year7.getFirstMillisecond();
        long long13 = year7.getFirstMillisecond();
        int int14 = year7.getYear();
        long long15 = year7.getFirstMillisecond();
        int int16 = year7.getYear();
        java.util.Calendar calendar17 = null;
        try {
            long long18 = year7.getFirstMillisecond(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-31507200000L) + "'", long12 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-31507200000L) + "'", long13 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1969 + "'", int14 == 1969);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-31507200000L) + "'", long15 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1969 + "'", int16 == 1969);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 10, (long) ' ');
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (java.lang.Number) 12);
        java.lang.String str5 = timePeriodValue4.toString();
        timePeriodValue4.setValue((java.lang.Number) 10.0f);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(4, (int) (short) 1, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(serialDate7);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate7);
        org.jfree.data.time.SerialDate serialDate10 = day9.getSerialDate();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int2 = timePeriodValues1.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener3);
        timePeriodValues1.fireSeriesChanged();
        java.lang.String str6 = timePeriodValues1.getDomainDescription();
        java.lang.String str7 = timePeriodValues1.getDescription();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getLastMillisecond();
        java.lang.String str12 = year7.toString();
        java.lang.String str13 = year7.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969" + "'", str12.equals("1969"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969" + "'", str13.equals("1969"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "Time", "org.jfree.data.general.SeriesException: hi!", "");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        java.lang.String str7 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        long long6 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 5L + "'", long6 == 5L);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int2 = timePeriodValues1.getMaxEndIndex();
        java.lang.Comparable comparable3 = timePeriodValues1.getKey();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues1.createCopy(9, (int) (byte) 1);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        boolean boolean15 = day13.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
        int int17 = day13.getYear();
        int int18 = day13.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day13.previous();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) regularTimePeriod19, (java.lang.Number) (-1L));
        try {
            org.jfree.data.time.TimePeriod timePeriod23 = timePeriodValues1.getTimePeriod((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + ' ' + "'", comparable3.equals(' '));
        org.junit.Assert.assertNotNull(timePeriodValues6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        java.lang.Number number18 = timePeriodValue4.getValue();
        java.lang.Object obj19 = timePeriodValue4.clone();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues21.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener24 = null;
        timePeriodValues21.removeChangeListener(seriesChangeListener24);
        java.lang.Comparable comparable26 = timePeriodValues21.getKey();
        int int27 = timePeriodValues21.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = timePeriodValues21.createCopy(12, 3);
        boolean boolean31 = timePeriodValue4.equals((java.lang.Object) timePeriodValues30);
        timePeriodValue4.setValue((java.lang.Number) (byte) -1);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 0.0d + "'", number18.equals(0.0d));
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + comparable26 + "' != '" + ' ' + "'", comparable26.equals(' '));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        timePeriodValues1.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener8);
        boolean boolean10 = timePeriodValues1.getNotify();
        int int11 = timePeriodValues1.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues13.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener16 = null;
        timePeriodValues13.removePropertyChangeListener(propertyChangeListener16);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timePeriodValues13.removeChangeListener(seriesChangeListener18);
        int int20 = timePeriodValues13.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener21 = null;
        timePeriodValues13.addChangeListener(seriesChangeListener21);
        boolean boolean23 = timePeriodValues1.equals((java.lang.Object) timePeriodValues13);
        int int24 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.time.TimePeriod timePeriod0 = null;
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue2 = new org.jfree.data.time.TimePeriodValue(timePeriod0, (double) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues1.getMinEndIndex();
        java.lang.Object obj7 = timePeriodValues1.clone();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) day10, "Value", "org.jfree.data.general.SeriesException: hi!");
        int int14 = timePeriodValues13.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.general.SeriesException: hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.String str5 = timePeriodFormatException4.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: " + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: "));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        boolean boolean15 = day13.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass20 = simpleTimePeriod19.getClass();
        long long21 = simpleTimePeriod19.getEndMillis();
        long long22 = simpleTimePeriod19.getStartMillis();
        java.util.Date date23 = simpleTimePeriod19.getStart();
        boolean boolean24 = day13.equals((java.lang.Object) date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date5, timeZone25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.previous();
        long long29 = year27.getSerialIndex();
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1969L + "'", long29 == 1969L);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass3 = simpleTimePeriod2.getClass();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        boolean boolean15 = day13.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass20 = simpleTimePeriod19.getClass();
        long long21 = simpleTimePeriod19.getEndMillis();
        long long22 = simpleTimePeriod19.getStartMillis();
        java.util.Date date23 = simpleTimePeriod19.getStart();
        boolean boolean24 = day13.equals((java.lang.Object) date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23, timeZone25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date6, timeZone25);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass31 = simpleTimePeriod30.getClass();
        long long32 = simpleTimePeriod30.getEndMillis();
        long long33 = simpleTimePeriod30.getStartMillis();
        java.util.Date date34 = simpleTimePeriod30.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj38 = null;
        boolean boolean39 = simpleTimePeriod37.equals(obj38);
        java.util.Date date40 = simpleTimePeriod37.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        boolean boolean43 = day41.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate44 = day41.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass48 = simpleTimePeriod47.getClass();
        long long49 = simpleTimePeriod47.getEndMillis();
        long long50 = simpleTimePeriod47.getStartMillis();
        java.util.Date date51 = simpleTimePeriod47.getStart();
        boolean boolean52 = day41.equals((java.lang.Object) date51);
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date51, timeZone53);
        org.jfree.data.time.Year year55 = new org.jfree.data.time.Year(date34, timeZone53);
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date6, timeZone53);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod59 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj60 = null;
        boolean boolean61 = simpleTimePeriod59.equals(obj60);
        java.util.Date date62 = simpleTimePeriod59.getEnd();
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date62);
        boolean boolean65 = day63.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate66 = day63.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod69 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass70 = simpleTimePeriod69.getClass();
        long long71 = simpleTimePeriod69.getEndMillis();
        long long72 = simpleTimePeriod69.getStartMillis();
        java.util.Date date73 = simpleTimePeriod69.getStart();
        boolean boolean74 = day63.equals((java.lang.Object) date73);
        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(date73, timeZone75);
        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day(date6, timeZone75);
        java.util.Date date78 = day77.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = day77.next();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 10L + "'", long32 == 10L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(serialDate44);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 10L + "'", long49 == 10L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(serialDate66);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 10L + "'", long71 == 10L);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 0L + "'", long72 == 0L);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(timeZone75);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNotNull(regularTimePeriod79);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        long long10 = day6.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate11 = day6.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day6.next();
        java.util.Calendar calendar13 = null;
        try {
            day6.peg(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.String str4 = seriesException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) seriesException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        seriesException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        org.jfree.data.general.SeriesException seriesException10 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: ");
        timePeriodFormatException7.addSuppressed((java.lang.Throwable) seriesException10);
        java.lang.Throwable[] throwableArray12 = timePeriodFormatException7.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str4.equals("org.jfree.data.general.SeriesException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day6.previous();
        java.util.Calendar calendar9 = null;
        try {
            long long10 = day6.getFirstMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.addPropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getRangeDescription();
        java.lang.Comparable comparable7 = timePeriodValues1.getKey();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod10 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        boolean boolean12 = simpleTimePeriod10.equals((java.lang.Object) 0.0d);
        boolean boolean13 = timePeriodValues1.equals((java.lang.Object) 0.0d);
        timePeriodValues1.setRangeDescription("");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + ' ' + "'", comparable7.equals(' '));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener4);
        java.lang.String str6 = timePeriodValues1.getDescription();
        java.lang.String str7 = timePeriodValues1.getDescription();
        boolean boolean8 = timePeriodValues1.isEmpty();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (double) 0);
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass18 = simpleTimePeriod17.getClass();
        long long19 = simpleTimePeriod17.getEndMillis();
        long long20 = simpleTimePeriod17.getStartMillis();
        boolean boolean21 = simpleTimePeriod11.equals((java.lang.Object) long20);
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (double) 28799999L);
        long long24 = simpleTimePeriod11.getStartMillis();
        java.util.Date date25 = simpleTimePeriod11.getStart();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        long long27 = day26.getFirstMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day26, (double) 1969L);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 10L + "'", long19 == 10L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-1L) + "'", long24 == (-1L));
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-57600000L) + "'", long27 == (-57600000L));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        long long3 = simpleTimePeriod2.getEndMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        java.util.Date date6 = simpleTimePeriod2.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        boolean boolean15 = day13.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate16 = day13.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass20 = simpleTimePeriod19.getClass();
        long long21 = simpleTimePeriod19.getEndMillis();
        long long22 = simpleTimePeriod19.getStartMillis();
        java.util.Date date23 = simpleTimePeriod19.getStart();
        boolean boolean24 = day13.equals((java.lang.Object) date23);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date23, timeZone25);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod27 = new org.jfree.data.time.SimpleTimePeriod(date6, date23);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeZone25);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        int int10 = day6.getYear();
        int int11 = day6.getYear();
        java.util.Date date12 = day6.getStart();
        long long13 = day6.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-57600000L) + "'", long13 == (-57600000L));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        boolean boolean7 = timePeriodValues1.isEmpty();
        java.lang.String str8 = timePeriodValues1.getDescription();
        timePeriodValues1.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timePeriodValues1.removePropertyChangeListener(propertyChangeListener11);
        timePeriodValues1.setDescription("1969");
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + ' ' + "'", comparable6.equals(' '));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setKey((java.lang.Comparable) 'a');
        timePeriodValues1.setRangeDescription("TimePeriodValue[1-January-1970,2.8799999E7]");
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        boolean boolean41 = day12.equals((java.lang.Object) 1L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod44.equals(obj45);
        java.util.Date date47 = simpleTimePeriod44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        boolean boolean50 = day48.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate51 = day48.getSerialDate();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
        boolean boolean53 = day12.equals((java.lang.Object) serialDate51);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(serialDate51);
        int int55 = day54.getDayOfMonth();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj59 = null;
        boolean boolean60 = simpleTimePeriod58.equals(obj59);
        java.util.Date date61 = simpleTimePeriod58.getEnd();
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date61);
        boolean boolean64 = day62.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate65 = day62.getSerialDate();
        long long66 = day62.getSerialIndex();
        org.jfree.data.time.SerialDate serialDate67 = day62.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = day62.next();
        long long69 = regularTimePeriod68.getMiddleMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue71 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) regularTimePeriod68, (double) 28799999L);
        int int72 = day54.compareTo((java.lang.Object) timePeriodValue71);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 31 + "'", int55 == 31);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(serialDate65);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 25568L + "'", long66 == 25568L);
        org.junit.Assert.assertNotNull(serialDate67);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 71999999L + "'", long69 == 71999999L);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        int int10 = day6.getYear();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = day6.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setKey((java.lang.Comparable) 'a');
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod6 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue8 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod6, (double) 0);
        java.util.Date date9 = simpleTimePeriod6.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj14 = null;
        boolean boolean15 = simpleTimePeriod13.equals(obj14);
        java.util.Date date16 = simpleTimePeriod13.getEnd();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        boolean boolean19 = day17.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate20 = day17.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass24 = simpleTimePeriod23.getClass();
        long long25 = simpleTimePeriod23.getEndMillis();
        long long26 = simpleTimePeriod23.getStartMillis();
        java.util.Date date27 = simpleTimePeriod23.getStart();
        boolean boolean28 = day17.equals((java.lang.Object) date27);
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date27, timeZone29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date9, timeZone29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year31.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues34.setRangeDescription("hi!");
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timePeriodValues34.removePropertyChangeListener(propertyChangeListener37);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener39 = null;
        timePeriodValues34.removeChangeListener(seriesChangeListener39);
        java.lang.Class<?> wildcardClass41 = timePeriodValues34.getClass();
        boolean boolean42 = year31.equals((java.lang.Object) wildcardClass41);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) year31, (java.lang.Number) 2019L);
        java.util.Calendar calendar45 = null;
        try {
            long long46 = year31.getLastMillisecond(calendar45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date5);
        java.lang.String str8 = year7.toString();
        long long9 = year7.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year7.next();
        long long11 = year7.getLastMillisecond();
        long long12 = year7.getFirstMillisecond();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod15 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj16 = null;
        boolean boolean17 = simpleTimePeriod15.equals(obj16);
        java.util.Date date18 = simpleTimePeriod15.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        boolean boolean21 = day19.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate22 = day19.getSerialDate();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(serialDate22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(serialDate22);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(serialDate22);
        boolean boolean26 = year7.equals((java.lang.Object) day25);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28799999L + "'", long9 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28799999L + "'", long11 == 28799999L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-31507200000L) + "'", long12 == (-31507200000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass3 = simpleTimePeriod2.getClass();
        long long4 = simpleTimePeriod2.getEndMillis();
        long long5 = simpleTimePeriod2.getStartMillis();
        long long6 = simpleTimePeriod2.getStartMillis();
        java.util.Date date7 = simpleTimePeriod2.getStart();
        long long8 = simpleTimePeriod2.getStartMillis();
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod2.equals(obj9);
        java.util.Date date11 = simpleTimePeriod2.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        java.lang.Class<?> wildcardClass13 = date11.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 10L + "'", long4 == 10L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setRangeDescription("hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        timePeriodValues1.setNotify(false);
        int int8 = timePeriodValues1.getItemCount();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = timePeriodValues1.createCopy((int) (short) 1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(timePeriodValues7);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        int int16 = day13.getMonth();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod19 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj20 = null;
        boolean boolean21 = simpleTimePeriod19.equals(obj20);
        java.util.Date date22 = simpleTimePeriod19.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        boolean boolean25 = day23.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate26 = day23.getSerialDate();
        int int27 = day23.getYear();
        long long28 = day23.getFirstMillisecond();
        int int29 = day13.compareTo((java.lang.Object) long28);
        java.util.Date date30 = day13.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj34 = null;
        boolean boolean35 = simpleTimePeriod33.equals(obj34);
        java.util.Date date36 = simpleTimePeriod33.getEnd();
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
        boolean boolean39 = day37.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate40 = day37.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod43 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass44 = simpleTimePeriod43.getClass();
        long long45 = simpleTimePeriod43.getEndMillis();
        long long46 = simpleTimePeriod43.getStartMillis();
        java.util.Date date47 = simpleTimePeriod43.getStart();
        boolean boolean48 = day37.equals((java.lang.Object) date47);
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date47, timeZone49);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date30, timeZone49);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-57600000L) + "'", long28 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(serialDate40);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 10L + "'", long45 == 10L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(timeZone49);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(serialDate9);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(serialDate9);
        java.lang.String str13 = day12.toString();
        int int14 = day12.getDayOfMonth();
        long long15 = day12.getSerialIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "31-December-1969" + "'", str13.equals("31-December-1969"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 31 + "'", int14 == 31);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 25568L + "'", long15 == 25568L);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.lang.Number number5 = timePeriodValue4.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj9 = null;
        boolean boolean10 = simpleTimePeriod8.equals(obj9);
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        boolean boolean14 = day12.equals((java.lang.Object) '4');
        long long15 = day12.getMiddleMillisecond();
        long long16 = day12.getFirstMillisecond();
        boolean boolean17 = timePeriodValue4.equals((java.lang.Object) day12);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj21 = null;
        boolean boolean22 = simpleTimePeriod20.equals(obj21);
        java.util.Date date23 = simpleTimePeriod20.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        int int26 = day12.compareTo((java.lang.Object) date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues28.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues33 = timePeriodValues28.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues35.setKey((java.lang.Comparable) 'a');
        boolean boolean38 = timePeriodValues28.equals((java.lang.Object) 'a');
        boolean boolean39 = day12.equals((java.lang.Object) timePeriodValues28);
        boolean boolean41 = day12.equals((java.lang.Object) 1L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj45 = null;
        boolean boolean46 = simpleTimePeriod44.equals(obj45);
        java.util.Date date47 = simpleTimePeriod44.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        boolean boolean50 = day48.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate51 = day48.getSerialDate();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(serialDate51);
        boolean boolean53 = day12.equals((java.lang.Object) serialDate51);
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(serialDate51);
        org.jfree.data.time.TimePeriodValue timePeriodValue56 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day54, (double) 10.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = day54.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = day54.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = day54.next();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-14400001L) + "'", long15 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-57600000L) + "'", long16 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(serialDate51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues1.getMinEndIndex();
        boolean boolean7 = timePeriodValues1.getNotify();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues1.createCopy(5, 4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timePeriodValues10);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues1.setKey((java.lang.Comparable) 'a');
        int int4 = timePeriodValues1.getMinStartIndex();
        int int5 = timePeriodValues1.getMaxStartIndex();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue10 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (double) 0);
        java.lang.Number number11 = timePeriodValue10.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj15 = null;
        boolean boolean16 = simpleTimePeriod14.equals(obj15);
        java.util.Date date17 = simpleTimePeriod14.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        boolean boolean20 = day18.equals((java.lang.Object) '4');
        long long21 = day18.getMiddleMillisecond();
        long long22 = day18.getFirstMillisecond();
        boolean boolean23 = timePeriodValue10.equals((java.lang.Object) day18);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj27 = null;
        boolean boolean28 = simpleTimePeriod26.equals(obj27);
        java.util.Date date29 = simpleTimePeriod26.getEnd();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date29);
        int int32 = day18.compareTo((java.lang.Object) date29);
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues34.setNotify(true);
        org.jfree.data.time.TimePeriodValues timePeriodValues39 = timePeriodValues34.createCopy(12, 4);
        org.jfree.data.time.TimePeriodValues timePeriodValues41 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        timePeriodValues41.setKey((java.lang.Comparable) 'a');
        boolean boolean44 = timePeriodValues34.equals((java.lang.Object) 'a');
        boolean boolean45 = day18.equals((java.lang.Object) timePeriodValues34);
        boolean boolean47 = day18.equals((java.lang.Object) 1L);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj51 = null;
        boolean boolean52 = simpleTimePeriod50.equals(obj51);
        java.util.Date date53 = simpleTimePeriod50.getEnd();
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date53);
        boolean boolean56 = day54.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate57 = day54.getSerialDate();
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(serialDate57);
        boolean boolean59 = day18.equals((java.lang.Object) serialDate57);
        int int60 = day18.getYear();
        long long61 = day18.getFirstMillisecond();
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day18, (double) 10);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod66 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj67 = null;
        boolean boolean68 = simpleTimePeriod66.equals(obj67);
        java.util.Date date69 = simpleTimePeriod66.getEnd();
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date69);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod73 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj74 = null;
        boolean boolean75 = simpleTimePeriod73.equals(obj74);
        java.util.Date date76 = simpleTimePeriod73.getEnd();
        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day(date76);
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year(date76);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod79 = new org.jfree.data.time.SimpleTimePeriod(date69, date76);
        timePeriodValues1.setKey((java.lang.Comparable) simpleTimePeriod79);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.0d + "'", number11.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-14400001L) + "'", long21 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-57600000L) + "'", long22 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(timePeriodValues39);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(serialDate57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1969 + "'", int60 == 1969);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-57600000L) + "'", long61 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(date76);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        boolean boolean7 = timePeriodValues1.isEmpty();
        java.lang.String str8 = timePeriodValues1.getDescription();
        timePeriodValues1.setNotify(false);
        java.lang.Object obj11 = timePeriodValues1.clone();
        try {
            java.lang.Number number13 = timePeriodValues1.getValue(9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + ' ' + "'", comparable6.equals(' '));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        timePeriodValues1.setNotify(true);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener4);
        java.lang.Comparable comparable6 = timePeriodValues1.getKey();
        int int7 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues1.createCopy(12, 3);
        java.lang.Class<?> wildcardClass11 = timePeriodValues10.getClass();
        boolean boolean12 = timePeriodValues10.isEmpty();
        try {
            org.jfree.data.time.TimePeriod timePeriod14 = timePeriodValues10.getTimePeriod((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + ' ' + "'", comparable6.equals(' '));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener16);
        int int18 = timePeriodValues1.getMaxEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0.0d);
        int int21 = timePeriodValues20.getMinEndIndex();
        int int22 = timePeriodValues20.getMinEndIndex();
        boolean boolean23 = timePeriodValues20.isEmpty();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue28 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod26, (double) 0);
        java.lang.Number number29 = timePeriodValue28.getValue();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj33 = null;
        boolean boolean34 = simpleTimePeriod32.equals(obj33);
        java.util.Date date35 = simpleTimePeriod32.getEnd();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        boolean boolean38 = day36.equals((java.lang.Object) '4');
        long long39 = day36.getMiddleMillisecond();
        long long40 = day36.getFirstMillisecond();
        boolean boolean41 = timePeriodValue28.equals((java.lang.Object) day36);
        java.lang.Number number42 = timePeriodValue28.getValue();
        java.lang.Object obj43 = timePeriodValue28.clone();
        timePeriodValues20.add(timePeriodValue28);
        java.beans.PropertyChangeListener propertyChangeListener45 = null;
        timePeriodValues20.removePropertyChangeListener(propertyChangeListener45);
        boolean boolean47 = timePeriodValues1.equals((java.lang.Object) propertyChangeListener45);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 0.0d + "'", number29.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-14400001L) + "'", long39 == (-14400001L));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-57600000L) + "'", long40 == (-57600000L));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 0.0d + "'", number42.equals(0.0d));
        org.junit.Assert.assertNotNull(obj43);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 'a');
        boolean boolean2 = timePeriodValues1.isEmpty();
        int int3 = timePeriodValues1.getItemCount();
        int int4 = timePeriodValues1.getItemCount();
        timePeriodValues1.setDomainDescription("Value");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 'a');
        java.lang.Object obj2 = timePeriodValues1.clone();
        java.lang.Class<?> wildcardClass3 = obj2.getClass();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        long long10 = day6.getSerialIndex();
        int int11 = day6.getYear();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 25568L + "'", long10 == 25568L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        boolean boolean8 = day6.equals((java.lang.Object) '4');
        org.jfree.data.time.SerialDate serialDate9 = day6.getSerialDate();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 0, (long) 10);
        java.lang.Class<?> wildcardClass13 = simpleTimePeriod12.getClass();
        long long14 = simpleTimePeriod12.getEndMillis();
        long long15 = simpleTimePeriod12.getStartMillis();
        java.util.Date date16 = simpleTimePeriod12.getStart();
        boolean boolean17 = day6.equals((java.lang.Object) date16);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16, timeZone18);
        long long20 = day19.getMiddleMillisecond();
        int int21 = day19.getMonth();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        int int24 = timePeriodValues23.getMaxEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timePeriodValues23.addChangeListener(seriesChangeListener25);
        int int27 = timePeriodValues23.getItemCount();
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean30 = timePeriodValues29.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener31 = null;
        timePeriodValues29.addChangeListener(seriesChangeListener31);
        timePeriodValues29.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj38 = null;
        boolean boolean39 = simpleTimePeriod37.equals(obj38);
        java.util.Date date40 = simpleTimePeriod37.getEnd();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date40);
        timePeriodValues29.add((org.jfree.data.time.TimePeriod) day41, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day41.next();
        long long45 = day41.getSerialIndex();
        timePeriodValues23.add((org.jfree.data.time.TimePeriod) day41, (java.lang.Number) 1);
        boolean boolean48 = day19.equals((java.lang.Object) day41);
        int int49 = day41.getYear();
        boolean boolean51 = day41.equals((java.lang.Object) "31-December-1969");
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-14400001L) + "'", long20 == (-14400001L));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 25568L + "'", long45 == 25568L);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1969 + "'", int49 == 1969);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setDomainDescription("hi!");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.lang.Object obj10 = null;
        boolean boolean11 = simpleTimePeriod9.equals(obj10);
        java.util.Date date12 = simpleTimePeriod9.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timePeriodValues1.add((org.jfree.data.time.TimePeriod) day13, (java.lang.Number) 100);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day13.next();
        long long17 = day13.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day13.next();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day13);
        java.lang.String str20 = seriesChangeEvent19.toString();
        java.lang.Object obj21 = seriesChangeEvent19.getSource();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 25568L + "'", long17 == 25568L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=31-December-1969]" + "'", str20.equals("org.jfree.data.general.SeriesChangeEvent[source=31-December-1969]"));
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Value");
        java.lang.String str2 = seriesException1.toString();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        java.lang.String str4 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.general.SeriesException: Value" + "'", str2.equals("org.jfree.data.general.SeriesException: Value"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: Value" + "'", str4.equals("org.jfree.data.general.SeriesException: Value"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) ' ');
        boolean boolean2 = timePeriodValues1.getNotify();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener3 = null;
        timePeriodValues1.addChangeListener(seriesChangeListener3);
        timePeriodValues1.setNotify(false);
        timePeriodValues1.setNotify(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod2, (double) 0);
        java.util.Date date5 = simpleTimePeriod2.getEnd();
        long long6 = simpleTimePeriod2.getStartMillis();
        java.util.Date date7 = simpleTimePeriod2.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(100, (int) (byte) 0, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) "Time", "org.jfree.data.general.SeriesException: hi!", "");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener4);
        int int6 = timePeriodValues3.getMaxMiddleIndex();
        int int7 = timePeriodValues3.getMaxMiddleIndex();
        java.lang.Object obj8 = null;
        boolean boolean9 = timePeriodValues3.equals(obj8);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        java.util.Date date3 = simpleTimePeriod2.getStart();
        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3, timeZone4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date3, "Value", "org.jfree.data.time.TimePeriodFormatException: org.jfree.data.general.SeriesChangeEvent[source=a]");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod((-1L), (long) 5);
        org.jfree.data.time.TimePeriodValue timePeriodValue13 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) simpleTimePeriod11, (double) 0);
        java.util.Date date14 = simpleTimePeriod11.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date3, date14);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date3);
        long long18 = year17.getFirstMillisecond();
        java.util.Calendar calendar19 = null;
        try {
            year17.peg(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-31507200000L) + "'", long18 == (-31507200000L));
    }
}

